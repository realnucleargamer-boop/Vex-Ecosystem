#!/usr/bin/env python3
"""VEX-Script 1.4 focused tests + full regression driver."""

import sys
import io
from pathlib import Path
from contextlib import redirect_stdout

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vexscript.interpreter import Interpreter
from vexscript.errors import VexError
from vexscript.lexer import Lexer, TokenKind

PASSED = 0
FAILED = 0


def check(name, cond, detail=""):
    global PASSED, FAILED
    if cond:
        PASSED += 1
        print(f"  PASS  {name}")
    else:
        FAILED += 1
        print(f"  FAIL  {name}  {detail}")


def run(src, filename="<test>"):
    interp = Interpreter()
    buf = io.StringIO()
    with redirect_stdout(buf):
        interp.load(src, filename)
        code = interp.run_main()
    return code, buf.getvalue()


def expect_ok(src, expected_out, name, filename="<test>"):
    try:
        code, out = run(src, filename)
        ok = code == 0 and out == expected_out
        check(name, ok, f"rc={code} out={out!r}")
    except VexError as e:
        check(name, False, str(e))


def expect_fail(src, name, must_contain=None):
    try:
        run(src)
        check(name, False, "should have been rejected")
    except VexError as e:
        msg = str(e)
        ok = True if must_contain is None else must_contain.lower() in msg.lower()
        check(name, ok, msg if not ok else "")


def test_structs_1_4():
    print("\n=== 1.4 Structs ===")
    expect_ok("""
struct Point { x: i64 y: i64 }
struct Box { position: Point }
fn main() -> i32 {
    let mut b = Box { position: Point { x: 10, y: 20 } };
    println(b.position.x);
    b.position.x = 99;
    println(b.position.x);
    return 0;
}
""", "10\n99\n", "nested construct+chained mutate")

    expect_fail("""
struct Point { x: i64 y: i64 }
struct Box { position: Point }
fn main() -> i32 {
    let b = Box { position: Point { x: 1, y: 2 } };
    b.position.x = 5;
    return 0;
}
""", "immutable chained mutate", "immutable")

    expect_fail("""
struct Point { x: i64 y: i64 }
struct Box { position: Point }
fn main() -> i32 {
    let b = Box { position: true };
    return 0;
}
""", "bad nested type", "expected")

    expect_fail("""
struct Point { x: i64 y: i64 }
fn main() -> i32 {
    let p = Point { x: 1 };
    return 0;
}
""", "missing field", "missing")

    expect_fail("""
struct Point { x: i64 y: i64 }
fn main() -> i32 {
    let p = Point { x: 1, y: 2, z: 3 };
    return 0;
}
""", "unknown field", "no field")

    expect_fail("""
fn main() -> i32 {
    let x: i64 = 1;
    let y = x.foo;
    return 0;
}
""", "field on primitive", "non-struct")


def test_functions_1_4():
    print("\n=== 1.4 Functions ===")
    expect_ok("""
fn add(a: i64, b: i64) -> i64 { return a + b; }
fn main() -> i32 {
    println(add(10, 20));
    println(add(add(1, 2), 3));
    return 0;
}
""", "30\n6\n", "nested calls")

    expect_fail("""
fn add(a: i64, b: i64) -> i64 { return a + b; }
fn main() -> i32 { add(true, 10); return 0; }
""", "wrong arg type", "expected")

    expect_fail("""
fn add(a: i64, b: i64) -> i64 { return a + b; }
fn main() -> i32 { add(10); return 0; }
""", "wrong arity", "expects 2")

    expect_fail("""
fn main() -> i32 { return true; }
""", "bad return type", "return type")


def test_modules_1_4():
    print("\n=== 1.4 Modules ===")
    # two modules with same function name
    a = ROOT / "examples" / "_mod_a.vex"
    b = ROOT / "examples" / "_mod_b.vex"
    a.write_text("pub fn value() -> i64 { return 1; }\n")
    b.write_text("pub fn value() -> i64 { return 2; }\n")
    src = """
use _mod_a;
use _mod_b;
fn main() -> i32 {
    println(_mod_a::value());
    println(_mod_b::value());
    return 0;
}
"""
    expect_ok(src, "1\n2\n", "same name different modules",
              filename=str(ROOT / "examples" / "use_both.vex"))

    expect_ok(
        Path(ROOT / "examples/use_math.vex").read_text(),
        "25\n30\n",
        "qualified math_mod",
        filename=str(ROOT / "examples/use_math.vex"),
    )

    expect_fail("use nonexistent_xyz;\nfn main() -> i32 { return 0; }\n",
                "missing module", "not found")

    # missing qualified symbol after successful module load
    try:
        src = Path(ROOT / "examples/use_math.vex").read_text().replace(
            "math_mod::square(5)", "math_mod::nope()"
        )
        run(src, str(ROOT / "examples/use_math.vex"))
        check("missing symbol", False, "should reject")
    except VexError as e:
        check("missing symbol", "undefined" in str(e).lower(), str(e))


def test_diagnostics():
    print("\n=== 1.4 Diagnostics ===")
    try:
        run("fn main() -> i32 {\n    let x: i64 = true;\n    return 0;\n}\n", "diag.vex")
        check("diag has location", False)
    except VexError as e:
        msg = str(e)
        check("diag has file", "diag.vex" in msg, msg)
        check("diag has line", ":2:" in msg or ":3:" in msg, msg)
        check("diag mentions types", "i64" in msg and "bool" in msg, msg)


def test_lexer_coloncolon():
    print("\n=== 1.4 Lexer :: ===")
    toks = Lexer("math::add").tokenize()
    kinds = [t.kind for t in toks]
    check("has COLONCOLON", TokenKind.COLONCOLON in kinds)


def main():
    print("VEX-Script 1.4 Test Suite")
    test_lexer_coloncolon()
    test_structs_1_4()
    test_functions_1_4()
    test_modules_1_4()
    test_diagnostics()
    print(f"\n=== 1.4 Results: {PASSED} passed, {FAILED} failed ===")
    return 0 if FAILED == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
