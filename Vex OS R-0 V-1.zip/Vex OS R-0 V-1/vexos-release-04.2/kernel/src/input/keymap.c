#include "keymap.h"
#include "input.h"
int vex_key_ascii(uint16_t k, uint16_t mods)
{
    int shift = (mods & (VEX_MOD_LSHIFT | VEX_MOD_RSHIFT)) != 0;
    if (k >= 4 && k <= 29) return (shift ? 'A' : 'a') + (k - 4);
    if (k >= 30 && k <= 38) return shift ? "!@#$%^&*("[k - 30] : '1' + (k - 30);
    if (k == 39) return shift ? ')' : '0';
    if (k == 44) return ' ';
    static const char lo[] = "-=[]\\", hi[] = "_+{}|";          /* HID 45..49 */
    if (k >= 45 && k <= 49) return shift ? hi[k - 45] : lo[k - 45];
    static const char lo2[] = ";'`,./", hi2[] = ":\"~<>?";         /* HID 51..56 */
    if (k >= 51 && k <= 56) return shift ? hi2[k - 51] : lo2[k - 51];
    return 0;
}
