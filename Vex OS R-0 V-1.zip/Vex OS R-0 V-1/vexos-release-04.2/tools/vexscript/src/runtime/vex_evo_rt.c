/* Native evolutionary/genome runtime — pure C, no Python. */
#include "vex_evo_rt.h"
#include <string.h>
#include <stdlib.h>

static uint64_t rng_state = 0x9E3779B97F4A7C15ULL;

void vex_rt_rng_seed(int64_t seed) {
    rng_state = (uint64_t)seed;
    if (rng_state == 0) rng_state = 0x9E3779B97F4A7C15ULL;
}

int64_t vex_rt_rng_u64(void) {
    rng_state = rng_state + 0x9E3779B97F4A7C15ULL;
    uint64_t z = rng_state;
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    return (int64_t)(z ^ (z >> 31));
}

static uint64_t rng_u64_raw(void) {
    return (uint64_t)vex_rt_rng_u64();
}

/* ---- genomes ---- */
typedef struct {
    int used;
    int capacity;
    int len;
    char data[VEX_MAX_GENOME_LEN];
} Genome;

static Genome genomes[VEX_MAX_GENOMES];
static int next_gid = 1;

static Genome *G(int64_t gid) {
    if (gid <= 0 || gid >= VEX_MAX_GENOMES || !genomes[gid].used) return NULL;
    return &genomes[gid];
}

int64_t vex_rt_genome_create(int64_t capacity) {
    if (next_gid >= VEX_MAX_GENOMES) return -1;
    int id = next_gid++;
    genomes[id].used = 1;
    genomes[id].capacity = (int)capacity;
    if (genomes[id].capacity > VEX_MAX_GENOME_LEN)
        genomes[id].capacity = VEX_MAX_GENOME_LEN;
    genomes[id].len = 0;
    return id;
}

int64_t vex_rt_genome_length(int64_t gid) {
    Genome *g = G(gid);
    return g ? g->len : 0;
}

int64_t vex_rt_genome_char_code_at(int64_t gid, int64_t index) {
    Genome *g = G(gid);
    if (!g || index < 0 || index >= g->len) return -1;
    return (unsigned char)g->data[index];
}

int64_t vex_rt_genome_set_char_code(int64_t gid, int64_t index, int64_t code) {
    Genome *g = G(gid);
    if (!g || index < 0 || index >= g->len) return -1;
    g->data[index] = (char)(code & 0xFF);
    return 0;
}

int64_t vex_rt_genome_fill_code(int64_t gid, int64_t code, int64_t length) {
    Genome *g = G(gid);
    if (!g) return -1;
    int n = (int)length;
    if (n < 0) n = 0;
    if (n > VEX_MAX_GENOME_LEN) n = VEX_MAX_GENOME_LEN;
    if (g->capacity > 0 && n > g->capacity) n = g->capacity;
    memset(g->data, (int)(code & 0xFF), (size_t)n);
    g->len = n;
    return 0;
}

int64_t vex_rt_genome_copy(int64_t gid) {
    Genome *g = G(gid);
    if (!g) return -1;
    int64_t nid = vex_rt_genome_create(g->capacity);
    if (nid < 0) return -1;
    Genome *n = G(nid);
    n->len = g->len;
    memcpy(n->data, g->data, (size_t)g->len);
    return nid;
}

int64_t vex_rt_genome_compare(int64_t a, int64_t b) {
    Genome *ga = G(a), *gb = G(b);
    if (!ga || !gb) return 0;
    int n = ga->len < gb->len ? ga->len : gb->len;
    int c = memcmp(ga->data, gb->data, (size_t)n);
    if (c < 0) return -1;
    if (c > 0) return 1;
    if (ga->len < gb->len) return -1;
    if (ga->len > gb->len) return 1;
    return 0;
}

int64_t vex_rt_genome_slice(int64_t gid, int64_t start, int64_t end) {
    Genome *g = G(gid);
    if (!g) return -1;
    int a = (int)start, b = (int)end;
    if (a < 0) a = 0;
    if (a > g->len) a = g->len;
    if (b < a) b = a;
    if (b > g->len) b = g->len;
    int64_t nid = vex_rt_genome_create(g->capacity);
    if (nid < 0) return -1;
    Genome *n = G(nid);
    n->len = b - a;
    memcpy(n->data, g->data + a, (size_t)n->len);
    return nid;
}

/* ---- populations as float weight vectors (stream candidates) ---- */
typedef struct {
    int used;
    int n;
    int dim;
    float data[VEX_MAX_POP_SIZE * VEX_MAX_DIM];
} Pop;

static Pop pops[VEX_MAX_POPS];
static int next_pid = 1;

static Pop *P(int64_t pid) {
    if (pid <= 0 || pid >= VEX_MAX_POPS || !pops[pid].used) return NULL;
    return &pops[pid];
}

static int64_t pop_create(int n, int dim) {
    if (next_pid >= VEX_MAX_POPS) return -1;
    if (n > VEX_MAX_POP_SIZE) n = VEX_MAX_POP_SIZE;
    if (dim > VEX_MAX_DIM) dim = VEX_MAX_DIM;
    if (n <= 0 || dim <= 0) return -1;
    int id = next_pid++;
    pops[id].used = 1;
    pops[id].n = n;
    pops[id].dim = dim;
    memset(pops[id].data, 0, sizeof(pops[id].data));
    return id;
}

typedef struct {
    int used;
    int64_t pop_id;
    int generation;
    int elite_count;
    int64_t scores[VEX_MAX_POP_SIZE];
} Stream;

static Stream streams[VEX_MAX_STREAMS];
static int next_sid = 1;

static Stream *S(int64_t sid) {
    if (sid <= 0 || sid >= VEX_MAX_STREAMS || !streams[sid].used) return NULL;
    return &streams[sid];
}

int64_t vex_rt_stream_create(int64_t n, int64_t dim, int64_t elite_count) {
    int64_t pid = pop_create((int)n, (int)dim);
    if (pid < 0) return -1;
    if (next_sid >= VEX_MAX_STREAMS) return -1;
    int id = next_sid++;
    streams[id].used = 1;
    streams[id].pop_id = pid;
    streams[id].generation = 0;
    streams[id].elite_count = elite_count > 0 ? (int)elite_count : 0;
    memset(streams[id].scores, 0, sizeof(streams[id].scores));
    /* randomize population lightly */
    Pop *p = P(pid);
    for (int i = 0; i < p->n * p->dim; i++) {
        p->data[i] = (float)((rng_u64_raw() % 1000) / 1000.0 - 0.5);
    }
    return id;
}

int64_t vex_rt_stream_size(int64_t sid) {
    Stream *s = S(sid);
    if (!s) return 0;
    Pop *p = P(s->pop_id);
    return p ? p->n : 0;
}

int64_t vex_rt_stream_generation(int64_t sid) {
    Stream *s = S(sid);
    return s ? s->generation : 0;
}

int64_t vex_rt_stream_set_elite_count(int64_t sid, int64_t n) {
    Stream *s = S(sid);
    if (!s) return -1;
    s->elite_count = n > 0 ? (int)n : 0;
    return 0;
}

int64_t vex_rt_stream_pop(int64_t sid) {
    Stream *s = S(sid);
    return s ? s->pop_id : -1;
}

int64_t vex_rt_fitness_set(int64_t sid, int64_t index, int64_t score) {
    Stream *s = S(sid);
    if (!s) return -1;
    Pop *p = P(s->pop_id);
    if (!p || index < 0 || index >= p->n) return -1;
    s->scores[index] = score;
    return 0;
}

int64_t vex_rt_fitness_get(int64_t sid, int64_t index) {
    Stream *s = S(sid);
    if (!s) return 0;
    Pop *p = P(s->pop_id);
    if (!p || index < 0 || index >= p->n) return 0;
    return s->scores[index];
}

int64_t vex_rt_fitness_best_index(int64_t sid) {
    Stream *s = S(sid);
    if (!s) return 0;
    Pop *p = P(s->pop_id);
    if (!p || p->n == 0) return 0;
    int best = 0;
    for (int i = 1; i < p->n; i++)
        if (s->scores[i] > s->scores[best]) best = i;
    return best;
}

int64_t vex_rt_fitness_worst_index(int64_t sid) {
    Stream *s = S(sid);
    if (!s) return 0;
    Pop *p = P(s->pop_id);
    if (!p || p->n == 0) return 0;
    int w = 0;
    for (int i = 1; i < p->n; i++)
        if (s->scores[i] < s->scores[w]) w = i;
    return w;
}

int64_t vex_rt_fitness_sum(int64_t sid) {
    Stream *s = S(sid);
    if (!s) return 0;
    Pop *p = P(s->pop_id);
    if (!p) return 0;
    int64_t sum = 0;
    for (int i = 0; i < p->n; i++) sum += s->scores[i];
    return sum;
}

int64_t vex_rt_fitness_average(int64_t sid) {
    Stream *s = S(sid);
    if (!s) return 0;
    Pop *p = P(s->pop_id);
    if (!p || p->n == 0) return 0;
    return vex_rt_fitness_sum(sid) / p->n;
}

int64_t vex_rt_elite_preserve_count(int64_t sid) {
    Stream *s = S(sid);
    return s ? s->elite_count : 0;
}

static void copy_cand(Pop *p, int dst, int src) {
    float *d = p->data + dst * p->dim;
    float *s = p->data + src * p->dim;
    memcpy(d, s, sizeof(float) * (size_t)p->dim);
}

int64_t vex_rt_stream_advance(int64_t sid, int64_t rate_milli) {
    Stream *st = S(sid);
    if (!st) return -1;
    Pop *p = P(st->pop_id);
    if (!p || p->n == 0) { st->generation++; return st->generation; }

    /* rank indices by score */
    int order[VEX_MAX_POP_SIZE];
    for (int i = 0; i < p->n; i++) order[i] = i;
    for (int i = 0; i < p->n; i++)
        for (int j = i + 1; j < p->n; j++)
            if (st->scores[order[j]] > st->scores[order[i]]) {
                int t = order[i]; order[i] = order[j]; order[j] = t;
            }
    int elite_n = st->elite_count;
    if (elite_n > p->n) elite_n = p->n;
    if (elite_n < 0) elite_n = 0;

    /* snapshot elite vectors */
    float elite_buf[VEX_MAX_POP_SIZE * VEX_MAX_DIM];
    for (int e = 0; e < elite_n; e++) {
        memcpy(elite_buf + e * p->dim, p->data + order[e] * p->dim,
               sizeof(float) * (size_t)p->dim);
    }

    /* rebuild: elites first, then mutated children */
    for (int e = 0; e < elite_n; e++) {
        memcpy(p->data + e * p->dim, elite_buf + e * p->dim,
               sizeof(float) * (size_t)p->dim);
    }
    for (int i = elite_n; i < p->n; i++) {
        int pi = elite_n > 0 ? order[rng_u64_raw() % (uint64_t)elite_n] : (int)(rng_u64_raw() % (uint64_t)p->n);
        int qi = (int)(rng_u64_raw() % (uint64_t)p->n);
        for (int d = 0; d < p->dim; d++) {
            float v = (rng_u64_raw() & 1) ? p->data[pi * p->dim + d] : p->data[qi * p->dim + d];
            if ((int)(rng_u64_raw() % 1000) < (int)rate_milli) {
                v += (float)((rng_u64_raw() % 100) / 1000.0 - 0.05);
            }
            p->data[i * p->dim + d] = v;
        }
    }
    st->generation++;
    return st->generation;
}

int64_t vex_rt_migrate_copy(int64_t src, int64_t si, int64_t dst, int64_t di) {
    Stream *a = S(src), *b = S(dst);
    if (!a || !b) return -1;
    Pop *pa = P(a->pop_id), *pb = P(b->pop_id);
    if (!pa || !pb) return -1;
    if (si < 0 || si >= pa->n || di < 0 || di >= pb->n) return -1;
    if (pa->dim != pb->dim) return -1;
    memcpy(pb->data + di * pb->dim, pa->data + si * pa->dim,
           sizeof(float) * (size_t)pa->dim);
    b->scores[di] = a->scores[si];
    return 0;
}

int64_t vex_rt_migrate_best(int64_t src, int64_t dst, int64_t di) {
    int64_t bi = vex_rt_fitness_best_index(src);
    return vex_rt_migrate_copy(src, bi, dst, di);
}

int64_t vex_rt_diversity_hamming_avg(int64_t sid) {
    Stream *st = S(sid);
    if (!st) return 0;
    Pop *p = P(st->pop_id);
    if (!p || p->n < 2 || p->dim == 0) return 0;
    int64_t total = 0, pairs = 0;
    for (int i = 0; i < p->n; i++) {
        for (int j = i + 1; j < p->n; j++) {
            int d = 0;
            for (int k = 0; k < p->dim; k++) {
                if (p->data[i * p->dim + k] != p->data[j * p->dim + k]) d++;
            }
            total += d;
            pairs++;
        }
    }
    if (!pairs) return 0;
    return (total * 1000) / (pairs * p->dim);
}


int64_t vex_rt_genome_from_cstr(const char *s) {
    if (!s) s = "";
    int64_t gid = vex_rt_genome_create(0);
    if (gid < 0) return -1;
    Genome *g = G(gid);
    int n = 0;
    while (s[n] && n < VEX_MAX_GENOME_LEN) n++;
    memcpy(g->data, s, (size_t)n);
    g->len = n;
    return gid;
}

static char char_at_buf[2];

const char *vex_rt_genome_char_at(int64_t gid, int64_t index) {
    Genome *g = G(gid);
    char_at_buf[0] = 0;
    char_at_buf[1] = 0;
    if (!g || index < 0 || index >= g->len) return char_at_buf;
    char_at_buf[0] = g->data[index];
    return char_at_buf;
}

const char *vex_rt_genome_to_cstr(int64_t gid) {
    Genome *g = G(gid);
    static char empty[] = "";
    if (!g) return empty;
    if (g->len < VEX_MAX_GENOME_LEN) {
        g->data[g->len] = 0;
        return g->data;
    }
    /* at max capacity cannot NUL terminate in-place safely for full buffer */
    static char spill[VEX_MAX_GENOME_LEN + 1];
    int n = g->len < VEX_MAX_GENOME_LEN ? g->len : VEX_MAX_GENOME_LEN;
    memcpy(spill, g->data, (size_t)n);
    spill[n] = 0;
    return spill;
}

int64_t vex_rt_genome_set_char(int64_t gid, int64_t index, const char *ch) {
    if (!ch || !ch[0]) return -1;
    return vex_rt_genome_set_char_code(gid, index, (unsigned char)ch[0]);
}

int64_t vex_rt_genome_append_char(int64_t gid, const char *ch) {
    Genome *g = G(gid);
    if (!g || !ch || !ch[0]) return -1;
    if (g->len >= VEX_MAX_GENOME_LEN) return -1;
    if (g->capacity > 0 && g->len >= g->capacity) return -1;
    g->data[g->len++] = ch[0];
    return 0;
}

int64_t vex_rt_genome_fill(int64_t gid, const char *ch, int64_t length) {
    if (!ch || !ch[0]) return -1;
    return vex_rt_genome_fill_code(gid, (unsigned char)ch[0], length);
}

int64_t vex_rt_genome_match_cstr(int64_t gid, const char *target) {
    Genome *g = G(gid);
    if (!g || !target) return 0;
    int64_t hits = 0;
    int i = 0;
    while (i < g->len && target[i]) {
        if (g->data[i] == target[i]) hits++;
        i++;
    }
    return hits;
}

void vex_rt_evo_reset(void) {
    memset(genomes, 0, sizeof(genomes));
    memset(pops, 0, sizeof(pops));
    memset(streams, 0, sizeof(streams));
    next_gid = 1;
    next_pid = 1;
    next_sid = 1;
    rng_state = 0x9E3779B97F4A7C15ULL;
}
