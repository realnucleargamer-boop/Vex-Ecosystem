"""Acceleration layer for VexScript / VEX AI workloads.

PyTorch-style device + dtype model with:
- CPU tensor path (NumPy/Torch when available, else pure Python lists)
- Optional CUDA when present (auto-detect; never required)
- Task stack limited to 1–2 worker threads (hard cap)

This is NOT VEX AI 1.0 and does not load models or call external AI APIs.
"""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any, Callable
import os
import threading

# Hard policy: never more than 2 CPU worker threads for parallel tasks.
MAX_CPU_WORKERS = 2
_DEFAULT_WORKERS = 2

_device = "cpu"  # "cpu" | "cuda"
_workers = _DEFAULT_WORKERS
_pool: ThreadPoolExecutor | None = None
_pool_lock = threading.Lock()

_torch = None
_cuda_ok = False


def _init_torch():
    global _torch, _cuda_ok
    if _torch is not None or _torch is False:
        return
    try:
        import torch
        _torch = torch
        _cuda_ok = bool(torch.cuda.is_available())
    except Exception:
        _torch = False
        _cuda_ok = False


def gpu_available() -> int:
    _init_torch()
    return 1 if _cuda_ok else 0


def device_get() -> str:
    return _device


def device_set(name: str) -> int:
    """Set compute device: 'cpu' or 'cuda'/'gpu'. Returns 0 ok, -1 unsupported."""
    global _device
    n = str(name).lower().strip()
    if n in ("gpu", "cuda"):
        _init_torch()
        if not _cuda_ok:
            _device = "cpu"
            return -1  # requested GPU but unavailable
        _device = "cuda"
        return 0
    if n in ("cpu",):
        _device = "cpu"
        return 0
    return -1


def workers_set(n: int) -> int:
    """Set parallel workers to 1 or 2 only."""
    global _workers, _pool
    w = int(n)
    if w < 1:
        w = 1
    if w > MAX_CPU_WORKERS:
        w = MAX_CPU_WORKERS
    with _pool_lock:
        _workers = w
        if _pool is not None:
            _pool.shutdown(wait=False)
            _pool = None
    return _workers


def workers_get() -> int:
    return _workers


def _get_pool() -> ThreadPoolExecutor:
    global _pool
    with _pool_lock:
        if _pool is None:
            _pool = ThreadPoolExecutor(max_workers=_workers, thread_name_prefix="vex-accel")
        return _pool


def parallel_map(fn: Callable[[Any], Any], items: list) -> list:
    """Run fn over items using 1–2 workers. Order-preserving."""
    if not items:
        return []
    if _workers <= 1 or len(items) == 1:
        return [fn(x) for x in items]
    pool = _get_pool()
    futs = {pool.submit(fn, it): i for i, it in enumerate(items)}
    out: list[Any] = [None] * len(items)
    for fut in as_completed(futs):
        out[futs[fut]] = fut.result()
    return out


@dataclass
class AccelTensor:
    """Device-aware tensor (Torch backend when available)."""
    dtype: str
    shape: tuple[int, ...]
    # Either list[float] or torch.Tensor
    storage: Any
    device: str = "cpu"

    def size(self) -> int:
        n = 1
        for d in self.shape:
            n *= d
        return n

    def to_list(self) -> list[float]:
        _init_torch()
        if _torch and not isinstance(self.storage, list):
            return self.storage.detach().cpu().flatten().tolist()
        return list(self.storage)


def accel_tensor_zeros(dtype: str, *dims: int) -> AccelTensor:
    shape = tuple(int(d) for d in dims)
    n = 1
    for d in shape:
        n *= d
    _init_torch()
    dev = _device
    if _torch and _torch is not False:
        dt = _torch.float32 if dtype != "f64" else _torch.float64
        device = "cuda" if dev == "cuda" and _cuda_ok else "cpu"
        storage = _torch.zeros(shape, dtype=dt, device=device)
        return AccelTensor(dtype=dtype or "f32", shape=shape, storage=storage, device=device)
    return AccelTensor(dtype=dtype or "f32", shape=shape, storage=[0.0] * n, device="cpu")


def accel_tensor_fill(t: AccelTensor, value: float) -> AccelTensor:
    v = float(value)
    _init_torch()
    if _torch and not isinstance(t.storage, list):
        t.storage.fill_(v)
        return t
    t.storage = [v] * t.size()
    return t


def accel_matmul(a: AccelTensor, b: AccelTensor) -> AccelTensor:
    _init_torch()
    if _torch and not isinstance(a.storage, list) and not isinstance(b.storage, list):
        out = a.storage @ b.storage
        return AccelTensor(a.dtype, tuple(out.shape), out, a.device)
    # pure python fallback
    from .tensor_rt import Tensor, tensor_matmul
    ta = Tensor(a.dtype, a.shape, a.to_list())
    tb = Tensor(b.dtype, b.shape, b.to_list())
    r = tensor_matmul(ta, tb)
    return AccelTensor(r.dtype, r.shape, r.data, "cpu")


def accel_add(a: AccelTensor, b: AccelTensor) -> AccelTensor:
    _init_torch()
    if _torch and not isinstance(a.storage, list) and not isinstance(b.storage, list):
        out = a.storage + b.storage
        return AccelTensor(a.dtype, tuple(out.shape), out, a.device)
    data = [x + y for x, y in zip(a.to_list(), b.to_list())]
    return AccelTensor(a.dtype, a.shape, data, "cpu")


def stream_advance_batch(sids: list[int], rate_milli: int, rng_fn: Callable) -> list[int]:
    """Advance multiple stream ids using 1–2 workers."""
    from . import evolve_rt as er

    def one(sid: int) -> int:
        return er.stream_advance(int(sid), int(rate_milli), rng_fn)

    return parallel_map(one, list(sids))


def reset_accel_state() -> None:
    global _device, _workers, _pool
    with _pool_lock:
        if _pool is not None:
            _pool.shutdown(wait=False)
            _pool = None
    _device = "cpu"
    _workers = _DEFAULT_WORKERS
