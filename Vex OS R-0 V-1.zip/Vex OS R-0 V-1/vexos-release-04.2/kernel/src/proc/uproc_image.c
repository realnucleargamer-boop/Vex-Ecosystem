/*
 * uproc_image.c - PROC-01: pure VXE1 image validation. No kernel dependencies (stdint/stddef only), no allocation,
 * no globals: it can be compiled on the host and fuzzed under ASAN/UBSan. See kernel/include/uproc.h for the format.
 * Every size/offset arithmetic step is done in uint64_t so a hostile 32-bit header field cannot wrap.
 */
#include "uproc.h"

static uint32_t rd32(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }
static uint32_t rd16(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8); }

UprocStatus uproc_image_validate(const uint8_t *img, size_t len, UprocLayout *L)
{
    if (!img || !L) return UPROC_E_NULL;
    if (len < UPROC_HDR_SIZE) return UPROC_E_TOO_SMALL;
    if (len > UPROC_MAX_IMAGE) return UPROC_E_TOO_BIG;
    if (!(img[0] == 'V' && img[1] == 'X' && img[2] == 'E' && img[3] == '1')) return UPROC_E_MAGIC;
    if (rd16(img + 4) != 1u) return UPROC_E_VERSION;
    if (rd16(img + 6) != UPROC_HDR_SIZE) return UPROC_E_HDRSIZE;
    if (rd32(img + 8) != 0u) return UPROC_E_FLAGS;
    if (rd32(img + 40) != 0u || rd32(img + 44) != 0u) return UPROC_E_RESERVED;

    uint32_t entry = rd32(img + 12), text_off = rd32(img + 16), text_size = rd32(img + 20);
    uint32_t data_off = rd32(img + 24), data_size = rd32(img + 28), bss_size = rd32(img + 32), stack_pages = rd32(img + 36);

    if (text_size == 0u || text_size > UPROC_MAX_TEXT_PAGES * UPROC_PAGE) return UPROC_E_TEXT_SIZE;
    if (text_off < UPROC_HDR_SIZE || (uint64_t)text_off + text_size > (uint64_t)len) return UPROC_E_TEXT_RANGE;
    if (data_size == 0u) { if (data_off != 0u) return UPROC_E_DATA_RANGE; }
    else if (data_off < UPROC_HDR_SIZE || (uint64_t)data_off + data_size > (uint64_t)len) return UPROC_E_DATA_RANGE;
    uint64_t total = (uint64_t)data_size + (uint64_t)bss_size;
    if (total > (uint64_t)UPROC_MAX_DATA_PAGES * UPROC_PAGE) return UPROC_E_DATA_PAGES;
    if (data_size != 0u) {
        uint64_t te = (uint64_t)text_off + text_size, de = (uint64_t)data_off + data_size;
        if (!(te <= data_off || de <= text_off)) return UPROC_E_OVERLAP;
    }
    if (entry >= text_size) return UPROC_E_ENTRY;
    if (stack_pages < 1u || stack_pages > UPROC_MAX_STACK_PAGES) return UPROC_E_STACK;

    L->entry = entry; L->text_off = text_off; L->text_size = text_size;
    L->data_off = data_off; L->data_size = data_size; L->bss_size = bss_size; L->stack_pages = stack_pages;
    L->text_pages = (uint32_t)(((uint64_t)text_size + UPROC_PAGE - 1u) / UPROC_PAGE);
    L->data_pages = (uint32_t)((total + UPROC_PAGE - 1u) / UPROC_PAGE);
    return UPROC_OK;
}

const char *uproc_status_name(UprocStatus s)
{
    static const char *const n[] = { "ok", "null", "too-small", "too-big", "bad-magic", "bad-version", "bad-header-size", "bad-flags",
        "bad-reserved", "bad-text-size", "text-out-of-image", "data-out-of-image", "data-too-large", "segments-overlap",
        "entry-outside-text", "bad-stack-pages", "not-initialised", "busy", "no-memory", "map-failed" };
    return ((unsigned)s < sizeof n / sizeof n[0]) ? n[s] : "unknown";
}
