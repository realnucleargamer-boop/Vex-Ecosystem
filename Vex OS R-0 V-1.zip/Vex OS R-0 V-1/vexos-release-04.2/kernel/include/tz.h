/* Vex OS - kernel/include/tz.h : the ONE place the display timezone is defined.
 * The RTC stays UTC (rtc.h); conversion happens only for display. India Standard Time = UTC+05:30,
 * no daylight saving (Asia/Kolkata). There is no tz database: this is a fixed-offset zone. */
#ifndef VEXOS_TZ_H
#define VEXOS_TZ_H
#include "rtc.h"
#define VEX_TZ_NAME        "IST"
#define VEX_TZ_OFFSET_MIN  330
void tz_utc_to_local(const RtcTime *utc, RtcTime *local);   /* pure; handles day/month/year/leap rollover */
int  tz_local_now(RtcTime *out);                             /* rtc_read + convert; 0 if the RTC is invalid */
#endif
