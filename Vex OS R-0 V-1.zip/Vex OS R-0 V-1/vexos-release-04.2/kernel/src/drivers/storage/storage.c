/* Vex OS - kernel/src/drivers/storage/storage.c : STORAGE-01 glue. See include/storage.h. */
#include "storage.h"
#include "ahci.h"
#include "pci.h"
#include "serial.h"

static VStoreState dstate[AHCI_MAX_DISKS];
static VStore vs; static int disk = -1; static int cand_blank = -1; static int inited;
static int io_read(void *c, uint64_t lba, void *b) { return ahci_read((int)(intptr_t)c, lba, 1, b); }
static int io_write(void *c, uint64_t lba, const void *b) { return ahci_write((int)(intptr_t)c, lba, 1, b); }
static VStoreIo mkio(int d) { VStoreIo io = { (void *)(intptr_t)d, io_read, io_write, ahci_disk(d)->sectors }; return io; }

void storage_init(void)
{
    if (inited) return;
    inited = 1; vs.state = VS_NONE;
    pci_scan();
    int n = ahci_init();
    for (int d = 0; d < n; d++) {
        VStore t; VStoreIo io = mkio(d); VStoreState st = vstore_probe(&t, &io);
        dstate[d] = st;
        serial_puts("[storage] disk "); serial_put_dec64((uint64_t)d); serial_puts(": "); serial_puts(vstore_state_text(st)); serial_puts("\n");
        if (st == VS_READY && disk < 0) {
            vs = t; disk = d;
        } else if (st == VS_BLANK && cand_blank < 0) {
            cand_blank = d;
        }
    }
    if (disk < 0 && cand_blank >= 0) { VStoreIo io = mkio(cand_blank); vstore_probe(&vs, &io); disk = cand_blank; }   /* state BLANK: usable only after an explicit format */
    serial_puts("[storage] data store: "); serial_puts(vstore_state_text(vs.state)); serial_puts("\n");
}
VStoreState storage_state(void) { return vs.state; }
int storage_format(void) { if (vs.state != VS_BLANK) return 0; int ok = vstore_format(&vs); serial_puts(ok ? "[storage] formatted data disk: ok\n" : "[storage] format FAILED\n"); return ok; }
int storage_load_wallpaper(uint32_t *idx) { return vstore_get_wallpaper(&vs, idx); }
int storage_save_wallpaper(uint32_t idx) { int ok = vstore_set_wallpaper(&vs, idx); serial_puts(ok ? "[storage] saved wallpaper choice\n" : "[storage] wallpaper choice NOT saved\n"); return ok; }

static void num(char *d, int *n, uint64_t v) { char t[24]; int k = 0; if (!v) t[k++] = '0'; while (v) { t[k++] = (char)('0' + v % 10); v /= 10; } while (k) d[(*n)++] = t[--k]; }
static void str(char *d, int *n, const char *s) { while (*s && *n < 90) d[(*n)++] = *s++; }
static void hex(char *d, int *n, uint32_t v, int digs) { for (int i = digs - 1; i >= 0; i--) d[(*n)++] = "0123456789abcdef"[(v >> (4 * i)) & 15]; }
void storage_report(StorageOut out)
{
    char l[96]; int n = 0; str(l, &n, "AHCI disks found: "); num(l, &n, (uint64_t)ahci_disk_count()); l[n] = 0; out(l);
    for (int d = 0; d < ahci_disk_count(); d++) {
        n = 0; str(l, &n, " disk "); num(l, &n, (uint64_t)d); str(l, &n, ": "); str(l, &n, ahci_disk(d)->model); str(l, &n, ", "); num(l, &n, ahci_disk(d)->sectors / 2048); str(l, &n, " MiB");
        if (d == disk) str(l, &n, "  <- data disk");
        else if (dstate[d] == VS_FOREIGN) str(l, &n, "  - not a Vex data disk (left untouched)");
        l[n] = 0; out(l);
    }
    n = 0; str(l, &n, "Data store: "); str(l, &n, vstore_state_text(vs.state)); l[n] = 0; out(l);
    if (vs.state == VS_BLANK) out("A blank disk is available. An administrator can run `v. storage format` to use it.");
    if (vs.state == VS_NONE) out("No data disk: settings (e.g. wallpaper) are NOT saved across reboots. Attach a blank second disk.");
    if (vs.state == VS_READY) { uint32_t w; n = 0; str(l, &n, "Saved wallpaper index: "); if (vstore_get_wallpaper(&vs, &w)) num(l, &n, w); else str(l, &n, "(none yet)"); l[n] = 0; out(l); }
}
void storage_pci_report(StorageOut out)
{
    char l[96]; int n = 0; str(l, &n, "PCI devices: "); num(l, &n, (uint64_t)pci_count()); l[n] = 0; out(l);
    for (int i = 0; i < pci_count(); i++) {
        const PciDev *d = pci_get(i); n = 0; hex(l, &n, d->bus, 2); l[n++] = ':'; hex(l, &n, d->slot, 2); l[n++] = '.'; hex(l, &n, d->func, 1); l[n++] = ' ';
        hex(l, &n, d->vendor, 4); l[n++] = ':'; hex(l, &n, d->device, 4); l[n++] = ' '; str(l, &n, pci_class_name(d->cls, d->sub)); l[n] = 0; out(l);
    }
}
