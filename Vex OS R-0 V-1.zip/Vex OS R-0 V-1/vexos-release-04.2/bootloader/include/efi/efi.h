/*
 * Vex OS - bootloader/include/efi/efi.h
 *
 * Minimal vendored UEFI type/protocol definitions, covering only what
 * bootloader/src/main.c uses. This exists purely to drop the gnu-efi
 * package dependency for the clang/lld Windows-native toolchain path
 * (see docs/WINDOWS-BUILD.md) - it is NOT a general-purpose UEFI SDK.
 *
 * Field layouts, struct ordering, and GUID values are taken directly
 * from the UEFI Specification (stable since UEFI 2.x) - this is a
 * fixed, standardized binary ABI, not something Vex OS defines.
 *
 * Calling convention note: UEFI mandates the Microsoft x64 calling
 * convention for all firmware calls. When this header is compiled
 * with `clang --target=x86_64-unknown-windows`, that IS the compiler's
 * native/default convention, so - unlike gnu-efi on a Linux-hosted
 * GCC/System V target - no calling-convention shim/wrapper
 * (gnu-efi's `uefi_call_wrapper`) is needed here. Function pointers
 * below are called directly.
 *
 * This header is used ONLY by the bootloader. The kernel and
 * common/include/bootinfo.h remain completely independent of it.
 */

#ifndef VEXOS_VENDORED_EFI_H
#define VEXOS_VENDORED_EFI_H

#include <stdint.h>

/* ---------------------------------------------------------------- */
/* Base types                                                         */
/* ---------------------------------------------------------------- */

typedef uint8_t   BOOLEAN;
typedef int64_t   INTN;
typedef uint64_t  UINTN;
typedef int8_t    INT8;
typedef uint8_t   UINT8;
typedef int16_t   INT16;
typedef uint16_t  UINT16;
typedef int32_t   INT32;
typedef uint32_t  UINT32;
typedef int64_t   INT64;
typedef uint64_t  UINT64;
typedef uint16_t  CHAR16;
typedef char      CHAR8;
typedef void      VOID;
typedef UINTN     EFI_STATUS;
typedef VOID     *EFI_HANDLE;
typedef VOID     *EFI_EVENT;
typedef UINTN     EFI_TPL;

#define TRUE  1
#define FALSE 0
#define NULL  ((void *)0)

/* EFI_STATUS: high bit set => error. Values below are the ones this
 * bootloader actually checks for. */
#define EFI_ERROR_BIT           (1ULL << 63)
#define EFI_SUCCESS              0ULL
#define EFI_LOAD_ERROR           (EFI_ERROR_BIT | 1ULL)
#define EFI_BUFFER_TOO_SMALL     (EFI_ERROR_BIT | 5ULL)
#define EFI_NOT_FOUND            (EFI_ERROR_BIT | 14ULL)

#define EFI_ERROR(status) (((INTN)(status)) < 0)

typedef struct {
    UINT32 Data1;
    UINT16 Data2;
    UINT16 Data3;
    UINT8  Data4[8];
} EFI_GUID;

/* ---------------------------------------------------------------- */
/* Table header                                                       */
/* ---------------------------------------------------------------- */

typedef struct {
    UINT64 Signature;
    UINT32 Revision;
    UINT32 HeaderSize;
    UINT32 CRC32;
    UINT32 Reserved;
} EFI_TABLE_HEADER;

/* Generic filler for boot-services table slots this bootloader never
 * calls. Keeps the struct's exact field COUNT/ORDER (and therefore
 * every real field's offset) correct without writing out every
 * function's full prototype. */
typedef VOID *EFI_UNUSED_SERVICE;

/* ---------------------------------------------------------------- */
/* Memory services                                                    */
/* ---------------------------------------------------------------- */

typedef enum {
    AllocateAnyPages,
    AllocateMaxAddress,
    AllocateAddress,
    MaxAllocateType
} EFI_ALLOCATE_TYPE;

typedef enum {
    EfiReservedMemoryType,
    EfiLoaderCode,
    EfiLoaderData,
    EfiBootServicesCode,
    EfiBootServicesData,
    EfiRuntimeServicesCode,
    EfiRuntimeServicesData,
    EfiConventionalMemory,
    EfiUnusableMemory,
    EfiACPIReclaimMemory,
    EfiACPIMemoryNVS,
    EfiMemoryMappedIO,
    EfiMemoryMappedIOPortSpace,
    EfiPalCode,
    EfiMaxMemoryType
} EFI_MEMORY_TYPE;

typedef UINT64 EFI_PHYSICAL_ADDRESS;
typedef UINT64 EFI_VIRTUAL_ADDRESS;

typedef struct {
    UINT32               Type;
    EFI_PHYSICAL_ADDRESS PhysicalStart;
    EFI_VIRTUAL_ADDRESS  VirtualStart;
    UINT64                NumberOfPages;
    UINT64                Attribute;
} EFI_MEMORY_DESCRIPTOR;

typedef EFI_STATUS (*EFI_ALLOCATE_PAGES)(EFI_ALLOCATE_TYPE Type,
    EFI_MEMORY_TYPE MemoryType, UINTN Pages, EFI_PHYSICAL_ADDRESS *Memory);

typedef EFI_STATUS (*EFI_FREE_PAGES)(EFI_PHYSICAL_ADDRESS Memory, UINTN Pages);

typedef EFI_STATUS (*EFI_GET_MEMORY_MAP)(UINTN *MemoryMapSize,
    EFI_MEMORY_DESCRIPTOR *MemoryMap, UINTN *MapKey,
    UINTN *DescriptorSize, UINT32 *DescriptorVersion);

typedef EFI_STATUS (*EFI_ALLOCATE_POOL)(EFI_MEMORY_TYPE PoolType,
    UINTN Size, VOID **Buffer);

typedef EFI_STATUS (*EFI_FREE_POOL)(VOID *Buffer);

/* ---------------------------------------------------------------- */
/* Protocol / image / misc services actually used                    */
/* ---------------------------------------------------------------- */

typedef EFI_STATUS (*EFI_HANDLE_PROTOCOL)(EFI_HANDLE Handle,
    EFI_GUID *Protocol, VOID **Interface);

typedef EFI_STATUS (*EFI_LOCATE_PROTOCOL)(EFI_GUID *Protocol,
    VOID *Registration, VOID **Interface);

typedef EFI_STATUS (*EFI_EXIT_BOOT_SERVICES)(EFI_HANDLE ImageHandle,
    UINTN MapKey);

typedef EFI_STATUS (*EFI_STALL)(UINTN Microseconds);

/* ---------------------------------------------------------------- */
/* EFI_BOOT_SERVICES                                                   */
/*                                                                     */
/* Field order is fixed by the UEFI Specification. Fields this        */
/* bootloader doesn't call are typed as EFI_UNUSED_SERVICE (a plain    */
/* pointer) purely to preserve struct layout/offsets - never invoked.  */
/* ---------------------------------------------------------------- */

typedef struct {
    EFI_TABLE_HEADER Hdr;

    EFI_UNUSED_SERVICE RaiseTPL;
    EFI_UNUSED_SERVICE RestoreTPL;

    EFI_ALLOCATE_PAGES AllocatePages;
    EFI_FREE_PAGES     FreePages;
    EFI_GET_MEMORY_MAP GetMemoryMap;
    EFI_ALLOCATE_POOL  AllocatePool;
    EFI_FREE_POOL      FreePool;

    EFI_UNUSED_SERVICE CreateEvent;
    EFI_UNUSED_SERVICE SetTimer;
    EFI_UNUSED_SERVICE WaitForEvent;
    EFI_UNUSED_SERVICE SignalEvent;
    EFI_UNUSED_SERVICE CloseEvent;
    EFI_UNUSED_SERVICE CheckEvent;

    EFI_UNUSED_SERVICE InstallProtocolInterface;
    EFI_UNUSED_SERVICE ReinstallProtocolInterface;
    EFI_UNUSED_SERVICE UninstallProtocolInterface;
    EFI_HANDLE_PROTOCOL HandleProtocol;
    EFI_UNUSED_SERVICE Reserved;
    EFI_UNUSED_SERVICE RegisterProtocolNotify;
    EFI_UNUSED_SERVICE LocateHandle;
    EFI_UNUSED_SERVICE LocateDevicePath;
    EFI_UNUSED_SERVICE InstallConfigurationTable;

    EFI_UNUSED_SERVICE LoadImage;
    EFI_UNUSED_SERVICE StartImage;
    EFI_UNUSED_SERVICE Exit;
    EFI_UNUSED_SERVICE UnloadImage;
    EFI_EXIT_BOOT_SERVICES ExitBootServices;

    EFI_UNUSED_SERVICE GetNextMonotonicCount;
    EFI_STALL          Stall;
    EFI_UNUSED_SERVICE SetWatchdogTimer;

    EFI_UNUSED_SERVICE ConnectController;
    EFI_UNUSED_SERVICE DisconnectController;

    EFI_UNUSED_SERVICE OpenProtocol;
    EFI_UNUSED_SERVICE CloseProtocol;
    EFI_UNUSED_SERVICE OpenProtocolInformation;

    EFI_UNUSED_SERVICE ProtocolsPerHandle;
    EFI_UNUSED_SERVICE LocateHandleBuffer;
    EFI_LOCATE_PROTOCOL LocateProtocol;
    EFI_UNUSED_SERVICE InstallMultipleProtocolInterfaces;
    EFI_UNUSED_SERVICE UninstallMultipleProtocolInterfaces;

    EFI_UNUSED_SERVICE CalculateCrc32;

    EFI_UNUSED_SERVICE CopyMem;
    EFI_UNUSED_SERVICE SetMem;
    EFI_UNUSED_SERVICE CreateEventEx;
} EFI_BOOT_SERVICES;

/* ---------------------------------------------------------------- */
/* Simple Text Output (console)                                       */
/* ---------------------------------------------------------------- */

typedef struct EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL;

typedef EFI_STATUS (*EFI_TEXT_RESET)(EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *This,
    BOOLEAN ExtendedVerification);
typedef EFI_STATUS (*EFI_TEXT_STRING)(EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *This,
    CHAR16 *String);

struct EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL {
    EFI_TEXT_RESET  Reset;
    EFI_TEXT_STRING OutputString;
    EFI_UNUSED_SERVICE TestString;
    EFI_UNUSED_SERVICE QueryMode;
    EFI_UNUSED_SERVICE SetMode;
    EFI_UNUSED_SERVICE SetAttribute;
    EFI_UNUSED_SERVICE ClearScreen;
    EFI_UNUSED_SERVICE SetCursorPosition;
    EFI_UNUSED_SERVICE EnableCursor;
    EFI_UNUSED_SERVICE Mode;
};

/* ---------------------------------------------------------------- */
/* Configuration table (ACPI RSDP lookup)                             */
/* ---------------------------------------------------------------- */

typedef struct {
    EFI_GUID VendorGuid;
    VOID    *VendorTable;
} EFI_CONFIGURATION_TABLE;

/* ---------------------------------------------------------------- */
/* EFI_SYSTEM_TABLE                                                    */
/* ---------------------------------------------------------------- */

typedef struct {
    EFI_TABLE_HEADER Hdr;
    CHAR16          *FirmwareVendor;
    UINT32           FirmwareRevision;
    EFI_HANDLE       ConsoleInHandle;
    VOID            *ConIn;
    EFI_HANDLE       ConsoleOutHandle;
    EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *ConOut;
    EFI_HANDLE       StandardErrorHandle;
    VOID            *StdErr;
    VOID            *RuntimeServices;
    EFI_BOOT_SERVICES *BootServices;
    UINTN            NumberOfTableEntries;
    EFI_CONFIGURATION_TABLE *ConfigurationTable;
} EFI_SYSTEM_TABLE;

/* ---------------------------------------------------------------- */
/* Graphics Output Protocol (GOP)                                     */
/* ---------------------------------------------------------------- */

#define EFI_GRAPHICS_OUTPUT_PROTOCOL_GUID \
    { 0x9042a9de, 0x23dc, 0x4a38, {0x96, 0xfb, 0x7a, 0xde, 0xd0, 0x80, 0x51, 0x6a} }

typedef enum {
    PixelRedGreenBlueReserved8BitPerColor,
    PixelBlueGreenRedReserved8BitPerColor,
    PixelBitMask,
    PixelBltOnly,
    PixelFormatMax
} EFI_GRAPHICS_PIXEL_FORMAT;

typedef struct {
    UINT32 RedMask, GreenMask, BlueMask, ReservedMask;
} EFI_PIXEL_BITMASK;

typedef struct {
    UINT32 Version;
    UINT32 HorizontalResolution;
    UINT32 VerticalResolution;
    EFI_GRAPHICS_PIXEL_FORMAT PixelFormat;
    EFI_PIXEL_BITMASK PixelInformation;
    UINT32 PixelsPerScanLine;
} EFI_GRAPHICS_OUTPUT_MODE_INFORMATION;

typedef struct {
    UINT32 MaxMode;
    UINT32 Mode;
    EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *Info;
    UINTN  SizeOfInfo;
    EFI_PHYSICAL_ADDRESS FrameBufferBase;
    UINTN  FrameBufferSize;
} EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE;

typedef struct {
    EFI_UNUSED_SERVICE QueryMode;
    EFI_UNUSED_SERVICE SetMode;
    EFI_UNUSED_SERVICE Blt;
    EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE *Mode;
} EFI_GRAPHICS_OUTPUT_PROTOCOL;

/* ---------------------------------------------------------------- */
/* Loaded Image / Simple File System / File protocols                 */
/* ---------------------------------------------------------------- */

#define EFI_LOADED_IMAGE_PROTOCOL_GUID \
    { 0x5b1b31a1, 0x9562, 0x11d2, {0x8e, 0x3f, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b} }

typedef struct {
    UINT32 Revision;
    EFI_HANDLE ParentHandle;
    VOID *SystemTable;
    EFI_HANDLE DeviceHandle;
    VOID *FilePath;
    VOID *Reserved;
    UINT32 LoadOptionsSize;
    VOID *LoadOptions;
    VOID *ImageBase;
    UINT64 ImageSize;
    UINT32 ImageCodeType;
    UINT32 ImageDataType;
    VOID *Unload;
} EFI_LOADED_IMAGE_PROTOCOL;

#define EFI_SIMPLE_FILE_SYSTEM_PROTOCOL_GUID \
    { 0x0964e5b22, 0x6459, 0x11d2, {0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b} }

typedef struct EFI_FILE_PROTOCOL EFI_FILE_PROTOCOL;

typedef EFI_STATUS (*EFI_FILE_OPEN)(EFI_FILE_PROTOCOL *This,
    EFI_FILE_PROTOCOL **NewHandle, CHAR16 *FileName,
    UINT64 OpenMode, UINT64 Attributes);
typedef EFI_STATUS (*EFI_FILE_CLOSE)(EFI_FILE_PROTOCOL *This);
typedef EFI_STATUS (*EFI_FILE_READ)(EFI_FILE_PROTOCOL *This,
    UINTN *BufferSize, VOID *Buffer);
typedef EFI_STATUS (*EFI_FILE_GET_INFO)(EFI_FILE_PROTOCOL *This,
    EFI_GUID *InformationType, UINTN *BufferSize, VOID *Buffer);

struct EFI_FILE_PROTOCOL {
    UINT64 Revision;
    EFI_FILE_OPEN Open;
    EFI_FILE_CLOSE Close;
    EFI_UNUSED_SERVICE Delete;
    EFI_FILE_READ Read;
    EFI_UNUSED_SERVICE Write;
    EFI_UNUSED_SERVICE GetPosition;
    EFI_UNUSED_SERVICE SetPosition;
    EFI_FILE_GET_INFO GetInfo;
    EFI_UNUSED_SERVICE SetInfo;
    EFI_UNUSED_SERVICE Flush;
};

#define EFI_FILE_MODE_READ 0x0000000000000001ULL

typedef struct {
    EFI_UNUSED_SERVICE Revision;
    EFI_STATUS (*OpenVolume)(VOID *This, EFI_FILE_PROTOCOL **Root);
} EFI_SIMPLE_FILE_SYSTEM_PROTOCOL;

#define EFI_FILE_INFO_GUID \
    { 0x09576e92, 0x6d3f, 0x11d2, {0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b} }

typedef struct {
    UINT64 Size;
    UINT64 FileSize;
    UINT64 PhysicalSize;
    UINT64 CreateTime[2];   /* EFI_TIME is 16 bytes; contents unused here */
    UINT64 LastAccessTime[2];
    UINT64 ModificationTime[2];
    UINT64 Attribute;
    CHAR16 FileName[1];
} EFI_FILE_INFO;

/* ---------------------------------------------------------------- */
/* ACPI configuration table GUIDs                                     */
/* ---------------------------------------------------------------- */

#define ACPI_TABLE_GUID \
    { 0xeb9d2d30, 0x2d88, 0x11d3, {0x9a, 0x16, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d} }
#define ACPI_20_TABLE_GUID \
    { 0x8868e871, 0xe4f1, 0x11d3, {0xbc, 0x22, 0x00, 0x80, 0xc7, 0x3c, 0x88, 0x81} }

/* ---------------------------------------------------------------- */
/* Small helpers this bootloader needs, replacing gnu-efi's           */
/* InitializeLib/Print/ZeroMem/CompareGuid convenience functions.     */
/* ---------------------------------------------------------------- */

static inline int efi_guid_eq(const EFI_GUID *a, const EFI_GUID *b)
{
    const UINT8 *pa = (const UINT8 *)a;
    const UINT8 *pb = (const UINT8 *)b;
    for (UINTN i = 0; i < sizeof(EFI_GUID); i++) {
        if (pa[i] != pb[i]) return 0;
    }
    return 1;
}

static inline void efi_zero(void *p, UINTN n)
{
    UINT8 *b = (UINT8 *)p;
    for (UINTN i = 0; i < n; i++) b[i] = 0;
}

/* Minimal console print: CHAR16 string literals only (prefix with L),
 * no format specifiers - callers build simple messages by concatenating
 * calls, matching what main.c actually needs. */
static inline void efi_print(EFI_SYSTEM_TABLE *st, CHAR16 *s)
{
    st->ConOut->OutputString(st->ConOut, s);
}

#endif /* VEXOS_VENDORED_EFI_H */
