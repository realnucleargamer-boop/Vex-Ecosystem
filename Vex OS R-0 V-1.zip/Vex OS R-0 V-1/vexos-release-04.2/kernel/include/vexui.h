/*
 * Vex OS - kernel/include/vexui.h
 *
 * Lock screen + minimal "Vex" session screen (INPUT-03 / LOCK-01).
 *
 * WHAT THIS IS
 *   An in-kernel, framebuffer-drawn UI driven by the INPUT-02/03 event
 *   queues.  It has two screens - the lock screen and a deliberately small
 *   session screen - and two popups (power menu, network status).
 *
 * WHAT THIS IS NOT
 *   There is no user-account database, no authentication, no process, no
 *   window manager and no desktop shell.  The "Vex" session is a passwordless
 *   local development placeholder.  It is NOT a security boundary and the UI
 *   says so on screen.
 *
 * STRUCTURE (state machine separate from rendering)
 *   vexui_handle_key()/vexui_handle_mouse() mutate state only (and mark what
 *   needs redrawing).  They never touch hardware and never call power code:
 *   power requests are queued as a *pending action* and executed only by
 *   vexui_poll().  This is what lets the whole state machine be unit-tested
 *   in-kernel with no framebuffer, and it means there is no callback or
 *   function pointer anywhere that a stray write could redirect into a
 *   privileged operation.
 */
#ifndef VEXOS_VEXUI_H
#define VEXOS_VEXUI_H
#include <stdint.h>
#include "gfx/fb.h"
#include "input.h"

typedef struct {
    int      graphics_ok, input_ok, user_ok;
    int      mouse_present;
    uint32_t cpu_count;
    uint32_t sec02_run, sec02_failed;   /* real SECURITY-02 counters from boot */
} VexUiFacts;

/* DESKTOP-01: VEXUI_SESSION is now the desktop (kept as an alias so older callers still compile). */
typedef enum { VEXUI_LOCK = 0, VEXUI_SESSION = 1, VEXUI_DESKTOP = 1, VEXUI_SETUP = 2, VEXUI_TERMINAL = 3, VEXUI_EXPLORER = 4, VEXUI_TASKMGR = 5, VEXUI_VALBOOK = 6, VEXUI_SETTINGS = 7 } VexUiScreen;
typedef enum { VEXUI_POPUP_NONE = 0, VEXUI_POPUP_POWER = 1, VEXUI_POPUP_NET = 2, VEXUI_POPUP_USERS = 3,
               VEXUI_POPUP_VMENU = 4, VEXUI_POPUP_SEARCH = 5, VEXUI_POPUP_CTX = 6 } VexUiPopup;
typedef enum { VEXUI_ACT_NONE = 0, VEXUI_ACT_SHUTDOWN = 1, VEXUI_ACT_REBOOT = 2 } VexUiAction;

/* Control indices (same slots on both screens). */
/* Lock screen controls (index == focus order). Other screens use their own sets; see vexui_ctl_kind(). */
enum { VEXUI_CTL_PRIMARY = 0 /* Sign in */, VEXUI_CTL_USERS = 1, VEXUI_CTL_NET = 2, VEXUI_CTL_POWER = 3, VEXUI_CTL_COUNT = 4 };
/* Power menu items. */
enum { VEXUI_PWR_SHUTDOWN = 0, VEXUI_PWR_REBOOT = 1, VEXUI_PWR_CANCEL = 2, VEXUI_PWR_COUNT = 3 };

/* Bind to the framebuffer (may be NULL / !ok: the UI then runs headless,
 * logging transitions to serial) and show the lock screen. */
void vexui_init(const GfxFb *fb, const VexUiFacts *facts);

/* Main-loop step: drain input queues, update state, run any queued power
 * action, redraw only what changed.  Bounded work per call, never blocks. */
void vexui_poll(void);

/* State-machine entry points (also the unit-test seam). */
void vexui_handle_key(const VexKeyEvent *e);
void vexui_handle_mouse(const VexMouseEvent *e);

/* Introspection. */
VexUiScreen vexui_screen(void);
VexUiPopup  vexui_popup(void);
int      vexui_focus(void);
int      vexui_popup_focus(void);
int      vexui_hover(void);
int      vexui_pressed(void);
VexUiAction vexui_pending_action(void);
void     vexui_clear_pending(void);
uint32_t vexui_enter_count(void);   /* lock -> session transitions */
uint32_t vexui_lock_count(void);    /* session -> lock transitions */
int32_t  vexui_pointer_x(void);
int32_t  vexui_pointer_y(void);
int      vexui_ctl_rect(int ctl, int32_t *x, int32_t *y, int32_t *w, int32_t *h);
int      vexui_popup_item_rect(int item, int32_t *x, int32_t *y, int32_t *w, int32_t *h);
int      vexui_popup_item_enabled(int item);
int      vexui_popup_rect(int32_t *x, int32_t *y, int32_t *w, int32_t *h);

/* Test harness: reset to a logical screen of w x h with NO framebuffer, quiet
 * logging, and explicit power capabilities (so tests do not depend on the
 * platform).  vexui_test_end() leaves the module un-initialised. */
/* DESKTOP-01 introspection */
int  vexui_nctl(void);
int  vexui_ctl_kind(int ctl);                 /* VEXUI_CK_* */
enum { VEXUI_CK_SIGNIN, VEXUI_CK_USERS, VEXUI_CK_NET, VEXUI_CK_POWER, VEXUI_CK_VBTN, VEXUI_CK_SEARCH,
       VEXUI_CK_TERM, VEXUI_CK_NAME, VEXUI_CK_CREATE, VEXUI_CK_TCLOSE,
       VEXUI_CK_PASS, VEXUI_CK_PASS2, VEXUI_CK_EXPL, VEXUI_CK_TASK, VEXUI_CK_XUP, VEXUI_CK_XHOME, VEXUI_CK_XNEW,
       VEXUI_CK_XROW, VEXUI_CK_XOK, VEXUI_CK_XCANCEL,
       VEXUI_CK_TMIN, VEXUI_CK_VALB, VEXUI_CK_SETT, VEXUI_CK_XSORT, VEXUI_CK_VBNEW, VEXUI_CK_VBOPEN, VEXUI_CK_VBSAVE,
       VEXUI_CK_VBDISCARD, VEXUI_CK_SROW, VEXUI_CK_SSWATCH, VEXUI_CK_SBTN };
const char *vexui_name_text(void);            /* first-run account-name field */
const char *vexui_search_text(void);
const char *vexui_setup_message(void);        /* current validation / error text ("" if none) */
int  vexui_session_user(void);                /* account index signed in, or -1 */
int  vexui_popup_count(void);
uint32_t vexui_signin_count(void);
const char *vexui_auth_message(void);         /* last sign-in failure text ("" if none) */
int  vexui_add_mode(void);                    /* 1 while the admin "Add user" form is shown */
int  vexui_explorer_dir(void);                /* current File Explorer directory node */
const char *vexui_explorer_message(void);
int  vexui_explorer_entries(void);
/* Release-03 introspection */
const char *vexui_valbook_text(void); int vexui_valbook_modified(void); int vexui_valbook_node(void);
int  vexui_win_minimized(uint32_t app_id);
void vexui_win_pos(int32_t *x, int32_t *y);   /* current app window's top-left */
int  vexui_sort_mode(void); int vexui_settings_page(void); int vexui_ctx_count(void);
uint32_t vexui_accent_rgb(void);
int  vexui_explorer_entry(int i);             /* node index shown in row i (display order), -1 if none */
uint32_t vexui_heavy_redraws(void);         /* full + region-repaint + terminal-output redraw REQUESTS (typing must not add to it) */
uint32_t vexui_full_redraws(void);          /* full-screen redraw REQUESTS since init (regression counter) */
int  vexui_cpu_permille(void);                /* last Task Manager CPU sample, -1 = none yet */

void vexui_test_begin(int32_t w, int32_t h, int can_shutdown, int can_reboot);
void vexui_test_end(void);
#endif
