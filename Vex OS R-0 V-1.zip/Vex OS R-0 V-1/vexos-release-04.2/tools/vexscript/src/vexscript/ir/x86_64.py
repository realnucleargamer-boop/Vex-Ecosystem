"""Vex IR → x86-64 AT&T assembly (Phase E/F).

Temporary hosted ABI: System V AMD64.
NOT the Vex OS syscall ABI.
"""
from __future__ import annotations
from .nodes import ModuleIR, FunctionIR, Instruction, Value
from ..errors import VexError

ARG_REGS = ["%rdi", "%rsi", "%rdx", "%rcx", "%r8", "%r9"]


class X86_64Backend:
    def __init__(self):
        self.lines: list[str] = []
        self.rodata: list[str] = []
        self.str_id = 0
        self.str_labels: dict[str, str] = {}

    def _emit(self, line: str = ""):
        self.lines.append(line)

    def _str_label(self, s: str) -> str:
        if s not in self.str_labels:
            lab = f".Lstr{self.str_id}"
            self.str_id += 1
            self.str_labels[s] = lab
            esc = (
                s.replace("\\", "\\\\")
                .replace('"', '\\"')
                .replace("\n", "\\n")
                .replace("\t", "\\t")
            )
            self.rodata.append(f"{lab}:")
            self.rodata.append(f'    .asciz "{esc}"')
        return self.str_labels[s]

    def emit(self, mod: ModuleIR) -> str:
        self.lines = []
        self.rodata = []
        self.str_id = 0
        self.str_labels = {}
        self._emit(".text")
        self._emit(".globl main")
        self._emit(".extern vex_rt_print_i64")
        self._emit(".extern vex_rt_println_i64")
        self._emit(".extern vex_rt_print_cstr")
        self._emit(".extern vex_rt_println_cstr")
        for ext in (
            "vex_rt_rng_seed", "vex_rt_rng_u64",
            "vex_rt_genome_create", "vex_rt_genome_length",
            "vex_rt_genome_char_code_at", "vex_rt_genome_set_char_code",
            "vex_rt_genome_fill_code", "vex_rt_genome_copy",
            "vex_rt_genome_compare", "vex_rt_genome_slice",
            "vex_rt_stream_create", "vex_rt_stream_size",
            "vex_rt_stream_generation", "vex_rt_stream_set_elite_count",
            "vex_rt_stream_advance", "vex_rt_stream_pop",
            "vex_rt_fitness_set", "vex_rt_fitness_get",
            "vex_rt_fitness_best_index", "vex_rt_fitness_worst_index",
            "vex_rt_fitness_average", "vex_rt_fitness_sum",
            "vex_rt_diversity_hamming_avg",
            "vex_rt_migrate_copy", "vex_rt_migrate_best",
            "vex_rt_elite_preserve_count", "vex_rt_evo_reset",
            "vex_rt_genome_from_cstr", "vex_rt_genome_to_cstr",
            "vex_rt_genome_char_at", "vex_rt_genome_set_char",
            "vex_rt_genome_append_char", "vex_rt_genome_fill",
            "vex_rt_genome_match_cstr",
        ):
            self._emit(f".extern {ext}")
        self._emit("")
        for fn in mod.functions:
            self._emit_function(fn)
        if self.rodata:
            self._emit(".section .rodata")
            self.lines.extend(self.rodata)
            self._emit("")
        return "\n".join(self.lines) + "\n"

    def _emit_function(self, fn: FunctionIR):
        slots: dict[str, int] = {}
        offset = 0

        def alloc(name: str) -> int:
            nonlocal offset
            if name not in slots:
                offset += 8
                slots[name] = offset
            return slots[name]

        for pname, _ in fn.params:
            alloc(pname)
        for b in fn.blocks:
            for inst in b.instructions:
                if inst.dest:
                    alloc(inst.dest)
                if inst.op == "store_local" and inst.extra:
                    alloc(f"L_{inst.extra}")
                if inst.op == "load_local" and inst.extra:
                    alloc(f"L_{inst.extra}")

        frame = offset
        if frame % 16 != 0:
            frame += 16 - (frame % 16)

        safe = fn.name.replace("::", "_")
        self._emit(f"# ----- {fn.name} -----")
        self._emit(f".globl {safe}")
        self._emit(f"{safe}:")
        self._emit("    pushq %rbp")
        self._emit("    movq %rsp, %rbp")
        if frame:
            self._emit(f"    subq ${frame}, %rsp")

        for i, (pname, _) in enumerate(fn.params):
            off = slots[pname]
            if i < 6:
                self._emit(f"    movq {ARG_REGS[i]}, -{off}(%rbp)")
            else:
                so = 16 + (i - 6) * 8
                self._emit(f"    movq {so}(%rbp), %rax")
                self._emit(f"    movq %rax, -{off}(%rbp)")

        for b in fn.blocks:
            self._emit(f".L{safe}_{b.name}:")
            for inst in b.instructions:
                self._gen_inst(inst, slots, safe)
            if b.terminator:
                self._gen_term(b.terminator, slots, safe)

        self._emit("")

    def _val_to_rax(self, v: Value, slots: dict):
        if v.kind == "lit":
            self._emit(f"    movq ${v.text}, %rax")
        else:
            off = slots.get(v.text)
            if off is None:
                raise VexError(f"x86: unknown SSA {v.text}", error_code="E0501")
            self._emit(f"    movq -{off}(%rbp), %rax")

    def _store_rax(self, dest: str | None, slots: dict):
        if not dest:
            return
        self._emit(f"    movq %rax, -{slots[dest]}(%rbp)")

    def _gen_inst(self, inst: Instruction, slots: dict, safe: str):
        op = inst.op
        if op == "const":
            if inst.ty == "string" or isinstance(inst.extra, str):
                lab = self._str_label(str(inst.extra) if inst.extra is not None else "")
                self._emit(f"    leaq {lab}(%rip), %rax")
            else:
                val = int(inst.extra) if inst.extra is not None else 0
                self._emit(f"    movq ${val}, %rax")
            self._store_rax(inst.dest, slots)
        elif op == "copy":
            self._val_to_rax(inst.args[0], slots)
            self._store_rax(inst.dest, slots)
        elif op == "load_local":
            off = slots[f"L_{inst.extra}"]
            self._emit(f"    movq -{off}(%rbp), %rax")
            self._store_rax(inst.dest, slots)
        elif op == "store_local":
            self._val_to_rax(inst.args[0], slots)
            off = slots[f"L_{inst.extra}"]
            self._emit(f"    movq %rax, -{off}(%rbp)")
        elif op in ("add", "sub", "mul", "div", "mod"):
            self._val_to_rax(inst.args[0], slots)
            self._emit("    pushq %rax")
            self._val_to_rax(inst.args[1], slots)
            self._emit("    movq %rax, %rcx")
            self._emit("    popq %rax")
            if op == "add":
                self._emit("    addq %rcx, %rax")
            elif op == "sub":
                self._emit("    subq %rcx, %rax")
            elif op == "mul":
                self._emit("    imulq %rcx, %rax")
            elif op == "div":
                self._emit("    cqto")
                self._emit("    idivq %rcx")
            else:
                self._emit("    cqto")
                self._emit("    idivq %rcx")
                self._emit("    movq %rdx, %rax")
            self._store_rax(inst.dest, slots)
        elif op in ("eq", "ne") and inst.args and getattr(inst.args[0], "ty", None) == "string":
            # VEXOS-NATIVE-1: strings compare by VALUE (matches the hosted interpreter).
            # Stock backend compared the two pointers, which is wrong for any non-interned string.
            self._val_to_rax(inst.args[0], slots)
            self._emit("    movq %rax, %rdi")
            self._val_to_rax(inst.args[1], slots)
            self._emit("    movq %rax, %rsi")
            self._emit("    call vex_rt_str_eq")
            if op == "ne":
                self._emit("    xorq $1, %rax")
            self._store_rax(inst.dest, slots)
        elif op in ("eq", "ne", "lt", "le", "gt", "ge"):
            self._val_to_rax(inst.args[0], slots)
            self._emit("    pushq %rax")
            self._val_to_rax(inst.args[1], slots)
            self._emit("    movq %rax, %rcx")
            self._emit("    popq %rax")
            self._emit("    cmpq %rcx, %rax")
            smap = {
                "eq": "sete", "ne": "setne", "lt": "setl",
                "le": "setle", "gt": "setg", "ge": "setge",
            }
            self._emit(f"    {smap[op]} %al")
            self._emit("    movzbq %al, %rax")
            self._store_rax(inst.dest, slots)
        elif op in ("and", "or"):
            self._val_to_rax(inst.args[0], slots)
            self._emit("    pushq %rax")
            self._val_to_rax(inst.args[1], slots)
            self._emit("    movq %rax, %rcx")
            self._emit("    popq %rax")
            self._emit(f"    {'andq' if op == 'and' else 'orq'} %rcx, %rax")
            self._emit("    cmpq $0, %rax")
            self._emit("    setne %al")
            self._emit("    movzbq %al, %rax")
            self._store_rax(inst.dest, slots)
        elif op == "not":
            self._val_to_rax(inst.args[0], slots)
            self._emit("    cmpq $0, %rax")
            self._emit("    sete %al")
            self._emit("    movzbq %al, %rax")
            self._store_rax(inst.dest, slots)
        elif op == "call":
            callee = str(inst.extra)
            NATIVE_MAP = {
                "rng_seed": "vex_rt_rng_seed",
                "rng_u64": "vex_rt_rng_u64",
                "genome_create": "vex_rt_genome_create",
                "genome_length": "vex_rt_genome_length",
                "genome_char_code_at": "vex_rt_genome_char_code_at",
                "genome_set_char_code": "vex_rt_genome_set_char_code",
                "genome_fill_code": "vex_rt_genome_fill_code",
                "genome_copy": "vex_rt_genome_copy",
                "genome_compare": "vex_rt_genome_compare",
                "genome_slice": "vex_rt_genome_slice",
                "genome_from_string": "vex_rt_genome_from_cstr",
                "genome_to_string": "vex_rt_genome_to_cstr",
                "genome_char_at": "vex_rt_genome_char_at",
                "genome_set_char": "vex_rt_genome_set_char",
                "genome_append_char": "vex_rt_genome_append_char",
                "genome_fill": "vex_rt_genome_fill",
                "genome_match": "vex_rt_genome_match_cstr",
                "stream_create": "vex_rt_stream_create",
                "stream_size": "vex_rt_stream_size",
                "stream_generation": "vex_rt_stream_generation",
                "stream_set_elite_count": "vex_rt_stream_set_elite_count",
                "stream_advance": "vex_rt_stream_advance",
                "stream_pop": "vex_rt_stream_pop",
                "fitness_set": "vex_rt_fitness_set",
                "fitness_get": "vex_rt_fitness_get",
                "fitness_best_index": "vex_rt_fitness_best_index",
                "fitness_worst_index": "vex_rt_fitness_worst_index",
                "fitness_average": "vex_rt_fitness_average",
                "fitness_sum": "vex_rt_fitness_sum",
                "diversity_hamming_avg": "vex_rt_diversity_hamming_avg",
                "migrate_copy": "vex_rt_migrate_copy",
                "migrate_best": "vex_rt_migrate_best",
                "elite_preserve_count": "vex_rt_elite_preserve_count",
            }
            NATIVE_MAP.update({
                "str_equals": "vex_rt_str_eq", "str_starts_with": "vex_rt_str_starts_with",
                "str_ends_with": "vex_rt_str_ends_with", "str_contains": "vex_rt_str_contains",
                "str_len": "vex_rt_str_len", "len_string": "vex_rt_str_len", "str_length": "vex_rt_str_len",
                "str_char_at": "vex_rt_str_char_at", "str_skip": "vex_rt_str_skip",
            })
            for _n in ("os_state_get os_state_set os_buf_push os_buf_pop os_buf_clear os_buf_len os_buf_text "
                       "os_out_clear os_app_count os_app_id os_app_name os_app_kind os_app_started_ms "
                       "os_now_ms os_timer_start os_timer_stop os_timer_active os_cmd").split():
                NATIVE_MAP[_n] = "vex_" + _n
            if callee in NATIVE_MAP:
                # standard System V call — args already evaluated into arg regs by prior code?
                # Existing path loads args then call - mirror println style
                # Fall through to generic call with remapped name
                callee = NATIVE_MAP[callee]
            if callee in ("println", "print", "print_i64"):
                is_str = bool(inst.args) and inst.args[0].ty == "string"
                if inst.args:
                    self._val_to_rax(inst.args[0], slots)
                    self._emit("    movq %rax, %rdi")
                else:
                    self._emit("    movq $0, %rdi")
                if is_str:
                    self._emit(
                        f"    call {'vex_rt_print_cstr' if callee == 'print' else 'vex_rt_println_cstr'}"
                    )
                else:
                    self._emit(
                        f"    call {'vex_rt_print_i64' if callee == 'print' else 'vex_rt_println_i64'}"
                    )
                if inst.dest:
                    self._emit("    movq $0, %rax")
                    self._store_rax(inst.dest, slots)
                return
            if callee.startswith("vex::"):
                raise VexError(
                    f"x86 backend: hosted API '{callee}' not supported in native output",
                    error_code="E0502",
                )
            n = len(inst.args)
            n_reg = min(n, 6)
            n_stack = n - n_reg
            for i in range(n - 1, 5, -1):
                self._val_to_rax(inst.args[i], slots)
                self._emit("    pushq %rax")
            for i in range(n_reg):
                self._val_to_rax(inst.args[i], slots)
                self._emit("    pushq %rax")
            for i in range(n_reg - 1, -1, -1):
                self._emit(f"    popq {ARG_REGS[i]}")
            pad = 0
            if n_stack % 2 == 1:
                self._emit("    pushq $0")
                pad = 8
            self._emit(f"    call {callee.replace('::', '_')}")
            clean = n_stack * 8 + pad
            if clean:
                self._emit(f"    addq ${clean}, %rsp")
            if inst.dest:
                self._store_rax(inst.dest, slots)
        elif op == "extract":
            self._val_to_rax(inst.args[0], slots)
            self._store_rax(inst.dest, slots)
        else:
            raise VexError(f"x86 backend: unsupported IR op '{op}'", error_code="E0503")

    def _gen_term(self, inst: Instruction, slots: dict, safe: str):
        if inst.op == "ret":
            if inst.args:
                self._val_to_rax(inst.args[0], slots)
            else:
                self._emit("    movq $0, %rax")
            self._emit("    movq %rbp, %rsp")
            self._emit("    popq %rbp")
            self._emit("    ret")
        elif inst.op == "br":
            self._emit(f"    jmp .L{safe}_{inst.extra}")
        elif inst.op == "br_cond":
            self._val_to_rax(inst.args[0], slots)
            t, f = inst.extra
            self._emit("    cmpq $0, %rax")
            self._emit(f"    jne .L{safe}_{t}")
            self._emit(f"    jmp .L{safe}_{f}")
        else:
            raise VexError(f"x86: bad terminator {inst.op}", error_code="E0503")


def ir_to_asm(mod: ModuleIR) -> str:
    return X86_64Backend().emit(mod)


def ir_to_asm_per_function(mod: ModuleIR) -> dict[str, str]:
    """Emit separate assembly unit per function (multi-object linking)."""
    result = {}
    for fn in mod.functions:
        single = ModuleIR(functions=[fn])
        # Shared string pool: emit full module still better for strings;
        # for Phase F we emit full module asm once OR per-fn without cross strings.
        result[fn.name.replace("::", "_")] = X86_64Backend().emit(single)
    return result
