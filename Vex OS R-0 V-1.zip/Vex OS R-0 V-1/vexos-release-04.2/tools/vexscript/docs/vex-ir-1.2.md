# Vex IR 1.2

Canonical IR for **VexScript 2.0+++** (v2.2.0).

Backwards-compatible evolution of the in-tree IR 0.1 pipeline used by VexScript.

## Version header

```text
; Vex IR 1.2
ir_version 1.2
calling_conv vex_hosted
```

`calling_conv` is **hosted/temporary**, not the frozen Vex OS syscall ABI.

## Types

| Type | Notes |
|------|--------|
| `i8`…`i64`, `u8`…`u64` | Integers |
| `bool` | Boolean |
| `void` | No value |
| `string` | Immutable string value (IR level) |
| `T[]` | Fixed array value |
| `StructName` | Aggregate |
| `*T` / `*mut T` | Pointer annotations (limited lowering) |

## Core ops (1.2)

**Values:** `const`, `copy`, `load_local`, `store_local`  
**Arithmetic:** `add` `sub` `mul` `div` `mod`  
**Compare:** `eq` `ne` `lt` `le` `gt` `ge`  
**Bool:** `and` `or` `not`  
**Control:** `br` `br_cond` `ret`  
**Call:** `call`  
**Aggregates:** `make_struct` `extract` `insert`  
**Arrays:** `make_array` `index` (bounds checked in interpreter)

## String representation

```text
%v0 = const.string 'VEX AI'
%v1 = call string @concat(%v0, %v2)
%v3 = eq.bool %v0, %v4
```

## Array representation

```text
%a = make_array.i64[] n=3 (%c0, %c1, %c2)
%e = index.i64 %a, %i
```

## Validation

- Known ops only  
- SSA defined-before-use within linear block order  
- Terminators required  
- Branch targets must exist  
- Supports module versions `0.1`–`1.2` for read compatibility  

## Non-goals (1.2)

- Full IR 1.1 `switch` / `phi` dominance checker  
- Native GC  
- Frozen Vex OS syscalls  
