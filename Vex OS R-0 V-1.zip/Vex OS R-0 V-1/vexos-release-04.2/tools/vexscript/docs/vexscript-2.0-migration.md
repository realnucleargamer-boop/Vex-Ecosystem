# Migrating from VexScript 1.5 → 2.0

1. Replace `use foo;` with `import foo;` (optional but recommended).
2. Call imports as `foo::bar` only (already required since 1.4).
3. Mark exported functions `pub fn`.
4. Ensure all `if`/`while` conditions are `bool`.
5. Prefer `vex.toml` + `src/main.vex` for apps.
6. Do not rely on global injection of module symbols.

## Phase A notes (implemented)
- `import mod;` and `import mod::{ a, b };` supported
- `use` remains as deprecated synonym for `import`
- Module functions must be `pub fn` to be called as `mod::fn` from other files
- Private symbols: error[E0004]
- Duplicate import: error[E0005]
- Import cycle: error[E0002]
- Missing module: error[E0001]
