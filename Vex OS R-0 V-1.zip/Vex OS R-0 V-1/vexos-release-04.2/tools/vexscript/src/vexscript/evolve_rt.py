"""Evolutionary primitives for VexScript 3.0-D (deterministic with external RNG).

Population = list of candidate tensors (typically rank-1 weight vectors).
All stochastic ops consume a caller-provided RNG callable: rng() -> int u64.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable
from .tensor_rt import Tensor, tensor_create


RngFn = Callable[[], int]


@dataclass
class Population:
    candidates: list[Tensor] = field(default_factory=list)

    def size(self) -> int:
        return len(self.candidates)


_POPULATIONS: dict[int, Population] = {}
_NEXT_POP_ID = 1


def _rand_f32(rng: RngFn) -> float:
    """Uniform [0, 1)."""
    return (rng() & 0xFFFFFF) / float(0x1000000)


def evolve_create(n: int, dim: int) -> int:
    """Create population of n zero vectors of length dim. Returns handle id."""
    global _NEXT_POP_ID
    n, dim = int(n), int(dim)
    if n <= 0 or dim <= 0:
        raise ValueError("population size and dim must be positive")
    pop = Population(candidates=[tensor_create("f32", dim) for _ in range(n)])
    pid = _NEXT_POP_ID
    _NEXT_POP_ID += 1
    _POPULATIONS[pid] = pop
    return pid


def evolve_size(pid: int) -> int:
    return _POPULATIONS[int(pid)].size()


def evolve_get(pid: int, index: int) -> Tensor:
    pop = _POPULATIONS[int(pid)]
    i = int(index)
    if i < 0 or i >= len(pop.candidates):
        raise ValueError("candidate index out of range")
    # return copy to avoid accidental alias bugs in select
    c = pop.candidates[i]
    return Tensor(c.dtype, c.shape, list(c.data))


def evolve_set(pid: int, index: int, t: Tensor) -> int:
    pop = _POPULATIONS[int(pid)]
    i = int(index)
    if i < 0 or i >= len(pop.candidates):
        raise ValueError("candidate index out of range")
    pop.candidates[i] = Tensor(t.dtype, t.shape, list(t.data))
    return 0


def evolve_randomize(pid: int, rng: RngFn, scale: float = 1.0) -> int:
    """Fill all candidates with uniform [-scale, scale]."""
    pop = _POPULATIONS[int(pid)]
    s = float(scale)
    for c in pop.candidates:
        c.data = [(_rand_f32(rng) * 2.0 - 1.0) * s for _ in range(c.size())]
    return 0


def evolve_mutate(t: Tensor, rng: RngFn, rate_milli: int, scale: float = 0.1) -> Tensor:
    """Copy t; with probability rate_milli/1000, add noise N-ish via uniform * scale."""
    rate = max(0, min(1000, int(rate_milli))) / 1000.0
    s = float(scale)
    out = []
    for x in t.data:
        if _rand_f32(rng) < rate:
            noise = (_rand_f32(rng) * 2.0 - 1.0) * s
            out.append(x + noise)
        else:
            out.append(x)
    return Tensor(t.dtype, t.shape, out)


def evolve_crossover(a: Tensor, b: Tensor, rng: RngFn) -> Tensor:
    """Uniform crossover of two equal-shaped tensors."""
    if a.shape != b.shape:
        raise ValueError("crossover shape mismatch")
    out = [a.data[i] if _rand_f32(rng) < 0.5 else b.data[i] for i in range(a.size())]
    return Tensor(a.dtype, a.shape, out)


def evolve_select_tournament(scores: list[float], k: int, rng: RngFn) -> int:
    """Return index of best (highest) among k random contestants."""
    n = len(scores)
    if n == 0:
        raise ValueError("empty scores")
    k = max(1, min(int(k), n))
    best_i = rng() % n
    best_s = float(scores[best_i])
    for _ in range(k - 1):
        j = rng() % n
        if float(scores[j]) > best_s:
            best_s = float(scores[j])
            best_i = j
    return int(best_i)


def evolve_select_elite(scores: list[float], count: int) -> list[int]:
    """Indices of top `count` scores (highest first)."""
    count = max(0, min(int(count), len(scores)))
    ranked = sorted(range(len(scores)), key=lambda i: float(scores[i]), reverse=True)
    return ranked[:count]




# --- 3.0-E: checkpoint + generation helpers ---

_CHECKPOINTS: dict[str, str] = {}


def _serialize_pop(pop: Population) -> str:
    lines = [f"v1 {len(pop.candidates)}"]
    for c in pop.candidates:
        dims = ",".join(str(d) for d in c.shape)
        data = ",".join(repr(x) for x in c.data)
        lines.append(f"{c.dtype}|{dims}|{data}")
    return "\n".join(lines)


def _deserialize_pop(text: str) -> Population:
    lines = [ln for ln in text.strip().split("\n") if ln.strip()]
    if not lines or not lines[0].startswith("v1 "):
        raise ValueError("bad checkpoint header")
    n = int(lines[0].split()[1])
    cands = []
    for ln in lines[1 : 1 + n]:
        dtype, dims_s, data_s = ln.split("|", 2)
        shape = tuple(int(x) for x in dims_s.split(",") if x)
        data = [float(x) for x in data_s.split(",")] if data_s else []
        cands.append(Tensor(dtype, shape, data))
    return Population(candidates=cands)


def evolve_checkpoint_save(pid: int, name: str) -> int:
    """Save population to named in-memory checkpoint (hosted)."""
    key = str(name)
    pop = _POPULATIONS[int(pid)]
    _CHECKPOINTS[key] = _serialize_pop(pop)
    return 0


def evolve_checkpoint_load(name: str) -> int:
    """Load checkpoint into a new population handle."""
    global _NEXT_POP_ID
    key = str(name)
    if key not in _CHECKPOINTS:
        raise ValueError(f"unknown checkpoint '{key}'")
    pop = _deserialize_pop(_CHECKPOINTS[key])
    pid = _NEXT_POP_ID
    _NEXT_POP_ID += 1
    _POPULATIONS[pid] = pop
    return pid


def evolve_checkpoint_exists(name: str) -> int:
    return 1 if str(name) in _CHECKPOINTS else 0


def evolve_best_index(scores: list[float]) -> int:
    """Index of maximum score."""
    if not scores:
        raise ValueError("empty scores")
    best_i = 0
    best_s = float(scores[0])
    for i, s in enumerate(scores):
        if float(s) > best_s:
            best_s = float(s)
            best_i = i
    return best_i


def evolve_generation(
    pid: int,
    elite_index: int,
    rng: RngFn,
    mutate_rate_milli: int = 300,
) -> int:
    """One generation: keep elite, replace others with mutate(crossover(elite, random))."""
    pop = _POPULATIONS[int(pid)]
    n = len(pop.candidates)
    if n == 0:
        return 0
    e = int(elite_index) % n
    elite = Tensor(
        pop.candidates[e].dtype,
        pop.candidates[e].shape,
        list(pop.candidates[e].data),
    )
    new_cands = [elite]
    for i in range(1, n):
        other = pop.candidates[rng() % n]
        child = evolve_crossover(elite, other, rng)
        child = evolve_mutate(child, rng, int(mutate_rate_milli))
        new_cands.append(child)
    pop.candidates = new_cands
    return 0


def reset_evolve_state() -> None:
    global _POPULATIONS, _NEXT_POP_ID, _CHECKPOINTS
    _POPULATIONS = {}
    _NEXT_POP_ID = 1
    _CHECKPOINTS = {}


# --- Readiness expansion: streams, batch fitness, migration, diversity, elites ---

@dataclass
class Stream:
    """Independent evolutionary stream (not hardcoded to 12)."""
    pop_id: int
    generation: int = 0
    name: str = ""
    elite_count: int = 1
    # parallel fitness scores aligned with population candidates (floats)
    scores: list[float] = field(default_factory=list)


_STREAMS: dict[int, Stream] = {}
_NEXT_SID = 1


def reset_evolve_state() -> None:
    global _POPULATIONS, _NEXT_POP_ID, _CHECKPOINTS, _STREAMS, _NEXT_SID
    _POPULATIONS = {}
    _NEXT_POP_ID = 1
    _CHECKPOINTS = {}
    _STREAMS = {}
    _NEXT_SID = 1


def stream_create(n_candidates: int, dim: int, elite_count: int = 1) -> int:
    """Create stream owning a new population. Returns stream id."""
    global _NEXT_SID
    pid = evolve_create(int(n_candidates), int(dim))
    sid = _NEXT_SID
    _NEXT_SID += 1
    ec = max(0, int(elite_count))
    _STREAMS[sid] = Stream(pop_id=pid, generation=0, elite_count=ec, scores=[0.0] * int(n_candidates))
    return sid


def stream_pop(sid: int) -> int:
    return _STREAMS[int(sid)].pop_id


def stream_generation(sid: int) -> int:
    return _STREAMS[int(sid)].generation


def stream_size(sid: int) -> int:
    return evolve_size(_STREAMS[int(sid)].pop_id)


def stream_set_elite_count(sid: int, n: int) -> int:
    _STREAMS[int(sid)].elite_count = max(0, int(n))
    return 0


def stream_advance(sid: int, mutate_rate_milli: int, rng: RngFn) -> int:
    """Score-aware generation: preserve elites by fitness, mutate rest."""
    st = _STREAMS[int(sid)]
    pid = st.pop_id
    pop = _POPULATIONS[pid]
    n = len(pop.candidates)
    if n == 0:
        st.generation += 1
        return st.generation
    scores = st.scores if len(st.scores) == n else [0.0] * n
    # elite indices
    elite_n = min(st.elite_count, n)
    ranked = sorted(range(n), key=lambda i: float(scores[i]), reverse=True)
    elites = ranked[:elite_n]
    elite_copies = [
        Tensor(pop.candidates[i].dtype, pop.candidates[i].shape, list(pop.candidates[i].data))
        for i in elites
    ]
    new_cands: list[Tensor] = list(elite_copies)
    while len(new_cands) < n:
        # parent from elite or random
        pi = elites[rng() % len(elites)] if elites else (rng() % n)
        qi = rng() % n
        child = evolve_crossover(pop.candidates[pi], pop.candidates[qi], rng)
        child = evolve_mutate(child, rng, int(mutate_rate_milli))
        new_cands.append(child)
    pop.candidates = new_cands[:n]
    st.generation += 1
    return st.generation


def fitness_set(sid: int, index: int, score: int) -> int:
    """Set fitness score for candidate index (integer score)."""
    st = _STREAMS[int(sid)]
    pop = _POPULATIONS[st.pop_id]
    i = int(index)
    if i < 0 or i >= len(pop.candidates):
        return -1
    if len(st.scores) < len(pop.candidates):
        st.scores = list(st.scores) + [0.0] * (len(pop.candidates) - len(st.scores))
    st.scores[i] = float(score)
    return 0


def fitness_get(sid: int, index: int) -> int:
    st = _STREAMS[int(sid)]
    i = int(index)
    if i < 0 or i >= len(st.scores):
        return 0
    return int(st.scores[i])


def fitness_best_index(sid: int) -> int:
    st = _STREAMS[int(sid)]
    if not st.scores:
        return 0
    return max(range(len(st.scores)), key=lambda i: st.scores[i])


def fitness_worst_index(sid: int) -> int:
    st = _STREAMS[int(sid)]
    if not st.scores:
        return 0
    return min(range(len(st.scores)), key=lambda i: st.scores[i])


def fitness_average(sid: int) -> int:
    """Integer truncated average * 1 (same units as scores)."""
    st = _STREAMS[int(sid)]
    if not st.scores:
        return 0
    return int(sum(st.scores) / len(st.scores))


def fitness_sum(sid: int) -> int:
    st = _STREAMS[int(sid)]
    return int(sum(st.scores))


def diversity_hamming_avg(sid: int) -> int:
    """Average pairwise Hamming distance * 1000 / dim (milli-units), tensor candidates."""
    st = _STREAMS[int(sid)]
    pop = _POPULATIONS[st.pop_id]
    n = len(pop.candidates)
    if n < 2:
        return 0
    dim = pop.candidates[0].size()
    if dim == 0:
        return 0
    total = 0
    pairs = 0
    for i in range(n):
        for j in range(i + 1, n):
            a, b = pop.candidates[i].data, pop.candidates[j].data
            d = sum(1 for x, y in zip(a, b) if x != y)
            total += d
            pairs += 1
    # scale to milli of full dimension
    return int((total * 1000) // (pairs * dim)) if pairs else 0


def migrate_copy(src_sid: int, src_index: int, dst_sid: int, dst_index: int) -> int:
    """Copy candidate tensor from src stream to dst index. Does not touch elites policy."""
    sp = _STREAMS[int(src_sid)]
    dp = _STREAMS[int(dst_sid)]
    src_pop = _POPULATIONS[sp.pop_id]
    dst_pop = _POPULATIONS[dp.pop_id]
    si, di = int(src_index), int(dst_index)
    if si < 0 or si >= len(src_pop.candidates):
        return -1
    if di < 0 or di >= len(dst_pop.candidates):
        return -1
    c = src_pop.candidates[si]
    dst_pop.candidates[di] = Tensor(c.dtype, c.shape, list(c.data))
    # copy score if available
    if si < len(sp.scores) and di < len(dp.scores):
        dp.scores[di] = sp.scores[si]
    return 0


def migrate_best(src_sid: int, dst_sid: int, dst_index: int) -> int:
    """Copy best-scoring candidate from src into dst_index."""
    bi = fitness_best_index(int(src_sid))
    return migrate_copy(int(src_sid), bi, int(dst_sid), int(dst_index))


def elite_indices(sid: int) -> list[int]:
    st = _STREAMS[int(sid)]
    n = len(st.scores)
    if n == 0:
        return []
    k = min(st.elite_count, n)
    return sorted(range(n), key=lambda i: st.scores[i], reverse=True)[:k]


def elite_preserve_count(sid: int) -> int:
    return _STREAMS[int(sid)].elite_count
