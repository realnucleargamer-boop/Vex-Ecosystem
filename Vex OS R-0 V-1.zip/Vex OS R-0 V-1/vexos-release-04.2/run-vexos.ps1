[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
$root=$PSScriptRoot; $qemu='C:\Program Files\qemu\qemu-system-x86_64.exe'; $code='C:\Program Files\qemu\share\edk2-x86_64-code.fd'; $varsSource='C:\Program Files\qemu\share\edk2-i386-vars.fd'; $build=Join-Path $root 'build'; $esp=Join-Path $build 'runtime-esp'; $vars=Join-Path $build 'OVMF_VARS.local.fd'
foreach($p in @($qemu,$code,$varsSource)){if(!(Test-Path -LiteralPath $p)){throw "Required runtime dependency is missing: $p"}}
if(!(Test-Path -LiteralPath "$esp\EFI\BOOT\BOOTX64.EFI")){throw 'Runtime ESP is missing. Build the package first using scripts\build-runtime.ps1.'}
& (Join-Path $root 'scripts\Sync-RuntimeEsp.ps1') -BuildDir $build -VerifyOnly
if(!(Test-Path -LiteralPath $vars)){Copy-Item -LiteralPath $varsSource -Destination $vars -Force}
Write-Host 'Starting VEX OS Runtime Upgrade. Close the QEMU window to stop.' -ForegroundColor Cyan
& $qemu -machine q35,accel=tcg -cpu qemu64 -smp 2 -m 512M -drive "if=pflash,format=raw,readonly=on,file=$code" -drive "if=pflash,format=raw,file=$vars" -drive "format=raw,file=fat:rw:$esp" -serial stdio -no-reboot -no-shutdown
