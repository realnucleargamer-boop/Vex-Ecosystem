"""Native x86-64 compile pipeline (Phase E/F). Hosted only."""
from __future__ import annotations
import subprocess
import tempfile
from pathlib import Path
from .compile_ir import compile_to_ir
from .ir.x86_64 import ir_to_asm, ir_to_asm_per_function
from .ir.nodes import ModuleIR
from .ir.emitter import emit_program
from .ir.validate import validate_module
from .ir.optimize import optimize_module
from .interpreter import Interpreter
from .errors import VexError

RUNTIME_C = Path(__file__).resolve().parent.parent / "runtime" / "vex_rt.c"
RUNTIME_EVO_C = Path(__file__).resolve().parent.parent / "runtime" / "vex_evo_rt.c"


def emit_asm(source: str, filename: str = "<input>", module_paths: list[str] | None = None) -> str:
    mod = _compile_mod(source, filename, module_paths)
    return ir_to_asm(mod)


def _compile_mod(source: str, filename: str, module_paths: list[str] | None = None) -> ModuleIR:
    interp = Interpreter(module_paths=module_paths or [])
    program = interp.load(source, filename)
    extra = {
        k: v
        for k, v in interp.functions.items()
        if k != "main" and k in interp.exported and v is not None
    }
    mod = emit_program(program, extra, enum_values=getattr(interp, 'enum_values', {}))
    for fn in mod.functions:
        for b in fn.blocks:
            for inst in list(b.instructions) + ([b.terminator] if b.terminator else []):
                if inst and inst.op == "call" and inst.extra and "::" in str(inst.extra):
                    extra_s = str(inst.extra)
                    if not extra_s.startswith("vex::"):
                        inst.extra = extra_s.replace("::", "_")
    validate_module(mod)
    optimize_module(mod)
    validate_module(mod)
    return mod


def compile_native(
    source: str,
    filename: str = "<input>",
    out_path: Path | None = None,
    module_paths: list[str] | None = None,
    build_dir: Path | None = None,
    multi_object: bool = True,
) -> Path:
    """Compile to host x86-64 executable. Optionally emit per-function .o files."""
    if not RUNTIME_C.is_file():
        raise VexError(f"missing runtime: {RUNTIME_C}", error_code="E0504")
    mod = _compile_mod(source, filename, module_paths)
    if out_path is None:
        out_path = Path(tempfile.mkdtemp()) / "vex_native"
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    work = Path(build_dir) if build_dir else out_path.parent
    work.mkdir(parents=True, exist_ok=True)

    obj_files: list[Path] = []
    if multi_object and len(mod.functions) > 1:
        # One assembly unit still contains all strings in full module emit is safer;
        # emit per-function objects from single full asm split is complex.
        # Strategy: write full project.s + also per-fn .s/.o for visibility.
        full_asm = ir_to_asm(mod)
        full_s = work / "project.s"
        full_s.write_text(full_asm)
        # Per-function object files (code only; strings may duplicate — OK for Phase F)
        for name, asm in ir_to_asm_per_function(mod).items():
            s_path = work / f"{name}.s"
            o_path = work / f"{name}.o"
            s_path.write_text(asm)
            r = subprocess.run(
                ["gcc", "-c", "-o", str(o_path), str(s_path)],
                capture_output=True,
                text=True,
            )
            if r.returncode != 0:
                raise VexError(f"assemble {name} failed: {r.stderr}", error_code="E0505")
            obj_files.append(o_path)
        # Link all objects + runtime
        cmd = ["gcc", "-no-pie", "-o", str(out_path), *[str(o) for o in obj_files], str(RUNTIME_C), str(RUNTIME_EVO_C)]
    else:
        s_path = work / "project.s"
        s_path.write_text(ir_to_asm(mod))
        o_path = work / "project.o"
        r = subprocess.run(
            ["gcc", "-c", "-o", str(o_path), str(s_path)],
            capture_output=True,
            text=True,
        )
        if r.returncode != 0:
            raise VexError(f"assemble failed: {r.stderr}", error_code="E0505")
        cmd = ["gcc", "-no-pie", "-o", str(out_path), str(o_path), str(RUNTIME_C), str(RUNTIME_EVO_C)]

    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        # Fallback: single translation unit if multi-obj link fails (duplicate symbols)
        s_path = work / "project.s"
        s_path.write_text(ir_to_asm(mod))
        cmd2 = ["gcc", "-no-pie", "-o", str(out_path), str(s_path), str(RUNTIME_C), str(RUNTIME_EVO_C)]
        r2 = subprocess.run(cmd2, capture_output=True, text=True)
        if r2.returncode != 0:
            raise VexError(
                f"native link failed: {r.stderr or r2.stderr}",
                error_code="E0505",
            )
    out_path.chmod(out_path.stat().st_mode | 0o111)
    return out_path


def run_native(
    source: str,
    filename: str = "<input>",
    module_paths: list[str] | None = None,
) -> tuple[int, str]:
    path = compile_native(source, filename, module_paths=module_paths)
    r = subprocess.run([str(path)], capture_output=True, text=True)
    return r.returncode, r.stdout


def compile_project(cfg, target: str = "x86_64") -> Path:
    """Compile a Phase C project to native executable under build/."""
    paths = [str(cfg.entry.parent), str(cfg.root)]
    src = cfg.root / "src"
    if src.is_dir():
        paths.append(str(src))
    out = cfg.root / "build" / cfg.name
    return compile_native(
        cfg.entry.read_text(),
        str(cfg.entry),
        out_path=out,
        module_paths=paths,
        build_dir=cfg.root / "build",
        multi_object=True,
    )
