/*
 * Vex OS - kernel/include/storage.h
 * STORAGE-01 system glue: PCI scan -> AHCI -> the first Vex data disk (see vstore.h for the safety rules).
 */
#ifndef VEXOS_STORAGE_H
#define VEXOS_STORAGE_H
#include <stdint.h>
#include "vstore.h"
void storage_init(void);                       /* idempotent; safe to call when there is no controller/disk */
VStoreState storage_state(void);
int storage_format(void);                      /* formats the verified-blank disk (caller must have checked admin rights) */
int storage_load_wallpaper(uint32_t *idx);     /* 1 if a saved choice exists */
int storage_save_wallpaper(uint32_t idx);      /* 1 if durably saved; 0 if no ready store or a write failed */
typedef void (*StorageOut)(const char *line);
void storage_report(StorageOut out);           /* human-readable status lines (disks, store state) */
void storage_pci_report(StorageOut out);       /* PCI device list */
#endif
