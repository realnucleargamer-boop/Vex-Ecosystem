"""VEX-Script 1.5 — static type checker."""

from __future__ import annotations
from dataclasses import dataclass
from .ast_nodes import *
from .errors import VexError, SourceLocation


class TypeError_(VexError):
    pass


TY_INT = "integer_literal"
TY_BOOL = "bool"
TY_STRING = "string"
TY_VOID = "void"
TY_UNKNOWN = "unknown"


@dataclass
class FnSig:
    params: list[str]
    ret: str


@dataclass
class StructSig:
    fields: dict[str, str]


class TypeChecker:
    def __init__(self):
        self.functions: dict[str, FnSig] = {}
        self.structs: dict[str, StructSig] = {}
        self.aliases: dict[str, str] = {}  # name -> resolved primitive/struct
        self.enums: dict[str, list[str]] = {}  # enum name -> variants
        self.functions["println"] = FnSig(params=[], ret=TY_VOID)
        self.functions["print"] = FnSig(params=[], ret=TY_VOID)
        self.functions["assert"] = FnSig(params=[TY_BOOL], ret=TY_VOID)
        self.functions["len_string"] = FnSig(params=[TY_STRING], ret="i64")
        self.functions["str_len"] = FnSig(params=[TY_STRING], ret="i64")
        self.functions["concat"] = FnSig(params=[TY_STRING, TY_STRING], ret=TY_STRING)
        self.functions["abs"] = FnSig(params=["i64"], ret="i64")
        self.functions["min"] = FnSig(params=["i64", "i64"], ret="i64")
        self.functions["max"] = FnSig(params=["i64", "i64"], ret="i64")
        self.functions["str_contains"] = FnSig(params=[TY_STRING, TY_STRING], ret=TY_BOOL)
        self.functions["array_length"] = FnSig(params=[TY_UNKNOWN], ret="i64")
        self.functions["str_equals"] = FnSig(params=[TY_STRING, TY_STRING], ret=TY_BOOL)
        self.functions["str_starts_with"] = FnSig(params=[TY_STRING, TY_STRING], ret=TY_BOOL)
        self.functions["str_ends_with"] = FnSig(params=[TY_STRING, TY_STRING], ret=TY_BOOL)
        self.functions["str_length"] = FnSig(params=[TY_STRING], ret="i64")
        # VEXOS-NATIVE-1: string char access + OS services (native-only; see docs/VEXOS-NATIVE-1.md)
        self.functions["str_char_at"] = FnSig(params=[TY_STRING, "i64"], ret="i64")
        self.functions["str_skip"] = FnSig(params=[TY_STRING, "i64"], ret=TY_STRING)      # VEXOS-NATIVE-1: pointer offset, no allocation
        self.functions["os_cmd"] = FnSig(params=["i64", TY_STRING], ret="i64")           # VEXOS-NATIVE-1: one request channel for Verminal commands
        for _n, _p, _r in [
            ("os_state_get", ["i64"], "i64"), ("os_state_set", ["i64", "i64"], "i64"),
            ("os_buf_push", ["i64", "i64"], "i64"), ("os_buf_pop", ["i64"], "i64"),
            ("os_buf_clear", ["i64"], "i64"), ("os_buf_len", ["i64"], "i64"),
            ("os_buf_text", ["i64"], TY_STRING),
            ("os_out_clear", [], "i64"),
            ("os_app_count", [], "i64"), ("os_app_id", ["i64"], "i64"),
            ("os_app_name", ["i64"], TY_STRING), ("os_app_kind", ["i64"], TY_STRING),
            ("os_app_started_ms", ["i64"], "i64"), ("os_now_ms", [], "i64"),
            ("os_timer_start", ["i64"], "i64"), ("os_timer_stop", [], "i64"),
            ("os_timer_active", [], "i64"),
        ]:
            self.functions[_n] = FnSig(params=_p, ret=_r)
        self.functions["rng_seed"] = FnSig(params=["i64"], ret="i64")
        self.functions["rng_u64"] = FnSig(params=[], ret="i64")
        # 3.0-B tensor builtins (shapes encoded in names for fixed arity)
        self.functions["tensor_create_1"] = FnSig(params=["i64"], ret="tensor")
        self.functions["tensor_create_2"] = FnSig(params=["i64", "i64"], ret="tensor")
        self.functions["tensor_fill"] = FnSig(params=["tensor", "i64"], ret="tensor")
        self.functions["tensor_add"] = FnSig(params=["tensor", "tensor"], ret="tensor")
        self.functions["tensor_mul"] = FnSig(params=["tensor", "tensor"], ret="tensor")
        self.functions["tensor_dot"] = FnSig(params=["tensor", "tensor"], ret="i64")
        self.functions["tensor_matmul"] = FnSig(params=["tensor", "tensor"], ret="tensor")
        self.functions["tensor_get_1"] = FnSig(params=["tensor", "i64"], ret="i64")
        self.functions["tensor_get_2"] = FnSig(params=["tensor", "i64", "i64"], ret="i64")
        self.functions["tensor_set_1"] = FnSig(params=["tensor", "i64", "i64"], ret="i64")
        self.functions["tensor_set_2"] = FnSig(params=["tensor", "i64", "i64", "i64"], ret="i64")
        self.functions["tensor_length"] = FnSig(params=["tensor"], ret="i64")
        self.functions["neural_relu"] = FnSig(params=["tensor"], ret="tensor")
        self.functions["neural_linear"] = FnSig(params=["tensor", "tensor"], ret="tensor")
        self.functions["neural_linear_bias"] = FnSig(params=["tensor", "tensor", "tensor"], ret="tensor")
        self.functions["neural_forward_2"] = FnSig(
            params=["tensor", "tensor", "tensor", "tensor", "tensor"], ret="tensor"
        )
        self.functions["evolve_create"] = FnSig(params=["i64", "i64"], ret="i64")
        self.functions["evolve_size"] = FnSig(params=["i64"], ret="i64")
        self.functions["evolve_get"] = FnSig(params=["i64", "i64"], ret="tensor")
        self.functions["evolve_set"] = FnSig(params=["i64", "i64", "tensor"], ret="i64")
        self.functions["evolve_randomize"] = FnSig(params=["i64"], ret="i64")
        self.functions["evolve_mutate"] = FnSig(params=["tensor", "i64"], ret="tensor")
        self.functions["evolve_crossover"] = FnSig(params=["tensor", "tensor"], ret="tensor")
        self.functions["evolve_select_tournament"] = FnSig(
            params=["i64", "i64", "i64", "i64", "i64"], ret="i64"
        )
        self.functions["evolve_checkpoint_save"] = FnSig(params=["i64", "string"], ret="i64")
        self.functions["evolve_checkpoint_load"] = FnSig(params=["string"], ret="i64")
        self.functions["evolve_checkpoint_exists"] = FnSig(params=["string"], ret="i64")
        self.functions["evolve_best_index"] = FnSig(params=["i64", "i64", "i64", "i64"], ret="i64")
        self.functions["evolve_generation"] = FnSig(params=["i64", "i64", "i64"], ret="i64")
        self.functions["genome_create"] = FnSig(params=["i64"], ret="i64")
        self.functions["genome_from_string"] = FnSig(params=["string"], ret="i64")
        self.functions["genome_length"] = FnSig(params=["i64"], ret="i64")
        self.functions["genome_char_at"] = FnSig(params=["i64", "i64"], ret="string")
        self.functions["genome_set_char"] = FnSig(params=["i64", "i64", "string"], ret="i64")
        self.functions["genome_slice"] = FnSig(params=["i64", "i64", "i64"], ret="i64")
        self.functions["genome_copy"] = FnSig(params=["i64"], ret="i64")
        self.functions["genome_compare"] = FnSig(params=["i64", "i64"], ret="i64")
        self.functions["genome_append_char"] = FnSig(params=["i64", "string"], ret="i64")
        self.functions["genome_to_string"] = FnSig(params=["i64"], ret="string")
        self.functions["genome_fill"] = FnSig(params=["i64", "string", "i64"], ret="i64")
        self.functions["genome_char_code_at"] = FnSig(params=["i64", "i64"], ret="i64")
        self.functions["genome_set_char_code"] = FnSig(params=["i64", "i64", "i64"], ret="i64")
        self.functions["genome_fill_code"] = FnSig(params=["i64", "i64", "i64"], ret="i64")
        self.functions["genome_match"] = FnSig(params=["i64", "string"], ret="i64")
        self.functions["stream_create"] = FnSig(params=["i64", "i64", "i64"], ret="i64")
        self.functions["stream_pop"] = FnSig(params=["i64"], ret="i64")
        self.functions["stream_generation"] = FnSig(params=["i64"], ret="i64")
        self.functions["stream_size"] = FnSig(params=["i64"], ret="i64")
        self.functions["stream_set_elite_count"] = FnSig(params=["i64", "i64"], ret="i64")
        self.functions["stream_advance"] = FnSig(params=["i64", "i64"], ret="i64")
        self.functions["fitness_set"] = FnSig(params=["i64", "i64", "i64"], ret="i64")
        self.functions["fitness_get"] = FnSig(params=["i64", "i64"], ret="i64")
        self.functions["fitness_best_index"] = FnSig(params=["i64"], ret="i64")
        self.functions["fitness_worst_index"] = FnSig(params=["i64"], ret="i64")
        self.functions["fitness_average"] = FnSig(params=["i64"], ret="i64")
        self.functions["fitness_sum"] = FnSig(params=["i64"], ret="i64")
        self.functions["diversity_hamming_avg"] = FnSig(params=["i64"], ret="i64")
        self.functions["migrate_copy"] = FnSig(params=["i64", "i64", "i64", "i64"], ret="i64")
        self.functions["migrate_best"] = FnSig(params=["i64", "i64", "i64"], ret="i64")
        self.functions["elite_preserve_count"] = FnSig(params=["i64"], ret="i64")
        self.functions["gpu_available"] = FnSig(params=[], ret="i64")
        self.functions["device_set"] = FnSig(params=["i64"], ret="i64")
        self.functions["device_get_code"] = FnSig(params=[], ret="i64")
        self.functions["workers_set"] = FnSig(params=["i64"], ret="i64")
        self.functions["workers_get"] = FnSig(params=[], ret="i64")
        self.functions["accel_tensor_zeros_2"] = FnSig(params=["i64", "i64"], ret="tensor")
        self.functions["accel_tensor_fill"] = FnSig(params=["tensor", "i64"], ret="tensor")
        self.functions["accel_matmul"] = FnSig(params=["tensor", "tensor"], ret="tensor")
        self.functions["stream_advance_batch2"] = FnSig(params=["i64", "i64", "i64"], ret="i64")
        self.functions["stream_advance_batch4"] = FnSig(params=["i64", "i64", "i64", "i64", "i64"], ret="i64")

        from .hosted import HOSTED_SIGNATURES
        for hname, (params, ret) in HOSTED_SIGNATURES.items():
            self.functions[hname] = FnSig(params=params, ret=ret)
        for name in ("some", "none", "is_some", "unwrap", "ok", "err", "is_ok", "unwrap_ok"):
            self.functions[name] = FnSig(params=[], ret=TY_UNKNOWN)

    def check_program(self, program: Program):
        for ta in getattr(program, "type_aliases", []) or []:
            if ta.name in self.aliases or ta.name in self.structs or ta.name in self.enums:
                raise TypeError_(f"redefinition of type '{ta.name}'", ta.loc)
            self.aliases[ta.name] = ta.target.name
        # force cycle detection for all aliases
        for ta in getattr(program, "type_aliases", []) or []:
            try:
                self._resolve(ta.name)
            except TypeError_ as e:
                raise TypeError_(str(e.message) if hasattr(e, "message") else str(e), ta.loc)

        for en in getattr(program, "enums", []) or []:
            if en.name in self.enums or en.name in self.structs or en.name in self.aliases:
                raise TypeError_(f"redefinition of type '{en.name}'", en.loc)
            seen = set()
            for v in en.variants:
                if v in seen:
                    raise TypeError_(f"duplicate enum variant '{v}'", en.loc)
                seen.add(v)
            self.enums[en.name] = list(en.variants)

        for st in program.structs:
            fields = {f.name: (f.type.name if f.type else TY_UNKNOWN) for f in st.fields}
            self.structs[st.name] = StructSig(fields=fields)

        for fn in program.functions:
            params = [p.type.name if p.type else TY_UNKNOWN for p in fn.params]
            ret = fn.return_type.name if fn.return_type else TY_UNKNOWN
            self.functions[fn.name] = FnSig(params=params, ret=ret)

        if "main" not in self.functions:
            raise TypeError_("program must contain a 'main' function", program.loc)

        for fn in program.functions:
            self._check_function(fn)

    def _always_returns(self, stmts: list) -> bool:
        for stmt in stmts:
            if isinstance(stmt, Return):
                return True
            if isinstance(stmt, If) and stmt.else_body is not None:
                if self._always_returns(stmt.then_body) and self._always_returns(stmt.else_body):
                    return True
            if isinstance(stmt, Block):
                if self._always_returns(stmt.body):
                    return True
        return False

    def _resolve(self, ty: str) -> str:
        seen = set()
        while ty in self.aliases:
            if ty in seen:
                raise TypeError_(f"cyclic type alias involving '{ty}'")
            seen.add(ty)
            ty = self.aliases[ty]
        return ty

    def _compatible(self, expected: str, actual: str) -> bool:
        if expected.startswith("tensor") or actual.startswith("tensor"):
            # tensor, tensor<f32,[...]> treated compatible in 3.0-B
            if expected.startswith("tensor") and actual.startswith("tensor"):
                return True
            if actual == "unknown" or expected == "unknown":
                return True
        expected = self._resolve(expected)
        actual = self._resolve(actual)
        if expected == TY_UNKNOWN or actual == TY_UNKNOWN:
            return True
        if expected == actual:
            return True
        if actual == TY_INT and expected in (
            "i8", "i16", "i32", "i64", "u8", "u16", "u32", "u64"
        ):
            return True
        # enum types are distinct; integer_literal can coerce to enum
        if actual == TY_INT and expected in self.enums:
            return True
        # Phase C: provisional integer addresses / null for pointer types
        if actual == TY_INT and (expected.startswith("*") or expected.startswith("*mut ")):
            return True
        return False

    def _check_function(self, fn: Function):
        env: dict[str, tuple[str, bool]] = {}
        for p in fn.params:
            ty = p.type.name if p.type else TY_UNKNOWN
            env[p.name] = (ty, False)
        expected_ret = fn.return_type.name if fn.return_type else TY_UNKNOWN
        for stmt in fn.body:
            self._check_stmt(stmt, env, expected_ret)
        if expected_ret not in (TY_VOID, TY_UNKNOWN):
            if not self._always_returns(fn.body):
                raise TypeError_(
                    f"function '{fn.name}' may not return a value on all paths",
                    fn.loc,
                )

    def _check_stmt(self, stmt: Stmt, env: dict, expected_ret: str):
        if isinstance(stmt, Let):
            init_ty = self._check_expr(stmt.init, env) if stmt.init else TY_UNKNOWN
            declared = self._resolve(stmt.type.name) if stmt.type else init_ty
            if stmt.type and stmt.init and not self._compatible(declared, init_ty):
                raise TypeError_(
                    f"type mismatch in let '{stmt.name}': expected '{declared}', got '{init_ty}'",
                    stmt.loc,
                )
            env[stmt.name] = (declared, stmt.mutable)

        elif isinstance(stmt, Return):
            if stmt.value is None:
                if expected_ret not in (TY_VOID, TY_UNKNOWN):
                    raise TypeError_(f"return requires a value of type '{expected_ret}'", stmt.loc)
            else:
                ty = self._check_expr(stmt.value, env)
                if not self._compatible(expected_ret, ty):
                    raise TypeError_(
                        f"return type mismatch: expected '{expected_ret}', got '{ty}'",
                        stmt.value.loc,
                    )

        elif isinstance(stmt, ExprStmt):
            self._check_expr(stmt.expr, env)

        elif isinstance(stmt, If):
            cond_ty = self._check_expr(stmt.cond, env)
            if cond_ty not in (TY_BOOL, TY_UNKNOWN):
                raise TypeError_(f"if condition must be bool, got '{cond_ty}'", stmt.cond.loc)
            child = dict(env)
            for s in stmt.then_body:
                self._check_stmt(s, child, expected_ret)
            if stmt.else_body:
                child2 = dict(env)
                for s in stmt.else_body:
                    self._check_stmt(s, child2, expected_ret)

        elif isinstance(stmt, Match):
            scrut = self._check_expr(stmt.expr, env)
            has_wild = False
            for arm in stmt.arms:
                if arm.pattern == "_":
                    has_wild = True
                elif arm.pattern.isdigit() or (arm.pattern.startswith("-") and arm.pattern[1:].isdigit()):
                    pass  # integer pattern
                elif "::" in arm.pattern:
                    ename, var = arm.pattern.split("::", 1)
                    if ename not in self.enums:
                        raise TypeError_(f"unknown enum '{ename}' in match pattern", stmt.loc)
                    if var not in self.enums[ename]:
                        raise TypeError_(f"unknown variant '{arm.pattern}'", stmt.loc)
                    if scrut not in (TY_UNKNOWN, ename) and self._resolve(scrut) != ename:
                        # allow integer_literal/i64 matching enum
                        if not self._compatible(ename, scrut):
                            raise TypeError_(
                                f"match scrutinee type '{scrut}' does not match pattern '{arm.pattern}'",
                                stmt.loc,
                            )
                else:
                    raise TypeError_(f"invalid match pattern '{arm.pattern}'", stmt.loc)
                for s in arm.body:
                    self._check_stmt(s, env, expected_ret)
            # non-exhaustive warning not error if wildcard or all variants covered
            if not has_wild and scrut in self.enums:
                needed = set(f"{scrut}::{v}" for v in self.enums[scrut])
                got = set(a.pattern for a in stmt.arms)
                if not needed.issubset(got):
                    missing = needed - got
                    raise TypeError_(
                        f"non-exhaustive match; missing {', '.join(sorted(missing))} (or use _)",
                        stmt.loc,
                    )

        elif isinstance(stmt, While):
            cond_ty = self._check_expr(stmt.cond, env)
            if cond_ty not in (TY_BOOL, TY_UNKNOWN):
                raise TypeError_(f"while condition must be bool, got '{cond_ty}'", stmt.cond.loc)
            child = dict(env)
            for s in stmt.body:
                self._check_stmt(s, child, expected_ret)

        elif isinstance(stmt, For):
            child = dict(env)
            if stmt.init:
                self._check_stmt(stmt.init, child, expected_ret)
            if stmt.cond:
                cty = self._check_expr(stmt.cond, child)
                if cty not in (TY_BOOL, TY_UNKNOWN):
                    raise TypeError_(f"for condition must be bool, got '{cty}'", stmt.cond.loc)
            if stmt.step:
                self._check_expr(stmt.step, child)
            for s in stmt.body:
                self._check_stmt(s, child, expected_ret)

        elif isinstance(stmt, Loop):
            child = dict(env)
            for s in stmt.body:
                self._check_stmt(s, child, expected_ret)

        elif isinstance(stmt, Block):
            child = dict(env)
            for s in stmt.body:
                self._check_stmt(s, child, expected_ret)

        elif isinstance(stmt, (Break, Continue)):
            pass

    def _check_expr(self, expr: Expr, env: dict) -> str:
        if isinstance(expr, IntLit):
            return TY_INT
        if isinstance(expr, BoolLit):
            return TY_BOOL
        if isinstance(expr, StringLit):
            return TY_STRING

        if isinstance(expr, Name):
            if "::" in expr.name:
                ename = expr.name.split("::", 1)[0]
                if ename in self.enums:
                    variants = self.enums[ename]
                    v = expr.name.split("::", 1)[1]
                    if v not in variants:
                        raise TypeError_(f"unknown variant '{expr.name}'", expr.loc)
                    return ename
            if expr.name not in env:
                return TY_UNKNOWN
            return self._resolve(env[expr.name][0])

        if isinstance(expr, Assign):
            if expr.name not in env:
                raise TypeError_(f"undefined variable '{expr.name}'", expr.loc)
            ty, mut = env[expr.name]
            if not mut:
                raise TypeError_(f"cannot assign to immutable '{expr.name}'", expr.loc)
            val_ty = self._check_expr(expr.value, env)
            if not self._compatible(ty, val_ty):
                raise TypeError_(
                    f"type mismatch in assignment to '{expr.name}': expected '{ty}', got '{val_ty}'",
                    expr.loc,
                )
            return ty

        if isinstance(expr, Binary):
            l = self._check_expr(expr.left, env)
            r = self._check_expr(expr.right, env)
            opname = expr.op.name if hasattr(expr.op, "name") else str(expr.op)
            if opname in ("EQ", "NE"):
                return TY_BOOL
            if opname in ("LT", "LE", "GT", "GE"):
                if l == TY_STRING or r == TY_STRING:
                    raise TypeError_(f"ordered comparison not allowed on strings", expr.loc)
                return TY_BOOL
            if opname in ("ANDAND", "OROR"):
                if l not in (TY_BOOL, TY_UNKNOWN) or r not in (TY_BOOL, TY_UNKNOWN):
                    raise TypeError_(f"logical operators require bool operands", expr.loc)
                return TY_BOOL
            if opname == "PLUS" and (l == TY_STRING or r == TY_STRING):
                if l == TY_STRING and r == TY_STRING:
                    return TY_STRING
                raise TypeError_(f"string concatenation requires two strings, got '{l}' and '{r}'", expr.loc)
            if opname in ("PLUS", "MINUS", "STAR", "SLASH", "PERCENT"):
                if l == TY_BOOL or r == TY_BOOL:
                    raise TypeError_(f"arithmetic not allowed on bool", expr.loc)
                if l == TY_STRING or r == TY_STRING:
                    raise TypeError_(f"invalid arithmetic on string", expr.loc)
            if l == TY_INT and r == TY_INT:
                return TY_INT
            if l == r and l != TY_UNKNOWN:
                return l
            if TY_UNKNOWN in (l, r) or TY_INT in (l, r):
                if l not in (TY_INT, TY_UNKNOWN):
                    return l
                if r not in (TY_INT, TY_UNKNOWN):
                    return r
                return TY_INT
            return TY_UNKNOWN

        if isinstance(expr, Unary):
            ot = self._check_expr(expr.operand, env)
            opname = expr.op.name if hasattr(expr.op, "name") else str(expr.op)
            if opname == "BANG":
                if ot not in (TY_BOOL, TY_UNKNOWN):
                    raise TypeError_(f"! requires bool, got '{ot}'", expr.loc)
                return TY_BOOL
            return ot

        if isinstance(expr, Cast):
            src_ty = self._check_expr(expr.expr, env)
            target = expr.target.name
            allowed = {
                ("i32", "i64"), ("i64", "i32"),
                (TY_INT, "i32"), (TY_INT, "i64"),
                ("i32", "i32"), ("i64", "i64"),
            }
            if (src_ty, target) in allowed or src_ty == target or src_ty == TY_UNKNOWN:
                return target
            raise TypeError_(f"invalid cast from '{src_ty}' to '{target}'", expr.loc)

        if isinstance(expr, Call):
            arg_tys = [self._check_expr(a, env) for a in expr.args]
            if expr.name in self.functions:
                sig = self.functions[expr.name]
                skip_arity = expr.name in (
                    "println", "print", "some", "none", "ok", "err",
                    "is_some", "unwrap", "is_ok", "unwrap_ok",
                )
                if not skip_arity:
                    if len(arg_tys) != len(sig.params):
                        raise TypeError_(
                            f"function '{expr.name}' expects {len(sig.params)} arguments, got {len(arg_tys)}",
                            expr.loc,
                        )
                    for i, (expected, actual) in enumerate(zip(sig.params, arg_tys)):
                        if not self._compatible(expected, actual):
                            raise TypeError_(
                                f"argument {i+1} of '{expr.name}': expected '{expected}', got '{actual}'",
                                expr.args[i].loc,
                            )
                return sig.ret
            return TY_UNKNOWN

        if isinstance(expr, StructLit):
            if expr.name not in self.structs:
                raise TypeError_(f"undefined struct type '{expr.name}'", expr.loc)
            sig = self.structs[expr.name]
            provided = set()
            for fname, fexpr in expr.fields:
                if fname not in sig.fields:
                    raise TypeError_(f"struct '{expr.name}' has no field '{fname}'", expr.loc)
                fty = self._check_expr(fexpr, env)
                expected = sig.fields[fname]
                if not self._compatible(expected, fty):
                    raise TypeError_(
                        f"field '{fname}' of '{expr.name}': expected '{expected}', got '{fty}'",
                        fexpr.loc,
                    )
                provided.add(fname)
            missing = set(sig.fields.keys()) - provided
            if missing:
                raise TypeError_(
                    f"struct '{expr.name}' missing fields: {', '.join(sorted(missing))}",
                    expr.loc,
                )
            return expr.name

        if isinstance(expr, FieldAccess):
            obj_ty = self._check_expr(expr.obj, env)
            if obj_ty in self.structs:
                sig = self.structs[obj_ty]
                if expr.field not in sig.fields:
                    raise TypeError_(f"struct '{obj_ty}' has no field '{expr.field}'", expr.loc)
                return sig.fields[expr.field]
            if obj_ty != TY_UNKNOWN:
                raise TypeError_(f"field access on non-struct type '{obj_ty}'", expr.loc)
            return TY_UNKNOWN

        if isinstance(expr, ArrayLit):
            if not expr.elements:
                return "i64[]"  # empty array — element type unknown; use i64[] default
            et = self._check_expr(expr.elements[0], env)
            for e in expr.elements[1:]:
                t2 = self._check_expr(e, env)
                if not self._compatible(et, t2) and not self._compatible(t2, et):
                    raise TypeError_(f"array elements must share a type, got '{et}' and '{t2}'", e.loc)
            if et == TY_INT:
                et = "i64"
            return f"{et}[]"

        if isinstance(expr, Index):
            ot = self._check_expr(expr.obj, env)
            it = self._check_expr(expr.index, env)
            if it not in (TY_INT, "i64", "i32", "u64", "u32", TY_UNKNOWN):
                raise TypeError_(f"array index must be integer, got '{it}'", expr.index.loc)
            if ot.endswith("[]"):
                return ot[:-2]
            if ot != TY_UNKNOWN:
                raise TypeError_(f"indexing requires array type, got '{ot}'", expr.loc)
            return TY_UNKNOWN

        if isinstance(expr, FieldAssign):
            obj_ty = self._check_expr(expr.obj, env)
            val_ty = self._check_expr(expr.value, env)
            if obj_ty in self.structs:
                sig = self.structs[obj_ty]
                if expr.field not in sig.fields:
                    raise TypeError_(f"struct '{obj_ty}' has no field '{expr.field}'", expr.loc)
                expected = sig.fields[expr.field]
                if not self._compatible(expected, val_ty):
                    raise TypeError_(
                        f"field '{expr.field}' of '{obj_ty}': expected '{expected}', got '{val_ty}'",
                        expr.value.loc,
                    )
            elif obj_ty != TY_UNKNOWN:
                raise TypeError_(f"field assignment on non-struct type '{obj_ty}'", expr.loc)
            return val_ty

        if isinstance(expr, IndexAssign):
            ot = self._check_expr(expr.obj, env)
            it = self._check_expr(expr.index, env)
            if it not in (TY_INT, "i64", "i32", "u64", "u32", TY_UNKNOWN):
                raise TypeError_(f"array index must be integer, got '{it}'", expr.index.loc)
            val_ty = self._check_expr(expr.value, env)
            if ot.endswith("[]"):
                elem_ty = ot[:-2]
                if not self._compatible(elem_ty, val_ty) and not self._compatible(val_ty, elem_ty):
                    raise TypeError_(
                        f"cannot assign '{val_ty}' into array of '{elem_ty}'", expr.value.loc
                    )
            elif ot != TY_UNKNOWN:
                raise TypeError_(f"index assignment requires array type, got '{ot}'", expr.loc)
            return val_ty

        return TY_UNKNOWN
