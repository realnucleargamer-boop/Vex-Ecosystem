/*
 * Vex OS - kernel/src/arch/x86_64/time/rtc.c
 * CMOS RTC reader. See include/rtc.h.
 */
#include "rtc.h"

static inline void outb(uint16_t p, uint8_t v) { __asm__ volatile("outb %0,%1" :: "a"(v), "Nd"(p)); }
static inline uint8_t inb(uint16_t p) { uint8_t v; __asm__ volatile("inb %1,%0" : "=a"(v) : "Nd"(p)); return v; }

static uint8_t cmos(uint8_t reg) { outb(0x70, reg); return inb(0x71); }

uint8_t rtc_bcd_to_bin(uint8_t v) { return (uint8_t)((v & 0x0F) + ((v >> 4) * 10u)); }
static int bcd_ok(uint8_t v) { return (v & 0x0F) <= 9 && (v >> 4) <= 9; }

static int is_leap(uint16_t y) { return (y % 4 == 0 && y % 100 != 0) || y % 400 == 0; }

int rtc_validate(const RtcTime *t)
{
    static const uint8_t dim[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
    if (!t || t->year < 1970 || t->year > 2099) return 0;
    if (t->month < 1 || t->month > 12) return 0;
    uint8_t md = dim[t->month - 1];
    if (t->month == 2 && is_leap(t->year)) md = 29;
    if (t->day < 1 || t->day > md) return 0;
    return t->hour < 24 && t->minute < 60 && t->second < 60;
}

/* Sakamoto's algorithm. */
int rtc_weekday(uint16_t y, uint8_t m, uint8_t d)
{
    static const int t[12] = {0,3,2,5,0,3,5,1,4,6,2,4};
    if (m < 1 || m > 12) return 0;
    int yy = (int)y - (m < 3);
    return (yy + yy/4 - yy/100 + yy/400 + t[m-1] + d) % 7;
}

typedef struct { uint8_t s, mi, h, d, mo, y, c, b; } Raw;

static int read_raw(Raw *r)
{
    /* Wait (bounded) for "update in progress" to clear: registers are
     * invalid while it is set. */
    uint32_t i;
    for (i = 0; i < 100000u && (cmos(0x0A) & 0x80); i++) { }
    if (i >= 100000u) return 0;
    r->s = cmos(0x00); r->mi = cmos(0x02); r->h = cmos(0x04);
    r->d = cmos(0x07); r->mo = cmos(0x08); r->y = cmos(0x09);
    r->c = cmos(0x32); r->b = cmos(0x0B);
    return 1;
}
static int raw_eq(const Raw *a, const Raw *b) { return a->s==b->s && a->mi==b->mi && a->h==b->h && a->d==b->d && a->mo==b->mo && a->y==b->y && a->c==b->c; }

int rtc_read(RtcTime *out)
{
    if (!out) return 0;
    Raw a, b;
    /* Two identical consecutive reads guard against a rollover mid-read. */
    int ok = 0;
    for (int tries = 0; tries < 5 && !ok; tries++) {
        if (!read_raw(&a) || !read_raw(&b)) continue;
        ok = raw_eq(&a, &b);
    }
    if (!ok) return 0;

    int binary = (a.b & 0x04) != 0, h24 = (a.b & 0x02) != 0;
    uint8_t pm = (uint8_t)(a.h & 0x80);
    uint8_t h = (uint8_t)(a.h & 0x7F);
    if (!binary) {
        if (!bcd_ok(a.s) || !bcd_ok(a.mi) || !bcd_ok(h) || !bcd_ok(a.d) || !bcd_ok(a.mo) || !bcd_ok(a.y)) return 0;
        a.s = rtc_bcd_to_bin(a.s); a.mi = rtc_bcd_to_bin(a.mi); h = rtc_bcd_to_bin(h);
        a.d = rtc_bcd_to_bin(a.d); a.mo = rtc_bcd_to_bin(a.mo); a.y = rtc_bcd_to_bin(a.y);
        if (a.c != 0 && bcd_ok(a.c)) a.c = rtc_bcd_to_bin(a.c); else a.c = 0;
    }
    if (!h24) { h = (uint8_t)(h % 12); if (pm) h = (uint8_t)(h + 12); }   /* 12h clock */
    uint16_t century = (a.c >= 19 && a.c <= 21) ? a.c : 20;                /* register 0x32 is optional */
    out->year = (uint16_t)(century * 100u + a.y);
    out->month = a.mo; out->day = a.d; out->hour = h; out->minute = a.mi; out->second = a.s;
    return rtc_validate(out);
}
