/* Vex OS - kernel/src/ui/wallpaper.c - see include/wallpaper.h */
#include "wallpaper.h"
#include "pmm.h"
#include "serial.h"

#ifndef VEX_WP_TEST_CORRUPT
#define VEX_WP_TEST_CORRUPT 0          /* test builds only: 1-based wallpaper index whose checksum is forced to fail */
#endif
#ifndef VEX_WP_TEST_MISSING
#define VEX_WP_TEST_MISSING 0          /* test builds only: 1-based wallpaper index treated as a missing file */
#endif

#define WP_MAX_DRAW 512                 /* widest thumbnail/preview: bounds the on-stack scanline buffer (2 KiB) */

static struct {
    int applied;
    uint32_t *cache; uint64_t cache_phys; uint32_t cache_pages; uint32_t cw, ch;
    int8_t stat_valid[16]; WpStatus stat[16];
} W;

int wp_count(void) { return 1 + wp_asset_count; }
const char *wp_name(int idx) { if (idx == 0) return "Default"; if (idx < 0 || idx > wp_asset_count) return 0; return wp_assets[idx - 1].name; }
const char *wp_id(int idx) { if (idx == 0) return "default"; if (idx < 0 || idx > wp_asset_count) return 0; return wp_assets[idx - 1].id; }
int wp_applied(void) { return W.applied; }
int wp_active(void) { return W.cache != 0; }
uint32_t wp_cache_bytes(void) { return W.cache ? W.cache_pages * (uint32_t)PMM_PAGE_SIZE : 0; }
uint32_t wp_cache_dims(uint32_t *w, uint32_t *h) { if (w) *w = W.cw; if (h) *h = W.ch; return W.cache ? 1u : 0u; }
void wp_recheck(void) { for (unsigned i = 0; i < sizeof W.stat_valid; i++) W.stat_valid[i] = 0; }

static WpStatus verify_asset(int idx, WpImage *img)
{
    if (idx < 1 || idx > wp_asset_count) return WP_E_MISSING;
    const WpAsset *a = &wp_assets[idx - 1];
    if (!a->data || a->size == 0 || idx == VEX_WP_TEST_MISSING) return WP_E_MISSING;
    WpStatus s = wp_verify(a->data, a->size, img);
    if (s == WP_OK && idx == VEX_WP_TEST_CORRUPT) s = WP_E_CRC;
    return s;
}

WpStatus wp_status(int idx)
{
    if (idx == 0) return WP_OK;
    if (idx < 0 || idx > wp_asset_count) return WP_E_MISSING;
    if (idx < (int)sizeof W.stat_valid && W.stat_valid[idx]) return W.stat[idx];
    WpStatus s = verify_asset(idx, 0);
    if (idx < (int)sizeof W.stat_valid) { W.stat_valid[idx] = 1; W.stat[idx] = s; }
    return s;
}

static void cache_free(void)
{
    if (!W.cache) return;
    PmmResult r = pmm_free_pages(W.cache_phys, W.cache_pages);
    serial_puts("[wallpaper] cache freed ("); serial_put_dec64((uint64_t)W.cache_pages * PMM_PAGE_SIZE); serial_puts(" bytes) ");
    serial_puts(r == PMM_OK ? "ok\n" : "FAILED\n");
    W.cache = 0; W.cache_phys = 0; W.cache_pages = 0; W.cw = W.ch = 0;
}

WpStatus wp_apply(int idx, const GfxFb *fb)
{
    if (idx == 0) { cache_free(); W.applied = 0; return WP_OK; }
    WpImage img;
    WpStatus s = verify_asset(idx, &img);
    if (idx > 0 && idx < (int)sizeof W.stat_valid) { W.stat_valid[idx] = 1; W.stat[idx] = s; }
    if (s != WP_OK) return s;                                   /* previous wallpaper stays in place */
    if (!fb || !fb->ok || !fb->pixels) return WP_E_SCREEN;
    uint32_t vw = fb->width, vh = fb->height;
    if (vw < WP_MIN_SCREEN || vh < WP_MIN_SCREEN || vw > 8192u || vh > 8192u) return WP_E_SCREEN;
    uint64_t bytes = (uint64_t)vw * vh * 4u;
    if (bytes > WP_CACHE_MAX_BYTES) return WP_E_SCREEN;
    WpCover cv;
    if (wp_cover(img.w, img.h, vw, vh, &cv) != WP_OK) return WP_E_SCREEN;

    /* Reuse the existing cache when the size matches; otherwise take a NEW one first so a failed
     * allocation never costs the user the wallpaper they already have. */
    uint32_t *dst = W.cache; uint64_t phys = 0; uint32_t pages = (uint32_t)((bytes + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE);
    int fresh = 0;
    if (!W.cache || W.cw != vw || W.ch != vh) {
        phys = pmm_try_alloc_pages(pages);
        if (!phys) return WP_E_NOMEM;
        dst = (uint32_t *)(uintptr_t)phys; fresh = 1;
        serial_puts("[wallpaper] cache allocated ("); serial_put_dec64((uint64_t)pages * PMM_PAGE_SIZE); serial_puts(" bytes for ");
        serial_put_dec64(vw); serial_puts("x"); serial_put_dec64(vh); serial_puts(")\n");
    }
    /* Decode into a scratch-free path: render straight into the (possibly new) cache.  When reusing the live cache
     * a mid-render failure cannot happen (inputs already validated), so there is no half-written visible state. */
    for (uint32_t y = 0; y < vh; y++) {
        if (wp_render_row(&img, &cv, y, 0, vw, dst + (size_t)y * vw, fb->r_shift, fb->g_shift, fb->b_shift) != WP_OK) {
            if (fresh) pmm_free_pages(phys, pages);
            return WP_E_RANGE;
        }
    }
    if (fresh) { cache_free(); W.cache = dst; W.cache_phys = phys; W.cache_pages = pages; W.cw = vw; W.ch = vh; }
    W.applied = idx;
    return WP_OK;
}

int wp_blit_span(volatile uint32_t *dst, uint32_t x, uint32_t y, uint32_t n)
{
    if (!W.cache || !dst || y >= W.ch || x >= W.cw || n > W.cw - x) return 0;
    const uint32_t *src = W.cache + (size_t)y * W.cw + x;
    for (uint32_t i = 0; i < n; i++) dst[i] = src[i];
    return 1;
}

WpStatus wp_draw_scaled(const GfxFb *fb, int idx, int32_t x, int32_t y, int32_t w, int32_t h)
{
    if (!fb || !fb->ok || !fb->pixels) return WP_E_SCREEN;
    if (idx < 1 || idx > wp_asset_count) return WP_E_MISSING;     /* index 0 (default) is drawn by vexui, not from an asset */
    if (w <= 0 || h <= 0 || w > WP_MAX_DRAW || h > 4096) return WP_E_RANGE;
    WpImage img; WpStatus s = wp_status(idx);                   /* full checksum happened once (cached); drawing only re-parses the header */
    if (s != WP_OK) return s;
    if (wp_parse(wp_assets[idx - 1].data, wp_assets[idx - 1].size, &img) != WP_OK) return WP_E_CRC;
    WpCover cv; if (wp_cover(img.w, img.h, (uint32_t)w, (uint32_t)h, &cv) != WP_OK) return WP_E_RANGE;
    uint32_t line[WP_MAX_DRAW];
    int32_t x0 = x < 0 ? -x : 0, x1 = x + w > (int32_t)fb->width ? (int32_t)fb->width - x : w;
    if (x1 <= x0) return WP_OK;
    for (int32_t r = 0; r < h; r++) {
        int32_t py = y + r; if (py < 0 || py >= (int32_t)fb->height) continue;
        if (wp_render_row(&img, &cv, (uint32_t)r, (uint32_t)x0, (uint32_t)(x1 - x0), line, fb->r_shift, fb->g_shift, fb->b_shift) != WP_OK) return WP_E_RANGE;
        volatile uint32_t *d = fb->pixels + (size_t)py * fb->pitch_px + (uint32_t)(x + x0);
        for (int32_t i = 0; i < x1 - x0; i++) d[i] = line[i];
    }
    return WP_OK;
}

int wp_region_is_light(int32_t x, int32_t y, int32_t w, int32_t h, const GfxFb *fb)
{
    if (!W.cache || !fb) return 0;
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x >= (int32_t)W.cw || y >= (int32_t)W.ch) return 0;
    if (x + w > (int32_t)W.cw) w = (int32_t)W.cw - x;
    if (y + h > (int32_t)W.ch) h = (int32_t)W.ch - y;
    if (w <= 0 || h <= 0) return 0;
    return wp_mean_luma(W.cache + (size_t)y * W.cw + x, W.cw, (uint32_t)w, (uint32_t)h, fb->r_shift, fb->g_shift, fb->b_shift) > 150u;
}
