#include "input.h"

static VexKeyEvent queue[VEX_INPUT_QUEUE_CAPACITY];
static volatile uint32_t head, tail;
static volatile uint16_t mods;
static volatile uint64_t sequence, dropped;

static int valid_key(VexKeyCode k) { return k > VEX_KEY_UNKNOWN && k <= VEX_KEY_RALT; }
static uint16_t modifier_bit(VexKeyCode k) {
    switch ((uint16_t)k) { case 224: return VEX_MOD_LCTRL; case 225: return VEX_MOD_LSHIFT;
    case 226: return VEX_MOD_LALT; case 228: return VEX_MOD_RCTRL; case 229: return VEX_MOD_RSHIFT;
    case 230: return VEX_MOD_RALT; default: return 0; }
}
/* INPUT-03 mouse ring (see input.h). */
static VexMouseEvent mqueue[VEX_MOUSE_QUEUE_CAPACITY];
static volatile uint32_t mhead, mtail;
static volatile uint8_t  mbuttons;
static volatile uint64_t msequence, mdropped;

void input_init(void) {
    head = tail = 0; mods = 0; sequence = dropped = 0;
    mhead = mtail = 0; mbuttons = 0; msequence = mdropped = 0;
}
int input_publish_key(VexKeyCode key, VexKeyAction action) {
    if (!valid_key(key) || (action != VEX_KEY_PRESS && action != VEX_KEY_RELEASE)) return 0;
    uint16_t bit = modifier_bit(key);
    if (bit) { if (action == VEX_KEY_PRESS) mods |= bit; else mods &= (uint16_t)~bit; }
    uint32_t next = (head + 1u) % VEX_INPUT_QUEUE_CAPACITY;
    if (next == tail) { dropped++; return 0; }
    queue[head].key = key; queue[head].action = action; queue[head].modifiers = mods;
    queue[head].sequence = ++sequence;
    __atomic_thread_fence(__ATOMIC_RELEASE); head = next; return 1;
}
int input_poll_key(VexKeyEvent *out) {
    if (!out || tail == head) return 0;
    __atomic_thread_fence(__ATOMIC_ACQUIRE); *out = queue[tail]; tail = (tail + 1u) % VEX_INPUT_QUEUE_CAPACITY; return 1;
}
uint16_t input_modifiers(void) { return mods; }
uint64_t input_dropped_events(void) { return dropped; }
int input_self_test(void) {
    VexKeyEvent e;
    input_init();
    if (input_publish_key(VEX_KEY_UNKNOWN, VEX_KEY_PRESS)) return 0;
    if (!input_publish_key(VEX_KEY_LSHIFT, VEX_KEY_PRESS)) return 0;
    if (!input_publish_key(VEX_KEY_A, VEX_KEY_PRESS)) return 0;
    if (!input_poll_key(&e) || e.key != VEX_KEY_LSHIFT || !(e.modifiers & VEX_MOD_LSHIFT)) return 0;
    if (!input_poll_key(&e) || e.key != VEX_KEY_A || !(e.modifiers & VEX_MOD_LSHIFT)) return 0;
    if (!input_publish_key(VEX_KEY_LSHIFT, VEX_KEY_RELEASE) || input_modifiers()) return 0;
    return input_poll_key(&e) && e.action == VEX_KEY_RELEASE && !e.modifiers && !input_poll_key(&e);
}

/* ------------------------------------------------------------------ *
 * INPUT-03 mouse queue
 * ------------------------------------------------------------------ */
static int16_t sat16(int32_t v) { return v > 32767 ? 32767 : v < -32768 ? -32768 : (int16_t)v; }

int input_publish_mouse(int32_t dx, int32_t dy, uint8_t buttons) {
    /* Only the three defined button bits are meaningful. */
    if (buttons & (uint8_t)~(VEX_MOUSE_BTN_LEFT | VEX_MOUSE_BTN_RIGHT | VEX_MOUSE_BTN_MIDDLE)) return 0;
    uint32_t next = (mhead + 1u) % VEX_MOUSE_QUEUE_CAPACITY;
    if (next == mtail) { mdropped++; return 0; }
    mqueue[mhead].dx = sat16(dx); mqueue[mhead].dy = sat16(dy);
    mqueue[mhead].buttons = buttons; mqueue[mhead].sequence = ++msequence;
    mbuttons = buttons;
    __atomic_thread_fence(__ATOMIC_RELEASE); mhead = next; return 1;
}
int input_poll_mouse(VexMouseEvent *out) {
    if (!out || mtail == mhead) return 0;
    __atomic_thread_fence(__ATOMIC_ACQUIRE);
    *out = mqueue[mtail]; mtail = (mtail + 1u) % VEX_MOUSE_QUEUE_CAPACITY; return 1;
}
uint8_t  input_mouse_buttons(void) { return mbuttons; }
uint64_t input_mouse_dropped(void) { return mdropped; }

int input_mouse_self_test(void) {
    VexMouseEvent e;
    input_init();
    /* undefined button bits are refused, nothing queued */
    if (input_publish_mouse(1, 1, 0x80) || input_poll_mouse(&e)) return 0;
    /* NULL out pointer is safe */
    if (input_poll_mouse(0)) return 0;
    /* ordering + absolute button mask + saturation */
    if (!input_publish_mouse(5, -7, VEX_MOUSE_BTN_LEFT)) return 0;
    if (!input_publish_mouse(100000, -100000, 0)) return 0;
    if (!input_poll_mouse(&e) || e.dx != 5 || e.dy != -7 || e.buttons != VEX_MOUSE_BTN_LEFT) return 0;
    if (!input_poll_mouse(&e) || e.dx != 32767 || e.dy != -32768 || e.buttons != 0) return 0;
    if (input_poll_mouse(&e)) return 0;
    /* overflow: exactly CAPACITY-1 fit, the rest are dropped and counted, no corruption */
    input_init();
    uint32_t ok = 0;
    for (uint32_t i = 0; i < VEX_MOUSE_QUEUE_CAPACITY + 10u; i++) ok += (uint32_t)input_publish_mouse((int32_t)i, 0, 0);
    if (ok != VEX_MOUSE_QUEUE_CAPACITY - 1u || input_mouse_dropped() != 11u) return 0;
    for (uint32_t i = 0; i < VEX_MOUSE_QUEUE_CAPACITY - 1u; i++)
        if (!input_poll_mouse(&e) || e.dx != (int16_t)i) return 0;
    if (input_poll_mouse(&e)) return 0;
    /* usable again after a full drain (ring indices wrapped correctly) */
    if (!input_publish_mouse(3, 4, 0) || !input_poll_mouse(&e) || e.dx != 3 || e.dy != 4) return 0;
    input_init();
    return 1;
}
