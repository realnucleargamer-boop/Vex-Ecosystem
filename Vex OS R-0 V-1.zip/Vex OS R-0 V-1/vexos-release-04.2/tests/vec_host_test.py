#!/usr/bin/env python3
"""GFX-VEC-01 host verification of kernel/src/graphics/vec.c against an INDEPENDENT exact-coverage reference.
Reference: for each pixel, the true area of (shape ∩ pixel square) computed in float64 by Sutherland-Hodgman clipping (polygons),
or by dense supersampling of the analytic shape (ellipse / rounded rect / stroked line). Usage: tests/vec_host_test.py [O2|asan]
(asan needs LD_PRELOAD=libasan.so)."""
import ctypes as C, math, os, random, subprocess, sys
import numpy as np
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
kind = sys.argv[1] if len(sys.argv) > 1 else "O2"; out = os.path.join(ROOT, "build", "vec-host"); os.makedirs(out, exist_ok=True)
flags = ["-O2"] if kind == "O2" else ["-O1", "-g", "-fsanitize=address,undefined", "-fno-sanitize-recover=undefined", "-fno-omit-frame-pointer"]
so = os.path.join(out, f"libvec_{kind}.so")
subprocess.check_call(["gcc", *flags, "-shared", "-fPIC", "-Wall", "-Wextra", "-std=gnu11", "-I" + os.path.join(ROOT, "kernel/include"), "-I" + os.path.join(ROOT, "common/include"),
                       os.path.join(ROOT, "kernel/src/graphics/vec.c"), os.path.join(ROOT, "tests/vec_host_shim.c"), "-o", so])
L = C.CDLL(so)
i32p = C.POINTER(C.c_int32); u8p = C.POINTER(C.c_uint8)
R = []
def check(ok, what, d=""): R.append(bool(ok)); print(("PASS  " if ok else "FAIL  ") + what + (f"  [{d}]" if d and not ok else ""), flush=True)
def arr(v): return (C.c_int32 * len(v))(*v)
def mask(w, h): return (C.c_uint8 * (w * h))()
def np_mask(m, w, h): return np.frombuffer(m, dtype=np.uint8).reshape(h, w).astype(np.int32)

from shapely.geometry import Polygon, LineString, box
def ref_geom(g, w, h):
    """Exact per-pixel coverage of a shapely geometry (float64): area of (geometry ∩ pixel square)."""
    m = np.zeros((h, w)); x0, y0, x1, y1 = g.bounds
    for y in range(max(0, int(y0)), min(h, int(y1) + 1)):
        for x in range(max(0, int(x0)), min(w, int(x1) + 1)):
            m[y, x] = g.intersection(box(x, y, x + 1, y + 1)).area
    return np.rint(m * 255).astype(np.int32)
def ref_poly(poly, w, h): return ref_geom(Polygon(poly), w, h)
def super_mask(inside, w, h, S=24):
    ys, xs = np.mgrid[0:h * S, 0:w * S]; px = (xs + 0.5) / S; py = (ys + 0.5) / S
    return np.rint(inside(px, py).reshape(h, S, w, S).mean(axis=(1, 3)) * 255).astype(np.int32)

rnd = random.Random(7)
# 1. random simple polygons (star-shaped about a centre, fractional Q8 coordinates): exact comparison
worst = 0; N = 120; bad = 0; made = 0
while made < N:
    W = H = 28; n = rnd.randint(3, 11); cx, cy = rnd.uniform(8, 20), rnd.uniform(8, 20); angs = sorted(rnd.uniform(0, 2 * math.pi) for _ in range(n))
    pts = [(cx + rnd.uniform(1.5, 8) * math.cos(a), cy + rnd.uniform(1.5, 8) * math.sin(a)) for a in angs]
    q = [(round(x * 256), round(y * 256)) for x, y in pts]; poly = [(x / 256, y / 256) for x, y in q]
    if not Polygon(poly).is_valid or Polygon(poly).area < 1.0: continue          # only valid simple polygons are meaningful references
    made += 1
    m = mask(W, H); assert L.shim_poly_mask(arr([a for a, _ in q]), arr([b for _, b in q]), len(q), W, H, 0, m) == 0
    d = np.abs(np_mask(m, W, H) - ref_poly(poly, W, H)).max(); worst = max(worst, d); bad += d > 3
check(bad == 0, f"{N} random simple polygons (fractional Q8 vertices): max |coverage - exact| = {worst}/255 (limit 3)")
# 2. axis-aligned rectangles at fractional positions: coverage is exactly the product of overlaps
worst = 0
for _ in range(200):
    x0, y0 = rnd.uniform(0.2, 6), rnd.uniform(0.2, 6); rw, rh = rnd.uniform(0.3, 9), rnd.uniform(0.3, 9)
    q = [(round(x0 * 256), round(y0 * 256)), (round((x0 + rw) * 256), round(y0 * 256)), (round((x0 + rw) * 256), round((y0 + rh) * 256)), (round(x0 * 256), round((y0 + rh) * 256))]
    W = H = 18; m = mask(W, H); L.shim_poly_mask(arr([a for a, _ in q]), arr([b for _, b in q]), 4, W, H, 0, m)
    poly = [(a / 256, b / 256) for a, b in q]; worst = max(worst, np.abs(np_mask(m, W, H) - ref_poly(poly, W, H)).max())
check(worst <= 2, f"200 fractional rectangles: max error {worst}/255 (limit 2)")
# 3. sub-pixel translation: shifting a shape by 1/256 px changes coverage smoothly (the point of fractional coordinates)
base = [(4 * 256, 4 * 256), (10 * 256, 4 * 256), (10 * 256, 10 * 256), (4 * 256, 10 * 256)]; prev = None; steps = []
for dx in range(0, 256, 32):
    q = [(a + dx, b) for a, b in base]; m = mask(16, 16); L.shim_poly_mask(arr([a for a, _ in q]), arr([b for _, b in q]), 4, 16, 16, 0, m); steps.append(int(np_mask(m, 16, 16)[6, 4]))
check(steps == sorted(steps, reverse=True) and steps[0] == 255 and steps[-1] < 40 and len(set(steps)) == len(steps), f"moving a rectangle edge by 1/8 px steps gives smoothly decreasing left-edge coverage {steps}")
# 4. fill rules: pentagram (self-overlapping): even-odd leaves the centre hollow, non-zero fills it
c = 14 * 256; pts = [(c + int(10 * 256 * math.sin(2 * math.pi * k * 2 / 5)), c - int(10 * 256 * math.cos(2 * math.pi * k * 2 / 5))) for k in range(5)]
mn, me = mask(28, 28), mask(28, 28); L.shim_poly_mask(arr([a for a, _ in pts]), arr([b for _, b in pts]), 5, 28, 28, 0, mn); L.shim_poly_mask(arr([a for a, _ in pts]), arr([b for _, b in pts]), 5, 28, 28, 1, me)
check(np_mask(mn, 28, 28)[14, 14] == 255 and np_mask(me, 28, 28)[14, 14] == 0 and np_mask(me, 28, 28)[8, 14] > 200, "pentagram: non-zero fills the centre (255), even-odd leaves it hollow (0), arms still filled")
# 5. holes: outer CCW + inner CW square with non-zero => hollow ring with exact area
outer = [(2 * 256, 2 * 256), (14 * 256, 2 * 256), (14 * 256, 14 * 256), (2 * 256, 14 * 256)]; inner = [(5 * 256, 5 * 256), (5 * 256, 11 * 256), (11 * 256, 11 * 256), (11 * 256, 5 * 256)]
xs = arr([a for a, _ in outer + inner]); ys = arr([b for _, b in outer + inner]); m = mask(16, 16); L.shim_multi_mask(xs, ys, (C.c_int * 2)(4, 4), 2, 16, 16, 0, m); mm = np_mask(m, 16, 16)
check(mm[3, 3] == 255 and mm[8, 8] == 0 and mm.sum() == (144 - 36) * 255, "ring (opposite windings, non-zero): hole is empty, ring area exact (108 px)")
# 6. ellipse / rounded rect / stroked line vs dense supersampling of the analytic shape
def ell_ref(cx, cy, rx, ry, W, H): return super_mask(lambda x, y: ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1, W, H)
worst = 0
for _ in range(25):
    W = H = 40; cx, cy = rnd.uniform(14, 26), rnd.uniform(14, 26); rx, ry = rnd.uniform(1, 12), rnd.uniform(1, 12)
    m = mask(W, H); L.shim_ellipse_mask(round(cx * 256), round(cy * 256), round(rx * 256), round(ry * 256), W, H, m); worst = max(worst, np.abs(np_mask(m, W, H) - ell_ref(cx, cy, rx, ry, W, H)).max())
check(worst <= 12, f"25 random ellipses (Bezier-flattened) vs analytic supersample: max error {worst}/255 (limit 12; 4-cubic circle approximation + 24x24 reference noise)")
def rr_ref(x, y, rw, rh, r, W, H):
    def f(px, py):
        qx = np.maximum(np.abs(px - (x + rw / 2)) - (rw / 2 - r), 0); qy = np.maximum(np.abs(py - (y + rh / 2)) - (rh / 2 - r), 0); return qx * qx + qy * qy <= r * r
    return super_mask(f, W, H)
worst = 0
for _ in range(25):
    W = H = 48; x, y = rnd.uniform(2, 8), rnd.uniform(2, 8); rw, rh = rnd.uniform(8, 36), rnd.uniform(8, 36); r = rnd.uniform(0.5, min(rw, rh) / 2)
    m = mask(W, H); L.shim_rrect_mask(round(x * 256), round(y * 256), round(rw * 256), round(rh * 256), round(r * 256), W, H, m); worst = max(worst, np.abs(np_mask(m, W, H) - rr_ref(x, y, rw, rh, r, W, H)).max())
check(worst <= 12, f"25 random rounded rectangles vs analytic: max error {worst}/255 (limit 12)")
def line_ref(x0, y0, x1, y1, wd, rnd_caps, W, H):
    return ref_geom(LineString([(x0, y0), (x1, y1)]).buffer(wd / 2, cap_style=1 if rnd_caps else 2, quad_segs=64), W, H)
worst = 0
for rc in (1, 0):
    for _ in range(15):
        W = H = 40; x0, y0, x1, y1 = [rnd.uniform(6, 34) for _ in range(4)]; wd = rnd.uniform(0.8, 7)
        m = mask(W, H); assert L.shim_line_mask(round(x0 * 256), round(y0 * 256), round(x1 * 256), round(y1 * 256), round(wd * 256), rc, W, H, m) == 0
        worst = max(worst, np.abs(np_mask(m, W, H) - line_ref(x0, y0, x1, y1, wd, rc, W, H)).max())
check(worst <= 16, f"30 random stroked lines (round and butt caps) vs analytic: max error {worst}/255 (limit 16; round-cap disc is a 16/32-gon)")
# 6b. polylines with joins and closed rings vs shapely buffer (exact offset geometry)
def turn_deg(pts, i):
    a, b, c = pts[i - 1], pts[i], pts[(i + 1) % len(pts)]; v1 = (b[0] - a[0], b[1] - a[1]); v2 = (c[0] - b[0], c[1] - b[1])
    return abs(math.degrees(math.atan2(v1[0] * v2[1] - v1[1] * v2[0], v1[0] * v2[0] + v1[1] * v2[1])))
def poly_stroke(pts, closed, wd, rc, W, H):
    q = [(round(a * 256), round(b * 256)) for a, b in pts]; m = mask(W, H)
    rcode = L.shim_stroke_poly(arr([a for a, _ in q]), arr([b for _, b in q]), len(q), 1 if closed else 0, round(wd * 256), rc, W, H, m); return rcode, np_mask(m, W, H)
worst = 0; nb = 0
for _ in range(600):
    if nb >= 12: break
    n = rnd.randint(3, 6); pts = [(rnd.uniform(6, 34), rnd.uniform(6, 34)) for _ in range(n)]; wd = rnd.uniform(1.0, 5.0)
    g = LineString(pts)
    if not g.is_simple: continue                       # self-crossing polylines overlap themselves; shapely buffer is the union, our outline is non-zero of overlapping loops
    if min(math.dist(pts[i], pts[i + 1]) for i in range(n - 1)) < wd * 1.2: continue    # segments shorter than the stroke are a documented approximation
    if any(turn_deg(pts, i) > 120 for i in range(1, n - 1)): continue                    # hairpins (> 120 deg) overlap themselves: documented approximation
    rcode, got = poly_stroke(pts, False, wd, 1, 40, 40); nb += 1
    worst = max(worst, np.abs(got - ref_geom(g.buffer(wd / 2, cap_style=1, join_style=1, quad_segs=64), 40, 40)).max() if rcode == 0 else 255)
check(nb >= 10 and worst <= 14, f"{nb} random simple polylines, round joins+caps vs exact offset curve: max error {worst}/255 (limit 14)")
worst = 0; nb = 0
for _ in range(1500):
    if nb >= 40: break
    cx, cy = rnd.uniform(16, 24), rnd.uniform(16, 24); n = rnd.randint(3, 7); angs = sorted(rnd.uniform(0, 2 * math.pi) for _ in range(n))
    pts = [(cx + rnd.uniform(5, 11) * math.cos(a), cy + rnd.uniform(5, 11) * math.sin(a)) for a in angs]; wd = rnd.uniform(1.0, 3.5)
    if not Polygon(pts).is_valid: continue
    ring = LineString(pts + [pts[0]]); segs = [math.dist(pts[i], pts[(i + 1) % n]) for i in range(n)]
    if min(segs) < wd * 1.5: continue
    if any(turn_deg(pts, i) > 120 for i in range(n)) or Polygon(pts).buffer(-wd * 0.8).is_empty: continue   # interior must be wider than the stroke
    rcode, got = poly_stroke(pts, True, wd, 1, 40, 40); nb += 1
    worst = max(worst, np.abs(got - ref_geom(Polygon(pts).exterior.buffer(wd / 2, join_style=1, quad_segs=64), 40, 40)).max() if rcode == 0 else 255)
check(nb >= 30 and worst <= 14, f"{nb} random closed outlines (hollow ring, round joins) vs exact: max error {worst}/255 (limit 14)")
ok_h = True
for _ in range(300):                                   # hostile stroker fuzz: extreme coordinates, widths, counts
    n = rnd.choice([1, 2, 3, 50, 200]); big = rnd.choice([100, 5000, 2 ** 30]); pts = [(rnd.randint(-big, big), rnd.randint(-big, big)) for _ in range(n)]
    wd = rnd.choice([1, 100, 256 * 3, 2 ** 20, 2 ** 31 - 1]); rcode = L.shim_stroke_poly(arr([a for a, _ in pts]), arr([b for _, b in pts]), n, rnd.randint(0, 1), wd, rnd.randint(0, 1), 64, 64, mask(64, 64))
    ok_h &= rcode in (0, -1)
check(ok_h, "300 hostile stroke requests (coordinates up to 2^30, widths up to 2^31, up to 200 points): refused or drawn, never crash / UB")
# 6c. the shapes the UI actually strokes: rounded-rectangle and circle outlines vs exact offset geometry
worst = 0
for _ in range(20):
    W = H = 56; x, y = rnd.uniform(4, 10), rnd.uniform(4, 10); rw, rh = rnd.uniform(16, 40), rnd.uniform(16, 40); r = rnd.uniform(2, min(rw, rh) / 2 - 1); wd = rnd.uniform(1, 4)
    m = mask(W, H); assert L.shim_rrect_stroke_mask(round(x * 256), round(y * 256), round(rw * 256), round(rh * 256), round(r * 256), round(wd * 256), W, H, m) == 0
    shape = box(x + r, y + r, x + rw - r, y + rh - r).buffer(r, quad_segs=64); worst = max(worst, np.abs(np_mask(m, W, H) - ref_geom(shape.exterior.buffer(wd / 2, join_style=1, quad_segs=64), W, H)).max())
check(worst <= 14, f"20 random rounded-rectangle outlines (width 1-4 px) vs exact: max error {worst}/255 (limit 14)")
worst = 0
for _ in range(20):
    W = H = 48; cx, cy = rnd.uniform(18, 30), rnd.uniform(18, 30); rx, ry = rnd.uniform(5, 15), rnd.uniform(5, 15); wd = rnd.uniform(1, 4)
    m = mask(W, H); assert L.shim_ellipse_stroke_mask(round(cx * 256), round(cy * 256), round(rx * 256), round(ry * 256), round(wd * 256), W, H, m) == 0
    ring = LineString([(cx + rx * math.cos(t), cy + ry * math.sin(t)) for t in np.linspace(0, 2 * math.pi, 721)])
    worst = max(worst, np.abs(np_mask(m, W, H) - ref_geom(ring.buffer(wd / 2, quad_segs=64), W, H)).max())
check(worst <= 14, f"20 random ellipse outlines (width 1-4 px) vs exact: max error {worst}/255 (limit 14)")
# 7. cubic flatness: a symmetric cubic bulge matches the analytic curve area
c = [4 * 256, 20 * 256, 4 * 256, 2 * 256, 28 * 256, 2 * 256, 28 * 256, 20 * 256]; m = mask(32, 24); L.shim_cubic_mask(arr(c), 32, 24, m)
t = np.linspace(0, 1, 20001); P = np.array([(4, 20), (4, 2), (28, 2), (28, 20)], float); B = ((1 - t)[:, None] ** 3 * P[0] + 3 * ((1 - t) ** 2 * t)[:, None] * P[1] + 3 * ((1 - t) * t * t)[:, None] * P[2] + (t ** 3)[:, None] * P[3])
exact = Polygon([tuple(p) for p in B]).area
check(abs(np_mask(m, 32, 24).sum() / 255 - exact) / exact < 0.004, f"cubic flattening: rasterised area {np_mask(m, 32, 24).sum() / 255:.2f} vs analytic {exact:.2f} (< 0.4% error)")
# 8. framebuffer: clipping, alpha, and no write outside the framebuffer/clip (guard margin must stay untouched)
FW, FH, MG = 24, 16, 8; fbuf = (C.c_uint32 * ((FW + 2 * MG) * (FH + 2 * MG)))(*([0xDEADBEEF] * ((FW + 2 * MG) * (FH + 2 * MG))))
for yy in range(FH):
    for xx in range(FW): fbuf[(yy + MG) * (FW + 2 * MG) + xx + MG] = 0x102030
big = [(-50 * 256, -50 * 256), (80 * 256, -50 * 256), (80 * 256, 60 * 256), (-50 * 256, 60 * 256)]
L.shim_fill_fb.argtypes = [C.POINTER(C.c_uint32), C.c_int, C.c_int, C.c_int, i32p, i32p, C.c_int, C.c_int, i32p, C.c_int, C.c_int, C.c_int, C.c_int]
rc = L.shim_fill_fb(fbuf, FW, FH, MG, arr([a for a, _ in big]), arr([b for _, b in big]), 4, 1, arr([4, 3, 20, 12]), 200, 100, 50, 255)
inside = all((fbuf[(yy + MG) * (FW + 2 * MG) + xx + MG] == (0xC86432 if (4 <= xx < 20 and 3 <= yy < 12) else 0x102030)) for yy in range(FH) for xx in range(FW))
guard = all(fbuf[i] == 0xDEADBEEF for i in range((FW + 2 * MG) * (FH + 2 * MG)) if not (MG <= i % (FW + 2 * MG) < MG + FW and MG <= i // (FW + 2 * MG) < MG + FH))
check(rc == 0 and inside and guard, "huge shape + clip rect: exactly the clip rectangle is painted; nothing outside the clip or framebuffer is touched")
half = [(0, 0), (10 * 256, 0), (10 * 256, 8 * 256), (0, 8 * 256)]
for yy in range(FH):
    for xx in range(FW): fbuf[(yy + MG) * (FW + 2 * MG) + xx + MG] = 0x000000
L.shim_fill_fb(fbuf, FW, FH, MG, arr([a for a, _ in half]), arr([b for _, b in half]), 4, 0, arr([0, 0, 0, 0]), 255, 255, 255, 128)
v = fbuf[(2 + MG) * (FW + 2 * MG) + 3 + MG] & 255
check(abs(v - 128) <= 1, f"50% alpha white over black gives {v} (expected 128)")
# 9. hostile input
okh = True
w9 = mask(64, 64)
for coords in ([(0, 0), (2 ** 31 - 1, 0), (2 ** 31 - 1, 2 ** 31 - 1)], [(-2 ** 31, -2 ** 31), (2 ** 31 - 1, -2 ** 31), (0, 2 ** 31 - 1)], [(5, 5)] * 6, [(0, 0), (0, 0), (256, 0)], [(0, 0), (256 * 3000, 0), (256 * 3000, 256), (0, 256)]):
    r = L.shim_poly_mask(arr([a for a, _ in coords]), arr([b for _, b in coords]), len(coords), 64, 64, 0, w9); okh &= r in (0, -1)
check(okh, "overflow-bait / degenerate / zero-area / over-wide shapes: refused or drawn safely, no crash, no UB")
r = L.shim_poly_mask(arr([0, 256 * 3000, 256 * 3000, 0]), arr([0, 0, 256, 256]), 4, 64, 64, 0, w9)
check(r == -1, "a 3000-px-wide shape is refused (-1) because it exceeds VEC_MAX_W; callers fall back to the aliased fill")
mp = mask(256, 256); check(L.shim_many_points(5000, 256, 256, mp) == -1, "5000-vertex path: capacity limit hit, fill refused (-1), no overflow")
check(L.shim_many_subpaths(500, 128, 128, mask(128, 128)) == -1, "500 subpaths: capacity limit hit, fill refused (-1)")
# 10. determinism
m1, m2 = mask(28, 28), mask(28, 28); pts2 = [(3 * 256 + 17, 4 * 256), (20 * 256, 5 * 256 + 3), (12 * 256, 22 * 256)]
for mm_ in (m1, m2): L.shim_poly_mask(arr([a for a, _ in pts2]), arr([b for _, b in pts2]), 3, 28, 28, 0, mm_)
check(bytes(m1) == bytes(m2), "rasterisation is deterministic (identical bytes on repeat)")
print(f"\n{sum(R)}/{len(R)} vector-rasteriser host checks passed [{kind}]"); sys.exit(0 if all(R) else 1)
