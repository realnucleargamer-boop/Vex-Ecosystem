/*
 * vecfont.c - GFX-VEC-01 vector font renderer (see kernel/include/gfx/vecfont.h). Pure integer, no heap, no libc.
 */
#include "gfx/vecfont.h"
#include "vecfont_data.h"

#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC optimize ("O2", "no-tree-loop-distribute-patterns")
#endif

/* 8 px advance: size = 8 * 2048 / 1233 = 13.288 px.  Baseline row and vertical scale were tuned against rendered samples
 * (tests/vecfont_render.py): the x-height is snapped to a whole number of pixels so horizontal strokes stay crisp. */
#ifndef VF_CELL_YSCALE_Q8
#define VF_CELL_YSCALE_Q8 256
#endif
#ifndef VF_BOOST
#define VF_BOOST          96          /* 0..256: how much mid-coverage is lifted (light text on dark looks thin otherwise) */
#endif

static uint8_t g_cell[VF_COUNT][VF_CELL_W * VF_CELL_H];
static int g_ready;

int vf_has_glyph(int ch) { return ch >= VF_FIRST && ch < VF_FIRST + VF_COUNT; }

static int64_t rdiv(int64_t n, int64_t d) { return n >= 0 ? (n + d / 2) / d : -((-n + d / 2) / d); }

static void glyph_path(VecPath *p, int ch, vfx size, vfx ysc, vfx x, vfx baseline)
{
    if (!vf_has_glyph(ch)) return;
    const int16_t *d = vf_data + vf_off[ch - VF_FIRST];
    int64_t sx = size, sy = (int64_t)size * ysc / 256;
#define PX(v) ((vfx)(x + rdiv((int64_t)(v) * sx, VF_UPM)))
#define PY(v) ((vfx)(baseline - rdiv((int64_t)(v) * sy, VF_UPM)))
    for (;;) {
        int op = *d++;
        if (op == 0)      { vec_move_to(p, PX(d[0]), PY(d[1])); d += 2; }
        else if (op == 1) { vec_line_to(p, PX(d[0]), PY(d[1])); d += 2; }
        else if (op == 2) { vec_quad_to(p, PX(d[0]), PY(d[1]), PX(d[2]), PY(d[3])); d += 4; }
        else if (op == 3) { vec_close(p); }
        else break;
    }
#undef PX
#undef PY
}

void vf_glyph_path(VecPath *p, int ch, vfx size, vfx x, vfx baseline) { glyph_path(p, ch, size, 256, x, baseline); }

static uint8_t boost(int c)
{
    int lifted = 255 - ((255 - c) * (255 - c)) / 255;           /* concave curve: 128 -> 192 */
    return (uint8_t)((c * (256 - VF_BOOST) + lifted * VF_BOOST + 128) >> 8);
}

int vf_cache_init(void)
{
    if (g_ready) return VF_COUNT;
    VecPath *p = vec_scratch();
    for (int i = 0; i < VF_COUNT; i++) {
        vec_path_begin(p);
        glyph_path(p, VF_FIRST + i, VF_CELL_SIZE_Q8, VF_CELL_YSCALE_Q8, 0, VF_CELL_BASE_Q8);
        if (vec_mask(p, 0, VF_CELL_W, VF_CELL_H, g_cell[i]) != 0)
            for (int k = 0; k < VF_CELL_W * VF_CELL_H; k++) g_cell[i][k] = 0;
        for (int k = 0; k < VF_CELL_W * VF_CELL_H; k++) g_cell[i][k] = boost(g_cell[i][k]);
    }
    g_ready = 1;
    return VF_COUNT;
}

const uint8_t *vf_cell_coverage(int ch)
{
    if (!vf_has_glyph(ch)) return 0;
    vf_cache_init();
    return g_cell[ch - VF_FIRST];
}

static inline int div255(int v) { v += 128; return (v + (v >> 8)) >> 8; }

int vf_draw_cell(const GfxFb *fb, int px, int py, int ch, GfxColor fg, GfxColor bg)
{
    if (!fb || !fb->ok || !fb->pixels || !vf_has_glyph(ch)) return 0;
    if (px < 0 || py < 0 || (int64_t)px + VF_CELL_W > (int64_t)fb->width || (int64_t)py + VF_CELL_H > (int64_t)fb->height) return 0;   /* whole cell must be on screen */
    vf_cache_init();
    const uint8_t *cov = g_cell[ch - VF_FIRST];
    for (int y = 0; y < VF_CELL_H; y++) {
        volatile uint32_t *row = fb->pixels + (size_t)(py + y) * fb->pitch_px + px;
        for (int x = 0; x < VF_CELL_W; x++) {
            int a = cov[y * VF_CELL_W + x];
            int r = div255(fg.r * a + bg.r * (255 - a)), g = div255(fg.g * a + bg.g * (255 - a)), b = div255(fg.b * a + bg.b * (255 - a));
            row[x] = ((uint32_t)r << fb->r_shift) | ((uint32_t)g << fb->g_shift) | ((uint32_t)b << fb->b_shift);
        }
    }
    return 1;
}

void vf_blend_cell(const GfxFb *fb, int px, int py, int ch, GfxColor col, uint8_t alpha)
{
    if (!fb || !fb->ok || !fb->pixels || !vf_has_glyph(ch) || ch == ' ') return;
    vf_cache_init();
    const uint8_t *cov = g_cell[ch - VF_FIRST];
    for (int y = 0; y < VF_CELL_H; y++) {
        int64_t gy = (int64_t)py + y; if (gy < 0 || gy >= (int64_t)fb->height) continue;
        volatile uint32_t *row = fb->pixels + (size_t)gy * fb->pitch_px;
        for (int x = 0; x < VF_CELL_W; x++) {
            int64_t gx = (int64_t)px + x; if (gx < 0 || gx >= (int64_t)fb->width) continue;
            int a = cov[y * VF_CELL_W + x]; if (!a) continue;
            if (alpha != 255) a = div255(a * alpha);
            if (a >= 255) { row[gx] = gfx_encode(fb, col); continue; }
            uint32_t d = row[gx];
            int dr = (d >> fb->r_shift) & 255, dg = (d >> fb->g_shift) & 255, db = (d >> fb->b_shift) & 255;
            dr = div255(col.r * a + dr * (255 - a)); dg = div255(col.g * a + dg * (255 - a)); db = div255(col.b * a + db * (255 - a));
            row[gx] = ((uint32_t)dr << fb->r_shift) | ((uint32_t)dg << fb->g_shift) | ((uint32_t)db << fb->b_shift);
        }
    }
}

vfx vf_text_width(const char *s, vfx size)
{
    int64_t n = 0; while (s && s[n]) n++;
    return (vfx)(n * VF_ADVANCE * (int64_t)size / VF_UPM);
}

vfx vf_draw_text(const GfxFb *fb, vfx x, vfx baseline, vfx size, const char *s, const VecPaint *paint, const VecClip *clip)
{
    if (!s) return 0;
    int64_t pen = 0, adv = (int64_t)VF_ADVANCE * size;
    for (int i = 0; s[i]; i++) {
        if (vf_has_glyph((unsigned char)s[i]) && s[i] != ' ') {
            VecPath *p = vec_scratch(); vec_path_begin(p);
            glyph_path(p, (unsigned char)s[i], size, 256, (vfx)(x + pen / VF_UPM), baseline);
            vec_fill(fb, p, 0, paint, clip);
        }
        pen += adv;
        if (i > 4096) break;                                     /* bounded */
    }
    return (vfx)(pen / VF_UPM);
}
