/* Vex OS - kernel/src/ui/wallpaper_core.c - see include/wallpaper_core.h */
#include "wallpaper_core.h"

const char *wp_status_text(WpStatus s)
{
    switch (s) {
    case WP_OK:        return "ok";
    case WP_E_NULL:    return "no image data";
    case WP_E_TRUNCATED: return "image data is truncated";
    case WP_E_MAGIC:   return "not a supported wallpaper file";
    case WP_E_FORMAT:  return "unsupported image format";
    case WP_E_DIMS:    return "unsupported image dimensions";
    case WP_E_SIZE:    return "image size does not match its header";
    case WP_E_CRC:     return "image data is corrupt (checksum mismatch)";
    case WP_E_MISSING: return "wallpaper file is missing";
    case WP_E_NOMEM:   return "not enough free memory for the wallpaper cache";
    case WP_E_SCREEN:  return "this screen size is not supported for wallpapers";
    case WP_E_RANGE:   return "invalid geometry";
    }
    return "unknown error";
}

uint32_t wp_crc32(const uint8_t *p, uint32_t n)
{
    static const uint32_t T[16] = { 0x00000000u, 0x1DB71064u, 0x3B6E20C8u, 0x26D930ACu, 0x76DC4190u, 0x6B6B51F4u, 0x4DB26158u, 0x5005713Cu,
                                    0xEDB88320u, 0xF00F9344u, 0xD6D6A3E8u, 0xCB61B38Cu, 0x9B64C2B0u, 0x86D3D2D4u, 0xA00AE278u, 0xBDBDF21Cu };
    uint32_t c = 0xFFFFFFFFu;
    if (!p) return 0;
    for (uint32_t i = 0; i < n; i++) { c ^= p[i]; c = (c >> 4) ^ T[c & 15u]; c = (c >> 4) ^ T[c & 15u]; }
    return ~c;
}

static uint32_t rd16(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8); }
static uint32_t rd32(const uint8_t *p) { return rd16(p) | (rd16(p + 2) << 16); }

WpStatus wp_parse(const uint8_t *blob, uint32_t len, WpImage *out)
{
    if (!blob || !out || len == 0) return WP_E_NULL;
    if (len < WP_HEADER_BYTES) return WP_E_TRUNCATED;
    if (blob[0] != 'V' || blob[1] != 'W' || blob[2] != 'P' || blob[3] != '1') return WP_E_MAGIC;
    uint32_t w = rd16(blob + 4), h = rd16(blob + 6);
    if (blob[8] != WP_FMT_RGB565 || blob[9] != 0 || rd16(blob + 10) != 0) return WP_E_FORMAT;
    if (w < WP_MIN_DIM || w > WP_MAX_DIM || h < WP_MIN_DIM || h > WP_MAX_DIM) return WP_E_DIMS;
    uint64_t want = (uint64_t)w * h * 2u;                          /* <= 512*512*2: cannot overflow 64 bits */
    if ((uint64_t)rd32(blob + 12) != want) return WP_E_SIZE;
    if ((uint64_t)len < (uint64_t)WP_HEADER_BYTES + want) return WP_E_TRUNCATED;
    if ((uint64_t)len > (uint64_t)WP_HEADER_BYTES + want) return WP_E_SIZE;
    out->w = (uint16_t)w; out->h = (uint16_t)h; out->px = blob + WP_HEADER_BYTES;
    return WP_OK;
}

WpStatus wp_verify(const uint8_t *blob, uint32_t len, WpImage *out)
{
    WpImage tmp;
    WpStatus s = wp_parse(blob, len, &tmp);
    if (s != WP_OK) return s;
    if (wp_crc32(tmp.px, (uint32_t)tmp.w * tmp.h * 2u) != rd32(blob + 16)) return WP_E_CRC;
    if (out) *out = tmp;
    return WP_OK;
}

WpStatus wp_cover(uint32_t src_w, uint32_t src_h, uint32_t vw, uint32_t vh, WpCover *out)
{
    if (!out || src_w == 0 || src_h == 0 || vw == 0 || vh == 0 || vw > 8192u || vh > 8192u || src_w > WP_MAX_DIM || src_h > WP_MAX_DIM) return WP_E_RANGE;
    uint32_t sw, sh;
    if ((uint64_t)vw * src_h >= (uint64_t)vh * src_w) {            /* surface is relatively wider: match widths, crop top/bottom */
        sw = vw; sh = (uint32_t)(((uint64_t)src_h * vw + src_w - 1) / src_w); if (sh < vh) sh = vh;
    } else {                                                       /* surface is relatively taller: match heights, crop sides */
        sh = vh; sw = (uint32_t)(((uint64_t)src_w * vh + src_h - 1) / src_h); if (sw < vw) sw = vw;
    }
    out->vw = vw; out->vh = vh; out->sw = sw; out->sh = sh; out->cx = (sw - vw) / 2; out->cy = (sh - vh) / 2;
    return WP_OK;
}

static inline void px565(uint32_t v, int32_t *r, int32_t *g, int32_t *b)
{
    uint32_t rr = (v >> 11) & 31u, gg = (v >> 5) & 63u, bb = v & 31u;
    *r = (int32_t)((rr << 3) | (rr >> 2)); *g = (int32_t)((gg << 2) | (gg >> 4)); *b = (int32_t)((bb << 3) | (bb >> 2));
}

WpStatus wp_render_row(const WpImage *img, const WpCover *cv, uint32_t y, uint32_t x0, uint32_t n,
                       uint32_t *out, uint8_t rs, uint8_t gs, uint8_t bs)
{
    if (!img || !cv || !out || !img->px) return WP_E_NULL;
    if (img->w == 0 || img->h == 0 || cv->sw == 0 || cv->sh == 0) return WP_E_RANGE;
    if (y >= cv->vh || x0 > cv->vw || n > cv->vw - x0) return WP_E_RANGE;
    if (n == 0) return WP_OK;
    const uint32_t sw_img = img->w, sh_img = img->h;
    const int64_t maxx = (int64_t)(sw_img - 1) << 16, maxy = (int64_t)(sh_img - 1) << 16;
    /* pixel-centre mapping: src = (d + 0.5) * src_size / scaled_size - 0.5, in 16.16 */
    int64_t fy = (int64_t)((((uint64_t)(2u * (uint64_t)(y + cv->cy) + 1u)) * sh_img << 16) / (2u * (uint64_t)cv->sh)) - 0x8000;
    if (fy < 0) fy = 0;
    if (fy > maxy) fy = maxy;
    uint32_t iy = (uint32_t)(fy >> 16), iy1 = iy + 1 < sh_img ? iy + 1 : iy; int32_t wy = (int32_t)((fy >> 8) & 0xFF);
    const uint8_t *r0 = img->px + (size_t)iy * sw_img * 2, *r1 = img->px + (size_t)iy1 * sw_img * 2;
    int64_t fx = (int64_t)((((uint64_t)(2u * (uint64_t)(x0 + cv->cx) + 1u)) * sw_img << 16) / (2u * (uint64_t)cv->sw)) - 0x8000;
    const int64_t step = (int64_t)(((uint64_t)sw_img << 16) / cv->sw);
    for (uint32_t i = 0; i < n; i++, fx += step) {
        int64_t cx = fx < 0 ? 0 : (fx > maxx ? maxx : fx);
        uint32_t ix = (uint32_t)(cx >> 16), ix1 = ix + 1 < sw_img ? ix + 1 : ix; int32_t wx = (int32_t)((cx >> 8) & 0xFF);
        int32_t a[3], b[3], c[3], d[3];
        px565(rd16(r0 + ix * 2), &a[0], &a[1], &a[2]); px565(rd16(r0 + ix1 * 2), &b[0], &b[1], &b[2]);
        px565(rd16(r1 + ix * 2), &c[0], &c[1], &c[2]); px565(rd16(r1 + ix1 * 2), &d[0], &d[1], &d[2]);
        uint32_t o[3];
        for (int k = 0; k < 3; k++) {
            int32_t top = a[k] + (((b[k] - a[k]) * wx) >> 8), bot = c[k] + (((d[k] - c[k]) * wx) >> 8);
            int32_t v = top + (((bot - top) * wy) >> 8); o[k] = (uint32_t)(v < 0 ? 0 : v > 255 ? 255 : v);
        }
        out[i] = (o[0] << rs) | (o[1] << gs) | (o[2] << bs);
    }
    return WP_OK;
}

uint32_t wp_mean_luma(const uint32_t *px, uint32_t pitch_px, uint32_t w, uint32_t h, uint8_t rs, uint8_t gs, uint8_t bs)
{
    if (!px || !w || !h) return 0;
    uint64_t sum = 0, cnt = 0;
    for (uint32_t y = 0; y < h; y += 2) for (uint32_t x = 0; x < w; x += 2) {
        uint32_t v = px[(size_t)y * pitch_px + x];
        sum += (77u * ((v >> rs) & 255u) + 150u * ((v >> gs) & 255u) + 29u * ((v >> bs) & 255u)) >> 8; cnt++;
    }
    return cnt ? (uint32_t)(sum / cnt) : 0;
}
