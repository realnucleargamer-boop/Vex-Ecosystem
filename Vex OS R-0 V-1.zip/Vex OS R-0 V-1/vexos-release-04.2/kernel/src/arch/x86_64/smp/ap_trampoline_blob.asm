; Vex OS - kernel/src/arch/x86_64/smp/ap_trampoline_blob.asm
;
; BOOT-02C: embeds the separately-assembled AP trampoline flat binary
; into the kernel image as opaque data, and exposes its address and
; length to C.
;
; The trampoline cannot be linked with the kernel (see the long comment
; in ap_trampoline.asm: it runs from a low physical page in real mode,
; not from the kernel's link address). `incbin` keeps the two completely
; decoupled - the linker only ever sees a byte array, so there is no
; opportunity for it to apply a relocation to trampoline code.
;
; The blob is placed in .rodata and page-aligned. Alignment is not
; strictly required, since the BSP copies the bytes to a 4 KiB-aligned
; low page anyway, but it makes the copy trivially inspectable in a
; debugger and costs nothing.

BITS 64

section .rodata
align 4096

global ap_trampoline_blob_start
global ap_trampoline_blob_end

ap_trampoline_blob_start:
    incbin "build/ap_trampoline.bin"
ap_trampoline_blob_end:

section .note.GNU-stack noalloc noexec nowrite progbits
