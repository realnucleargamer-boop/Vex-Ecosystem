#!/usr/bin/env python3
"""VexScript 2.0 Phase B — Vex IR 0.1"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vexscript.compile_ir import compile_to_ir, emit_ir_text, run_via_ir
from vexscript.ir.validate import validate_module
from vexscript.ir.nodes import ModuleIR, FunctionIR, Block, Instruction, Value
from vexscript.errors import VexError

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

print("VexScript 2.0 Phase B — Vex IR 0.1")

print("\n=== IR generation + interpreter ===")
code, out = run_via_ir("""
fn main() -> i32 {
    let x: i64 = 7;
    println(x + 3);
    return 0;
}
""")
check("arith+print", code == 0 and out == "10\n", f"{code!r} {out!r}")

code, out = run_via_ir("""
fn add(a: i64, b: i64) -> i64 { return a + b; }
fn main() -> i32 {
    println(add(5, 6));
    return 0;
}
""")
check("call", code == 0 and out == "11\n", f"{out!r}")

code, out = run_via_ir("""
fn main() -> i32 {
    let x: i64 = 1;
    if (x < 2) {
        println(42);
    } else {
        println(0);
    }
    return 0;
}
""")
check("if", code == 0 and "42" in out, f"{out!r}")

code, out = run_via_ir("""
fn main() -> i32 {
    let mut i: i64 = 0;
    while (i < 3) {
        i = i + 1;
    }
    println(i);
    return 0;
}
""")
check("while", code == 0 and out == "3\n", f"{out!r}")

print("\n=== Determinism ===")
src = "fn main() -> i32 { return 1 + 2; }\n"
a = emit_ir_text(src)
b = emit_ir_text(src)
check("same IR twice", a == b)

print("\n=== Validation rejects ===")
def bad_mod():
    b = Block(name="entry", instructions=[], terminator=None)
    return ModuleIR(functions=[FunctionIR("main", [], "i32", [b])])

try:
    validate_module(bad_mod())
    check("missing terminator", False)
except VexError as e:
    check("missing terminator", "E0302" in str(e), str(e))

def undef_ssa():
    inst = Instruction("%v0", "add", "i64", [Value("ssa", "%missing", "i64"), Value("ssa", "%missing", "i64")])
    term = Instruction(None, "ret", "i64", [Value("ssa", "%v0", "i64")])
    b = Block(name="entry", instructions=[inst], terminator=term)
    return ModuleIR(functions=[FunctionIR("main", [], "i64", [b])])
try:
    validate_module(undef_ssa())
    check("undefined SSA", False)
except VexError as e:
    check("undefined SSA", "E0307" in str(e), str(e))

print("\n=== Modules via IR ===")
ex = ROOT / "examples"
try:
    code, out = run_via_ir(
        (ex / "use_math.vex").read_text(),
        str(ex / "use_math.vex"),
    )
    check("module IR run", code == 0 and "25" in out and "30" in out, f"{out!r}")
except Exception as e:
    check("module IR run", False, str(e))

print(f"\n=== Phase B Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
