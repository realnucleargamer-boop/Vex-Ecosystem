
#include <stddef.h>

void *memset(void *dest, int value, size_t count)
{
    volatile unsigned char *p = (volatile unsigned char *)dest;

    while (count > 0) {
        *p++ = (unsigned char)value;
        --count;
    }

    return dest;
}
