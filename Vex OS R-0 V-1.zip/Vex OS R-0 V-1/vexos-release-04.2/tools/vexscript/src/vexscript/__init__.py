"""VexScript 3.2.3 — VEX AI readiness expansion (genome/streams/fitness)."""

__version__ = "3.2.3"
__release_name__ = "3.2"
__codename__ = "Readiness-Expansion"
__ir_version__ = "1.5"

FEATURES = {
    "strings": True,
    "arrays": True,
    "structs": True,
    "modules": True,
    "vex_ir_version": "1.5",
    "tensor_types": True,
    "tensor_ops": True,
    "neural_layers": True,
    "evolution": True,
    "checkpoint": True,
    "rng_seed": True,
    "genome_buffers": True,
    "streams": True,
    "batch_fitness": True,
    "migration": True,
    "diversity": True,
    "string_genomes_native": True,
    "text_fitness": True,
}
