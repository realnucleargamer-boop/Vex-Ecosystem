# VexScript Memory Model (2+ Phase C)

## Principles
- No garbage collector
- No hidden allocations in the language core
- Pointer types exist as **annotations**: `*T`, `*mut T`
- `unsafe` remains a marker for future checked operations; it does **not** grant kernel privileges

## Pointer types (Phase C)
```vex
let p: *i64 = ...;      // not fully operational in interpreter yet
let q: *mut i64 = ...;
```
Native/x86 backend does not yet lower general pointer arithmetic.

## Ownership
- Values are copied by default (integers, enums, small structs)
- Strings are provisional C-string pointers in native mode
- Hosted `vex::fs` uses an in-memory VFS only

## Allocation
- Fixed stack slots in native codegen
- No general `malloc` in the language
- Future: explicit `std::mem` APIs bound to a real allocator when Vex OS provides one
