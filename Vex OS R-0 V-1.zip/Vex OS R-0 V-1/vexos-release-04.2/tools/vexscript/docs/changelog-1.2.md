# VEX-Script Changelog — 1.2

## Added
- Operational structs (define, construct, field access, field mutation, nested)
- Multi-file modules with cycle detection and missing-module errors
- Stdlib: abs, min, max, str_contains
- Expanded test suite (structs, modules, negatives, compatibility)

## Compatibility
- All 1.0 surface programs and 1.1 examples remain valid
- No intentional breaking changes to existing syntax

## Implementation notes
- Still a reference interpreter (not a compiler)
- Struct instances are mutable dictionaries under a type tag
- Field mutation checks mutability of the binding (simple Name base)
