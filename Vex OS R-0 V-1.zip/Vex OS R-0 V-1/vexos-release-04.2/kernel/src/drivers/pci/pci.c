/* Vex OS - kernel/src/drivers/pci/pci.c : STORAGE-01 PCI enumeration. See include/pci.h. */
#include "pci.h"
#include "serial.h"

static PciDev devs[PCI_MAX_DEVICES]; static int ndev; static int scanned;
static inline void outl_(uint16_t p, uint32_t v) { __asm__ volatile("outl %0,%1" :: "a"(v), "Nd"(p)); }
static inline uint32_t inl_(uint16_t p) { uint32_t v; __asm__ volatile("inl %1,%0" : "=a"(v) : "Nd"(p)); return v; }
static uint32_t rd(uint8_t b, uint8_t s, uint8_t f, uint8_t off) { outl_(0xCF8, 0x80000000u | ((uint32_t)b << 16) | ((uint32_t)s << 11) | ((uint32_t)f << 8) | (off & 0xFCu)); return inl_(0xCFC); }
static void wr(uint8_t b, uint8_t s, uint8_t f, uint8_t off, uint32_t v) { outl_(0xCF8, 0x80000000u | ((uint32_t)b << 16) | ((uint32_t)s << 11) | ((uint32_t)f << 8) | (off & 0xFCu)); outl_(0xCFC, v); }

int pci_scan(void)
{
    if (scanned) return ndev;
    scanned = 1; ndev = 0;
    uint32_t h = rd(0, 0, 0, 0);
    if (h == 0xFFFFFFFFu || (h & 0xFFFFu) == 0xFFFFu) { serial_puts("[pci] config space not reachable\n"); return 0; }
    for (uint32_t bus = 0; bus < 256; bus++)
        for (uint32_t slot = 0; slot < 32; slot++) {
            if ((rd((uint8_t)bus, (uint8_t)slot, 0, 0) & 0xFFFFu) == 0xFFFFu) continue;
            uint32_t nf = (rd((uint8_t)bus, (uint8_t)slot, 0, 0x0C) & 0x00800000u) ? 8u : 1u;
            for (uint32_t fn = 0; fn < nf; fn++) {
                uint32_t id = rd((uint8_t)bus, (uint8_t)slot, (uint8_t)fn, 0);
                if ((id & 0xFFFFu) == 0xFFFFu) continue;
                if (ndev >= PCI_MAX_DEVICES) { serial_puts("[pci] device table full; further devices ignored\n"); return ndev; }
                PciDev *d = &devs[ndev++]; uint32_t cl = rd((uint8_t)bus, (uint8_t)slot, (uint8_t)fn, 0x08), hd = rd((uint8_t)bus, (uint8_t)slot, (uint8_t)fn, 0x0C);
                d->bus = (uint8_t)bus; d->slot = (uint8_t)slot; d->func = (uint8_t)fn; d->vendor = (uint16_t)id; d->device = (uint16_t)(id >> 16);
                d->cls = (uint8_t)(cl >> 24); d->sub = (uint8_t)(cl >> 16); d->prog = (uint8_t)(cl >> 8); d->hdr = (uint8_t)((hd >> 16) & 0x7F);
                for (int i = 0; i < 6; i++) d->bar[i] = (d->hdr == 0) ? rd(d->bus, d->slot, d->func, (uint8_t)(0x10 + 4 * i)) : 0;
            }
        }
    serial_puts("[pci] "); serial_put_dec64((uint64_t)ndev); serial_puts(" device(s)\n");
    for (int i = 0; i < ndev; i++) {
        const PciDev *d = &devs[i];
        serial_puts("[pci]  "); serial_put_hex64(d->bus); serial_puts(":"); serial_put_hex64(d->slot); serial_puts("."); serial_put_hex64(d->func);
        serial_puts(" "); serial_put_hex64(d->vendor); serial_puts(":"); serial_put_hex64(d->device); serial_puts(" class "); serial_put_hex64(d->cls); serial_puts("/"); serial_put_hex64(d->sub); serial_puts(" ");
        serial_puts(pci_class_name(d->cls, d->sub)); serial_puts("\n");
    }
    return ndev;
}
int pci_count(void) { return ndev; }
const PciDev *pci_get(int i) { return (i >= 0 && i < ndev) ? &devs[i] : 0; }
const PciDev *pci_find_class(uint8_t c, uint8_t s, int p) { for (int i = 0; i < ndev; i++) if (devs[i].cls == c && devs[i].sub == s && (p == 0xFF || devs[i].prog == p)) return &devs[i]; return 0; }
uint32_t pci_read32(const PciDev *d, uint8_t off) { return rd(d->bus, d->slot, d->func, off); }
void pci_write32(const PciDev *d, uint8_t off, uint32_t v) { wr(d->bus, d->slot, d->func, off, v); }
void pci_enable_mem_dma(const PciDev *d) { uint32_t c = rd(d->bus, d->slot, d->func, 4); wr(d->bus, d->slot, d->func, 4, (c & 0xFFFFu) | 0x6u); }
uint64_t pci_bar_mem(const PciDev *d, int n)
{
    if (!d || n < 0 || n > 5 || d->hdr != 0) return 0;
    uint32_t b = d->bar[n]; if (b & 1u) return 0;                       /* I/O BAR */
    uint64_t base = b & ~0xFull;
    if (((b >> 1) & 3u) == 2u) { if (n >= 5) return 0; base |= (uint64_t)d->bar[n + 1] << 32; }   /* 64-bit BAR */
    return base;
}
const char *pci_class_name(uint8_t c, uint8_t s)
{
    switch (c) {
    case 0x00: return "unclassified"; case 0x01: return s == 0x06 ? "SATA controller (AHCI class)" : s == 0x08 ? "NVMe/non-volatile controller" : s == 0x01 ? "IDE controller" : "mass storage controller";
    case 0x02: return "network controller"; case 0x03: return "display controller"; case 0x04: return s == 0x03 ? "audio device" : "multimedia";
    case 0x06: return s == 0 ? "host bridge" : s == 1 ? "ISA bridge" : "bridge"; case 0x0C: return s == 0x03 ? "USB controller" : "serial bus controller";
    default: return "other";
    }
}
