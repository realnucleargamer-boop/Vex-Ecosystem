# QEMU-only UEFI USB-mass-storage boot validation for Release 04.
# It accepts only the project-local build image and never touches physical disks.
[CmdletBinding()] param([switch]$RefreshTools)
$ErrorActionPreference = "Stop"; $root = Split-Path -Parent $PSCommandPath; $image = Join-Path $root "build\vexos.img"
if (-not (Test-Path -LiteralPath $image)) { throw "Missing $image; build first." }
. (Join-Path $root "scripts\VexToolchain.ps1")
$tc = Resolve-VexToolchain -RepoRoot $root -Require @("qemu") -Refresh:$RefreshTools -Quiet
$code=$env:OVMF_CODE; $vars=$env:OVMF_VARS
if (-not $code -or -not $vars -or -not (Test-Path -LiteralPath $code) -or -not (Test-Path -LiteralPath $vars)) { throw "Set OVMF_CODE and OVMF_VARS to existing firmware files." }
$build=(Resolve-Path -LiteralPath (Join-Path $root "build")).Path; $resolved=(Resolve-Path -LiteralPath $image).Path
if (-not $resolved.StartsWith($build+"\")) { throw "Refusing non-project image: $resolved" }
$localVars=Join-Path $build "OVMF_VARS.usb.local.fd"; Copy-Item -LiteralPath $vars -Destination $localVars -Force
& $tc["qemu"] -machine q35,accel=tcg -m 512M -smp 4 -drive if=pflash,format=raw,readonly=on,file="$code" -drive if=pflash,format=raw,file="$localVars" -drive if=none,id=vexusb,format=vpc,readonly=on,file="$resolved" -device qemu-xhci -device usb-storage,drive=vexusb -serial stdio -no-reboot -no-shutdown
