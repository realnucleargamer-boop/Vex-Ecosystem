/*
 * Vex OS - kernel/src/security/secure.c
 *
 * SECURITY-01. See kernel/include/secure.h for scope, and in particular
 * for what this milestone does NOT claim: there is no Ring 3 in this
 * repository, so nothing here validates a pointer that came from user
 * mode. It builds and audits the primitives that boundary will require,
 * and hardens the invariants that are load-bearing today.
 */

#include "secure.h"
#include "vmm.h"
#include "idt.h"
#include "boot03_inject.h"

/* ------------------------------------------------------------------ *
 * Page-table shape, duplicated deliberately
 *
 * vmm.c keeps these private. Re-deriving them here rather than exporting
 * vmm.c's internals is intentional: this auditor must be able to
 * disagree with the mapper. If it shared the mapper's helpers, a bug in
 * those helpers would be invisible to the audit that exists to catch it.
 * ------------------------------------------------------------------ */

#define SEC_ADDR_MASK   0x000FFFFFFFFFF000ULL
#define SEC_ENTRIES     512
#define SEC_PML4_IDX(v) (((v) >> 39) & 0x1FF)

static uint64_t sec_read_cr4(void)
{
    uint64_t v;
    __asm__ volatile ("mov %%cr4, %0" : "=r"(v));
    return v;
}

static uint64_t sec_read_cr3(void)
{
    uint64_t v;
    __asm__ volatile ("mov %%cr3, %0" : "=r"(v));
    return v;
}

static uint64_t sec_read_msr(uint32_t msr)
{
    uint32_t lo, hi;
    __asm__ volatile ("rdmsr" : "=a"(lo), "=d"(hi) : "c"(msr));
    return ((uint64_t)hi << 32) | lo;
}

static void sec_cpuid(uint32_t leaf, uint32_t sub,
                      uint32_t *a, uint32_t *b, uint32_t *c, uint32_t *d)
{
    __asm__ volatile ("cpuid"
                      : "=a"(*a), "=b"(*b), "=c"(*c), "=d"(*d)
                      : "a"(leaf), "c"(sub));
}

/* ------------------------------------------------------------------ *
 * Canonical addresses and overflow
 * ------------------------------------------------------------------ */

int sec_is_canonical(uint64_t addr)
{
#if VEX_INJECTED(12)
    /* INJECTION 12: canonical-address checking removed. Every address is
     * declared canonical, so a range validator built on this happily
     * approves addresses the CPU will reject with #GP. */
    (void)addr;
    return 1;
#else
    return (addr <= SEC_CANONICAL_LOW_MAX) || (addr >= SEC_CANONICAL_HIGH_MIN);
#endif
}

int sec_add_ovf(uint64_t a, uint64_t b, uint64_t *out)
{
    if (b > UINT64_MAX - a) return 0;
    if (out) *out = a + b;
    return 1;
}

int sec_mul_ovf(uint64_t a, uint64_t b, uint64_t *out)
{
    if (a != 0 && b > UINT64_MAX / a) return 0;
    if (out) *out = a * b;
    return 1;
}

const char *sec_result_name(SecResult r)
{
    switch (r) {
    case SEC_RANGE_OK:           return "ok";
    case SEC_ERR_ZERO_LEN:       return "zero length";
    case SEC_ERR_OVERFLOW:       return "base+len overflows";
    case SEC_ERR_NON_CANONICAL:  return "non-canonical address";
    case SEC_ERR_STRADDLES_HOLE: return "range straddles the canonical hole";
    case SEC_ERR_OUT_OF_WINDOW:  return "outside the permitted window";
    case SEC_ERR_NOT_MAPPED:     return "page not mapped";
    case SEC_ERR_NOT_WRITABLE:   return "page not writable";
    case SEC_ERR_IS_USER:        return "page is USER-accessible";
    case SEC_ERR_BAD_WINDOW:     return "malformed window";
    default:                     return "unknown";
    }
}

static const SecWindow g_win_kmap      = { VEX_KMAP_BASE, VEX_KMAP_SIZE };
static const SecWindow g_win_directmap = { VEX_PHYS_MAP_BASE,
                                           0x0000400000000000ULL };

const SecWindow *sec_window_kmap(void)       { return &g_win_kmap; }
const SecWindow *sec_window_direct_map(void) { return &g_win_directmap; }

/* Reads the leaf entry mapping `virt`, following 2 MiB pages. Returns 1
 * and the raw entry, or 0 if not present at some level. */
static int sec_leaf_entry(uint64_t virt, uint64_t *out_entry, int *out_large)
{
    uint64_t *pml4 = (uint64_t *)(uintptr_t)(sec_read_cr3() & SEC_ADDR_MASK);
    uint64_t e = pml4[SEC_PML4_IDX(virt)];
    if (!(e & VMM_PRESENT)) return 0;

    uint64_t *pdpt = (uint64_t *)(uintptr_t)(e & SEC_ADDR_MASK);
    e = pdpt[(virt >> 30) & 0x1FF];
    if (!(e & VMM_PRESENT)) return 0;
    if (e & VMM_LARGE) {
        if (out_entry) *out_entry = e;
        if (out_large) *out_large = 1;
        return 1;
    }

    uint64_t *pd = (uint64_t *)(uintptr_t)(e & SEC_ADDR_MASK);
    e = pd[(virt >> 21) & 0x1FF];
    if (!(e & VMM_PRESENT)) return 0;
    if (e & VMM_LARGE) {
        if (out_entry) *out_entry = e;
        if (out_large) *out_large = 1;
        return 1;
    }

    uint64_t *pt = (uint64_t *)(uintptr_t)(e & SEC_ADDR_MASK);
    e = pt[(virt >> 12) & 0x1FF];
    if (!(e & VMM_PRESENT)) return 0;
    if (out_entry) *out_entry = e;
    if (out_large) *out_large = 0;
    return 1;
}

SecResult sec_check_range(uint64_t base, uint64_t len,
                          const SecWindow *window,
                          uint32_t access,
                          int allow_zero_len,
                          int check_mappings)
{
    if (len == 0) {
        if (allow_zero_len) return SEC_RANGE_OK;
        return SEC_ERR_ZERO_LEN;
    }

    /* Overflow FIRST. Every check after this point reasons about
     * base+len-1, and if that wrapped, all of them would be reasoning
     * about the wrong address - approving a range that covers everything
     * because its "end" came out smaller than its start. */
    uint64_t end_excl;
#if VEX_INJECTED(10)
    /* INJECTION 10: the overflow check is removed and the wrapped value
     * is used. This is the classic ptr+len bug: a huge length makes the
     * computed end small, so every subsequent bound looks satisfied. */
    end_excl = base + len;
#else
    if (!sec_add_ovf(base, len, &end_excl)) return SEC_ERR_OVERFLOW;
#endif
    uint64_t last = end_excl - 1;

    if (!sec_is_canonical(base)) return SEC_ERR_NON_CANONICAL;
    if (!sec_is_canonical(last)) return SEC_ERR_NON_CANONICAL;

    /* A range whose ends are both canonical can still cross the hole in
     * between - low-half start, high-half end. Detected by the halves
     * disagreeing, not by inspecting the middle. */
    int base_high = (base >= SEC_CANONICAL_HIGH_MIN);
    int last_high = (last >= SEC_CANONICAL_HIGH_MIN);
    if (base_high != last_high) return SEC_ERR_STRADDLES_HOLE;

    if (window) {
        uint64_t wend;
        if (window->size == 0) return SEC_ERR_BAD_WINDOW;
        if (!sec_add_ovf(window->base, window->size, &wend))
            return SEC_ERR_BAD_WINDOW;
#if VEX_INJECTED(11)
        /* INJECTION 11: only the FIRST byte is bounds-checked against the
         * window. A range that starts inside and runs out the far end is
         * approved - the exact "validated ptr, dereferenced ptr+len" bug
         * the checker exists to prevent. */
        if (base < window->base || base >= wend) return SEC_ERR_OUT_OF_WINDOW;
#else
        if (base < window->base) return SEC_ERR_OUT_OF_WINDOW;
        if (end_excl > wend)     return SEC_ERR_OUT_OF_WINDOW;
#endif
    }

    if (!check_mappings) return SEC_RANGE_OK;

    /* Walk EVERY page. Iterating page-aligned so that a range starting
     * mid-page still examines the page it starts in, and so that a range
     * ending mid-page still examines the page it ends in. */
    uint64_t first_page = base & ~(VMM_PAGE_SIZE - 1);
    uint64_t last_page  = last & ~(VMM_PAGE_SIZE - 1);

    for (uint64_t p = first_page; ; p += VMM_PAGE_SIZE) {
        uint64_t entry = 0;
        int large = 0;
        if (!sec_leaf_entry(p, &entry, &large)) return SEC_ERR_NOT_MAPPED;

        if ((access & SEC_ACCESS_WRITE) && !(entry & VMM_WRITE))
            return SEC_ERR_NOT_WRITABLE;

        /* No kernel mapping may be USER-accessible. Checked here, on the
         * actual entry, not assumed from how it was created. */
        if (entry & VMM_USER) return SEC_ERR_IS_USER;

        if (p == last_page) break;

#if VEX_INJECTED(13)
        /* INJECTION 13: stop after the first page. Cross-page ranges are
         * then validated only at their start, so an unmapped or
         * wrongly-permissioned second page is never seen. */
        break;
#endif
        /* Guard against wrap on the final page of the address space. */
        if (p + VMM_PAGE_SIZE < p) break;
    }

    return SEC_RANGE_OK;
}

/* ------------------------------------------------------------------ *
 * Page-table audit
 * ------------------------------------------------------------------ */

static void sec_classify_wx(SecPageAudit *a, uint64_t virt)
{
    if (virt >= VEX_KMAP_BASE && virt < VEX_KMAP_BASE + VEX_KMAP_SIZE)
        a->wx_kmap++;
    else if (virt >= VEX_PHYS_MAP_BASE && virt < VEX_KMAP_BASE)
        a->wx_direct_map++;
    else if (virt <= SEC_CANONICAL_LOW_MAX)
        a->wx_identity++;
    else
        a->wx_other++;
}

/* Sign-extends a 48-bit linear address assembled from table indices, so
 * that higher-half entries are reported at the address the CPU uses
 * rather than at a truncated one. */
static uint64_t sec_canonicalize(uint64_t v)
{
    if (v & (1ULL << 47)) return v | 0xFFFF000000000000ULL;
    return v;
}

static void sec_note_leaf(SecPageAudit *a, uint64_t virt, uint64_t e)
{
    a->leaves++;
    if (e & VMM_NX) a->nx_leaves++;
    if ((e & VMM_WRITE) && !(e & VMM_NX)) {
        a->wx_leaves++;
        sec_classify_wx(a, virt);
    }
}

int sec_audit_page_tables(SecPageAudit *out)
{
    if (!out) return 0;

    SecPageAudit a;
    uint8_t *z = (uint8_t *)&a;
    for (uint64_t i = 0; i < sizeof(a); i++) z[i] = 0;

    uint64_t cr3 = sec_read_cr3();
    uint64_t *pml4 = (uint64_t *)(uintptr_t)(cr3 & SEC_ADDR_MASK);
    if (pml4 == 0) return 0;

    for (uint64_t i4 = 0; i4 < SEC_ENTRIES; i4++) {
        uint64_t e4 = pml4[i4];
        if (!(e4 & VMM_PRESENT)) continue;
        a.entries_walked++;
        if (e4 & VMM_USER) { a.user_pml4++; }

        uint64_t *pdpt = (uint64_t *)(uintptr_t)(e4 & SEC_ADDR_MASK);
        for (uint64_t i3 = 0; i3 < SEC_ENTRIES; i3++) {
            uint64_t e3 = pdpt[i3];
            if (!(e3 & VMM_PRESENT)) continue;
            a.entries_walked++;
            if (e3 & VMM_USER) { a.user_pdpt++; }

            uint64_t v3 = sec_canonicalize((i4 << 39) | (i3 << 30));
            if (e3 & VMM_LARGE) { sec_note_leaf(&a, v3, e3); continue; }

            uint64_t *pd = (uint64_t *)(uintptr_t)(e3 & SEC_ADDR_MASK);
            for (uint64_t i2 = 0; i2 < SEC_ENTRIES; i2++) {
                uint64_t e2 = pd[i2];
                if (!(e2 & VMM_PRESENT)) continue;
                a.entries_walked++;
                if (e2 & VMM_USER) { a.user_pd++; }

                uint64_t v2 = sec_canonicalize((i4 << 39) | (i3 << 30) |
                                               (i2 << 21));
                if (e2 & VMM_LARGE) { sec_note_leaf(&a, v2, e2); continue; }

                uint64_t *pt = (uint64_t *)(uintptr_t)(e2 & SEC_ADDR_MASK);
                for (uint64_t i1 = 0; i1 < SEC_ENTRIES; i1++) {
                    uint64_t e1 = pt[i1];
                    if (!(e1 & VMM_PRESENT)) continue;
                    a.entries_walked++;
                    if (e1 & VMM_USER) { a.user_pt++; }

                    uint64_t v1 = sec_canonicalize((i4 << 39) | (i3 << 30) |
                                                   (i2 << 21) | (i1 << 12));
                    sec_note_leaf(&a, v1, e1);
                }
            }
        }
    }

    a.user_total = a.user_pml4 + a.user_pdpt + a.user_pd + a.user_pt;
    *out = a;
    return 1;
}

/* ------------------------------------------------------------------ *
 * CPU features
 * ------------------------------------------------------------------ */

#define SEC_CR4_UMIP     (1ULL << 11)
#define SEC_CR4_FSGSBASE (1ULL << 16)
#define SEC_CR4_SMEP     (1ULL << 20)
#define SEC_CR4_SMAP     (1ULL << 21)
#define SEC_IA32_EFER    0xC0000080u
#define SEC_EFER_NXE     (1ULL << 11)

void sec_cpu_features(SecCpuFeatures *out)
{
    if (!out) return;

    uint32_t a = 0, b = 0, c = 0, d = 0;

    sec_cpuid(0, 0, &a, &b, &c, &d);
    uint32_t max_leaf = a;

    out->smep_supported = 0;
    out->smap_supported = 0;
    out->umip_supported = 0;
    out->fsgsbase_supported = 0;
    if (max_leaf >= 7) {
        sec_cpuid(7, 0, &a, &b, &c, &d);
        out->fsgsbase_supported = (b & (1u << 0)) != 0;
        out->smep_supported     = (b & (1u << 7)) != 0;
        out->smap_supported     = (b & (1u << 20)) != 0;
        out->umip_supported     = (c & (1u << 2)) != 0;
    }

    sec_cpuid(0x80000000u, 0, &a, &b, &c, &d);
    out->nx_supported = 0;
    if (a >= 0x80000001u) {
        sec_cpuid(0x80000001u, 0, &a, &b, &c, &d);
        out->nx_supported = (d & (1u << 20)) != 0;
    }

    uint64_t cr4 = sec_read_cr4();
    out->cr4 = cr4;
    out->smep_enabled     = (cr4 & SEC_CR4_SMEP) != 0;
    out->smap_enabled     = (cr4 & SEC_CR4_SMAP) != 0;
    out->umip_enabled     = (cr4 & SEC_CR4_UMIP) != 0;
    out->fsgsbase_enabled = (cr4 & SEC_CR4_FSGSBASE) != 0;

    uint64_t efer = sec_read_msr(SEC_IA32_EFER);
    out->efer = efer;
    out->nx_enabled = (efer & SEC_EFER_NXE) != 0;
}

/* ------------------------------------------------------------------ *
 * Probe fixup, called from idt.c
 * ------------------------------------------------------------------ */

extern volatile uint64_t sec_probe_active;      /* probe.asm */
extern volatile uint64_t sec_probe_fixup_rip;   /* probe.asm */

static volatile uint64_t g_probe_faults;
static volatile uint64_t g_last_vector;
static volatile uint64_t g_last_error;
static volatile uint64_t g_last_cr2;
static volatile uint64_t g_last_cs;
static volatile int      g_last_valid;

int sec_probe_fixup(void *frame_v, uint64_t vector, uint64_t error_code,
                    uint64_t cr2)
{
#if VEX_INJECTED(15)
    /* INJECTION 15: the fixup swallows the exception SILENTLY. It still
     * redirects to the probe's fixup, so the kernel survives and the boot
     * looks entirely normal, but it records nothing: no vector, no error
     * code, no CR2, and no increment of the fault counter.
     *
     * This attacks the TEST INSTRUMENT on purpose. Negative controls are
     * only evidence if the thing reporting "the CPU denied this" can
     * itself be shown to fail. With this on, every SEC-FAULT assertion
     * about what the hardware reported is reading stale state, and the
     * "the CPU actually raised an exception" counter checks see no
     * increment - so the suite must fail rather than quietly report
     * denials it never observed.
     *
     * NOTE ON AN EARLIER, BROKEN VERSION OF THIS INJECTION. The first
     * attempt set frame->rax = 1 to fake a successful access. It did
     * nothing, because the probe's fixup label zeroes EAX immediately
     * after resuming, so the forged value was overwritten before the
     * probe returned - the injected build booted clean and
     * fault-inject.sh correctly reported injection 15 as NOT behaving as
     * expected. The injection was rewritten; no test was touched. Recorded
     * here because "the negative control didn't fire and I fixed the
     * control" is exactly the kind of event that must not be quietly
     * edited out of the history. */
    if (!sec_probe_active) return 0;
    InterruptFrame *f = (InterruptFrame *)frame_v;
    sec_probe_active = 0;
    f->rip = sec_probe_fixup_rip;
    return 1;
#else
    if (!sec_probe_active) return 0;

    InterruptFrame *f = (InterruptFrame *)frame_v;

    g_last_vector = vector;
    g_last_error  = error_code;
    g_last_cr2    = cr2;
    g_last_cs     = f->cs;
    g_probe_faults++;
    g_last_valid  = 1;

    sec_probe_active = 0;

    /* Redirect the interrupted flow to the probe's fixup label. The
     * probe restores its own RSP there; doing it here would mean
     * knowing which of several probes was running. */
    f->rip = sec_probe_fixup_rip;
    return 1;
#endif
}

int sec_probe_last_fault(uint64_t *out_vector, uint64_t *out_error,
                         uint64_t *out_cr2, uint64_t *out_cs)
{
    if (out_vector) *out_vector = g_last_vector;
    if (out_error)  *out_error  = g_last_error;
    if (out_cr2)    *out_cr2    = g_last_cr2;
    if (out_cs)     *out_cs     = g_last_cs;
    return g_last_valid;
}

uint64_t sec_probe_fault_count(void) { return g_probe_faults; }
