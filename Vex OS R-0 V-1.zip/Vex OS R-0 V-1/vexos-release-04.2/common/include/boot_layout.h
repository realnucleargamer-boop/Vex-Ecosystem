/*
 * Vex OS - common/include/boot_layout.h
 *
 * BOOT-01 ONLY: the kernel has no paging/relocation support yet, so
 * for this milestone the bootloader loads the kernel as a flat
 * binary at a FIXED, pre-agreed physical address, and the kernel is
 * linked to run at that same address. This is a temporary contract,
 * separate from BootInfo, that exists only until the paging milestone
 * lets the kernel be placed anywhere and relocated to the frozen
 * higher-half virtual layout (kernel_virtual_base, 0xFFFFFFFF80000000).
 *
 * 0x100000 (1 MiB) is chosen because it sits above the legacy/BIOS
 * reserved region and is conventionally free and identity-usable on
 * UEFI systems; the bootloader still verifies this via the EFI
 * memory map before allocating (see bootloader/src/main.c).
 *
 * FROZEN for BOOT-01. Must change together in bootloader, kernel
 * linker script, and this header if it ever changes - do not let
 * these drift independently.
 */

#ifndef VEXOS_BOOT_LAYOUT_H
#define VEXOS_BOOT_LAYOUT_H

#define VEX_KERNEL_LOAD_PHYS 0x100000ULL

/*
 * Size of the physical region the bootloader must reserve for the
 * kernel at VEX_KERNEL_LOAD_PHYS - NOT the size of the kernel file.
 *
 * The kernel is loaded as a flat binary produced by `objcopy -O binary`,
 * and .bss is NOBITS, so it is not present in that file. The kernel's
 * run-time footprint is therefore strictly larger than its file size,
 * by the whole of .bss - which includes the boot stack the kernel runs
 * on from its first instruction.
 *
 * Reserving only ceil(file_size / 4096) pages (as BOOT-01 through
 * BOOT-02C did) leaves .bss sitting in memory that the EFI memory map
 * still reports as EfiConventionalMemory, i.e. free for anyone to
 * allocate - including the kernel's own physical allocator. That was a
 * live latent bug: it went unnoticed only because the BOOT-02A bump
 * arena happened to start tens of megabytes higher up. BOOT-03's
 * allocator, which places its bitmaps immediately after the kernel,
 * reproduced it immediately as a hang.
 *
 * 2 MiB is chosen to be comfortably larger than the current footprint
 * (~104 KiB of image + ~40 KiB of .bss) and to align with a single
 * 2 MiB page, which is the granularity a future higher-half/NX mapping
 * will want anyway. The kernel verifies at run time that __kernel_end
 * fits inside it, so overflowing this is a loud failure, not silent
 * corruption.
 */
/*
 * CRYSTAL-NATIVE-01: raised from 2 MiB to 4 MiB. The embedded Crystal model is 2,167,108 bytes of read-only data, which
 * pushes the kernel's run-time footprint past the old 2 MiB reserve. This is the documented knob ("raise it in
 * boot_layout.h"); the kernel still verifies at boot that __kernel_end fits, and kernel01_tests still requires >= 256 KiB
 * of headroom. Both bootloaders (main.c and main_win.c) take the value from here. Still 2 MiB-page aligned (2 pages).
 */
#define VEX_KERNEL_RESERVE_BYTES 0x400000ULL

#endif /* VEXOS_BOOT_LAYOUT_H */
