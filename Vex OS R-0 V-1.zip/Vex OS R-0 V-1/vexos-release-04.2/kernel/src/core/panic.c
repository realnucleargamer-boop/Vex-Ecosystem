/*
 * Vex OS - kernel/src/core/panic.c
 *
 * BOOT-01 panic implementation. Emits the frozen panic format to
 * serial (the reliable channel this early - the framebuffer may not
 * be initialized or may itself be the cause of the failure), then
 * halts the CPU with interrupts disabled. Never returns, never
 * silently hangs without having said why.
 *
 * Real stack unwinding, CPU id, and thread name come with the
 * interrupt/process milestones - this is the minimal honest version:
 * it never fabricates data it doesn't have.
 */

#include "panic.h"
#include "serial.h"

void panic(const char *reason, uint64_t rip, uint64_t cr2)
{
    serial_puts("\n\nVEX KERNEL PANIC\n\n");

    serial_puts("Reason: ");
    serial_puts(reason ? reason : "(unknown)");
    serial_putc('\n');

    serial_puts("RIP: ");
    serial_put_hex64(rip);
    serial_putc('\n');

    serial_puts("CR2: ");
    serial_put_hex64(cr2);
    serial_putc('\n');

    serial_puts("CPU: 0\n");       /* BOOT-01: single CPU assumed, APIC milestone extends this */
    serial_puts("Thread: kernel\n"); /* BOOT-01: no scheduler yet, process milestone extends this */

    serial_puts("\n[Stack trace]\n");
    serial_puts("(unwinding not yet implemented - BOOT-01)\n");

    serial_puts("\nSystem halted. (ENTER-to-reboot handling arrives with keyboard/input milestone)\n");

    __asm__ volatile ("cli");
    for (;;) {
        __asm__ volatile ("hlt");
    }
}
