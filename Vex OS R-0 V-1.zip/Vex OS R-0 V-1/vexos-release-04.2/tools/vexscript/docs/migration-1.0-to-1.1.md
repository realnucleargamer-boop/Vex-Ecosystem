# Migration / Compatibility Guide — VEX-Script 1.0 → 1.1

## Compatibility promise

Any program that only uses the **frozen VEX-Script 1.0 surface** remains valid in 1.1.

This includes:
- `fn`, `let`, `let mut`, `const`
- integer and bool types, `string` type
- arithmetic and comparisons
- `if` / `else` / `while`
- `struct` / `type` (syntax accepted; full struct value support still limited)
- `unsafe` keyword (accepted; semantics still the 1.0 safety model)
- `print` / `println` style output (now provided as builtins)

## What 1.1 adds (opt-in)

- `for` and `loop` with working `break` / `continue`
- `use module;` (minimal modules)
- Library types/helpers: `some` / `none` / `ok` / `err` / `is_some` / `unwrap` …
- `len_string`, `concat`
- `assert`
- Clearer runtime diagnostics

## Breaking changes

**None intentionally.**  
1.1 is designed as a superset.

If a 1.0 program relied on unspecified behaviour around `for`/`loop`/`break`, the 1.1 semantics become the definition.

## How to migrate

1. Keep existing 1.0 source unchanged — it should run.
2. Optionally adopt `for`/`loop`, Option/Result helpers, and string utilities.
3. When multi-file programs are needed, introduce `use`.

## Runtime note

1.1 ships as a **reference interpreter**.  
A future compiler backend will target the same language surface.
