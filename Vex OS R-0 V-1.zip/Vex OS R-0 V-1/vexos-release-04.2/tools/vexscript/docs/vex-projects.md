# VexScript projects

```
myapp/
  vex.toml
  src/main.vex
  src/math.vex
```

```toml
[package]
name = "myapp"
version = "0.1.0"

[build]
entry = "src/main.vex"
```
