/*
 * Vex OS - kernel/src/memory/virtual/kstack.c
 *
 * BOOT-03 guarded kernel stacks. See kernel/include/kstack.h.
 */

#include "kstack.h"
#include "vmm.h"
#include "pmm.h"
#include "serial.h"

static volatile uint64_t g_kstacks;

uint64_t kstack_count(void)
{
    return __atomic_load_n(&g_kstacks, __ATOMIC_ACQUIRE);
}

int kstack_alloc(KernelStack *out)
{
    if (out == 0) return 0;

    out->base = 0; out->top = 0; out->guard = 0; out->pages = 0;

    /* Reserve guard page + stack pages contiguously in virtual space,
     * then map only the stack pages. The guard is simply the page that
     * is never mapped; it costs one page of virtual address space and no
     * physical memory at all. */
    uint64_t vbase = vmm_kmap_reserve_virtual(KSTACK_PAGES + 1);
    if (vbase == 0) {
        serial_puts("[kernel] KSTACK: FAILED - kmap virtual window exhausted\n");
        return 0;
    }

    uint64_t guard = vbase;
    uint64_t base = vbase + VMM_PAGE_SIZE;

    uint64_t mapped = 0;
    for (uint64_t i = 0; i < KSTACK_PAGES; i++) {
        uint64_t phys = pmm_alloc_page();
        if (phys == 0) {
            serial_puts("[kernel] KSTACK: FAILED - out of physical memory\n");
            goto unwind;
        }

        /* Stack memory is data: NX is correct here and is applied
         * because it is one of the few places in BOOT-03 where it can be
         * applied without touching the kernel image's own mappings. */
        VmmResult r = vmm_map_page(base + i * VMM_PAGE_SIZE, phys,
                                   VMM_KERNEL_RW_NX);
        if (r != VMM_OK) {
            serial_puts("[kernel] KSTACK: FAILED - map error: ");
            serial_puts(vmm_result_name(r));
            serial_puts("\n");
            pmm_free_page(phys);
            goto unwind;
        }
        mapped++;
    }

    out->guard = guard;
    out->base = base;
    out->top = base + KSTACK_SIZE;
    out->pages = KSTACK_PAGES;

    __atomic_add_fetch(&g_kstacks, 1, __ATOMIC_ACQ_REL);
    return 1;

unwind:
    /* Release what was taken. KERNEL-01 Phase 6 gave the kmap allocator a
     * free, so unlike in BOOT-03 the virtual range is returned too - a
     * failed stack allocation no longer costs window space permanently.
     * Order matters and is not interchangeable: every page must be
     * unmapped before the range is returned, because
     * vmm_kmap_free_virtual() refuses a range that still has live
     * mappings inside it. */
    for (uint64_t i = 0; i < mapped; i++) {
        uint64_t v = base + i * VMM_PAGE_SIZE;
        uint64_t phys = 0;
        if (vmm_translate(v, &phys) == VMM_OK) {
            vmm_unmap_page(v);
            pmm_free_page(phys);
        }
    }
    vmm_kmap_free_virtual(vbase, KSTACK_PAGES + 1);
    return 0;
}

int kstack_verify(const KernelStack *s)
{
    if (s == 0 || s->base == 0) return 0;

    /* The guard page must NOT translate. */
    uint64_t phys = 0;
    if (vmm_translate(s->guard, &phys) == VMM_OK) {
        serial_puts("[kernel] KSTACK: guard page @ ");
        serial_put_hex64(s->guard);
        serial_puts(" IS MAPPED - overflow protection absent\n");
        return 0;
    }

    /* Every stack page must be present and writable. */
    for (uint64_t i = 0; i < s->pages; i++) {
        uint64_t v = s->base + i * VMM_PAGE_SIZE;
        uint64_t entry = 0, size = 0;
        if (vmm_query(v, &entry, &size) != VMM_OK) {
            serial_puts("[kernel] KSTACK: stack page @ ");
            serial_put_hex64(v);
            serial_puts(" is not mapped\n");
            return 0;
        }
        if (!(entry & VMM_WRITE)) {
            serial_puts("[kernel] KSTACK: stack page @ ");
            serial_put_hex64(v);
            serial_puts(" is not writable\n");
            return 0;
        }
        if (size != VMM_PAGE_SIZE) {
            serial_puts("[kernel] KSTACK: stack page @ ");
            serial_put_hex64(v);
            serial_puts(" is inside a large mapping - the guard page cannot"
                        " exist\n");
            return 0;
        }
    }

    /* Actually write to both ends. A mapping that reads correct in the
     * tables but faults on access is the failure this is looking for. */
    volatile uint64_t *lo = (volatile uint64_t *)(uintptr_t)s->base;
    volatile uint64_t *hi = (volatile uint64_t *)(uintptr_t)(s->top - 8);
    *lo = 0x5645583353544B31ULL;   /* "VEX3STK1" */
    *hi = 0x5645583353544B32ULL;   /* "VEX3STK2" */
    if (*lo != 0x5645583353544B31ULL || *hi != 0x5645583353544B32ULL) {
        serial_puts("[kernel] KSTACK: stack memory does not read back\n");
        return 0;
    }

    return 1;
}
