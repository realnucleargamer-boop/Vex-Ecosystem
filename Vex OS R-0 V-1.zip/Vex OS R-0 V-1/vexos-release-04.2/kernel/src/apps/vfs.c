#include "vfs.h"
#include "timer.h"
static VfsNode nd[VFS_MAX_NODES]; static int cnt; static char fdata[VFS_MAX_NODES][VFS_DATA_MAX];
static uint64_t now_ms(void) { return timer_ticks() * (1000u / TIMER_TARGET_HZ); }
static int slen(const char *s) { int n = 0; while (s && s[n] && n < 512) n++; return n; }
static int seq(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return *a == *b; }
static void put(char *d, const char *s) { int i = 0; for (; s[i] && i < VFS_NAME_MAX; i++) d[i] = s[i]; d[i] = 0; }
void vfs_init(void)
{
    for (int i = 0; i < VFS_MAX_NODES; i++) nd[i].used = 0;
    cnt = 0;
    nd[0] = (VfsNode){ "", 1, 1, 0, 0, 0, 0, 0 }; cnt = 1;                          /* "/" owned by uid 0 */
    nd[1] = (VfsNode){ "home", 1, 1, 0, 0, 0, 0, 0 }; nd[2] = (VfsNode){ "tmp", 1, 1, 1, 0, 0, 0, 0 }; cnt = 3;
}
int vfs_persistent(void) { return 0; }
int vfs_root(void) { return 0; }
int vfs_count(void) { return cnt; }
const VfsNode *vfs_node(int i) { return (i >= 0 && i < VFS_MAX_NODES && nd[i].used) ? &nd[i] : 0; }
int vfs_parent(int i) { return (i > 0 && vfs_node(i)) ? nd[i].parent : 0; }
VfsResult vfs_validate_name(const char *s)
{
    int l = slen(s);
    if (l < 1 || l > VFS_NAME_MAX) return VFS_ERR_NAME;
    if (seq(s, ".") || seq(s, "..") || s[0] == ' ' || s[l - 1] == ' ') return VFS_ERR_NAME;
    for (int i = 0; i < l; i++) { char c = s[i];
        if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == ' ' || c == '.' || c == '_' || c == '-')) return VFS_ERR_NAME; }
    return VFS_OK;
}
static int find_child(int dir, const char *name) { for (int i = 0; i < VFS_MAX_NODES; i++) if (nd[i].used && i != 0 && nd[i].parent == dir && seq(nd[i].name, name)) return i; return -1; }
int vfs_resolve(const char *path)
{
    if (!path || path[0] != '/') return VFS_ERR_PATH;
    int cur = 0, i = 1, l = slen(path);
    if (l > 255) return VFS_ERR_PATH;
    while (i < l) {
        char comp[VFS_NAME_MAX + 2]; int k = 0;
        while (i < l && path[i] != '/') { if (k >= VFS_NAME_MAX) return VFS_ERR_PATH; comp[k++] = path[i++]; }
        comp[k] = 0; if (i < l) i++;                                           /* skip '/' */
        if (k == 0) continue;                                                  /* tolerate "//" and trailing "/" */
        if (vfs_validate_name(comp) != VFS_OK) return VFS_ERR_PATH;            /* rejects "." and ".." : no traversal */
        if (!nd[cur].is_dir) return VFS_ERR_NOTDIR;
        int c = find_child(cur, comp); if (c < 0) return VFS_ERR_NOTFOUND;
        cur = c;
    }
    return cur;
}
int vfs_create(int dir, const char *name, int is_dir, uint32_t uid, int admin)
{
    VfsResult v = vfs_validate_name(name); if (v != VFS_OK) return v;
    const VfsNode *d = vfs_node(dir); if (!d) return VFS_ERR_NOTFOUND; if (!d->is_dir) return VFS_ERR_NOTDIR;
    if (!(admin || d->owner_uid == uid || d->world_writable)) return VFS_ERR_DENIED;
    if (find_child(dir, name) >= 0) return VFS_ERR_EXISTS;                     /* never overwrites */
    int slot = -1; for (int i = 1; i < VFS_MAX_NODES; i++) if (!nd[i].used) { slot = i; break; }
    if (slot < 0) return VFS_ERR_FULL;
    VfsNode t; put(t.name, name); t.is_dir = (uint8_t)(is_dir != 0); t.world_writable = 0; t.parent = (int16_t)dir; t.owner_uid = uid; t.used = 1; t.size = 0; t.mtime_ms = now_ms(); fdata[slot][0] = 0;
    nd[slot] = t; cnt++;                                                       /* node becomes visible only when fully built */
    return slot;
}
int vfs_ensure_home(uint32_t uid, const char *id)
{
    int c = find_child(1, id); if (c >= 0) return c;
    return vfs_create(1, id, 1, uid, 1);
}
int vfs_list(int dir, int *out, int max)
{
    int k = 0;
    for (int pass = 0; pass < 2; pass++)
        for (int i = 1; i < VFS_MAX_NODES && k < max; i++)
            if (nd[i].used && nd[i].parent == dir && (int)nd[i].is_dir == (pass == 0)) out[k++] = i;
    return k;
}
int vfs_path(int i, char *buf, int cap)
{
    if (!vfs_node(i) || cap < 2) return -1;
    if (i == 0) { buf[0] = '/'; buf[1] = 0; return 1; }
    int chain[16], n = 0; for (int c = i; c != 0 && n < 16; c = nd[c].parent) chain[n++] = c;
    int p = 0; for (int k = n - 1; k >= 0; k--) { if (p + 2 + slen(nd[chain[k]].name) >= cap) return -1; buf[p++] = '/'; for (int j = 0; nd[chain[k]].name[j]; j++) buf[p++] = nd[chain[k]].name[j]; }
    buf[p] = 0; return p;
}
static int can_write_dir(int dir, uint32_t uid, int admin) { const VfsNode *d = vfs_node(dir); return d && (admin || d->owner_uid == uid || d->world_writable); }
int vfs_write(int n, const char *data, int len, uint32_t uid, int admin)
{
    const VfsNode *f = vfs_node(n); if (!f) return VFS_ERR_NOTFOUND; if (f->is_dir) return VFS_ERR_NOTDIR;
    if (len < 0 || (len > 0 && !data)) return VFS_ERR_PATH;
    if (!(admin || f->owner_uid == uid || can_write_dir(f->parent, uid, admin))) return VFS_ERR_DENIED;
    if (len > VFS_DATA_MAX - 1) return VFS_ERR_TOOBIG;                          /* validated BEFORE touching the file */
    for (int i = 0; i < len; i++) fdata[n][i] = data[i];
    fdata[n][len] = 0; nd[n].size = (uint16_t)len; nd[n].mtime_ms = now_ms(); return 0;
}
int vfs_read(int n, char *out, int cap)
{
    const VfsNode *f = vfs_node(n); if (!f) return VFS_ERR_NOTFOUND; if (f->is_dir) return VFS_ERR_NOTDIR; if (!out || cap < 1) return VFS_ERR_PATH;
    int k = f->size < cap - 1 ? f->size : cap - 1; for (int i = 0; i < k; i++) out[i] = fdata[n][i]; out[k] = 0; return k;
}
int vfs_rename(int n, const char *name, uint32_t uid, int admin)
{
    const VfsNode *f = vfs_node(n); if (!f || n < 3) return n < 3 && n >= 0 ? VFS_ERR_DENIED : VFS_ERR_NOTFOUND;
    VfsResult v = vfs_validate_name(name); if (v != VFS_OK) return v;
    if (!can_write_dir(f->parent, uid, admin)) return VFS_ERR_DENIED;
    if (seq(f->name, name)) return 0;
    if (find_child(f->parent, name) >= 0) return VFS_ERR_EXISTS;
    put(nd[n].name, name); nd[n].mtime_ms = now_ms(); return 0;
}
int vfs_delete(int n, uint32_t uid, int admin)
{
    const VfsNode *f = vfs_node(n); if (!f) return VFS_ERR_NOTFOUND; if (n < 3) return VFS_ERR_DENIED;
    if (!can_write_dir(f->parent, uid, admin)) return VFS_ERR_DENIED;
    if (f->is_dir) for (int i = 1; i < VFS_MAX_NODES; i++) if (nd[i].used && nd[i].parent == n) return VFS_ERR_NOTEMPTY;
    nd[n].used = 0; cnt--; fdata[n][0] = 0; return 0;
}
int vfs_can_read(int n, uint32_t uid, int admin)
{
    if (!vfs_node(n)) return 0;
    if (admin) return 1;
    int c = n; for (int g = 0; g < 16 && c > 0; g++) { if (nd[c].parent == 1) return nd[c].owner_uid == uid; c = nd[c].parent; }
    return 1;
}
static char lc(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
int vfs_search(const char *q, uint32_t uid, int admin, int *out, int max)
{
    int k = 0, ql = slen(q); if (ql < 1 || ql > VFS_NAME_MAX) return 0;
    for (int i = 1; i < VFS_MAX_NODES && k < max; i++) {
        if (!nd[i].used || !vfs_can_read(i, uid, admin)) continue;
        for (int s = 0; nd[i].name[s]; s++) { int j = 0; while (j < ql && nd[i].name[s + j] && lc(nd[i].name[s + j]) == lc(q[j])) j++; if (j == ql) { out[k++] = i; break; } }
    }
    return k;
}
const char *vfs_errmsg(int c)
{
    switch (c) {
    case VFS_ERR_NAME: return "Invalid file name (1-31 chars: letters, digits, space . _ -).";
    case VFS_ERR_EXISTS: return "A file or folder with that name already exists.";
    case VFS_ERR_NOTFOUND: return "That location does not exist.";
    case VFS_ERR_NOTDIR: return "That is not a folder.";
    case VFS_ERR_DENIED: return "Permission denied: you cannot write in this folder.";
    case VFS_ERR_FULL: return "The filesystem is full.";
    case VFS_ERR_PATH: return "Invalid path.";
    case VFS_ERR_NOTEMPTY: return "The folder is not empty.";
    case VFS_ERR_TOOBIG: return "The content is too large (limit 2047 bytes).";
    default: return "OK";
    }
}
