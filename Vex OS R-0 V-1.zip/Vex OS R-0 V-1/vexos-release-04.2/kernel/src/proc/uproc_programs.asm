; Vex OS - kernel/src/proc/uproc_programs.asm
;
; PROC-01: Ring 3 test programs as complete VXE1 images (header + text + data), embedded as read-only data and
; loaded through the real loader by `v. proc test`. Each program attacks ONE boundary; the expected outcome of every
; one is asserted in uproc_tests.c. Entry state: RDI = data base, RSI = text base, RSP = stack top - 16.
; Calling convention for `int 0x80`: RAX = number, RDI RSI RDX R10 = args, result in RAX.

BITS 64
section .rodata
align 16

%macro VXE_BEGIN 3                     ; name, bss bytes, stack pages
align 16
global uprog_%1
global uprog_%1_end
uprog_%1:
    db 'V','X','E','1'
    dw 1, 48
    dd 0                               ; flags
    dd 0                               ; entry = start of text
    dd %1_text - uprog_%1              ; text_off
    dd %1_text_end - %1_text           ; text_size
    dd %1_data - uprog_%1              ; data_off
    dd %1_data_end - %1_data           ; data_size
    dd %2                              ; bss
    dd %3                              ; stack pages
    dd 0, 0
%1_text:
%endmacro
%macro VXE_DATA 1
%1_text_end:
%1_data:
%endmacro
%macro VXE_END 1
%1_data_end:
uprog_%1_end:
%endmacro
%macro EXIT_RDI 0
    xor eax, eax
    int 0x80
    jmp $
%endmacro
%macro CHK_FAIL 1                      ; the syscall MUST return a negative value
    mov eax, %1
    int 0x80
    test rax, rax
    js %%ok
    inc r13
%%ok:
%endmacro
%macro CHK_GOOD 1                      ; the syscall MUST succeed (>= 0)
    mov eax, %1
    int 0x80
    test rax, rax
    jns %%ok
    inc r13
%%ok:
%endmacro

; ---- 1. hello: WRITE then exit with the byte count ---------------------------------------------------------------
VXE_BEGIN hello, 0, 1
    mov rbx, rdi
    mov eax, 1
    mov rdi, rbx
    mov esi, 15
    int 0x80
    mov rdi, rax
    EXIT_RDI
VXE_DATA hello
    db "hello from vxe1"
VXE_END hello

; ---- 2. bssdata: initialised data readable, bss zero-filled across pages, data+bss writable --------------------------
VXE_BEGIN bssdata, 8192, 1
    mov rbx, rdi
    mov rax, 0x1122334455667788
    mov edi, 1
    cmp [rbx], rax
    jne .out
    mov edi, 2
    cmp qword [rbx+8], 0
    jne .out
    mov edi, 3
    cmp qword [rbx+4096], 0
    jne .out
    mov edi, 4
    cmp qword [rbx+8192], 0
    jne .out
    mov rax, 0xAAAAAAAAAAAAAAAA
    mov [rbx+8], rax
    mov [rbx+4096], rax
    mov [rbx+8192], rax
    mov edi, 5
    cmp [rbx+8], rax
    jne .out
    cmp [rbx+4096], rax
    jne .out
    cmp [rbx+8192], rax
    jne .out
    xor edi, edi
.out:
    EXIT_RDI
VXE_DATA bssdata
    dq 0x1122334455667788
VXE_END bssdata

; ---- 3-6. memory attacks -------------------------------------------------------------------------------------------
VXE_BEGIN kread, 0, 1                  ; read kernel memory -> #PF
    mov rax, 0x100000
    mov rax, [rax]
    mov edi, 99
    EXIT_RDI
VXE_DATA kread
    db 0
VXE_END kread

VXE_BEGIN kwrite, 0, 1                 ; write kernel memory -> #PF
    mov rax, 0x100000
    mov qword [rax], 1
    mov edi, 99
    EXIT_RDI
VXE_DATA kwrite
    db 0
VXE_END kwrite

VXE_BEGIN textwrite, 0, 1              ; write own (read-only) code page -> #PF
    mov byte [rsi], 0
    mov edi, 99
    EXIT_RDI
VXE_DATA textwrite
    db 0
VXE_END textwrite

VXE_BEGIN nxdata, 0, 1                 ; execute the writable data page (NX) -> #PF instruction fetch
    jmp rdi
VXE_DATA nxdata
    db 0xC3                            ; `ret`: would run harmlessly IF the page were executable
VXE_END nxdata

VXE_BEGIN nxstack, 0, 1                ; execute the stack (NX) -> #PF instruction fetch
    mov rax, rsp
    jmp rax
VXE_DATA nxstack
    db 0
VXE_END nxstack

VXE_BEGIN guardlo, 0, 1                ; byte just below the data segment (guard page) -> #PF
    mov byte [rdi-1], 0
    mov edi, 99
    EXIT_RDI
VXE_DATA guardlo
    db 0
VXE_END guardlo

VXE_BEGIN guardhi, 0, 1                ; byte at the stack top (guard page above) -> #PF
    mov qword [rsp+16], 0
    mov edi, 99
    EXIT_RDI
VXE_DATA guardhi
    db 0
VXE_END guardhi

VXE_BEGIN texthole, 0, 1               ; one page past the end of text (unmapped) -> #PF
    mov al, [rsi+4096]
    mov edi, 99
    EXIT_RDI
VXE_DATA texthole
    db 0
VXE_END texthole

VXE_BEGIN stackover, 0, 1              ; push until the stack page is exhausted -> #PF in the guard below it
.l: push rax
    jmp .l
VXE_DATA stackover
    db 0
VXE_END stackover

; ---- privileged / illegal instructions ---------------------------------------------------------------------------
VXE_BEGIN priv_cli, 0, 1
    cli
    mov edi, 99
    EXIT_RDI
VXE_DATA priv_cli
    db 0
VXE_END priv_cli
VXE_BEGIN priv_hlt, 0, 1
    hlt
    mov edi, 99
    EXIT_RDI
VXE_DATA priv_hlt
    db 0
VXE_END priv_hlt
VXE_BEGIN priv_cr3, 0, 1
    mov rax, cr3
    mov edi, 99
    EXIT_RDI
VXE_DATA priv_cr3
    db 0
VXE_END priv_cr3
VXE_BEGIN priv_in, 0, 1                ; port I/O from Ring 3 (IOPL 0, no I/O bitmap)
    in al, 0x60
    mov edi, 99
    EXIT_RDI
VXE_DATA priv_in
    db 0
VXE_END priv_in
VXE_BEGIN priv_wrmsr, 0, 1
    xor ecx, ecx
    xor eax, eax
    xor edx, edx
    wrmsr
    mov edi, 99
    EXIT_RDI
VXE_DATA priv_wrmsr
    db 0
VXE_END priv_wrmsr
VXE_BEGIN ud2, 0, 1
    ud2
VXE_DATA ud2
    db 0
VXE_END ud2
VXE_BEGIN div0, 0, 1
    xor edx, edx
    xor ecx, ecx
    mov eax, 1
    div ecx
    mov edi, 99
    EXIT_RDI
VXE_DATA div0
    db 0
VXE_END div0
VXE_BEGIN intk, 0, 1                   ; software `int 0x20` = the kernel's timer vector: DPL0 gate -> #GP, handler NOT run
    int 0x20
    mov edi, 99
    EXIT_RDI
VXE_DATA intk
    db 0
VXE_END intk
VXE_BEGIN usyscall, 0, 1               ; the SYSCALL instruction (only run when EFER.SCE is clear) -> #UD
    syscall
    mov edi, 99
    EXIT_RDI
VXE_DATA usyscall
    db 0
VXE_END usyscall

; ---- syscall boundary ------------------------------------------------------------------------------------------------
VXE_BEGIN badptr, 4088, 1              ; data = 8 + 4088 bss = exactly ONE page; exit code = number of WRONG syscall results
    mov rbx, rdi
    mov r12, rsi
    xor r13d, r13d
    xor edi, edi                        ; 1 WRITE null
    mov esi, 4
    CHK_FAIL 1
    mov rdi, 0x100000                   ; 2 WRITE kernel pointer
    mov esi, 4
    CHK_FAIL 1
    lea rdi, [rbx-4096]                 ; 3 WRITE guard page below data
    mov esi, 4
    CHK_FAIL 1
    mov rdi, 0xFFFFFFFFFFFFFFF0         ; 4 WRITE ptr+len overflow
    mov esi, 0x20
    CHK_FAIL 1
    mov rdi, rbx                        ; 5 WRITE len = 2^64-1
    mov rsi, -1
    CHK_FAIL 1
    mov rdi, rbx                        ; 6 WRITE len 257 (> 256)
    mov esi, 257
    CHK_FAIL 1
    mov rdi, 0x0000800000000000         ; 7 WRITE non-canonical pointer
    mov esi, 1
    CHK_FAIL 1
    lea rdi, [rbx+4090]                 ; 8 WRITE spans the end of data into the guard page
    mov esi, 16
    CHK_FAIL 1
    lea rdi, [rbx+4080]                 ; 9 WRITE ends exactly at the segment end: VALID
    mov esi, 16
    CHK_GOOD 1
    mov rdi, rbx                        ; 10 WRITE len 0 at a valid pointer: VALID
    xor esi, esi
    CHK_GOOD 1
    mov rdi, 0x100000                   ; 11 WRITE len 0 at a wild pointer: refused
    xor esi, esi
    CHK_FAIL 1
    mov rdi, r12                        ; 12 WRITE from own text (readable): VALID
    mov esi, 4
    CHK_GOOD 1
    xor edi, edi                        ; 13 AI_ASK null input
    mov esi, 4
    mov rdx, rbx
    mov r10d, 64
    CHK_FAIL 3
    mov rdi, 0x100000                   ; 14 AI_ASK kernel input pointer
    mov esi, 4
    mov rdx, rbx
    mov r10d, 64
    CHK_FAIL 3
    mov rdi, rbx                        ; 15 AI_ASK output into read-only text
    mov esi, 1
    mov rdx, r12
    mov r10d, 64
    CHK_FAIL 3
    mov rdi, rbx                        ; 16 AI_ASK output to kernel memory
    mov esi, 1
    mov rdx, 0x100000
    mov r10d, 64
    CHK_FAIL 3
    mov rdi, rbx                        ; 17 AI_ASK input length 300
    mov esi, 300
    lea rdx, [rbx+64]
    mov r10d, 64
    CHK_FAIL 3
    mov rdi, rbx                        ; 18 AI_ASK capacity 0
    mov esi, 1
    lea rdx, [rbx+64]
    xor r10d, r10d
    CHK_FAIL 3
    mov rdi, rbx                        ; 19 AI_ASK capacity 5000 (> 4096)
    mov esi, 1
    lea rdx, [rbx+64]
    mov r10d, 5000
    CHK_FAIL 3
    mov rdi, rbx                        ; 20 AI_ASK output ptr+cap overflow
    mov esi, 1
    mov rdx, 0xFFFFFFFFFFFFFFF0
    mov r10d, 64
    CHK_FAIL 3
    mov rdi, rbx                        ; 21 AI_ASK output spans the end of data
    mov esi, 1
    lea rdx, [rbx+4090]
    mov r10d, 64
    CHK_FAIL 3
    mov rdi, rbx                        ; 22 AI_ASK valid ("a")
    mov esi, 1
    lea rdx, [rbx+64]
    mov r10d, 64
    CHK_GOOD 3
    mov rdi, 0xDEADBEEF                 ; 23 GETPID ignores garbage arguments: VALID
    mov rsi, -1
    CHK_GOOD 2
    mov rdi, r13
    EXIT_RDI
VXE_DATA badptr
    db "abcdefgh"
VXE_END badptr

VXE_BEGIN nosys, 0, 1                  ; every unknown number -> -38 exactly; 32-bit aliases of EXIT/WRITE must NOT alias
    lea r15, [rel .tbl]
    xor r13d, r13d
    mov r14d, 13
.l: mov rax, [r15]
    mov rdi, 0x100000
    mov rsi, 8
    int 0x80
    cmp rax, -38
    je .ok
    inc r13
.ok:add r15, 8
    dec r14d
    jnz .l
    mov rdi, r13
    EXIT_RDI
.tbl:
    dq 4, 5, 6, 7, 100, 0x7FFFFFFF, 0xFFFFFFFF, 0x80000000, 0x8000000000000000, 0xFFFFFFFFFFFFFFFF
    dq 0x100000000              ; low 32 bits == 0 (EXIT)
    dq 0x100000001              ; low 32 bits == 1 (WRITE)
    dq 0x100000003              ; low 32 bits == 3 (AI_ASK)
VXE_DATA nosys
    db 0
VXE_END nosys

VXE_BEGIN getpid, 0, 1
    mov eax, 2
    int 0x80
    mov rdi, rax
    EXIT_RDI
VXE_DATA getpid
    db 0
VXE_END getpid

VXE_BEGIN exit_neg, 0, 1               ; the full 64-bit exit code must come back unmodified
    mov rdi, -1
    EXIT_RDI
VXE_DATA exit_neg
    db 0
VXE_END exit_neg

VXE_BEGIN flood, 0, 1                  ; 3000 syscalls in a row: must finish well inside the CPU budget
    mov r13d, 3000
.l: mov eax, 2
    int 0x80
    dec r13d
    jnz .l
    xor edi, edi
    EXIT_RDI
VXE_DATA flood
    db 0
VXE_END flood

VXE_BEGIN spin, 0, 1                   ; infinite loop: the watchdog must end it
    jmp $
VXE_DATA spin
    db 0
VXE_END spin

VXE_BEGIN spinsys, 0, 1                ; infinite syscall loop: terminated at a syscall entry or user tick
.l: mov eax, 2
    int 0x80
    jmp .l
VXE_DATA spinsys
    db 0
VXE_END spinsys

; ---- Crystal across the boundary --------------------------------------------------------------------------------------
VXE_BEGIN ask, 256, 1                  ; AI_ASK "what is 12 plus 30", WRITE the reply, exit with its length
    mov rbx, rdi
    mov eax, 3
    mov rdi, rbx
    mov esi, 18
    lea rdx, [rbx+18]
    mov r10d, 200
    int 0x80
    mov r13, rax
    test rax, rax
    js .out
    mov eax, 1
    lea rdi, [rbx+18]
    mov rsi, r13
    int 0x80
.out:
    mov rdi, r13
    EXIT_RDI
VXE_DATA ask
    db "what is 12 plus 30"
VXE_END ask

; ---- no leakage between runs (same VAs, recycled frames) --------------------------------------------------------------
VXE_BEGIN leaka, 4088, 1               ; scribble a magic value over data, bss and the stack, then exit
    mov rax, 0xDEADBEEFCAFEBABE
    mov [rdi], rax
    mov [rdi+2000], rax
    mov [rdi+4000], rax
    mov ecx, 400
.l: push rax
    dec ecx
    jnz .l
    xor edi, edi
    EXIT_RDI
VXE_DATA leaka
    db "AAAAAAAA"
VXE_END leaka

VXE_BEGIN leakb, 4088, 1               ; same layout: bss and the whole stack page must read as zero
    mov rbx, rdi
    xor r13d, r13d
    cmp qword [rbx+2000], 0
    je .a
    inc r13
.a: cmp qword [rbx+4000], 0
    je .b
    inc r13
.b: mov rdx, rsp
    sub rdx, 3000                       ; 3000 bytes below the entry stack pointer (still inside the 4 KiB stack page)
    mov ecx, 300
.l: cmp qword [rdx], 0
    je .c
    inc r13
.c: add rdx, 8
    dec ecx
    jnz .l
    mov rdi, r13
    EXIT_RDI
VXE_DATA leakb
    db "BBBBBBBB"
VXE_END leakb
