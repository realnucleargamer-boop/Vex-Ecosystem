/*
 * Vex OS - kernel/src/arch/x86_64/acpi/power.c
 * ACPI S5 soft-off + reset.  See include/power.h.
 */
#include "power.h"
#include "acpi.h"
#include "serial.h"

static PowerInfo pi;

static inline void outb(uint16_t p, uint8_t v)  { __asm__ volatile("outb %0,%1" :: "a"(v), "Nd"(p)); }
static inline void outw(uint16_t p, uint16_t v) { __asm__ volatile("outw %0,%1" :: "a"(v), "Nd"(p)); }
static inline uint8_t  inb(uint16_t p) { uint8_t v;  __asm__ volatile("inb %1,%0" : "=a"(v) : "Nd"(p)); return v; }
static inline uint16_t inw(uint16_t p) { uint16_t v; __asm__ volatile("inw %1,%0" : "=a"(v) : "Nd"(p)); return v; }

/* Byte-wise little-endian loads: table fields are unaligned and we do not
 * rely on the CPU forgiving that (nor on the compiler not exploiting it). */
static uint8_t  rd8 (const uint8_t *b, uint32_t o) { return b[o]; }
static uint32_t rd32(const uint8_t *b, uint32_t o) { return (uint32_t)b[o] | ((uint32_t)b[o+1] << 8) | ((uint32_t)b[o+2] << 16) | ((uint32_t)b[o+3] << 24); }
static uint64_t rd64(const uint8_t *b, uint32_t o) { return (uint64_t)rd32(b, o) | ((uint64_t)rd32(b, o + 4) << 32); }

static int sum_ok(const uint8_t *p, uint32_t n) { uint8_t s = 0; for (uint32_t i = 0; i < n; i++) s = (uint8_t)(s + p[i]); return s == 0; }
static int sig4(const uint8_t *p, const char *s) { return p[0]==(uint8_t)s[0] && p[1]==(uint8_t)s[1] && p[2]==(uint8_t)s[2] && p[3]==(uint8_t)s[3]; }

/* ---- DSDT \_S5_ ------------------------------------------------------ *
 * AML:  [5C] 08 5F 53 35 5F  12 <PkgLength 1..4 bytes> <NumElements>
 *       <elem0 = SLP_TYPa> <elem1 = SLP_TYPb> ...
 * An element is ZeroOp (00), OneOp (01) or BytePrefix (0A) + byte.
 * Every read is bounds-checked against `len`; hostile lengths are refused. */
static int aml_int(const uint8_t *d, uint32_t len, uint32_t *pos, uint8_t *val)
{
    if (*pos >= len) return 0;
    uint8_t op = d[*pos];
    if (op == 0x00 || op == 0x01) { *val = op; (*pos)++; return 1; }
    if (op == 0x0A) { if (*pos + 1 >= len) return 0; *val = d[*pos + 1]; *pos += 2; return 1; }
    return 0;   /* Word/Dword/other encodings are not valid SLP_TYP values */
}

int power_parse_s5(const uint8_t *d, uint32_t len, uint8_t *typa, uint8_t *typb)
{
    if (!d || !typa || !typb || len < 12) return 0;
    for (uint32_t i = 1; i + 4 <= len; i++) {
        if (!(d[i]=='_' && d[i+1]=='S' && d[i+2]=='5' && d[i+3]=='_')) continue;
        /* Must be a NameOp definition, optionally root-prefixed - not a mere
         * mention of the string inside some other object. */
        int named = (d[i-1] == 0x08) || (i >= 2 && d[i-1] == 0x5C && d[i-2] == 0x08);
        if (!named) continue;
        uint32_t pos = i + 4;
        if (pos >= len || d[pos] != 0x12) continue;            /* PackageOp */
        pos++;
        if (pos >= len) return 0;
        uint32_t extra = (uint32_t)(d[pos] >> 6);              /* PkgLength follow-bytes */
        pos += 1 + extra;
        if (pos >= len) return 0;
        uint8_t nelem = d[pos++];
        if (nelem < 2) return 0;                               /* need TYPa and TYPb */
        uint8_t a, b;
        if (!aml_int(d, len, &pos, &a) || !aml_int(d, len, &pos, &b)) return 0;
        if (a > 7 || b > 7) return 0;                          /* SLP_TYP is a 3-bit field */
        *typa = a; *typb = b;
        return 1;
    }
    return 0;
}

/* ---- FADT ------------------------------------------------------------ */
#define FADT_MIN_LEN_PM   68    /* through PM1a_CNT_BLK/PM1b_CNT_BLK (+4)  */
#define FADT_OFF_SMI_CMD  48
#define FADT_OFF_ACPI_EN  52
#define FADT_OFF_PM1A_CNT 64
#define FADT_OFF_PM1B_CNT 68
#define FADT_OFF_FLAGS    112
#define FADT_OFF_RESET    116   /* GAS: space(1) width(1) off(1) size(1) addr(8) */
#define FADT_OFF_RESETVAL 128
#define FADT_FLAG_RESET_REG_SUP (1u << 10)

int power_parse_fadt(const uint8_t *f, uint32_t len, PowerInfo *o)
{
    if (!f || !o) return 0;
    *o = (PowerInfo){0};
    if (len < FADT_MIN_LEN_PM + 4 || !sig4(f, "FACP")) return 0;
    if (rd32(f, 4) != len) return 0;               /* header length must agree with what we were given */
    if (!sum_ok(f, len)) return 0;
    o->fadt_ok = 1;

    uint32_t smi = rd32(f, FADT_OFF_SMI_CMD);
    o->smi_cmd = (smi != 0 && smi <= 0xFFFFu) ? (uint16_t)smi : 0;
    o->acpi_enable = rd8(f, FADT_OFF_ACPI_EN);

    uint32_t a = rd32(f, FADT_OFF_PM1A_CNT), b = rd32(f, FADT_OFF_PM1B_CNT);
    /* PM1x_CNT_BLK are 32-bit I/O port numbers; anything above 0xFFFF is not
     * a legal x86 port and is treated as absent rather than truncated. */
    o->pm1a_cnt = (a != 0 && a <= 0xFFFFu) ? (uint16_t)a : 0;
    o->pm1b_cnt = (b != 0 && b <= 0xFFFFu) ? (uint16_t)b : 0;

    if (len >= FADT_OFF_RESETVAL + 1) {
        uint32_t flags = rd32(f, FADT_OFF_FLAGS);
        uint8_t  space = rd8(f, FADT_OFF_RESET);          /* 1 = SystemIO */
        uint8_t  width = rd8(f, FADT_OFF_RESET + 1);
        uint64_t addr  = rd64(f, FADT_OFF_RESET + 4);
        if ((flags & FADT_FLAG_RESET_REG_SUP) && space == 1 && (width == 8 || width == 0) && addr != 0 && addr <= 0xFFFFu) {
            o->reset_port  = (uint16_t)addr;
            o->reset_value = rd8(f, FADT_OFF_RESETVAL);
        }
    }
    return 1;
}

/* ---- discovery (needs firmware tables mapped) ----------------------- */
static const uint8_t *find_sdt(uint64_t root, uint32_t esz, const char *sig, uint32_t *outlen)
{
    const uint8_t *r = (const uint8_t *)(uintptr_t)root;
    if (!sig4(r, esz == 8 ? "XSDT" : "RSDT")) return 0;
    uint32_t rl = rd32(r, 4);
    if (rl < 36 || !sum_ok(r, rl)) return 0;
    for (uint32_t i = 0; i < (rl - 36) / esz; i++) {
        uint64_t pa = esz == 8 ? rd64(r, 36 + i * 8) : rd32(r, 36 + i * 4);
        if (!pa) continue;
        const uint8_t *t = (const uint8_t *)(uintptr_t)pa;
        if (sig4(t, sig)) { *outlen = rd32(t, 4); return t; }
    }
    return 0;
}

int power_init(uint64_t rsdp_phys)
{
    pi = (PowerInfo){0};
    if (!rsdp_phys) { serial_puts("[power] no RSDP - power control unavailable\n"); return 0; }
    const uint8_t *rsdp = (const uint8_t *)(uintptr_t)rsdp_phys;
    uint8_t rev = rd8(rsdp, 15);
    uint64_t xsdt = rev >= 2 ? rd64(rsdp, 24) : 0;
    uint32_t rsdt = rd32(rsdp, 16);

    uint32_t flen = 0;
    const uint8_t *fadt = 0;
    if (xsdt) fadt = find_sdt(xsdt, 8, "FACP", &flen);
    if (!fadt && rsdt) fadt = find_sdt(rsdt, 4, "FACP", &flen);
    if (!fadt) { serial_puts("[power] FADT (FACP) not found\n"); return 0; }
    if (flen > 4096u * 4u || !power_parse_fadt(fadt, flen, &pi)) {
        serial_puts("[power] FADT failed validation\n");
        pi = (PowerInfo){0};
        return 0;
    }

    /* DSDT: prefer X_DSDT (offset 140) when the table is long enough and non-zero. */
    uint64_t dsdt_pa = 0;
    if (flen >= 148) dsdt_pa = rd64(fadt, 140);
    if (!dsdt_pa && flen >= 44) dsdt_pa = rd32(fadt, 40);
    if (dsdt_pa) {
        const uint8_t *dsdt = (const uint8_t *)(uintptr_t)dsdt_pa;
        uint32_t dlen = rd32(dsdt, 4);
        /* Cap at 1 MiB: real DSDTs are tens of KiB; a bogus length must not
         * send the scanner through arbitrary memory. */
        if (sig4(dsdt, "DSDT") && dlen >= 36 && dlen <= (1u << 20) && sum_ok(dsdt, dlen)) {
            uint8_t ta, tb;
            if (power_parse_s5(dsdt, dlen, &ta, &tb)) { pi.slp_typa = ta; pi.slp_typb = tb; pi.shutdown_ok = pi.pm1a_cnt != 0; }
            else serial_puts("[power] DSDT has no usable \\_S5_ object\n");
        } else serial_puts("[power] DSDT failed validation\n");
    } else serial_puts("[power] FADT has no DSDT pointer\n");

    /* Reboot: ACPI reset register if the FADT advertises one; otherwise the
     * i8042 pulse-reset line, but only if a controller is actually present
     * (an absent one floats the bus to 0xFF). */
    if (pi.reset_port) { pi.reboot_ok = 1; pi.reboot_via_acpi = 1; }
    else if (inb(0x64) != 0xFF) { pi.reboot_ok = 1; pi.reboot_via_acpi = 0; }

    serial_puts("[power] FADT ok: PM1a_CNT=");  serial_put_hex64(pi.pm1a_cnt);
    serial_puts(" SLP_TYPa=");                    serial_put_dec64(pi.slp_typa);
    serial_puts(" SMI_CMD=");                     serial_put_hex64(pi.smi_cmd);
    serial_puts(" reset=");                       serial_put_hex64(pi.reset_port);
    serial_puts("\n[power] shutdown ");           serial_puts(pi.shutdown_ok ? "AVAILABLE (ACPI S5)" : "UNAVAILABLE");
    serial_puts(", reboot ");                     serial_puts(pi.reboot_ok ? (pi.reboot_via_acpi ? "AVAILABLE (ACPI reset register)" : "AVAILABLE (i8042 pulse)") : "UNAVAILABLE");
    serial_puts("\n");
    return pi.shutdown_ok || pi.reboot_ok;
}

const PowerInfo *power_info(void) { return &pi; }
int power_can_shutdown(void) { return pi.shutdown_ok; }
int power_can_reboot(void)   { return pi.reboot_ok; }
const char *power_shutdown_method(void) { return pi.shutdown_ok ? "ACPI S5 soft-off via PM1a_CNT" : "no ACPI S5 support found"; }
const char *power_reboot_method(void)   { return pi.reboot_ok ? (pi.reboot_via_acpi ? "ACPI reset register" : "i8042 reset line") : "no reset mechanism found"; }

/* ---- actions --------------------------------------------------------- */
static uint64_t save_flags_cli(void) { uint64_t f; __asm__ volatile("pushfq; pop %0; cli" : "=r"(f) :: "memory"); return f; }
static void restore_flags(uint64_t f) { if (f & (1u << 9)) __asm__ volatile("sti" ::: "memory"); }
static void spin(uint32_t n) { for (uint32_t i = 0; i < n; i++) __asm__ volatile("pause"); }

void power_shutdown(void)
{
    if (!pi.shutdown_ok) return;
    uint64_t fl = save_flags_cli();

    /* ACPI mode must be on (PM1_CNT.SCI_EN).  If firmware left it off and
     * gave us an enable command, issue it and wait (bounded) for SCI_EN. */
    if (!(inw(pi.pm1a_cnt) & 1u) && pi.smi_cmd && pi.acpi_enable) {
        outb(pi.smi_cmd, pi.acpi_enable);
        for (uint32_t i = 0; i < 300000u && !(inw(pi.pm1a_cnt) & 1u); i++) spin(1);
    }
    /* Preserve non-sleep bits (SCI_EN etc.), set SLP_TYP and SLP_EN. */
    uint16_t base = (uint16_t)(inw(pi.pm1a_cnt) & ~((7u << 10) | (1u << 13)));
    outw(pi.pm1a_cnt, (uint16_t)(base | ((uint16_t)pi.slp_typa << 10) | (1u << 13)));
    if (pi.pm1b_cnt) {
        uint16_t bb = (uint16_t)(inw(pi.pm1b_cnt) & ~((7u << 10) | (1u << 13)));
        outw(pi.pm1b_cnt, (uint16_t)(bb | ((uint16_t)pi.slp_typb << 10) | (1u << 13)));
    }
    /* On real power-off this never returns.  Give the platform a bounded
     * moment, then report failure rather than claim success. */
    spin(5000000u);
    restore_flags(fl);
}

void power_reboot(void)
{
    if (!pi.reboot_ok) return;
    uint64_t fl = save_flags_cli();
    if (pi.reboot_via_acpi) {
        outb(pi.reset_port, pi.reset_value);
        spin(5000000u);
    } else {
        for (uint32_t i = 0; i < 100000u && (inb(0x64) & 2u); i++) spin(1);   /* wait IBF clear */
        outb(0x64, 0xFE);                                                     /* pulse CPU reset */
        spin(5000000u);
    }
    restore_flags(fl);
}
