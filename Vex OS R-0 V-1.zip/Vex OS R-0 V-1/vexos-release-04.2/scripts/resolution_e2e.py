#!/usr/bin/env python3
"""Vex OS - scripts/resolution_e2e.py : boot the seeded image at several GOP resolutions and exercise the desktop + Wallpaper page.
Resolution is forced with QEMU `-vga none -device VGA,xres=,yres=` (OVMF exposes it as the GOP mode). Usage: resolution_e2e.py <seeded.img> [WxH ...]"""
import os, re, sys, time
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
from qemu_drive import Vm, ppm_to_png, load_ppm
from PIL import Image, ImageChops
import make_wallpapers as MW
IMG = sys.argv[1]; MODES = [tuple(map(int, a.split("x"))) for a in sys.argv[2:]] or [(640, 480), (800, 600), (1024, 600), (1024, 768), (1280, 800), (1360, 768), (1920, 1080)]
OUT = "build/resolution"; os.makedirs(OUT, exist_ok=True); res = []
SRC = os.path.join(os.path.dirname(__file__), "..", "assets", "wallpapers", "src")
NAVY = (5, 18, 34)
def check(ok, w, d=""): res.append(bool(ok)); print(("PASS  " if ok else "FAIL  ") + w + (f"  [{d}]" if d and not ok else ""), flush=True)
def cnt(vm, p): return len(re.findall(p, vm.serial()))
def last_line(vm, tag):
    ls = [l for l in vm.serial().splitlines() if tag in l]; return ls[-1] if ls else ""
def rects(vm, tag):
    l = last_line(vm, tag); return {m.group(1): tuple(map(int, m.groups()[1:])) for m in re.finditer(r"(\w+)=\((\d+),(\d+),(\d+),(\d+)\)", l)}
def all_rects(vm, tag, name): return [tuple(map(int, m.groups())) for m in re.finditer(name + r"=\((\d+),(\d+),(\d+),(\d+)\)", last_line(vm, tag))]
def mr(vm, dx, dy):
    while dx or dy:
        sx = max(-100, min(100, dx)); sy = max(-100, min(100, dy)); vm.mouse_move(sx, sy); dx -= sx; dy -= sy; time.sleep(0.03)
    time.sleep(0.3)
def clk(vm, x, y): mr(vm, -3000, -2000); mr(vm, x, y); vm.mouse_button(1); time.sleep(0.25); vm.mouse_button(0); time.sleep(0.8)
def click(vm, r): clk(vm, r[0] + r[2] // 2, r[1] + r[3] // 2)
K = {" ": "spc", ".": "dot", "\n": "ret"}
def typ(vm, s):
    for c in s: vm.sendkey(K.get(c) or c); time.sleep(0.11)
    time.sleep(0.5)
def shot(vm, n):
    p = f"{OUT}/{n}.ppm"; vm.screendump(p); ppm_to_png(p, f"{OUT}/{n}.png"); return load_ppm(p).convert("RGB")
def expected(W, H, stem="blue-flow"):
    im = MW.remove_corner_mark(Image.open(os.path.join(SRC, stem + ".png")).convert("RGB"))
    if W * im.height >= H * im.width: sw, sh = W, max(H, -(-im.height * W // im.width))
    else: sw, sh = max(W, -(-im.width * H // im.height)), H
    r = im.resize((sw, sh), Image.BICUBIC); cx, cy = (sw - W) // 2, (sh - H) // 2; return r.crop((cx, cy, cx + W, cy + H))
def mae(a, b, box):
    d = ImageChops.difference(a.crop(box), b.crop(box)).convert("L"); h = d.histogram(); return sum(k * v for k, v in enumerate(h)) / max(1, sum(h))
def inside(r, W, H): return r[0] >= 0 and r[1] >= 0 and r[2] > 0 and r[3] > 0 and r[0] + r[2] <= W and r[1] + r[3] <= H
for (W, H) in MODES:
    tag = f"{W}x{H}"; print(f"--- {tag}", flush=True)
    vm = Vm(IMG, OUT, tag=tag, extra=["-vga", "none", "-device", f"VGA,xres={W},yres={H}"])
    try:
        vm.wait_serial(r"\[ui\] lock screen shown", 200); time.sleep(1.2)
        m = re.search(r"\[gfx\] framebuffer: (\d+)x(\d+)", vm.serial()); check(m and (int(m[1]), int(m[2])) == (W, H), f"{tag}: kernel booted with a {W}x{H} framebuffer", m and m[0])
        typ(vm, "vexpass1\n"); time.sleep(1.8); D = rects(vm, "desktop shown")
        check(D and all(inside(r, W, H) for r in D.values()), f"{tag}: desktop icons/taskbar all inside the screen", str(D))
        d0 = shot(vm, tag + "_desktop"); check(d0.getpixel((2, H // 2)) == NAVY and d0.getpixel((W - 3, H // 2)) == NAVY, f"{tag}: default desktop is the exact navy")
        click(vm, D["sett"]); time.sleep(0.5); S = rects(vm, "settings view shown")
        check(S and all(inside(r, W, H) for r in S.values()), f"{tag}: Settings window and its controls are inside the screen", str(S))
        tc = S["tclose"]; cx, cy = tc[0] + 40 - 1000, tc[1] - 6
        # Wallpaper row: use the focus ring free approach - click row 6 via Tab-free geometry from the layout line if present
        rows = all_rects(vm, "settings view shown", "row"); 
        if rows and len(rows) >= 6: click(vm, rows[5])
        else: clk(vm, cx + 121, cy + 52 + 5 * 36 + 16)
        time.sleep(0.6); tiles = all_rects(vm, "[ui] layout", "wptile"); AP = all_rects(vm, "[ui] layout", "wpapply"); RS = all_rects(vm, "[ui] layout", "wpreset")
        check(len(tiles) == 7 and AP and RS, f"{tag}: Wallpaper page shows 7 tiles + Apply + Reset", f"{len(tiles)} {AP}")
        ok_in = tiles and all(inside(r, W, H) for r in tiles + AP + RS)
        w = shot(vm, tag + "_page"); check(ok_in, f"{tag}: every wallpaper control is on screen", str(tiles[:2]))
        if len(tiles) == 7 and AP:
            click(vm, tiles[3]); click(vm, AP[0]); time.sleep(1.5)
            check(cnt(vm, r"\[wallpaper\] applied Blue Flow") == 1, f"{tag}: Apply succeeds", last_line(vm, "[wallpaper]"))
            click(vm, rects(vm, "settings view shown")["tmin"]); time.sleep(0.8); a = shot(vm, tag + "_applied")
            e = expected(W, H); err = mae(a, e, (0, 0, W, H - 70))
            check(err < 12, f"{tag}: real desktop shows the wallpaper scaled to the actual screen (mean error {err:.1f} < 12)", f"{err:.1f}")
            check(re.search(rf"cache allocated \((\d+) bytes for {W}x{H}\)", vm.serial()) and 0 <= int(re.search(rf"cache allocated \((\d+) bytes for {W}x{H}\)", vm.serial())[1]) - W * H * 4 < 4096, f"{tag}: cache is {W}x{H}x4 = {W*H*4} bytes rounded up to a whole 4 KiB page")
        check(vm.alive() and "PANIC" not in vm.serial() and "UNHANDLED CPU EXCEPTION" not in vm.serial(), f"{tag}: no panic / CPU exception")
    except Exception as ex: check(False, f"{tag}: run aborted", repr(ex)[:200])
    finally: vm.stop()
print(f"\n{sum(res)}/{len(res)} resolution checks passed"); sys.exit(0 if all(res) else 1)
