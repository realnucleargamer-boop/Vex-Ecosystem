/*
 * Vex OS - kernel/src/graphics/gfx_text.c
 *
 * Glyph rendering (8x16 bitmap font) and scrolling GfxConsole.
 * The font bitmap is in gfx_font8x16.c as gfx_font8x16[96][16].
 * No SSE.  No heap.  No static state beyond the font table itself.
 */

#include "gfx/text.h"
#include "gfx/vecfont.h"

/* Forward declaration of the font bitmap. */
extern const uint8_t gfx_font8x16[96][16];

/* SECURITY-02: upper bound on characters a single string call will
 * render or measure. Every string in the kernel today is a short static
 * literal or a bounded status message, so this changes no existing
 * output - it exists so that a missing terminator or a hostile length
 * can never turn a draw call into an unbounded loop or push the pen
 * position past int32_t. 4096 characters is 32768 px at 8 px/glyph,
 * already wider than any framebuffer gfx_fb_init() accepts. */
#define GFX_STR_MAX 4096

/* ------------------------------------------------------------------ */
/* Single glyph and string rendering                                   */
/* ------------------------------------------------------------------ */

void gfx_draw_char(const GfxFb *fb, int32_t px, int32_t py,
                   char c, GfxColor fg, GfxColor bg)
{
    if (!fb || !fb->ok) return;

    /* GFX-VEC-01: smooth vector glyph when enabled and the whole cell is on screen; otherwise the clipped bitmap path below. */
    if (vec_aa() && vf_draw_cell(fb, px, py, (unsigned char)c, fg, bg)) return;

    /* Map to our glyph table: 0x20–0x7E, anything else -> space. */
    unsigned int idx = (unsigned int)c;
    if (idx < 0x20 || idx > 0x7E) idx = 0x20;
    idx -= 0x20;

    const uint8_t *glyph = gfx_font8x16[idx];
    for (int row = 0; row < GFX_FONT_H; row++) {
        uint8_t bits = glyph[row];
        for (int col = 0; col < GFX_FONT_W; col++) {
            GfxColor pixel = (bits & (0x80 >> col)) ? fg : bg;
            /* int64: px + col overflowed int32_t (undefined behaviour)
             * for a pen near INT32_MAX. A coordinate that does not fit
             * int32_t is off-screen by definition, so skip it. */
            int64_t gx = (int64_t)px + col, gy = (int64_t)py + row;
            if (gx < INT32_MIN || gx > INT32_MAX ||
                gy < INT32_MIN || gy > INT32_MAX) continue;
            gfx_put(fb, (int32_t)gx, (int32_t)gy, pixel);
        }
    }
}

int32_t gfx_draw_str(const GfxFb *fb, int32_t px, int32_t py,
                     const char *s, GfxColor fg, GfxColor bg)
{
    if (!s) return px;
    int64_t x = px;
    for (int n = 0; *s && n < GFX_STR_MAX; n++, s++) {
        if (x >= INT32_MIN && x <= INT32_MAX)
            gfx_draw_char(fb, (int32_t)x, py, *s, fg, bg);
        x += GFX_FONT_W;
    }
    if (x > INT32_MAX) x = INT32_MAX;
    if (x < INT32_MIN) x = INT32_MIN;
    return (int32_t)x;
}

void gfx_draw_str_right(const GfxFb *fb, int32_t rx, int32_t py,
                        const char *s, GfxColor fg, GfxColor bg)
{
    /* Measure length. */
    if (!s) return;
    int64_t len = 0;
    const char *p = s;
    while (*p++ && len < GFX_STR_MAX) len++;
    int64_t start = (int64_t)rx - len * GFX_FONT_W;
    if (start < INT32_MIN || start > INT32_MAX) return;
    gfx_draw_str(fb, (int32_t)start, py, s, fg, bg);
}

/* ------------------------------------------------------------------ */
/* Scrolling console                                                   */
/* ------------------------------------------------------------------ */

int gfx_console_init(GfxConsole *con, const GfxFb *fb,
                     int32_t x, int32_t y, int32_t w, int32_t h,
                     GfxColor fg, GfxColor bg)
{
    con->ok = 0;
    if (!con || !fb || !fb->ok || w < GFX_FONT_W || h < GFX_FONT_H) return 0;

    /* SECURITY-02 Graphics audit finding: console_scroll() copies pixels
     * with raw `row * pitch_px + col` indexing and no clip, trusting that
     * the console area lies inside the framebuffer. Nothing checked that.
     * An area extending past fb->width/height made every scroll an
     * out-of-bounds read AND write. Validating once here, in 64-bit so
     * the check itself cannot overflow, makes the scroll blit safe by
     * construction instead of by the caller's good behaviour. */
    if ((int64_t)x < 0 || (int64_t)y < 0 ||
        (int64_t)x + w > (int64_t)fb->width ||
        (int64_t)y + h > (int64_t)fb->height) return 0;

    con->fb       = fb;
    con->origin_x = x;
    con->origin_y = y;
    con->area_w   = w;
    con->area_h   = h;
    con->cols     = (uint32_t)(w / GFX_FONT_W);
    con->rows     = (uint32_t)(h / GFX_FONT_H);
    con->cx       = 0;
    con->cy       = 0;
    con->fg       = fg;
    con->bg       = bg;
    con->ok       = 1;

    /* Clear the text area. */
    gfx_fill_rect(fb, x, y, w, h, bg);
    return 1;
}

/* Scroll the console up by one row. */
static void console_scroll(GfxConsole *con)
{
    const GfxFb *fb = con->fb;
    uint32_t row_h  = GFX_FONT_H;
    int32_t  src_y  = con->origin_y + (int32_t)row_h;
    int32_t  dst_y  = con->origin_y;
    int32_t  w      = con->area_w;
    uint32_t rows_to_copy = con->rows - 1;
    uint32_t total_h = rows_to_copy * row_h;

    /* Pixel blit: copy rows 1..rows-1 up to rows 0..rows-2. */
    for (uint32_t y = 0; y < total_h; y++) {
        uint32_t sy = (uint32_t)src_y + y;
        uint32_t dy = (uint32_t)dst_y + y;
        volatile uint32_t *src_line = fb->pixels + sy * fb->pitch_px;
        volatile uint32_t *dst_line = fb->pixels + dy * fb->pitch_px;
        int32_t ox = con->origin_x;
        for (int32_t x = 0; x < w; x++) {
            dst_line[(uint32_t)ox + (uint32_t)x] =
                src_line[(uint32_t)ox + (uint32_t)x];
        }
    }

    /* Blank the last row. */
    int32_t blank_y = con->origin_y + (int32_t)(rows_to_copy * row_h);
    gfx_fill_rect(fb, con->origin_x, blank_y, w, (int32_t)row_h, con->bg);

    if (con->cy > 0) con->cy--;
}

void gfx_console_putc(GfxConsole *con, char c)
{
    if (!con->ok) return;

    if (c == '\n') {
        con->cx = 0;
        con->cy++;
        if (con->cy >= con->rows) console_scroll(con);
        return;
    }

    if (con->cx >= con->cols) {
        con->cx = 0;
        con->cy++;
        if (con->cy >= con->rows) console_scroll(con);
    }

    int32_t px = con->origin_x + (int32_t)(con->cx * GFX_FONT_W);
    int32_t py = con->origin_y + (int32_t)(con->cy * GFX_FONT_H);
    gfx_draw_char(con->fb, px, py, c, con->fg, con->bg);
    con->cx++;
}

void gfx_console_puts(GfxConsole *con, const char *s)
{
    if (!con || !s) return;
    for (int n = 0; *s && n < GFX_STR_MAX; n++) gfx_console_putc(con, *s++);
}

void gfx_console_puts_col(GfxConsole *con, const char *s, GfxColor col)
{
    GfxColor saved = con->fg;
    con->fg = col;
    gfx_console_puts(con, s);
    con->fg = saved;
}

void gfx_console_put_u64(GfxConsole *con, uint64_t v)
{
    char buf[21];
    int i = 20;
    buf[i] = '\0';
    if (v == 0) { buf[--i] = '0'; }
    else { while (v > 0 && i > 0) { buf[--i] = (char)('0' + v % 10); v /= 10; } }
    gfx_console_puts(con, &buf[i]);
}

void gfx_console_put_i64(GfxConsole *con, int64_t v)
{
    /* `v = -v` is undefined for INT64_MIN. Negate in unsigned
     * arithmetic, which is defined for every value. */
    uint64_t u = (uint64_t)v;
    if (v < 0) { gfx_console_putc(con, '-'); u = (uint64_t)0 - u; }
    gfx_console_put_u64(con, u);
}
