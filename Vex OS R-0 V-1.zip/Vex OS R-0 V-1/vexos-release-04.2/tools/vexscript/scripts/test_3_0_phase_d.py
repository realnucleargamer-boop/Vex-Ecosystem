#!/usr/bin/env python3
"""VexScript 3.0-D — evolution primitives + deterministic RNG"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vexscript import __version__, __ir_version__
from vexscript.interpreter import Interpreter
from vexscript.compile_ir import run_via_ir
from vexscript.evolve_rt import (
    evolve_create, evolve_size, evolve_randomize, evolve_mutate, evolve_crossover,
    evolve_select_tournament, evolve_get, reset_evolve_state,
)
from vexscript.tensor_rt import tensor_create, tensor_fill

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

print("VexScript 3.0-D")
check("version", __version__.startswith("3."), __version__)
check("ir 1.4", __ir_version__ == "1.4", __ir_version__)

# pure evolve with fixed rng
state = [12345]
def rng():
    state[0] = (state[0] + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
    z = state[0]
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9 & 0xFFFFFFFFFFFFFFFF
    z = (z ^ (z >> 27)) * 0x94D049BB133111EB & 0xFFFFFFFFFFFFFFFF
    return z ^ (z >> 31)

reset_evolve_state()
pid = evolve_create(4, 8)
check("create size", evolve_size(pid) == 4)
evolve_randomize(pid, rng, 1.0)
c0 = evolve_get(pid, 0)
m = evolve_mutate(c0, rng, 500, 0.1)
check("mutate rank", m.shape == c0.shape, m.shape)
a = tensor_fill(tensor_create("f32", 4), 1.0)
b = tensor_fill(tensor_create("f32", 4), 2.0)
x = evolve_crossover(a, b, rng)
check("crossover", x.shape == (4,) and all(v in (1.0, 2.0) for v in x.data), x.data)
idx = evolve_select_tournament([1.0, 9.0, 3.0, 2.0], 3, rng)
check("select range", 0 <= idx < 4, idx)

# deterministic language path
src = '''
fn main() -> i32 {
    rng_seed(999);
    let pop = evolve_create(4, 4);
    evolve_randomize(pop);
    println(evolve_size(pop));
    let a = evolve_get(pop, 0);
    let b = evolve_get(pop, 1);
    let c = evolve_crossover(a, b);
    let d = evolve_mutate(c, 300);
    evolve_set(pop, 2, d);
    let winner = evolve_select_tournament(1, 5, 3, 2, 2);
    println(winner);
    return 0;
}
'''
i = Interpreter(); i.load(src, "t"); code = i.run_main(); o1 = list(i.output)
j = Interpreter(); j.load(src, "t"); j.run_main(); o2 = list(j.output)
check("ast evolve run", code == 0 and o1[0] in ("4", 4, "4.0"), o1)
check("ast deterministic", o1 == o2, (o1, o2))

code, out = run_via_ir(src)
check("ir evolve", code == 0 and "4" in out, out)
code2, out2 = run_via_ir(src)
check("ir deterministic", out == out2, (out, out2))

# neural still works
src_n = '''
fn main() -> i32 {
    let x = tensor_create_2(1, 2);
    tensor_fill(x, 1);
    let w = tensor_create_2(2, 2);
    tensor_fill(w, 1);
    let y = neural_linear(x, w);
    println(tensor_get_2(y, 0, 0));
    return 0;
}
'''
code, out = run_via_ir(src_n)
check("compat neural", code == 0 and "2" in out, out)

print(f"\n=== 3.0-D Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
