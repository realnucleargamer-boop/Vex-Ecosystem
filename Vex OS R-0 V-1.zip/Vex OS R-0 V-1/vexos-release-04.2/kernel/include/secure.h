/*
 * Vex OS - kernel/include/secure.h
 *
 * SECURITY-01: security primitives and auditing.
 *
 * SCOPE, STATED HONESTLY UP FRONT
 *
 *   SECURITY-01 was specified as a hardening pass over a USER-01 Ring 3
 *   boundary. That boundary DOES NOT EXIST in this repository: there is
 *   no Ring 3 entry, no per-process address space, no syscall path, and
 *   no user program. `grep -r sysret kernel/` finds nothing, and gdt.h
 *   marks its user selectors "placeholder - unused".
 *
 *   Therefore this file does NOT pretend to validate user pointers
 *   arriving from Ring 3. It does two things that are real today:
 *
 *     1. Builds the validation and overflow primitives such a boundary
 *        will need, and tests them against hostile inputs directly, so
 *        that USER-01 inherits audited code instead of writing new
 *        unaudited code at the worst possible place.
 *
 *     2. Audits and hardens the invariants that already exist and are
 *        already load-bearing: no kernel mapping may carry the USER bit,
 *        W^X where achievable, canonical-address discipline, and the
 *        privilege fields of the descriptor tables.
 *
 *   Anything requiring CPL 3 to observe is reported as
 *   "NOT APPLICABLE - NO USERSPACE", never as PASS. See
 *   docs/SECURITY-01.md.
 *
 * THREAT MODEL FOR WHAT IS HERE
 *
 *   The range checker is written as if `base` and `len` were supplied by
 *   an attacker, because that is what they will be. It is used today by
 *   kernel callers with kernel-chosen arguments, which is exactly why it
 *   must be tested with hostile arguments now - a checker only exercised
 *   on well-formed input has not been shown to reject anything.
 */

#ifndef VEXOS_SECURE_H
#define VEXOS_SECURE_H

#include <stdint.h>

/* ------------------------------------------------------------------ *
 * Canonical addresses
 *
 * x86-64 with 4-level paging requires bits 63:47 of a linear address to
 * be all zeros or all ones. Anything else is non-canonical and faults
 * with #GP rather than #PF - which matters, because a validator that
 * only ever anticipates #PF will mis-handle it.
 * ------------------------------------------------------------------ */

#define SEC_CANONICAL_LOW_MAX   0x00007FFFFFFFFFFFULL
#define SEC_CANONICAL_HIGH_MIN  0xFFFF800000000000ULL

/* 1 if `addr` is canonical for 4-level paging. */
int sec_is_canonical(uint64_t addr);

/* ------------------------------------------------------------------ *
 * Overflow-checked arithmetic
 *
 * Every one of these exists because unsigned wraparound is defined
 * behaviour in C and therefore silent. `base + len` wrapping to a small
 * number is how a range check gets talked into approving a range that
 * covers the whole address space.
 * ------------------------------------------------------------------ */

/* 1 on success (no overflow) with the result in *out; 0 on overflow,
 * and *out is then left untouched so a caller that ignores the return
 * value does not silently get a wrapped value it can use. */
int sec_add_ovf(uint64_t a, uint64_t b, uint64_t *out);
int sec_mul_ovf(uint64_t a, uint64_t b, uint64_t *out);

/* ------------------------------------------------------------------ *
 * Range validation
 * ------------------------------------------------------------------ */

typedef enum {
    SEC_RANGE_OK = 0,
    SEC_ERR_ZERO_LEN,        /* len == 0 and the caller disallowed it */
    SEC_ERR_OVERFLOW,        /* base + len wraps */
    SEC_ERR_NON_CANONICAL,   /* base, or the last byte, is non-canonical */
    SEC_ERR_STRADDLES_HOLE,  /* range spans the non-canonical gap */
    SEC_ERR_OUT_OF_WINDOW,   /* range leaves the permitted window */
    SEC_ERR_NOT_MAPPED,      /* some page in the range is not present */
    SEC_ERR_NOT_WRITABLE,    /* write access wanted, page is read-only */
    SEC_ERR_IS_USER,         /* page carries USER - must not, for kernel */
    SEC_ERR_BAD_WINDOW       /* window descriptor itself is nonsense */
} SecResult;

const char *sec_result_name(SecResult r);

/* A permitted address window, half-open: [base, base+size). */
typedef struct {
    uint64_t base;
    uint64_t size;
} SecWindow;

#define SEC_ACCESS_READ   0x1u
#define SEC_ACCESS_WRITE  0x2u

/* Validates that EVERY byte of [base, base+len) is safe for `access`.
 *
 * The whole range, not the first byte. This is the entire point of the
 * function and the reason it takes a length at all: a check that
 * validates `ptr` and then lets the caller touch `ptr + len` has
 * validated nothing about the bytes that matter.
 *
 * Order of checks is deliberate. Overflow is tested BEFORE anything
 * derived from base+len is computed, because every later check would
 * otherwise be reasoning about a wrapped address. Canonicality is tested
 * on both the first and the LAST byte, because a range can begin
 * canonical and end inside the hole.
 *
 * `allow_zero_len` selects whether a zero-length range is vacuously
 * fine (it touches nothing) or a rejected malformed request. Both are
 * defensible; making the caller state which prevents the ambiguity from
 * being resolved differently in two places.
 *
 * `check_mappings` walks the page tables for EVERY page in the range.
 * With it clear, only the arithmetic and window checks run. Callers that
 * are about to dereference memory must pass 1.
 */
SecResult sec_check_range(uint64_t base, uint64_t len,
                          const SecWindow *window,
                          uint32_t access,
                          int allow_zero_len,
                          int check_mappings);

/* The kernel windows, as SecWindows, for callers and tests. */
const SecWindow *sec_window_kmap(void);
const SecWindow *sec_window_direct_map(void);

/* ------------------------------------------------------------------ *
 * Page-table auditing
 *
 * These walk the LIVE page tables through their identity addresses and
 * report what the hardware would actually see. They deliberately do not
 * consult the code that built the tables: "we intended no USER bits" and
 * "there are no USER bits" are different claims, and only the second is
 * evidence.
 * ------------------------------------------------------------------ */

typedef struct {
    uint64_t entries_walked;     /* present entries examined, all levels */
    uint64_t leaves;             /* leaf mappings (4 KiB PTEs + 2 MiB PDEs) */
    uint64_t user_pml4;          /* present PML4Es with USER set */
    uint64_t user_pdpt;
    uint64_t user_pd;
    uint64_t user_pt;
    uint64_t user_total;         /* sum of the four above */
    uint64_t wx_leaves;          /* present, writable, NOT NX - i.e. W+X */
    uint64_t wx_identity;        /* of those, inside the identity map */
    uint64_t wx_direct_map;      /* of those, inside the direct map */
    uint64_t wx_kmap;            /* of those, inside the kmap window */
    uint64_t wx_other;           /* anywhere else - should be zero */
    uint64_t nx_leaves;          /* present leaves with NX set */
} SecPageAudit;

/* Walks the entire live hierarchy from CR3. Returns 1 if the walk
 * completed, 0 if the tables could not be read at all. */
int sec_audit_page_tables(SecPageAudit *out);

/* ------------------------------------------------------------------ *
 * CPU security features
 *
 * Reported, and separately: enabled or not. SMEP and SMAP are only
 * meaningful once Ring 3 exists, and enabling SMAP in particular changes
 * how the kernel is permitted to touch user memory - so this milestone
 * probes and reports rather than switching things on underneath an
 * architecture that has no user memory to protect. See
 * docs/SECURITY-01-DESIGN-NOTE.md.
 * ------------------------------------------------------------------ */

typedef struct {
    int smep_supported;   /* CPUID.(EAX=7,ECX=0):EBX bit 7 */
    int smap_supported;   /* CPUID.(EAX=7,ECX=0):EBX bit 20 */
    int umip_supported;   /* CPUID.(EAX=7,ECX=0):ECX bit 2 */
    int fsgsbase_supported; /* CPUID.(EAX=7,ECX=0):EBX bit 0 */
    int nx_supported;     /* CPUID.80000001:EDX bit 20 */
    int smep_enabled;     /* CR4 bit 20 */
    int smap_enabled;     /* CR4 bit 21 */
    int umip_enabled;     /* CR4 bit 11 */
    int fsgsbase_enabled; /* CR4 bit 16 */
    int nx_enabled;       /* EFER bit 11 */
    uint64_t cr4;
    uint64_t efer;
} SecCpuFeatures;

void sec_cpu_features(SecCpuFeatures *out);

/* ------------------------------------------------------------------ *
 * Faulting probes
 *
 * A security test that asks the kernel whether an access is denied is
 * worthless. These make the CPU answer.
 *
 * Each probe performs one real access and returns 1 if it completed or 0
 * if it faulted. On a fault, the exception is recorded and control
 * resumes at a fixup point inside the probe itself - the fault is
 * genuinely taken, delivered, and reported by the CPU. Nothing is
 * repaired, because for these tests the access is SUPPOSED to stay
 * denied; repairing it would destroy the evidence.
 *
 * Implemented in kernel/src/security/probe.asm with the fixup hook in
 * idt.c. Single-slot and BSP-only, exactly like BOOT-03's page-fault
 * expectation, and for the same reason: it must stay a test instrument
 * and not quietly become an exception-handling subsystem.
 * ------------------------------------------------------------------ */

/* 1 = access completed, 0 = it faulted. */
int sec_probe_read8(uint64_t addr, uint8_t *out);
int sec_probe_write8(uint64_t addr, uint8_t value);
int sec_probe_exec(uint64_t addr);

/* Details of the last probe fault: vector, error code, CR2, and the CS
 * recorded in the frame (so a test can assert the fault was taken at
 * CPL 0, which is the only privilege level that exists here). Returns 1
 * if any probe has faulted since the counter was last read. */
int sec_probe_last_fault(uint64_t *out_vector, uint64_t *out_error,
                         uint64_t *out_cr2, uint64_t *out_cs);

/* Number of probe faults handled through the fixup path. */
uint64_t sec_probe_fault_count(void);

/* Internal, for idt.c only: if a probe is in flight, record `frame` and
 * redirect execution to the probe's fixup. Returns 1 if it did so, in
 * which case the handler must return without panicking. */
struct InterruptFrameTag;
int sec_probe_fixup(void *frame, uint64_t vector, uint64_t error_code,
                    uint64_t cr2);

#endif /* VEXOS_SECURE_H */
