<#
.SYNOPSIS
  SECURITY-02: makes build\runtime-esp match the artifacts the build just
  produced, and PROVES it by hash.

.DESCRIPTION
  Problem this fixes: the build writes build\BOOTX64.EFI and build\KERNEL.ELF,
  but run-vexos.ps1 boots build\runtime-esp\EFI\BOOT\BOOTX64.EFI and
  build\runtime-esp\KERNEL.ELF. Nothing copied the first pair to the second
  (run-vexos.ps1 even pointed at a scripts\build-runtime.ps1 that did not
  exist), so a successful build could leave the launcher booting a stale
  kernel - and a security test run against the wrong binary proves nothing.

  Default mode copies, then re-reads BOTH sides from disk and compares
  SHA-256. It throws (non-zero exit) on any mismatch or missing source.
  -VerifyOnly performs the comparison without copying; run-vexos.ps1 uses it
  to refuse to launch a stale ESP.
#>
[CmdletBinding()]
param(
    [string]$BuildDir,
    [switch]$VerifyOnly
)
$ErrorActionPreference = 'Stop'
if (-not $BuildDir) { $BuildDir = Join-Path (Split-Path -Parent $PSScriptRoot) 'build' }

$pairs = @(
    @{ Name='BOOTX64.EFI'; Src=(Join-Path $BuildDir 'BOOTX64.EFI');
       Dst=(Join-Path $BuildDir 'runtime-esp\EFI\BOOT\BOOTX64.EFI') },
    @{ Name='KERNEL.ELF';  Src=(Join-Path $BuildDir 'KERNEL.ELF');
       Dst=(Join-Path $BuildDir 'runtime-esp\KERNEL.ELF') }
)

foreach ($p in $pairs) {
    if (-not (Test-Path -LiteralPath $p.Src)) {
        throw "Runtime ESP sync: build artifact missing: $($p.Src). Build first."
    }
    if (-not $VerifyOnly) {
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $p.Dst) | Out-Null
        Copy-Item -LiteralPath $p.Src -Destination $p.Dst -Force
    }
    if (-not (Test-Path -LiteralPath $p.Dst)) {
        throw "Runtime ESP is missing $($p.Name). Run build.ps1 (it syncs automatically)."
    }
    $hs = (Get-FileHash -LiteralPath $p.Src -Algorithm SHA256).Hash
    $hd = (Get-FileHash -LiteralPath $p.Dst -Algorithm SHA256).Hash
    if ($hs -ne $hd) {
        throw "Runtime ESP is STALE: $($p.Name) differs from the current build.`n  build:       $hs`n  runtime-esp: $hd"
    }
    Write-Host ("  runtime-esp {0}: SHA-256 {1} (matches build)" -f $p.Name, $hs.Substring(0,16)) -ForegroundColor DarkGray
}
Write-Host "Runtime ESP verified: contains the current build artifacts." -ForegroundColor Green
