#include "user.h"
#define VEX_MAX_SERVICES 16u
typedef struct { uint32_t caps; uint32_t generation; int active; } Service;
static Service services[VEX_MAX_SERVICES];
void user_init(void) { for(uint32_t i=0;i<VEX_MAX_SERVICES;i++) services[i].active=0; }
VexHandle user_kernel_service_register(uint32_t caps) { for(uint32_t i=0;i<VEX_MAX_SERVICES;i++) if(!services[i].active) { services[i].active=1; services[i].caps=caps; services[i].generation++; return ((services[i].generation & 0xffffu)<<16)|(i+1u); } return 0; }
int user_handle_validate(VexHandle h,uint32_t cap) { uint32_t i=(h&0xffffu); uint32_t g=h>>16; if(!i||i>VEX_MAX_SERVICES) return 0; Service *s=&services[i-1]; return s->active && s->generation==g && (s->caps&cap)==cap; }
uint32_t user_service_count(void) { uint32_t n=0; for(uint32_t i=0;i<VEX_MAX_SERVICES;i++) n+=services[i].active; return n; }
