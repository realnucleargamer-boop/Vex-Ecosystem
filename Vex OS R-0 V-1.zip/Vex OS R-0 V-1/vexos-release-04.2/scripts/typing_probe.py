#!/usr/bin/env python3
"""Vex OS - scripts/typing_probe.py : counts FULL-SCREEN redraws caused by typing, per input context, in real QEMU.
The kernel logs '[gfx] full-screen redraw #N' for every executed full redraw. A burst of K typed characters must
add 0 (ideal) full redraws.  Usage: python3 scripts/typing_probe.py build/vexos-seed.img"""
import os, re, sys, time
sys.path.insert(0, os.path.dirname(__file__))
from qemu_drive import Vm
IMG = sys.argv[1] if len(sys.argv) > 1 else "build/vexos-seed.img"; OUT = "build/typing"; os.makedirs(OUT, exist_ok=True)
def full(vm): return tuple(len(re.findall(q, vm.serial())) for q in (r"\[gfx\] full-screen redraw", r"\[gfx\] region repaint", r"\[gfx\] terminal content redraw"))
def rects(vm, tag):
    ls = [l for l in vm.serial().splitlines() if tag in l]
    return {m.group(1): tuple(map(int, m.groups()[1:])) for m in re.finditer(r"(\w+)=\((\d+),(\d+),(\d+),(\d+)\)", ls[-1])} if ls else {}
def mr(vm, dx, dy):
    while dx or dy:
        sx = max(-100, min(100, dx)); sy = max(-100, min(100, dy)); vm.mouse_move(sx, sy); dx -= sx; dy -= sy; time.sleep(0.03)
    time.sleep(0.3)
def click(vm, r): mr(vm, -1500, -1000); mr(vm, r[0] + r[2] // 2, r[1] + r[3] // 2); vm.mouse_button(1); time.sleep(0.25); vm.mouse_button(0); time.sleep(0.6)
def burst(vm, keys):
    time.sleep(0.5); a = full(vm)
    for k in keys: vm.sendkey(k); time.sleep(0.15)
    time.sleep(0.8); b = full(vm); return tuple(y - x for x, y in zip(a, b))
vm = Vm(IMG, OUT, tag="P"); vm.wait_serial(r"\[ui\] lock screen shown", 120); time.sleep(1.5)
rows = []; L = rects(vm, "lock screen shown")
rows.append(("lock: password field (7 chars)", 7, burst(vm, list("abcdefg"))))
rows.append(("lock: backspace x3", 3, burst(vm, ["backspace"] * 3)))
for _ in range(4): vm.sendkey("backspace")
for k in "vexpass1": vm.sendkey(k); time.sleep(0.1)
vm.sendkey("ret"); time.sleep(1.5); D = rects(vm, "desktop shown")
click(vm, D["search"]); rows.append(("desktop: search bar (3 chars)", 3, burst(vm, list("abc")))); vm.sendkey("esc")
click(vm, D["term"]); time.sleep(0.8)
rows.append(("Verminal prompt (8 chars)", 8, burst(vm, list("abcdefgh"))))
for _ in range(8): vm.sendkey("backspace")
vm.sendkey("esc"); time.sleep(0.6); click(vm, D["expl"]); time.sleep(0.6); vm.sendkey("n"); time.sleep(0.4)
rows.append(("Explorer: new-file name dialog (6 chars)", 6, burst(vm, list("abcdef"))))
vm.sendkey("esc"); vm.sendkey("esc"); time.sleep(0.5); click(vm, D["valb"]); time.sleep(0.6)
rows.append(("Valbook editing (10 chars + newline)", 11, burst(vm, list("abcdefghij") + ["ret"])))
vm.stop()
print(f"{'input context':44s} keys  full-screen | region-repaint | terminal-content   (heavy redraw events caused)")
for n, k, f in rows: print(f"{n:44s} {k:4d}  {f[0]:11d} | {f[1]:14d} | {f[2]:16d}")
TOTAL = sum(f[0] + f[1] + f[2] for _, _, f in rows)
print("TOTAL heavy redraw events:", TOTAL)
sys.exit(1 if os.environ.get("PROBE_STRICT") and TOTAL else 0)
