#!/usr/bin/env python3
"""Vex OS - scripts/gfx_e2e.py : GFX-VEC-01 acceptance (anti-aliased vector graphics, A/B in one build) through REAL PS/2 typing in QEMU (dev-seeded image).

Path exercised: PS/2 key events -> Verminal (VexScript) -> os_cmd(13) -> kernel run_term_request -> gfx_term
-> vxc_infer (integer network inside the kernel) -> term_out -> framebuffer + `[term]` serial mirror (which this script reads).
Every command waits for the kernel's own `[ui] v. ai: handled` marker, so a slow reply cannot pass or fail by timing luck.
  Build the seeded test image first:  make image EXTRA_CFLAGS="-DGRAPHICS2_VISUAL_DEMO=0 -DVEX_DEV_SEED_ACCOUNTS=1 -DVEX_TERM_MIRROR=1" && cp build/vexos.img build/vexos-seed.img
  python3 scripts/proc_e2e.py build/vexos-seed.img   (seed image needs -DGRAPHICS2_VISUAL_DEMO=0 -DVEX_DEV_SEED_ACCOUNTS=1 -DVEX_TERM_MIRROR=1)
"""
import os, re, sys, time
sys.path.insert(0, os.path.dirname(__file__))
from qemu_drive import Vm, ppm_to_png
SEED = sys.argv[1] if len(sys.argv) > 1 else "build/vexos-seed.img"; OUT = "build/gfx_e2e"; os.makedirs(OUT, exist_ok=True); res = []
def check(ok, w, d=""): res.append(bool(ok)); print(("PASS  " if ok else "FAIL  ") + w + (f"  [{d}]" if d and not ok else ""), flush=True)
def cnt(vm, p): return len(re.findall(p, vm.serial()))
def rects(vm, tag):
    ls = [l for l in vm.serial().splitlines() if tag in l]
    return {m.group(1): tuple(map(int, m.groups()[1:])) for m in re.finditer(r"(\w+)=\((\d+),(\d+),(\d+),(\d+)\)", ls[-1])} if ls else {}
def mr(vm, dx, dy):
    while dx or dy:
        sx = max(-100, min(100, dx)); sy = max(-100, min(100, dy)); vm.mouse_move(sx, sy); dx -= sx; dy -= sy; time.sleep(0.03)
    time.sleep(0.35)
def clk(vm, x, y): mr(vm, -1500, -1000); mr(vm, x, y); vm.mouse_button(1); time.sleep(0.25); vm.mouse_button(0); time.sleep(0.7)
def click(vm, r): clk(vm, r[0] + r[2] // 2, r[1] + r[3] // 2)
K = {" ": "spc", ".": "dot", "-": "minus", "\n": "ret", "/": "slash", "+": "shift-equal", "*": "shift-8", "?": "shift-slash", "'": "apostrophe", '"': "shift-apostrophe", "=": "equal", "!": "shift-1"}
def typ(vm, s):
    for c in s: vm.sendkey(K.get(c) or ("shift-" + c.lower() if c.isupper() else c)); time.sleep(0.11)
    time.sleep(0.4)
def shot(vm, n): p = f"{OUT}/{n}.ppm"; vm.screendump(p); ppm_to_png(p, f"{OUT}/{n}.png")
def term_lines(vm): return [l[len("[term] "):].rstrip("\r") for l in vm.serial().splitlines() if l.startswith("[term] ")]
import numpy as np
from PIL import Image
def ask(vm, cmd, marker, timeout=120):
    n_h = cnt(vm, marker); n_t = len(term_lines(vm)); t0 = time.time(); typ(vm, cmd + "\n")
    while time.time() - t0 < timeout and cnt(vm, marker) <= n_h: time.sleep(0.5)
    time.sleep(1.2); return term_lines(vm)[n_t:]
def load(name): return np.array(Image.open(f"{OUT}/{name}.png").convert("RGB")).astype(int)
def distinct(a): return len({tuple(p) for p in a.reshape(-1, 3)})
def blended_fraction(a, bg):
    flat = a.reshape(-1, 3); bgm = (np.abs(flat - np.array(bg)).sum(axis=1) < 6); fg = flat[~bgm]
    if len(fg) == 0: return 0.0, 0
    # an anti-aliased glyph edge has colours strictly between bg and a text colour; count distinct non-bg colours
    return float((~bgm).mean()), len({tuple(p) for p in fg})
vm = Vm(SEED, OUT, tag="G"); vm.wait_serial(r"\[ui\] lock screen shown", 200); time.sleep(1.2)
typ(vm, "vexpass1\n"); time.sleep(2.0); D = rects(vm, "desktop shown"); check("term" in D, "desktop is up and Verminal is on the taskbar")
shot(vm, "00_desktop_aa_on")
click(vm, D["term"]); time.sleep(1.0)
M = r"\[ui\] v\. gfx: handled"
L = ask(vm, "v. gfx", M); check(any("anti-aliased vector rendering is ON" in l for l in L) and any("Q24.8" in l for l in L) and any("no hardware floating point" in l or "does not use hardware floating point" in l for l in L), "`v. gfx` reports AA ON by default and states that coordinates are Q24.8 fixed point, not hardware float")
for c in ("v. help", "v. version", "v. roadmap"):
    typ(vm, c + "\n"); time.sleep(1.5)
shot(vm, "01_terminal_aa_on")
L = ask(vm, "v. gfx aa off", M); check(any("OFF" in l for l in L), "`v. gfx aa off` switches to the original aliased primitives"); time.sleep(2.0)
shot(vm, "02_terminal_aa_off"); shot(vm, "02b_desktop_aa_off")
L = ask(vm, "v. gfx aa on", M); check(any("ON" in l for l in L), "`v. gfx aa on` switches back"); time.sleep(2.0); shot(vm, "03_terminal_aa_on_again")
on, off = load("01_terminal_aa_on"), load("02_terminal_aa_off")
# terminal text area (black panel, uniform background) and window corner patches
T = (slice(100, 330), slice(160, 1000)); bg = tuple(on[600, 600]) if False else None
bgc = tuple(np.median(on[T[0], T[1]].reshape(-1, 3), axis=0).astype(int)); fon, don = blended_fraction(on[T[0], T[1]], bgc); foff, doff = blended_fraction(off[T[0], T[1]], bgc)
check(don > 3 * doff and don > 60, f"terminal text: {don} distinct colours with AA on vs {doff} with AA off (anti-aliasing introduces intermediate shades; the bitmap font has none)")
corner_on, corner_off = on[24:40, 140:156], off[24:40, 140:156]
check(distinct(corner_on) > distinct(corner_off), f"window corner patch: {distinct(corner_on)} distinct colours with AA on vs {distinct(corner_off)} off (smooth curve vs staircase)")
print("   terminal text distinct colours on/off:", don, doff, " corner on/off:", distinct(corner_on), distinct(corner_off))
L = ask(vm, "v. gfx bench", M, timeout=200); print("\n".join("   | " + l for l in L))
check(len(L) == 2 and "anti-aliased" in L[0] and "aliased" in L[1], "`v. gfx bench` ran both modes and reported timings")
import re as _re
ms = [int(x) for l in L for x in _re.findall(r"(\d+) ms", l)]; check(len(ms) >= 4 and all(m < 5000 for m in ms), f"benchmark timings are sane (no pathological slowdown): {ms} ms")
L = ask(vm, "v. gfx bench", M, timeout=200)
shot(vm, "04_after_bench")
typ(vm, "v. ai what is 12 plus 30\n"); time.sleep(10); check("12 plus 30 = 42" in " ".join(term_lines(vm)[-8:]), "terminal still works with AA text: v. ai answers 12 plus 30 = 42")
s = vm.serial(); check(not re.search(r"VEX KERNEL PANIC|UNHANDLED CPU EXCEPTION|\[kernel\] FATAL", s), "no kernel panic / unhandled CPU exception / FATAL during the whole session")
open(f"{OUT}/serial_full.log", "w").write(s); vm.stop()
print(f"\n{sum(res)}/{len(res)} GFX-VEC-01 end-to-end checks passed"); sys.exit(0 if all(res) else 1)
