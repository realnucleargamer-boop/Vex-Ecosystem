# VEX-Script 1.0 Language Specification (Frozen)

This document records the authoritative VEX-Script 1.0 freeze decided by the Principal AI Architect.  
It is the baseline for all subsequent versions.

**Status**: Frozen  
**Date of freeze**: 2026-08-20 (conversation record)  
**Materialized into repository**: 2026-08-21

---

## 1. Core Syntax — FROZEN

```vex
fn main() -> i32 {
    let x: i64 = 10;
    let y: i64 = 20;
    let result: i64 = x + y;
    println("Hello from VexScript");
    return 0;
}
```

### Frozen keywords
```
fn  let  const  mut  return
if  else  while  for  loop
break  continue
struct  type  unsafe
true  false
```

---

## 2. Types — FROZEN

### Primitives
```
bool
i8  i16  i32  i64
u8  u16  u32  u64
f32  f64
string
```

### Fixed-size arrays
```vex
let nums: [i64; 4] = [1, 2, 3, 4];
```

### Structs (value types)
```vex
struct Point {
    x: i64,
    y: i64,
}
```

### Type aliases
```vex
type Handle = u64;
```

No implicit numeric conversions. Explicit `as` cast required.

---

## 3. Variables — FROZEN

```vex
let x: i64 = 10;          // immutable
let mut x: i64 = 10;      // mutable
x = 20;
const MAX: i64 = 1024;
```

---

## 4. Functions — FROZEN

```vex
fn add(a: i64, b: i64) -> i64 {
    return a + b;
}

fn main() -> i32 { ... }   // exit code
```

---

## 5. Control Flow — FROZEN

```vex
if (cond) { } else if (cond) { } else { }
while (cond) { }
for (let i: i64 = 0; i < 10; i = i + 1) { }
loop { }
break;  continue;
```

No `goto`.

---

## 6. Strings — FROZEN (interface)

Language type: `string`  
Literals: `"Hello"`  
Functions: `print(...)`, `println(...)`  
Internal representation is an implementation detail.

---

## 7. Pointers — FROZEN SAFETY MODEL

```vex
*T
*mut T
&x
&mut x

unsafe {
    *ptr
}
```

`unsafe` means the programmer accepts responsibility for a language-level safety rule.  
It does **not** grant kernel privileges, physical memory access, or security bypasses.

---

## 8. OS Interaction Direction — FROZEN

```vex
type Handle = u64;
```

Applications receive only opaque handles.  
They never receive raw kernel virtual addresses.

---

## 9. Explicitly Not Part of 1.0

generics, traits, modules/imports, async, concurrency syntax, exceptions,  
package manager, advanced pointer arithmetic, allocator API, reflection,  
macros, SIMD, FFI syntax, exact ABI details, Vex IR (compiler internal).

---

This specification is the compatibility baseline for VEX-Script 1.1.
