# CHANGELOG — VEX AI 1.1 toolchain pass (VexScript 3.2.3)

This 3.2.3 base already included the acceleration layer (accel_rt.py:
device_set/gpu_available/workers_set/workers_get/stream_advance_batch) but
did NOT yet include the three language fixes from the VEX AI 1.0 pass
(that pass was applied to a separate 3.2.2 lineage). Reapplied here,
identically in substance to the 1.0 CHANGELOG_VEX_AI_1.0.md:

1. Indexed array mutation (`a[i] = x`): parser/typecheck/interpreter/IR
   emitter/IR interpreter (new `index_set` opcode).
2. Same-module function resolution: hosted interpreter module-context
   stack; IR emitter qualifies bare same-module calls; CLI no longer
   excludes private (non-pub) module functions from IR emission; removed
   the fn_rets bare-name aliasing bug that caused both issues.
3. genome_*/stream_*/fitness_*/migrate_*/diversity_*/elite_* builtins now
   dispatch through the IR interpreter (previously hosted-only).

Additionally for VEX AI 1.1: the IR interpreter's dispatch was extended to
cover the acceleration builtins too (`gpu_available`, `device_set`,
`device_get_code`, `workers_set`, `workers_get`,
`stream_advance_batch2/4`), so `vexc run` can execute VEX AI 1.1 code that
uses the accelerator API, not just the hosted interpreter.

No version numbers bumped (additive fixes, not contract changes).

Regression status: pre-existing 27-test suite (`scripts/run_tests.py`)
27/27 pass. Pre-existing accel suite (`scripts/test_accel.py`) 10/10 pass.
New language-wave suite (`scripts/test_language_wave_1_0.py`, reused as-is)
10/10 pass.
