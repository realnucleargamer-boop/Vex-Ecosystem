#!/usr/bin/env python3
"""VexScript 3.0 Phase A — tensor types + deterministic RNG"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vexscript import __version__
from vexscript.lexer import Lexer
from vexscript.parser import Parser
from vexscript.typecheck import TypeChecker
from vexscript.interpreter import Interpreter

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

print("VexScript 3.0-A")
check("version", __version__.startswith("3."), __version__)

src = '''
fn foo(w: tensor<f32, [128, 64]>) -> i32 { return 0; }
fn bar(v: tensor<f32, [128]>) -> i32 { return 0; }
fn main() -> i32 {
    rng_seed(12345);
    println(rng_u64());
    return 0;
}
'''
prog = Parser(Lexer(src, "t").tokenize(), "t").parse()
TypeChecker().check_program(prog)
check("tensor rank2 type", "tensor<f32, [128, 64]>" in prog.functions[0].params[0].type.name)
check("tensor rank1 type", "tensor<f32, [128]>" in prog.functions[1].params[0].type.name)

i = Interpreter(); i.load(src, "t"); i.run_main()
j = Interpreter(); j.load(src, "t"); j.run_main()
check("rng deterministic", i.output == j.output and len(i.output) == 1, i.output)

# regression: plain 2.0+++ still works
src2 = 'fn main() -> i32 { println("Vex" + "Script"); return 0; }\n'
i = Interpreter(); i.load(src2, "t"); c = i.run_main()
check("2.0+++ string+", c == 0 and i.output == ["VexScript"], i.output)

print(f"\n=== 3.0-A Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
