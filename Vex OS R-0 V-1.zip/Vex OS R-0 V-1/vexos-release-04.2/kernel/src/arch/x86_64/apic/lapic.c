/*
 * Vex OS - kernel/src/arch/x86_64/apic/lapic.c
 */

#include "lapic.h"
#include "serial.h"

#define IA32_APIC_BASE_MSR 0x1B
#define IA32_APIC_BASE_EN_BIT (1ULL << 11)

#define LAPIC_REG_ID          0x020
#define LAPIC_REG_TPR         0x080
#define LAPIC_REG_EOI         0x0B0
#define LAPIC_REG_SPURIOUS    0x0F0
#define LAPIC_REG_ICR_LOW     0x300
#define LAPIC_REG_ICR_HIGH    0x310

/* Interrupt Command Register fields (Intel SDM Vol.3, "Interrupt
 * Command Register (ICR)"). */
#define ICR_DELIVERY_INIT     (5u << 8)
#define ICR_DELIVERY_STARTUP  (6u << 8)
#define ICR_PHYSICAL_DEST     (0u << 11)
#define ICR_DELIVERY_PENDING  (1u << 12)  /* Delivery Status, read-only */
#define ICR_LEVEL_ASSERT      (1u << 14)
#define ICR_LEVEL_DEASSERT    (0u << 14)
#define ICR_TRIGGER_LEVEL     (1u << 15)
#define ICR_DEST_NO_SHORTHAND (0u << 18)

#define LAPIC_SPURIOUS_VECTOR 0xFF   /* dedicated, otherwise-unused vector */
#define LAPIC_SOFTWARE_ENABLE (1u << 8)

/* KERNEL-01 Phase 2: recorded once by lapic_init() so that interrupt
 * context can EOI without an argument. See lapic_dispatch_base() in
 * lapic.h for why one global value is correct rather than per-CPU. */
static uint64_t g_dispatch_base;

static int cpuid_has_apic(void)
{
    uint32_t eax, ebx, ecx, edx;
    __asm__ volatile ("cpuid"
        : "=a"(eax), "=b"(ebx), "=c"(ecx), "=d"(edx)
        : "a"(1));
    return (edx & (1u << 9)) != 0; /* CPUID.1:EDX.APIC */
}

static uint64_t read_msr(uint32_t msr)
{
    uint32_t lo, hi;
    __asm__ volatile ("rdmsr" : "=a"(lo), "=d"(hi) : "c"(msr));
    return ((uint64_t)hi << 32) | lo;
}

static void write_msr(uint32_t msr, uint64_t value)
{
    uint32_t lo = (uint32_t)(value & 0xFFFFFFFF);
    uint32_t hi = (uint32_t)(value >> 32);
    __asm__ volatile ("wrmsr" : : "c"(msr), "a"(lo), "d"(hi));
}

static uint32_t lapic_read(uint64_t base, uint32_t reg)
{
    volatile uint32_t *p = (volatile uint32_t *)(uintptr_t)(base + reg);
    return *p;
}

static void lapic_write(uint64_t base, uint32_t reg, uint32_t value)
{
    volatile uint32_t *p = (volatile uint32_t *)(uintptr_t)(base + reg);
    *p = value;
}

uint32_t lapic_read_own_id(uint64_t physical_base)
{
    return lapic_read(physical_base, LAPIC_REG_ID) >> 24;
}

/* BOOT-03: raw accessors for the timer code. Thin wrappers over the
 * file-static helpers so there is exactly one definition of "how a
 * LAPIC register is touched" in the tree. */
uint32_t lapic_reg_read(uint64_t physical_base, uint32_t reg)
{
    return lapic_read(physical_base, reg);
}

void lapic_reg_write(uint64_t physical_base, uint32_t reg, uint32_t value)
{
    lapic_write(physical_base, reg, value);
}

uint32_t lapic_spurious_vector(void)
{
    return LAPIC_SPURIOUS_VECTOR;
}

uint64_t lapic_dispatch_base(void)
{
    return g_dispatch_base;
}

uint32_t lapic_enable_on_this_cpu(uint64_t physical_base)
{
    if (physical_base == 0) return 0;

    lapic_write(physical_base, LAPIC_REG_SPURIOUS,
                LAPIC_SPURIOUS_VECTOR | LAPIC_SOFTWARE_ENABLE);

    /* TPR 0 = accept every priority class. INIT leaves TPR at 0 already,
     * so this is belt-and-braces rather than a fix - but a non-zero TPR
     * on one CPU would make that CPU silently ignore the shootdown
     * vector while every other CPU acknowledged, and the resulting
     * failure would look like a lost IPI rather than a masked one. Cheap
     * to state explicitly, expensive to debug if wrong. */
    lapic_write(physical_base, LAPIC_REG_TPR, 0);

    /* Read back rather than reporting what was written: the caller
     * publishes this as evidence that the LAPIC really is software
     * enabled on this CPU. */
    return lapic_read(physical_base, LAPIC_REG_SPURIOUS);
}

void lapic_send_eoi(uint64_t physical_base)
{
    /* Any value written to the EOI register signals end-of-interrupt;
     * 0 is written by convention. Writing EOI when no interrupt is in
     * service is architecturally undefined, so this is only ever called
     * from an interrupt handler. */
    lapic_write(physical_base, LAPIC_REG_EOI, 0);
}

int lapic_wait_ipi_idle(uint64_t physical_base)
{
    /* Bounded, not unbounded. If a LAPIC never clears Delivery Status
     * the BSP must report a failure, not spin forever - one dead AP
     * hanging the whole machine is exactly the failure mode BOOT-02C
     * is required to avoid. The bound is an iteration count rather
     * than a time, because this runs before any timekeeping is
     * trustworthy; it is generous enough that a healthy LAPIC always
     * clears well within it. */
    for (uint32_t i = 0; i < 1000000u; i++) {
        if ((lapic_read(physical_base, LAPIC_REG_ICR_LOW)
             & ICR_DELIVERY_PENDING) == 0) {
            return 1;
        }
        __asm__ volatile ("pause");
    }
    return 0;
}

/* Writing the ICR is a two-step operation and the ORDER MATTERS: the
 * high dword (destination) must be written first, because writing the
 * low dword is what actually triggers delivery. */
static void lapic_write_icr(uint64_t base, uint32_t apic_id, uint32_t low)
{
    lapic_write(base, LAPIC_REG_ICR_HIGH, apic_id << 24);
    lapic_write(base, LAPIC_REG_ICR_LOW, low);
}

void lapic_send_init(uint64_t physical_base, uint32_t apic_id)
{
    /* INIT assert, then INIT deassert (level-triggered). The deassert
     * is legacy behaviour that modern CPUs largely ignore, but it is
     * still what the documented startup algorithm specifies and it is
     * harmless, so it is issued rather than skipped. */
    lapic_write_icr(physical_base, apic_id,
                    ICR_DELIVERY_INIT | ICR_PHYSICAL_DEST |
                    ICR_DEST_NO_SHORTHAND | ICR_TRIGGER_LEVEL |
                    ICR_LEVEL_ASSERT);
    lapic_wait_ipi_idle(physical_base);

    lapic_write_icr(physical_base, apic_id,
                    ICR_DELIVERY_INIT | ICR_PHYSICAL_DEST |
                    ICR_DEST_NO_SHORTHAND | ICR_TRIGGER_LEVEL |
                    ICR_LEVEL_DEASSERT);
    lapic_wait_ipi_idle(physical_base);
}

void lapic_send_sipi(uint64_t physical_base, uint32_t apic_id,
                     uint8_t vector)
{
    /* SIPI is edge-triggered and carries the trampoline page number in
     * the vector field: the AP starts at CS = vector << 8, IP = 0,
     * i.e. physical address vector * 4096. */
    lapic_write_icr(physical_base, apic_id,
                    ICR_DELIVERY_STARTUP | ICR_PHYSICAL_DEST |
                    ICR_DEST_NO_SHORTHAND | ICR_LEVEL_ASSERT | vector);
}

int lapic_init(LapicInfo *out)
{
    out->supported = 0;
    out->globally_enabled = 0;
    out->physical_base = 0;
    out->id = 0;

    if (!cpuid_has_apic()) {
        serial_puts("[kernel] LAPIC: CPUID reports no APIC support\n");
        return 0;
    }
    out->supported = 1;

    uint64_t apic_base_msr = read_msr(IA32_APIC_BASE_MSR);
    out->physical_base = apic_base_msr & 0xFFFFF000ULL; /* bits 12-35 (low 32 shown; identity-mapped low MMIO in practice) */
    out->globally_enabled = (apic_base_msr & IA32_APIC_BASE_EN_BIT) != 0;

    if (!out->globally_enabled) {
        /* Firmware disabling the LAPIC globally is unusual and
         * worth surfacing rather than silently forcing it on -
         * forcing it on ourselves this early, before we're sure
         * nothing else depends on the current state, is a bigger
         * assumption than BOOT-02B should make quietly. */
        serial_puts("[kernel] LAPIC: WARNING - IA32_APIC_BASE.EN is not set by firmware\n");
        write_msr(IA32_APIC_BASE_MSR, apic_base_msr | IA32_APIC_BASE_EN_BIT);
        out->globally_enabled = (read_msr(IA32_APIC_BASE_MSR) & IA32_APIC_BASE_EN_BIT) != 0;
        if (!out->globally_enabled) {
            serial_puts("[kernel] LAPIC: failed to enable globally\n");
            return 0;
        }
        serial_puts("[kernel] LAPIC: enabled globally by Vex OS (was disabled)\n");
    }

    out->id = lapic_read(out->physical_base, LAPIC_REG_ID) >> 24;

    /* Software-enable the LAPIC with a dedicated spurious vector.
     * This does NOT unmask anything real - no IDT gate we'd actually
     * hit is wired to fire from this in BOOT-02B, and `sti` is still
     * never called anywhere. This just readies the LAPIC for
     * BOOT-02C's IPI-based AP startup. */
    lapic_write(out->physical_base, LAPIC_REG_SPURIOUS,
                LAPIC_SPURIOUS_VECTOR | LAPIC_SOFTWARE_ENABLE);

    /* KERNEL-01 Phase 2: publish the base for interrupt context. Done
     * last, so a base is only ever visible after the LAPIC behind it has
     * been fully set up. */
    g_dispatch_base = out->physical_base;

    return 1;
}
