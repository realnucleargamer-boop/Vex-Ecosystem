#!/usr/bin/env python3
"""VEX-AI-01 compiler readiness (hosted IR interpreter)."""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vexscript.compile_ir import run_via_ir

P = F = 0
def check(n, c, d=""):
    global P, F
    if c:
        P += 1
        print(f"  PASS  {n}")
    else:
        F += 1
        print(f"  FAIL  {n}  {d}")

def run(src, expect):
    code, out = run_via_ir(src)
    lines = [ln for ln in out.strip().split("\n") if ln != ""] if out.strip() else []
    return code == 0 and lines == expect, lines

print("VEX-AI readiness")

ok, o = run('fn main() -> i32 { println("VEX AI ONLINE"); return 0; }\n', ["VEX AI ONLINE"])
check("println string const", ok, o)

ok, o = run('fn main() -> i32 { let x: string = "VEX AI"; println(x); return 0; }\n', ["VEX AI"])
check("string variable", ok, o)

ok, o = run('''
fn echo(x: string) -> string { return x; }
fn main() -> i32 { println(echo("VEX AI")); return 0; }
''', ["VEX AI"])
check("string param/return", ok, o)

ok, o = run('''
fn main() -> i32 {
    println(concat("Vex", "AI"));
    return 0;
}
''', ["VexAI"])
check("concat", ok, o)

ok, o = run('''
fn main() -> i32 {
    let a: string = "Vex";
    let b: string = concat(a, "Script");
    println(b);
    println(len_string(b));
    return 0;
}
''', ["VexScript", "9"])
check("concat+len", ok, o)

ok, o = run('''
fn main() -> i32 {
    let input: string = "";
    if (input == "") { println(1); }
    if (input != "x") { println(2); }
    return 0;
}
''', ["1", "2"])
check("string compare", ok, o)

ok, o = run('''
struct Message {
    id: i64
    content: string
}
fn main() -> i32 {
    let m = Message { id: 1001, content: "Hello" };
    println(m.id);
    println(m.content);
    return 0;
}
''', ["1001", "Hello"])
check("mixed struct fields", ok, o)

ok, o = run('''
struct VexMessage {
    id: i64
    role: i64
    content: string
}
fn make_message(text: string) -> VexMessage {
    return VexMessage { id: 1001, role: 1, content: text };
}
fn main() -> i32 {
    let m = make_message("Ping AI Service");
    println(m.id);
    println(m.content);
    return 0;
}
''', ["1001", "Ping AI Service"])
check("VexMessage make+print", ok, o)

print(f"\n=== VEX-AI readiness: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
