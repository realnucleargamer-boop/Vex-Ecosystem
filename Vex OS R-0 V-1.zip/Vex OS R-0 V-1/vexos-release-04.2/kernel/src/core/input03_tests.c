/* Vex OS - kernel/src/core/input03_tests.c  (see include/input03_tests.h) */
#include "input03_tests.h"
#include "input.h"
#include "ps2_mouse.h"
#include "power.h"
#include "rtc.h"
#include "netstatus.h"
#include "cursor.h"
#include "serial.h"

static Input03Results *R;
static void check(int ok, const char *what)
{
    R->checks_run++;
    if (!ok) { R->checks_failed++; serial_puts("[test] INPUT-03: FAIL - "); serial_puts(what); serial_puts("\n"); }
}

/* ---------------- mouse decode / assembler ---------------- */
static void t_mouse(void)
{
    Ps2MousePacket p;
    check(ps2_mouse_decode(0x09, 5, 3, &p) && p.dx == 5 && p.dy == -3 && p.buttons == 1 && !p.overflow, "decode: +dx, device-up becomes screen-up (dy negated), left button");
    check(ps2_mouse_decode(0x38, 0xFB, 0xFD, &p) && p.dx == -5 && p.dy == 3, "decode: signed (9-bit two's complement) negative deltas");
    check(ps2_mouse_decode(0x18, 0x00, 0x00, &p) && p.dx == -256 && p.dy == 0, "decode: most negative delta (-256)");
    check(ps2_mouse_decode(0x08 | 0x20 | 0x10, 0x01, 0x01, &p) && p.dx == -255 && p.dy == 255, "decode: sign bit with small low byte");
    check(!ps2_mouse_decode(0x01, 1, 1, &p), "decode: missing sync bit (bit 3) is rejected");
    check(!ps2_mouse_decode(0x09, 1, 1, 0), "decode: NULL output is refused");
    check(ps2_mouse_decode(0x08 | 0x40, 100, 100, &p) && p.overflow && p.dx == 0 && p.dy == 0, "decode: X overflow discards movement");
    check(ps2_mouse_decode(0x08 | 0x80, 100, 100, &p) && p.overflow && p.dx == 0 && p.dy == 0, "decode: Y overflow discards movement");
    check(ps2_mouse_decode(0x0F, 0, 0, &p) && p.buttons == 7, "decode: all three buttons");

    VexMouseEvent e;
    input_init(); ps2_mouse_reset_decoder();
    ps2_mouse_feed(0x00, 10);                 /* not a valid first byte: slid past */
    check(!input_poll_mouse(&e), "assembler: stray non-sync byte produces no event");
    ps2_mouse_feed(0x09, 11); ps2_mouse_feed(2, 11); ps2_mouse_feed(4, 11);
    check(input_poll_mouse(&e) && e.dx == 2 && e.dy == -4 && e.buttons == 1 && !input_poll_mouse(&e), "assembler: one 3-byte packet yields exactly one event");
    ps2_mouse_feed(0x09, 12); ps2_mouse_feed(0, 12); ps2_mouse_feed(0, 12);
    check(!input_poll_mouse(&e), "assembler: packet with no movement and no button change is not published");
    ps2_mouse_feed(0x08, 13); ps2_mouse_feed(0, 13); ps2_mouse_feed(0, 13);
    check(input_poll_mouse(&e) && e.buttons == 0 && e.dx == 0, "assembler: button release alone is published (absolute mask 0)");
    /* stale half packet: 2 bytes, long gap, then a byte lacking the sync bit */
    input_init(); ps2_mouse_reset_decoder();
    ps2_mouse_feed(0x09, 100); ps2_mouse_feed(7, 100);
    ps2_mouse_feed(0x00, 200);
    ps2_mouse_feed(0x09, 201); ps2_mouse_feed(1, 201); ps2_mouse_feed(1, 201);
    check(input_poll_mouse(&e) && e.dx == 1 && e.dy == -1 && !input_poll_mouse(&e), "assembler: stale half-packet abandoned; stream resynchronises on the next valid packet");
    input_init(); ps2_mouse_reset_decoder();
}

/* ---------------- power parsers ---------------- */
static void put32(uint8_t *b, int o, uint32_t v) { for (int i = 0; i < 4; i++) b[o + i] = (uint8_t)(v >> (8 * i)); }
static void fix_sum(uint8_t *b, int len) { b[9] = 0; uint8_t s = 0; for (int i = 0; i < len; i++) s = (uint8_t)(s + b[i]); b[9] = (uint8_t)(0 - s); }
static void t_power(void)
{
    uint8_t ta = 99, tb = 99;
    static const uint8_t s5_zero[] = { 0x10, 0x20, 0x08, '_','S','5','_', 0x12, 0x06, 0x04, 0x00, 0x00, 0x00, 0x00, 0x77 };
    check(power_parse_s5(s5_zero, sizeof s5_zero, &ta, &tb) && ta == 0 && tb == 0, "S5: ZeroOp elements (QEMU encoding) parse to SLP_TYP 0/0");
    static const uint8_t s5_byte[] = { 0x5C, 0x08, '_','S','5','_', 0x12, 0x0A, 0x04, 0x0A, 0x05, 0x0A, 0x03, 0x00, 0x00, 0x00 };
    ta = tb = 99;
    check(power_parse_s5(s5_byte, sizeof s5_byte, &ta, &tb) && ta == 5 && tb == 3, "S5: root-prefixed name with BytePrefix elements parses to 5/3");
    static const uint8_t not_named[] = { 0x00, 0x00, '_','S','5','_', 0x12, 0x06, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00 };
    check(!power_parse_s5(not_named, sizeof not_named, &ta, &tb), "S5: the string without a NameOp definition is refused");
    static const uint8_t trunc[] = { 0x00, 0x08, '_','S','5','_', 0x12, 0x06, 0x04, 0x0A };
    check(!power_parse_s5(trunc, sizeof trunc, &ta, &tb), "S5: truncated package is refused (no read past the end)");
    static const uint8_t big[] = { 0x00, 0x08, '_','S','5','_', 0x12, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x04, 0x00, 0x00 };
    check(!power_parse_s5(big, sizeof big, &ta, &tb), "S5: hostile PkgLength (4 follow bytes) cannot walk past the buffer");
    static const uint8_t one[] = { 0x00, 0x08, '_','S','5','_', 0x12, 0x03, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00 };
    check(!power_parse_s5(one, sizeof one, &ta, &tb), "S5: a package with fewer than 2 elements is refused");
    static const uint8_t bigv[] = { 0x00, 0x08, '_','S','5','_', 0x12, 0x06, 0x04, 0x0A, 0x09, 0x00, 0x00, 0x00 };
    check(!power_parse_s5(bigv, sizeof bigv, &ta, &tb), "S5: SLP_TYP above 7 (3-bit field) is refused");
    check(!power_parse_s5(0, 100, &ta, &tb) && !power_parse_s5(s5_zero, 4, &ta, &tb), "S5: NULL / tiny buffers are refused");

    static uint8_t f[244]; PowerInfo pi;
    for (int i = 0; i < 244; i++) f[i] = 0;
    f[0]='F'; f[1]='A'; f[2]='C'; f[3]='P'; put32(f, 4, 244);
    put32(f, 48, 0xB2); f[52] = 0xF1; put32(f, 64, 0x604);
    put32(f, 112, 1u << 10); f[116] = 1; f[117] = 8; f[120] = 0xF9; f[121] = 0x0C; f[128] = 0x0E;
    fix_sum(f, 244);
    check(power_parse_fadt(f, 244, &pi) && pi.pm1a_cnt == 0x604 && pi.smi_cmd == 0xB2 && pi.reset_port == 0xCF9 && pi.reset_value == 0x0E, "FADT: PM1a_CNT, SMI_CMD and I/O reset register extracted");
    f[9] ^= 1;
    check(!power_parse_fadt(f, 244, &pi) && !pi.fadt_ok, "FADT: bad checksum is refused");
    f[9] ^= 1; put32(f, 4, 200); fix_sum(f, 244);
    check(!power_parse_fadt(f, 244, &pi), "FADT: header length that disagrees with the supplied length is refused");
    put32(f, 4, 244); put32(f, 64, 0x10000); fix_sum(f, 244);
    check(power_parse_fadt(f, 244, &pi) && pi.pm1a_cnt == 0, "FADT: PM1a_CNT above 0xFFFF is treated as absent, not truncated to a wrong port");
    put32(f, 64, 0x604); put32(f, 112, 0); fix_sum(f, 244);
    check(power_parse_fadt(f, 244, &pi) && pi.reset_port == 0, "FADT: reset register ignored when RESET_REG_SUP is clear");
    check(!power_parse_fadt(f, 20, &pi) && !power_parse_fadt(0, 244, &pi), "FADT: short / NULL input refused");
}

/* ---------------- rtc / net / cursor ---------------- */
static void t_misc(void)
{
    RtcTime t = { 2024, 2, 29, 12, 0, 0 };
    check(rtc_validate(&t), "rtc: 2024-02-29 (leap day) is valid");
    t.year = 2023; check(!rtc_validate(&t), "rtc: 2023-02-29 is invalid");
    t.year = 2100; check(!rtc_validate(&t), "rtc: year outside the supported range is invalid");
    t.year = 2026; t.month = 13; check(!rtc_validate(&t), "rtc: month 13 is invalid");
    t.month = 4; t.day = 31; check(!rtc_validate(&t), "rtc: April 31 is invalid");
    t.day = 30; t.hour = 24; check(!rtc_validate(&t), "rtc: hour 24 is invalid");
    check(!rtc_validate(0), "rtc: NULL is invalid");
    check(rtc_weekday(2026, 10, 11) == 0 && rtc_weekday(2000, 1, 1) == 6 && rtc_weekday(2024, 2, 29) == 4, "rtc: weekday computation (Sun 2026-10-11, Sat 2000-01-01, Thu 2024-02-29)");
    check(rtc_bcd_to_bin(0x59) == 59 && rtc_bcd_to_bin(0x07) == 7, "rtc: BCD conversion");

    check(netstatus_is_network_class(2) && !netstatus_is_network_class(3) && !netstatus_is_network_class(0), "net: only PCI class 0x02 counts as a network controller");
    check(netstatus_known_name(0x8086, 0x10D3) != 0 && netstatus_known_name(0x1234, 0x5678) == 0, "net: known-ID table names known adapters only; unknown IDs stay unnamed");

    check(cursor_clamp(-5, 0, 99) == 0 && cursor_clamp(500, 0, 99) == 99 && cursor_clamp(42, 0, 99) == 42, "cursor: clamp to screen bounds");
    check(cursor_clamp(2147483647, 0, 99) == 99 && cursor_clamp(-2147483647 - 1, 0, 99) == 0, "cursor: clamp at int32 extremes");
    check(cursor_sprite_wellformed(), "cursor: every sprite row is exactly CURSOR_W valid characters");
}

/* The LOCK-01 UI state-machine scenarios were superseded by the DESKTOP-01 UI tests (desktop01_tests.c);
 * the redesigned lock screen has different controls. Decoder/queue/power/RTC/net/cursor checks stay here. */

void input03_run_tests(Input03Results *out)
{
    R = out; out->checks_run = 0; out->checks_failed = 0;
    check(input_mouse_self_test(), "mouse event queue: order, saturation, bad-bit refusal, overflow drop-and-count, wraparound");
    t_mouse(); t_power(); t_misc();
}
void input03_print_summary(const Input03Results *r)
{
    serial_puts("[test] ===== ");
    serial_put_dec64(r->checks_run - r->checks_failed); serial_puts("/"); serial_put_dec64(r->checks_run);
    serial_puts(" INPUT-03 checks passed =====\n");
}
int input03_all_passed(const Input03Results *r) { return r->checks_run > 0 && r->checks_failed == 0; }
