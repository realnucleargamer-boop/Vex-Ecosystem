#include "ps2_keyboard.h"
#include "input.h"
#include "ps2_mouse.h"
#include "timer.h"
static uint64_t events;
static uint8_t e0;
static inline uint8_t inb(uint16_t p) { uint8_t v; __asm__ volatile("inb %1,%0":"=a"(v):"Nd"(p)); return v; }
static VexKeyCode map(uint8_t s) { static const VexKeyCode t[128] = {
 [1]=VEX_KEY_ESCAPE,[14]=VEX_KEY_BACKSPACE,[15]=VEX_KEY_TAB,[28]=VEX_KEY_ENTER,[29]=VEX_KEY_LCTRL,[42]=VEX_KEY_LSHIFT,[54]=VEX_KEY_RSHIFT,[56]=VEX_KEY_LALT,[57]=VEX_KEY_SPACE,
 [30]=VEX_KEY_A,[48]=VEX_KEY_B,[46]=VEX_KEY_C,[32]=7,[18]=8,[33]=9,[34]=10,[35]=11,[23]=12,[36]=13,[37]=14,[38]=15,[50]=16,[49]=17,[24]=18,[25]=19,[16]=20,[19]=21,[31]=22,[20]=23,[22]=24,[47]=25,[17]=26,[45]=27,[21]=28,[44]=29,
 /* DESKTOP-01: digits and punctuation (US layout) so account names / the input test can use them */
 [2]=30,[3]=31,[4]=32,[5]=33,[6]=34,[7]=35,[8]=36,[9]=37,[10]=38,[11]=39,
 [12]=45,[13]=46,[26]=47,[27]=48,[43]=49,[39]=51,[40]=52,[41]=53,[51]=54,[52]=55,[53]=56,[88]=69}; return t[s]; }
int ps2_keyboard_init(void) { events=0; e0=0; return 1; }
/* INPUT-03: this is now the SINGLE reader of the i8042 output buffer.  Status
 * bit 5 marks a byte as coming from the auxiliary (mouse) device; those are
 * routed to the mouse assembler instead of being mis-decoded as scancodes.
 * Bits 6/7 (timeout / parity error) mean the byte is untrustworthy and it is
 * dropped.  The loop is bounded so a controller that never deasserts OBF
 * cannot hang the main loop.  Keyboard decoding is otherwise unchanged. */
#define PS2_MAX_BYTES_PER_POLL 128
void ps2_keyboard_poll(void) {
    for (int n = 0; n < PS2_MAX_BYTES_PER_POLL; n++) {
        uint8_t st = inb(0x64);
        if (!(st & 1u)) break;
        uint8_t b = inb(0x60);
        if (st & 0xC0u) continue;
        if (st & 0x20u) { ps2_mouse_feed(b, timer_ticks()); continue; }
        if(b==0xE0){e0=1;continue;}
        VexKeyCode k;
        if(e0){ k=(b&0x7f)==0x48?VEX_KEY_UP:(b&0x7f)==0x50?VEX_KEY_DOWN:(b&0x7f)==0x4b?VEX_KEY_LEFT:(b&0x7f)==0x4d?VEX_KEY_RIGHT:VEX_KEY_UNKNOWN; e0=0; }
        else k=map(b&0x7f);
        if(k!=VEX_KEY_UNKNOWN && input_publish_key(k,(b&0x80)?VEX_KEY_RELEASE:VEX_KEY_PRESS)) events++;
    }
}
uint64_t ps2_keyboard_events(void){return events;}
