; Vex OS - kernel/src/arch/x86_64/cpu/ring3_programs.asm
;
; SECURITY-02: the Ring 3 test programs themselves, as hand-written,
; position-independent machine code. Written in asm and linked as a
; normal object (not hand-encoded as a C byte array) so NASM, not a
; human, is responsible for opcode correctness - consistent with how
; every other privilege-sensitive routine in this kernel (gdt_flush,
; isr_stubs, context_switch, ap_trampoline) already lives in asm, not C.
;
; These bytes are never executed from HERE. ring3.c copies this blob's
; bytes into the dedicated user code page (kernel/src/memory/virtual's
; vmm_map_user_page() target) and Ring 3 executes them from THAT address
; instead. That is why every block below is fully position-independent:
; straight-line code only, no internal jumps/calls, no RIP-relative
; references to anything outside itself. The one address referenced
; (0x100000) is the kernel image's own known load address from
; kernel/link.ld - not a reference to this blob's own location.
;
; Layout: one test program per 0x20-byte-aligned slot, selected by the
; kernel passing that slot's offset as ring3_enter()'s entry point.
; Calling convention into each block (set by ring3_enter, see
; ring3_transition.asm): RDI = arg0, RSI = arg1. Syscall convention
; (int 0x80): RAX = syscall number, RDI/RSI = arg0/arg1, result
; returned in RAX. SYS_EXIT = 0, SYS_WRITE = 1 (see ring3.h).

BITS 64
section .text

KERNEL_IMAGE_ADDR equ 0x100000   ; identity-mapped, supervisor-only - see link.ld

global ring3_prog_base
ring3_prog_base:

; --- slot 0x00: clean exit. Positive-path "Ring 3 can run and return
; through the controlled syscall path" test. ---
align 0x20
    mov rax, 0
    xor rdi, rdi
    int 0x80

; --- slot 0x20: read forbidden kernel memory. Expected: #PF, caught by
; the kernel's fault-isolation path, never reaches the syscall below. ---
align 0x20
    mov rax, KERNEL_IMAGE_ADDR
    mov rbx, [rax]
    mov rax, 0
    xor rdi, rdi
    int 0x80

; --- slot 0x40: write forbidden kernel memory. Expected: #PF. ---
align 0x20
    mov rax, KERNEL_IMAGE_ADDR
    mov qword [rax], 0x41414141   ; imm32, sign-extended - x86 has no imm64 store
    mov rax, 0
    xor rdi, rdi
    int 0x80

; --- slot 0x60: valid syscall using Ring 3's own mapped memory.
; Entry args (RDI=ptr, RSI=len) are already in SYS_WRITE's register
; positions, so no shuffling needed. Positive-path "Ring 3 can access
; its own mapped memory, via a validated syscall" test. ---
align 0x20
    mov rax, 1
    int 0x80
    mov rax, 0
    xor rdi, rdi
    int 0x80

; --- slot 0x80: syscall with a NULL pointer. Expected: rejected
; (RAX == -1 on return from int 0x80), kernel survives, this program
; continues and exits cleanly - proving rejection is graceful, not a
; crash. ---
align 0x20
    mov rax, 1
    xor rdi, rdi
    mov rsi, 10
    int 0x80
    mov rax, 0
    xor rdi, rdi
    int 0x80

; --- slot 0xA0: syscall with ptr+len overflowing UINT64_MAX. Expected:
; rejected without wraparound. ---
align 0x20
    mov rax, 1
    mov rdi, 0xFFFFFFFFFFFFFFF0
    mov rsi, 0x1000
    int 0x80
    mov rax, 0
    xor rdi, rdi
    int 0x80

; --- slot 0xC0: syscall with a pointer that IS mapped and present, but
; is KERNEL memory (not user memory). Expected: rejected - proves the
; validator checks the U/S bit per page, not merely "is this mapped
; anywhere". ---
align 0x20
    mov rax, 1
    mov rdi, KERNEL_IMAGE_ADDR
    mov rsi, 16
    int 0x80
    mov rax, 0
    xor rdi, rdi
    int 0x80

align 0x20
ring3_prog_end:

global ring3_prog_size
section .rodata
ring3_prog_size: dq ring3_prog_end - ring3_prog_base

; Fixed slot offsets, exported so ring3.c never hardcodes "0x60" etc.
; itself - the layout lives in exactly one place.
global ring3_slot_exit_clean
global ring3_slot_read_kernel
global ring3_slot_write_kernel
global ring3_slot_syscall_valid
global ring3_slot_syscall_null
global ring3_slot_syscall_overflow
global ring3_slot_syscall_kernel_ptr
ring3_slot_exit_clean:         dq 0x00
ring3_slot_read_kernel:        dq 0x20
ring3_slot_write_kernel:       dq 0x40
ring3_slot_syscall_valid:      dq 0x60
ring3_slot_syscall_null:       dq 0x80
ring3_slot_syscall_overflow:   dq 0xA0
ring3_slot_syscall_kernel_ptr: dq 0xC0

section .note.GNU-stack noalloc noexec nowrite progbits
