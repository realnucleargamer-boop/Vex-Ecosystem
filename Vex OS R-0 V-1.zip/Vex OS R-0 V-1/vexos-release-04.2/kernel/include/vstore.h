/*
 * Vex OS - kernel/include/vstore.h
 * STORAGE-01: tiny crash-safe settings store on a dedicated data disk. Pure logic over a block-I/O callback table so it is host-testable.
 *
 * Disk layout (512-byte sectors):  LBA0 header "VEXSTOR1" | LBA1 and LBA2 two settings slots (A/B).
 * Safety rules (these are the point of the design):
 *   - It NEVER writes to a disk it did not format. A disk is usable only if LBA0 carries a valid VEXSTOR1 header, or if it is
 *     completely BLANK (LBA0..2 all zero) AND the administrator explicitly asks for it to be formatted.
 *   - Any other disk (boot image, partitioned, foreign data) is classified FOREIGN and is never written.
 *   - Settings are written to the slot that is NOT the current best one, with seq+1 and a CRC32; the old slot stays intact until the
 *     new one verifies, so a torn write loses at most the newest value, never the whole store. The header is written LAST by format.
 */
#ifndef VEXOS_VSTORE_H
#define VEXOS_VSTORE_H
#include <stdint.h>

typedef struct {
    void *ctx;
    int (*read)(void *ctx, uint64_t lba, void *buf512);       /* 0 = ok */
    int (*write)(void *ctx, uint64_t lba, const void *buf512);
    uint64_t sectors;
} VStoreIo;
typedef enum { VS_NONE = 0, VS_BLANK, VS_READY, VS_FOREIGN, VS_IOERR } VStoreState;
typedef struct { VStoreIo io; VStoreState state; uint32_t seq; int best; uint32_t wallpaper; int have_settings; } VStore;

/* Classifies the disk and (if READY) loads the newest valid settings slot. Never writes. */
VStoreState vstore_probe(VStore *s, const VStoreIo *io);
/* Only valid in state BLANK. Writes the empty slots, then the header last, and re-probes. Returns 1 on success. */
int vstore_format(VStore *s);
/* READY only. Returns 1 if a valid slot exists and writes its wallpaper index to *idx. */
int vstore_get_wallpaper(const VStore *s, uint32_t *idx);
/* READY only. Atomically (A/B) stores the wallpaper index; verifies by read-back. Returns 1 on success. */
int vstore_set_wallpaper(VStore *s, uint32_t idx);
const char *vstore_state_text(VStoreState st);
#endif
