/*
 * Vex OS - kernel/src/core/security01_tests.c
 *
 * SECURITY-01 self-tests. See kernel/include/security01_tests.h for the
 * scope statement, and in particular for why a large part of the
 * original brief is reported as NOT APPLICABLE rather than as PASS.
 */

#include "security01_tests.h"
#include "secure.h"
#include "vmm.h"
#include "pmm.h"
#include "gdt.h"
#include "serial.h"
#include "boot03_inject.h"

/* ------------------------------------------------------------------ *
 * Reporting
 *
 * Its own counters again, for the same reason KERNEL-01 kept its own:
 * the BOOT-03 tally is what the external harness greps for and must
 * stay exactly 105/105, and a SECURITY-01 failure should say
 * SECURITY-01.
 * ------------------------------------------------------------------ */

static uint32_t g_checks;
static uint32_t g_failed;
static uint32_t g_na;

static int check(const char *sub, const char *what, int ok)
{
    g_checks++;
    if (!ok) g_failed++;
    serial_puts("[test] ");
    serial_puts(sub);
    serial_puts(ok ? ": ok   - " : ": FAIL - ");
    serial_puts(what);
    serial_puts("\n");
    return ok;
}

static int check_v(const char *sub, const char *what, int ok, uint64_t value)
{
    g_checks++;
    if (!ok) g_failed++;
    serial_puts("[test] ");
    serial_puts(sub);
    serial_puts(ok ? ": ok   - " : ": FAIL - ");
    serial_puts(what);
    serial_puts(" [");
    serial_put_hex64(value);
    serial_puts("]\n");
    return ok;
}

/* Not a pass and not a failure. A missing capability, stated as such.
 *
 * This is the honest alternative to the two dishonest options: printing
 * PASS for something that was never exercised, or quietly omitting the
 * line so the log looks complete. It is counted in its own tally and
 * cannot move the pass/fail result either way. */
static void na(const char *what)
{
    g_na++;
    serial_puts("[test] SEC-NA: n/a  - ");
    serial_puts(what);
    serial_puts(" (NOT APPLICABLE - NO USERSPACE)\n");
}

/* Informational only: an observation printed for the record that is not
 * itself an assertion. Kept visibly distinct from `ok` so that nobody
 * can later count these as passing checks. */
static void note(const char *sub, const char *what, uint64_t value)
{
    serial_puts("[test] ");
    serial_puts(sub);
    serial_puts(": note - ");
    serial_puts(what);
    serial_puts(" [");
    serial_put_hex64(value);
    serial_puts("]\n");
}

/* ------------------------------------------------------------------ *
 * SEC-PTR: range validation against hostile input
 *
 * The claim under test: sec_check_range() rejects every malformed or
 * out-of-bounds range, and accepts well-formed ones.
 *
 * Both halves matter. A validator that returns "reject" unconditionally
 * would satisfy every negative case here and be completely useless, so
 * the positive controls are not padding - they are what stops the
 * negative results from being vacuous.
 *
 * Arithmetic is exercised WITHOUT touching memory (check_mappings = 0)
 * so that an overflow bug cannot hide behind an unrelated
 * not-mapped rejection. The mapping walk is then tested separately
 * against real mappings the test creates itself.
 * ------------------------------------------------------------------ */

#define S_PTR "SEC-PTR"

static int test_pointer_validation(void)
{
    int ok = 1;
    const SecWindow *kw = sec_window_kmap();

    /* --- canonicality, independent of any range --- */
    ok &= check(S_PTR, "0x0000000000001000 is canonical",
                sec_is_canonical(0x1000ULL));
    ok &= check(S_PTR, "0x00007FFFFFFFFFFF is canonical (last low address)",
                sec_is_canonical(0x00007FFFFFFFFFFFULL));
    ok &= check(S_PTR, "0x0000800000000000 is NOT canonical (hole starts)",
                !sec_is_canonical(0x0000800000000000ULL));
    ok &= check(S_PTR, "0xFFFF7FFFFFFFFFFF is NOT canonical (hole ends)",
                !sec_is_canonical(0xFFFF7FFFFFFFFFFFULL));
    ok &= check(S_PTR, "0xFFFF800000000000 is canonical (first high address)",
                sec_is_canonical(0xFFFF800000000000ULL));
    ok &= check(S_PTR, "kmap base is canonical",
                sec_is_canonical(VEX_KMAP_BASE));

    /* --- overflow-checked arithmetic --- */
    uint64_t r64 = 0;
    ok &= check(S_PTR, "1 + 1 does not overflow",
                sec_add_ovf(1, 1, &r64) && r64 == 2);
    ok &= check(S_PTR, "UINT64_MAX + 1 is reported as overflow",
                !sec_add_ovf(UINT64_MAX, 1, &r64));
    ok &= check(S_PTR, "1 + UINT64_MAX is reported as overflow (operand order)",
                !sec_add_ovf(1, UINT64_MAX, &r64));
    ok &= check(S_PTR, "UINT64_MAX + 0 does not overflow (boundary is exact)",
                sec_add_ovf(UINT64_MAX, 0, &r64) && r64 == UINT64_MAX);
    ok &= check(S_PTR, "4096 * 4096 does not overflow",
                sec_mul_ovf(4096, 4096, &r64) && r64 == 0x1000000ULL);
    ok &= check(S_PTR, "(1<<63) * 4 is reported as overflow",
                !sec_mul_ovf(1ULL << 63, 4, &r64));
    ok &= check(S_PTR, "0 * UINT64_MAX does not overflow",
                sec_mul_ovf(0, UINT64_MAX, &r64) && r64 == 0);

    /* On overflow the output must be left alone, so that a caller who
     * ignores the return value cannot pick up a wrapped value and use
     * it as if it were a length. */
    r64 = 0xDEADBEEF;
    (void)sec_add_ovf(UINT64_MAX, 8, &r64);
    ok &= check_v(S_PTR, "overflowing add leaves the output untouched",
                  r64 == 0xDEADBEEF, r64);

    /* --- the range checker, arithmetic only --- */

    /* POSITIVE CONTROL. Without this the negative results below prove
     * nothing: a checker that rejects everything would pass them all. */
    ok &= check(S_PTR, "POSITIVE: a well-formed in-window range is accepted",
                sec_check_range(VEX_KMAP_BASE, 0x1000, kw,
                                SEC_ACCESS_READ, 0, 0) == SEC_RANGE_OK);
    ok &= check(S_PTR, "POSITIVE: a range ending exactly at the window end "
                "is accepted",
                sec_check_range(VEX_KMAP_BASE + VEX_KMAP_SIZE - 0x1000,
                                0x1000, kw, SEC_ACCESS_READ, 0, 0)
                == SEC_RANGE_OK);

    /* Overflow. base + len wraps to a small number; a checker that
     * computes the end before testing for wrap sees a tiny range that
     * satisfies every bound. */
    ok &= check(S_PTR, "ptr + len overflow is rejected (len = UINT64_MAX)",
                sec_check_range(VEX_KMAP_BASE, UINT64_MAX, kw,
                                SEC_ACCESS_READ, 0, 0) == SEC_ERR_OVERFLOW);
    ok &= check(S_PTR, "ptr + len overflow is rejected (base near the top)",
                sec_check_range(0xFFFFFFFFFFFFF000ULL, 0x2000, kw,
                                SEC_ACCESS_READ, 0, 0) == SEC_ERR_OVERFLOW);

    /* Non-canonical, in both directions. */
    ok &= check(S_PTR, "a non-canonical base is rejected",
                sec_check_range(0x0000800000000000ULL, 0x1000, 0,
                                SEC_ACCESS_READ, 0, 0)
                == SEC_ERR_NON_CANONICAL);
    ok &= check(S_PTR, "a canonical base whose LAST BYTE is non-canonical "
                "is rejected",
                sec_check_range(0x00007FFFFFFFF000ULL, 0x2000, 0,
                                SEC_ACCESS_READ, 0, 0)
                == SEC_ERR_NON_CANONICAL);

    /* Straddling the hole: both ends canonical, everything between is
     * not. Only a check that compares the two halves catches it. */
    ok &= check(S_PTR, "a range straddling the canonical hole is rejected",
                sec_check_range(0x00007FFFFFFFF000ULL,
                                0xFFFF800000001000ULL - 0x00007FFFFFFFF000ULL,
                                0, SEC_ACCESS_READ, 0, 0)
                == SEC_ERR_STRADDLES_HOLE);

    /* Window bounds, including the one-byte-past case that a
     * first-byte-only check cannot see. */
    ok &= check(S_PTR, "a range starting below the window is rejected",
                sec_check_range(VEX_KMAP_BASE - 0x1000, 0x1000, kw,
                                SEC_ACCESS_READ, 0, 0)
                == SEC_ERR_OUT_OF_WINDOW);
    ok &= check(S_PTR, "a range starting INSIDE but ending past the window "
                "end is rejected",
                sec_check_range(VEX_KMAP_BASE + VEX_KMAP_SIZE - 0x1000,
                                0x2000, kw, SEC_ACCESS_READ, 0, 0)
                == SEC_ERR_OUT_OF_WINDOW);
    ok &= check(S_PTR, "a huge length from a valid base is rejected, not "
                "truncated to the window",
                sec_check_range(VEX_KMAP_BASE, VEX_KMAP_SIZE + 0x1000, kw,
                                SEC_ACCESS_READ, 0, 0)
                == SEC_ERR_OUT_OF_WINDOW);

    /* Zero length: whichever answer, it must be the one the caller
     * asked for, rather than whatever falls out of the arithmetic. */
    ok &= check(S_PTR, "zero length is rejected when the caller disallows it",
                sec_check_range(VEX_KMAP_BASE, 0, kw, SEC_ACCESS_READ, 0, 0)
                == SEC_ERR_ZERO_LEN);
    ok &= check(S_PTR, "zero length is accepted when the caller allows it",
                sec_check_range(VEX_KMAP_BASE, 0, kw, SEC_ACCESS_READ, 1, 0)
                == SEC_RANGE_OK);

    /* --- the mapping walk, against mappings this test creates --- *
     *
     * Two adjacent pages of virtual space; the first is mapped, the
     * second deliberately is not. A range covering both must be
     * rejected. A checker that validates only the first page accepts
     * it, which is precisely injection 13. */
    uint64_t vbase = vmm_kmap_reserve_virtual(2);
    if (vbase == 0) {
        ok &= check(S_PTR, "reserved 2 kmap pages for the cross-page test", 0);
        return ok;
    }
    uint64_t frame = pmm_alloc_page();
    if (frame == 0) {
        ok &= check(S_PTR, "allocated a frame for the cross-page test", 0);
        (void)vmm_kmap_free_virtual(vbase, 2);
        return ok;
    }

    SecWindow local = { vbase, 2 * VMM_PAGE_SIZE };
    ok &= check(S_PTR, "mapped the first page of the cross-page test",
                vmm_map_page(vbase, frame, VMM_KERNEL_RW_NX) == VMM_OK);

    ok &= check(S_PTR, "POSITIVE: a range inside the single mapped page is "
                "accepted with mapping checks on",
                sec_check_range(vbase, VMM_PAGE_SIZE, &local,
                                SEC_ACCESS_WRITE, 0, 1) == SEC_RANGE_OK);

    ok &= check(S_PTR, "a range spanning into the UNMAPPED second page is "
                "rejected (whole range is validated)",
                sec_check_range(vbase, 2 * VMM_PAGE_SIZE, &local,
                                SEC_ACCESS_WRITE, 0, 1) == SEC_ERR_NOT_MAPPED);

    /* A one-byte range that merely starts in the good page but extends
     * one byte into the bad one. The smallest possible version of the
     * bug, and the one a coarse check is likeliest to miss. */
    ok &= check(S_PTR, "a range ending ONE BYTE into the unmapped page is "
                "rejected",
                sec_check_range(vbase + VMM_PAGE_SIZE - 1, 2, &local,
                                SEC_ACCESS_READ, 0, 1) == SEC_ERR_NOT_MAPPED);

    /* Write access against a read-only mapping. */
    ok &= check(S_PTR, "re-protected the test page read-only",
                vmm_protect_page(vbase, VMM_KERNEL_RO_NX) == VMM_OK);
    ok &= check(S_PTR, "POSITIVE: read access to a read-only page is accepted",
                sec_check_range(vbase, VMM_PAGE_SIZE, &local,
                                SEC_ACCESS_READ, 0, 1) == SEC_RANGE_OK);
    ok &= check(S_PTR, "write access to a read-only page is rejected",
                sec_check_range(vbase, VMM_PAGE_SIZE, &local,
                                SEC_ACCESS_WRITE, 0, 1) == SEC_ERR_NOT_WRITABLE);

    /* Clean up: unmap before returning the virtual range, or the free is
     * refused - which is itself a BOOT-03 invariant worth not violating
     * in a security test. */
    (void)vmm_unmap_page(vbase);
    (void)vmm_kmap_free_virtual(vbase, 2);
    return ok;
}

/* ------------------------------------------------------------------ *
 * SEC-PERM: the USER bit and W^X, in the LIVE page tables
 *
 * The claim: no entry anywhere in the active hierarchy carries the USER
 * bit, and the direct map carries NX.
 *
 * Asserted by walking the tables the CPU is using, not by asking the
 * code that built them what it intended. Those are different claims and
 * only the first is evidence - a mapper with a bug intends the right
 * thing and produces the wrong entry.
 * ------------------------------------------------------------------ */

#define S_PERM "SEC-PERM"

static int test_permissions(void)
{
    int ok = 1;
    SecPageAudit a;

    if (!sec_audit_page_tables(&a)) {
        return check(S_PERM, "walked the live page tables", 0);
    }
    ok &= check_v(S_PERM, "walked the live page tables",
                  a.entries_walked > 0, a.entries_walked);
    ok &= check_v(S_PERM, "the walk found leaf mappings",
                  a.leaves > 0, a.leaves);

    /* THE central invariant of this milestone. Every level, separately,
     * so that a violation is attributable rather than just counted. */
    ok &= check_v(S_PERM, "no PML4 entry carries the USER bit",
                  a.user_pml4 == 0, a.user_pml4);
    ok &= check_v(S_PERM, "no PDPT entry carries the USER bit",
                  a.user_pdpt == 0, a.user_pdpt);
    ok &= check_v(S_PERM, "no PD entry carries the USER bit",
                  a.user_pd == 0, a.user_pd);
    ok &= check_v(S_PERM, "no PT entry carries the USER bit",
                  a.user_pt == 0, a.user_pt);
    ok &= check_v(S_PERM, "the kernel address space contains ZERO "
                  "USER-accessible entries",
                  a.user_total == 0, a.user_total);

    /* The enforcement point, tested by attempting the thing it forbids.
     * A rejected request proves the guard runs; the audit above proves
     * the tables are clean. Both are needed: the guard could be present
     * and the tables dirty from some other path, or the tables clean
     * merely because nobody happened to ask. */
    uint64_t v = vmm_kmap_reserve_virtual(1);
    uint64_t f = pmm_alloc_page();
    if (v != 0 && f != 0) {
        VmmResult r = vmm_map_page(v, f, VMM_KERNEL_RW_NX | VMM_USER);
        ok &= check_v(S_PERM, "vmm_map_page REFUSES a mapping requesting "
                      "the USER bit", r == VMM_ERR_BAD_REQUEST, (uint64_t)r);

        /* And the refusal must have created nothing. A guard that
         * returns an error after already writing the entry is worse
         * than no guard, because the caller now believes it failed. */
        uint64_t phys = 0;
        ok &= check(S_PERM, "the refused USER mapping was NOT created",
                    vmm_translate(v, &phys) != VMM_OK);

        /* The same door, from the other side. */
        ok &= check(S_PERM, "mapped the page without the USER bit",
                    vmm_map_page(v, f, VMM_KERNEL_RW_NX) == VMM_OK);
        r = vmm_protect_page(v, VMM_KERNEL_RW_NX | VMM_USER);
        ok &= check_v(S_PERM, "vmm_protect_page REFUSES adding the USER bit "
                      "to an existing kernel mapping",
                      r == VMM_ERR_BAD_REQUEST, (uint64_t)r);

        uint64_t entry = 0, sz = 0;
        if (vmm_query(v, &entry, &sz) == VMM_OK) {
            ok &= check_v(S_PERM, "the live entry still has USER clear after "
                          "the refused protect", (entry & VMM_USER) == 0,
                          entry);
        } else {
            ok &= check(S_PERM, "queried the live entry after the refused "
                        "protect", 0);
        }

        (void)vmm_unmap_page(v);
        (void)vmm_kmap_free_virtual(v, 1);
    } else {
        ok &= check(S_PERM, "obtained a test page for the USER-bit guard", 0);
    }

    /* W^X. Stated precisely, because overclaiming here would be the
     * easiest dishonesty available: the identity map is deliberately
     * still writable+executable, because the kernel image lives in it
     * and per-section protection needs linker symbols this milestone
     * does not introduce. What SECURITY-01 establishes is the removal
     * of the SECOND, aliased W+X view of all of physical memory. */
    note(S_PERM, "W+X leaves remaining in the identity map (known, "
         "kernel image)", a.wx_identity);
    ok &= check_v(S_PERM, "the DIRECT MAP has no writable+executable leaves",
                  a.wx_direct_map == 0, a.wx_direct_map);
    ok &= check_v(S_PERM, "no W+X leaves outside the identity map",
                  a.wx_direct_map == 0 && a.wx_kmap == 0 && a.wx_other == 0,
                  a.wx_kmap + a.wx_other);
    ok &= check_v(S_PERM, "the tables contain NX leaves (NX is actually in "
                  "use, not merely supported)", a.nx_leaves > 0, a.nx_leaves);

    return ok;
}

/* ------------------------------------------------------------------ *
 * SEC-CPU: what the hardware actually offers and what is actually on
 *
 * Reported, not assumed. SMEP and SMAP are NOT enabled here, and the
 * reason is recorded in docs/SECURITY-01-DESIGN-NOTE.md: both protect
 * the kernel from user-mode pages, there is no user mode, and enabling
 * SMAP in particular would change the rules for kernel accesses in a
 * way no test in this repository could validate. Printing a PASS for
 * "SMEP enabled" by switching on a bit whose effect nothing exercises
 * would be exactly the fake security the brief forbids.
 * ------------------------------------------------------------------ */

#define S_CPU "SEC-CPU"

static int test_cpu_features(void)
{
    int ok = 1;
    SecCpuFeatures f;
    sec_cpu_features(&f);

    note(S_CPU, "CR4", f.cr4);
    note(S_CPU, "IA32_EFER", f.efer);

    /* NX is the one feature this milestone both requires and uses. */
    ok &= check(S_CPU, "the CPU reports NX support (CPUID.80000001:EDX.20)",
                f.nx_supported);
    ok &= check_v(S_CPU, "EFER.NXE is enabled", f.nx_enabled, f.efer);

    /* CR0.WP. Without it a ring-0 write to a read-only page does not
     * fault, and the read-only negative control below would pass while
     * demonstrating the opposite of what it claims. Asserted here so
     * that the SEC-FAULT result cannot be misread. */
    ok &= check(S_CPU, "CR0.WP is set (supervisor writes honour read-only)",
                vmm_write_protect_enabled());

    /* Support is reported as an observation, not asserted: whether this
     * CPU has SMEP is a fact about the host, not a property of the
     * kernel, and failing the suite on a machine without it would be a
     * test that measures the wrong thing. */
    note(S_CPU, "SMEP supported (CPUID.7:EBX.7)",
         (uint64_t)f.smep_supported);
    note(S_CPU, "SMAP supported (CPUID.7:EBX.20)",
         (uint64_t)f.smap_supported);
    note(S_CPU, "UMIP supported (CPUID.7:ECX.2)",
         (uint64_t)f.umip_supported);

    /* What IS asserted: that this milestone did not silently switch them
     * on. The decision is deliberate and documented, so the state must
     * match the decision - if some later change enables SMAP without
     * updating the design note, this check fires. */
    ok &= check_v(S_CPU, "SMEP is NOT enabled - deliberate, see "
                  "docs/SECURITY-01-DESIGN-NOTE.md (no Ring 3 exists)",
                  !f.smep_enabled, f.cr4);
    ok &= check_v(S_CPU, "SMAP is NOT enabled - deliberate, see "
                  "docs/SECURITY-01-DESIGN-NOTE.md (no Ring 3 exists)",
                  !f.smap_enabled, f.cr4);

    na("SMEP blocks kernel execution of a user page");
    na("SMAP blocks kernel data access to a user page");
    na("STAC/CLAC brackets a deliberate user access");

    return ok;
}

/* ------------------------------------------------------------------ *
 * SEC-FAULT: the CPU refuses, and says so
 *
 * Every check here is a negative control in which the hardware itself
 * denies an access. Nothing is repaired: the probe resumes at a fixup
 * and the mapping stays exactly as denied as it was. The assertions are
 * on the vector, the error code, and CR2 as reported by the CPU - not on
 * a message the kernel chose to print.
 *
 * The positive control matters as much as the denials. An access that is
 * supposed to SUCCEED must succeed through the same probe machinery; if
 * every probe reported "faulted", the denials would prove nothing about
 * the mappings and everything about a broken probe.
 * ------------------------------------------------------------------ */

#define S_FAULT "SEC-FAULT"

/* Page-fault error-code bits (Intel SDM Vol.3, "Page-Fault Exception"). */
#define PF_PRESENT  0x1u
#define PF_WRITE    0x2u
#define PF_USER     0x4u
#define PF_INSTR    0x10u

static int test_faults(void)
{
    int ok = 1;
    uint64_t vec = 0, err = 0, cr2 = 0, cs = 0;
    uint8_t val = 0;

    uint64_t v = vmm_kmap_reserve_virtual(2);
    uint64_t f = pmm_alloc_page();
    if (v == 0 || f == 0) {
        return check(S_FAULT, "obtained a page pair for the fault probes", 0);
    }
    uint64_t v_mapped   = v;
    uint64_t v_unmapped = v + VMM_PAGE_SIZE;   /* deliberately never mapped */

    ok &= check(S_FAULT, "mapped the probe page read-write",
                vmm_map_page(v_mapped, f, VMM_KERNEL_RW_NX) == VMM_OK);

    uint64_t before = sec_probe_fault_count();

    /* POSITIVE CONTROL: a legal write and read-back through the probe. */
    ok &= check(S_FAULT, "POSITIVE: writing a mapped writable page completes",
                sec_probe_write8(v_mapped, 0x5A) == 1);
    ok &= check(S_FAULT, "POSITIVE: reading it back completes",
                sec_probe_read8(v_mapped, &val) == 1);
    ok &= check_v(S_FAULT, "POSITIVE: the value read back is the value "
                  "written", val == 0x5A, val);
    ok &= check_v(S_FAULT, "POSITIVE: no fault was taken during the legal "
                  "accesses", sec_probe_fault_count() == before,
                  sec_probe_fault_count() - before);

    /* NEGATIVE: read an unmapped page. */
    before = sec_probe_fault_count();
    ok &= check(S_FAULT, "reading an UNMAPPED page does not complete",
                sec_probe_read8(v_unmapped, &val) == 0);
    ok &= check_v(S_FAULT, "the CPU actually raised an exception for it",
                  sec_probe_fault_count() == before + 1,
                  sec_probe_fault_count() - before);
    (void)sec_probe_last_fault(&vec, &err, &cr2, &cs);
    ok &= check_v(S_FAULT, "it was #PF (vector 14)", vec == 14, vec);
    ok &= check_v(S_FAULT, "CR2 is the address that was probed",
                  cr2 == v_unmapped, cr2);
    ok &= check_v(S_FAULT, "the error code says NOT PRESENT",
                  (err & PF_PRESENT) == 0, err);
    ok &= check_v(S_FAULT, "the error code says SUPERVISOR (no Ring 3 here)",
                  (err & PF_USER) == 0, err);
    ok &= check_v(S_FAULT, "the fault was taken at CPL 0",
                  (cs & 3) == 0, cs);

    /* And it must STILL be unmapped. A negative control that quietly
     * repaired the mapping would report a denial and leave behind the
     * very access it claimed to prevent. */
    uint64_t phys = 0;
    ok &= check(S_FAULT, "the unmapped page is STILL unmapped afterwards "
                "(nothing was repaired)",
                vmm_translate(v_unmapped, &phys) != VMM_OK);
    ok &= check(S_FAULT, "a second probe of it faults again (denial is "
                "persistent, not one-shot)",
                sec_probe_read8(v_unmapped, &val) == 0);

    /* NEGATIVE: write a read-only page. Meaningful only because CR0.WP
     * was asserted in SEC-CPU. */
    ok &= check(S_FAULT, "re-protected the probe page read-only",
                vmm_protect_page(v_mapped, VMM_KERNEL_RO_NX) == VMM_OK);
    ok &= check(S_FAULT, "POSITIVE: reading a read-only page still completes",
                sec_probe_read8(v_mapped, &val) == 1);
    before = sec_probe_fault_count();
    ok &= check(S_FAULT, "writing a READ-ONLY page does not complete",
                sec_probe_write8(v_mapped, 0xA5) == 0);
    ok &= check_v(S_FAULT, "the CPU raised an exception for the write",
                  sec_probe_fault_count() == before + 1,
                  sec_probe_fault_count() - before);
    (void)sec_probe_last_fault(&vec, &err, &cr2, &cs);
    ok &= check_v(S_FAULT, "it was #PF on the probe page", vec == 14, vec);
    ok &= check_v(S_FAULT, "CR2 is the read-only page", cr2 == v_mapped, cr2);
    ok &= check_v(S_FAULT, "the error code says PRESENT (a permission "
                  "violation, not a missing page)",
                  (err & PF_PRESENT) != 0, err);
    ok &= check_v(S_FAULT, "the error code says WRITE", (err & PF_WRITE) != 0,
                  err);

    /* The refused write must not have landed. */
    ok &= check(S_FAULT, "reading the page back still completes",
                sec_probe_read8(v_mapped, &val) == 1);
    ok &= check_v(S_FAULT, "the read-only page still holds the ORIGINAL "
                  "value - the refused write did not land", val == 0x5A, val);

    /* NEGATIVE: execute an NX page. This is the check that turns the
     * direct-map NX work from a flag into an enforced property. */
    ok &= check(S_FAULT, "re-protected the probe page read-only + NX",
                vmm_protect_page(v_mapped, VMM_KERNEL_RO_NX) == VMM_OK);
    before = sec_probe_fault_count();
    ok &= check(S_FAULT, "EXECUTING an NX page does not complete",
                sec_probe_exec(v_mapped) == 0);
    ok &= check_v(S_FAULT, "the CPU raised an exception for the fetch",
                  sec_probe_fault_count() == before + 1,
                  sec_probe_fault_count() - before);
    (void)sec_probe_last_fault(&vec, &err, &cr2, &cs);
    ok &= check_v(S_FAULT, "it was #PF on the fetch", vec == 14, vec);
    ok &= check_v(S_FAULT, "the error code has the INSTRUCTION FETCH bit set "
                  "(NX is enforced, not merely flagged)",
                  (err & PF_INSTR) != 0, err);
    ok &= check_v(S_FAULT, "CR2 is the NX page", cr2 == v_mapped, cr2);

    /* NEGATIVE: touch a non-canonical address. Included because it
     * produces #GP, not #PF - a validator or handler that assumes every
     * bad pointer arrives as a page fault mishandles exactly this. */
    before = sec_probe_fault_count();
    ok &= check(S_FAULT, "reading a NON-CANONICAL address does not complete",
                sec_probe_read8(0x0000800000000000ULL, &val) == 0);
    ok &= check_v(S_FAULT, "the CPU raised an exception for it",
                  sec_probe_fault_count() == before + 1,
                  sec_probe_fault_count() - before);
    (void)sec_probe_last_fault(&vec, &err, &cr2, &cs);
    ok &= check_v(S_FAULT, "it was #GP (vector 13), NOT a page fault",
                  vec == 13, vec);

    /* The direct map, end to end: it is NX in the tables (SEC-PERM) and
     * the CPU refuses to fetch from it (here). Physical page 0 is chosen
     * because it is mapped in both windows, so the fetch is refused for
     * the permission and not for being absent. */
    uint64_t dm = VEX_PHYS_MAP_BASE + 0x1000;
    if (vmm_translate(dm, &phys) == VMM_OK) {
        ok &= check(S_FAULT, "POSITIVE: reading through the direct map "
                    "completes", sec_probe_read8(dm, &val) == 1);
        before = sec_probe_fault_count();
        ok &= check(S_FAULT, "EXECUTING through the direct map does not "
                    "complete", sec_probe_exec(dm) == 0);
        (void)sec_probe_last_fault(&vec, &err, &cr2, &cs);
        ok &= check_v(S_FAULT, "the direct-map fetch faulted with the "
                      "INSTRUCTION FETCH bit set",
                      vec == 14 && (err & PF_INSTR) != 0, err);
    } else {
        ok &= check(S_FAULT, "the direct map covers the low physical pages", 0);
    }

    (void)vmm_unmap_page(v_mapped);
    (void)vmm_kmap_free_virtual(v, 2);

    na("a Ring 3 read of a kernel page raises #PF with USER set");
    na("a Ring 3 write to a read-only user page raises #PF");
    na("a fatal user fault terminates the offending process");
    na("an invalid syscall number is rejected at the syscall entry");
    na("a syscall pointer argument is validated before use");

    return ok;
}

/* ------------------------------------------------------------------ *
 * SEC-ISO: descriptor-table privilege state
 *
 * What can honestly be checked about privilege separation on a system
 * with only one privilege level in use: that the descriptors are shaped
 * the way a ring transition would require, and that the parts which
 * would carry a transition are visibly inert rather than half-configured.
 *
 * A half-configured ring transition is worse than none. rsp0 = 0 with no
 * transition is inert; rsp0 = 0 with a transition is a fault on a null
 * stack, in the handler, at the worst moment. Asserting it is zero pins
 * the current state so that adding user mode cannot quietly inherit it.
 * ------------------------------------------------------------------ */

#define S_ISO "SEC-ISO"

static int test_isolation(void)
{
    int ok = 1;

    uint16_t cs = gdt_read_cs();
    ok &= check_v(S_ISO, "the kernel is running at CPL 0", (cs & 3) == 0, cs);
    ok &= check_v(S_ISO, "CS is the kernel code selector",
                  (cs & ~0x7) == (GDT_SEL_KERNEL_CODE & ~0x7), cs);

    /* The user selectors exist in the GDT but nothing loads them. Their
     * DPL is checked anyway: if a later milestone starts using them, it
     * inherits descriptors that were already verified to be DPL 3, and
     * if someone "fixes" them to DPL 0 the privilege separation would be
     * silently gone before user mode ever ran. */
    ok &= check_v(S_ISO, "the user code selector carries RPL 3",
                  (GDT_SEL_USER_CODE & 3) == 3, GDT_SEL_USER_CODE);
    ok &= check_v(S_ISO, "the user data selector carries RPL 3",
                  (GDT_SEL_USER_DATA & 3) == 3, GDT_SEL_USER_DATA);

    /* TSS descriptors must be DPL 0: a DPL 3 TSS descriptor would let
     * Ring 3 load the task register. Read out of the GDT's own bytes,
     * not from the constant that was meant to be written there. */
    uint8_t access = gdt_tss_descriptor_access(0);
    ok &= check_v(S_ISO, "the BSP TSS descriptor is present",
                  (access & 0x80) != 0, access);
    ok &= check_v(S_ISO, "the BSP TSS descriptor is DPL 0",
                  ((access >> 5) & 3) == 0, access);
    /* Type 0x0B, not 0x09. The GDT is BUILT with 0x89 (available 64-bit
     * TSS), and `ltr` makes the CPU set the busy bit in the descriptor
     * in memory - so the live byte reads 0x8B once the task register has
     * actually been loaded.
     *
     * The first version of this check asserted 0x09 and failed on real
     * hardware behaviour. Keeping the corrected form as an assertion on
     * BUSY rather than relaxing it to "either value" is deliberate: busy
     * is positive evidence that LTR executed, which is a stronger claim
     * than the one the broken check was trying to make. Accepting both
     * values would have turned a real observation into a check that
     * cannot fail. */
    ok &= check_v(S_ISO, "the BSP TSS descriptor type is 64-bit TSS",
                  (access & 0x0D) == 0x09, access);
    ok &= check_v(S_ISO, "the BSP TSS descriptor is BUSY - the CPU set that "
                  "bit, so LTR really executed",
                  (access & 0x0F) == 0x0B, access);

    na("a Ring 3 attempt to load a kernel data selector raises #GP");
    na("SYSCALL/SYSRET MSRs point at a validated kernel entry");
    na("TSS.rsp0 delivers a ring transition onto a per-CPU kernel stack");

    return ok;
}

/* ------------------------------------------------------------------ *
 * Driver
 * ------------------------------------------------------------------ */

void security01_run_tests(Security01Results *out)
{
    g_checks = 0;
    g_failed = 0;
    g_na = 0;

    serial_puts("\n[kernel] SECURITY-01 self-tests\n");
    serial_puts("[kernel] SCOPE: no Ring 3 exists in this build. Items that\n");
    serial_puts("[kernel] require user mode are reported NOT APPLICABLE and\n");
    serial_puts("[kernel] are never counted as passing. See "
                "docs/SECURITY-01.md\n");

    Security01Results r;
    r.ptr   = test_pointer_validation();
    r.perm  = test_permissions();
    r.cpu   = test_cpu_features();
    r.fault = test_faults();
    r.iso   = test_isolation();

    r.checks_run     = g_checks;
    r.checks_failed  = g_failed;
    r.not_applicable = g_na;

    if (out) *out = r;
}

int security01_all_passed(const Security01Results *r)
{
    if (!r) return 0;
    if (r->checks_failed != 0) return 0;
    if (r->checks_run == 0) return 0;   /* a suite that ran nothing is not a pass */
    return r->ptr && r->perm && r->cpu && r->fault && r->iso;
}

void security01_print_summary(const Security01Results *r)
{
    serial_puts("===== ");
    serial_put_dec64(r->checks_run - r->checks_failed);
    serial_puts("/");
    serial_put_dec64(r->checks_run);
    serial_puts(" SECURITY-01 checks passed =====\n");

    serial_puts("VEX OS SECURITY-01\n");
    serial_puts("SEC-PTR: ");   serial_puts(r->ptr   ? "PASS\n" : "FAIL\n");
    serial_puts("SEC-PERM: ");  serial_puts(r->perm  ? "PASS\n" : "FAIL\n");
    serial_puts("SEC-CPU: ");   serial_puts(r->cpu   ? "PASS\n" : "FAIL\n");
    serial_puts("SEC-FAULT: "); serial_puts(r->fault ? "PASS\n" : "FAIL\n");
    serial_puts("SEC-ISO: ");   serial_puts(r->iso   ? "PASS\n" : "FAIL\n");

    serial_puts("SECURITY-01 NOT APPLICABLE (no userspace): ");
    serial_put_dec64(r->not_applicable);
    serial_puts("\n");

    if (security01_all_passed(r)) {
        /* Deliberately NOT "SECURITY-01 COMPLETE". The milestone as
         * specified assumes a Ring 3 boundary this repository does not
         * have, so a large part of it is untested rather than passing.
         * Printing COMPLETE here would let an absent userspace satisfy a
         * userspace security milestone. */
        serial_puts("SECURITY-01 PARTIAL: implemented invariants PASS; "
                    "Ring 3 items NOT APPLICABLE\n");
    } else {
        serial_puts("SECURITY-01: FAILED - ");
        serial_put_dec64(r->checks_failed);
        serial_puts(" of ");
        serial_put_dec64(r->checks_run);
        serial_puts(" checks failed.\n");
    }
    serial_puts("\n");
}
