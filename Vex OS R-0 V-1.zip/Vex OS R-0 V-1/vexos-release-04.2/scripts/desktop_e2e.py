#!/usr/bin/env python3
"""SUPERSEDED by scripts/release_e2e.py: RELEASE-02 requires passwords at first-run/sign-in, which this script does not type.
Vex OS - scripts/desktop_e2e.py : DESKTOP-01 end-to-end verification in QEMU (q35/TCG/OVMF, project machine config).
Real PS/2 key + mouse events are injected through QEMU's i8042; results come from the guest's serial log and from
exact framebuffer pixels (screendump).  Needs two images:
  build/vexos.img        normal build            (first-run flow, one account)
  build/vexos-seed.img   built with -DVEX_DEV_SEED_ACCOUNTS=1 (3 accounts, to exercise multi-account UI)
Usage: python3 scripts/desktop_e2e.py [normal.img] [seed.img]"""
import os, re, sys, time
sys.path.insert(0, os.path.dirname(__file__))
from qemu_drive import Vm, load_ppm, ppm_to_png
IMG = sys.argv[1] if len(sys.argv) > 1 else "build/vexos.img"
SEED = sys.argv[2] if len(sys.argv) > 2 else "build/vexos-seed.img"
OUT = os.environ.get("E2E_OUT", "build/desktop-e2e"); os.makedirs(OUT, exist_ok=True)
results = []
def check(ok, what, detail=""):
    results.append((bool(ok), what)); print(("PASS  " if ok else "FAIL  ") + what + (f"   [{detail}]" if detail and not ok else ""), flush=True); return ok
def count(vm, pat): return len(re.findall(pat, vm.serial()))
def settle(t=0.4): time.sleep(t)
def shot(vm, n):
    p = os.path.join(OUT, n + ".ppm"); vm.screendump(p); ppm_to_png(p, os.path.join(OUT, n + ".png")); return load_ppm(p)
def rects(vm, tag):
    """last '[ui] ... <tag>' log line -> {name: (x,y,w,h)}"""
    ls = [l for l in vm.serial().splitlines() if tag in l]
    return {m.group(1): tuple(map(int, m.groups()[1:])) for m in re.finditer(r"(\w+)=\((\d+),(\d+),(\d+),(\d+)\)", ls[-1])} if ls else {}
def centre(r): return (r[0] + r[2] // 2, r[1] + r[3] // 2)
def move_rel(vm, dx, dy):
    while dx or dy:
        sx = max(-100, min(100, dx)); sy = max(-100, min(100, dy)); vm.mouse_move(sx, sy); dx -= sx; dy -= sy; time.sleep(0.03)
    settle()
def move_to(vm, x, y): move_rel(vm, -1500, -1000); move_rel(vm, x, y)
def click(vm, r): move_to(vm, *centre(r)); vm.mouse_button(1); time.sleep(0.25); vm.mouse_button(0); settle(0.5)
KEY = {" ": "spc", "-": "minus", ".": "dot", ",": "comma", "/": "slash", "!": "shift-1", "_": "shift-minus", "?": "shift-slash", "\n": "ret"}
def typ(vm, s, gap=0.12):
    for c in s:
        k = KEY.get(c) or ("shift-" + c.lower() if c.isupper() else c); vm.sendkey(k); time.sleep(gap)
    settle(0.3)
def boot(img, tag, pat=r"\[ui\] (setup|lock) screen shown", **kw):
    vm = Vm(img, OUT, tag=tag, **kw); ok = vm.wait_serial(pat, 150); settle(1.0); return vm, ok
def diff_px(a, b, box):
    n = 0
    for y in range(box[1], box[1] + box[3], 2):
        for x in range(box[0], box[0] + box[2], 2):
            if a.getpixel((x, y)) != b.getpixel((x, y)): n += 1
    return n

print("\n=== A. Normal build: first-run -> lock -> panels -> desktop -> terminal ===")
vm, ok = boot(IMG, "A"); log = vm.serial()
check(ok and "[ui] setup screen shown" in log, "no accounts -> first-run SETUP screen is shown (not the lock screen)")
check("[ui] lock screen shown" not in log, "lock screen is NOT shown before an account exists")
for pat, nm in [(r"105/105 checks passed", "BOOT-03 105/105"), (r"210/210 KERNEL-01", "KERNEL-01 210/210"), (r"97/97 SECURITY-01", "SECURITY-01 97/97"),
                (r"7/7 checks passed", "Graphics 2 7/7"), (r"108/108 SECURITY-02", "SECURITY-02 108/108"), (r"(\d+)/\1 INPUT-03", "INPUT-03 all passed"),
                (r"(\d+)/\1 DESKTOP-01", "DESKTOP-01 logic suite all passed")]:
    check(re.search(pat, log), "boot: " + nm)
check("SYSTEM READY" in log and "BOOT SAGA COMPLETE" in log and "VEX KERNEL PANIC" not in log, "boot: SYSTEM READY, BOOT SAGA COMPLETE, no panic")
m = re.search(r"\[memory\]   TOTAL: (\d+) bytes", log); boot_total = int(m.group(1)) if m else 0
check(boot_total and "DESKTOP-01 budget 20 MiB (20971520 B): PASS" in log, f"memory at boot: {boot_total} B < 20 MiB budget (measured)")
shot(vm, "01_setup"); R = rects(vm, "setup screen shown")
click(vm, R["name"]); vm.sendkey("ret"); settle(0.6)
check(count(vm, r"rejected: Account name cannot be empty") == 1 and "[ui] lock screen shown" not in vm.serial(), "empty name rejected with a message; still on setup")
vm.sendkey("spc"); vm.sendkey("ret"); settle(0.6)
check("lock screen shown" not in vm.serial() and count(vm, r"account creation rejected") == 2, "whitespace-only name cannot bypass setup (Enter/Space)")
for _ in range(4): vm.sendkey("backspace")
typ(vm, "ab\n"); check("at least 3 characters" in vm.serial(), "too-short name rejected with reason")
typ(vm, "!\n"); settle(0.4); shot(vm, "02_setup_error")
check(count(vm, r"account creation rejected") == 4 and "lock screen shown" not in vm.serial(), "invalid character rejected")
for _ in range(8): vm.sendkey("backspace")
typ(vm, "Vex\n"); settle(1.0)
check(count(vm, r"account created: Vex \[backend: RAM \(temporary") == 1 and "[ui] lock screen shown" in vm.serial(), "valid name creates the account (labelled RAM/temporary) and shows the lock screen")
R = rects(vm, "lock screen shown"); shot(vm, "03_lock")
check(set(R) >= {"signin", "users", "net", "power"} and R["users"][1] == R["net"][1] == R["power"][1] and R["users"][0] < R["net"][0] < R["power"][0], "lock: Users, Internet, Power form one row (lower-right)")
click(vm, R["users"]); check(count(vm, r"users panel opened") == 1, "Users button opens the switch-user panel"); shot(vm, "04_users_1acct")
vm.sendkey("esc"); settle(0.5); check("users panel closed (ESC)" in vm.serial(), "ESC dismisses the users panel")
click(vm, R["net"]); check(count(vm, r"network panel opened") == 1, "Internet button opens the network panel"); shot(vm, "05_network")
move_to(vm, 5, 5); vm.mouse_button(1); time.sleep(0.2); vm.mouse_button(0); settle(0.5)
check("network panel closed (click outside)" in vm.serial(), "click outside dismisses the network panel")
click(vm, R["power"]); check(count(vm, r"power menu opened") == 1, "Power button opens the power menu"); shot(vm, "06_power")
P = rects(vm, "power menu opened"); vm.sendkey("esc"); settle(0.5)
img = shot(vm, "07_lock_clean"); 
vm.sendkey("ret"); settle(1.0)
check(count(vm, r"signed in as Vex \(via ENTER\)") == 1 and "[ui] desktop shown" in vm.serial(), "ENTER on the lock screen signs in as the selected account -> desktop")
D = rects(vm, "desktop shown"); img = shot(vm, "08_desktop")
check(img.getpixel((300, 300)) == (0, 0, 0) and img.getpixel((900, 450)) == (0, 0, 0), "desktop background is plain black")
check(set(D) >= {"vbtn", "search", "term"}, "desktop: V button, search bar, pinned terminal present")
m = re.search(r"\[memory\] \[after sign-in\].*", vm.serial()); check(m and "PASS" in m.group(0), "memory after sign-in measured", m.group(0)[:160] if m else "")
click(vm, D["vbtn"]); check(count(vm, r"V menu opened") == 1, "V button opens the V menu"); shot(vm, "09_vmenu")
vm.sendkey("esc"); settle(0.5); check("V menu closed (ESC)" in vm.serial(), "ESC closes the V menu")
click(vm, D["search"]); check(count(vm, r"search results opened") == 1, "search bar click opens results")
typ(vm, "term"); shot(vm, "10_search"); vm.sendkey("esc"); settle(0.5)
click(vm, D["vbtn"]); V = rects(vm, "V menu opened"); click(vm, V["item0"])
check(count(vm, r"Verminal launched") == 1, "V menu: Verminal launches the VexScript app"); settle(0.6); shot(vm, "11_terminal")
typ(vm, "v. help\n"); shot(vm, "12_help")
typ(vm, "foo\n"); settle(0.3)
typ(vm, "v. processes\n"); settle(1.2); a = shot(vm, "13_proc_a"); settle(2.2); b = shot(vm, "13_proc_b")
box = (150, 110, 900, 60)       # the two table rows (uptime digits)
check(diff_px(a, b, box) > 0, "process list refreshes: uptime digits changed between captures while the view is open")
vm.sendkey("esc"); settle(1.5); c = shot(vm, "14_after_esc"); settle(3.0); d = shot(vm, "14_after_esc_later")
check(diff_px(c, d, (200, 100, 700, 450)) == 0, "after leaving the process view the terminal area no longer changes (refresh stopped)")
for _ in range(3): typ(vm, "v. processes\n"); settle(1.2); vm.sendkey("esc"); settle(0.6)
typ(vm, "v. input test\n"); typ(vm, "Hello, VEX OS! 123"); shot(vm, "15_input_live"); vm.sendkey("backspace"); vm.sendkey("backspace"); vm.sendkey("ret"); settle(0.5); shot(vm, "16_input_submitted")
vm.sendkey("esc"); settle(0.5)
typ(vm, "v. exit\n"); settle(0.8)
check("Verminal closed (timer stopped)" in vm.serial() and "[ui] desktop shown" in vm.serial().split("Verminal closed")[-1], "`v. exit` closes the terminal and returns to the desktop")
m = re.search(r"\[memory\] \[terminal closed\].*", vm.serial()); check(m and "PASS" in m.group(0), "memory after exercising desktop + terminal measured", m.group(0)[:200] if m else "")
print("   memory snapshots:"); [print("     ", l[:210]) for l in vm.serial().splitlines() if l.startswith("[memory] [")]
click(vm, rects(vm, "desktop shown")["term"]); settle(0.6); vm.sendkey("esc"); settle(0.6)
check(count(vm, r"Verminal launched") == 2 and count(vm, r"Verminal closed") == 2, "taskbar icon launches; Esc closes (one instance per launch)")
check(vm.alive() and "VEX KERNEL PANIC" not in vm.serial() and "UNHANDLED CPU EXCEPTION" not in vm.serial(), "no panic / unhandled exception after the full session")
click(vm, rects(vm, "desktop shown")["vbtn"]); V = rects(vm, "V menu opened"); click(vm, V["item1"])
check(count(vm, r"session locked \(via V menu\)") == 1, "V menu -> Lock returns to the lock screen")
R = rects(vm, "lock screen shown"); click(vm, R["power"]); P = rects(vm, "power menu opened"); click(vm, P["item0"]); settle(2.0)
check("[ui] power: shutdown requested" in vm.serial() and "executing ACPI S5 shutdown" in vm.serial() and "shutdown" in vm.status().lower(), "Shut down: real ACPI S5 power-off (QEMU reports the guest shut down)")
vm.stop()

print("\n=== B. Reboot: accounts are temporary (honest persistence check) ===")
vm, ok = boot(IMG, "B", allow_reboot=True); R = rects(vm, "setup screen shown")
click(vm, R["name"]); typ(vm, "Vex\n"); settle(1.0); R = rects(vm, "lock screen shown"); click(vm, R["power"]); P = rects(vm, "power menu opened"); click(vm, P["item1"])
t0 = time.time(); ok2 = False
while time.time() - t0 < 120:
    if count(vm, r"\[ui\] setup screen shown") >= 2: ok2 = True; break
    time.sleep(0.5)
check(ok2, "after a real guest reboot the account is GONE and first-run setup appears again: accounts are NOT persistent (documented limitation)")
vm.stop()

if os.path.exists(SEED):
    print("\n=== C. Dev-seeded build: multi-account Users panel + switching ===")
    vm, ok = boot(SEED, "C", pat=r"\[ui\] lock screen shown"); R = rects(vm, "lock screen shown")
    check(ok and "VEX_DEV_SEED_ACCOUNTS" in vm.serial() and "[ui] setup screen shown" not in vm.serial(), "accounts present -> first-run is skipped, lock screen shown")
    shot(vm, "20_lock_vex"); click(vm, R["users"]); U = rects(vm, "users panel opened"); shot(vm, "21_users_3")
    check(all(k in U for k in ("item0", "item1", "item2", "item3")) and "item4" not in U, "Users panel lists the 3 actual accounts + Close")
    click(vm, U["item1"]); check("[ui] selected account Nexus" in vm.serial(), "selecting Nexus updates the selected account"); img = shot(vm, "22_lock_nexus")
    vm.sendkey("ret"); settle(1.0)
    check("signed in as Nexus (via ENTER)" in vm.serial(), "sign-in uses the newly selected identity (Nexus)")
    shot(vm, "23_desktop_nexus"); vm.stop()
else: print("NOT RUN: seeded build missing")

print("\n=== D. Stress ===")
vm, ok = boot(IMG, "D"); R = rects(vm, "setup screen shown"); click(vm, R["name"]); typ(vm, "Vex\n"); settle(1.0)
vm.sendkey("ret"); settle(1.0); D = rects(vm, "desktop shown"); click(vm, D["term"]); settle(0.6)
for i in range(150): vm.sendkey("a"); 
for i in range(40): vm.mouse_move(30 if i % 2 else -30, 20)
typ(vm, "v. processes\n"); settle(2.5)
check(vm.alive() and "VEX KERNEL PANIC" not in vm.serial() and "running" in vm.status().lower(), "key/mouse flood into the terminal then process view: guest alive, no panic")
vm.sendkey("esc"); typ(vm, "v. help\n"); shot(vm, "30_after_flood")
check(vm.alive(), "terminal still responsive after the flood")
vm.stop()
print("\n=== Summary ===")
bad = [w for ok, w in results if not ok]
print(f"{len(results) - len(bad)}/{len(results)} DESKTOP-01 end-to-end checks passed")
for w in bad: print("  FAILED:", w)
sys.exit(1 if bad else 0)
