# Vex IR 1.3 — Canonical Intermediate Representation

**Status:** Implemented  
**Used by:** VexScript **3.0.0**, VEX-C **5.0.1**  
**Supersedes emit default:** IR 1.2 (still accepted by validators)

## 1. Version header

```text
; Vex IR 1.3
ir_version 1.3
calling_conv sysv_amd64    ; or vex_hosted
```

| Producer | `calling_conv` |
|----------|----------------|
| VexScript hosted | `vex_hosted` |
| VEX-C native path emit | `sysv_amd64` |

## 2. Compatibility matrix

| Consumer \ Producer | IR 1.2 | IR 1.3 |
|---------------------|--------|--------|
| VexScript validator | yes | yes |
| VexScript IR interpreter | yes* | yes |
| VEX-C `--emit-ir` | emits 1.3 | emits 1.3 |

\*1.2 modules without tensor/evolve calls run as before.

## 3. Core ops (shared)

Inherited from 1.2:

`const`, `copy`, `add/sub/mul/div/mod`, `eq/ne/lt/le/gt/ge`, `and/or/not`,  
`load_local` / `store_local`, `br` / `br_cond` / `ret`, `call`,  
`make_struct` / `extract` / `insert`, `make_array` / `index`

## 4. VexScript 3.0 extensions (via `call`)

Tensor / neural / evolve are **hosted builtins** invoked as IR calls (keeps VEX-C and VexScript IR text aligned without forcing every backend to implement tensor kernels):

```text
call @tensor_create_2
call @tensor_add
call @neural_linear
call @evolve_create
call @rng_seed
```

First-class `tensor.*` opcodes remain **IR 2.0** design (`docs/vex-ir-2.0.md`).

## 5. Types

`i8`…`i64`, `u8`…`u64`, `bool`, `void`, `string`, `T[]`, struct names,  
`tensor` / `tensor<f32,[…]>` (VexScript), pointer annotations where present.

## 6. Determinism

Text form is ordered (functions sorted by name in VexScript printer).  
RNG and evolve require explicit `rng_seed` for reproducibility.

## 7. Non-goals

- Frozen Vex OS syscall numbers  
- GPU dialect  
- Autodiff  
