/*
 * Vex OS - kernel/include/wallpaper.h
 *
 * WALLPAPER-01: desktop wallpaper state and cache.  There is ONE desktop; a wallpaper only changes what
 * vexui's single background-paint routine (bg_rect) copies behind windows, the taskbar and the widgets.
 *
 * Index 0 is always the built-in DEFAULT (the procedural navy "Zen Horizon" gradient in vexui.c): it
 * needs no asset, no allocation and cannot fail, so "reset to default" is always possible.
 * Indices 1..N are the embedded VWP1 assets in wallpaper_data.c (wp_assets[idx-1]).
 *
 * Applying a wallpaper decodes it ONCE into a screen-sized cache of framebuffer-format pixels
 * (physical frames from the PMM, freed again when the default is restored).  Repainting any exposed
 * rectangle is then a plain row copy: no per-repaint decoding or allocation.
 */
#ifndef VEXOS_WALLPAPER_H
#define VEXOS_WALLPAPER_H

#include <stdint.h>
#include "wallpaper_core.h"
#include "gfx/fb.h"

#define WP_CACHE_MAX_BYTES (16u * 1024u * 1024u)    /* hard cap: 1920x1200x4 = 8.8 MB fits; 4K (33 MB) is refused */
#define WP_MIN_SCREEN      64u

int         wp_count(void);                         /* 1 (default) + embedded wallpapers */
const char *wp_name(int idx);                       /* NULL if idx is out of range */
const char *wp_id(int idx);
WpStatus    wp_status(int idx);                     /* WP_OK, or why this wallpaper cannot be used (verified once, cached) */
void        wp_recheck(void);                       /* forget cached verification results (tests) */

int         wp_applied(void);                       /* currently applied index (0 = default) */
int         wp_active(void);                        /* 1 if a screen-sized cache is live */
uint32_t    wp_cache_bytes(void);                   /* bytes of cache currently held (0 when default) */
uint32_t    wp_cache_dims(uint32_t *w, uint32_t *h);

/* Apply wallpaper idx for fb.  On ANY failure the previously applied wallpaper is left untouched. */
WpStatus    wp_apply(int idx, const GfxFb *fb);

/* Copy n cached pixels of screen row y starting at column x into dst (volatile: the framebuffer).
 * Returns 0 and copies nothing when no cache is active or the span is out of range. */
int         wp_blit_span(volatile uint32_t *dst, uint32_t x, uint32_t y, uint32_t n);

/* Draw wallpaper idx (>=1) scaled to fill the rectangle (cover-fit, clipped to the screen). Used for
 * thumbnails and the preview; reads the embedded blob directly, allocates nothing. */
WpStatus    wp_draw_scaled(const GfxFb *fb, int idx, int32_t x, int32_t y, int32_t w, int32_t h);

/* 1 if the cached wallpaper is predominantly light inside the given screen rectangle (text on top must be dark). */
int         wp_region_is_light(int32_t x, int32_t y, int32_t w, int32_t h, const GfxFb *fb);

#endif /* VEXOS_WALLPAPER_H */
