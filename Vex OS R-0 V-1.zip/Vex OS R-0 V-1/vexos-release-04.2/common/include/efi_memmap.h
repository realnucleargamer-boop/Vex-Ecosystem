/*
 * Vex OS - common/include/efi_memmap.h
 *
 * Mirrors the UEFI EFI_MEMORY_DESCRIPTOR layout (a UEFI-spec-fixed
 * binary ABI, not something Vex OS defines). Used by the kernel to
 * walk the raw memory map array BootInfo points at
 * (info->memory_map, described by info->memory_map_desc_size).
 *
 * Only the fields actually read are named. ALWAYS advance through
 * the array using BootInfo's memory_map_desc_size, never
 * sizeof(EfiMemoryDescriptor) - firmware is permitted to report a
 * larger descriptor with extra trailing fields.
 */

#ifndef VEXOS_EFI_MEMMAP_H
#define VEXOS_EFI_MEMMAP_H

#include <stdint.h>

typedef struct __attribute__((packed)) {
    uint32_t Type;
    uint32_t _pad;           /* natural alignment gap before the UINT64s */
    uint64_t PhysicalStart;
    uint64_t VirtualStart;
    uint64_t NumberOfPages;  /* count of 4 KiB pages */
    uint64_t Attribute;
} EfiMemoryDescriptor;

/* EFI_MEMORY_TYPE values, per the UEFI spec's EFI_MEMORY_TYPE enum.
 *
 * BOOT-03 needs more than just CONVENTIONAL: the physical allocator is
 * default-deny (every page starts reserved, only CONVENTIONAL is
 * released) and the diagnostics name the type that owns a region, so
 * the full low range is spelled out here rather than open-coding
 * numbers at the use sites.
 *
 * Note which of these are deliberately NOT reclaimed in BOOT-03:
 * BOOT_SERVICES_CODE/DATA and LOADER_CODE/DATA are reclaimable in
 * principle, but BootInfo, the EFI memory map array itself, and the
 * ACPI tables live in that memory and the kernel still reads them.
 * See docs/BOOT-03.md. */
#define EFI_MEM_TYPE_RESERVED            0
#define EFI_MEM_TYPE_LOADER_CODE         1
#define EFI_MEM_TYPE_LOADER_DATA         2
#define EFI_MEM_TYPE_BOOT_SERVICES_CODE  3
#define EFI_MEM_TYPE_BOOT_SERVICES_DATA  4
#define EFI_MEM_TYPE_RUNTIME_CODE        5
#define EFI_MEM_TYPE_RUNTIME_DATA        6
#define EFI_MEM_TYPE_CONVENTIONAL        7
#define EFI_MEM_TYPE_UNUSABLE            8
#define EFI_MEM_TYPE_ACPI_RECLAIM        9
#define EFI_MEM_TYPE_ACPI_NVS            10
#define EFI_MEM_TYPE_MMIO                11
#define EFI_MEM_TYPE_MMIO_PORT_SPACE     12
#define EFI_MEM_TYPE_PAL_CODE            13
#define EFI_MEM_TYPE_PERSISTENT          14
#define EFI_MEM_TYPE_MAX                 15

/* True for descriptor types that describe real, readable/writable
 * system RAM (as opposed to MMIO or address space that is not backed
 * by memory at all). Used by the paging code to decide whether a
 * region may be mapped write-back: mapping MMIO write-back is a real
 * correctness bug, not a performance question. */
static inline int efi_mem_type_is_ram(uint32_t t)
{
    switch (t) {
    case EFI_MEM_TYPE_LOADER_CODE:
    case EFI_MEM_TYPE_LOADER_DATA:
    case EFI_MEM_TYPE_BOOT_SERVICES_CODE:
    case EFI_MEM_TYPE_BOOT_SERVICES_DATA:
    case EFI_MEM_TYPE_RUNTIME_CODE:
    case EFI_MEM_TYPE_RUNTIME_DATA:
    case EFI_MEM_TYPE_CONVENTIONAL:
    case EFI_MEM_TYPE_ACPI_RECLAIM:
    case EFI_MEM_TYPE_ACPI_NVS:
        return 1;
    default:
        /* RESERVED, UNUSABLE, MMIO, MMIO_PORT_SPACE, PAL_CODE,
         * PERSISTENT and anything unknown are treated as not-RAM. Being
         * wrong in this direction costs performance (an uncacheable
         * mapping); being wrong in the other direction can break MMIO. */
        return 0;
    }
}

#endif /* VEXOS_EFI_MEMMAP_H */
