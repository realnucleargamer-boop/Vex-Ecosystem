/* Host test harness for the COMPILED Verminal. Implements the vex_os_* / vex_rt_print* services
 * as a mock (bounded buffers, one timer slot) and drives vt_* entry points. Not part of the OS. */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#define OUTCAP 65536
static char out[OUTCAP]; static int outn;
static int64_t state[16]; static char bufs[2][128]; static int blen[2];
static int timer_active, timer_starts, timer_stops; static int64_t now = 1000000;
void vex_rt_print_cstr(const char *s){ for(;*s&&outn<OUTCAP-1;s++) out[outn++]=*s; out[outn]=0; }
void vex_rt_println_cstr(const char *s){ vex_rt_print_cstr(s); vex_rt_print_cstr("\n"); }
void vex_rt_print_i64(int64_t v){ char t[24]; snprintf(t,sizeof t,"%ld",(long)v); vex_rt_print_cstr(t); }
void vex_rt_println_i64(int64_t v){ vex_rt_print_i64(v); vex_rt_print_cstr("\n"); }
int64_t vex_os_state_get(int64_t k){ return (k>=0&&k<16)?state[k]:0; }
int64_t vex_os_state_set(int64_t k,int64_t v){ if(k<0||k>=16) return 0; state[k]=v; return 1; }
int64_t vex_os_buf_push(int64_t b,int64_t c){ if(b<0||b>1||c<32||c>126||blen[b]>=127) return 0; bufs[b][blen[b]++]=(char)c; bufs[b][blen[b]]=0; return 1; }
int64_t vex_os_buf_pop(int64_t b){ if(b<0||b>1||!blen[b]) return 0; bufs[b][--blen[b]]=0; return 1; }
int64_t vex_os_buf_clear(int64_t b){ if(b<0||b>1) return 0; blen[b]=0; bufs[b][0]=0; return 1; }
int64_t vex_os_buf_len(int64_t b){ return (b>=0&&b<=1)?blen[b]:0; }
const char *vex_os_buf_text(int64_t b){ return (b>=0&&b<=1)?bufs[b]:""; }
int64_t vex_os_out_clear(void){ outn=0; out[0]=0; return 1; }
static const char *names[]={"Desktop","Verminal"}, *kinds[]={"System","App"}; static int64_t started[]={900000,950000};
int64_t vex_os_app_count(void){ return 2; }
int64_t vex_os_app_id(int64_t i){ return 1001+i; }
const char *vex_os_app_name(int64_t i){ return (i>=0&&i<2)?names[i]:""; }
const char *vex_os_app_kind(int64_t i){ return (i>=0&&i<2)?kinds[i]:""; }
int64_t vex_os_app_started_ms(int64_t i){ return (i>=0&&i<2)?started[i]:0; }
int64_t vex_os_now_ms(void){ return now; }
int64_t vex_os_timer_start(int64_t ms){ if(timer_active||ms<=0) return 0; timer_active=1; timer_starts++; return 1; }
int64_t vex_os_timer_stop(void){ int was=timer_active; timer_active=0; if(was) timer_stops++; return was; }
int64_t vex_os_timer_active(void){ return timer_active; }
static int last_kind; static char last_arg[160];
int64_t vex_os_cmd(int64_t k,const char *a){ last_kind=(int)k; strncpy(last_arg,a?a:"",sizeof last_arg-1); return 1; }

int64_t vt_init(void); int64_t vt_on_key(int64_t,int64_t); int64_t vt_on_tick(void); int64_t vt_enter_processes(void);
static int fails, total;
#define CHECK(c,msg) do{ total++; if(!(c)){ fails++; printf("FAIL  %s\n",msg);} else printf("PASS  %s\n",msg);}while(0)
static void typeline(const char *s){ for(;*s;s++) vt_on_key(0,(unsigned char)*s); }
static int64_t run(const char *s){ typeline(s); return vt_on_key(40,0); }
int main(void){
  vt_init(); CHECK(strstr(out,"Verminal  (VexScript") && !timer_active,"init: banner shown, no timer");
  vex_os_out_clear(); run("v. help");
  CHECK(strstr(out,"v. help")&&strstr(out,"v. processes")&&strstr(out,"v. input test")&&strstr(out,"Esc"),"v. help lists all three commands and navigation");
  CHECK(blen[0]==0,"prompt line cleared after a command");
  vex_os_out_clear(); run("   v.    help   "); CHECK(strstr(out,"Available commands"),"whitespace variants of v. help accepted");
  const char *bad[]={"v.help","v. hel","v. helpx","V. HELP","help","v.  processesx","v. input  tes","vv. help",".",0};
  int okbad=1; for(int i=0;bad[i];i++){ vex_os_out_clear(); run(bad[i]); if(!strstr(out,"Unknown command. Type `v. help` for available commands.")){okbad=0;printf("   not rejected: '%s'\n",bad[i]);} }
  CHECK(okbad,"near-miss / unsupported commands all rejected with guidance");
  vex_os_out_clear(); run("   "); CHECK(!strstr(out,"Unknown"),"blank line is not an error");
  /* processes view + timer lifecycle */
  vex_os_out_clear(); run("v. processes");
  CHECK(state[0]==1&&timer_active&&timer_starts==1,"v. processes: view entered, exactly one timer started");
  CHECK(strstr(out,"1001  ")&&strstr(out,"Desktop")&&strstr(out,"Verminal")&&strstr(out,"2 application(s)")&&strstr(out,"00:01:40"),"processes shows tracked apps with uptime from kernel data (Desktop 100 s)");
  now+=1000; int64_t r=vt_on_tick(); CHECK(r==1&&strstr(out,"00:01:41"),"tick re-renders with updated uptime");
  vt_enter_processes(); CHECK(timer_starts==1&&timer_active,"re-entering while active does not start a duplicate timer");
  CHECK(vt_on_key(0,'x')==0&&state[0]==1,"unrelated key ignored in the process view");
  vt_on_key(41,0); CHECK(state[0]==0&&!timer_active&&timer_stops==1,"Esc leaves the process view and stops the timer");
  int len0=outn; r=vt_on_tick(); CHECK(r==0&&outn==len0&&!timer_active,"stray tick after leaving renders nothing and keeps no timer");
  for(int i=0;i<50;i++){ run("v. processes"); vt_on_key(113,'q'); }
  CHECK(timer_starts==51&&timer_stops==51&&!timer_active,"50 enter/leave cycles: starts==stops, nothing left running");
  /* input test */
  run("v. input test"); CHECK(state[0]==2,"v. input test opens the input view");
  const char *txt="Hello, VEX OS! 123 ~`@#$%^&*()_+-=[]{};:'\",.<>/?\\|"; typeline(txt);
  CHECK(strcmp(bufs[1],txt)==0,"arbitrary printable ASCII (letters, digits, punctuation, spaces) accepted exactly");
  vt_on_key(42,0); vt_on_key(42,0); CHECK(strlen(bufs[1])==strlen(txt)-2,"backspace removes characters");
  vex_os_out_clear(); vt_on_key(40,0); CHECK(strstr(out,"You typed: Hello, VEX OS!")&&blen[1]==0,"Enter submits and clears the line");
  for(int i=0;i<500;i++) vt_on_key(0,'A'); CHECK(blen[1]==127&&bufs[1][127]==0,"500 characters cannot overflow the 127-byte buffer");
  vt_on_key(0,200); vt_on_key(0,5); CHECK(blen[1]==127,"non-ASCII / control characters rejected");
  for(int i=0;i<200;i++) vt_on_key(42,0); CHECK(blen[1]==0,"backspace on empty buffer is safe");
  vt_on_key(41,0); CHECK(state[0]==0&&strstr(out,"Verminal  (VexScript"),"Esc returns to the terminal");
  run("v. input test"); typeline("again"); CHECK(strcmp(bufs[1],"again")==0,"input test is repeatable without reboot");
  vt_on_key(41,0);
  /* Release-03 commands: the VexScript parser must route each command with the right request kind + raw argument text */
  last_kind=0; vex_os_out_clear(); run("v. open Valbook");
  CHECK(last_kind==1 && strstr(last_arg,"Valbook") && !strstr(out,"Unknown"),"v. open <app> -> request 1 with the argument");
  last_kind=0; run("v. open \"File Explorer\""); CHECK(last_kind==1 && strstr(last_arg,"\"File Explorer\""),"quoted name (with a space) reaches the kernel intact");
  last_kind=0; run("  v.   close    Valbook  "); CHECK(last_kind==2 && strstr(last_arg,"Valbook"),"v. close <app> -> request 2 (extra blanks tolerated)");
  last_kind=0; run("v. search notes.txt"); CHECK(last_kind==3 && strstr(last_arg,"notes.txt"),"v. search <name> -> request 3");
  last_kind=0; run("v. audio test"); CHECK(last_kind==4,"v. audio test -> request 4");
  last_kind=0; run("v. change users"); CHECK(last_kind==5,"v. change users -> request 5");
  last_kind=0; vex_os_out_clear(); run("v. add user bob secret123");
  CHECK(last_kind==6 && strstr(last_arg,"bob") && strstr(last_arg,"secret123"),"v. add user -> request 6 carries name and password to the kernel");
  CHECK(strstr(out,"v. add user ********") && !strstr(out,"secret123"),"the password is NEVER echoed into the terminal output");
  last_kind=0; vex_os_out_clear(); run("v. open"); CHECK(last_kind==1,"v. open with no argument still reaches the kernel (which prints usage)");
  const char *bad2[]={"v. opener","v. closeall","v. audio","v. search","v. changeusers","v. add users x y","v.open Valbook",0}; int okb=1;
  for(int i=0;bad2[i];i++){ last_kind=0; vex_os_out_clear(); run(bad2[i]); int isbare=(strcmp(bad2[i],"v. search")==0); if(!isbare && (last_kind!=0 || !strstr(out,"Unknown command"))){okb=0;printf("   wrongly accepted: '%s'\n",bad2[i]);} }
  CHECK(okb,"near-miss command words (no word boundary / wrong phrase) are rejected as unknown, no request made");
  vex_os_out_clear(); run("v. help"); CHECK(strstr(out,"v. open")&&strstr(out,"v. close")&&strstr(out,"v. search")&&strstr(out,"v. audio test")&&strstr(out,"v. change users")&&strstr(out,"v. add user"),"v. help documents every new command");
  last_kind=0; vex_os_out_clear(); run("v. testpath /home/vex/n.txt"); CHECK(last_kind==7 && strstr(last_arg,"/home/vex/n.txt") && !strstr(out,"Unknown"),"v. testpath <path> -> request 7 with the path");
  last_kind=0; run("  v.  testpath   \"/home/my dir/a b.txt\" "); CHECK(last_kind==7 && strstr(last_arg,"\"/home/my dir/a b.txt\""),"v. testpath: quoted path with spaces reaches the kernel intact");
  last_kind=0; run("v. testpath"); CHECK(last_kind==7,"v. testpath with no argument still reaches the kernel (which prints usage)");
  last_kind=0; vex_os_out_clear(); run("v. content notes.txt"); CHECK(last_kind==8 && strstr(last_arg,"notes.txt") && !strstr(out,"Unknown"),"v. content <path> -> request 8 with the path");
  last_kind=0; run("v. content"); CHECK(last_kind==8,"v. content with no argument still reaches the kernel (which prints usage)");
  last_kind=0; run("v. storage"); CHECK(last_kind==9 && !strstr(out,"Unknown"),"v. storage -> request 9 (real kernel status, no canned text)");
  last_kind=0; run("v. storage format"); CHECK(last_kind==9 && strstr(last_arg,"format"),"v. storage format -> request 9 with the argument");
  last_kind=0; run("v. drivers"); CHECK(last_kind==10 && !strstr(out,"Unknown"),"v. drivers -> request 10 (PCI device list)");
  { const char *bad4[]={"v. storages","v.storage","v. driver","v. driversx",0}; int ok4=1; for(int q=0;bad4[q];q++){ last_kind=0; run(bad4[q]); if(last_kind==9||last_kind==10) ok4=0; }
    CHECK(ok4,"storage/drivers near-miss words make no kernel request"); }
  { const char *bad3[]={"v. testpaths x","v. contents x","v.testpath x","v. contentx","v. test path x","v. testpat x",0}; int ok3=1;
    for(int i=0;bad3[i];i++){ last_kind=0; vex_os_out_clear(); run(bad3[i]); if(last_kind!=0 || !strstr(out,"Unknown command")){ok3=0;printf("   wrongly accepted: '%s'\n",bad3[i]);} }
    CHECK(ok3,"testpath/content near-miss words are rejected (word boundary), no request made"); }
  vex_os_out_clear(); run("v. help"); CHECK(strstr(out,"v. testpath")&&strstr(out,"v. content"),"v. help documents testpath and content");
  /* exit + robustness */
  CHECK(run("v. exit")==2,"v. exit requests close"); CHECK(vt_on_key(41,0)==2,"Esc in terminal requests close");
  vex_os_out_clear(); for(int i=0;i<2000;i++){ run("bogus"); run("v. help"); } CHECK(outn<OUTCAP,"2000 mixed commands: still responsive, output bounded by the host");
  CHECK(vt_on_key(0,'a')==1&&strcmp(bufs[0],"a")==0,"terminal still accepts input after heavy use");
  printf("\n%d/%d host checks passed\n",total-fails,total); return fails!=0;
}
