/* Host-only test shim for kernel/src/ai/crystal_core.c: flat C ABI for ctypes. NOT part of the kernel build. */
#include "crystal_core.h"
static VxcModel M; static VxcScratch S;
int shim_open(const uint8_t *b, size_t n, int crc) { return vxc_model_open(&M, b, n, crc); }
int shim_probe(const uint8_t *b, size_t n, int crc) { VxcModel t; return vxc_model_open(&t, b, n, crc); }   /* does not touch the active model */
uint32_t shim_crc(const uint8_t *p, size_t n) { return vxc_crc32(p, n); }
/* res[8] = intent, neural_top, confidence, prob_q30, source, handler, truncated, n_numbers */
int shim_infer(const char *t, size_t n, char *out, size_t cap, int32_t *res, int64_t *logit)
{
    VxcResult r; int rc = vxc_infer(&M, &S, t, n, &r, out, cap);
    if (rc != VXC_OK) return rc;
    res[0] = r.intent; res[1] = r.neural_top; res[2] = r.confidence; res[3] = r.prob_q30; res[4] = r.source; res[5] = r.handler; res[6] = r.truncated; res[7] = r.n_numbers;
    if (logit) for (uint32_t k = 0; k < M.nint; k++) logit[k] = S.logit[k];
    return rc;
}
int shim_arith(const char *t, size_t n, char *out, size_t cap, int *handler) { return vxc_arith(&S, t, n, out, cap, handler); }
const char *shim_label(int id) { return vxc_intent_label(&M, id); }
const char *shim_family(int id) { return vxc_intent_family(&M, id); }
size_t shim_scratch_size(void) { return sizeof(VxcScratch); }
