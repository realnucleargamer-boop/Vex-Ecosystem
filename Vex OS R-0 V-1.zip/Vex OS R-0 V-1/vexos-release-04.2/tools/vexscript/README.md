# VexScript 2.0+++ (v2.2.0)

Statically typed, deterministic language toolchain for **VEX AI** and **Vex OS**.

```text
VexScript → Lexer → Parser → Typecheck → Vex IR → IR interpreter / x86-64
```

## Version

| Field | Value |
|-------|--------|
| Version | **2.2.0** |
| Release | **2.0+++** |
| Codename | VEX-AI-Foundation |

## Features

- Static types: `i64`, `bool`, `str`/`string`, arrays `T[]`, structs, enums
- Strings: literals, `+`, `==`/`!=`, params/returns
- Bool logic: `&&` `||` `!`
- Arrays: literals, index, `array_length` (bounds-checked)
- Modules: `import` / `pub`
- Vex IR + hosted interpreter + partial native backend
- Hosted `vex::*` stubs (not real kernel)

## Quick start

```bash
cd vexscript
export PYTHONPATH=src

python3 -m vexscript.cli --version
python3 scripts/test_2_0_plus_plus.py
python3 scripts/test_vex_ai_ready.py
python3 -m vexscript.cli run examples/hello_project
```

## Layout

```
vexscript/
├── src/vexscript/   # compiler
├── src/runtime/     # vex_rt.c
├── stdlib/
├── examples/
├── scripts/
└── docs/
```

## Docs

- `docs/vexscript-2.0-plus-plus.md` — 2.0+++ feature status
- `docs/vexscript-2-plus.md` — 2+ phases
- `docs/vex-ir-0.1.md` — IR notes
