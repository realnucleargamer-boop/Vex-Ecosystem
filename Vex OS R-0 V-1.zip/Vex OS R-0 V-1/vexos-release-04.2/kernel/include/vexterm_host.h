/*
 * Vex OS - kernel/include/vexterm_host.h : kernel-side host of the Verminal VexScript application.
 *
 * The APPLICATION LOGIC (parsing, dispatch, help, views, process-list rendering, input-test editing) is
 * VexScript: apps/vex_terminal/src/main.vex, compiled by tools/vexscript to x86-64 and linked in. This file
 * is only the OS service layer it calls: bounded text output, two bounded line buffers, 16 state slots, a
 * read-only view of the app tracker, and ONE periodic timer slot.
 *
 * EXECUTION MODEL (be precise): the compiled VexScript runs in RING 0 as trusted, build-time-compiled,
 * statically linked code. It is NOT sandboxed and NOT in Ring 3: the existing Ring 3 facility is a single
 * 4 KiB test-blob region (SECURITY-02) with no loader, no multi-page user image and no scheduler. The
 * isolation that does exist is at the language level (no pointers/`unsafe` in the app; strings are
 * read-only; every service below validates its arguments and is bounded).
 *
 * BOUNDS: scrollback VTH_LINES x VTH_COLS (older lines are overwritten, long lines wrap); line buffers
 * VTH_BUF_MAX chars; state slots 16; one timer. Calls from the app never allocate.
 */
#ifndef VEXOS_VEXTERM_HOST_H
#define VEXOS_VEXTERM_HOST_H
#include <stdint.h>
#define VTH_COLS 96
#define VTH_LINES 200
#define VTH_BUF_MAX 127
#define VTH_ARG_MAX 120
#define VTH_TIMER_MIN_MS 100
#define VTH_TIMER_MAX_MS 60000
void vth_open(void);                 /* run vt_init() */
void vth_close(void);                /* stop the timer, clear state */
int  vth_is_open(void);
int  vth_key(uint16_t code, int ascii);   /* 0 ignored, 1 handled, 2 app asked to exit */
void vth_poll(void);                 /* fire the periodic callback if due; bounded, never blocks */
int  vth_take_dirty(void);          /* output rows changed: redraw rows + prompt */
int  vth_take_prompt_dirty(void);   /* only the edit line changed: redraw the prompt row alone */
int  vth_visible(int rows, const char **out);   /* up to `rows` newest lines, oldest first; returns count */
const char *vth_prompt_label(void);  /* "> ", "input> " or "" (no prompt row in the process view) */
const char *vth_prompt_text(void);
int  vth_take_request(int *kind, char *arg, int cap);   /* 1 open, 2 close, 3 search, 4 audio, 5 users, 6 add user */
void vth_print(const char *s);                          /* append a line to the terminal output (kernel-side results) */
int  vth_view(void);                 /* app state slot 0 */
int  vth_timer_active(void);
uint32_t vth_timer_starts(void), vth_timer_stops(void), vth_timer_fires(void);
#endif
