/*
 * Vex OS - kernel/src/arch/x86_64/acpi/acpi.c
 */

#include "acpi.h"
#include "serial.h"

static int checksum_ok(const void *table, uint32_t length)
{
    const uint8_t *p = (const uint8_t *)table;
    uint8_t sum = 0;
    for (uint32_t i = 0; i < length; i++) sum = (uint8_t)(sum + p[i]);
    return sum == 0;
}

static int sig_eq4(const char *a, const char *b)
{
    return a[0] == b[0] && a[1] == b[1] && a[2] == b[2] && a[3] == b[3];
}

/* Finds the MADT ("APIC") among the SDT pointers in an XSDT (8-byte
 * pointers) or RSDT (4-byte pointers). `entry_size` selects which. */
static AcpiSdtHeader *find_table(uint64_t sdt_physical, uint32_t entry_size, const char sig[4])
{
    AcpiSdtHeader *sdt = (AcpiSdtHeader *)(uintptr_t)sdt_physical;

    if (!sig_eq4(sdt->Signature, entry_size == 8 ? "XSDT" : "RSDT")) {
        serial_puts("[kernel] ACPI: root table signature mismatch\n");
        return 0;
    }
    if (!checksum_ok(sdt, sdt->Length)) {
        serial_puts("[kernel] ACPI: root table checksum failed\n");
        return 0;
    }

    uint32_t entry_count = (sdt->Length - sizeof(AcpiSdtHeader)) / entry_size;
    uint8_t *entries = (uint8_t *)sdt + sizeof(AcpiSdtHeader);

    for (uint32_t i = 0; i < entry_count; i++) {
        uint64_t table_phys;
        if (entry_size == 8) {
            table_phys = *(uint64_t *)(entries + i * 8);
        } else {
            table_phys = *(uint32_t *)(entries + i * 4);
        }

        AcpiSdtHeader *candidate = (AcpiSdtHeader *)(uintptr_t)table_phys;
        if (sig_eq4(candidate->Signature, sig)) {
            if (!checksum_ok(candidate, candidate->Length)) {
                serial_puts("[kernel] ACPI: found table but checksum failed: ");
                serial_putc(sig[0]); serial_putc(sig[1]);
                serial_putc(sig[2]); serial_putc(sig[3]);
                serial_puts("\n");
                return 0;
            }
            return candidate;
        }
    }

    return 0;
}

int acpi_init(uint64_t rsdp_physical_address, AcpiInfo *out)
{
    out->local_apic_address = 0;
    out->cpu_count = 0;

    if (rsdp_physical_address == 0) {
        serial_puts("[kernel] ACPI: no RSDP address in BootInfo\n");
        return 0;
    }

    AcpiRsdp *rsdp = (AcpiRsdp *)(uintptr_t)rsdp_physical_address;

    if (rsdp->Signature[0] != 'R' || rsdp->Signature[1] != 'S' ||
        rsdp->Signature[2] != 'D' || rsdp->Signature[3] != ' ' ||
        rsdp->Signature[4] != 'P' || rsdp->Signature[5] != 'T' ||
        rsdp->Signature[6] != 'R' || rsdp->Signature[7] != ' ') {
        serial_puts("[kernel] ACPI: RSDP signature mismatch\n");
        return 0;
    }

    /* ACPI 1.0 checksum covers the first 20 bytes only. */
    if (!checksum_ok(rsdp, 20)) {
        serial_puts("[kernel] ACPI: RSDP (v1) checksum failed\n");
        return 0;
    }

    AcpiSdtHeader *madt = 0;

    if (rsdp->Revision >= 2 && rsdp->XsdtAddress != 0) {
        /* ACPI 2.0+ extended checksum covers the full RSDP length. */
        if (!checksum_ok(rsdp, rsdp->Length)) {
            serial_puts("[kernel] ACPI: RSDP (v2) extended checksum failed\n");
            return 0;
        }
        madt = find_table(rsdp->XsdtAddress, 8, "APIC");
    }

    if (!madt && rsdp->RsdtAddress != 0) {
        serial_puts("[kernel] ACPI: falling back to RSDT\n");
        madt = find_table((uint64_t)rsdp->RsdtAddress, 4, "APIC");
    }

    if (!madt) {
        serial_puts("[kernel] ACPI: MADT not found\n");
        return 0;
    }

    /* MADT-specific fields sit right after the common SDT header. */
    uint8_t *madt_bytes = (uint8_t *)madt;
    uint32_t local_apic_address = *(uint32_t *)(madt_bytes + sizeof(AcpiSdtHeader));
    /* uint32_t madt_flags = *(uint32_t*)(madt_bytes + sizeof(AcpiSdtHeader) + 4); (unused in BOOT-02B) */

    out->local_apic_address = local_apic_address;

    uint8_t *entry = madt_bytes + sizeof(AcpiSdtHeader) + 8;
    uint8_t *madt_end = madt_bytes + madt->Length;

    while (entry < madt_end) {
        AcpiMadtEntryHeader *eh = (AcpiMadtEntryHeader *)entry;
        if (eh->Length == 0) break; /* malformed table - stop rather than loop forever */

        if (eh->Type == ACPI_MADT_TYPE_LOCAL_APIC && out->cpu_count < ACPI_MAX_CPUS) {
            AcpiMadtLocalApic *la = (AcpiMadtLocalApic *)entry;
            AcpiCpuEntry *cpu = &out->cpus[out->cpu_count];
            cpu->processor_id = la->ProcessorId;
            cpu->apic_id = la->ApicId;
            cpu->enabled = (la->Flags & ACPI_MADT_LAPIC_FLAG_ENABLED) != 0;
            out->cpu_count++;
        }

        entry += eh->Length;
    }

    return 1;
}
