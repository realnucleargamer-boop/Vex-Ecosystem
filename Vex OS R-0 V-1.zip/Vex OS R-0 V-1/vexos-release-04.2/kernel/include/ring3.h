/*
 * Vex OS - kernel/include/ring3.h
 *
 * SECURITY-02: the first Ring 3 foundation. See docs/SECURITY-02.md for
 * the design rationale, the threat model, and what is deliberately NOT
 * here (no processes, no scheduler integration, no per-task address
 * space, no ELF loader).
 *
 * What this file defines is a privilege BOUNDARY, not a userspace:
 *   - one dedicated user region (code page, guard, stack page, guard),
 *     mapped through vmm_map_user_page() and nothing else;
 *   - one syscall gate (int 0x80, the only DPL3 IDT gate);
 *   - one pointer validator every syscall must call before it touches a
 *     user-supplied address;
 *   - one fault path that turns "Ring 3 did something illegal" into a
 *     logged event and a return to a known-good kernel point, instead of
 *     a kernel panic or - worse - silently continuing in Ring 0.
 */

#ifndef VEXOS_RING3_H
#define VEXOS_RING3_H

#include <stdint.h>
#include "idt.h"

/* Layout must stay in lockstep with ring3_transition.asm's
 * ring3_checkpoint_save/restore: eight qwords, this order. */
typedef struct {
    uint64_t rbx, rbp, r12, r13, r14, r15, rsp, rip;
} Ring3Checkpoint;

/* ---- syscall ABI (int 0x80) ------------------------------------------
 * RAX = syscall number; RDI, RSI = arguments; result in RAX.
 * Only what SECURITY-02 needs. Adding a syscall means adding a case to
 * ring3_syscall_handler() AND a validation story for every pointer it
 * takes - there is deliberately no table to register into. */
#define RING3_SYSCALL_VECTOR   0x80
#define RING3_SYS_EXIT         0   /* rdi = exit code; does not return    */
#define RING3_SYS_WRITE        1   /* rdi = user ptr, rsi = length        */
#define RING3_SYS_REJECTED     ((int64_t)-1)

/* SYS_WRITE copies at most this many bytes out of user memory per call.
 * A bound is part of the validation story: an unbounded length is an
 * unbounded kernel loop driven by an untrusted value. */
#define RING3_WRITE_MAX        256

typedef enum {
    RING3_OUT_NONE    = 0,   /* run did not complete (should not occur)   */
    RING3_OUT_EXITED  = 1,   /* program issued SYS_EXIT                   */
    RING3_OUT_FAULTED = 2,   /* program took a CPU exception in Ring 3    */
    RING3_OUT_TIMEOUT = 3    /* PROC-01: terminated by the CPU-time watchdog */
} Ring3Outcome;

typedef struct {
    Ring3Outcome outcome;
    uint64_t exit_code;
    /* Valid when outcome == RING3_OUT_FAULTED: */
    uint64_t fault_vector;
    uint64_t fault_error_code;
    uint64_t fault_rip;
    uint64_t fault_cr2;
    /* Always valid: */
    uint64_t syscalls_seen;
    uint64_t syscalls_rejected;
    int64_t  last_write_ret;     /* RAX returned to the most recent SYS_WRITE */
    int      last_reject_reason; /* UserValidate code of the last rejected syscall pointer (0 if none) */
    uint64_t bytes_written;
} Ring3Result;

/* Result of user_range_check(). Distinct codes (not a bare bool) so a
 * test can assert WHY a pointer was refused - "rejected" for the wrong
 * reason would be a bug hiding behind a passing result. */
typedef enum {
    UV_OK = 0,
    UV_ERR_NOT_INITIALISED,
    UV_ERR_NULL,
    UV_ERR_OVERFLOW,          /* ptr + len wraps past 2^64                */
    UV_ERR_NONCANONICAL,
    UV_ERR_OUTSIDE_REGION,    /* not inside the explicit user region      */
    UV_ERR_NOT_MAPPED,        /* some page in the range is not present    */
    UV_ERR_NOT_USER,          /* page present but U/S = supervisor        */
    UV_ERR_NOT_WRITABLE,      /* caller needs write, page is read-only    */
    UV_ERR_LARGE_PAGE,        /* covered by a 2 MiB mapping - never user  */
    UV_ERR_TOO_LARGE          /* valid range but longer than the syscall's cap */
} UserValidate;

/* Builds the user region: reserves virtual space, allocates two frames,
 * copies the test-program blob into the code frame, maps code as
 * user+read-only+executable and the stack as user+writable+NX, leaves
 * two guard pages unmapped, points TSS.rsp0 at a dedicated kernel stack,
 * and opens the one DPL3 syscall gate. Returns 1 on success.
 * MUST be called after SECURITY-01's tests have run: SECURITY-01 asserts
 * "zero user-accessible page-table entries exist", which is true right
 * up until this function runs. See docs/SECURITY-02.md. */
int ring3_init(void);
int ring3_initialised(void);

/* Runs one test program to completion or fault and returns control to
 * the caller either way. `slot` is one of the ring3_slot_*() offsets;
 * arg0/arg1 arrive in the program's RDI/RSI. */
void ring3_run(uint64_t slot, uint64_t arg0, uint64_t arg1, Ring3Result *out);

/* ---- PROC-01 extension points (additive; the canned-program path above is unchanged) ------------------------------
 * ring3_run_ext(): run an arbitrary Ring 3 entry point/stack (the process loader's path). The caller owns every mapping.
 * ring3_set_ext_syscall(): while non-NULL, EVERY int 0x80 from the active run is delegated to `fn` (including SYS_EXIT's
 *   number: fn decides). fn returns the value placed in the user's RAX, or calls ring3_finish() and never returns.
 * ring3_finish(): end the active run NOW with `outcome`/`exit_code` and resume the kernel at the ring3_run*() checkpoint.
 *   Only legal from a Ring 3 syscall/fault/timer frame with a run armed (no resource may be held on the abandoned stack).
 * ring3_active(): a Ring 3 run is armed. */
typedef int64_t (*Ring3ExtSyscall)(InterruptFrame *frame);
void ring3_set_ext_syscall(Ring3ExtSyscall fn);
void ring3_run_ext(uint64_t entry, uint64_t stack_top, uint64_t arg0, uint64_t arg1, Ring3Result *out);
void ring3_finish(Ring3Outcome outcome, uint64_t exit_code) __attribute__((noreturn));
int  ring3_active(void);

/* THE user-pointer validator. Answers, for the whole range
 * [ptr, ptr + len) and not just its first byte: is the arithmetic sound,
 * is it inside the explicit user region, is EVERY page it touches
 * present, 4 KiB-granular, and user-accessible (and writable if
 * need_write)? len == 0 is valid only if ptr itself lies on a valid user
 * page (a zero-length buffer at a wild address is still a wild address). */
UserValidate user_range_check(uint64_t ptr, uint64_t len, int need_write);

/* Called by idt_common_handler for any exception whose saved CS has
 * RPL 3. If a Ring 3 run is in flight it records the fault and abandons
 * the interrupt frame by jumping back to ring3_run()'s checkpoint, and
 * does not return. Returns 0 (and does nothing) if no run is armed, so
 * the caller falls through to its normal fatal path. */
int ring3_handle_user_fault(InterruptFrame *frame);

/* Geometry, for tests and the audit. */
uint64_t ring3_region_base(void);
uint64_t ring3_region_bytes(void);
uint64_t ring3_code_va(void);
uint64_t ring3_stack_va(void);       /* base of the stack PAGE (lowest addr)  */
uint64_t ring3_guard_lo_va(void);    /* unmapped page between code and stack  */
uint64_t ring3_guard_hi_va(void);    /* unmapped page above the stack         */
uint64_t ring3_msg_va(void);         /* valid, pre-filled user buffer         */
uint64_t ring3_msg_len(void);
uint64_t ring3_kernel_stack_top(void);

/* Test-program slot offsets (defined in ring3_programs.asm). */
extern const uint64_t ring3_slot_exit_clean;
extern const uint64_t ring3_slot_read_kernel;
extern const uint64_t ring3_slot_write_kernel;
extern const uint64_t ring3_slot_syscall_valid;
extern const uint64_t ring3_slot_syscall_null;
extern const uint64_t ring3_slot_syscall_overflow;
extern const uint64_t ring3_slot_syscall_kernel_ptr;

/* Counters for the audit. */
uint64_t ring3_runs_total(void);
uint64_t ring3_faults_isolated(void);

#endif /* VEXOS_RING3_H */
