#include "apps.h"
#include "timer.h"
static const AppInfo reg[] = { { APP_ID_TERMINAL, "Verminal", "VexScript command terminal", 1 },
    { APP_ID_TASKMGR, "Task Manager", "CPU and memory", 1 },
    { APP_ID_EXPLORER, "File Explorer", "Browse and create files", 1 },
    { APP_ID_VALBOOK, "Valbook", "Text editor", 1 },
    { APP_ID_SETTINGS, "Settings", "System settings", 1 } };
int apps_registry_count(void) { return (int)(sizeof reg / sizeof reg[0]); }
const AppInfo *apps_registry_get(int i) { return (i >= 0 && i < apps_registry_count()) ? &reg[i] : 0; }
static char lc(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
static int contains_ci(const char *h, const char *q)
{
    if (!*q) return 1;
    for (; *h; h++) { int i = 0; while (q[i] && h[i] && lc(h[i]) == lc(q[i])) i++; if (!q[i]) return 1; }
    return 0;
}
int apps_search(const char *q, int *out, int max)
{
    int k = 0; if (!q) q = "";
    for (int i = 0; i < apps_registry_count() && k < max; i++)
        if (contains_ci(reg[i].name, q) || contains_ci(reg[i].desc, q)) out[k++] = i;
    return k;
}
uint64_t apps_now_ms(void) { return timer_ticks() * (1000u / TIMER_TARGET_HZ); }
static AppInst inst[APPS_TRACK_MAX]; static int cnt; static uint32_t next_id = 1001;
void apps_tracker_reset(void) { cnt = 0; next_id = 1001; }      /* ids are unique within a desktop session */
static int add(uint32_t app, const char *name, const char *kind)
{
    if (cnt >= APPS_TRACK_MAX) return 0;
    inst[cnt].inst_id = next_id++; inst[cnt].app_id = app; inst[cnt].name = name; inst[cnt].kind = kind;
    inst[cnt].started_ms = apps_now_ms(); cnt++; return (int)inst[cnt - 1].inst_id;
}
int apps_session_begin(void) { apps_tracker_reset(); return add(0, "Desktop", "System"); }
void apps_session_end(void) { cnt = 0; }
uint32_t apps_launch(uint32_t app_id, int *already)
{
    if (already) *already = 0;
    for (int i = 0; i < cnt; i++) if (inst[i].app_id == app_id) { if (already) *already = 1; return inst[i].inst_id; }
    for (int i = 0; i < apps_registry_count(); i++) if (reg[i].app_id == app_id) return (uint32_t)add(app_id, reg[i].name, "App");
    return 0;
}
void apps_close(uint32_t app_id)
{
    for (int i = 0; i < cnt; i++) if (inst[i].app_id == app_id && app_id != 0) { for (int j = i; j + 1 < cnt; j++) inst[j] = inst[j + 1]; cnt--; return; }
}
int apps_running(uint32_t app_id) { for (int i = 0; i < cnt; i++) if (inst[i].app_id == app_id) return 1; return 0; }
int apps_tracked_count(void) { return cnt; }
const AppInst *apps_tracked_get(int i) { return (i >= 0 && i < cnt) ? &inst[i] : 0; }
