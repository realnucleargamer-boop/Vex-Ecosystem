#!/usr/bin/env bash
# Vex OS - scripts/smp-matrix.sh
#
# Runs the BOOT-02C SMP test matrix and asserts on the CAPTURED SERIAL
# LOG rather than on exit codes. Repeats each configuration so that an
# intermittent AP startup failure has a chance to show up.
#
#   ./scripts/smp-matrix.sh [repeats] [cpu counts...]
#
# Checks performed per run:
#   * the boot reached SYSTEM READY
#   * "SMP: <n>/<n> CPUs online" with n equal to the requested count
#   * "SMP: PASS" is present and "FAILED" is absent
#   * every non-BSP CPU line carries a self-reported APIC ID (proof the
#     AP executed AP C code, not merely that a SIPI was accepted)
#   * no duplicate self-reported APIC IDs
#   * (BOOT-03) every subsystem line reports PASS, the in-kernel check
#     counter shows zero failures, no individual check printed FAIL, and
#     BOOT SAGA COMPLETE was reached
#
# Prints a per-run PASS/FAIL line and exits non-zero if any run failed.

set -uo pipefail

REPEATS="${1:-3}"
shift || true
COUNTS=("$@")
if [ ${#COUNTS[@]} -eq 0 ]; then
    COUNTS=(1 2 4 8 16 32)
fi

# Under TCG, a 32-vCPU guest doing a serialized 10 ms INIT wait per AP
# is slow; scale the timeout with the CPU count instead of using one
# fixed value that would spuriously truncate the large runs.
timeout_for() {
    local n="$1"
    echo $(( 60 + n * 12 ))
}

overall=0
mkdir -p build/smp-logs

for n in "${COUNTS[@]}"; do
    for r in $(seq 1 "$REPEATS"); do
        log="build/smp-logs/smp${n}-run${r}.log"
        t=$(timeout_for "$n")

        ./scripts/smp-test.sh "$n" "$t" "$log" >/dev/null 2>&1

        # Strip NULs and terminal escape sequences that the firmware
        # emits before our own output starts.
        clean=$(tr -d '\000' < "$log" | sed 's/\x1b\[[0-9;=]*[a-zA-Z]//g')

        fail=""

        echo "$clean" | grep -q "SYSTEM READY" || fail="$fail no-SYSTEM-READY"
        echo "$clean" | grep -q "SMP: PASS"    || fail="$fail no-PASS"
        echo "$clean" | grep -q "FAILED"       && fail="$fail saw-FAILED"

        echo "$clean" | grep -q "SMP: ${n}/${n} CPUs online" \
            || fail="$fail wrong-online-count"

        # Count CPUs that proved they ran AP C code.
        selfreported=$(echo "$clean" | grep -c "self-reported APIC ID")
        expected_aps=$(( n - 1 ))
        if [ "$selfreported" -ne "$expected_aps" ]; then
            fail="$fail self-reported=$selfreported/want=$expected_aps"
        fi

        # Duplicate APIC ID detection across ALL reported CPU lines.
        ids=$(echo "$clean" | grep -oE "^CPU [0-9]+:" | grep -oE "[0-9]+")
        dupes=$(echo "$ids" | sort | uniq -d | tr '\n' ' ')
        if [ -n "${dupes// /}" ]; then
            fail="$fail duplicate-apic-ids:$dupes"
        fi

        # --- BOOT-03 subsystem assertions ---
        #
        # Asserted individually rather than by looking for the summary
        # block as a whole, so that a partial or reordered summary cannot
        # pass. The kernel prints SYSTEM READY only when everything
        # passed, but this harness must not depend on the kernel's own
        # gating being correct - that is precisely what fault injection
        # exists to test.
        for sub in "MEMORY" "PAGING" "INTERRUPTS" "TIMER" "SMP" "KERNEL FOUNDATION"; do
            echo "$clean" | grep -q "^${sub}: PASS" || fail="$fail no-${sub// /_}-PASS"
        done

        echo "$clean" | grep -q "BOOT SAGA COMPLETE" || fail="$fail no-BOOT-SAGA-COMPLETE"

        # Any individual check that failed.
        badchecks=$(echo "$clean" | grep -c "^\[test\] .*: FAIL")
        if [ "$badchecks" -ne 0 ]; then
            fail="$fail failed-checks=$badchecks"
        fi

        # The in-kernel counter must show every check passing, and there
        # must be a non-trivial number of them - a suite that silently
        # ran zero checks would otherwise look identical to success.
        summary=$(echo "$clean" | grep -oE "===== [0-9]+/[0-9]+ checks passed =====" | head -1)
        if [ -z "$summary" ]; then
            fail="$fail no-check-summary"
        else
            passed=$(echo "$summary" | grep -oE "[0-9]+/" | tr -d '/')
            total=$(echo "$summary" | grep -oE "/[0-9]+" | tr -d '/')
            if [ "$passed" != "$total" ]; then
                fail="$fail checks=$passed/$total"
            elif [ "$total" -lt 50 ]; then
                fail="$fail too-few-checks=$total"
            fi
        fi

        # A triple fault / reset shows up as the firmware banner
        # appearing more than once.
        boots=$(echo "$clean" | grep -c "Vex OS Bootloader")
        if [ "$boots" -gt 1 ]; then
            fail="$fail rebooted($boots)"
        fi

        if [ -z "$fail" ]; then
            echo "PASS  -smp $n  run $r"
        else
            echo "FAIL  -smp $n  run $r :$fail"
            overall=1
        fi
    done
done

if [ "$overall" -eq 0 ]; then
    echo "ALL RUNS PASSED"
else
    echo "SOME RUNS FAILED"
fi
exit "$overall"
