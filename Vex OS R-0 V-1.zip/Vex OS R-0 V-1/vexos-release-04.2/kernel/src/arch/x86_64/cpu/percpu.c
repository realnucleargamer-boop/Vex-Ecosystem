/*
 * Vex OS - kernel/src/arch/x86_64/cpu/percpu.c
 *
 * BOOT-03 CPU-local storage. See kernel/include/percpu.h.
 */

#include "percpu.h"
#include "acpi.h"
#include "serial.h"
#include "boot03_inject.h"

#define IA32_GS_BASE 0xC0000101U

/* Kept in sync with the ACPI CPU limit by a hard build-time check
 * instead of a comment. */
_Static_assert(PERCPU_MAX_CPUS == ACPI_MAX_CPUS,
               "PERCPU_MAX_CPUS must equal ACPI_MAX_CPUS");

/* Each block is padded to its own 128-byte region. Two CPUs writing
 * their own tick counters must not dirty the same cache line: on real
 * hardware that false sharing turns an uncontended per-CPU counter into
 * a cache-line ping-pong, and it is invisible under QEMU TCG, which is
 * exactly the class of problem that has to be designed out rather than
 * tested out here. */
typedef struct {
    PerCpu cpu;
    uint8_t pad[128 - (sizeof(PerCpu) % 128)];
} PerCpuSlot;

static PerCpuSlot g_slots[PERCPU_MAX_CPUS] __attribute__((aligned(128)));
static volatile uint32_t g_initialized;

static void write_msr(uint32_t msr, uint64_t value)
{
    __asm__ volatile ("wrmsr" : :
        "c"(msr), "a"((uint32_t)(value & 0xFFFFFFFF)),
        "d"((uint32_t)(value >> 32)));
}

static uint64_t read_msr(uint32_t msr)
{
    uint32_t lo, hi;
    __asm__ volatile ("rdmsr" : "=a"(lo), "=d"(hi) : "c"(msr));
    return ((uint64_t)hi << 32) | lo;
}

static uint64_t read_cr3(void)
{
    uint64_t v;
    __asm__ volatile ("mov %%cr3, %0" : "=r"(v));
    return v;
}

int percpu_init_for_this_cpu(uint32_t index, uint32_t apic_id,
                             uint64_t kernel_stack_top, int is_bsp)
{
    if (index >= PERCPU_MAX_CPUS) return 0;

    PerCpu *p = &g_slots[index].cpu;

    p->self             = p;
    p->magic            = PERCPU_MAGIC;
#if VEX_INJECTED(4)
    /* NEGATIVE CONTROL: store the wrong index, so a CPU misidentifies
     * itself through %gs:0. The per-CPU test must catch this. See
     * kernel/include/boot03_inject.h. */
    p->cpu_index        = index + 1;
#else
    p->cpu_index        = index;
#endif
    p->apic_id          = apic_id;
    p->kernel_stack_top = kernel_stack_top;
    p->cr3              = read_cr3();
    p->ticks            = 0;
    p->is_bsp           = is_bsp ? 1 : 0;
    p->current_context  = 0;

    /* The block must be fully written before GS base points at it, and
     * before another CPU can observe the count. */
    __atomic_thread_fence(__ATOMIC_RELEASE);

    write_msr(IA32_GS_BASE, (uint64_t)(uintptr_t)p);

    /* Read back: a wrmsr to a base that is not canonical would #GP, but
     * a silently ignored write would not, and the difference matters. */
    if (read_msr(IA32_GS_BASE) != (uint64_t)(uintptr_t)p) {
        serial_puts("[kernel] PERCPU: FAILED - GS base did not take for CPU ");
        serial_put_dec64(index);
        serial_puts("\n");
        return 0;
    }

    __atomic_add_fetch(&g_initialized, 1, __ATOMIC_ACQ_REL);
    return 1;
}

PerCpu *percpu_this(void)
{
    PerCpu *p;
    /* Reads the self pointer stored at the base of this CPU's block. */
    __asm__ volatile ("mov %%gs:0, %0" : "=r"(p));
    return p;
}

PerCpu *percpu_this_or_null(void)
{
    uint64_t base = read_msr(IA32_GS_BASE);
    if (base == 0) return 0;

    PerCpu *p = percpu_this();
    if (p == 0) return 0;
    if (p->magic != PERCPU_MAGIC) return 0;
    if (p->self != p) return 0;
    return p;
}

int percpu_verify_this_cpu(uint32_t index)
{
    if (index >= PERCPU_MAX_CPUS) return 0;

    PerCpu *via_gs = percpu_this();
    PerCpu *expected = &g_slots[index].cpu;

    if (via_gs == 0) return 0;
    if (via_gs != expected) return 0;
    if (via_gs->magic != PERCPU_MAGIC) return 0;
    if (via_gs->cpu_index != index) return 0;
    if (via_gs->self != via_gs) return 0;

    return 1;
}

PerCpu *percpu_get(uint32_t index)
{
    if (index >= PERCPU_MAX_CPUS) return 0;
    return &g_slots[index].cpu;
}

uint32_t percpu_initialized_count(void)
{
    return __atomic_load_n(&g_initialized, __ATOMIC_ACQUIRE);
}
