/* Vex OS - kernel/src/apps/vfs_cmds.c - see include/vfs_cmds.h */
#include "vfs_cmds.h"
#include "vfs.h"

#define PATH_CAP 256
typedef struct { char b[200]; int n; } Buf;
static void cs(Buf *s, const char *t) { while (t && *t && s->n < (int)sizeof s->b - 1) s->b[s->n++] = *t++; s->b[s->n] = 0; }
static void cu(Buf *s, unsigned v) { char d[12]; int q = 0; do { d[q++] = (char)('0' + v % 10); v /= 10; } while (v && q < 11); while (q && s->n < (int)sizeof s->b - 1) s->b[s->n++] = d[--q]; s->b[s->n] = 0; }
static int starts(const char *s, const char *p) { while (*p) { if (*s++ != *p++) return 0; } return 1; }

enum { A_OK = 0, A_BADPATH = -1, A_NOTFOUND = -2, A_DENIED = -3, A_EMPTY = -4 };

/* Expand "~", "~/x", "/abs" and bare "name" (relative to the user's home) into an absolute path; 0 on empty/too long. */
static int expand(const char *arg, const char *home_id, char *full)
{
    while (arg && (*arg == ' ' || *arg == '\t')) arg++;
    if (!arg || !*arg) return 0;
    int n = 0;
    #define PUT(c) do { if (n >= PATH_CAP - 1) return 0; full[n++] = (c); } while (0)
    if (arg[0] == '/') { for (; *arg; arg++) PUT(*arg); }
    else {
        const char *rest = arg;
        if (arg[0] == '~' && (arg[1] == 0 || arg[1] == '/')) rest = arg + 1;
        for (const char *p = "/home/"; *p; p++) PUT(*p);
        for (const char *p = home_id ? home_id : ""; *p; p++) PUT(*p);
        if (*rest && *rest != '/') PUT('/');
        for (; *rest; rest++) PUT(*rest);
    }
    #undef PUT
    full[n] = 0;
    while (n > 1 && full[n - 1] == ' ') full[--n] = 0;               /* trailing blanks are never part of a name */
    return 1;
}

/* Resolve + permission check. For non-administrators any path inside a home they cannot read is A_DENIED
 * WITHOUT consulting whether it exists, so existence of other users' files cannot be probed. */
static int access_path(const char *full, uint32_t uid, int admin, int *node)
{
    *node = -1;
    if (!admin && starts(full, "/home/") && full[6]) {
        char pre[64]; int n = 0; for (const char *p = full; *p && !(n > 6 && *p == '/') && n < 62; p++) pre[n++] = *p;
        pre[n] = 0;
        int h = vfs_resolve(pre);
        if (h >= 0 && !vfs_can_read(h, uid, admin)) return A_DENIED;
    }
    int r = vfs_resolve(full);
    if (r == VFS_ERR_PATH) return A_BADPATH;
    if (r < 0) return A_NOTFOUND;                                   /* NOTFOUND, or a file used as a folder */
    if (!vfs_can_read(r, uid, admin)) return A_DENIED;
    *node = r; return A_OK;
}

static int nchildren(int dir) { int ids[VFS_MAX_NODES]; return vfs_list(dir, ids, VFS_MAX_NODES); }

int vfs_cmd_testpath(const char *arg, uint32_t uid, int admin, const char *home_id, VfscOut out)
{
    char full[PATH_CAP]; Buf m = {{0}, 0}; int node;
    if (!expand(arg, home_id, full)) { out("Usage: v. testpath <path>   (absolute like /home/vex/notes.txt, or relative to your home like notes.txt)"); return 0; }
    int a = access_path(full, uid, admin, &node);
    if (a == A_BADPATH) { cs(&m, "FALSE: '"); cs(&m, full); cs(&m, "' is not a valid path (names: letters, digits, space . _ - ; no '.' or '..')."); out(m.b); return 0; }
    if (a == A_NOTFOUND) { cs(&m, "FALSE: '"); cs(&m, full); cs(&m, "' does not exist."); out(m.b); return 0; }
    if (a == A_DENIED) { cs(&m, "FALSE: '"); cs(&m, full); cs(&m, "' is not accessible to you (it does not exist, or it belongs to another user)."); out(m.b); return 0; }
    char canon[PATH_CAP]; if (vfs_path(node, canon, sizeof canon) < 1) { canon[0] = '/'; canon[1] = 0; }
    const VfsNode *v = vfs_node(node);
    cs(&m, "TRUE: '"); cs(&m, canon); cs(&m, "' exists and is a ");
    if (v->is_dir) { cs(&m, "folder ("); cu(&m, (unsigned)nchildren(node)); cs(&m, " item(s))."); }
    else { cs(&m, "file ("); cu(&m, v->size); cs(&m, " bytes)."); }
    out(m.b); return 1;
}

typedef struct { VfscOut out; int lines; int truncated; } Sink;
static void emit(Sink *k, const char *line)
{
    if (k->lines >= VFSC_MAX_LINES) { k->truncated = 1; return; }
    k->out(line); k->lines++;
}
/* Print file text: split at '\n', tabs become spaces, other control / non-ASCII bytes become '?'. */
static void emit_text(Sink *k, int node)
{
    static char data[VFS_DATA_MAX + 1]; char line[100]; int n = 0;
    int got = vfs_read(node, data, (int)sizeof data);
    if (got <= 0) { emit(k, "  (empty file)"); return; }
    for (int i = 0; i < got; i++) {
        unsigned char c = (unsigned char)data[i];
        if (c == '\n') { line[n] = 0; emit(k, line); n = 0; continue; }
        if (c == '\r') continue;
        if (c == '\t') c = ' ';
        if (c < 32 || c > 126) c = '?';
        line[n++] = (char)c;
        if (n >= (int)sizeof line - 1) { line[n] = 0; emit(k, line); n = 0; }
    }
    if (n) { line[n] = 0; emit(k, line); }
}
static void emit_header(Sink *k, int node)
{
    Buf m = {{0}, 0}; char p[PATH_CAP]; if (vfs_path(node, p, sizeof p) < 1) { p[0] = '?'; p[1] = 0; }
    cs(&m, "== "); cs(&m, p); cs(&m, " ("); cu(&m, vfs_node(node)->size); cs(&m, " bytes) =="); emit(k, m.b);
}

int vfs_cmd_content(const char *arg, uint32_t uid, int admin, const char *home_id, VfscOut out)
{
    char full[PATH_CAP]; Buf m = {{0}, 0}; int node; Sink k = { out, 0, 0 };
    if (!expand(arg, home_id, full)) { out("Usage: v. content <file or folder>   (absolute like /home/vex, or relative to your home like notes.txt)"); return -1; }
    int a = access_path(full, uid, admin, &node);
    if (a != A_OK) {
        cs(&m, "Cannot show '"); cs(&m, full);
        cs(&m, a == A_BADPATH ? "': not a valid path." : a == A_NOTFOUND ? "': it does not exist." : "': not accessible to you (it does not exist, or it belongs to another user).");
        out(m.b); return -1;
    }
    const VfsNode *v = vfs_node(node);
    if (!v->is_dir) { emit_header(&k, node); emit_text(&k, node); }
    else {
        int ids[VFS_MAX_NODES], n = vfs_list(node, ids, VFS_MAX_NODES), files = 0, folders = 0, hidden = 0, shown = 0;
        for (int i = 0; i < n; i++) {
            if (!vfs_can_read(ids[i], uid, admin)) { hidden++; continue; }
            const VfsNode *c = vfs_node(ids[i]);
            if (c->is_dir) { folders++; continue; }
            if (shown >= VFSC_MAX_FILES) { files++; continue; }
            emit_header(&k, ids[i]); emit_text(&k, ids[i]); shown++; files++;
        }
        Buf s = {{0}, 0}; cs(&s, "-- folder "); { char p[PATH_CAP]; if (vfs_path(node, p, sizeof p) < 1) p[0] = 0; cs(&s, p); }
        cs(&s, ": "); cu(&s, (unsigned)files); cs(&s, " file(s), "); cu(&s, (unsigned)folders); cs(&s, " subfolder(s) (not expanded)");
        if (hidden) { cs(&s, ", "); cu(&s, (unsigned)hidden); cs(&s, " hidden (not readable by you)"); }
        if (files > shown) { cs(&s, "; only the first "); cu(&s, (unsigned)shown); cs(&s, " files shown"); }
        cs(&s, " --"); emit(&k, s.b);
    }
    if (k.truncated) out("... output truncated (line limit reached); name a single file to read the rest.");
    return k.lines;
}
