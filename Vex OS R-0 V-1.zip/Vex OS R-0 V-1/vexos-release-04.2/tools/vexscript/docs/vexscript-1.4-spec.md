# VEX-Script 1.4 Language Specification

**Status**: Implemented (reference interpreter)  
**Baseline**: VEX-Script 1.3

## Changes from 1.3

### Module namespace isolation
Imported module functions are stored under qualified names:

```vex
use math_mod;
fn main() -> i32 {
    let x = math_mod::add(10, 20);
    return 0;
}
```

- Syntax: `module::symbol`
- Same function name may exist in different modules without collision
- Missing module / missing symbol / import cycles still rejected
- Top-level (entry file) functions remain unqualified

### Struct typing (strengthened)
- Nested struct construction type-checked recursively
- Chained field access (`a.b.c`) resolved step-by-step statically
- Chained mutation requires mutable **root** binding
- Field access/assign on non-struct types rejected statically

### Function typing
- Arity and argument types checked when parameters are annotated
- Return types checked
- Nested calls supported
- Integer literals remain compatible with integer annotations (no other implicit conversions)

### Diagnostics
Errors include `filename:line:column: error: message` with expected/actual types where applicable.

## Unchanged
1.0–1.3 language surface (aside from requiring `module::fn` for imported functions).

## Breaking change
**Module calls must be qualified.**  
Previously, `use math_mod` injected `add` into the global namespace.  
In 1.4, call `math_mod::add(...)`.
