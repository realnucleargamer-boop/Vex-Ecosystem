"""VEX-Script 1.1 Lexer"""

from __future__ import annotations
from enum import Enum, auto
from dataclasses import dataclass
from .errors import LexError, SourceLocation


class TokenKind(Enum):
    IDENT = auto()
    INT = auto()
    STRING = auto()
    FN = auto()
    LET = auto()
    MUT = auto()
    CONST = auto()
    RETURN = auto()
    IF = auto()
    ELSE = auto()
    WHILE = auto()
    FOR = auto()
    LOOP = auto()
    BREAK = auto()
    CONTINUE = auto()
    STRUCT = auto()
    TYPE = auto()
    UNSAFE = auto()
    TRUE = auto()
    FALSE = auto()
    AS = auto()
    USE = auto()
    IMPORT = auto()
    PUB = auto()
    ENUM = auto()
    MATCH = auto()  # reserved 2+ B
    # types
    I8 = auto(); I16 = auto(); I32 = auto(); I64 = auto()
    U8 = auto(); U16 = auto(); U32 = auto(); U64 = auto()
    F32 = auto(); F64 = auto()
    BOOL = auto()
    STRING_TYPE = auto()  # keyword "string"
    TENSOR = auto()
    WEIGHTS = auto()
    LAYER = auto()
    # operators
    PLUS = auto(); MINUS = auto(); STAR = auto(); SLASH = auto(); PERCENT = auto()
    ANDAND = auto(); OROR = auto(); BANG = auto()  # && || !
    EQ = auto(); NE = auto(); LT = auto(); LE = auto(); GT = auto(); GE = auto()
    ASSIGN = auto()
    SEMI = auto(); COMMA = auto(); COLON = auto(); COLONCOLON = auto(); ARROW = auto(); FATARROW = auto()  # =>
    LPAREN = auto(); RPAREN = auto(); LBRACE = auto(); RBRACE = auto()
    LBRACKET = auto(); RBRACKET = auto()
    DOT = auto()
    EOF = auto()


KEYWORDS = {
    "fn": TokenKind.FN, "let": TokenKind.LET, "mut": TokenKind.MUT,
    "const": TokenKind.CONST, "return": TokenKind.RETURN,
    "if": TokenKind.IF, "else": TokenKind.ELSE, "while": TokenKind.WHILE,
    "for": TokenKind.FOR, "loop": TokenKind.LOOP,
    "break": TokenKind.BREAK, "continue": TokenKind.CONTINUE,
    "struct": TokenKind.STRUCT, "type": TokenKind.TYPE, "unsafe": TokenKind.UNSAFE,
    "true": TokenKind.TRUE, "false": TokenKind.FALSE, "as": TokenKind.AS, "use": TokenKind.USE, "import": TokenKind.IMPORT, "pub": TokenKind.PUB, "enum": TokenKind.ENUM, "match": TokenKind.MATCH,
    "i8": TokenKind.I8, "i16": TokenKind.I16, "i32": TokenKind.I32, "i64": TokenKind.I64,
    "u8": TokenKind.U8, "u16": TokenKind.U16, "u32": TokenKind.U32, "u64": TokenKind.U64,
    "f32": TokenKind.F32, "f64": TokenKind.F64, "bool": TokenKind.BOOL,
    "string": TokenKind.STRING_TYPE, "str": TokenKind.STRING_TYPE,
    "tensor": TokenKind.TENSOR, "weights": TokenKind.WEIGHTS,
    "layer": TokenKind.LAYER,
}


@dataclass
class Token:
    kind: TokenKind
    value: object
    loc: SourceLocation


class Lexer:
    def __init__(self, source: str, filename: str = "<input>"):
        self.source = source
        self.filename = filename
        self.pos = 0
        self.line = 1
        self.column = 1

    def _loc(self) -> SourceLocation:
        return SourceLocation(self.filename, self.line, self.column)

    def _peek(self, n: int = 0) -> str:
        i = self.pos + n
        return self.source[i] if i < len(self.source) else "\0"

    def _advance(self) -> str:
        ch = self._peek()
        self.pos += 1
        if ch == "\n":
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return ch

    def _skip(self):
        while True:
            ch = self._peek()
            if ch in " \t\r\n":
                self._advance()
                continue
            if ch == "/" and self._peek(1) == "/":
                while self._peek() not in "\n\0":
                    self._advance()
                continue
            if ch == "/" and self._peek(1) == "*":
                start = self._loc()
                self._advance(); self._advance()
                while True:
                    if self._peek() == "\0":
                        raise LexError("unterminated block comment", start)
                    if self._peek() == "*" and self._peek(1) == "/":
                        self._advance(); self._advance()
                        break
                    self._advance()
                continue
            break

    def tokenize(self) -> list[Token]:
        tokens: list[Token] = []
        while True:
            self._skip()
            loc = self._loc()
            ch = self._peek()
            if ch == "\0":
                tokens.append(Token(TokenKind.EOF, None, loc))
                break

            if ch.isdigit():
                start = self.pos
                base = 10
                if ch == "0" and self._peek(1) in "xX":
                    self._advance(); self._advance()
                    base = 16
                    while self._peek().lower() in "0123456789abcdef":
                        self._advance()
                elif ch == "0" and self._peek(1) in "bB":
                    self._advance(); self._advance()
                    base = 2
                    while self._peek() in "01":
                        self._advance()
                else:
                    while self._peek().isdigit():
                        self._advance()
                text = self.source[start:self.pos]
                tokens.append(Token(TokenKind.INT, int(text, base), loc))
                continue

            if ch == '"':
                self._advance()
                start = self.pos
                while self._peek() not in '"\0':
                    if self._peek() == "\\":
                        self._advance()
                    self._advance()
                if self._peek() != '"':
                    raise LexError("unterminated string", loc)
                value = self.source[start:self.pos]
                self._advance()
                # simple escapes
                value = value.replace("\\n", "\n").replace("\\t", "\t").replace('\\"', '"').replace("\\\\", "\\")
                tokens.append(Token(TokenKind.STRING, value, loc))
                continue

            if ch.isalpha() or ch == "_":
                start = self.pos
                while self._peek().isalnum() or self._peek() == "_":
                    self._advance()
                text = self.source[start:self.pos]
                kind = KEYWORDS.get(text, TokenKind.IDENT)
                val = text
                if kind == TokenKind.TRUE:
                    val = True
                elif kind == TokenKind.FALSE:
                    val = False
                tokens.append(Token(kind, val, loc))
                continue

            # two-char
            two = {
                ("=", "="): TokenKind.EQ, ("!", "="): TokenKind.NE,
                ("<", "="): TokenKind.LE, (">", "="): TokenKind.GE,
                ("-", ">"): TokenKind.ARROW,
                ("=", ">"): TokenKind.FATARROW,
                ("&", "&"): TokenKind.ANDAND,
                ("|", "|"): TokenKind.OROR,
                (":", ":"): TokenKind.COLONCOLON,
            }
            pair = (ch, self._peek(1))
            if pair in two:
                self._advance(); self._advance()
                tokens.append(Token(two[pair], "".join(pair), loc))
                continue

            single = {
                "+": TokenKind.PLUS, "-": TokenKind.MINUS, "*": TokenKind.STAR,
                "!": TokenKind.BANG,
                "/": TokenKind.SLASH, "%": TokenKind.PERCENT, "=": TokenKind.ASSIGN,
                ";": TokenKind.SEMI, ",": TokenKind.COMMA, ":": TokenKind.COLON,
                "(": TokenKind.LPAREN, ")": TokenKind.RPAREN,
                "{": TokenKind.LBRACE, "}": TokenKind.RBRACE,
                "[": TokenKind.LBRACKET, "]": TokenKind.RBRACKET,
                "<": TokenKind.LT, ">": TokenKind.GT, ".": TokenKind.DOT,
            }
            if ch in single:
                self._advance()
                tokens.append(Token(single[ch], ch, loc))
                continue

            raise LexError(f"unexpected character {ch!r}", loc)
        return tokens
