/*
 * Vex OS - kernel/src/ui/vexui.c
 * Lock screen + minimal Vex session. See include/vexui.h for scope and
 * for what this deliberately is NOT.
 */
#include "vexui.h"
#include "cursor.h"
#include "power.h"
#include "rtc.h"
#include "netstatus.h"
#include "timer.h"
#include "serial.h"
#include "gfx/draw.h"
#include "gfx/text.h"
#include "accounts.h"
#include "apps.h"
#include "tz.h"
#include "vexterm_host.h"
#include "keymap.h"
#include "pmm.h"
#include "vfs.h"
#include "cpuacct.h"
#include "crypto.h"
#include "wallpaper.h"
#include "vfs_cmds.h"
#include "storage.h"
#include "crystal_kernel.h"
#include "proc_term.h"
#include "gfx/vec.h"
#include "gfx/vecfont.h"

extern const uint8_t gfx_font8x16[96][16];

/* ------------------------------------------------------------------ */
#define REDRAW_ALL() do { U.redraw_all = 1; U.full_req++; U.heavy_req++; } while (0)
/* Palette                                                              */
/* ------------------------------------------------------------------ */
#define C_BG_TOP     gfx_rgb(0x05, 0x12, 0x22)
#define C_BG_BOT     gfx_rgb(0x12, 0x32, 0x50)
#define C_TEXT       gfx_rgb(0xF2, 0xF5, 0xFC)
#define C_DIM        gfx_rgb(0x8E, 0x9A, 0xB8)
#define C_ACCENT     (U.accent)          /* runtime-selectable (Settings > Personalization) */
#define C_FOCUS      gfx_rgb(0xB4, 0xD2, 0xFF)
#define C_PANEL      gfx_rgb(0x12, 0x18, 0x2E)
#define C_PANEL_BD   gfx_rgb(0x30, 0x3C, 0x62)
#define C_ERR        gfx_rgb(0xFF, 0x6B, 0x6B)
#define C_WARN       gfx_rgb(0xF0, 0xC0, 0x40)
#define C_OK         gfx_rgb(0x4C, 0xC7, 0x5A)

/* ------------------------------------------------------------------ */
/* State                                                                */
/* ------------------------------------------------------------------ */
typedef struct { int32_t x, y, w, h; } Rect;
#define MAX_REPAINT 4
#define MAX_CTL 32      /* was 24; setctl() now refuses (and logs) instead of writing past the array */

static struct {
    int inited, quiet;
    const GfxFb *fb; int fb_ok;
    VexUiFacts facts;
    int32_t sw, sh;                       /* logical screen size */
    int compact;                          /* small-screen layout */

    VexUiScreen screen;
    VexUiPopup popup;
    int focus, pfocus;                    /* base focus / popup focus */
    int hover, pressed, press_ctx;        /* press_ctx: -1 none, 0 base, 1 popup item, 2 popup outside */
    int32_t px, py;                       /* pointer position (logical) */
    uint8_t mbuttons;
    int mouse_present;
    uint8_t keydown[256];
    uint64_t last_key_dropped;

    int can_shutdown, can_reboot;
    VexUiAction pending;
    uint32_t enter_count, lock_count;

    /* layout */
    Rect ctl[MAX_CTL]; int ckind[MAX_CTL]; int nctl;
    Rect pop;                             /* popup panel */
    Rect pitem[ACCT_MAX + 4];          /* popup items (net popup uses [0] as Close) */
    Rect card;                            /* session card */
    Rect dyn;                             /* live-text rectangle */
    Rect status_r;
    Rect clock_r;

    /* render bookkeeping */
    int redraw_all;
    Rect repaint[MAX_REPAINT]; int repaint_n;
    int drawn_ctl[MAX_CTL];
    int drawn_pitem[ACCT_MAX + 4];
    int popup_redraw;
    int dyn_dirty;
    int cursor_dirty;
    uint64_t last_sec;
    char status[96];
    char last_input[64];
    /* DESKTOP-01 */
    char name_buf[40]; int name_len; char search_buf[40]; int search_len; char setup_msg[96];
    int pscroll, na, app_hit[8]; int session_user; uint32_t signin_count;
    char pass_buf[72]; int pass_len; char pass2_buf[72]; int pass2_len; char auth_msg[64]; int add_mode;
    int xdir, xrows, xn, xlist[64], xscroll, xsel, xdlg, xname_len; char xname_buf[40]; char xmsg[96];
    int cpu_pm; uint64_t img_b, fb_b; uint32_t full_req, full_draws, part_draws, heavy_req;
    uint32_t ctl_dirty; int msg_dirty, xdlg_dirty, prompt_dirty, cheap_valid; Rect cheap_old;
    GfxColor accent;
    char vb_buf[VFS_DATA_MAX]; int vb_len, vb_cur, vb_node, vb_modified, vb_dlg, vb_pending, vb_d0, vb_d1, vb_scroll, vb_status_dirty;
    char vb_name[72]; int vb_name_len; char vb_msg[96];
    int wdx[8], wdy[8]; uint8_t wmin[8]; int drag, drag_ox, drag_oy;
    int xmode, xsort, xtarget; int ctx_n; uint8_t ctx_code[8]; int ctx_target; int32_t ctx_x, ctx_y;
    int spage; uint64_t beep_off;
    int wp_sel, wp_err;                   /* WALLPAPER-01: previewed (not necessarily applied) index; last Settings message is an error */
} U;

/* ------------------------------------------------------------------ */
/* Tiny helpers                                                         */
/* ------------------------------------------------------------------ */
static void ulog(const char *s) { if (!U.quiet) serial_puts(s); }
static void ulog2(const char *a, const char *b) { if (!U.quiet) { serial_puts(a); serial_puts(b); } }

static void log_rect(const char *name, Rect r)
{
    if (U.quiet) return;
    serial_puts(name); serial_puts("=("); serial_put_dec64((uint64_t)r.x); serial_puts(",");
    serial_put_dec64((uint64_t)r.y); serial_puts(",");  serial_put_dec64((uint64_t)r.w); serial_puts(",");
    serial_put_dec64((uint64_t)r.h); serial_puts(") ");
}
static int32_t imin(int32_t a, int32_t b) { return a < b ? a : b; }
static int32_t imax(int32_t a, int32_t b) { return a > b ? a : b; }
static int in_rect(const Rect *r, int32_t x, int32_t y) { return x >= r->x && x < r->x + r->w && y >= r->y && y < r->y + r->h; }
static int rects_overlap(const Rect *a, const Rect *b) { return a->x < b->x + b->w && b->x < a->x + a->w && a->y < b->y + b->h && b->y < a->y + a->h; }
static Rect mkrect(int32_t x, int32_t y, int32_t w, int32_t h) { Rect r; r.x = x; r.y = y; r.w = w; r.h = h; return r; }
static int slen(const char *s) { int n = 0; while (s[n] && n < 255) n++; return n; }

typedef struct { char b[96]; int n; } Sb;
static void sb_s(Sb *s, const char *t) { while (*t && s->n < (int)sizeof s->b - 1) s->b[s->n++] = *t++; s->b[s->n] = 0; }
static void sb_u(Sb *s, uint64_t v) { char d[21]; int q = 0; do { d[q++] = (char)('0' + v % 10); v /= 10; } while (v && q < 20); while (q && s->n < (int)sizeof s->b - 1) s->b[s->n++] = d[--q]; s->b[s->n] = 0; }
static void sb_pad(Sb *s, uint64_t v, int digits) { char d[8]; for (int i = digits - 1; i >= 0; i--) { d[i] = (char)('0' + v % 10); v /= 10; } for (int i = 0; i < digits && s->n < (int)sizeof s->b - 1; i++) s->b[s->n++] = d[i]; s->b[s->n] = 0; }

/* ------------------------------------------------------------------ */
/* Drawing primitives (all no-ops without a usable framebuffer)         */
/* ------------------------------------------------------------------ */
/* Every screen that is the ONE desktop (the desktop itself and all app windows) shares one background.
 * (Release-04 slice bug fixed here: Valbook and Settings fell through to the lock-screen sky.) */
static int desk_screen(VexUiScreen v) { return v == VEXUI_DESKTOP || v == VEXUI_TERMINAL || v == VEXUI_EXPLORER || v == VEXUI_TASKMGR || v == VEXUI_VALBOOK || v == VEXUI_SETTINGS; }
static GfxColor bg_at(int32_t y)
{
    if (desk_screen(U.screen)) return gfx_rgb(0x05, 0x12, 0x22);   /* default Zen Horizon desktop: solid navy, exactly as before (no asset: this IS the default wallpaper) */
    { /* lock/setup: dusk sky down to a warm horizon at 62% height, then water (procedural, no image asset) */
        int32_t hz = U.sh * 62 / 100; GfxColor c;
        if (y < hz) { int32_t t = y * 1000 / (hz ? hz : 1); c.r = (uint8_t)(0x0B + (0x78 - 0x0B) * t / 1000 * t / 1000 + (0x3C - 0x0B) * t / 1000 / 3); c.g = (uint8_t)(0x22 + (0x8A - 0x22) * t / 1000); c.b = (uint8_t)(0x5A + (0xC8 - 0x5A) * t / 1000); }
        else { int32_t t = (y - hz) * 1000 / (U.sh - hz > 0 ? U.sh - hz : 1); c.r = (uint8_t)(0x2A - (0x2A - 0x08) * t / 1000); c.g = (uint8_t)(0x48 - (0x48 - 0x10) * t / 1000); c.b = (uint8_t)(0x7C - (0x7C - 0x28) * t / 1000); }
        return c; }
    int32_t h = U.sh > 1 ? U.sh - 1 : 1;
    if (y < 0) y = 0;
    if (y > h) y = h;
    GfxColor t = C_BG_TOP, b = C_BG_BOT, c;
    c.r = (uint8_t)(t.r + ((int32_t)b.r - t.r) * y / h);
    c.g = (uint8_t)(t.g + ((int32_t)b.g - t.g) * y / h);
    c.b = (uint8_t)(t.b + ((int32_t)b.b - t.b) * y / h);
    return c;
}

static void bg_rect(Rect r)
{
    if (!U.fb_ok) return;
    int32_t y0 = imax(r.y, 0), y1 = imin(r.y + r.h, U.sh), x0 = imax(r.x, 0), x1 = imin(r.x + r.w, U.sw);
    if (x1 <= x0) return;
    int wall = desk_screen(U.screen) && wp_active();            /* WALLPAPER-01: copy the pre-scaled cache; nothing is decoded here */
    for (int32_t y = y0; y < y1; y++) {
        if (wall && wp_blit_span(U.fb->pixels + (size_t)y * U.fb->pitch_px + (uint32_t)x0, (uint32_t)x0, (uint32_t)y, (uint32_t)(x1 - x0))) continue;
        gfx_fill_rect(U.fb, x0, y, x1 - x0, 1, bg_at(y));
    }
}

/* Transparent, integer-scaled 8x16 text; horizontal runs are merged so a glyph
 * costs a handful of rect fills rather than one per pixel. */
static void glyph(int32_t px, int32_t py, char ch, int sc, GfxColor col)
{
    unsigned idx = (unsigned)(uint8_t)ch;
    if (idx < 0x20 || idx > 0x7E) idx = 0x20;
    const uint8_t *g = gfx_font8x16[idx - 0x20];
    for (int row = 0; row < GFX_FONT_H; row++) {
        uint8_t bits = g[row];
        int c = 0;
        while (c < GFX_FONT_W) {
            if (!(bits & (0x80 >> c))) { c++; continue; }
            int run = 1;
            while (c + run < GFX_FONT_W && (bits & (0x80 >> (c + run)))) run++;
            gfx_fill_rect(U.fb, px + c * sc, py + row * sc, run * sc, sc, col);
            c += run;
        }
    }
}
static void aa_disc(int32_t cx, int32_t cy, int32_t r, GfxColor c)
{
    if (r < 0) return;
    if (vec_aa()) { VecPaint pt = vec_solid(c, 255); if (vec_fill_ellipse(U.fb, VFX_INT(cx) + 128, VFX_INT(cy) + 128, VFX_INT(r) + 128, VFX_INT(r) + 128, &pt, 0) == 0) return; }
    gfx_circle(U.fb, cx, cy, r, c);
}
static int32_t text_w(const char *s, int sc) { return (int32_t)slen(s) * GFX_FONT_W * sc; }
static void text(int32_t x, int32_t y, const char *s, int sc, GfxColor col)
{
    if (!U.fb_ok) return;
    for (int n = 0; s[n] && n < 255; n++) {
        int32_t gx = x + n * GFX_FONT_W * sc;
        if (vec_aa() && vf_has_glyph((unsigned char)s[n]) && sc >= 1 && sc <= 8) {
            if (s[n] == ' ') continue;
            if (sc == 1) vf_blend_cell(U.fb, gx, y, (unsigned char)s[n], col, 255);               /* cached coverage: as cheap as the bitmap */
            else {                                                                               /* scaled text is rendered from the outlines, not pixel-doubled */
                char one[2] = { s[n], 0 }; VecPaint pt = vec_solid(col, 255);
                vf_draw_text(U.fb, VFX_INT(gx), (vfx)(VFX_INT(y) + VF_CELL_BASE_Q8 * sc), (vfx)(VF_CELL_SIZE_Q8 * sc), one, &pt, 0);
            }
        } else glyph(gx, y, s[n], sc, col);
    }
}
static void text_c(int32_t cx, int32_t y, const char *s, int sc, GfxColor col) { text(cx - text_w(s, sc) / 2, y, s, sc, col); }

/* Rounded rectangle via per-row corner inset (the aliased fallback; GFX-VEC-01 draws the anti-aliased one when enabled). */
static void rrect_aliased(Rect r, int rad, GfxColor c);
static void rrect(Rect r, int rad, GfxColor c)
{
    if (!U.fb_ok || r.w <= 0 || r.h <= 0) return;
    if (vec_aa()) {
        VecPaint pt = vec_solid(c, 255);
        if (vec_fill_rrect(U.fb, VFX_INT(r.x), VFX_INT(r.y), VFX_INT(r.w), VFX_INT(r.h), VFX_INT(rad), &pt, 0) == 0) return;
    }
    rrect_aliased(r, rad, c);
}
static void rrect_aliased(Rect r, int rad, GfxColor c)
{
    if (rad * 2 > r.h) rad = r.h / 2;
    if (rad * 2 > r.w) rad = r.w / 2;
    for (int32_t row = 0; row < r.h; row++) {
        int32_t d = row < rad ? rad - row : (row >= r.h - rad ? row - (r.h - rad) + 1 : 0);
        int32_t inset = 0;
        if (d > 0) {                      /* smallest inset with (rad-inset)^2 + (d-0.5)^2 <= rad^2, integer form */
            while (inset < rad && (rad - inset) * (rad - inset) * 4 + (2 * d - 1) * (2 * d - 1) > 4 * rad * rad) inset++;
        }
        gfx_fill_rect(U.fb, r.x + inset, r.y + row, r.w - 2 * inset, 1, c);
    }
}

/* ------------------------------------------------------------------ */
/* Layout                                                               */
static void set_status(const char *msg);
static int tf_edit(char *buf, int *len, int cap, unsigned key, int ascii);
static void launch_app(uint32_t id);
static void lock_screen(const char *how);
static int is_editable(const char *n);
static void draw_setup_msg(void); static void draw_auth_msg(void); static void draw_xmsg(void); static void draw_xdlg_field(void);
extern void memreport_get(uint64_t *img, uint64_t *fb);
static int bufeq(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return *a == *b; }
static void wipe(char *b, int n) { secure_zero(b, (size_t)n); }
extern void memreport_snapshot(const char *tag);
/* ------------------------------------------------------------------ */
/* DESKTOP-01 layout: per-screen control sets (kinds), popups           */
/* ------------------------------------------------------------------ */
enum { CK_SIGNIN = VEXUI_CK_SIGNIN, CK_USERS, CK_NET, CK_POWER, CK_VBTN, CK_SEARCH, CK_TERM, CK_NAME, CK_CREATE, CK_TCLOSE,
       CK_PASS, CK_PASS2, CK_EXPL, CK_TASK, CK_XUP, CK_XHOME, CK_XNEW, CK_XROW, CK_XOK, CK_XCANCEL,
       CK_TMIN, CK_VALB, CK_SETT, CK_XSORT, CK_VBNEW, CK_VBOPEN, CK_VBSAVE, CK_VBDISCARD, CK_SROW, CK_SSWATCH, CK_SBTN, CK_WPTILE, CK_WPAPPLY, CK_WPRESET };
static const char *const CK_NAMES[] = { "signin", "users", "net", "power", "vbtn", "search", "term", "name", "create", "tclose", "pass", "pass2", "expl", "task", "xup", "xhome", "xnew", "xrow", "xok", "xcancel", "tmin", "valb", "sett", "xsort", "vbnew", "vbopen", "vbsave", "vbdiscard", "srow", "sswatch", "sbtn", "wptile", "wpapply", "wpreset" };
_Static_assert(sizeof CK_NAMES / sizeof CK_NAMES[0] == CK_WPRESET + 1, "CK_NAMES must name every control kind (log_layout indexes it)");
#define USERS_VISIBLE 6

static int is_app_screen(VexUiScreen v) { return v == VEXUI_TERMINAL || v == VEXUI_EXPLORER || v == VEXUI_TASKMGR || v == VEXUI_VALBOOK || v == VEXUI_SETTINGS; }
static int app_idx(VexUiScreen v) { return v == VEXUI_EXPLORER ? 1 : v == VEXUI_TASKMGR ? 2 : v == VEXUI_VALBOOK ? 3 : v == VEXUI_SETTINGS ? 4 : 0; }
static VexUiScreen screen_of_app(uint32_t id) { return id == APP_ID_EXPLORER ? VEXUI_EXPLORER : id == APP_ID_TASKMGR ? VEXUI_TASKMGR : id == APP_ID_VALBOOK ? VEXUI_VALBOOK : id == APP_ID_SETTINGS ? VEXUI_SETTINGS : VEXUI_TERMINAL; }
static uint32_t app_of_screen(VexUiScreen v) { return v == VEXUI_EXPLORER ? APP_ID_EXPLORER : v == VEXUI_TASKMGR ? APP_ID_TASKMGR : v == VEXUI_VALBOOK ? APP_ID_VALBOOK : v == VEXUI_SETTINGS ? APP_ID_SETTINGS : APP_ID_TERMINAL; }
static void win_base(int32_t *bx, int32_t *by) { int32_t m = U.compact ? 12 : 24; *bx = (U.sw - imin(U.sw - 2 * m, 1000)) / 2; *by = m; }
static char lcc(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
static int cmp_name(const char *a, const char *b) { while (*a && lcc(*a) == lcc(*b)) { a++; b++; } return lcc(*a) - lcc(*b); }
static const char *ext_of(const char *n) { const char *e = ""; for (; *n; n++) if (*n == '.') e = n + 1; return e; }
static int xcmp(int a, int b)
{
    const VfsNode *x = vfs_node(a), *y = vfs_node(b); int r = 0;
    if (x->is_dir != y->is_dir) return (int)y->is_dir - (int)x->is_dir;          /* folders always first */
    switch (U.xsort) {
    case 0: r = cmp_name(x->name, y->name); break;
    case 1: r = -cmp_name(x->name, y->name); break;
    case 2: r = cmp_name(ext_of(x->name), ext_of(y->name)); break;
    case 3: r = (int)x->size - (int)y->size; break;
    default: r = y->mtime_ms > x->mtime_ms ? 1 : y->mtime_ms < x->mtime_ms ? -1 : 0; break;
    }
    return r ? r : cmp_name(x->name, y->name);
}
/* Sorts only the DISPLAY order (xlist); the stored directory is never touched. */
static void sort_xlist(void) { for (int i = 1; i < U.xn; i++) { int v = U.xlist[i], j = i - 1; while (j >= 0 && xcmp(U.xlist[j], v) > 0) { U.xlist[j + 1] = U.xlist[j]; j--; } U.xlist[j + 1] = v; } }
static const char *xok_label(void)
{
    if (U.screen == VEXUI_VALBOOK) return U.vb_dlg == 2 ? "Open" : "Save";
    return U.xmode == 4 ? "Rename" : U.xmode == 5 ? "Delete" : "Create";
}
/* ---- Valbook document core (no drawing) ---- */
static int vb_nlines(void) { int l = 1; for (int i = 0; i < U.vb_len; i++) if (U.vb_buf[i] == '\n') l++; return l; }
static int vb_line_start(int line) { int l = 0, i = 0; while (l < line && i < U.vb_len) { if (U.vb_buf[i] == '\n') l++; i++; } return i; }
static void vb_pos(int *line, int *col) { int l = 0, c = 0; for (int i = 0; i < U.vb_cur; i++) { if (U.vb_buf[i] == '\n') { l++; c = 0; } else c++; } *line = l; *col = c; }
static void vb_dirty(int l0, int l1) { if (U.vb_d0 < 0 || l0 < U.vb_d0) U.vb_d0 = l0; if (l1 > U.vb_d1) U.vb_d1 = l1; U.vb_status_dirty = 1; }
static Rect vb_area(void) { return mkrect(U.card.x + 16, U.card.y + 44 + 40, U.card.w - 32, U.card.h - 44 - 40 - 36); }
static void vb_ensure_scroll(void)
{
    int rows = vb_area().h / 16, cl, cc; if (rows < 1) rows = 1; vb_pos(&cl, &cc);
    int old = U.vb_scroll;
    if (cl < U.vb_scroll) { U.vb_scroll = cl; }
    if (cl >= U.vb_scroll + rows) { U.vb_scroll = cl - rows + 1; }
    if (U.vb_scroll != old) { U.vb_d0 = 0; U.vb_d1 = 1 << 20; U.vb_status_dirty = 1; }       /* scrolled: repaint the text area (and only it) */
}
static void vb_set_msg(const char *m) { int i = 0; for (; m[i] && i < 95; i++) U.vb_msg[i] = m[i]; U.vb_msg[i] = 0; U.vb_status_dirty = 1; }
static void vb_insert(int c)
{
    if (U.vb_len >= VFS_DATA_MAX - 1) { vb_set_msg("Document is full (2047 bytes)."); return; }
    int cl, cc; vb_pos(&cl, &cc);
    for (int i = U.vb_len; i > U.vb_cur; i--) U.vb_buf[i] = U.vb_buf[i - 1];
    U.vb_buf[U.vb_cur++] = (char)c; U.vb_len++; U.vb_buf[U.vb_len] = 0; U.vb_modified = 1; U.vb_msg[0] = 0;
    if (c == '\n') vb_dirty(cl, 1 << 20); else vb_dirty(cl, cl);
    vb_ensure_scroll();
}
static void vb_backspace(void)
{
    if (U.vb_cur <= 0) return;
    int cl, cc; vb_pos(&cl, &cc); char gone = U.vb_buf[U.vb_cur - 1];
    for (int i = U.vb_cur - 1; i < U.vb_len - 1; i++) U.vb_buf[i] = U.vb_buf[i + 1];
    U.vb_cur--; U.vb_len--; U.vb_buf[U.vb_len] = 0; U.vb_modified = 1; U.vb_msg[0] = 0;
    if (gone == '\n') vb_dirty(cl > 0 ? cl - 1 : 0, 1 << 20); else vb_dirty(cl, cl);
    vb_ensure_scroll();
}
static void vb_move(int key)
{
    int cl, cc; vb_pos(&cl, &cc); int old = cl;
    if (key == VEX_KEY_LEFT && U.vb_cur > 0) U.vb_cur--;
    else if (key == VEX_KEY_RIGHT && U.vb_cur < U.vb_len) U.vb_cur++;
    else if (key == VEX_KEY_UP || key == VEX_KEY_DOWN) {
        int tl = cl + (key == VEX_KEY_DOWN ? 1 : -1); if (tl < 0 || tl >= vb_nlines()) return;
        int s = vb_line_start(tl), len = 0; while (s + len < U.vb_len && U.vb_buf[s + len] != '\n') len++;
        U.vb_cur = s + (cc < len ? cc : len);
    }
    vb_pos(&cl, &cc); vb_dirty(old < cl ? old : cl, old < cl ? cl : old); vb_ensure_scroll();
}
static void vb_reset(void) { U.vb_len = 0; U.vb_cur = 0; U.vb_buf[0] = 0; U.vb_node = -1; U.vb_modified = 0; U.vb_scroll = 0; U.vb_dlg = 0; U.vb_msg[0] = 0; U.vb_name_len = 0; U.vb_name[0] = 0; }
static void setctl(int i, int kind, Rect r) { if (i < 0 || i >= MAX_CTL) { serial_puts("[ui] ERROR: control table full, control dropped\n"); return; } U.ckind[i] = kind; U.ctl[i] = r; if (i + 1 > U.nctl) U.nctl = i + 1; }
static int pop_na(void) { return U.na; }
static int is_admin_session(void) { return U.session_user >= 0 && acct_role(U.session_user) == ACCT_ROLE_ADMIN; }

/* WALLPAPER-01 Settings page geometry: one function used by BOTH layout() (hit rectangles) and drawing, so they cannot disagree. */
#define WP_MAXT 12
typedef struct { int big; int32_t tx; Rect prev, apply, reset, tile[WP_MAXT]; int ntile; int32_t tw, th, img_h, label_y, list_y; } WpGeom;
static void wp_geom_mode(WpGeom *g, int mode)
{
    int32_t px = U.card.x + 260, py = U.card.y + 96, aw = U.card.w - 260 - 20, bottom = U.card.y + U.card.h - 52;
    g->big = (mode < 2 && U.card.h >= 600 && aw >= 600);
    int32_t gap = mode == 3 ? 8 : 12; g->ntile = 0;
    g->label_y = py;
    if (g->big) {
        int32_t pw = mode == 0 ? 336 : 240, ph = mode == 0 ? 210 : 150;      /* mode 1: smaller preview so all tiles still fit */
        g->prev = mkrect(px, py + 24, pw, ph); g->tx = px + pw + 20;
        g->apply = mkrect(g->tx, g->prev.y + g->prev.h - 78, 190, 34); g->reset = mkrect(g->tx, g->prev.y + g->prev.h - 36, 190, 34);
        g->tw = 156;
    } else {
        g->prev = mkrect(0, 0, 0, 0); g->tx = px;
        g->apply = mkrect(px, py + 24, 150, 34); g->reset = mkrect(px + 162, py + 24, 150, 34);
        g->tw = mode == 3 ? 72 : 100;                                       /* mode 3: tiny screens (e.g. 640x480) */
    }
    g->img_h = (g->tw - 8) * 10 / 16; g->th = g->img_h + 8 + 20;           /* image + padding + caption line */
    int32_t per = (aw + gap) / (g->tw + gap); if (per < 1) per = 1;
    int32_t y0 = (g->big ? g->prev.y + g->prev.h : g->apply.y + g->apply.h) + 40, n = wp_count();
    g->list_y = y0 - 24;
    for (int i = 0; i < n && g->ntile < WP_MAXT; i++) {
        int32_t col = i % per, row = i / per, ty = y0 + row * (g->th + 12);
        if (ty + g->th > bottom) break;                                      /* never draw a control that would leave the window */
        g->tile[g->ntile++] = mkrect(px + col * (g->tw + gap), ty, g->tw, g->th);
    }
}
/* Pick the roomiest layout in which EVERY wallpaper is selectable (a hidden tile = an unusable wallpaper). Falls back to the most compact. */
static void wp_geom(WpGeom *g)
{
    for (int mode = 0; mode < 4; mode++) { wp_geom_mode(g, mode); if (g->ntile >= wp_count() || mode == 3) return; }
}
static void layout(void)
{
    int32_t w = U.sw, h = U.sh;
    U.compact = (w < 700 || h < 500);
    int32_t m = U.compact ? 12 : 24;
    U.nctl = 0;
    if (U.screen == VEXUI_SETUP) {
        int32_t cw = imin(440, w - 2 * m), cx = (w - cw) / 2, ch = 408, cy = imax(m, (h - ch) / 2);
        U.card = mkrect(cx, cy, cw, ch);
        setctl(0, CK_NAME, mkrect(cx + 32, cy + 176, cw - 64, 40));
        setctl(1, CK_CREATE, mkrect(cx + 32, cy + 320, cw - 64, 40));
        setctl(2, CK_PASS, mkrect(cx + 32, cy + 224, cw - 64, 40));
        setctl(3, CK_PASS2, mkrect(cx + 32, cy + 272, cw - 64, 40));
    } else if (U.screen == VEXUI_LOCK) {
        int32_t bw = 64, bh = 56, g = 12, py = h - m - bh;
        int32_t sy = U.compact ? h * 64 / 100 : h * 70 / 100;
        setctl(CK_SIGNIN, CK_SIGNIN, mkrect((w - 200) / 2, sy, 200, 44));
        setctl(1, CK_USERS, mkrect(w - m - 3 * bw - 2 * g, py, bw, bh));
        setctl(2, CK_NET, mkrect(w - m - 2 * bw - g, py, bw, bh));
        setctl(3, CK_POWER, mkrect(w - m - bw, py, bw, bh));
        if (acct_has_password(acct_selected())) setctl(4, CK_PASS, mkrect((w - 260) / 2, sy - 52, 260, 40));
        int32_t cs = U.compact ? 3 : (w >= 1000 ? 6 : 4);
        U.clock_r = mkrect(w / 2 - 5 * 8 * cs / 2 - 120, U.compact ? 8 : h / 12, 5 * 8 * cs + 240, 16 * cs + 56);
    } else if (U.screen == VEXUI_DESKTOP) {
        int32_t tb = 56;
        setctl(0, CK_VBTN, mkrect(12, h - tb + 6, 44, 44));
        setctl(1, CK_SEARCH, mkrect(imax(m, w / 2 - 330), 12, imin(420, w - 260), 36));
        setctl(2, CK_TERM, mkrect(64, h - tb + 6, 44, 44));
        setctl(3, CK_EXPL, mkrect(116, h - tb + 6, 44, 44));
        setctl(4, CK_TASK, mkrect(168, h - tb + 6, 44, 44));
        setctl(5, CK_VALB, mkrect(220, h - tb + 6, 44, 44));
        setctl(6, CK_SETT, mkrect(272, h - tb + 6, 44, 44));
        U.clock_r = mkrect(w - 176, 4, 170, 56);
    } else {                                                     /* app windows: terminal, explorer, task manager, valbook, settings */
        int32_t ww = imin(w - 2 * m, 1000), wh = h - 56 - 2 * m; if (wh < 200) wh = 200;
        int ai = app_idx(U.screen), bx, by; win_base(&bx, &by);
        U.card = mkrect(cursor_clamp(bx + U.wdx[ai], -(ww - 140), w - 140), cursor_clamp(by + U.wdy[ai], 0, h - 56 - 40), ww, wh);
        setctl(0, CK_TCLOSE, mkrect(U.card.x + U.card.w - 40, U.card.y + 6, 32, 28));
        int32_t ty = U.card.y + 44;
        if (U.screen == VEXUI_EXPLORER) {
            setctl(1, CK_XUP, mkrect(U.card.x + 16, ty, 70, 32)); setctl(2, CK_XHOME, mkrect(U.card.x + 94, ty, 80, 32));
            setctl(3, CK_XNEW, mkrect(U.card.x + 182, ty, 110, 32));
            U.xn = vfs_list(U.xdir, U.xlist, 64); sort_xlist();
            int32_t rows = imin(12, (U.card.h - 44 - 32 - 90) / 26); if (rows < 1) rows = 1;
            U.xrows = rows;
            if (U.xscroll > U.xn - rows) U.xscroll = imax(0, U.xn - rows);
            if (!U.xdlg) for (int k = 0; k < rows && U.xscroll + k < U.xn; k++) setctl(4 + k, CK_XROW, mkrect(U.card.x + 16, ty + 80 + k * 26, U.card.w - 32, 24));
            if (U.xdlg) { int base = U.nctl; Rect d = mkrect(U.card.x + U.card.w / 2 - 190, U.card.y + 150, 380, 150);
                setctl(base, CK_XOK, mkrect(d.x + d.w - 16 - 220, d.y + d.h - 50, 100, 34)); setctl(base + 1, CK_XCANCEL, mkrect(d.x + d.w - 16 - 110, d.y + d.h - 50, 100, 34)); }
            setctl(U.nctl, CK_XSORT, mkrect(U.card.x + 300, ty, 170, 32));
        } else if (U.screen == VEXUI_VALBOOK) {
            setctl(1, CK_VBNEW, mkrect(U.card.x + 16, ty, 80, 32)); setctl(2, CK_VBOPEN, mkrect(U.card.x + 104, ty, 80, 32)); setctl(3, CK_VBSAVE, mkrect(U.card.x + 192, ty, 80, 32));
            if (U.vb_dlg) { Rect d = mkrect(U.card.x + U.card.w / 2 - 190, U.card.y + 150, 380, 150); int base = U.nctl;
                if (U.vb_dlg == 3) { setctl(base, CK_XOK, mkrect(d.x + 16, d.y + d.h - 50, 110, 34)); setctl(base + 1, CK_VBDISCARD, mkrect(d.x + 134, d.y + d.h - 50, 110, 34)); setctl(base + 2, CK_XCANCEL, mkrect(d.x + 252, d.y + d.h - 50, 110, 34)); }
                else { setctl(base, CK_XOK, mkrect(d.x + d.w - 16 - 220, d.y + d.h - 50, 100, 34)); setctl(base + 1, CK_XCANCEL, mkrect(d.x + d.w - 16 - 110, d.y + d.h - 50, 100, 34)); } }
        } else if (U.screen == VEXUI_SETTINGS) {
            for (int k = 0; k < 7; k++) setctl(1 + k, CK_SROW, mkrect(U.card.x + 16, U.card.y + 52 + k * 36, 210, 32));
            if (U.spage == 2) for (int k = 0; k < 6; k++) setctl(U.nctl, CK_SSWATCH, mkrect(U.card.x + 260 + k * 46, U.card.y + 150, 34, 34));
            if (U.spage == 3) setctl(U.nctl, CK_SBTN, mkrect(U.card.x + 260, U.card.y + 150, 190, 34));
            if (U.spage == 5) { WpGeom g; wp_geom(&g); setctl(U.nctl, CK_WPAPPLY, g.apply); setctl(U.nctl, CK_WPRESET, g.reset); for (int k = 0; k < g.ntile; k++) setctl(U.nctl, CK_WPTILE, g.tile[k]); }
            if (U.spage == 4 && is_admin_session()) setctl(U.nctl, CK_SBTN, mkrect(U.card.x + 260, U.card.y + U.card.h - 90, 170, 34));
        }
        setctl(U.nctl, CK_TMIN, mkrect(U.card.x + U.card.w - 76, U.card.y + 6, 32, 28));
        { int32_t tbt = h - 56 + 6;
          setctl(U.nctl, CK_VBTN, mkrect(12, tbt, 44, 44)); setctl(U.nctl, CK_TERM, mkrect(64, tbt, 44, 44)); setctl(U.nctl, CK_EXPL, mkrect(116, tbt, 44, 44));
          setctl(U.nctl, CK_TASK, mkrect(168, tbt, 44, 44)); setctl(U.nctl, CK_VALB, mkrect(220, tbt, 44, 44)); setctl(U.nctl, CK_SETT, mkrect(272, tbt, 44, 44)); }
    }
    U.status_r = mkrect(0, h - m - 56 - 30, w, 20);

    /* ---- popup geometry ---- */
    U.pop = mkrect(0, 0, 0, 0);
    if (U.popup == VEXUI_POPUP_POWER) {
        int32_t pw2 = imin(300, w - 2 * m), ih = 40, ph = 12 + 24 + 3 * (ih + 6) + 4 + 32 + 8;
        const Rect *b = &U.ctl[CK_POWER];
        U.pop = mkrect(imax(m, b->x + b->w - pw2), b->y - 10 - ph, pw2, ph);
        for (int i = 0; i < 3; i++) U.pitem[i] = mkrect(U.pop.x + 16, U.pop.y + 40 + i * (ih + 6), U.pop.w - 32, ih);
    } else if (U.popup == VEXUI_POPUP_NET) {
        int32_t pw2 = imin(380, w - 2 * m), ph = 12 + 16 + 10 + 18 * 5 + 12 + 34 + 12;
        const Rect *b = &U.ctl[CK_NET];
        U.pop = mkrect(imax(m, b->x + b->w - pw2 + 76), b->y - 10 - ph, pw2, ph);
        if (U.pop.x + U.pop.w > w - m) U.pop.x = w - m - U.pop.w;
        U.pitem[0] = mkrect(U.pop.x + U.pop.w - 16 - 120, U.pop.y + U.pop.h - 12 - 34, 120, 34);
    } else if (U.popup == VEXUI_POPUP_USERS) {
        int32_t n = acct_count(), vis = imin(n, USERS_VISIBLE), pw2 = imin(340, w - 2 * m), rh = 48;
        int32_t ph = 12 + 20 + 18 + 10 + vis * (rh + 6) + 6 + 34 + 12;
        const Rect *b = &U.ctl[CK_USERS];
        U.pop = mkrect(imax(m, imin(b->x + b->w - pw2 + 130, w - m - pw2)), b->y - 10 - ph, pw2, ph);
        if (U.pscroll > n - vis) U.pscroll = imax(0, n - vis);
        for (int i = 0; i < n; i++) {
            int slot = i - U.pscroll;
            U.pitem[i] = (slot >= 0 && slot < vis) ? mkrect(U.pop.x + 16, U.pop.y + 12 + 20 + 18 + 10 + slot * (rh + 6), U.pop.w - 32, rh) : mkrect(0, 0, 0, 0);
        }
        U.pitem[n] = mkrect(U.pop.x + U.pop.w - 16 - 100, U.pop.y + U.pop.h - 12 - 34, 100, 34);
    } else if (U.popup == VEXUI_POPUP_CTX) {
        int32_t pw2 = 214, ih = 30, ph = 8 + U.ctx_n * ih + 8;
        U.pop = mkrect(cursor_clamp(U.ctx_x, 0, w - pw2), cursor_clamp(U.ctx_y, 0, h - 56 - ph), pw2, ph);
        for (int i = 0; i < U.ctx_n; i++) U.pitem[i] = mkrect(U.pop.x + 6, U.pop.y + 8 + i * ih, pw2 - 12, ih - 2);
    } else if (U.popup == VEXUI_POPUP_VMENU || U.popup == VEXUI_POPUP_SEARCH) {
        U.na = apps_search(U.search_buf, U.app_hit, 8);
        int32_t na = pop_na(), rows = imax(1, na);
        if (U.popup == VEXUI_POPUP_VMENU) {
            int32_t pw2 = imin(340, w - 2 * m), ph = 12 + 36 + 12 + 16 + rows * 48 + 10 + (3 + is_admin_session()) * 44 + 12;
            U.pop = mkrect(m, U.sh - 56 - 8 - ph, pw2, ph);
            for (int i = 0; i < na; i++) U.pitem[i] = mkrect(U.pop.x + 12, U.pop.y + 12 + 36 + 12 + 16 + i * 48, U.pop.w - 24, 44);
            int32_t y0 = U.pop.y + 12 + 36 + 12 + 16 + rows * 48 + 10;
            for (int i = 0; i < 3 + is_admin_session(); i++) U.pitem[na + i] = mkrect(U.pop.x + 12, y0 + i * 44, U.pop.w - 24, 40);
        } else {
            const Rect *b = &U.ctl[1];
            U.pop = mkrect(b->x, b->y + b->h + 4, b->w, 8 + rows * 44 + 8);
            for (int i = 0; i < na; i++) U.pitem[i] = mkrect(U.pop.x + 8, U.pop.y + 8 + i * 44, U.pop.w - 16, 40);
        }
    }
}

/* ---- popup item model ---- */
static int pitem_count(void)
{
    switch (U.popup) {
    case VEXUI_POPUP_POWER: return 3;
    case VEXUI_POPUP_NET: return 1;
    case VEXUI_POPUP_USERS: return acct_count() + 1;
    case VEXUI_POPUP_VMENU: return U.na + 3 + is_admin_session();
    case VEXUI_POPUP_SEARCH: return U.na;
    case VEXUI_POPUP_CTX: return U.ctx_n;
    default: return 0;
    }
}
int vexui_popup_count(void) { return pitem_count(); }
int vexui_popup_item_enabled(int item)
{
    if (item < 0 || item >= pitem_count()) return 0;
    if (U.popup == VEXUI_POPUP_POWER) return item == VEXUI_PWR_SHUTDOWN ? U.can_shutdown : item == VEXUI_PWR_REBOOT ? U.can_reboot : 1;
    if (U.popup == VEXUI_POPUP_VMENU && item == U.na + 1) return U.can_shutdown;
    if (U.popup == VEXUI_POPUP_VMENU && item == U.na + 2) return U.can_reboot;
    return 1;
}

enum { ST_HOVER = 1, ST_PRESSED = 2, ST_FOCUS = 4, ST_DISABLED = 8 };
static int ctl_style(int i)
{
    int s = 0;
    if (U.popup == VEXUI_POPUP_NONE || U.popup == VEXUI_POPUP_SEARCH) {
        if (U.hover == i && U.popup == VEXUI_POPUP_NONE) s |= ST_HOVER;
        if (U.pressed == i && U.press_ctx == 0) s |= ST_PRESSED;
    }
    if (U.focus == i && (U.popup == VEXUI_POPUP_NONE || U.popup == VEXUI_POPUP_SEARCH)) s |= ST_FOCUS;
    return s;
}
static int pitem_style(int i)
{
    int s = 0;
    if (!vexui_popup_item_enabled(i)) s |= ST_DISABLED;
    else { if (U.hover == i) s |= ST_HOVER; if (U.pressed == i && U.press_ctx == 1) s |= ST_PRESSED; }
    if (U.pfocus == i) s |= ST_FOCUS;
    return s;
}

static void button_body(Rect r, int rad, int primary, int st, GfxColor *fillout)
{
    GfxColor fill, border;
    if (st & ST_DISABLED)      { fill = gfx_rgb(0x14, 0x19, 0x2B); border = gfx_rgb(0x24, 0x2C, 0x45); }
    else if (primary)          { fill = (st & ST_PRESSED) ? gfx_rgb(0x1B, 0x55, 0xB8) : (st & ST_HOVER) ? gfx_rgb(0x5A, 0xA0, 0xFF) : gfx_rgb(0x2E, 0x7A, 0xF0);
                                 border = gfx_rgb(0x7E, 0xB6, 0xFF); }
    else                       { fill = (st & ST_PRESSED) ? gfx_rgb(0x12, 0x2B, 0x58) : (st & ST_HOVER) ? gfx_rgb(0x2C, 0x3E, 0x6C) : gfx_rgb(0x1A, 0x25, 0x45);
                                 border = gfx_rgb(0x3A, 0x4B, 0x7A); }
    int b = 1;
    if (st & ST_FOCUS) { border = C_FOCUS; b = 2; }
    rrect(r, rad, border);
    rrect(mkrect(r.x + b, r.y + b, r.w - 2 * b, r.h - 2 * b), rad > b ? rad - b : 0, fill);
    *fillout = fill;
}

/* ---- icons (primitive shapes only) ---- */
static void draw_power_icon(int32_t cx, int32_t cy, GfxColor fg, GfxColor bgc)
{
    if (!U.fb_ok) return;
    aa_disc(cx, cy + 1, 10, fg); aa_disc(cx, cy + 1, 7, bgc);
    gfx_fill_rect(U.fb, cx - 4, cy - 12, 9, 11, bgc); gfx_fill_rect(U.fb, cx - 1, cy - 11, 3, 12, fg);
}
static void draw_net_icon(int32_t cx, int32_t cy, GfxColor fg, GfxColor dot)
{
    if (!U.fb_ok) return;
    for (int i = 0; i < 4; i++) gfx_fill_rect(U.fb, cx - 12 + i * 6, cy + 9 - (4 + i * 4), 4, 4 + i * 4, fg);
    gfx_fill_rect(U.fb, cx + 9, cy - 11, 6, 6, dot);
}
static void draw_users_icon(int32_t cx, int32_t cy, GfxColor fg, GfxColor bgc)
{
    if (!U.fb_ok) return;
    aa_disc(cx, cy - 4, 6, fg); aa_disc(cx, cy + 12, 11, fg);
    gfx_fill_rect(U.fb, cx - 13, cy + 8, 27, 10, bgc);
}
static void draw_avatar(int32_t cx, int32_t cy, int32_t r)
{
    aa_disc(cx, cy, r + 4, gfx_rgb(0x2A, 0x4F, 0x9A));
    aa_disc(cx, cy, r, C_ACCENT);
    aa_disc(cx, cy, r - 5, gfx_rgb(0x16, 0x20, 0x44));
}
static char initial_of(const char *name) { char c = name && name[0] ? name[0] : '?'; return (c >= 'a' && c <= 'z') ? (char)(c - 32) : c; }
static void small_avatar(int32_t cx, int32_t cy, int32_t r, const char *name)
{
    char s[2] = { initial_of(name), 0 };
    aa_disc(cx, cy, r, gfx_rgb(0x2A, 0x4F, 0x9A)); aa_disc(cx, cy, r - 2, gfx_rgb(0x1E, 0x2C, 0x58));
    text_c(cx, cy - 8, s, 1, C_TEXT);
}
static const char *sel_name(void) { const Account *a = acct_get(acct_selected()); return a ? a->display : ""; }

static void field_text_m(Rect r, const char *buf, int len, const char *placeholder, int focused, int mask)
{
    char tmp[72];
    if (mask) { int k = len < 71 ? len : 71; for (int i = 0; i < k; i++) tmp[i] = '*'; tmp[k] = 0; buf = tmp; }
    int32_t tx = r.x + 12, ty = r.y + (r.h - 16) / 2;
    if (len == 0) { text(tx, ty, placeholder, 1, gfx_rgb(0x6A, 0x76, 0x96)); }
    else {
        int maxc = (r.w - 24) / 8 - 1; const char *s = buf;
        if (len > maxc) s = buf + (len - maxc);                          /* show the tail while typing */
        text(tx, ty, s, 1, C_TEXT);
    }
    if (focused) { int vis = len > (r.w - 24) / 8 - 1 ? (r.w - 24) / 8 - 1 : len; gfx_fill_rect(U.fb, tx + vis * 8, ty, 2, 16, C_ACCENT); }
}

static void field_text(Rect r, const char *buf, int len, const char *placeholder, int focused) { field_text_m(r, buf, len, placeholder, focused, 0); }
static void draw_icon_folder(int32_t cx, int32_t cy, GfxColor c) { gfx_fill_rect(U.fb, cx - 12, cy - 9, 11, 5, c); gfx_fill_rect(U.fb, cx - 12, cy - 5, 24, 16, c); }
static void draw_icon_bars(int32_t cx, int32_t cy, GfxColor c) { gfx_fill_rect(U.fb, cx - 11, cy + 2, 6, 9, c); gfx_fill_rect(U.fb, cx - 3, cy - 6, 6, 17, c); gfx_fill_rect(U.fb, cx + 5, cy - 1, 6, 12, c); }
/* ---- WALLPAPER-01 drawing ---------------------------------------------------------------- */
#define C_DESK_DEFAULT gfx_rgb(0x05, 0x12, 0x22)       /* == the default desktop colour returned by bg_at() */
static void wp_paint(Rect im, int idx)
{
    if (idx == 0) { gfx_fill_rect(U.fb, im.x, im.y, im.w, im.h, C_DESK_DEFAULT); return; }
    WpStatus st = wp_status(idx);
    if (st == WP_OK && wp_draw_scaled(U.fb, idx, im.x, im.y, im.w, im.h) == WP_OK) return;
    gfx_fill_rect(U.fb, im.x, im.y, im.w, im.h, gfx_rgb(0x1E, 0x10, 0x18));
    text_c(im.x + im.w / 2, im.y + im.h / 2 - 18, "!", 2, C_ERR);
    text_c(im.x + im.w / 2, im.y + im.h / 2 + 8, "Unavailable", 1, C_ERR);
}
static void wp_caption(char *dst, int cap, const char *name, int max_px)
{
    int n = 0, maxc = max_px / 8; if (maxc >= cap) maxc = cap - 1;
    for (; name[n] && n < maxc; n++) dst[n] = name[n];
    dst[n] = 0;
}
static void draw_wp_tile(Rect r, int idx, int st)
{
    int sel = (idx == U.wp_sel), app = (idx == wp_applied());
    rrect(r, 8, (st & ST_FOCUS) ? C_FOCUS : sel ? C_ACCENT : C_PANEL_BD);
    rrect(mkrect(r.x + 2, r.y + 2, r.w - 4, r.h - 4), 7, (st & ST_HOVER) ? gfx_rgb(0x16, 0x20, 0x40) : gfx_rgb(0x0B, 0x10, 0x20));
    int32_t iw = r.w - 8, ih = iw * 10 / 16; Rect im = mkrect(r.x + 4, r.y + 4, iw, ih);
    wp_paint(im, idx);
    char cap[24]; wp_caption(cap, (int)sizeof cap, wp_name(idx) ? wp_name(idx) : "?", iw);
    text_c(r.x + r.w / 2, r.y + 4 + ih + 4, cap, 1, sel ? C_TEXT : C_DIM);
    if (app) { rrect(mkrect(im.x + 6, im.y + 6, 64, 20), 5, C_ACCENT); text(im.x + 10, im.y + 8, "APPLIED", 1, C_TEXT); }
}
static void draw_ctl(int i)
{
    if (!U.fb_ok) return;
    Rect r = U.ctl[i];
    int st = ctl_style(i), kind = U.ckind[i];
    GfxColor fill;
    int off = (st & ST_PRESSED) ? 1 : 0;
    switch (kind) {
    case CK_SIGNIN: button_body(r, 10, 1, st, &fill); text_c(r.x + r.w / 2, r.y + (r.h - 16) / 2 + off, "Sign in", 1, C_TEXT); break;
    case CK_CREATE: button_body(r, 8, 1, st, &fill); text_c(r.x + r.w / 2, r.y + (r.h - 16) / 2 + off, "Create Account", 1, C_TEXT); break;
    case CK_USERS: button_body(r, 10, 0, st, &fill); draw_users_icon(r.x + r.w / 2, r.y + 18, C_TEXT, fill); text_c(r.x + r.w / 2, r.y + r.h - 20, "Users", 1, C_DIM); break;
    case CK_NET:   button_body(r, 10, 0, st, &fill); draw_net_icon(r.x + r.w / 2, r.y + 20, C_DIM, C_ERR); text_c(r.x + r.w / 2, r.y + r.h - 20, "Internet", 1, C_DIM); break;
    case CK_POWER: button_body(r, 10, 0, st, &fill); draw_power_icon(r.x + r.w / 2, r.y + 20, C_TEXT, fill); text_c(r.x + r.w / 2, r.y + r.h - 20, "Power", 1, C_DIM); break;
    case CK_VBTN:  button_body(r, 10, 0, st, &fill); text_c(r.x + r.w / 2, r.y + (r.h - 32) / 2 + off, "V", 2, C_ACCENT); break;
    case CK_TERM:  button_body(r, 10, 0, st, &fill); text_c(r.x + r.w / 2, r.y + (r.h - 16) / 2 + off, ">_", 1, C_TEXT); break;
    case CK_PASS: case CK_PASS2: {
        rrect(r, 8, (st & ST_FOCUS) ? C_FOCUS : C_PANEL_BD); rrect(mkrect(r.x + 1, r.y + 1, r.w - 2, r.h - 2), 7, gfx_rgb(0x0C, 0x11, 0x22));
        if (kind == CK_PASS) field_text_m(r, U.pass_buf, U.pass_len, "Password", st & ST_FOCUS, 1);
        else field_text_m(r, U.pass2_buf, U.pass2_len, "Confirm password", st & ST_FOCUS, 1);
        break; }
    case CK_EXPL: button_body(r, 10, 0, st, &fill); draw_icon_folder(r.x + r.w / 2, r.y + r.h / 2, gfx_rgb(0xE8, 0xB8, 0x5A)); break;
    case CK_TASK: button_body(r, 10, 0, st, &fill); draw_icon_bars(r.x + r.w / 2, r.y + r.h / 2, C_ACCENT); break;
    case CK_XUP: case CK_XHOME: case CK_XNEW: case CK_XOK: case CK_XCANCEL:
        button_body(r, 8, kind == CK_XOK, st, &fill);
        text_c(r.x + r.w / 2, r.y + (r.h - 16) / 2, kind == CK_XUP ? "Up" : kind == CK_XHOME ? "Home" : kind == CK_XNEW ? "New File" : kind == CK_XOK ? xok_label() : "Cancel", 1, C_TEXT); break;
    case CK_XROW: {
        int e = U.xlist[U.xscroll + (i - 4)]; const VfsNode *n = vfs_node(e);
        GfxColor rf = (st & ST_HOVER) ? gfx_rgb(0x1E, 0x2B, 0x4C) : ((U.xscroll + (i - 4)) == U.xsel ? gfx_rgb(0x18, 0x24, 0x44) : gfx_rgb(0x0B, 0x10, 0x20));
        rrect(r, 5, rf); if (st & ST_FOCUS) { rrect(r, 5, C_FOCUS); rrect(mkrect(r.x + 1, r.y + 1, r.w - 2, r.h - 2), 4, rf); }
        if (n) { text(r.x + 10, r.y + 4, n->is_dir ? "[D]" : "[F]", 1, n->is_dir ? gfx_rgb(0xE8, 0xB8, 0x5A) : C_DIM); text(r.x + 46, r.y + 4, n->name, 1, C_TEXT);
                 Sb m = {{0}, 0}; sb_s(&m, n->is_dir ? "folder" : "0 bytes"); sb_s(&m, "   uid "); sb_u(&m, n->owner_uid); text(r.x + r.w - 150, r.y + 4, m.b, 1, C_DIM); }
        break; }
    case CK_TMIN: button_body(r, 6, 0, st, &fill); text_c(r.x + r.w / 2, r.y + (r.h - 16) / 2, "-", 1, C_TEXT); break;
    case CK_VALB: button_body(r, 10, 0, st, &fill); rrect(mkrect(r.x + 14, r.y + 9, 16, 26), 3, C_TEXT); for (int q = 0; q < 4; q++) gfx_fill_rect(U.fb, r.x + 17, r.y + 14 + q * 5, 10, 2, gfx_rgb(0x40, 0x50, 0x80)); break;
    case CK_SETT: button_body(r, 10, 0, st, &fill); aa_disc(r.x + r.w / 2, r.y + r.h / 2, 11, C_DIM); aa_disc(r.x + r.w / 2, r.y + r.h / 2, 5, fill); break;
    case CK_XSORT: { static const char *const sl[] = { "Sort: Name A-Z", "Sort: Name Z-A", "Sort: Type", "Sort: Size", "Sort: Modified" };
        button_body(r, 8, 0, st, &fill); text_c(r.x + r.w / 2, r.y + (r.h - 16) / 2, sl[U.xsort % 5], 1, C_TEXT); break; }
    case CK_VBNEW: case CK_VBOPEN: case CK_VBSAVE: case CK_VBDISCARD:
        button_body(r, 8, 0, st, &fill); text_c(r.x + r.w / 2, r.y + (r.h - 16) / 2, kind == CK_VBNEW ? "New" : kind == CK_VBOPEN ? "Open" : kind == CK_VBSAVE ? "Save" : "Discard", 1, C_TEXT); break;
    case CK_SROW: { static const char *const sn[] = { "System", "Display", "Personalization", "Sound", "Users and Accounts", "Wallpaper", "About VEX OS" };
        int k = i - 1; GfxColor rf = (k == U.spage) ? gfx_rgb(0x1E, 0x34, 0x66) : (st & ST_HOVER) ? gfx_rgb(0x16, 0x20, 0x40) : gfx_rgb(0x0B, 0x10, 0x20);
        rrect(r, 6, rf); if (k == U.spage) gfx_fill_rect(U.fb, r.x, r.y + 6, 3, r.h - 12, C_ACCENT); if (st & ST_FOCUS) { rrect(r, 6, C_FOCUS); rrect(mkrect(r.x + 1, r.y + 1, r.w - 2, r.h - 2), 5, rf); }
        text(r.x + 16, r.y + 8, sn[k], 1, C_TEXT); break; }
    case CK_SSWATCH: { static const uint8_t pal[6][3] = { {0x3A,0x8C,0xFF}, {0x8E,0x5C,0xF0}, {0x4C,0xC7,0x5A}, {0xF0,0xA0,0x30}, {0xF0,0x5A,0x6E}, {0x7A,0x8A,0xA8} };
        int k = 0; for (int q = 0; q < i; q++) if (U.ckind[q] == CK_SSWATCH) k++;
        GfxColor c = gfx_rgb(pal[k][0], pal[k][1], pal[k][2]); int sel = (U.accent.r == c.r && U.accent.g == c.g && U.accent.b == c.b);
        rrect(r, 8, sel || (st & ST_FOCUS) ? C_TEXT : C_PANEL_BD); rrect(mkrect(r.x + 2, r.y + 2, r.w - 4, r.h - 4), 7, c); break; }
    case CK_WPTILE: { int k = 0; for (int q = 0; q < i; q++) if (U.ckind[q] == CK_WPTILE) k++; draw_wp_tile(r, k, st); break; }
    case CK_WPAPPLY: { int same = (U.wp_sel == wp_applied()); button_body(r, 8, !same, st, &fill);
        text_c(r.x + r.w / 2, r.y + (r.h - 16) / 2, same ? "Applied" : "Apply wallpaper", 1, same ? C_DIM : C_TEXT); break; }
    case CK_WPRESET: button_body(r, 8, 0, st, &fill); text_c(r.x + r.w / 2, r.y + (r.h - 16) / 2, "Reset to default", 1, C_TEXT); break;
    case CK_SBTN: button_body(r, 8, 1, st, &fill); text_c(r.x + r.w / 2, r.y + (r.h - 16) / 2, U.spage == 3 ? "Play test tone" : "Add user", 1, C_TEXT); break;
    case CK_TCLOSE: button_body(r, 6, 0, st, &fill); text_c(r.x + r.w / 2, r.y + (r.h - 16) / 2, "X", 1, C_TEXT); break;
    case CK_NAME: case CK_SEARCH: {
        rrect(r, 8, (st & ST_FOCUS) ? C_FOCUS : C_PANEL_BD); rrect(mkrect(r.x + 1, r.y + 1, r.w - 2, r.h - 2), 7, gfx_rgb(0x0C, 0x11, 0x22));
        if (kind == CK_NAME) field_text(r, U.name_buf, U.name_len, "Account name", st & ST_FOCUS);
        else if (U.popup == VEXUI_POPUP_VMENU) field_text(mkrect(r.x + 18, r.y, r.w - 18, r.h), "", 0, "Search anything...", 0);   /* the V menu has its OWN search box; never mirror it here */
        else field_text(mkrect(r.x + 18, r.y, r.w - 18, r.h), U.search_buf, U.search_len, "Search anything...", st & ST_FOCUS);
        if (kind == CK_SEARCH) { aa_disc(r.x + 15, r.y + 17, 5, C_DIM); aa_disc(r.x + 15, r.y + 17, 3, gfx_rgb(0x0C, 0x11, 0x22)); }
        break; }
    default: break;
    }
    if (kind == CK_TERM || kind == CK_EXPL || kind == CK_TASK || kind == CK_VALB || kind == CK_SETT) {     /* taskbar: running indicator */
        uint32_t id = kind == CK_TERM ? APP_ID_TERMINAL : kind == CK_EXPL ? APP_ID_EXPLORER : kind == CK_TASK ? APP_ID_TASKMGR : kind == CK_VALB ? APP_ID_VALBOOK : APP_ID_SETTINGS;
        if (apps_running(id)) gfx_fill_rect(U.fb, r.x + 12, r.y + r.h - 4, r.w - 24, 3, (is_app_screen(U.screen) && app_of_screen(U.screen) == id) ? C_ACCENT : C_DIM);
    }
    U.drawn_ctl[i] = st;
}

static const char *ctx_label(int c) { static const char *const l[] = { "", "Open", "Edit (Valbook)", "Rename", "Delete", "New File", "New Folder", "New Vex Code File", "Refresh" }; return (c >= 1 && c <= 8) ? l[c] : ""; }
static void draw_pitem(int i)
{
    if (!U.fb_ok) return;
    Rect r = U.pitem[i];
    if (r.w <= 0) { U.drawn_pitem[i] = pitem_style(i); return; }
    int st = pitem_style(i); GfxColor fill;
    button_body(r, 8, 0, st, &fill);
    GfxColor tc = (st & ST_DISABLED) ? gfx_rgb(0x5A, 0x65, 0x82) : C_TEXT;
    int32_t ty = r.y + (r.h - 16) / 2 + ((st & ST_PRESSED) ? 1 : 0);
    if (U.popup == VEXUI_POPUP_USERS && i < acct_count()) {
        const Account *a = acct_get(i); int cur = (i == acct_selected());
        small_avatar(r.x + 26, r.y + r.h / 2, 16, a->display);
        text(r.x + 52, r.y + 9, a->display, 1, C_TEXT);
        text(r.x + 52, r.y + 26, cur ? "Current account" : "Select account", 1, cur ? C_ACCENT : C_DIM);
        if (cur) text(r.x + r.w - 28, ty, "OK", 1, C_ACCENT);
    } else if (U.popup == VEXUI_POPUP_USERS || U.popup == VEXUI_POPUP_NET) {
        text_c(r.x + r.w / 2, ty, "Close", 1, tc);
    } else if (U.popup == VEXUI_POPUP_POWER) {
        text_c(r.x + r.w / 2, ty, i == VEXUI_PWR_SHUTDOWN ? "Shut down" : i == VEXUI_PWR_REBOOT ? "Restart" : "Cancel", 1, tc);
    } else if (U.popup == VEXUI_POPUP_CTX) {
        text(r.x + 12, ty, ctx_label(U.ctx_code[i]), 1, tc);
    } else if (i < U.na) {
        text(r.x + 14, ty, ">_", 1, C_ACCENT); text(r.x + 46, ty, apps_registry_get(U.app_hit[i])->name, 1, tc);
    } else {
        int k = i - U.na; text(r.x + 14, ty, k == 0 ? "Lock" : k == 1 ? "Shut down" : k == 2 ? "Restart" : "Add user (admin)", 1, tc);
    }
    U.drawn_pitem[i] = st;
}

static void draw_popup(void)
{
    if (!U.fb_ok || U.popup == VEXUI_POPUP_NONE) return;
    rrect(mkrect(U.pop.x - 1, U.pop.y - 1, U.pop.w + 2, U.pop.h + 2), 12, C_PANEL_BD);
    rrect(U.pop, 11, C_PANEL);
    int32_t x = U.pop.x + 16;
    if (U.popup == VEXUI_POPUP_POWER) {
        text(x, U.pop.y + 14, "Power", 1, C_ACCENT);
        for (int i = 0; i < 3; i++) draw_pitem(i);
        int32_t fy = U.pitem[2].y + U.pitem[2].h + 6;
        text(x, fy, U.can_shutdown ? "ACPI S5 soft-off available" : "Shut down unavailable: no ACPI S5", 1, U.can_shutdown ? C_DIM : C_WARN);
        text(x, fy + 16, U.can_reboot ? "Restart via platform reset" : "Restart unavailable: no reset method", 1, U.can_reboot ? C_DIM : C_WARN);
    } else if (U.popup == VEXUI_POPUP_NET) {
        const NetStatus *n = netstatus_get(); int32_t y = U.pop.y + 12;
        text(x, y, "Internet / Ethernet", 1, C_ACCENT); y += 26;
        text(x, y, "Network unavailable", 1, C_WARN); y += 18;
        text(x, y, "No usable network driver installed.", 1, C_TEXT); y += 18;
        text(x, y, "No connection, IP address or Wi-Fi exists.", 1, C_DIM); y += 18;
        text(x, y, "Nothing here can be enabled or disabled.", 1, C_DIM); y += 18;
        Sb s = {{0}, 0};
        if (n->adapter_found) { sb_s(&s, "Adapter: "); if (n->adapter_name) sb_s(&s, n->adapter_name); else sb_s(&s, "PCI (unknown model)"); sb_s(&s, " - no driver"); }
        else sb_s(&s, "Adapter: none found on the PCI bus");
        text(x, y, s.b, 1, C_DIM);
        draw_pitem(0);
    } else if (U.popup == VEXUI_POPUP_USERS) {
        text(x, U.pop.y + 12, "Switch user", 1, C_TEXT);
        text(x, U.pop.y + 32, "Choose an account to continue.", 1, C_DIM);
        for (int i = 0; i <= acct_count(); i++) draw_pitem(i);
        if (acct_count() > USERS_VISIBLE) { Sb s = {{0}, 0}; sb_u(&s, (uint64_t)U.pscroll + 1); sb_s(&s, "-"); sb_u(&s, (uint64_t)imin(acct_count(), U.pscroll + USERS_VISIBLE)); sb_s(&s, " of "); sb_u(&s, (uint64_t)acct_count()); text(x, U.pitem[acct_count()].y + 9, s.b, 1, C_DIM); }
    } else if (U.popup == VEXUI_POPUP_VMENU) {
        Rect sf = mkrect(U.pop.x + 12, U.pop.y + 12, U.pop.w - 24, 36);
        rrect(sf, 8, C_PANEL_BD); rrect(mkrect(sf.x + 1, sf.y + 1, sf.w - 2, sf.h - 2), 7, gfx_rgb(0x0C, 0x11, 0x22));
        field_text(sf, U.search_buf, U.search_len, "Search apps...", 1);
        text(x, U.pop.y + 12 + 36 + 12, U.search_len ? "Results" : "Pinned Apps", 1, C_DIM);
        if (U.na == 0) text(x, U.pop.y + 12 + 36 + 12 + 16 + 14, "No matching apps", 1, C_WARN);
        for (int i = 0; i < pitem_count(); i++) draw_pitem(i);
    } else {
        if (U.popup != VEXUI_POPUP_CTX && U.na == 0) text(U.pop.x + 16, U.pop.y + 20, "No matching apps", 1, C_WARN);
        for (int i = 0; i < pitem_count(); i++) draw_pitem(i);
    }
}

/* ---- dynamic: clocks + terminal content ---- */
static const char *const MONTHS[12] = { "January","February","March","April","May","June","July","August","September","October","November","December" };
static const char *const WDAYS[7]   = { "Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday" };

static void draw_lock_clock(void)
{
    if (!U.fb_ok) return;
    bg_rect(U.clock_r);
    RtcTime t;
    if (!tz_local_now(&t)) return;                   /* RTC invalid: omit the clock entirely */
    int cs = U.compact ? 3 : (U.sw >= 1000 ? 6 : 4);
    Sb s = {{0}, 0}; sb_pad(&s, t.hour, 2); sb_s(&s, ":"); sb_pad(&s, t.minute, 2);
    int32_t y = U.clock_r.y + 4;
    text_c(U.sw / 2, y, s.b, cs, C_TEXT); y += 16 * cs + 8;
    Sb d = {{0}, 0};
    sb_s(&d, WDAYS[rtc_weekday(t.year, t.month, t.day)]); sb_s(&d, ", "); sb_u(&d, t.day); sb_s(&d, " "); sb_s(&d, MONTHS[t.month - 1]); sb_s(&d, " ("); sb_s(&d, VEX_TZ_NAME); sb_s(&d, ")");
    text_c(U.sw / 2, y, d.b, U.compact ? 1 : 2, C_TEXT);
}
static void draw_desktop_clock(void)
{
    if (!U.fb_ok) return;
    bg_rect(U.clock_r);
    RtcTime t;
    /* text sits directly on the wallpaper here (everywhere else it sits on an opaque panel), so on a light wallpaper use dark ink */
    int light = wp_region_is_light(U.clock_r.x, U.clock_r.y, U.clock_r.w, U.clock_r.h, U.fb);
    GfxColor ink = light ? gfx_rgb(0x0B, 0x1A, 0x36) : C_TEXT, ink2 = light ? gfx_rgb(0x2E, 0x3E, 0x62) : C_DIM;
    /* weather placeholder: small cloud + "No data". No temperature/condition is ever invented. */
    int32_t wx = U.sw - 12 - 28, wy = 8;                 /* right-aligned block: cloud above, "No data" below */
    aa_disc(wx + 6, wy + 12, 6, ink2); aa_disc(wx + 15, wy + 9, 7, ink2); gfx_fill_rect(U.fb, wx + 4, wy + 12, 18, 6, ink2);
    text(U.sw - 12 - 7 * 8, wy + 28, "No data", 1, ink2);
    if (tz_local_now(&t)) {
        Sb s = {{0}, 0}; sb_pad(&s, t.hour, 2); sb_s(&s, ":"); sb_pad(&s, t.minute, 2);
        text(U.sw - 168, 10, s.b, 2, ink);
        text(U.sw - 168 + 30, 44, VEX_TZ_NAME, 1, ink2);
    } else text(U.sw - 168, 14, "--:--", 2, ink2);
}
static void draw_terminal_prompt(void);
static void draw_terminal_content(void)
{
    if (!U.fb_ok) return;
    if (!U.quiet) serial_puts("[gfx] terminal content redraw (all rows + prompt)\n");
    Rect c = mkrect(U.card.x + 8, U.card.y + 44, U.card.w - 16, U.card.h - 44 - 52);
    GfxColor bgc = gfx_rgb(0x07, 0x0A, 0x14);
    gfx_fill_rect(U.fb, c.x, c.y, c.w, c.h, bgc);
    int rows = c.h / 16; const char *ls[64]; if (rows > 64) rows = 64;
    int n = vth_visible(rows, ls);
    int cols = c.w / 8 - 2;
    for (int i = 0; i < n; i++) { if (ls[i][0]) { char tmp[VTH_COLS + 1]; int k = 0; for (; ls[i][k] && k < cols && k < VTH_COLS; k++) tmp[k] = ls[i][k]; tmp[k] = 0; gfx_draw_str(U.fb, c.x + 8, c.y + 4 + i * 16, tmp, C_TEXT, bgc); } }
    draw_terminal_prompt();
}
static void draw_terminal_prompt(void)
{
    if (!U.fb_ok) return;
    GfxColor bgc = gfx_rgb(0x07, 0x0A, 0x14);
    Rect pr = mkrect(U.card.x + 8, U.card.y + U.card.h - 48, U.card.w - 16, 40);
    rrect(pr, 8, C_PANEL_BD); rrect(mkrect(pr.x + 1, pr.y + 1, pr.w - 2, pr.h - 2), 7, bgc);
    const char *lab = vth_prompt_label(), *txt = vth_prompt_text();
    if (lab[0]) {
        int32_t tx = pr.x + 12, ty = pr.y + 12; text(tx, ty, lab, 1, C_ACCENT);
        int lw = slen(lab) * 8, tl = slen(txt), maxc = (pr.w - 24) / 8 - slen(lab) - 2;
        const char *shown = tl > maxc ? txt + (tl - maxc) : txt; text(tx + lw, ty, shown, 1, C_TEXT);
        gfx_fill_rect(U.fb, tx + lw + slen(shown) * 8, ty, 2, 16, C_ACCENT);
    } else text(pr.x + 12, pr.y + 12, "Esc: back to terminal", 1, C_DIM);
}

/* ---- screens ---- */
static void draw_setup_msg(void)
{
    if (!U.fb_ok) return;
    int32_t y = U.ctl[1].y + U.ctl[1].h + 8, cx = U.card.x + U.card.w / 2;
    gfx_fill_rect(U.fb, U.card.x + 10, y, U.card.w - 20, 20, C_PANEL);
    if (U.setup_msg[0]) text_c(cx, y + 2, U.setup_msg, 1, C_ERR); else text_c(cx, y + 2, "Name 3-32 chars. Password 6-64 chars.", 1, C_DIM);
}
static void draw_setup_static(void)
{
    rrect(mkrect(U.card.x - 1, U.card.y - 1, U.card.w + 2, U.card.h + 2), 14, C_PANEL_BD); rrect(U.card, 13, C_PANEL);
    int32_t cx = U.card.x + U.card.w / 2, y = U.card.y + 22;
    text_c(cx, y, "VEX OS", 3, C_ACCENT); y += 64;
    if (U.add_mode) { text_c(cx, y, "Add a new user", 1, C_TEXT); y += 20; text_c(cx, y, "Only administrators can add users. Esc cancels.", 1, C_DIM); y += 28; }
    else { text_c(cx, y, "No account detected.", 1, C_TEXT); y += 20; text_c(cx, y, "Please create an account.", 1, C_TEXT); y += 28; }
    text_c(cx, y, "Accounts are temporary: not saved across reboots.", 1, C_WARN);
    draw_setup_msg();
}
static void draw_auth_msg(void)
{
    if (!U.fb_ok) return;
    int32_t y = U.ctl[0].y + U.ctl[0].h + 34;
    bg_rect(mkrect(U.sw / 2 - 220, y, 440, 20));                  /* below the horizon: plain water gradient, no scenery here */
    if (U.auth_msg[0]) text_c(U.sw / 2, y + 2, U.auth_msg, 1, C_ERR);
}
static void draw_scenery(void)
{
    int32_t w = U.sw, hz = U.sh * 62 / 100;
    for (int layer = 0; layer < 2; layer++) {
        GfxColor col = layer == 0 ? gfx_rgb(0x2A, 0x4A, 0x80) : gfx_rgb(0x10, 0x28, 0x52);
        int32_t amp = layer == 0 ? U.sh / 7 : U.sh / 12, per = layer == 0 ? 170 : 90;
        for (int32_t x = 0; x < w; x += 2) {
            int32_t t = (x + layer * 77) % (per * 2); t = t < per ? t : per * 2 - t;
            int32_t t2 = (x * 3 + layer * 31) % 97; t2 = t2 < 48 ? t2 : 97 - t2;
            int32_t hgt = amp / 3 + amp * t / per * 2 / 3 + t2 / 3;
            gfx_fill_rect(U.fb, x, hz - hgt, 2, hgt, col);
        }
    }
}
static void draw_lock_static(void)
{
    int32_t w = U.sw, h = U.sh; int c = U.compact;
    if (U.fb_ok) draw_scenery();
    text(c ? 12 : 24, c ? 10 : 22, "VEX OS", c ? 1 : 2, C_TEXT);
    int32_t r = c ? 28 : 46, cy = c ? h * 44 / 100 : h * 47 / 100 - 10;
    draw_avatar(w / 2, cy, r);
    char s[2] = { initial_of(sel_name()), 0 };
    text_c(w / 2, cy - 8 * (c ? 2 : 3), s, c ? 2 : 3, C_TEXT);
    text_c(w / 2, cy + r + 14, sel_name(), c ? 1 : 2, C_TEXT);
    text_c(w / 2, cy + r + 14 + (c ? 20 : 34), "Your session awaits", 1, C_DIM);
    text_c(w / 2, U.ctl[0].y + U.ctl[0].h + 14, "Press Enter to sign in", 1, C_TEXT);
    draw_auth_msg();
    draw_lock_clock();
}
static void draw_desktop_static(void)
{
    int32_t tb = 56;
    gfx_fill_rect(U.fb, 0, U.sh - tb, U.sw, tb, gfx_rgb(0x06, 0x1B, 0x30));
    gfx_fill_rect(U.fb, 0, U.sh - tb, U.sw, 1, C_PANEL_BD);
    Sb s = {{0}, 0}; sb_s(&s, "Signed in as "); sb_s(&s, U.session_user >= 0 && acct_get(U.session_user) ? acct_get(U.session_user)->display : "?");
    text(U.sw - 12 - text_w(s.b, 1), U.sh - tb + 20, s.b, 1, C_DIM);
    text(14, U.sh - tb + 20, "ZEN HORIZON", 1, C_ACCENT);
    draw_desktop_clock();
}
static void draw_terminal_static(void)
{
    rrect(mkrect(U.card.x - 1, U.card.y - 1, U.card.w + 2, U.card.h + 2), 12, C_PANEL_BD); rrect(U.card, 11, gfx_rgb(0x0B, 0x10, 0x20));
    text(U.card.x + 16, U.card.y + 14, ">_  Verminal", 1, C_TEXT);
    draw_terminal_content();
}
static void draw_frame(const char *title)
{
    rrect(mkrect(U.card.x - 1, U.card.y - 1, U.card.w + 2, U.card.h + 2), 12, C_PANEL_BD); rrect(U.card, 11, gfx_rgb(0x0B, 0x10, 0x20));
    text(U.card.x + 16, U.card.y + 14, title, 1, C_TEXT);
}
static void draw_xmsg(void)
{
    if (!U.fb_ok) return;
    gfx_fill_rect(U.fb, U.card.x + 8, U.card.y + U.card.h - 50, U.card.w - 16, 22, gfx_rgb(0x0B, 0x10, 0x20));
    if (U.xmsg[0]) text(U.card.x + 16, U.card.y + U.card.h - 46, U.xmsg, 1, (U.xmsg[0] == 'C' || U.xmsg[0] == 'R' || U.xmsg[0] == 'D') ? C_OK : C_ERR);
}
static void draw_xdlg_field(void)
{
    if (!U.fb_ok || !U.xdlg || U.xmode == 5) return;
    Rect d = mkrect(U.card.x + U.card.w / 2 - 190, U.card.y + 150, 380, 150);
    Rect f = mkrect(d.x + 16, d.y + 40, d.w - 32, 36); rrect(f, 8, C_FOCUS); rrect(mkrect(f.x + 1, f.y + 1, f.w - 2, f.h - 2), 7, gfx_rgb(0x0C, 0x11, 0x22));
    field_text(f, U.xname_buf, U.xname_len, "file name", 1);
}
static void draw_explorer_static(void)
{
    draw_frame("File Explorer");
    char path[96]; if (vfs_path(U.xdir, path, sizeof path) < 0) { path[0] = '?'; path[1] = 0; }
    Sb s = {{0}, 0}; sb_s(&s, "Location: "); sb_s(&s, path);
    text(U.card.x + 16, U.card.y + 44 + 42, s.b, 1, C_ACCENT);
    if (!U.xdlg && U.xn == 0) text(U.card.x + 26, U.card.y + 44 + 80 + 4, "(empty folder)", 1, C_DIM);
    text(U.card.x + 16, U.card.y + U.card.h - 24, "RAM filesystem: volatile, empty again after reboot. Files have no content (0 bytes).", 1, C_DIM);
    draw_xmsg();
    if (U.xdlg) {
        Rect d = mkrect(U.card.x + U.card.w / 2 - 190, U.card.y + 150, 380, 150);
        rrect(mkrect(d.x - 1, d.y - 1, d.w + 2, d.h + 2), 12, C_ACCENT); rrect(d, 11, C_PANEL);
        { static const char *const dt[] = { "", "New file - enter a name", "New folder - enter a name", "New Vex Code file - name (.vex added)", "Rename - enter the new name", "Delete?" };
          text(d.x + 16, d.y + 14, dt[U.xmode % 6], 1, U.xmode == 5 ? C_WARN : C_TEXT);
          if (U.xmode == 5) { const VfsNode *tn = vfs_node(U.xtarget); Sb q = {{0}, 0}; sb_s(&q, "Delete \""); sb_s(&q, tn ? tn->name : "?"); sb_s(&q, "\"?"); text(d.x + 16, d.y + 50, q.b, 1, C_TEXT); text(d.x + 16, d.y + 74, "This cannot be undone.", 1, C_DIM); } }
        draw_xdlg_field();
    }
}
static void draw_taskmgr_content(void)
{
    if (!U.fb_ok) return;
    Rect c = mkrect(U.card.x + 8, U.card.y + 40, U.card.w - 16, U.card.h - 48);
    gfx_fill_rect(U.fb, c.x, c.y, c.w, c.h, gfx_rgb(0x0B, 0x10, 0x20));
    int32_t x = c.x + 16, y = c.y + 10; Sb s = {{0}, 0};
    text(x, y, "CPU (boot processor)", 2, C_TEXT); y += 36;
    if (U.cpu_pm < 0) text(x, y, "measuring... (needs two samples, 1 s apart)", 1, C_WARN);
    else { sb_u(&s, (uint64_t)U.cpu_pm / 10); sb_s(&s, "."); sb_u(&s, (uint64_t)U.cpu_pm % 10); sb_s(&s, " % busy"); text(x, y, s.b, 2, C_ACCENT);
           gfx_fill_rect(U.fb, x + 220, y + 2, 300, 18, gfx_rgb(0x1A, 0x25, 0x45)); gfx_fill_rect(U.fb, x + 220, y + 2, 300 * U.cpu_pm / 1000, 18, C_ACCENT); }
    y += 36; text(x, y, "100% = the boot CPU never halted since the last sample (1 s window).", 1, C_DIM); y += 18;
    Sb o = {{0}, 0}; sb_s(&o, "CPUs online: "); sb_u(&o, U.facts.cpu_count ? U.facts.cpu_count : 1); sb_s(&o, "  (only the boot CPU is accounted; the others are parked, running no work)"); text(x, y, o.b, 1, C_DIM);
    y += 40; text(x, y, "Memory", 2, C_TEXT); y += 36;
    uint64_t fr = 4096, tot = pmm_usable_frames() * fr, used = pmm_allocated_frames() * fr, fre = pmm_free_frames() * fr;
    Sb a = {{0}, 0}; sb_s(&a, "Usable physical memory: "); sb_u(&a, tot / 1048576); sb_s(&a, " MiB (");  sb_u(&a, tot / 1024); sb_s(&a, " KiB)"); text(x, y, a.b, 1, C_TEXT); y += 20;
    Sb b = {{0}, 0}; sb_s(&b, "Allocated (PMM frames): "); sb_u(&b, used / 1024); sb_s(&b, " KiB"); text(x, y, b.b, 1, C_TEXT); y += 20;
    Sb d = {{0}, 0}; sb_s(&d, "Free: "); sb_u(&d, fre / 1048576); sb_s(&d, " MiB (");  sb_u(&d, fre / 1024); sb_s(&d, " KiB)"); text(x, y, d.b, 1, C_TEXT); y += 20;
    Sb e = {{0}, 0}; sb_s(&e, "Kernel image (static): "); sb_u(&e, U.img_b / 1024); sb_s(&e, " KiB   Framebuffer: "); sb_u(&e, U.fb_b / 1024); sb_s(&e, " KiB"); text(x, y, e.b, 1, C_TEXT); y += 20;
    text(x, y, "Counts PMM frames only; excludes firmware memory and page tables outside the PMM.", 1, C_DIM); y += 34;
    text(x, y, "Applications tracked by the desktop shell", 1, C_ACCENT); y += 22;
    uint64_t now = apps_now_ms();
    for (int i = 0; i < apps_tracked_count() && i < 8; i++) { const AppInst *ai = apps_tracked_get(i); Sb r = {{0}, 0};
        sb_u(&r, ai->inst_id); sb_s(&r, "   "); sb_s(&r, ai->name); sb_s(&r, "   "); sb_s(&r, ai->kind); sb_s(&r, "   up "); sb_u(&r, (now - ai->started_ms) / 1000); sb_s(&r, " s"); text(x, y, r.b, 1, C_TEXT); y += 18; }
    Sb u = {{0}, 0}; sb_s(&u, "Uptime: "); sb_u(&u, now / 1000); sb_s(&u, " s   (refreshes every second)"); text(x, c.y + c.h - 24, u.b, 1, C_DIM);
}
static void draw_taskmgr_static(void) { draw_frame("Task Manager"); draw_taskmgr_content(); }
static void draw_taskbar_bg(void)
{
    if (!U.fb_ok) return;
    gfx_fill_rect(U.fb, 0, U.sh - 56, U.sw, 56, gfx_rgb(0x06, 0x1B, 0x30)); gfx_fill_rect(U.fb, 0, U.sh - 56, U.sw, 1, C_PANEL_BD);
}
static void draw_vb_title(void)
{
    if (!U.fb_ok) return;
    gfx_fill_rect(U.fb, U.card.x + 8, U.card.y + 8, U.card.w - 130, 26, gfx_rgb(0x0B, 0x10, 0x20));
    Sb t = {{0}, 0}; sb_s(&t, "Valbook - "); const VfsNode *n = U.vb_node >= 0 ? vfs_node(U.vb_node) : 0; sb_s(&t, n ? n->name : "Untitled"); if (U.vb_modified) sb_s(&t, " *");
    text(U.card.x + 16, U.card.y + 14, t.b, 1, C_TEXT);
}
static void draw_vb_status(void)
{
    if (!U.fb_ok) return;
    Rect st = mkrect(U.card.x + 8, U.card.y + U.card.h - 32, U.card.w - 16, 24); gfx_fill_rect(U.fb, st.x, st.y, st.w, st.h, gfx_rgb(0x0B, 0x10, 0x20));
    int cl, cc; vb_pos(&cl, &cc); Sb s2 = {{0}, 0}; sb_s(&s2, "Ln "); sb_u(&s2, (uint64_t)cl + 1); sb_s(&s2, ", Col "); sb_u(&s2, (uint64_t)cc + 1);
    sb_s(&s2, U.vb_modified ? "   Modified" : "   Saved/unchanged"); sb_s(&s2, "   "); sb_u(&s2, (uint64_t)U.vb_len); sb_s(&s2, "/2047 bytes");
    text(st.x + 8, st.y + 4, s2.b, 1, C_DIM);
    if (U.vb_msg[0]) text(st.x + 360, st.y + 4, U.vb_msg, 1, (U.vb_msg[0] == 'S' && U.vb_msg[1] == 'a') ? C_OK : C_ERR);
}
static void draw_vb_lines(int l0, int l1)
{
    if (!U.fb_ok) return;
    Rect a = vb_area(); int R = a.h / 16, C = (a.w - 16) / 8, cl, cc, nl = vb_nlines(); GfxColor bgc = gfx_rgb(0x0A, 0x0E, 0x1A); vb_pos(&cl, &cc);
    for (int row = 0; row < R; row++) {
        int line = U.vb_scroll + row; if (line < l0 || line > l1) continue;
        int32_t y = a.y + row * 16; gfx_fill_rect(U.fb, a.x, y, a.w, 16, bgc);
        if (line < nl) { int st = vb_line_start(line), k = 0; char tmp[136]; for (int i = st; i < U.vb_len && U.vb_buf[i] != '\n' && k < C && k < 134; i++) tmp[k++] = U.vb_buf[i]; tmp[k] = 0; text(a.x + 8, y, tmp, 1, C_TEXT); }
        if (line == cl && cc < C) gfx_fill_rect(U.fb, a.x + 8 + cc * 8, y, 2, 16, C_ACCENT);
    }
}
static void draw_vb_dlg_field(void)
{
    if (!U.fb_ok || U.vb_dlg < 1 || U.vb_dlg > 2) return;
    Rect d = mkrect(U.card.x + U.card.w / 2 - 190, U.card.y + 150, 380, 150), f = mkrect(d.x + 16, d.y + 40, d.w - 32, 36);
    rrect(f, 8, C_FOCUS); rrect(mkrect(f.x + 1, f.y + 1, f.w - 2, f.h - 2), 7, gfx_rgb(0x0C, 0x11, 0x22)); field_text(f, U.vb_name, U.vb_name_len, U.vb_dlg == 1 ? "file name" : "/home/name/file.txt", 1);
}
static void draw_valbook_static(void)
{
    draw_frame(""); draw_vb_title();
    Rect a = vb_area(); rrect(mkrect(a.x - 1, a.y - 1, a.w + 2, a.h + 2), 6, C_PANEL_BD); gfx_fill_rect(U.fb, a.x, a.y, a.w, a.h, gfx_rgb(0x0A, 0x0E, 0x1A));
    draw_vb_lines(0, 1 << 20); draw_vb_status();
    if (U.vb_dlg) {
        Rect d = mkrect(U.card.x + U.card.w / 2 - 190, U.card.y + 150, 380, 150);
        rrect(mkrect(d.x - 1, d.y - 1, d.w + 2, d.h + 2), 12, C_ACCENT); rrect(d, 11, C_PANEL);
        if (U.vb_dlg == 3) { const VfsNode *n = U.vb_node >= 0 ? vfs_node(U.vb_node) : 0; Sb q = {{0}, 0}; sb_s(&q, "Save changes to "); sb_s(&q, n ? n->name : "Untitled"); sb_s(&q, "?");
            text(d.x + 16, d.y + 14, "Unsaved changes", 1, C_WARN); text(d.x + 16, d.y + 50, q.b, 1, C_TEXT); text(d.x + 16, d.y + 74, "Your edits will be lost if you discard.", 1, C_DIM); }
        else { text(d.x + 16, d.y + 14, U.vb_dlg == 1 ? "Save as - file name (in your home folder)" : "Open - full path", 1, C_TEXT); draw_vb_dlg_field(); }
    }
}
static void draw_settings_static(void)
{
    draw_frame("Settings");
    Rect pane = mkrect(U.card.x + 244, U.card.y + 44, U.card.w - 260, U.card.h - 60); gfx_fill_rect(U.fb, U.card.x + 236, U.card.y + 44, 1, U.card.h - 60, C_PANEL_BD);
    int32_t x = pane.x + 16, y = pane.y + 8; Sb s2 = {{0}, 0}; uint64_t img, fb; memreport_get(&img, &fb);
    static const char *const ttl[] = { "System", "Display", "Personalization", "Sound", "Users and Accounts", "Wallpaper", "About VEX OS" };
    text(x, y, ttl[U.spage % 7], 2, C_TEXT); y += 44;
    switch (U.spage) {
    case 0: sb_s(&s2, "Uptime: "); sb_u(&s2, apps_now_ms() / 1000); sb_s(&s2, " s"); text(x, y, s2.b, 1, C_TEXT); y += 22;
        { Sb a = {{0}, 0}; sb_s(&a, "CPUs online: "); sb_u(&a, U.facts.cpu_count ? U.facts.cpu_count : 1); text(x, y, a.b, 1, C_TEXT); y += 22; }
        { Sb b = {{0}, 0}; sb_s(&b, "Memory: "); sb_u(&b, pmm_usable_frames() * 4 / 1024); sb_s(&b, " MiB usable, "); sb_u(&b, pmm_allocated_frames() * 4); sb_s(&b, " KiB allocated"); text(x, y, b.b, 1, C_TEXT); y += 22; }
        text(x, y, "Time zone: India Standard Time (UTC+05:30), fixed", 1, C_TEXT); y += 22;
        text(x, y, "Filesystem: RAM only (volatile). Settings, accounts and files reset on reboot.", 1, C_WARN); break;
    case 1: sb_s(&s2, "Resolution: "); sb_u(&s2, (uint64_t)U.sw); sb_s(&s2, " x "); sb_u(&s2, (uint64_t)U.sh); sb_s(&s2, "  (32-bit)"); text(x, y, s2.b, 1, C_TEXT); y += 26;
        text(x, y, "Read-only: the display mode is chosen by the UEFI firmware at boot;", 1, C_DIM); y += 18; text(x, y, "VEX OS has no display driver that could change it.", 1, C_DIM); y += 26;
        text(x, y, "Scale / brightness / night light: not available.", 1, C_WARN); break;
    case 2: text(x, y, "Accent color", 1, C_TEXT); y += 100; text(x, y, "Theme: Dark. A light theme is not implemented.", 1, C_DIM); y += 22;
        text(x, y, "The accent applies immediately. It is not saved across reboots.", 1, C_DIM); break;
    case 3: text(x, y, "Audio output devices: none. No HDA / AC'97 / USB audio driver exists.", 1, C_WARN); y += 22;
        text(x, y, "PC speaker: can be driven (square wave). Whether you HEAR it depends on", 1, C_TEXT); y += 18; text(x, y, "the host: QEMU needs a pcspk audiodev. The OS cannot detect audibility.", 1, C_TEXT); y += 110;
        text(x, y, "Volume / microphone: not available.", 1, C_DIM); break;
    case 4: for (int i = 0; i < acct_count() && i < 8; i++) { const Account *ac = acct_get(i); Sb r = {{0}, 0}; sb_s(&r, ac->display); sb_s(&r, ac->role == ACCT_ROLE_ADMIN ? "   (administrator)" : "   (standard user)"); if (i == acct_active()) sb_s(&r, "   <- you");
            text(x, y, r.b, 1, i == acct_active() ? C_ACCENT : C_TEXT); y += 22; }
        text(x, pane.y + pane.h - 120, is_admin_session() ? "As an administrator you can add users:" : "Only an administrator can add users.", 1, C_DIM); break;
    case 5: { WpGeom g; wp_geom(&g); const char *nm = wp_name(U.wp_sel) ? wp_name(U.wp_sel) : "?"; WpStatus ws = wp_status(U.wp_sel);
        int same = (U.wp_sel == wp_applied());
        if (g.big) {
            text(g.prev.x, g.label_y, "Preview", 1, C_DIM);
            rrect(mkrect(g.prev.x - 2, g.prev.y - 2, g.prev.w + 4, g.prev.h + 4), 6, C_PANEL_BD); wp_paint(g.prev, U.wp_sel);
            int32_t x2 = g.tx, y2 = g.prev.y;
            text(x2, y2, nm, 2, C_TEXT); y2 += 34;
            if (ws != WP_OK) { Sb e = {{0}, 0}; sb_s(&e, "Cannot be applied: "); sb_s(&e, wp_status_text(ws)); text(x2, y2, e.b, 1, C_ERR); }
            else if (same) text(x2, y2, "Currently applied to the desktop", 1, C_OK);
            else text(x2, y2, "Preview only - not applied yet", 1, C_WARN);
            y2 += 26;
            if (U.wp_sel == 0) text(x2, y2, "Built-in solid navy. Always available.", 1, C_DIM);
            else { Sb d = {{0}, 0}; sb_s(&d, "Built-in image, scaled to fit "); sb_u(&d, (uint64_t)U.sw); sb_s(&d, "x"); sb_u(&d, (uint64_t)U.sh); text(x2, y2, d.b, 1, C_DIM); }
            y2 += 20; text(x2, y2, "Changes the desktop behind all windows.", 1, C_DIM);
            y2 += 20; text(x2, y2, storage_state() == VS_READY ? "Your choice is saved for the next boot." : storage_state() == VS_BLANK ? "Not saved: data disk is blank (v. storage format)." : "Not saved across reboots (no data disk).", 1, C_DIM);
        } else {
            Sb d = {{0}, 0}; sb_s(&d, nm); sb_s(&d, ws != WP_OK ? ": unavailable" : same ? ": applied" : ": preview only"); text(g.apply.x, g.label_y, d.b, 1, ws != WP_OK ? C_ERR : C_TEXT);
        }
        text(U.card.x + 260, g.list_y, "Available wallpapers", 1, C_DIM);
        break; }
    default: text(x, y, "VEX OS  Release-03", 1, C_TEXT); y += 22; { Sb a = {{0}, 0}; sb_s(&a, "Kernel image: "); sb_u(&a, img / 1024); sb_s(&a, " KiB   Framebuffer: "); sb_u(&a, fb / 1024); sb_s(&a, " KiB"); text(x, y, a.b, 1, C_TEXT); y += 22; }
        text(x, y, "Apps: Verminal (VexScript), Valbook, File Explorer, Task Manager, Settings", 1, C_TEXT); y += 22;
        text(x, y, "No network driver, no audio driver, no persistent storage.", 1, C_WARN); break;
    }
    if (U.xmsg[0]) text(x, U.card.y + U.card.h - 40, U.xmsg, 1, U.wp_err ? C_ERR : C_OK);
}
static void draw_status(void)
{
    if (!U.fb_ok || !U.status[0]) return;
    text_c(U.sw / 2, U.status_r.y + 2, U.status, 1, C_ERR);
}
static void draw_msgs(void)
{
    if (U.screen == VEXUI_SETUP) draw_setup_msg(); else if (U.screen == VEXUI_LOCK) draw_auth_msg(); else if (U.screen == VEXUI_EXPLORER) draw_xmsg();
}
static void draw_dynamic(void)
{
    if (U.screen == VEXUI_LOCK) draw_lock_clock();
    else if (U.screen == VEXUI_DESKTOP) draw_desktop_clock();
    else if (U.screen == VEXUI_TERMINAL) draw_terminal_content();
    else if (U.screen == VEXUI_TASKMGR) draw_taskmgr_content();
}
static void draw_screen_no_bg(void)
{
    if (U.screen == VEXUI_SETUP) draw_setup_static();
    else if (U.screen == VEXUI_LOCK) draw_lock_static();
    else if (U.screen == VEXUI_DESKTOP) draw_desktop_static();
    else if (U.screen == VEXUI_EXPLORER) draw_explorer_static();
    else if (U.screen == VEXUI_TASKMGR) draw_taskmgr_static();
    else if (U.screen == VEXUI_VALBOOK) draw_valbook_static();
    else if (U.screen == VEXUI_SETTINGS) draw_settings_static();
    else draw_terminal_static();
    if (is_app_screen(U.screen)) draw_taskbar_bg();
    for (int i = 0; i < U.nctl; i++) draw_ctl(i);
    draw_status();
    if (U.popup != VEXUI_POPUP_NONE) draw_popup();
}
static void queue_repaint(Rect r) { U.heavy_req++; if (U.repaint_n < MAX_REPAINT) U.repaint[U.repaint_n++] = r; else REDRAW_ALL(); }

/* ------------------------------------------------------------------ */
/* State transitions                                                    */
/* ------------------------------------------------------------------ */
static int hit_ctl(int32_t x, int32_t y) { for (int i = 0; i < U.nctl; i++) if (in_rect(&U.ctl[i], x, y)) return i; return -1; }
static int hit_pitem(int32_t x, int32_t y) { for (int i = 0; i < pitem_count(); i++) if (U.pitem[i].w > 0 && in_rect(&U.pitem[i], x, y)) return i; return -1; }
static void recompute_hover(void)
{
    if (!U.mouse_present) { U.hover = -1; return; }
    if (U.popup != VEXUI_POPUP_NONE) { int h = hit_pitem(U.px, U.py); U.hover = (h >= 0 && vexui_popup_item_enabled(h)) ? h : -1; }
    else U.hover = hit_ctl(U.px, U.py);
}
static void log_layout(void)
{
    if (U.quiet) return;
    serial_puts("[ui] layout ");
    for (int i = 0; i < U.nctl; i++) log_rect(CK_NAMES[U.ckind[i]], U.ctl[i]);
    serial_puts("\n");
}
static void set_screen(VexUiScreen s)
{
    U.screen = s; U.popup = VEXUI_POPUP_NONE; U.focus = 0; U.pfocus = 0; U.pscroll = 0;
    U.pressed = -1; U.press_ctx = -1; U.status[0] = 0; U.na = 0; U.search_len = 0; U.search_buf[0] = 0;
    if (s == VEXUI_LOCK || s == VEXUI_SETUP) { wipe(U.pass_buf, sizeof U.pass_buf); wipe(U.pass2_buf, sizeof U.pass2_buf); U.pass_len = U.pass2_len = 0; U.auth_msg[0] = 0; }
    if (s == VEXUI_SETUP) { U.focus = 0; U.name_len = 0; U.name_buf[0] = 0; U.setup_msg[0] = 0; }
    if (s != VEXUI_EXPLORER) U.xdlg = 0;
    layout(); recompute_hover();
    REDRAW_ALL(); U.repaint_n = 0; U.popup_redraw = 0;
    if (!U.quiet) { ulog(s == VEXUI_SETUP ? "[ui] setup screen shown " : s == VEXUI_LOCK ? "[ui] lock screen shown " : s == VEXUI_DESKTOP ? "[ui] desktop shown " : s == VEXUI_EXPLORER ? "[ui] explorer view shown " : s == VEXUI_TASKMGR ? "[ui] task manager view shown " : s == VEXUI_VALBOOK ? "[ui] valbook view shown " : s == VEXUI_SETTINGS ? "[ui] settings view shown " : "[ui] terminal view shown "); log_layout(); }
}
static void signin(const char *how)
{
    if (U.screen != VEXUI_LOCK || acct_selected() < 0) return;
    int idx = acct_selected();
    if (!acct_login(idx, U.pass_buf)) {                         /* rejected: NO identity is established */
        wipe(U.pass_buf, sizeof U.pass_buf); U.pass_len = 0;
        const char *m = "Incorrect password."; int i = 0; for (; m[i]; i++) U.auth_msg[i] = m[i]; U.auth_msg[i] = 0;
        ulog2("[ui] sign-in REJECTED for ", sel_name()); ulog("\n"); U.msg_dirty = 1; for (int q = 0; q < U.nctl; q++) if (U.ckind[q] == CK_PASS) U.ctl_dirty |= 1u << q; return;
    }
    wipe(U.pass_buf, sizeof U.pass_buf); U.pass_len = 0; U.auth_msg[0] = 0;
    U.session_user = idx; U.signin_count++; U.enter_count++;
    (void)vfs_ensure_home(acct_get(idx)->uid, acct_get(idx)->id);
    (void)apps_session_begin();
    if (!U.quiet) memreport_snapshot("after sign-in");
    ulog2("[ui] signed in as ", sel_name()); ulog2(" (via ", how); ulog(")\n");
    set_screen(VEXUI_DESKTOP);
}
static void lock_screen(const char *how)
{
    if (U.screen == VEXUI_LOCK || U.screen == VEXUI_SETUP) return;
    if (apps_running(APP_ID_VALBOOK) && U.vb_modified) {          /* never lose unsaved work silently: ask first */
        set_screen(VEXUI_VALBOOK); U.vb_dlg = 3; U.vb_pending = 3; layout(); REDRAW_ALL(); ulog("[ui] lock deferred: Valbook has unsaved changes\n"); return;
    }
    vb_reset(); U.spage = 0; U.xdlg = 0; for (int q = 0; q < 8; q++) { U.wmin[q] = 0; U.wdx[q] = 0; U.wdy[q] = 0; }
    U.lock_count++; vth_close(); apps_session_end(); U.session_user = -1; acct_logout();   /* the previous identity is invalidated */
    ulog2("[ui] session locked (via ", how); ulog(")\n");
    set_screen(VEXUI_LOCK);
}
static void open_popup(VexUiPopup p)
{
    U.popup = p; U.pressed = -1; U.press_ctx = -1; U.pscroll = 0;
    if (p == VEXUI_POPUP_VMENU || p == VEXUI_POPUP_SEARCH) { if (p == VEXUI_POPUP_VMENU) { U.search_len = 0; U.search_buf[0] = 0; } }
    layout();
    U.pfocus = p == VEXUI_POPUP_POWER ? VEXUI_PWR_CANCEL : p == VEXUI_POPUP_USERS ? (acct_selected() >= 0 ? acct_selected() : 0) : 0;
    recompute_hover(); U.popup_redraw = 1;
    if (p == VEXUI_POPUP_USERS) layout();
    if (!U.quiet) {
        static const char *const nm[] = { "", "power menu", "network panel", "users panel", "V menu", "search results", "context menu" };
        ulog2("[ui] ", nm[p]); ulog(" opened "); log_rect("panel", U.pop);
        for (int i = 0; i < pitem_count() && i < 10; i++) { serial_puts("item"); serial_put_dec64((uint64_t)i); serial_puts(""); log_rect("", U.pitem[i]); }
        serial_puts("\n");
    }
}
static void close_popup(const char *how)
{
    if (U.popup == VEXUI_POPUP_NONE) return;
    Rect old = mkrect(U.pop.x - 2, U.pop.y - 2, U.pop.w + 4, U.pop.h + 4);
    static const char *const nm[] = { "", "power menu", "network panel", "users panel", "V menu", "search results", "context menu" };
    ulog2("[ui] ", nm[U.popup]); ulog2(" closed (", how); ulog(")\n");
    if (U.popup == VEXUI_POPUP_VMENU || U.popup == VEXUI_POPUP_SEARCH) { U.search_len = 0; U.search_buf[0] = 0; }   /* never leak a stale query */
    U.popup = VEXUI_POPUP_NONE; U.pressed = -1; U.press_ctx = -1;
    if (U.screen == VEXUI_LOCK) U.focus = 0;            /* "Press Enter to sign in" must stay true after any panel closes */
    layout(); recompute_hover(); U.popup_redraw = 0; queue_repaint(old);
}
static void launch_terminal(void)
{
    int already = 0; uint32_t id = apps_launch(APP_ID_TERMINAL, &already);
    if (!id) { set_status("Could not launch Verminal (application table full)."); return; }
    if (U.popup != VEXUI_POPUP_NONE) { U.popup = VEXUI_POPUP_NONE; }
    if (!already) vth_open();
    ulog("[ui] Verminal launched (VexScript application)\n");
    if (!U.quiet) memreport_snapshot("terminal open");
    set_screen(VEXUI_TERMINAL);
}
static void close_terminal(void)
{
    vth_close(); apps_close(APP_ID_TERMINAL);
    ulog("[ui] Verminal closed (timer stopped)\n");
    if (!U.quiet) memreport_snapshot("terminal closed");
    set_screen(VEXUI_DESKTOP);
}
static void setup_msg_set(const char *m) { int i = 0; for (; m[i] && i < (int)sizeof U.setup_msg - 1; i++) U.setup_msg[i] = m[i]; U.setup_msg[i] = 0; }
static void setup_submit(void)
{
    if (!bufeq(U.pass_buf, U.pass2_buf)) { setup_msg_set("Passwords do not match."); ulog("[ui] account creation rejected: passwords do not match\n"); U.msg_dirty = 1; return; }
    AcctResult r = acct_create_pw(U.name_buf, U.pass_buf, U.add_mode ? acct_active() : -1);   /* admin check is inside the account store */
    if (r != ACCT_OK) { setup_msg_set(acct_result_msg(r)); ulog2("[ui] account creation rejected: ", acct_result_msg(r)); ulog("\n"); U.msg_dirty = 1; return; }
    int idx = acct_find(U.name_buf);
    (void)vfs_ensure_home(acct_get(idx)->uid, acct_get(idx)->id);
    ulog2("[ui] account created: ", acct_get(idx)->display); ulog2(acct_role(idx) == ACCT_ROLE_ADMIN ? " (administrator) [backend: " : " (standard user) [backend: ", acct_backend()->label); ulog("]\n");
    wipe(U.pass_buf, sizeof U.pass_buf); wipe(U.pass2_buf, sizeof U.pass2_buf); U.pass_len = U.pass2_len = 0; U.name_len = 0; U.name_buf[0] = 0; U.setup_msg[0] = 0;
    if (U.add_mode) { U.add_mode = 0; set_screen(VEXUI_DESKTOP); }
    else { (void)acct_select(idx); set_screen(VEXUI_LOCK); }
}
static void valbook_open_node(int node);
static void explorer_go(int dir)
{
    { const Account *a = acct_get(acct_active()); if (a && !vfs_can_read(dir, a->uid, a->role == ACCT_ROLE_ADMIN)) { int j = 0; const char *m = "Permission denied: this folder belongs to another user."; for (; m[j]; j++) U.xmsg[j] = m[j]; U.xmsg[j] = 0; U.msg_dirty = 1; ulog("[ui] explorer: navigation denied (not readable)\n"); return; } }
    U.xdir = dir; U.xscroll = 0; U.xsel = 0; U.xmsg[0] = 0; layout(); REDRAW_ALL();
    if (!U.quiet) { char p[96]; if (vfs_path(dir, p, sizeof p) > 0) { ulog2("[ui] explorer: ", p); ulog("\n"); } }
}
static void explorer_home(void)
{
    char p[64] = "/home/"; const Account *a = acct_get(U.session_user); int k = 6;
    if (a) { for (int i = 0; a->id[i] && k < 62; i++) p[k++] = a->id[i]; } p[k] = 0;
    int h = vfs_resolve(p); U.xdir = h >= 0 ? h : 0;
}
static int me_uid(uint32_t *uid, int *adm) { const Account *a = acct_get(acct_active()); if (!a) return 0; *uid = a->uid; *adm = a->role == ACCT_ROLE_ADMIN; return 1; }
static void xmsg_set(const char *m) { U.wp_err = 0; int j = 0; for (; m[j] && j < 95; j++) U.xmsg[j] = m[j]; U.xmsg[j] = 0; }
static const char VEX_STARTER[] = "// New Vex Code file (VexScript)\nfn main() -> i32 {\n    return 0;\n}\n";
static void explorer_create(void)                 /* dialog OK for every Explorer dialog mode */
{
    uint32_t uid; int adm, r; char nm[48]; char path[96];
    if (!me_uid(&uid, &adm)) { xmsg_set("Not signed in."); U.msg_dirty = 1; return; }
    if (U.xmode == 5) {
        r = vfs_delete(U.xtarget, uid, adm);
        if (r < 0) { xmsg_set(vfs_errmsg(r)); ulog2("[ui] explorer: delete rejected: ", vfs_errmsg(r)); ulog("\n"); U.msg_dirty = 1; return; }
        xmsg_set("Deleted."); ulog("[ui] explorer: deleted item\n"); U.xdlg = 0; U.xsel = 0; layout(); REDRAW_ALL(); return;
    }
    int l = 0; while (U.xname_buf[l] && l < 40) { nm[l] = U.xname_buf[l]; l++; } nm[l] = 0;
    if (U.xmode == 4) {
        r = vfs_rename(U.xtarget, nm, uid, adm);
        if (r < 0) { xmsg_set(vfs_errmsg(r)); ulog2("[ui] explorer: rename rejected: ", vfs_errmsg(r)); ulog("\n"); U.msg_dirty = 1; return; }
        Sb m = {{0}, 0}; sb_s(&m, "Renamed to "); sb_s(&m, nm); xmsg_set(m.b); ulog2("[ui] explorer: renamed to ", nm); ulog("\n"); U.xdlg = 0; layout(); REDRAW_ALL(); return;
    }
    if (U.xmode == 3 && !(l >= 4 && nm[l - 4] == '.' && nm[l - 3] == 'v' && nm[l - 2] == 'e' && nm[l - 1] == 'x')) { if (l + 4 > VFS_NAME_MAX) { xmsg_set(vfs_errmsg(VFS_ERR_NAME)); U.msg_dirty = 1; return; } nm[l++] = '.'; nm[l++] = 'v'; nm[l++] = 'e'; nm[l++] = 'x'; nm[l] = 0; }
    r = vfs_create(U.xdir, nm, U.xmode == 2, uid, adm);
    if (r >= 0 && U.xmode == 3) { int w = vfs_write(r, VEX_STARTER, (int)sizeof VEX_STARTER - 1, uid, adm); if (w < 0) { (void)vfs_delete(r, uid, adm); r = w; } }   /* roll back a half-made file */
    if (r < 0) { xmsg_set(vfs_errmsg(r)); ulog2("[ui] explorer: create rejected: ", vfs_errmsg(r)); ulog("\n"); U.msg_dirty = 1; return; }
    Sb m = {{0}, 0}; sb_s(&m, "Created "); sb_s(&m, nm); xmsg_set(m.b);
    if (vfs_path(r, path, sizeof path) > 0) { ulog2(U.xmode == 2 ? "[ui] explorer: created folder " : "[ui] explorer: created file ", path); ulog("\n"); }
    U.xdlg = 0; U.xname_len = 0; U.xname_buf[0] = 0; U.xsel = 0; layout(); REDRAW_ALL();
}
static void explorer_open_dialog(int mode, int target)
{
    U.xmode = mode; U.xtarget = target; U.xdlg = 1; U.xmsg[0] = 0; U.xname_len = 0; U.xname_buf[0] = 0;
    if (mode == 4) { const VfsNode *n = vfs_node(target); if (n) { for (int k = 0; n->name[k] && k < 39; k++) U.xname_buf[U.xname_len++] = n->name[k]; U.xname_buf[U.xname_len] = 0; } }
    layout(); REDRAW_ALL();
}
/* ---- Valbook actions ---- */
static void vb_perform_pending(void)
{
    int p = U.vb_pending; U.vb_pending = 0; U.vb_dlg = 0;
    if (p == 1) { apps_close(APP_ID_VALBOOK); vb_reset(); ulog("[ui] Valbook closed\n"); set_screen(VEXUI_DESKTOP); }
    else if (p == 2) { vb_reset(); layout(); REDRAW_ALL(); }
    else if (p == 3) { vb_reset(); lock_screen("pending save/discard"); }
    else { layout(); REDRAW_ALL(); }
}
static int vb_do_save(void)
{
    uint32_t uid; int adm; char path[96];
    if (!me_uid(&uid, &adm)) { vb_set_msg("Not signed in."); return 0; }
    if (U.vb_node < 0) { U.vb_dlg = 1; U.vb_name_len = 0; U.vb_name[0] = 0; layout(); REDRAW_ALL(); return 0; }        /* untitled: ask for a name first */
    int r = vfs_write(U.vb_node, U.vb_buf, U.vb_len, uid, adm);
    if (r < 0) { vb_set_msg(vfs_errmsg(r)); ulog2("[ui] valbook: save FAILED: ", vfs_errmsg(r)); ulog("\n"); return 0; }   /* modified stays set: nothing is claimed saved */
    U.vb_modified = 0; vb_set_msg("Saved."); U.vb_status_dirty = 1;
    if (vfs_path(U.vb_node, path, sizeof path) > 0) { ulog2("[ui] valbook: saved ", path); ulog("\n"); }
    return 1;
}
static void vb_saveas_ok(void)
{
    uint32_t uid; int adm; const Account *a = acct_get(acct_active()); char path[96];
    if (!a || !me_uid(&uid, &adm)) { vb_set_msg("Not signed in."); return; }
    int home = vfs_ensure_home(a->uid, a->id); if (home < 0) { vb_set_msg(vfs_errmsg(home)); return; }
    int n = vfs_create(home, U.vb_name, 0, uid, adm); if (n < 0) { vb_set_msg(vfs_errmsg(n)); ulog2("[ui] valbook: save-as rejected: ", vfs_errmsg(n)); ulog("\n"); return; }
    int w = vfs_write(n, U.vb_buf, U.vb_len, uid, adm);
    if (w < 0) { (void)vfs_delete(n, uid, adm); vb_set_msg(vfs_errmsg(w)); return; }                          /* roll back: no empty leftover file */
    U.vb_node = n; U.vb_modified = 0; U.vb_dlg = 0; vb_set_msg("Saved.");
    if (vfs_path(n, path, sizeof path) > 0) { ulog2("[ui] valbook: saved ", path); ulog("\n"); }
    if (U.vb_pending) vb_perform_pending(); else { layout(); REDRAW_ALL(); }
}
static void vb_load_node(int n)
{
    int k = vfs_read(n, U.vb_buf, VFS_DATA_MAX); char path[96];
    if (k < 0) { vb_set_msg(vfs_errmsg(k)); return; }
    U.vb_len = k; U.vb_cur = 0; U.vb_node = n; U.vb_modified = 0; U.vb_scroll = 0; U.vb_dlg = 0; U.vb_msg[0] = 0;
    if (vfs_path(n, path, sizeof path) > 0) { ulog2("[ui] valbook: opened ", path); ulog("\n"); }
    layout(); REDRAW_ALL();
}
static void vb_open_path_ok(void)
{
    uint32_t uid; int adm; if (!me_uid(&uid, &adm)) { vb_set_msg("Not signed in."); return; }
    int n = vfs_resolve(U.vb_name);
    if (n < 0) { vb_set_msg(n == VFS_ERR_NOTFOUND ? "File not found." : vfs_errmsg(n)); ulog("[ui] valbook: open failed\n"); return; }
    if (vfs_node(n)->is_dir) { vb_set_msg("That is a folder, not a file."); return; }
    if (!vfs_can_read(n, uid, adm)) { vb_set_msg("Permission denied."); return; }
    vb_load_node(n);
}
static void vb_dialog_ok(void) { if (U.vb_dlg == 1) vb_saveas_ok(); else if (U.vb_dlg == 2) vb_open_path_ok(); }
static void valbook_key(const VexKeyEvent *e, int ascii, int repeat)
{
    int ctrl = (e->modifiers & (VEX_MOD_LCTRL | VEX_MOD_RCTRL)) != 0;
    if (U.vb_dlg) {
        if (e->key == VEX_KEY_ESCAPE) { U.vb_dlg = 0; U.vb_pending = 0; layout(); REDRAW_ALL(); return; }
        if (U.vb_dlg == 3) return;                                                  /* choose with the buttons */
        if (e->key == VEX_KEY_ENTER) { if (!repeat) vb_dialog_ok(); return; }
        if (tf_edit(U.vb_name, &U.vb_name_len, 63, e->key, ascii)) { U.xdlg_dirty = 1; U.vb_msg[0] = 0; U.vb_status_dirty = 1; }
        return;
    }
    if (ctrl && !repeat && e->key == 22) { (void)vb_do_save(); return; }          /* Ctrl+S */
    if (ctrl && !repeat && e->key == 17) { if (U.vb_modified) { U.vb_dlg = 3; U.vb_pending = 2; layout(); REDRAW_ALL(); } else { vb_reset(); layout(); REDRAW_ALL(); } return; }   /* Ctrl+N */
    if (ctrl) return;
    if (e->key == VEX_KEY_LEFT || e->key == VEX_KEY_RIGHT || e->key == VEX_KEY_UP || e->key == VEX_KEY_DOWN) { vb_move(e->key); return; }
    if (e->key == VEX_KEY_ENTER) { vb_insert('\n'); return; }
    if (e->key == VEX_KEY_BACKSPACE) { vb_backspace(); return; }
    if (ascii >= 32 && ascii < 127) vb_insert(ascii);
}
static void valbook_open_node(int node)
{
    uint32_t uid; int adm;
    if (!me_uid(&uid, &adm) || !vfs_can_read(node, uid, adm)) return;
    int was = apps_running(APP_ID_VALBOOK);
    launch_app(APP_ID_VALBOOK);
    if (was && U.vb_modified) { vb_set_msg("Save or discard the current document first."); return; }
    vb_load_node(node);
}
/* ---- speaker (PC speaker only; the one audio device this OS can drive) ---- */
static inline void outb_(uint16_t p, uint8_t v) { __asm__ volatile("outb %0,%1" :: "a"(v), "Nd"(p)); }
static inline uint8_t inb_(uint16_t p) { uint8_t v; __asm__ volatile("inb %1,%0" : "=a"(v) : "Nd"(p)); return v; }
static void speaker_on(uint32_t hz, uint32_t ms)
{
    if (!U.quiet) { uint32_t div = 1193182u / hz; outb_(0x43, 0xB6); outb_(0x42, (uint8_t)div); outb_(0x42, (uint8_t)(div >> 8)); outb_(0x61, (uint8_t)(inb_(0x61) | 3)); }
    U.beep_off = timer_ticks() + ((uint64_t)ms * TIMER_TARGET_HZ + 999) / 1000;
}
static void speaker_off(void) { if (!U.quiet) outb_(0x61, (uint8_t)(inb_(0x61) & ~3)); U.beep_off = 0; }
static void launch_app(uint32_t id)
{
    if (id == APP_ID_TERMINAL) { U.wmin[0] = 0; launch_terminal(); return; }
    int already = 0; uint32_t inst = apps_launch(id, &already);
    if (!inst) { set_status("Could not launch the application (tracker full)."); return; }
    U.popup = VEXUI_POPUP_NONE; U.wmin[app_idx(screen_of_app(id))] = 0;
    if (!already) {
        if (id == APP_ID_EXPLORER) { explorer_home(); U.xscroll = 0; U.xsel = 0; U.xdlg = 0; U.xmsg[0] = 0; ulog("[ui] File Explorer launched\n"); }
        else if (id == APP_ID_TASKMGR) { uint32_t pm; (void)cpuacct_sample(&pm); U.cpu_pm = -1; memreport_get(&U.img_b, &U.fb_b); ulog("[ui] Task Manager launched\n"); }
        else if (id == APP_ID_VALBOOK) { vb_reset(); ulog("[ui] Valbook launched\n"); }
        else { U.spage = 0; U.xmsg[0] = 0; ulog("[ui] Settings launched\n"); }
    } else ulog("[ui] application brought to the foreground\n");
    set_screen(screen_of_app(id));
}
static const char *app_label(uint32_t id);
static void close_app(void)
{
    if (U.screen == VEXUI_TERMINAL) { close_terminal(); return; }
    if (U.screen == VEXUI_VALBOOK && U.vb_modified) { U.vb_dlg = 3; U.vb_pending = 1; layout(); REDRAW_ALL(); return; }   /* save / discard / cancel */
    apps_close(app_of_screen(U.screen)); if (U.screen == VEXUI_VALBOOK) vb_reset();
    ulog2("[ui] ", app_label(app_of_screen(U.screen))); ulog(" closed\n"); set_screen(VEXUI_DESKTOP);
}
static int is_editable(const char *n) { const char *e = ext_of(n); return !*e || (cmp_name(e, "txt") == 0) || (cmp_name(e, "vex") == 0) || (cmp_name(e, "md") == 0) || (cmp_name(e, "log") == 0); }
static void ctx_action(int code)
{
    int t = U.ctx_target; close_popup("selected"); const VfsNode *n = t >= 0 ? vfs_node(t) : 0;
    switch (code) {
    case 1: if (n && n->is_dir) explorer_go(t); else if (n) valbook_open_node(t); break;
    case 2: if (n) valbook_open_node(t); break;
    case 3: if (n) explorer_open_dialog(4, t); break;
    case 4: if (n) explorer_open_dialog(5, t); break;
    case 5: explorer_open_dialog(1, -1); break;
    case 6: explorer_open_dialog(2, -1); break;
    case 7: explorer_open_dialog(3, -1); break;
    case 8: U.xmsg[0] = 0; layout(); REDRAW_ALL(); ulog("[ui] explorer: refreshed\n"); break;
    default: break;
    }
}
/* Apply wallpaper idx to the one desktop. On failure the previous wallpaper is untouched and the reason is shown. */
static void wp_ui_apply(int idx)
{
    const char *nm = wp_name(idx) ? wp_name(idx) : "?";
    if (idx == wp_applied() && idx != 0) { xmsg_set("That wallpaper is already applied."); REDRAW_ALL(); return; }
    uint64_t t0 = apps_now_ms();
    WpStatus st = (idx == 0 || (U.fb_ok && U.fb && (uint32_t)U.sw == U.fb->width && (uint32_t)U.sh == U.fb->height)) ? wp_apply(idx, U.fb) : WP_E_SCREEN;
    uint64_t dt = apps_now_ms() - t0;
    Sb m = {{0}, 0};
    if (st == WP_OK) {
        int saved = storage_save_wallpaper((uint32_t)idx);
        const char *sv = saved ? " - saved for next boot" : (storage_state() == VS_READY ? " - could NOT be saved (disk error)" : storage_state() == VS_BLANK ? " (not saved: data disk not formatted)" : " (not saved: no data disk)");
        if (idx == 0) { sb_s(&m, "Default wallpaper restored"); sb_s(&m, sv); sb_s(&m, "."); ulog("[wallpaper] reset to default: ok\n"); }
        else { sb_s(&m, "Wallpaper applied: "); sb_s(&m, nm); sb_s(&m, sv);
               Sb l = {{0}, 0}; sb_s(&l, "[wallpaper] applied "); sb_s(&l, nm); sb_s(&l, " in "); sb_u(&l, dt); sb_s(&l, " ms, cache "); sb_u(&l, wp_cache_bytes()); sb_s(&l, " bytes\n"); ulog(l.b); }
        xmsg_set(m.b);
    } else {
        sb_s(&m, "Not applied: "); sb_s(&m, nm); sb_s(&m, " - "); sb_s(&m, wp_status_text(st)); sb_s(&m, ". Previous kept.");
        xmsg_set(m.b); U.wp_err = 1;
        Sb l = {{0}, 0}; sb_s(&l, "[wallpaper] apply FAILED for "); sb_s(&l, nm); sb_s(&l, ": "); sb_s(&l, wp_status_text(st)); sb_s(&l, "\n"); ulog(l.b);
    }
    REDRAW_ALL();
}
/* STORAGE-01: apply the wallpaper saved on the data disk (if any) at start-up. A bad/unavailable choice is ignored: the default desktop is the fallback. */
static void wp_restore_saved(void)
{
    uint32_t idx = 0; if (!storage_load_wallpaper(&idx) || idx == 0) return;
    if (idx >= (uint32_t)wp_count() || !U.fb_ok || (uint32_t)U.sw != U.fb->width || (uint32_t)U.sh != U.fb->height) { ulog("[wallpaper] saved choice ignored (invalid index or screen mismatch)\n"); return; }
    WpStatus st = wp_apply((int)idx, U.fb);
    if (st == WP_OK) { U.wp_sel = (int)idx; Sb l = {{0}, 0}; sb_s(&l, "[wallpaper] restored saved wallpaper: "); sb_s(&l, wp_name((int)idx)); sb_s(&l, "\n"); ulog(l.b); }
    else { Sb l = {{0}, 0}; sb_s(&l, "[wallpaper] saved wallpaper could not be restored: "); sb_s(&l, wp_status_text(st)); sb_s(&l, " (default kept)\n"); ulog(l.b); }
}
static void activate_ctl(int i, const char *how)
{
    switch (U.ckind[i]) {
    case CK_SIGNIN: signin(how); break;
    case CK_PASS: if (U.screen == VEXUI_LOCK) signin(how); else U.focus = i; break;
    case CK_PASS2: U.focus = i; break;
    case CK_USERS: open_popup(VEXUI_POPUP_USERS); break;
    case CK_NET: open_popup(VEXUI_POPUP_NET); break;
    case CK_POWER: open_popup(VEXUI_POPUP_POWER); break;
    case CK_VBTN: open_popup(VEXUI_POPUP_VMENU); break;
    case CK_SEARCH: U.focus = i; open_popup(VEXUI_POPUP_SEARCH); break;
    case CK_TERM: launch_app(APP_ID_TERMINAL); break;
    case CK_EXPL: launch_app(APP_ID_EXPLORER); break;
    case CK_TASK: launch_app(APP_ID_TASKMGR); break;
    case CK_VALB: launch_app(APP_ID_VALBOOK); break;
    case CK_SETT: launch_app(APP_ID_SETTINGS); break;
    case CK_TCLOSE: close_app(); break;
    case CK_TMIN: U.wmin[app_idx(U.screen)] = 1; ulog("[ui] window minimized (state kept)\n"); set_screen(VEXUI_DESKTOP); break;
    case CK_CREATE: setup_submit(); break;
    case CK_XUP: explorer_go(vfs_parent(U.xdir)); break;
    case CK_XHOME: explorer_home(); explorer_go(U.xdir); break;
    case CK_XNEW: explorer_open_dialog(1, -1); break;
    case CK_XSORT: U.xsort = (U.xsort + 1) % 5; layout(); REDRAW_ALL(); break;
    case CK_XROW: { int k = U.xscroll + (i - 4); U.xsel = k; const VfsNode *n = (k < U.xn) ? vfs_node(U.xlist[k]) : 0; if (n && n->is_dir) explorer_go(U.xlist[k]); else REDRAW_ALL(); break; }
    case CK_XOK: if (U.screen == VEXUI_VALBOOK) { if (U.vb_dlg == 3) { if (U.vb_node >= 0) { if (vb_do_save()) vb_perform_pending(); } else { U.vb_dlg = 1; U.vb_name_len = 0; U.vb_name[0] = 0; layout(); REDRAW_ALL(); } } else vb_dialog_ok(); } else explorer_create(); break;
    case CK_XCANCEL: if (U.screen == VEXUI_VALBOOK) { U.vb_dlg = 0; U.vb_pending = 0; } else { U.xdlg = 0; U.xmsg[0] = 0; } layout(); REDRAW_ALL(); break;
    case CK_VBDISCARD: vb_perform_pending(); break;
    case CK_VBNEW: if (U.vb_modified) { U.vb_dlg = 3; U.vb_pending = 2; } else vb_reset(); layout(); REDRAW_ALL(); break;
    case CK_VBOPEN: { U.vb_dlg = 2; U.vb_name_len = 0; U.vb_name[0] = 0; const Account *a = acct_get(acct_active()); if (a) { const char *pre = "/home/"; for (int k = 0; pre[k]; k++) U.vb_name[U.vb_name_len++] = pre[k]; for (int k = 0; a->id[k] && U.vb_name_len < 60; k++) U.vb_name[U.vb_name_len++] = a->id[k]; U.vb_name[U.vb_name_len++] = '/'; U.vb_name[U.vb_name_len] = 0; } layout(); REDRAW_ALL(); break; }
    case CK_VBSAVE: (void)vb_do_save(); break;
    case CK_SROW: U.spage = i - 1; U.xmsg[0] = 0; U.wp_err = 0; if (U.spage == 5) { U.wp_sel = wp_applied(); ulog("[wallpaper] page shown\n"); } layout(); if (U.spage == 5) log_layout(); REDRAW_ALL(); break;
    case CK_WPTILE: { int k = 0; for (int q = 0; q < i; q++) if (U.ckind[q] == CK_WPTILE) k++;
        U.wp_sel = k; U.xmsg[0] = 0; U.wp_err = 0; ulog2("[wallpaper] selected (preview): ", wp_name(k) ? wp_name(k) : "?"); ulog("\n"); REDRAW_ALL(); break; }
    case CK_WPAPPLY: wp_ui_apply(U.wp_sel); break;
    case CK_WPRESET: U.wp_sel = 0; if (wp_applied() == 0) { xmsg_set("Already using the default wallpaper."); ulog("[wallpaper] reset requested: already default\n"); REDRAW_ALL(); } else wp_ui_apply(0); break;
    case CK_SSWATCH: { static const uint8_t pal[6][3] = { {0x3A,0x8C,0xFF}, {0x8E,0x5C,0xF0}, {0x4C,0xC7,0x5A}, {0xF0,0xA0,0x30}, {0xF0,0x5A,0x6E}, {0x7A,0x8A,0xA8} };
        int k = 0; for (int q = 0; q < i; q++) if (U.ckind[q] == CK_SSWATCH) k++;
        U.accent = gfx_rgb(pal[k][0], pal[k][1], pal[k][2]); ulog("[ui] settings: accent color changed\n"); REDRAW_ALL(); break; }
    case CK_SBTN:
        if (U.spage == 3) { speaker_on(440, 400); xmsg_set("PC speaker tone (440 Hz, 0.4 s) started. Audible only if the host routes the PC speaker."); ulog("[ui] settings: PC speaker test started\n"); REDRAW_ALL(); }
        else if (U.spage == 4 && is_admin_session()) { U.add_mode = 1; set_screen(VEXUI_SETUP); }
        break;
    default: break;
    }
}
static void activate_pitem(int i, const char *how)
{
    if (!vexui_popup_item_enabled(i)) return;
    switch (U.popup) {
    case VEXUI_POPUP_CTX: ctx_action(U.ctx_code[i]); break;
    case VEXUI_POPUP_NET: close_popup(how); break;
    case VEXUI_POPUP_POWER:
        if (i == VEXUI_PWR_CANCEL) close_popup(how);
        else { U.pending = i == VEXUI_PWR_SHUTDOWN ? VEXUI_ACT_SHUTDOWN : VEXUI_ACT_REBOOT; ulog(i == VEXUI_PWR_SHUTDOWN ? "[ui] power: shutdown requested\n" : "[ui] power: reboot requested\n"); close_popup(how); }
        break;
    case VEXUI_POPUP_USERS:
        if (i < acct_count()) { (void)acct_select(i); acct_logout(); wipe(U.pass_buf, sizeof U.pass_buf); U.pass_len = 0; U.auth_msg[0] = 0; ulog2("[ui] selected account ", sel_name()); ulog("\n"); }
        close_popup(how); REDRAW_ALL(); break;
    case VEXUI_POPUP_VMENU: case VEXUI_POPUP_SEARCH:
        if (i < U.na) { launch_app(apps_registry_get(U.app_hit[i])->app_id); }
        else if (i == U.na) { close_popup(how); lock_screen("V menu"); }
        else if (i == U.na + 3) { close_popup(how); U.add_mode = 1; set_screen(VEXUI_SETUP); }
        else { U.pending = i == U.na + 1 ? VEXUI_ACT_SHUTDOWN : VEXUI_ACT_REBOOT; ulog(i == U.na + 1 ? "[ui] power: shutdown requested\n" : "[ui] power: reboot requested\n"); close_popup(how); }
        break;
    default: break;
    }
}
static void note_input(const char *kind, uint32_t v)
{
    Sb s = {{0}, 0}; sb_s(&s, kind); sb_u(&s, v);
    int i = 0; for (; s.b[i] && i < (int)sizeof U.last_input - 1; i++) U.last_input[i] = s.b[i];
    U.last_input[i] = 0;
}
static void move_focus_base(int dir) { if (U.nctl) { U.focus = (U.focus + dir + U.nctl) % U.nctl; if (U.screen == VEXUI_SETTINGS && U.ckind[U.focus] >= CK_WPTILE) { ulog2("[ui] focus ", CK_NAMES[U.ckind[U.focus]]); ulog("\n"); } } }
static void move_focus_popup(int dir)
{
    int n = pitem_count();
    for (int tries = 0; tries < n; tries++) { U.pfocus = (U.pfocus + dir + n) % n; if (vexui_popup_item_enabled(U.pfocus)) break; }
    if (U.popup == VEXUI_POPUP_USERS) {                          /* keep the focused row inside the scroll window */
        int vis = imin(acct_count(), USERS_VISIBLE), f = U.pfocus;
        if (f < acct_count()) { if (f < U.pscroll) U.pscroll = f; if (f >= U.pscroll + vis) U.pscroll = f - vis + 1; }
        Rect old = mkrect(U.pop.x - 2, U.pop.y - 2, U.pop.w + 4, U.pop.h + 4); layout(); queue_repaint(old); U.popup_redraw = 1;
    }
}
/* returns 1 if the key edited the buffer */
static int tf_edit(char *buf, int *len, int cap, unsigned key, int ascii)
{
    if (key == VEX_KEY_BACKSPACE) { if (*len > 0) { buf[--*len] = 0; return 1; } return 0; }
    if (ascii >= 32 && ascii < 127 && *len < cap) { buf[(*len)++] = (char)ascii; buf[*len] = 0; return 1; }
    return 0;
}
static void popup_refilter(void)
{
    Rect old = mkrect(U.pop.x - 2, U.pop.y - 2, U.pop.w + 4, U.pop.h + 4);
    layout(); U.pfocus = 0;
    if (U.screen == VEXUI_DESKTOP) { U.cheap_old = old; U.cheap_valid = 1; }      /* black desktop: clear the old panel rect and redraw ONLY the panel */
    else queue_repaint(old);
    U.popup_redraw = 1;
}

/* ------------------------------------------------------------------ *
 * Verminal command requests (made by the VexScript app, executed here)  *
 * ------------------------------------------------------------------ */
static const char *skipws(const char *s) { while (*s == ' ' || *s == '\t') s++; return s; }
/* One argument: "quoted text" (spaces allowed) or the whole trimmed remainder (so v. open File Explorer also works). */
static int parse_rest(const char *in, char *out, int cap, const char **err)
{
    int n = 0; in = skipws(in);
    if (*in == '"') {
        in++; while (*in && *in != '"') { if (n < cap - 1) out[n++] = *in; in++; }
        if (*in != '"') { *err = "Unterminated quote."; return 0; }
        in++; if (*skipws(in)) { *err = "Unexpected text after the closing quote."; return 0; }
        out[n] = 0; return 1;
    }
    while (*in && n < cap - 1) out[n++] = *in++;
    while (n > 0 && (out[n - 1] == ' ' || out[n - 1] == '\t')) n--;
    out[n] = 0; return 1;
}
static int parse_token(const char **pp, char *out, int cap, const char **err)
{
    const char *s = skipws(*pp); int n = 0;
    if (*s == '"') { s++; while (*s && *s != '"') { if (n < cap - 1) out[n++] = *s; s++; } if (*s != '"') { *err = "Unterminated quote."; return 0; } s++; }
    else while (*s && *s != ' ' && *s != '\t') { if (n < cap - 1) out[n++] = *s; s++; }
    out[n] = 0; *pp = s; return 1;
}
static uint32_t resolve_app(const char *q)
{
    for (int i = 0; i < apps_registry_count(); i++) if (cmp_name(apps_registry_get(i)->name, q) == 0) return apps_registry_get(i)->app_id;
    if (cmp_name(q, "explorer") == 0) return APP_ID_EXPLORER;
    return 0;
}
static const char *app_label(uint32_t id) { for (int i = 0; i < apps_registry_count(); i++) if (apps_registry_get(i)->app_id == id) return apps_registry_get(i)->name; return "?"; }
static void say3(const char *a, const char *b, const char *c) { Sb s = {{0}, 0}; sb_s(&s, a); sb_s(&s, b); sb_s(&s, c); vth_print(s.b); }
static void close_running_app(uint32_t id)
{
    if (id == APP_ID_VALBOOK) vb_reset();
    apps_close(id); U.wmin[app_idx(screen_of_app(id))] = 0;
    if (is_app_screen(U.screen) && app_of_screen(U.screen) == id) set_screen(VEXUI_DESKTOP);
}
#if defined(VEX_TERM_MIRROR) && VEX_TERM_MIRROR
/* TEST BUILDS ONLY (-DVEX_TERM_MIRROR=1, with the seeded-accounts image): copy the output of v. testpath / v. content to the serial log
 * so scripts/wallpaper_e2e.py can assert on the exact text.  Never enabled in a normal build (file text would reach the debug console). */
static void term_out(const char *s) { serial_puts("[term] "); serial_puts(s); serial_puts("\n"); vth_print(s); }
#else
#define term_out vth_print
#endif
/* ---- v. gfx : GFX-VEC-01 status, A/B switch and benchmark ------------------------------------------------------ */
static void gfx_bench(void (*emit)(const char *))
{
    int was = vec_aa(); char b[120]; Rect r;
    for (int mode = 1; mode >= 0; mode--) {
        vec_set_aa(mode); uint64_t t0 = timer_ticks();
        for (int i = 0; i < 30; i++) { r.x = 10 + i % 7; r.y = 10 + i % 5; r.w = 640; r.h = 360; rrect(r, 14, gfx_rgb((uint8_t)(40 + i), 60, 120)); }
        uint64_t t1 = timer_ticks();
        for (int i = 0; i < 40; i++) text(10, 10 + (i % 20) * 16, "The quick brown fox jumps over the lazy dog 0123456789 +-*/=<>", 1, C_ACCENT);
        uint64_t t2 = timer_ticks(); char *p = b; const char *l = mode ? "anti-aliased: " : "aliased:      ";
        while (*l) *p++ = *l++;
        { const char *m1 = "30 large rounded rects "; while (*m1) *p++ = *m1++; }
        { uint64_t v = (t1 - t0) * 10; char t[12]; int k = 0; do { t[k++] = (char)('0' + v % 10); v /= 10; } while (v); while (k) *p++ = t[--k]; }
        { const char *m2 = " ms; 40 text lines (2560 chars) "; while (*m2) *p++ = *m2++; }
        { uint64_t v = (t2 - t1) * 10; char t[12]; int k = 0; do { t[k++] = (char)('0' + v % 10); v /= 10; } while (v); while (k) *p++ = t[--k]; }
        { const char *m3 = " ms (timer resolution 10 ms)"; while (*m3) *p++ = *m3++; }
        *p = 0; emit(b);
    }
    vec_set_aa(was);
}
static void gfx_term(const char *arg, void (*emit)(const char *))
{
    while (*arg == ' ') arg++;
    if (bufeq(arg, "aa on") || bufeq(arg, "aa off")) {
        vec_set_aa(arg[3] == 'o' && arg[4] == 'n'); REDRAW_ALL();      /* "aa on" -> index 3 is 'o', index 4 is 'n' */
        emit(vec_aa() ? "Anti-aliased vector rendering ON (text, rounded shapes, discs)." : "Anti-aliased rendering OFF: using the original aliased primitives and bitmap font.");
        return;
    }
    if (bufeq(arg, "bench")) { gfx_bench(emit); REDRAW_ALL(); return; }
    emit(vec_aa() ? "Graphics: anti-aliased vector rendering is ON." : "Graphics: anti-aliased vector rendering is OFF.");
    emit("Sub-pixel coordinates are Q24.8 fixed point (1/256 px); the kernel does not use hardware floating point.");
    emit("Outline font: DejaVu Sans Mono (ASCII). Commands: v. gfx aa on | aa off | bench   (see docs/GFX-VEC-01.md)");
}

static void run_term_request(int kind, char *arg)
{
    char a[96]; const char *err = "";
    if (kind == 4) {                                                       /* audio test */
        speaker_on(440, 400);
        vth_print("Programmed the PC speaker: 440 Hz square wave for 0.4 s (non-blocking).");
        vth_print("You will only HEAR it if the host routes the PC speaker (QEMU: -machine pcspk-audiodev=<id>).");
        vth_print("The OS cannot detect audibility. No other audio device (HDA/AC'97/USB) has a driver."); ulog("[ui] v. audio test: PC speaker tone started\n"); return;
    }
    if (kind == 5) {                                                       /* change users */
        if (apps_running(APP_ID_VALBOOK) && U.vb_modified) vth_print("Valbook has unsaved changes: asking it to Save/Discard/Cancel before switching user.");
        else vth_print("Locking the session (all applications close). Pick another user on the lock screen; a password is required.");
        lock_screen("v. change users"); return;
    }
    if (kind == 6) {                                                       /* add user (administrators only; enforced in the account store) */
        const char *p = arg; char name[40], pw[72]; int n = 0;
        if (!parse_token(&p, name, sizeof name, &err)) { vth_print(err); return; }
        p = skipws(p); while (*p && n < 70) pw[n++] = *p++; while (n > 0 && (pw[n - 1] == ' ' || pw[n - 1] == '\t')) n--; pw[n] = 0;
        if (!name[0] || !pw[0]) { vth_print("Usage: v. add user <name> <password>   (quote a name with spaces: v. add user \"Mary Jane\" secret123)"); secure_zero(pw, sizeof pw); return; }
        AcctResult r = acct_create_pw(name, pw, acct_active()); secure_zero(pw, sizeof pw);
        if (r != ACCT_OK) { say3("Could not add user: ", acct_result_msg(r), ""); ulog2("[ui] v. add user rejected: ", acct_result_msg(r)); ulog("\n"); return; }
        int idx = acct_find(name); (void)vfs_ensure_home(acct_get(idx)->uid, acct_get(idx)->id);
        say3("Created user '", acct_get(idx)->display, acct_role(idx) == ACCT_ROLE_ADMIN ? "' (administrator)." : "' (standard user)."); ulog2("[ui] v. add user: created ", acct_get(idx)->display); ulog("\n"); return;
    }
    if (kind == 9) {                                                       /* v. storage [format] */
        char t[16]; int n = 0; while (arg[n] == ' ') n++; int m = 0; while (arg[n] && arg[n] != ' ' && m < 15) t[m++] = arg[n++]; t[m] = 0;
        if (m == 0) { storage_report(term_out); return; }
        if (t[0] == 'f' && t[1] == 'o' && t[2] == 'r' && t[3] == 'm' && t[4] == 'a' && t[5] == 't' && !t[6]) {
            if (!is_admin_session()) { term_out("Only an administrator can format a data disk."); return; }
            if (storage_state() != VS_BLANK) { term_out(storage_state() == VS_READY ? "The data disk is already formatted." : "Refused: there is no verified-blank data disk to format (other disks are never touched)."); return; }
            term_out(storage_format() ? "Data disk formatted. Wallpaper choices are now saved." : "Format failed (disk error); nothing was changed that the store trusts.");
            return;
        }
        term_out("Usage: v. storage [format]"); return;
    }
    if (kind == 10) { storage_pci_report(term_out); return; }              /* v. drivers */
    if (kind == 13) { gfx_term(arg, term_out); ulog("[ui] v. gfx: handled\n"); return; }                                   /* v. gfx (GFX-VEC-01) */
    if (kind == 12) { proc_term(arg, term_out); ulog("[ui] v. proc: handled by the PROC-01 loader\n"); return; }     /* v. proc (PROC-01) */
    if (kind == 11) { crystal_kernel_term(arg, term_out); ulog("[ui] v. ai: handled by the native Crystal runtime\n"); return; }   /* v. ai (CRYSTAL-NATIVE-01) */
    if (kind == 7 || kind == 8) {                                          /* testpath / content: read-only, permission-checked in vfs_cmds.c */
        char pth[96]; uint32_t uid; int adm; const Account *ac = acct_get(acct_active());
        if (!parse_rest(arg, pth, sizeof pth, &err)) { vth_print(err); return; }
        if (!me_uid(&uid, &adm) || !ac) { vth_print("Not signed in."); return; }
        if (kind == 7) { int ok = vfs_cmd_testpath(pth, uid, adm, ac->id, term_out); ulog2("[ui] v. testpath: ", ok ? "true\n" : "false\n"); }
        else { int n = vfs_cmd_content(pth, uid, adm, ac->id, term_out); ulog2("[ui] v. content: ", n >= 0 ? "ok\n" : "refused\n"); }
        return;
    }
    if (!parse_rest(arg, a, sizeof a, &err)) { vth_print(err); return; }
    if (!a[0]) { vth_print(kind == 1 ? "Usage: v. open <application>   (quote names with spaces: v. open \"File Explorer\")" : kind == 2 ? "Usage: v. close <application>" : "Usage: v. search <name>"); return; }
    if (kind == 3) {                                                       /* search: only places the signed-in user may read */
        uint32_t uid; int adm, hits[20]; if (!me_uid(&uid, &adm)) { vth_print("Not signed in."); return; }
        int n = vfs_search(a, uid, adm, hits, 20);
        if (n == 0) { say3("No results for '", a, "' in the locations you can read."); return; }
        Sb h = {{0}, 0}; sb_u(&h, (uint64_t)n); sb_s(&h, n >= 20 ? "+ result(s) (first 20 shown):" : " result(s):"); vth_print(h.b);
        for (int i = 0; i < n; i++) { char path[96]; if (vfs_path(hits[i], path, sizeof path) > 0) say3("  ", path, vfs_node(hits[i])->is_dir ? "/" : ""); }
        vth_print("(Searches the RAM filesystem by name, case-insensitive; nothing else exists to search.)"); return;
    }
    uint32_t id = resolve_app(a);
    if (!id) { say3("Unknown application '", a, "'. Known: Verminal, Task Manager, File Explorer, Valbook, Settings."); return; }
    if (kind == 1) {                                                       /* open / restore / focus */
        if (id == APP_ID_TERMINAL) { vth_print("Verminal is already open (this window)."); return; }
        int running = apps_running(id), mn = U.wmin[app_idx(screen_of_app(id))];
        say3(!running ? "Opening " : mn ? "Restoring " : "Bringing to the foreground: ", app_label(id), ".");
        launch_app(id); U.wmin[0] = 1; return;                             /* Verminal keeps running behind it */
    }
    /* kind == 2: close */
    if (!apps_running(id)) { say3(app_label(id), " is not running.", ""); return; }
    if (id == APP_ID_TERMINAL) { vth_print("Closing Verminal."); close_terminal(); return; }
    if (id == APP_ID_VALBOOK && U.vb_modified) {
        vth_print("Valbook has unsaved changes: asking it to Save/Discard/Cancel (nothing was closed).");
        set_screen(VEXUI_VALBOOK); U.vb_dlg = 3; U.vb_pending = 1; layout(); REDRAW_ALL(); return;
    }
    say3("Closed ", app_label(id), "."); close_running_app(id);
}
static void explorer_key(const VexKeyEvent *e, int ascii, int repeat)
{
    if (U.xdlg) {
        if (e->key == VEX_KEY_ESCAPE) { U.xdlg = 0; U.xmsg[0] = 0; layout(); REDRAW_ALL(); return; }
        if (e->key == VEX_KEY_ENTER) { if (!repeat) explorer_create(); return; }
        if (U.xmode == 5) return;
        if (tf_edit(U.xname_buf, &U.xname_len, 31, e->key, ascii)) { U.xmsg[0] = 0; U.xdlg_dirty = 1; U.msg_dirty = 1; }
        return;
    }
    if (e->key == VEX_KEY_ESCAPE) { if (!repeat) close_app(); return; }
    if (e->key == VEX_KEY_DOWN || e->key == VEX_KEY_UP) {
        if (e->key == VEX_KEY_DOWN && U.xsel + 1 < U.xn) { U.xsel++; }
        if (e->key == VEX_KEY_UP && U.xsel > 0) { U.xsel--; }
        if (U.xsel < U.xscroll) { U.xscroll = U.xsel; }
        if (U.xsel >= U.xscroll + U.xrows) { U.xscroll = U.xsel - U.xrows + 1; }
        layout(); REDRAW_ALL(); return; }
    if (e->key == VEX_KEY_ENTER && !repeat) { const VfsNode *n = (U.xsel < U.xn) ? vfs_node(U.xlist[U.xsel]) : 0; if (n && n->is_dir) explorer_go(U.xlist[U.xsel]); else if (n) valbook_open_node(U.xlist[U.xsel]); return; }
    if (e->key == VEX_KEY_BACKSPACE && !repeat) { explorer_go(vfs_parent(U.xdir)); return; }
    if (ascii == 'n' && !repeat) activate_ctl(3, "keyboard");
    if (ascii == 'h' && !repeat) { explorer_home(); explorer_go(U.xdir); }
}
void vexui_handle_key(const VexKeyEvent *e)
{
    if (!U.inited || !e) return;
    unsigned k = (unsigned)e->key & 0xFFu;
    if (e->action == VEX_KEY_RELEASE) { U.keydown[k] = 0; return; }
    if (e->action != VEX_KEY_PRESS) return;
    int repeat = U.keydown[k]; U.keydown[k] = 1;
    int shift = (e->modifiers & (VEX_MOD_LSHIFT | VEX_MOD_RSHIFT)) != 0;
    if (e->key == 69) { if (!repeat) { REDRAW_ALL(); ulog("[ui] explicit full redraw requested (F12)\n"); } return; }
    int ascii = vex_key_ascii(e->key, e->modifiers);
    if (!repeat) note_input("Key code ", (uint32_t)e->key);
    int next = (e->key == VEX_KEY_TAB && !shift) || e->key == VEX_KEY_RIGHT || e->key == VEX_KEY_DOWN;
    int prev = (e->key == VEX_KEY_TAB && shift) || e->key == VEX_KEY_LEFT || e->key == VEX_KEY_UP;

    if (U.popup == VEXUI_POPUP_NONE && U.screen == VEXUI_TASKMGR) { if (e->key == VEX_KEY_ESCAPE && !repeat) close_app(); return; }
    if (U.popup == VEXUI_POPUP_NONE && U.screen == VEXUI_SETTINGS && e->key == VEX_KEY_ESCAPE) { if (!repeat) close_app(); return; }   /* other keys: Tab/arrows/Enter/Space navigate the page (generic handling below) */
    if (U.popup == VEXUI_POPUP_NONE && U.screen == VEXUI_VALBOOK) { valbook_key(e, ascii, repeat); return; }
    if (U.popup == VEXUI_POPUP_NONE && U.screen == VEXUI_EXPLORER) { explorer_key(e, ascii, repeat); return; }
    if (U.popup == VEXUI_POPUP_NONE && U.screen == VEXUI_TERMINAL) {                            /* every key goes to the VexScript app; typematic repeat is fine for text */
        if (vth_key(e->key, ascii) == 2) close_terminal();
        else { int rk; char ra[VTH_ARG_MAX + 1]; if (vth_take_request(&rk, ra, sizeof ra)) { run_term_request(rk, ra); secure_zero(ra, sizeof ra); } }
        return;
    }
    if (U.screen == VEXUI_SETUP) {
        static const int order[4] = { 0, 2, 3, 1 };               /* name -> password -> confirm -> Create */
        if (e->key == VEX_KEY_ESCAPE && U.add_mode) { if (!repeat) { U.add_mode = 0; set_screen(VEXUI_DESKTOP); } return; }
        if (e->key == VEX_KEY_TAB || e->key == VEX_KEY_DOWN || e->key == VEX_KEY_UP) {
            int pos = 0; for (int q = 0; q < 4; q++) if (order[q] == U.focus) pos = q;
            pos = (pos + ((e->key == VEX_KEY_UP || (e->key == VEX_KEY_TAB && shift)) ? 3 : 1)) % 4; U.focus = order[pos]; return; }   /* focus ring repaint comes from the per-control style diff: no full redraw */
        if (e->key == VEX_KEY_ENTER) { if (!repeat) setup_submit(); return; }       /* always validates: never a bypass */
        int ed = 0;
        if (U.focus == 0) ed = tf_edit(U.name_buf, &U.name_len, 39, e->key, ascii);
        else if (U.focus == 2) ed = tf_edit(U.pass_buf, &U.pass_len, ACCT_PW_MAX + 4, e->key, ascii);
        else if (U.focus == 3) ed = tf_edit(U.pass2_buf, &U.pass2_len, ACCT_PW_MAX + 4, e->key, ascii);
        else if (e->key == VEX_KEY_SPACE && !repeat) setup_submit();
        if (ed) { U.setup_msg[0] = 0; U.msg_dirty = 1; U.ctl_dirty |= 1u << U.focus; }
        return;
    }
    if (U.popup == VEXUI_POPUP_VMENU || U.popup == VEXUI_POPUP_SEARCH) {
        if (e->key == VEX_KEY_ESCAPE) { if (!repeat) close_popup("ESC"); return; }
        if (e->key == VEX_KEY_BACKSPACE || (ascii && !(e->key == VEX_KEY_TAB))) {
            if (tf_edit(U.search_buf, &U.search_len, 31, e->key, ascii)) { popup_refilter(); if (U.popup == VEXUI_POPUP_SEARCH) for (int q = 0; q < U.nctl; q++) if (U.ckind[q] == CK_SEARCH) U.ctl_dirty |= 1u << q; }
            return;
        }
        if (next) { move_focus_popup(+1); return; }
        if (prev) { move_focus_popup(-1); return; }
        if (e->key == VEX_KEY_ENTER && !repeat) activate_pitem(U.pfocus, "keyboard");
        return;
    }
    if (U.popup != VEXUI_POPUP_NONE) {
        if (e->key == VEX_KEY_ESCAPE) { if (!repeat) close_popup("ESC"); return; }
        if (next) { move_focus_popup(+1); return; }
        if (prev) { move_focus_popup(-1); return; }
        if ((e->key == VEX_KEY_ENTER || e->key == VEX_KEY_SPACE) && !repeat) activate_pitem(U.pfocus, "keyboard");
        return;
    }
    if (U.screen == VEXUI_DESKTOP && U.ckind[U.focus] == CK_SEARCH && (ascii || e->key == VEX_KEY_BACKSPACE) && e->key != VEX_KEY_TAB) {
        if (tf_edit(U.search_buf, &U.search_len, 31, e->key, ascii)) { open_popup(VEXUI_POPUP_SEARCH); U.ctl_dirty |= 1u << U.focus; }
        return;
    }
    if (U.screen == VEXUI_LOCK && acct_has_password(acct_selected()) && (e->key == VEX_KEY_BACKSPACE || ascii)) {    /* type-to-password */
        if (tf_edit(U.pass_buf, &U.pass_len, ACCT_PW_MAX + 4, e->key, ascii)) { U.auth_msg[0] = 0; U.msg_dirty = 1; for (int q = 0; q < U.nctl; q++) if (U.ckind[q] == CK_PASS) U.ctl_dirty |= 1u << q; }
        return;
    }
    if (next) { move_focus_base(+1); return; }
    if (prev) { move_focus_base(-1); return; }
    if (repeat) return;
    if (U.screen == VEXUI_LOCK && e->key == VEX_KEY_SPACE) signin("SPACE");
    else if (e->key == VEX_KEY_ENTER || (e->key == VEX_KEY_SPACE && U.screen == VEXUI_SETTINGS)) {
        if (U.screen == VEXUI_LOCK && (U.focus == 0 || U.ckind[U.focus] == CK_PASS)) signin("ENTER"); else activate_ctl(U.focus, "ENTER");
    }
}

void vexui_handle_mouse(const VexMouseEvent *e)
{
    if (!U.inited || !e) return;
    U.mouse_present = 1;
    U.px = cursor_clamp(U.px + e->dx, 0, U.sw - 1);
    U.py = cursor_clamp(U.py + e->dy, 0, U.sh - 1);
    if (e->dx || e->dy) U.cursor_dirty = 1;
    int prev = (U.mbuttons & VEX_MOUSE_BTN_LEFT) != 0, now = (e->buttons & VEX_MOUSE_BTN_LEFT) != 0;
    int rprev = (U.mbuttons & VEX_MOUSE_BTN_RIGHT) != 0, rnow = (e->buttons & VEX_MOUSE_BTN_RIGHT) != 0;
    U.mbuttons = e->buttons;
    recompute_hover();
    if (U.drag && now && (e->dx || e->dy)) {                                    /* title-bar drag: move the REAL window, keep it reachable */
        int ai = app_idx(U.screen), bx, by; win_base(&bx, &by); Rect old = U.card;
        U.wdx[ai] = U.px - U.drag_ox - bx; U.wdy[ai] = U.py - U.drag_oy - by; layout();
        U.wdx[ai] = U.card.x - bx; U.wdy[ai] = U.card.y - by;                    /* store the CLAMPED position */
        int32_t x0 = imin(old.x, U.card.x) - 2, y0 = imin(old.y, U.card.y) - 2, x1 = imax(old.x + old.w, U.card.x + U.card.w) + 2, y1 = imax(old.y + old.h, U.card.y + U.card.h) + 2;
        queue_repaint(mkrect(x0, y0, x1 - x0, y1 - y0)); recompute_hover();
    }
    if (rprev && !rnow) {                                                       /* right-click release */
        if (U.popup != VEXUI_POPUP_NONE) close_popup("right click");
        else if (U.screen == VEXUI_EXPLORER && !U.xdlg) {
            int h = hit_ctl(U.px, U.py), t = -1; static uint8_t dummy;
            if (h >= 0 && U.ckind[h] == CK_XROW) { int k = U.xscroll + (h - 4); if (k < U.xn) t = U.xlist[k]; }
            Rect area = mkrect(U.card.x + 16, U.card.y + 44 + 40, U.card.w - 32, U.card.h - 44 - 40 - 60);
            if (t >= 0 || in_rect(&area, U.px, U.py)) {
                const VfsNode *n = t >= 0 ? vfs_node(t) : 0; (void)dummy; U.ctx_n = 0; U.ctx_target = t;
                if (n && n->is_dir) { U.ctx_code[U.ctx_n++] = 1; U.ctx_code[U.ctx_n++] = 3; U.ctx_code[U.ctx_n++] = 4; }
                else if (n) { U.ctx_code[U.ctx_n++] = 1; if (is_editable(n->name)) U.ctx_code[U.ctx_n++] = 2; U.ctx_code[U.ctx_n++] = 3; U.ctx_code[U.ctx_n++] = 4; }
                else { U.ctx_code[U.ctx_n++] = 5; U.ctx_code[U.ctx_n++] = 6; U.ctx_code[U.ctx_n++] = 7; U.ctx_code[U.ctx_n++] = 8; }
                U.ctx_x = U.px; U.ctx_y = U.py; open_popup(VEXUI_POPUP_CTX);
            }
        }
    }
    if (prev && !now) U.drag = 0;
    if (!prev && now) {
        note_input("Mouse press at ", (uint32_t)U.px);
        if (U.popup != VEXUI_POPUP_NONE) {
            int h = hit_pitem(U.px, U.py);
            if (h >= 0 && vexui_popup_item_enabled(h)) { U.pressed = h; U.press_ctx = 1; } else { U.pressed = -1; U.press_ctx = 2; }
        } else { int h = hit_ctl(U.px, U.py); U.pressed = h; U.press_ctx = 0; if (h >= 0) U.focus = h;
            else if (is_app_screen(U.screen) && U.px >= U.card.x && U.px < U.card.x + U.card.w && U.py >= U.card.y && U.py < U.card.y + 40) { U.drag = 1; U.drag_ox = U.px - U.card.x; U.drag_oy = U.py - U.card.y; U.press_ctx = -1; } }
    } else if (prev && !now) {                                   /* the one place a click fires */
        int pc = U.press_ctx, pr = U.pressed;
        U.pressed = -1; U.press_ctx = -1;
        if (pc == 0 && pr >= 0 && U.popup == VEXUI_POPUP_NONE && hit_ctl(U.px, U.py) == pr) activate_ctl(pr, "mouse click");
        else if (pc == 1 && pr >= 0 && U.popup != VEXUI_POPUP_NONE && hit_pitem(U.px, U.py) == pr) activate_pitem(pr, "mouse click");
        else if (pc == 2 && U.popup != VEXUI_POPUP_NONE && !in_rect(&U.pop, U.px, U.py)) close_popup("click outside");
        recompute_hover();
    }
}

/* ------------------------------------------------------------------ */
/* Rendering flush                                                      */
/* ------------------------------------------------------------------ */
static void flush_render(void)
{
    if (!U.fb_ok) { U.redraw_all = 0; U.repaint_n = 0; U.popup_redraw = 0; U.dyn_dirty = 0; U.cursor_dirty = 0; return; }
    int ctl_dirty = 0, pitem_dirty = 0;
    for (int i = 0; i < U.nctl; i++) if (U.drawn_ctl[i] != ctl_style(i)) ctl_dirty = 1;
    for (int i = 0; i < pitem_count(); i++) if (U.drawn_pitem[i] != pitem_style(i)) pitem_dirty = 1;
    int work = U.redraw_all || U.repaint_n || U.popup_redraw || U.dyn_dirty || ctl_dirty || pitem_dirty || U.cursor_dirty
               || U.ctl_dirty || U.msg_dirty || U.xdlg_dirty || U.prompt_dirty || U.vb_d0 >= 0 || U.vb_status_dirty;
    if (!work) return;
    cursor_hide();
    if (U.redraw_all) { U.full_draws++; if (!U.quiet) { serial_puts("[gfx] full-screen redraw #"); serial_put_dec64(U.full_draws); serial_puts("\n"); } bg_rect(mkrect(0, 0, U.sw, U.sh)); draw_screen_no_bg(); }
    else {
        if (U.repaint_n) { if (!U.quiet) serial_puts("[gfx] region repaint (bg + ALL widgets redrawn)\n"); for (int i = 0; i < U.repaint_n; i++) bg_rect(U.repaint[i]); draw_screen_no_bg(); }
        else if (U.popup_redraw) { if (U.cheap_valid) { bg_rect(U.cheap_old); U.cheap_valid = 0; } draw_popup(); }
        else {
            if (pitem_dirty) for (int i = 0; i < pitem_count(); i++) if (U.drawn_pitem[i] != pitem_style(i)) draw_pitem(i);
            for (int i = 0; i < U.nctl; i++)
                if (U.drawn_ctl[i] != ctl_style(i) && !(U.popup != VEXUI_POPUP_NONE && rects_overlap(&U.ctl[i], &U.pop))) draw_ctl(i);
        }
        if (U.dyn_dirty && !U.repaint_n) {
            draw_dynamic();
            if (U.popup != VEXUI_POPUP_NONE && rects_overlap(&U.clock_r, &U.pop)) draw_popup();
        }
    }
    if (!U.redraw_all && !U.repaint_n) {                          /* FINE-GRAINED updates: only what typing actually changed */
        for (int i = 0; i < U.nctl; i++) if ((U.ctl_dirty >> i) & 1u) draw_ctl(i);
        if (U.msg_dirty) draw_msgs();
        if (U.xdlg_dirty) { if (U.screen == VEXUI_VALBOOK) draw_vb_dlg_field(); else draw_xdlg_field(); }
        if (U.vb_d0 >= 0 && U.screen == VEXUI_VALBOOK) { draw_vb_lines(U.vb_d0, U.vb_d1); }
        if (U.vb_status_dirty && U.screen == VEXUI_VALBOOK) { draw_vb_status(); draw_vb_title(); }
        if (U.prompt_dirty && !U.dyn_dirty) draw_terminal_prompt();
    }
    if (!U.redraw_all && !U.repaint_n && is_app_screen(U.screen) && U.card.y + U.card.h > U.sh - 56
        && (U.ctl_dirty || U.msg_dirty || U.xdlg_dirty || U.prompt_dirty || U.vb_d0 >= 0 || U.vb_status_dirty || U.dyn_dirty)) {
        Rect tb = mkrect(0, U.sh - 56, U.sw, 56);                  /* a dragged window overlaps the taskbar: keep the taskbar ON TOP, exactly like a full redraw */
        draw_taskbar_bg(); for (int i = 0; i < U.nctl; i++) if (rects_overlap(&U.ctl[i], &tb)) draw_ctl(i);
    }
    U.ctl_dirty = 0; U.msg_dirty = 0; U.xdlg_dirty = 0; U.prompt_dirty = 0; U.vb_d0 = -1; U.vb_d1 = -1; U.vb_status_dirty = 0;
    U.redraw_all = 0; U.repaint_n = 0; U.popup_redraw = 0; U.dyn_dirty = 0;
    if (U.mouse_present) { cursor_move_to(U.px, U.py); cursor_show(); }
    U.cursor_dirty = 0;
}

static void set_status(const char *msg)
{
    int i = 0; for (; msg[i] && i < (int)sizeof U.status - 1; i++) U.status[i] = msg[i];
    U.status[i] = 0;
    queue_repaint(U.status_r);
}

/* Draws a message box over the current screen; used right before a power
 * action so the display tells the truth about what is being requested. */
static void overlay_message(const char *l1, const char *l2)
{
    if (!U.fb_ok) return;
    cursor_hide();
    Rect r = mkrect((U.sw - 460) / 2, (U.sh - 96) / 2, 460, 96);
    if (r.x < 0) r.x = 0;
    rrect(mkrect(r.x - 1, r.y - 1, r.w + 2, r.h + 2), 12, C_ACCENT);
    rrect(r, 11, C_PANEL);
    text_c(r.x + r.w / 2, r.y + 24, l1, 2, C_TEXT);
    text_c(r.x + r.w / 2, r.y + 62, l2, 1, C_DIM);
    if (U.mouse_present) cursor_show();
}

static void execute_pending(void)
{
    VexUiAction a = U.pending;
    U.pending = VEXUI_ACT_NONE;
    if (a == VEXUI_ACT_NONE) return;
    flush_render();                                            /* popup is closed on screen first */
    if (a == VEXUI_ACT_SHUTDOWN) {
        ulog("[power] executing ACPI S5 shutdown...\n");
        overlay_message("Shutting down...", "Requesting ACPI S5 power-off");
        power_shutdown();                                      /* does not return on success */
        ulog("[power] SHUTDOWN FAILED: platform did not power off\n");
        set_status("Shutdown failed: the platform did not power off.");
    } else {
        ulog("[power] executing reboot...\n");
        overlay_message("Rebooting...", "Requesting platform reset");
        power_reboot();                                        /* does not return on success */
        ulog("[power] REBOOT FAILED: platform did not reset\n");
        set_status("Reboot failed: the platform did not reset.");
    }
    queue_repaint(mkrect((U.sw - 460) / 2 - 4, (U.sh - 96) / 2 - 4, 468, 104));
}

/* ------------------------------------------------------------------ */
/* Public                                                               */
/* ------------------------------------------------------------------ */
static void reset_state(int32_t w, int32_t h)
{
    uint8_t *p = (uint8_t *)&U;
    for (uint32_t i = 0; i < sizeof U; i++) p[i] = 0;          /* no libc memset in the kernel */
    U.sw = w; U.sh = h; U.hover = -1; U.pressed = -1; U.press_ctx = -1;
    U.px = w / 2; U.py = h / 2; U.cpu_pm = -1; U.accent = gfx_rgb(0x3A, 0x8C, 0xFF); U.vb_node = -1; U.vb_d0 = U.vb_d1 = -1;
}

void vexui_init(const GfxFb *fb, const VexUiFacts *facts)
{
    int32_t w = (fb && fb->ok) ? (int32_t)fb->width : 1024, h = (fb && fb->ok) ? (int32_t)fb->height : 768;
    reset_state(w, h);
    U.fb = fb; U.fb_ok = fb && fb->ok;
    if (facts) U.facts = *facts;
    U.mouse_present = facts ? facts->mouse_present : 0;
    U.can_shutdown = power_can_shutdown(); U.can_reboot = power_can_reboot();
    U.last_key_dropped = input_dropped_events();
    U.last_sec = timer_ticks() / TIMER_TARGET_HZ;
    U.session_user = -1;
    cursor_init(U.fb);
    U.inited = 1;
    wp_restore_saved();
    set_screen(acct_count() > 0 ? VEXUI_LOCK : VEXUI_SETUP);
    flush_render();
}

void vexui_poll(void)
{
    if (!U.inited) return;
    /* If the key queue overflowed, a RELEASE may have been lost; forget held-key state. */
    uint64_t d = input_dropped_events();
    if (d != U.last_key_dropped) { for (int i = 0; i < 256; i++) U.keydown[i] = 0; U.last_key_dropped = d; }

    VexKeyEvent ke; int n = 0;
    while (n++ < 64 && input_poll_key(&ke)) vexui_handle_key(&ke);
    VexMouseEvent me; n = 0;
    while (n++ < 128 && input_poll_mouse(&me)) vexui_handle_mouse(&me);

    vth_poll();                                                   /* periodic VexScript callback, if its timer is due */
    if (U.beep_off && timer_ticks() >= U.beep_off) speaker_off();   /* non-blocking beep timeout */
    if (U.screen == VEXUI_TERMINAL) {
        if (vth_take_dirty()) { U.dyn_dirty = 1; U.heavy_req++; (void)vth_take_prompt_dirty(); }    /* output changed: rows + prompt */
        else if (vth_take_prompt_dirty()) U.prompt_dirty = 1;                                     /* typing: prompt row only */
    }
    uint64_t sec = timer_ticks() / TIMER_TARGET_HZ;
    if (sec != U.last_sec) {
        U.last_sec = sec;
        if (U.screen == VEXUI_TASKMGR) { uint32_t pm; if (cpuacct_sample(&pm)) U.cpu_pm = (int)pm; }
        if (U.screen != VEXUI_TERMINAL) U.dyn_dirty = 1;
    }

    flush_render();
    if (U.pending != VEXUI_ACT_NONE) execute_pending();
    flush_render();
}

VexUiScreen vexui_screen(void) { return U.screen; }
VexUiPopup vexui_popup(void) { return U.popup; }
int vexui_focus(void) { return U.focus; }
int vexui_popup_focus(void) { return U.pfocus; }
int vexui_hover(void) { return U.hover; }
int vexui_pressed(void) { return U.pressed; }
VexUiAction vexui_pending_action(void) { return U.pending; }
void vexui_clear_pending(void) { U.pending = VEXUI_ACT_NONE; }
uint32_t vexui_enter_count(void) { return U.enter_count; }
uint32_t vexui_lock_count(void) { return U.lock_count; }
int32_t vexui_pointer_x(void) { return U.px; }
int32_t vexui_pointer_y(void) { return U.py; }

int vexui_ctl_rect(int ctl, int32_t *x, int32_t *y, int32_t *w, int32_t *h)
{
    if (ctl < 0 || ctl >= U.nctl || !x || !y || !w || !h) return 0;
    *x = U.ctl[ctl].x; *y = U.ctl[ctl].y; *w = U.ctl[ctl].w; *h = U.ctl[ctl].h; return 1;
}
int vexui_popup_item_rect(int item, int32_t *x, int32_t *y, int32_t *w, int32_t *h)
{
    if (item < 0 || item >= pitem_count() || !x || !y || !w || !h) return 0;
    *x = U.pitem[item].x; *y = U.pitem[item].y; *w = U.pitem[item].w; *h = U.pitem[item].h; return 1;
}
int vexui_popup_rect(int32_t *x, int32_t *y, int32_t *w, int32_t *h)
{
    if (U.popup == VEXUI_POPUP_NONE || !x || !y || !w || !h) return 0;
    *x = U.pop.x; *y = U.pop.y; *w = U.pop.w; *h = U.pop.h; return 1;
}

void vexui_test_begin(int32_t w, int32_t h, int can_shutdown, int can_reboot)
{
    reset_state(w, h);
    U.quiet = 1; U.fb = 0; U.fb_ok = 0; U.mouse_present = 1;
    U.can_shutdown = can_shutdown; U.can_reboot = can_reboot;
    U.inited = 1; U.session_user = -1;
    set_screen(acct_count() > 0 ? VEXUI_LOCK : VEXUI_SETUP);
}
int vexui_nctl(void) { return U.nctl; }
int vexui_ctl_kind(int c) { return (c >= 0 && c < U.nctl) ? U.ckind[c] : -1; }
const char *vexui_name_text(void) { return U.name_buf; }
const char *vexui_search_text(void) { return U.search_buf; }
const char *vexui_setup_message(void) { return U.setup_msg; }
int vexui_session_user(void) { return U.session_user; }
uint32_t vexui_signin_count(void) { return U.signin_count; }
const char *vexui_auth_message(void) { return U.auth_msg; }
int vexui_add_mode(void) { return U.add_mode; }
int vexui_explorer_dir(void) { return U.xdir; }
const char *vexui_explorer_message(void) { return U.xmsg; }
int vexui_explorer_entries(void) { return U.xn; }
int vexui_cpu_permille(void) { return U.cpu_pm; }
uint32_t vexui_full_redraws(void) { return U.full_req; }
uint32_t vexui_heavy_redraws(void) { return U.heavy_req; }
const char *vexui_valbook_text(void) { return U.vb_buf; }
int vexui_valbook_modified(void) { return U.vb_modified; }
int vexui_valbook_node(void) { return U.vb_node; }
int vexui_win_minimized(uint32_t id) { return U.wmin[app_idx(screen_of_app(id))]; }
void vexui_win_pos(int32_t *x, int32_t *y) { if (x) *x = U.card.x; if (y) *y = U.card.y; }
int vexui_sort_mode(void) { return U.xsort; }
int vexui_settings_page(void) { return U.spage; }
int vexui_ctx_count(void) { return U.ctx_n; }
int vexui_explorer_entry(int i) { return (i >= 0 && i < U.xn) ? U.xlist[i] : -1; }
uint32_t vexui_accent_rgb(void) { return ((uint32_t)U.accent.r << 16) | ((uint32_t)U.accent.g << 8) | U.accent.b; }
void vexui_test_end(void) { reset_state(0, 0); }
