/*
 * Vex OS - kernel/src/memory/virtual/tlb.c
 *
 * KERNEL-01 Phase 4 - cross-CPU TLB shootdown. The protocol, the
 * deadlock argument, and the reasons for each rule are in
 * kernel/include/tlb.h; this file is the implementation of what is
 * described there.
 */

#include "tlb.h"
#include "ipi.h"
#include "irq.h"
#include "lapic.h"
#include "percpu.h"
#include "acpi.h"
#include "serial.h"
#include "boot03_inject.h"

#define PAGE_SIZE 4096ull

/* Marks a request as "invalidate everything" rather than a range. Not a
 * valid page-aligned address, so it cannot be confused with one. */
#define TLB_REQUEST_FLUSH_ALL 1ull

/* Iterations to wait for all acknowledgements.
 *
 * A BOUND, NOT A DURATION, and the distinction is load-bearing here in a
 * way it was not in Phase 3. There is no time source usable from this
 * path: the timer interrupt is itself something a wedged CPU would not be
 * servicing, and this function can be called with the PIT in use
 * elsewhere. What the bound guarantees is the property the milestone
 * actually asks for - a halted or unresponsive CPU cannot deadlock the
 * initiator - not any particular wall-clock patience.
 *
 * Deliberately large. The cost of an over-long bound is that a genuinely
 * broken machine takes longer to report the breakage; the cost of a short
 * one is spurious timeouts on a heavily contended TCG host, which would
 * mean the suite reports failures that are artifacts of the emulator. Of
 * the two, only the second can make a working kernel look broken. */
#define TLB_ACK_SPIN_BUDGET 200000000u

/* Iterations to wait for the shootdown serialization lock. Bounded for
 * the same reason: a caller that cannot get the lock must fail, not hang.
 * Distinct from the ack budget because failing to acquire the lock is a
 * different fault from a CPU not answering. */
#define TLB_LOCK_SPIN_BUDGET 200000000u

/* One request slot per CPU.
 *
 * PADDED TO A CACHE LINE. Without the padding, two CPUs' slots would
 * share a line, and every acknowledgement store would invalidate the
 * line under a neighbour that is spinning on its own field. That is not
 * only slow - it is the kind of contention that turns a bounded wait into
 * a timeout on a busy machine, i.e. it would manifest as a correctness
 * failure in the tests rather than as a performance number. 64 bytes is
 * the line size on every x86-64 part this kernel targets.
 *
 * `volatile` on the cross-CPU fields, because they are written by one CPU
 * and polled by another; the atomic builtins below carry the ordering,
 * while volatile stops the compiler from hoisting a poll out of its loop.
 */
typedef struct {
    volatile uint64_t requested;      /* written by initiators (under lock) */
    volatile uint64_t acked;          /* written ONLY by the owning CPU */
    volatile uint64_t virt;           /* range base, or FLUSH_ALL */
    volatile uint64_t pages;
    volatile uint64_t serviced;       /* requests this CPU has handled */
    volatile uint64_t pages_done;     /* pages this CPU has invalidated */
    uint64_t pad[2];
} __attribute__((aligned(64))) TlbSlot;

static TlbSlot g_slots[PERCPU_MAX_CPUS];

static const SmpInfo *g_smp;
static int            g_ready;

/* Serializes INITIATORS only. Never taken by the receiver - see tlb.h.
 * Its purpose is to keep two concurrent initiators from interleaving
 * writes into the same target slot, which would let one CPU's range be
 * overwritten by another's while both waited for the same generation. */
static volatile uint32_t g_lock;

static uint64_t g_initiated;
static uint64_t g_remote_requests;
static uint64_t g_acks;
static uint64_t g_timeouts;
static uint64_t g_stale;
static uint64_t g_full_flushes;
static uint64_t g_anonymous;
static uint64_t g_completed;

static inline void invlpg_local(uint64_t virt)
{
    __asm__ volatile ("invlpg (%0)" :: "r"((void *)(uintptr_t)virt) : "memory");
}

/* Full local flush by reloading CR3. Legal because this kernel has one
 * address space and no global pages are set in the entries it creates;
 * a CR3 reload therefore invalidates every non-global translation, which
 * is all of them. */
static inline void flush_local_all(void)
{
    uint64_t cr3;
    __asm__ volatile ("mov %%cr3, %0" : "=r"(cr3));
    __asm__ volatile ("mov %0, %%cr3" :: "r"(cr3) : "memory");
}

static inline int interrupts_enabled(void)
{
    uint64_t flags;
    __asm__ volatile ("pushfq; pop %0" : "=r"(flags) :: "memory");
    return (flags & (1ull << 9)) != 0;
}

const char *tlb_result_name(TlbResult r)
{
    switch (r) {
    case TLB_OK:                 return "ok";
    case TLB_OK_LOCAL_ONLY:      return "ok (local only, no remote CPUs)";
    case TLB_ERR_NOT_READY:      return "shootdown layer not initialized";
    case TLB_ERR_BAD_RANGE:      return "range is empty or misaligned";
    case TLB_ERR_UNSAFE_CONTEXT: return "remote shootdown with interrupts"
                                        " disabled";
    case TLB_ERR_IPI_FAILED:     return "the IPI layer refused to send";
    case TLB_ERR_ACK_TIMEOUT:    return "a target CPU never acknowledged";
    default:                     return "unknown";
    }
}

uint64_t tlb_shootdowns_initiated(void) { return g_initiated; }
uint64_t tlb_remote_requests(void)      { return g_remote_requests; }
uint64_t tlb_acks_received(void)        { return g_acks; }
uint64_t tlb_timeouts(void)             { return g_timeouts; }
uint64_t tlb_stale_ignored(void)        { return g_stale; }
uint64_t tlb_full_flushes(void)         { return g_full_flushes; }
uint64_t tlb_anonymous_receipts(void)   { return g_anonymous; }
uint64_t tlb_completed_count(void)      { return g_completed; }

uint64_t tlb_serviced_by_cpu(uint32_t index)
{
    if (index >= PERCPU_MAX_CPUS) return 0;
    return g_slots[index].serviced;
}

uint64_t tlb_pages_invalidated_by_cpu(uint32_t index)
{
    if (index >= PERCPU_MAX_CPUS) return 0;
    return g_slots[index].pages_done;
}

/* ------------------------------------------------------------------ *
 * Receiver. Runs in interrupt context on the target CPU.
 *
 * Everything this function is allowed to do is constrained by that: no
 * lock, no allocation, no page-table walk, nothing that can block. It
 * touches only its own slot and the two instructions that invalidate
 * translations.
 * ------------------------------------------------------------------ */
static void tlb_shootdown_handler(InterruptFrame *frame)
{
    (void)frame;

    /* The checked accessor. A CPU whose GS base is not yet set would make
     * percpu_this() dereference linear address 0; recording that as an
     * anomaly is strictly better than corrupting whatever lives there,
     * and a non-zero count here would mean the AP handshake let a CPU
     * take interrupts before its CPU-local storage existed. */
    PerCpu *p = percpu_this_or_null();
    if (p == 0 || p->cpu_index >= PERCPU_MAX_CPUS) {
        __atomic_fetch_add(&g_anonymous, 1, __ATOMIC_RELAXED);
        lapic_send_eoi(lapic_dispatch_base());
        return;
    }

    TlbSlot *s = &g_slots[p->cpu_index];

    /* ACQUIRE pairs with the initiator's RELEASE store of `requested`.
     * It is what guarantees the range fields read below are the ones that
     * belong to this generation and not the previous request's. */
    uint64_t req = __atomic_load_n(&s->requested, __ATOMIC_ACQUIRE);

    if (req == s->acked) {
        /* Nothing outstanding. Expected occasionally and not an error: a
         * broadcast reaches CPUs that a preceding targeted send already
         * served. Counted rather than ignored so that a flood of
         * unnecessary shootdown interrupts is visible. */
        __atomic_fetch_add(&g_stale, 1, __ATOMIC_RELAXED);
        lapic_send_eoi(lapic_dispatch_base());
        return;
    }

    uint64_t virt  = s->virt;
    uint64_t pages = s->pages;

    if (virt == TLB_REQUEST_FLUSH_ALL) {
        flush_local_all();
        s->pages_done += 1;
    } else {
        for (uint64_t i = 0; i < pages; i++) {
            invlpg_local(virt + i * PAGE_SIZE);
        }
        s->pages_done += pages;
    }
    s->serviced += 1;

    /* RELEASE, so that the invalidations above are complete before the
     * initiator can observe the acknowledgement. An initiator that saw
     * the ack while the invlpg had not retired would free a page frame
     * another CPU could still translate - which is the exact bug this
     * whole file exists to prevent. */
#if VEX_INJECTED(8)
    /* NEGATIVE CONTROL: the invalidation is performed but never
     * acknowledged. The initiator must therefore time out - BOUNDED, not
     * hung - and the TLB tests must catch the timeout. This is the
     * injection that proves the acknowledgement protocol is load-bearing
     * rather than decorative: without it, a shootdown that silently
     * failed to reach a CPU would be indistinguishable from one that
     * succeeded. See kernel/include/boot03_inject.h. */
    (void)req;
#else
    __atomic_store_n(&s->acked, req, __ATOMIC_RELEASE);
#endif

    /* Handlers own their EOI - see irq.h. Omitting it would leave this
     * CPU's in-service bit set and it would never receive another
     * shootdown, so it would acknowledge exactly one and then silently
     * stop invalidating anything. */
    lapic_send_eoi(lapic_dispatch_base());
}

TlbResult tlb_init(const SmpInfo *smp)
{
    if (smp == 0) return TLB_ERR_NOT_READY;

    IrqResult r = irq_register(TLB_SHOOTDOWN_VECTOR, tlb_shootdown_handler,
                               "tlb-shootdown");
    if (r != IRQ_OK) return TLB_ERR_NOT_READY;

    g_smp   = smp;
    g_ready = 1;
    return TLB_OK;
}

/* ------------------------------------------------------------------ *
 * Initiator.
 * ------------------------------------------------------------------ */

static int lock_acquire(void)
{
    for (uint32_t i = 0; i < TLB_LOCK_SPIN_BUDGET; i++) {
        if (__atomic_exchange_n(&g_lock, 1u, __ATOMIC_ACQUIRE) == 0) {
            return 1;
        }
        __asm__ volatile ("pause");
    }
    return 0;
}

static void lock_release(void)
{
    __atomic_store_n(&g_lock, 0u, __ATOMIC_RELEASE);
}

/* This CPU's index, or 0 if CPU-local storage is not up yet - which can
 * only be the case on the BSP during early boot, where 0 is correct. */
static uint32_t self_index(void)
{
    PerCpu *p = percpu_this_or_null();
    return (p != 0) ? p->cpu_index : 0;
}

/* Online CPUs other than this one. Used to decide whether a shootdown
 * needs to leave this CPU at all. */
static uint32_t count_remote_targets(void)
{
    if (g_smp == 0) return 0;

    uint32_t self = self_index();
    uint32_t n = 0;
    for (uint32_t i = 0; i < ACPI_MAX_CPUS; i++) {
        const CpuInfo *c = &g_smp->cpus[i];
        if (c->state != CPU_STATE_ONLINE) continue;
        if (c->percpu_index >= PERCPU_MAX_CPUS) continue;
        if (c->percpu_index == self) continue;
        n++;
    }
    return n;
}

/* The whole remote protocol, once the caller's own TLB is already
 * consistent and the range has been validated. */
static TlbResult shootdown_remote(uint64_t virt, uint64_t pages)
{
    uint32_t self = self_index();

    /* Take the lock BEFORE deciding who to notify, so the online set
     * cannot change under us between the decision and the sends. Note
     * that interrupts stay ENABLED while spinning here - deliberately,
     * so a CPU waiting to initiate still answers other CPUs' shootdowns.
     * That is what keeps two simultaneous initiators from livelocking. */
    if (!lock_acquire()) {
        __atomic_fetch_add(&g_timeouts, 1, __ATOMIC_RELAXED);
        return TLB_ERR_ACK_TIMEOUT;
    }

    /* Published generation per target, so the wait below compares against
     * the exact value this call wrote rather than re-reading a field
     * another initiator may have advanced. */
    uint64_t published[PERCPU_MAX_CPUS];
    uint32_t targets = 0;
    uint32_t target_index[PERCPU_MAX_CPUS];
    uint32_t target_apic[PERCPU_MAX_CPUS];

    for (uint32_t i = 0; i < ACPI_MAX_CPUS; i++) {
        const CpuInfo *c = &g_smp->cpus[i];

        /* ONLINE only, which by construction excludes the BSP (whose
         * state is CPU_STATE_BSP) and every CPU that failed to start.
         * Excluding offline CPUs is not an optimization: a CPU that never
         * came up has no TLB to invalidate and would never acknowledge,
         * so including it would turn every shootdown into a timeout. */
        if (c->state != CPU_STATE_ONLINE) continue;

        uint32_t idx = c->percpu_index;
        if (idx >= PERCPU_MAX_CPUS) continue;

        /* Skip the initiator itself even if it appears ONLINE - its TLB
         * was already invalidated directly by the caller, and asking it
         * to acknowledge its own request would be waiting for an
         * interrupt it cannot take while it is here. */
        if (idx == self) continue;

        TlbSlot *s = &g_slots[idx];
        s->virt  = virt;
        s->pages = pages;

        /* RELEASE: the range above must be visible before the generation
         * that advertises it. */
        uint64_t gen = s->requested + 1;
        __atomic_store_n(&s->requested, gen, __ATOMIC_RELEASE);

        published[targets]    = gen;
        target_index[targets] = idx;
        target_apic[targets]  = c->expected_apic_id;
        targets++;
    }

    if (targets == 0) {
        lock_release();
        return TLB_OK_LOCAL_ONLY;
    }

    __atomic_fetch_add(&g_remote_requests, targets, __ATOMIC_RELAXED);

    /* One broadcast beats N targeted sends once N > 1: each targeted send
     * carries its own delivery-status wait, so at 31 targets the
     * difference is 31 ICR round-trips versus one. */
    IpiResult ir;
    if (targets == 1) {
        ir = ipi_send(target_apic[0], TLB_SHOOTDOWN_VECTOR);
    } else {
        ir = ipi_broadcast_others(TLB_SHOOTDOWN_VECTOR);
    }

    if (ir != IPI_OK) {
        /* The requests are published but nobody was told. Left published
         * rather than rolled back: a later successful shootdown to the
         * same CPU will carry a higher generation and the receiver will
         * service both ranges' worth of invalidation, which is
         * conservative. Rolling back would race with a receiver that had
         * already started. */
        lock_release();
        return TLB_ERR_IPI_FAILED;
    }

    /* Wait for every target. Bounded, and with interrupts still enabled
     * so this CPU can service shootdowns aimed at it while it waits. */
    uint32_t acked = 0;
    for (uint32_t spin = 0; spin < TLB_ACK_SPIN_BUDGET && acked < targets;
         spin++) {
        acked = 0;
        for (uint32_t t = 0; t < targets; t++) {
            uint64_t a = __atomic_load_n(&g_slots[target_index[t]].acked,
                                         __ATOMIC_ACQUIRE);
            /* >= and not ==, because a concurrent initiator may already
             * have advanced this slot past our generation; that later
             * request's invalidation is a superset in the only sense that
             * matters - our range was invalidated on the way there. */
            if (a >= published[t]) acked++;
        }
        if (acked < targets) __asm__ volatile ("pause");
    }

    lock_release();

    __atomic_fetch_add(&g_acks, acked, __ATOMIC_RELAXED);

    if (acked < targets) {
        __atomic_fetch_add(&g_timeouts, targets - acked, __ATOMIC_RELAXED);
        return TLB_ERR_ACK_TIMEOUT;
    }
    return TLB_OK;
}

/* Counts only shootdowns that fully completed - every target acknowledged,
 * or there was nobody to tell. Published so that page-table reclamation
 * can PROVE a shootdown finished before it frees anything, rather than
 * assuming the call it made succeeded. See vmm.c. */
static TlbResult shootdown_inner(uint64_t virt, uint64_t pages, int flush_all);

static TlbResult shootdown(uint64_t virt, uint64_t pages, int flush_all)
{
    TlbResult r = shootdown_inner(virt, pages, flush_all);
    if (r == TLB_OK || r == TLB_OK_LOCAL_ONLY) {
        __atomic_fetch_add(&g_completed, 1, __ATOMIC_RELAXED);
    }
    return r;
}

static TlbResult shootdown_inner(uint64_t virt, uint64_t pages, int flush_all)
{
    __atomic_fetch_add(&g_initiated, 1, __ATOMIC_RELAXED);

    /* This CPU first, always, and before any of the checks that can
     * refuse. Even a refused remote shootdown leaves the initiator
     * self-consistent, so a caller that ignores the return value has a
     * correct local TLB rather than a corrupt one. */
    if (flush_all) {
        flush_local_all();
        __atomic_fetch_add(&g_full_flushes, 1, __ATOMIC_RELAXED);
    } else {
        for (uint64_t i = 0; i < pages; i++) {
            invlpg_local(virt + i * PAGE_SIZE);
        }
    }

    /* Before tlb_init(), or with no LAPIC, there is exactly one CPU
     * running and local invalidation IS the whole shootdown. Reported as
     * a distinct result so a caller can tell "nobody needed telling"
     * from "everybody was told", and permitted with interrupts disabled
     * because it cannot wait for anyone - which is what lets the
     * single-threaded boot path keep mapping pages before the first
     * `sti`. */
    if (!g_ready || g_smp == 0 || !g_smp->started) {
        return TLB_OK_LOCAL_ONLY;
    }

    /* WHETHER ANYBODY NEEDS TELLING IS DECIDED BEFORE THE INTERRUPT-STATE
     * GUARD, and the order is load-bearing rather than incidental.
     *
     * The guard below exists only because WAITING for another CPU with
     * interrupts disabled can livelock. If there is no other CPU to wait
     * for, there is nothing to livelock against, and refusing would be
     * refusing a shootdown that had already been fully performed by the
     * local invlpg above.
     *
     * That is not a hypothetical: on a uniprocessor boot, and on every
     * boot before the first `sti`, a mapping change is a complete
     * shootdown the moment the initiator invalidates its own TLB. Putting
     * the guard first made the layer reject those, which is how this was
     * found - the -smp 1 run failed while every multi-CPU run passed.
     *
     * The count here is advisory and taken without the lock; it can only
     * be stale in the direction of a CPU having come online, and
     * shootdown_remote() recounts under the lock before publishing
     * anything. A CPU cannot go offline in this kernel. */
    if (count_remote_targets() == 0) {
        return TLB_OK_LOCAL_ONLY;
    }

    /* REFUSED, not attempted. With interrupts disabled this CPU cannot
     * answer another initiator, so two concurrent shootdowns would each
     * spin out their whole budget. Refusing turns a livelock into an
     * error at the call site that can still be fixed. In particular this
     * catches any attempt to shoot down while holding the VMM lock, since
     * vmm_lock() clears IF. */
    if (!interrupts_enabled()) {
        return TLB_ERR_UNSAFE_CONTEXT;
    }

    return shootdown_remote(flush_all ? TLB_REQUEST_FLUSH_ALL : virt, pages);
}

TlbResult tlb_shootdown_range(uint64_t virt, uint32_t pages)
{
    if (pages == 0)                 return TLB_ERR_BAD_RANGE;
    if ((virt & (PAGE_SIZE - 1)))   return TLB_ERR_BAD_RANGE;

    /* Promoted to a full flush rather than rejected: a long invlpg loop
     * running inside an interrupt handler on every CPU is worse for the
     * system than one CR3 reload, and a caller with a big range should
     * not have to know the threshold. Always correct, only ever less
     * precise. */
    if (pages > TLB_MAX_RANGE_PAGES) {
        return shootdown(0, 1, 1);
    }
    return shootdown(virt, pages, 0);
}

TlbResult tlb_shootdown_page(uint64_t virt)
{
    return tlb_shootdown_range(virt, 1);
}

TlbResult tlb_shootdown_all(void)
{
    return shootdown(0, 1, 1);
}
