/*
 * Vex OS - kernel/include/gdt.h
 *
 * BOOT-02A: Vex OS's own GDT, replacing reliance on whatever GDT
 * UEFI firmware left active. Firmware-owned descriptor tables live in
 * memory the PMM may later reclaim (EfiBootServicesCode/Data regions
 * are NOT excluded from EfiConventionalMemory once ExitBootServices
 * has run on some firmware) - continuing to use them is fragile.
 * Establishing our own is a correctness requirement, not decoration.
 *
 * Layout (selectors are index*8, or index*8+3 for DPL3):
 *   0x00  null descriptor            (required by the architecture)
 *   0x08  kernel code (ring0)
 *   0x10  kernel data (ring0)
 *   0x18  user code   (ring3, placeholder - unused until BOOT-04)
 *   0x20  user data   (ring3, placeholder - unused until BOOT-04)
 *   0x28  TSS for CPU 0 (16 bytes, occupies two 8-byte slots)
 *   0x38  TSS for CPU 1        <-- KERNEL-01 Phase 1
 *   ...
 *   0x218 TSS for CPU 31
 *
 * User-mode selectors are placed now, even though nothing uses them
 * until Ring 3 exists (BOOT-04), specifically so selector numbering
 * never has to shift later - a change flagged and confirmed during
 * planning rather than decided silently.
 *
 * KERNEL-01 PHASE 1: PER-CPU TSS
 *
 *   BOOT-02C shared ONE TSS and deliberately omitted `ltr` on APs, so
 *   APs had no IST and no double-fault stack, and therefore could never
 *   safely enable interrupts. TLB shootdown needs APs to receive IPIs,
 *   which needs interrupts on APs, which needs this first.
 *
 *   Every CPU now gets its own Tss and its own #DF stack, described by
 *   its own 16-byte GDT descriptor, and loads it with `ltr`. A CPU only
 *   ever loads ITS OWN descriptor, so the architectural rule that a busy
 *   TSS cannot be loaded again is respected by construction rather than
 *   by convention.
 *
 *   SELECTOR NUMBERING. The descriptors are laid out uniformly as
 *   GDT_SEL_TSS_FOR(i) = 0x28 + i*16, which makes CPU 0's selector
 *   exactly 0x28 - the value BOOT-02A froze and GDT_SEL_TSS still names.
 *   The BSP therefore loads the identical selector it always loaded, and
 *   no pre-existing selector value moves. (An earlier sketch put the
 *   per-CPU block at 0x30 and left 0x28 as a separate legacy descriptor;
 *   that needed two descriptors for CPU 0 and a special case in the
 *   init loop. This is smaller and has no special case.)
 *
 *   Phase 1 does NOT enable interrupts on APs. It only makes doing so
 *   survivable. See docs/ROADMAP.md - that is Phase 2.
 */

#ifndef VEXOS_GDT_H
#define VEXOS_GDT_H

#include <stdint.h>

#define GDT_SEL_NULL        0x00
#define GDT_SEL_KERNEL_CODE 0x08
#define GDT_SEL_KERNEL_DATA 0x10
#define GDT_SEL_USER_CODE   (0x18 | 3)
#define GDT_SEL_USER_DATA   (0x20 | 3)
#define GDT_SEL_TSS         0x28   /* == GDT_SEL_TSS_FOR(0), the BSP's */

/* CPUs covered by the per-CPU TSS array. Kept equal to PERCPU_MAX_CPUS
 * (and hence ACPI_MAX_CPUS) by a static assertion in gdt.c rather than
 * by hoping they match - an AP whose index exceeds this array would
 * otherwise load a descriptor describing nothing. */
#define GDT_MAX_CPUS 32

/* Index of the first GdtEntry slot used by TSS descriptors. Slots 0-4
 * are the null/code/data descriptors above. */
#define GDT_TSS_FIRST_SLOT 5

/* Selector for CPU `i`'s TSS. Each 64-bit TSS descriptor is 16 bytes,
 * i.e. two 8-byte GDT slots, so consecutive CPUs are 16 apart. */
#define GDT_SEL_TSS_FOR(i) \
    ((uint16_t)((GDT_TSS_FIRST_SLOT * 8) + (uint32_t)(i) * 16u))

/* Total GdtEntry-sized slots: 5 fixed + 2 per CPU. */
#define GDT_TOTAL_SLOTS (GDT_TSS_FIRST_SLOT + 2 * GDT_MAX_CPUS)

/* Size of each CPU's dedicated #DF stack. One 4 KiB page, matching the
 * single shared stack BOOT-02A used, so the BSP's double-fault stack is
 * the same size it has always been.
 *
 * NOTE, honestly: these stacks are plain .bss arrays with NO guard page.
 * kstack.c can produce guarded stacks, but it needs the PMM and the VMM,
 * and gdt_init() runs before pmm_init() - the BSP must have a valid IST
 * before there is an allocator at all. Overflowing a #DF stack is
 * therefore still silent corruption. Recorded as a known limitation
 * rather than papered over; moving IST stacks onto guarded pages is a
 * later, separable change. */
#define GDT_DF_STACK_SIZE 4096

/* IST slot reserved for #DF (double fault). A double fault often
 * means the current stack is unusable (e.g. it overflowed) - taking
 * the fault on a completely separate, known-good stack via IST is
 * the only way to have any chance of reporting it instead of
 * silently triple-faulting. This is the one piece of BOOT-02A that
 * goes slightly beyond the literal "GDT+IDT+exceptions+PMM" list,
 * included because a "safe kernel foundation" that can't survive its
 * own stack overflowing isn't actually safe - see docs/BOOT-02A.md
 * for the explicit call-out of this as an architectural assumption. */
#define TSS_IST_DOUBLE_FAULT 1

typedef struct __attribute__((packed)) {
    uint16_t limit_low;
    uint16_t base_low;
    uint8_t  base_mid;
    uint8_t  access;
    uint8_t  granularity;
    uint8_t  base_high;
} GdtEntry;

typedef struct __attribute__((packed)) {
    uint16_t length;
    uint16_t base_low;
    uint8_t  base_mid;
    uint8_t  access;
    uint8_t  granularity;
    uint8_t  base_high;
    uint32_t base_upper;
    uint32_t reserved;
} GdtTssEntry;

typedef struct __attribute__((packed)) {
    uint16_t limit;
    uint64_t base;
} GdtPtr;

typedef struct __attribute__((packed)) {
    uint32_t reserved0;
    uint64_t rsp0;
    uint64_t rsp1;
    uint64_t rsp2;
    uint64_t reserved1;
    uint64_t ist1;
    uint64_t ist2;
    uint64_t ist3;
    uint64_t ist4;
    uint64_t ist5;
    uint64_t ist6;
    uint64_t ist7;
    uint64_t reserved2;
    uint16_t reserved3;
    uint16_t iomap_base;
} Tss;

/* Builds the GDT, every CPU's TSS and #DF stack, and every per-CPU TSS
 * descriptor; then loads the GDTR and this CPU's (the BSP's, index 0)
 * task register. Must run on the BSP before any AP is started, because
 * APs read the descriptors it writes. */
void gdt_init(void);

/* Returns the CS selector currently active - used by kernel_entry as
 * the concrete, checkable proof that gdt_flush() actually took
 * effect (expected value: GDT_SEL_KERNEL_CODE, 0x08). */
uint16_t gdt_read_cs(void);

/* BOOT-02C: makes the CALLING CPU use the GDT the BSP already built,
 * and reloads its segment registers and CS accordingly.
 *
 * KERNEL-01 PHASE 1: this now ALSO executes `ltr` with the calling
 * CPU's own TSS selector, which BOOT-02C deliberately did not do.
 *
 * The original reasoning for omitting it was correct and is worth
 * keeping visible: a TSS holds one set of RSP0/IST pointers, the CPU
 * marks a TSS busy when it is loaded, so loading the SAME TSS on a
 * second CPU is architecturally invalid, and two CPUs sharing one IST
 * stack would corrupt each other the moment both took a double fault.
 * None of that has stopped being true - what changed is that each CPU
 * now has its own TSS and its own #DF stack, so `ltr` is loading a
 * distinct, unbusied descriptor on every CPU.
 *
 * `cpu_index` must be the same index the caller uses for percpu and for
 * SmpInfo.cpus[], so that all three views of "which CPU is this" agree.
 * Out-of-range indices are refused: the GDTR is still loaded (a CPU with
 * no GDT is worse than one with no TSS) but `ltr` is skipped and 0 is
 * returned, leaving the caller to decide what to do rather than loading
 * a descriptor that describes nothing.
 *
 * Returns 1 if both the GDTR and the task register were loaded.
 *
 * Still does NOT enable interrupts and does not unmask any interrupt
 * source. Phase 1 makes interrupts on APs survivable, not enabled. */
int gdt_load_on_this_cpu(uint32_t cpu_index);

/* ---------------------------------------------------------------- *
 * KERNEL-01 Phase 1 introspection, for the self-tests.
 *
 * These exist so a test can ask the HARDWARE what happened rather than
 * trusting that the code which was supposed to run did run. "We called
 * ltr" and "the task register holds the right selector" are different
 * claims, and only the second one is evidence.
 * ---------------------------------------------------------------- */

/* The task register selector currently loaded on the CALLING CPU, via
 * `str`. Zero means no TSS is loaded. */
uint16_t gdt_read_tr(void);

/* CPU `i`'s TSS, or NULL if out of range. Read by the BSP for
 * diagnostics and by the tests to check IST1 distinctness. */
const Tss *gdt_tss_for(uint32_t i);

/* SECURITY-02: sets CPU `i`'s TSS.rsp0 (the Ring 3 -> Ring 0 stack).
 * Returns 1 on success, 0 (and changes nothing) if i is out of range or
 * rsp0 is zero, misaligned, or non-canonical. */
int gdt_set_rsp0(uint32_t cpu_index, uint64_t rsp0);

/* CPU `i`'s IST1 (#DF stack top) as recorded in its TSS, or 0 if out of
 * range. Convenience wrapper so tests do not each repeat the range
 * check. */
uint64_t gdt_ist1_for(uint32_t i);

/* The TSS base address DECODED BACK OUT of the GDT descriptor named by
 * GDT_SEL_TSS_FOR(i) - not the address we intended to write, but the
 * address the descriptor actually encodes, reassembled from its five
 * scattered base fields. Returns 0 if `i` is out of range.
 *
 * This exists because the 64-bit TSS descriptor splits its base across
 * base_low/base_mid/base_high/base_upper, and a shifting mistake in
 * tss_set_entry() would produce a descriptor that loads without
 * faulting yet points somewhere else entirely. Comparing this against
 * gdt_tss_for(i) is what turns "CPU i loaded selector 0x28+16i" into
 * "CPU i loaded CPU i's TSS". */
uint64_t gdt_tss_descriptor_base(uint32_t i);

/* The type/access byte of that same descriptor, so a test can confirm it
 * is a present, DPL0, available 64-bit TSS (0x89) rather than merely
 * something the CPU tolerated. Returns 0 if `i` is out of range. */
uint8_t gdt_tss_descriptor_access(uint32_t i);

/* Bytes of .bss occupied by the per-CPU TSS array plus every #DF stack.
 * Printed at boot and checked against VEX_KERNEL_RESERVE_BYTES, because
 * this is the change that made those stacks 32x larger. */
uint64_t gdt_percpu_footprint_bytes(void);

#endif /* VEXOS_GDT_H */
