/* VEXOS-NATIVE-1: freestanding string runtime for natively compiled VexScript.
 * No libc, no allocation, no globals. A VexScript `string` is a pointer to a
 * NUL-terminated byte sequence (the native backend's existing representation).
 * Every function tolerates NULL (treated as ""), so a bad handle cannot fault.
 * Shared by the Vex OS kernel build and the host test harness. */
#include <stdint.h>
static int64_t vs_len(const char *s) { int64_t n = 0; if (!s) return 0; while (s[n]) n++; return n; }
int64_t vex_rt_str_len(const char *s) { return vs_len(s); }
int64_t vex_rt_str_eq(const char *a, const char *b)
{
    if (a == b) return 1;
    if (!a) a = "";
    if (!b) b = "";
    while (*a && *a == *b) { a++; b++; }
    return *a == *b;
}
int64_t vex_rt_str_starts_with(const char *s, const char *p)
{
    if (!s) s = "";
    if (!p) p = "";
    while (*p) { if (*s != *p) return 0; s++; p++; }
    return 1;
}
int64_t vex_rt_str_ends_with(const char *s, const char *p)
{
    int64_t ls = vs_len(s), lp = vs_len(p);
    if (lp > ls) return 0;
    return vex_rt_str_eq(s + (ls - lp), p ? p : "");
}
int64_t vex_rt_str_contains(const char *s, const char *sub)
{
    if (!s) s = "";
    if (!sub) sub = "";
    if (!*sub) return 1;
    for (; *s; s++) if (vex_rt_str_starts_with(s, sub)) return 1;
    return 0;
}
/* byte value 0..255, or -1 if out of range */
int64_t vex_rt_str_char_at(const char *s, int64_t i)
{
    int64_t n = vs_len(s);
    if (i < 0 || i >= n) return -1;
    return (int64_t)(uint8_t)s[i];
}
/* returns s + n (clamped to the terminating NUL): lets VexScript pass "the rest of the line" without allocating */
const char *vex_rt_str_skip(const char *s, int64_t n)
{
    if (!s) return "";
    int64_t l = vs_len(s); if (n < 0) n = 0; if (n > l) n = l;
    return s + n;
}
