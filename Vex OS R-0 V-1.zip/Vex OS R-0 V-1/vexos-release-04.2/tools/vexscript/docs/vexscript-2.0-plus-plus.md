# VexScript 2.0+++

Language foundation for VEX AI (version **2.2.0**).

## Implemented
- `str` synonym for `string`
- String `+` concatenation
- String params/returns, equality
- `bool` with `&&` `||` `!`
- Arrays: `T[]`, literals `[...]`, index `a[i]`, `array_length`
- Structs with string fields
- Hosted IR path for the above
- Integration: `classify(input: str) -> str`

## Partially implemented
- Array assignment `a[i] = v` (not yet)
- Multi-dimensional arrays
- Native x86-64 full array/string object model

## Planned
- Growable vectors / push
- Generic collections
- Method syntax `str.equals` (functions `str_equals` available)
