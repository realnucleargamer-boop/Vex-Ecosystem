#include "desktop01_tests.h"
#include "accounts.h"
#include "apps.h"
#include "tz.h"
#include "keymap.h"
#include "input.h"
#include "vexui.h"
#include "vexterm_host.h"
#include "serial.h"
#include "crypto.h"
#include "vfs.h"
#include "cpuacct.h"

static Desktop01Results *R;
#define TINIT() do { acct_init(); acct_test_set_iters(4); } while (0)
static void check(int ok, const char *what)
{
    R->checks_run++;
    if (!ok) { R->checks_failed++; serial_puts("[test] DESKTOP-01: FAIL - "); serial_puts(what); serial_puts("\n"); }
}
static int seq(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return *a == *b; }
static int has(const char *h, const char *n) { for (; *h; h++) { int i = 0; while (n[i] && h[i] == n[i]) i++; if (!n[i]) return 1; } return 0; }

static void t_accounts(void)
{
    TINIT();
    check(acct_count() == 0 && acct_selected() == -1, "accounts: a fresh store is empty with nothing selected");
    check(acct_validate("") == ACCT_ERR_EMPTY && acct_validate("   ") == ACCT_ERR_EMPTY && acct_validate(0) == ACCT_ERR_EMPTY, "accounts: empty / whitespace-only / NULL rejected");
    check(acct_validate("ab") == ACCT_ERR_SHORT && acct_validate("abc") == ACCT_OK, "accounts: minimum length 3");
    check(acct_validate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa") == ACCT_OK && acct_validate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa") == ACCT_ERR_LONG, "accounts: maximum length 32 (33 rejected)");
    check(acct_validate("bad!name") == ACCT_ERR_CHAR && acct_validate("a/b") == ACCT_ERR_CHAR && acct_validate("_abc") == ACCT_ERR_CHAR && acct_validate("a\tb") == ACCT_ERR_CHAR, "accounts: invalid characters / leading symbol rejected");
    check(acct_validate(" abc") == ACCT_ERR_SPACE && acct_validate("abc ") == ACCT_ERR_SPACE && acct_validate("a  b") == ACCT_ERR_SPACE && acct_validate("a b") == ACCT_OK, "accounts: leading/trailing/double spaces rejected, single inner space allowed");
    check(acct_validate("Ana_1.x-y") == ACCT_OK, "accounts: letters, digits, _ . - accepted");
    char huge[400]; for (int i = 0; i < 399; i++) huge[i] = 'a'; huge[399] = 0;
    check(acct_validate(huge) == ACCT_ERR_LONG, "accounts: 399-char input rejected without overflow");
    check(acct_create("Vex") == ACCT_OK && acct_count() == 1 && acct_find("vex") == 0 && seq(acct_get(0)->display, "Vex") && seq(acct_get(0)->id, "vex"), "accounts: create keeps display name, id is lower-case, retrievable");
    check(acct_create("VEX") == ACCT_ERR_DUP && acct_create("vex") == ACCT_ERR_DUP && acct_count() == 1, "accounts: duplicates rejected case-insensitively");
    acct_test_fail_next_store(1);
    check(acct_create("Nexus") == ACCT_ERR_STORE && acct_count() == 1 && acct_find("nexus") == -1, "accounts: storage failure is reported and rolled back (no half-created account)");
    check(acct_create("Nexus") == ACCT_OK && acct_count() == 2, "accounts: retry after a storage failure succeeds");
    check(acct_select(1) && acct_selected() == 1 && !acct_select(2) && !acct_select(-1) && acct_selected() == 1, "accounts: selection updates; bad indices refused");
    check(!acct_backend()->persistent && has(acct_backend()->label, "temporary"), "accounts: backend is honestly labelled temporary / non-persistent");
    char nm[8]; int made = 0;
    for (int i = 0; i < 30; i++) { nm[0] = 'u'; nm[1] = 's'; nm[2] = (char)('a' + i / 10); nm[3] = (char)('0' + i % 10); nm[4] = 0; if (acct_create(nm) == ACCT_OK) made++; }
    check(acct_count() == ACCT_MAX && made == ACCT_MAX - 2 && acct_create("overflowx") == ACCT_ERR_FULL, "accounts: capped at 16, overflow refused");
}

static void t_time_keys_apps(void)
{
    RtcTime u = { 2026, 10, 13, 10, 39, 0 }, l;
    tz_utc_to_local(&u, &l);
    check(l.hour == 16 && l.minute == 9 && l.day == 13, "IST: 10:39 UTC -> 16:09 IST, same day (matches the reference screen)");
    u = (RtcTime){ 2026, 12, 31, 20, 0, 0 }; tz_utc_to_local(&u, &l);
    check(l.year == 2027 && l.month == 1 && l.day == 1 && l.hour == 1 && l.minute == 30, "IST: 31 Dec 20:00 UTC -> 1 Jan 01:30 IST (year rollover)");
    u = (RtcTime){ 2024, 2, 28, 19, 0, 0 }; tz_utc_to_local(&u, &l);
    check(l.month == 2 && l.day == 29 && l.hour == 0 && l.minute == 30, "IST: leap-year 28 Feb 19:00 UTC -> 29 Feb 00:30 IST");
    u = (RtcTime){ 2023, 2, 28, 19, 0, 0 }; tz_utc_to_local(&u, &l);
    check(l.month == 3 && l.day == 1, "IST: non-leap 28 Feb 19:00 UTC -> 1 Mar IST");
    u = (RtcTime){ 2026, 10, 13, 18, 29, 59 }; tz_utc_to_local(&u, &l);
    check(l.day == 13 && l.hour == 23 && l.minute == 59, "IST: 18:29 UTC is still the same IST day");
    u = (RtcTime){ 2026, 10, 13, 18, 30, 0 }; tz_utc_to_local(&u, &l);
    check(l.day == 14 && l.hour == 0 && l.minute == 0, "IST: 18:30 UTC is exactly midnight IST (date rolls over)");
    check(VEX_TZ_OFFSET_MIN == 330, "IST: offset is the single constant 330 minutes");

    check(vex_key_ascii(4, 0) == 'a' && vex_key_ascii(4, VEX_MOD_LSHIFT) == 'A' && vex_key_ascii(39, 0) == '0' && vex_key_ascii(30, VEX_MOD_RSHIFT) == '!', "keymap: letters, digits, shifted digits");
    check(vex_key_ascii(45, 0) == '-' && vex_key_ascii(45, VEX_MOD_LSHIFT) == '_' && vex_key_ascii(55, 0) == '.' && vex_key_ascii(56, VEX_MOD_LSHIFT) == '?' && vex_key_ascii(44, 0) == ' ', "keymap: punctuation and space");
    check(vex_key_ascii(VEX_KEY_ENTER, 0) == 0 && vex_key_ascii(VEX_KEY_ESCAPE, 0) == 0 && vex_key_ascii(200, 0) == 0, "keymap: non-printing keys produce no character");

    apps_tracker_reset();
    int hits[8];
    check(apps_registry_count() >= 1 && seq(apps_registry_get(0)->name, "Verminal") && apps_registry_get(0)->pinned, "apps: Verminal is the first pinned registry entry");
    check(apps_search("", hits, 8) >= 1 && apps_search("TERM", hits, 8) == 1 && apps_search("zzz", hits, 8) == 0 && apps_search("vermi", hits, 8) == 1, "apps: search is case-insensitive substring, empty lists all, no false hits");
    check(apps_session_begin() > 0 && apps_tracked_count() == 1 && seq(apps_tracked_get(0)->name, "Desktop") && seq(apps_tracked_get(0)->kind, "System"), "tracker: session tracks the Desktop (System)");
    int again = 0; uint32_t id1 = apps_launch(APP_ID_TERMINAL, &again);
    uint32_t id2 = apps_launch(APP_ID_TERMINAL, &again);
    check(id1 && id1 == id2 && again == 1 && apps_tracked_count() == 2, "tracker: relaunching returns the same instance (no duplicate growth)");
    apps_close(APP_ID_TERMINAL); apps_close(APP_ID_TERMINAL); apps_close(0);
    check(apps_tracked_count() == 1 && !apps_launch(999, 0), "tracker: close is idempotent, the Desktop entry cannot be closed, unknown apps refused");
    apps_session_end();
    check(apps_tracked_count() == 0, "tracker: session end clears everything");
}

/* ---- UI driving ---- */
static void key(VexKeyCode k, VexKeyAction a, uint16_t m) { VexKeyEvent e; e.key = k; e.action = a; e.modifiers = m; e.sequence = 0; vexui_handle_key(&e); }
static void tap(VexKeyCode k) { key(k, VEX_KEY_PRESS, 0); key(k, VEX_KEY_RELEASE, 0); }
static void typech(char c)
{
    uint16_t m = 0; VexKeyCode k = 0;
    if (c >= 'a' && c <= 'z') k = 4 + (c - 'a');
    else if (c >= 'A' && c <= 'Z') { k = 4 + (c - 'A'); m = VEX_MOD_LSHIFT; }
    else if (c >= '1' && c <= '9') k = 30 + (c - '1');
    else if (c == '0') k = 39;
    else if (c == ' ') k = 44; else if (c == '-') k = 45; else if (c == '.') k = 55; else if (c == '_') { k = 45; m = VEX_MOD_LSHIFT; }
    else if (c == '!') { k = 30; m = VEX_MOD_LSHIFT; }
    else if (c == '"') { k = 52; m = VEX_MOD_LSHIFT; }
    else if (c == '/') k = 56; else if (c == ',') k = 54; else if (c == '?') { k = 56; m = VEX_MOD_LSHIFT; }
    key(k, VEX_KEY_PRESS, m); key(k, VEX_KEY_RELEASE, m);
}
static void typestr(const char *s) { for (; *s; s++) typech(*s); }
static void mouse(int dx, int dy, uint8_t b) { VexMouseEvent e; e.dx = (int16_t)dx; e.dy = (int16_t)dy; e.buttons = b; e.sequence = 0; vexui_handle_mouse(&e); }
static void mv(int32_t x, int32_t y, uint8_t b) { mouse(x - vexui_pointer_x(), y - vexui_pointer_y(), b); }
static void click(int32_t x, int32_t y) { mv(x, y, 0); mv(x, y, 1); mv(x, y, 0); }
static void click_ctl(int c) { int32_t x, y, w, h; vexui_ctl_rect(c, &x, &y, &w, &h); click(x + w / 2, y + h / 2); }
static void click_item(int i) { int32_t x, y, w, h; vexui_popup_item_rect(i, &x, &y, &w, &h); click(x + w / 2, y + h / 2); }
static int ctl_of(int kind) { for (int i = 0; i < vexui_nctl(); i++) if (vexui_ctl_kind(i) == kind) return i; return -1; }
static void run_line(const char *s) { typestr(s); tap(VEX_KEY_ENTER); }
static int row_has(const char *needle)
{
    const char *ls[64]; int n = vth_visible(64, ls);
    for (int i = 0; i < n; i++) if (has(ls[i], needle)) return 1;
    return 0;
}

static void typestr(const char *s);
static void tap(VexKeyCode k);
static void fill_setup(const char *name, const char *pw) { typestr(name); tap(VEX_KEY_TAB); typestr(pw); tap(VEX_KEY_TAB); typestr(pw); }
static int strlen_(const char *s) { int n = 0; while (s[n]) n++; return n; }
static void t_setup_flow(void)
{
    TINIT(); apps_tracker_reset();
    vexui_test_begin(1280, 800, 1, 1);
    check(vexui_screen() == VEXUI_SETUP && vexui_ctl_kind(0) == VEXUI_CK_NAME && vexui_ctl_kind(1) == VEXUI_CK_CREATE, "setup: with no accounts the first-run screen is shown (name field + Create Account)");
    tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_SETUP && has(vexui_setup_message(), "empty") && acct_count() == 0, "setup: ENTER on an empty name is rejected with a visible message");
    tap(VEX_KEY_SPACE); tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_SETUP && acct_count() == 0, "setup: a whitespace-only name cannot bypass the screen");
    for (int i = 0; i < 3; i++) tap(VEX_KEY_BACKSPACE);
    typestr("ab"); tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_SETUP && has(vexui_setup_message(), "at least 3"), "setup: too-short name rejected with the reason");
    typestr("!"); tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_SETUP && acct_count() == 0, "setup: invalid character rejected");
    for (int i = 0; i < 5; i++) tap(VEX_KEY_BACKSPACE);
    for (int i = 0; i < 45; i++) typech('a');
    check((int)(sizeof(int)) && vexui_name_text()[38] == 'a' && vexui_name_text()[39] == 0, "setup: the field stops accepting input at its 39-char buffer (no overflow)");
    tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_SETUP && has(vexui_setup_message(), "at most 32") && acct_count() == 0, "setup: oversized name rejected");
    for (int i = 0; i < 60; i++) tap(VEX_KEY_BACKSPACE);
    check(vexui_name_text()[0] == 0, "setup: backspace clears the field safely (and past empty)");
    acct_test_fail_next_store(1); fill_setup("Vex", "secret1"); tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_SETUP && has(vexui_setup_message(), "try again") && acct_count() == 0, "setup: a storage failure shows the real error and stays on the setup screen");
    tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_LOCK && acct_count() == 1 && acct_selected() == 0 && seq(acct_get(0)->display, "Vex"), "setup: retry succeeds -> account created, selected, lock screen shown");
    vexui_test_end();

    TINIT(); vexui_test_begin(1280, 800, 1, 1);
    fill_setup("Bob", "secret1"); click_ctl(ctl_of(VEXUI_CK_CREATE));
    check(vexui_screen() == VEXUI_LOCK && acct_count() == 1, "setup: the Create Account button (mouse) creates the account");
    vexui_test_end();
}

static void t_lock_users(void)
{
    TINIT(); (void)acct_create("Vex"); (void)acct_create("Nexus"); (void)acct_create("Bob"); acct_select(0);
    vexui_test_begin(1280, 800, 1, 1);
    check(vexui_screen() == VEXUI_LOCK && vexui_nctl() == 4 && vexui_ctl_kind(1) == VEXUI_CK_USERS && vexui_ctl_kind(2) == VEXUI_CK_NET && vexui_ctl_kind(3) == VEXUI_CK_POWER, "lock: accounts exist -> lock screen with Sign in + exactly three utility buttons (Users, Internet, Power)");
    int32_t ux, uy, uw, uh, nx, ny, nw, nh, px, py, pw, ph; vexui_ctl_rect(1, &ux, &uy, &uw, &uh); vexui_ctl_rect(2, &nx, &ny, &nw, &nh); vexui_ctl_rect(3, &px, &py, &pw, &ph);
    check(uy == ny && ny == py && ux < nx && nx < px && px + pw <= 1280 && py + ph <= 800, "lock: the three buttons form one row in the lower-right, inside the screen");
    click_ctl(1);
    check(vexui_popup() == VEXUI_POPUP_USERS && vexui_popup_count() == 4, "users: Users opens the switch-user panel listing the 3 REAL accounts + Close");
    click_item(1);
    check(acct_selected() == 1 && vexui_popup() == VEXUI_POPUP_NONE && vexui_screen() == VEXUI_LOCK, "users: choosing Nexus updates the real selected account and returns to the lock screen");
    click_ctl(1); tap(VEX_KEY_ESCAPE);
    check(vexui_popup() == VEXUI_POPUP_NONE && acct_selected() == 1, "users: ESC dismisses the panel without changing the selection");
    click_ctl(1); click(5, 5);
    check(vexui_popup() == VEXUI_POPUP_NONE && acct_selected() == 1, "users: clicking outside dismisses the panel");
    click_ctl(1); click_item(3);
    check(vexui_popup() == VEXUI_POPUP_NONE, "users: Close dismisses the panel");
    tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_DESKTOP && vexui_session_user() == 1, "signin: ENTER signs in as the SELECTED account (Nexus) and shows the desktop");
    vexui_test_end();

    TINIT(); for (int i = 0; i < 10; i++) { char n[6] = { 'u', 's', 'r', (char)('a' + i), 0 }; (void)acct_create(n); } acct_select(0);
    vexui_test_begin(1280, 800, 1, 1);
    click_ctl(1);
    int32_t x, y, w, h;
    check(vexui_popup_count() == 11 && vexui_popup_item_rect(0, &x, &y, &w, &h) && w > 0 && vexui_popup_item_rect(9, &x, &y, &w, &h) && w == 0, "users: with 10 accounts only a scroll window is laid out (no overlap/corruption)");
    for (int i = 0; i < 9; i++) tap(VEX_KEY_DOWN);
    check(vexui_popup_focus() == 9 && vexui_popup_item_rect(9, &x, &y, &w, &h) && w > 0, "users: keyboard navigation scrolls the focused account into view");
    tap(VEX_KEY_ENTER);
    check(acct_selected() == 9, "users: ENTER selects the focused account");
    vexui_test_end();

    TINIT(); (void)acct_create("Vex"); acct_select(0);
    vexui_test_begin(1280, 800, 1, 1);
    click_ctl(2);
    check(vexui_popup() == VEXUI_POPUP_NET && vexui_popup_count() == 1, "internet: opens the status panel with no actions other than Close");
    tap(VEX_KEY_ESCAPE);
    click_ctl(3);
    check(vexui_popup() == VEXUI_POPUP_POWER && vexui_popup_focus() == VEXUI_PWR_CANCEL, "power: opens with Cancel focused");
    tap(VEX_KEY_UP); tap(VEX_KEY_ENTER);
    check(vexui_pending_action() == VEXUI_ACT_REBOOT, "power: Restart queues a restart request (executed only by vexui_poll)");
    vexui_clear_pending();
    vexui_test_end();
    vexui_test_begin(1280, 800, 0, 0);
    click_ctl(3); click_item(VEXUI_PWR_SHUTDOWN);
    check(vexui_pending_action() == VEXUI_ACT_NONE && !vexui_popup_item_enabled(VEXUI_PWR_SHUTDOWN) && !vexui_popup_item_enabled(VEXUI_PWR_REBOOT), "power: unsupported actions are disabled and cannot be triggered");
    vexui_test_end();
}

extern int64_t vex_os_timer_start(int64_t), vex_os_timer_stop(void), vex_os_timer_active(void);
static void t_timer_contract(void)
{
    vth_open();                                                   /* real compiled VexScript init: timer starts stopped */
    uint32_t st = vth_timer_starts(), sp = vth_timer_stops();
    check(!vex_os_timer_active() && vex_os_timer_start(1000) == 1 && vth_timer_active(), "timer service: first start succeeds");
    check(vex_os_timer_start(1000) == 0 && vex_os_timer_start(250) == 0 && vth_timer_starts() == st + 1, "timer service: a second start while active is REFUSED (never two timers, no count growth)");
    check(vex_os_timer_stop() == 1 && !vth_timer_active() && vex_os_timer_stop() == 0 && vth_timer_stops() == sp + 1, "timer service: stop works once; stopping again is a harmless no-op");
    check(vex_os_timer_start(50) == 0 && vex_os_timer_start(70000) == 0 && vex_os_timer_start(-1) == 0 && !vth_timer_active(), "timer service: period below 100 ms / above 60 s / negative is refused");
    check(vex_os_timer_start(100) == 1 && vex_os_timer_start(60000) == 0, "timer service: 100 ms is the accepted minimum");
    vth_close();
    check(!vth_timer_active() && vth_timer_stops() == sp + 2, "timer service: closing the app force-stops a running timer (no leak)");
}

static void t_desktop_terminal(void)
{
    TINIT(); (void)acct_create("Vex"); acct_select(0); apps_tracker_reset();
    vexui_test_begin(1280, 800, 1, 1);
    tap(VEX_KEY_SPACE);
    check(vexui_screen() == VEXUI_DESKTOP && apps_tracked_count() == 1, "desktop: SPACE on the lock screen signs in; the Desktop is tracked");
    check(vexui_ctl_kind(0) == VEXUI_CK_VBTN && vexui_ctl_kind(1) == VEXUI_CK_SEARCH && vexui_ctl_kind(2) == VEXUI_CK_TERM, "desktop: V button, search bar and pinned terminal are present");
    click_ctl(0);
    check(vexui_popup() == VEXUI_POPUP_VMENU && vexui_popup_count() == apps_registry_count() + 4, "V menu: opens with all pinned apps + Lock, Shut down, Restart + admin-only Add user");
    tap(VEX_KEY_ESCAPE);
    check(vexui_popup() == VEXUI_POPUP_NONE, "V menu: ESC closes it");
    click_ctl(0); typestr("zzz");
    check(vexui_popup() == VEXUI_POPUP_VMENU && vexui_popup_count() == 4, "V menu search: a non-matching query shows no app (accurate, nothing fabricated)");
    tap(VEX_KEY_BACKSPACE); tap(VEX_KEY_BACKSPACE); tap(VEX_KEY_BACKSPACE); typestr("TERM");
    check(vexui_popup_count() == 5, "V menu search: 'TERM' finds Verminal (case-insensitive)");
    tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_TERMINAL && vth_is_open() && apps_tracked_count() == 2, "V menu: selecting Verminal launches the VexScript app and tracks it");

    check(row_has("Verminal  (VexScript") && row_has("v. help"), "terminal: the VexScript app printed its banner");
    run_line("v. help");
    check(row_has("v. help") && row_has("v. processes") && row_has("v. input test") && row_has("Esc"), "terminal: `v. help` (VexScript) lists all three commands and how to go back/exit");
    run_line("  v.   help ");
    run_line("nonsense");
    check(row_has("Unknown command. Type `v. help` for available commands."), "terminal: unknown command gets guidance");
    uint32_t st0 = vth_timer_starts(), sp0 = vth_timer_stops();
    run_line("v. processes");
    check(vth_view() == 1 && vth_timer_active() && vth_timer_starts() == st0 + 1, "processes: view opens and exactly one 1000 ms timer starts");
    check(row_has("Desktop") && row_has("Verminal") && row_has("System") && row_has("2 application(s)"), "processes: shows the tracked apps from the real tracker (Desktop + Verminal), not fake PIDs");
    uint32_t f0 = vth_timer_fires();
    for (int i = 0; i < 3; i++) { uint64_t t0 = 0; (void)t0; }
    tap(VEX_KEY_ESCAPE);
    check(vth_view() == 0 && !vth_timer_active() && vth_timer_stops() == sp0 + 1 && vth_timer_fires() == f0, "processes: Esc returns to the terminal and stops the timer");
    for (int i = 0; i < 20; i++) { run_line("v. processes"); tap(VEX_KEY_ESCAPE); }
    check(!vth_timer_active() && vth_timer_starts() - st0 == 21 && vth_timer_stops() - sp0 == 21, "processes: 20 more open/close cycles - starts == stops, no timer left running");
    run_line("v. input test");
    check(vth_view() == 2, "input test: view opens");
    typestr("Hello, VEX OS! 123_-./?");
    check(seq(vth_prompt_text(), "Hello, VEX OS! 123_-./?"), "input test: letters, digits, spaces, punctuation echo exactly");
    tap(VEX_KEY_BACKSPACE); tap(VEX_KEY_BACKSPACE);
    check(seq(vth_prompt_text(), "Hello, VEX OS! 123_-."), "input test: backspace edits the text");
    tap(VEX_KEY_ENTER);
    check(row_has("You typed: Hello, VEX OS! 123_-.") && vth_prompt_text()[0] == 0, "input test: Enter submits and clears");
    for (int i = 0; i < 300; i++) typech('x');
    check(vth_prompt_text()[VTH_BUF_MAX] == 0 && vth_prompt_text()[VTH_BUF_MAX - 1] == 'x', "input test: 300 characters cannot overflow the bounded buffer");
    tap(VEX_KEY_ESCAPE); run_line("v. input test");
    check(vth_view() == 2, "input test: repeatable without reboot");
    tap(VEX_KEY_ESCAPE);
    for (int i = 0; i < 300; i++) { run_line("bogus"); run_line("v. help"); }
    check(vexui_screen() == VEXUI_TERMINAL && vth_view() == 0, "terminal: 600 mixed commands, scrollback bounded, still responsive");
    run_line("v. exit");
    check(vexui_screen() == VEXUI_DESKTOP && !vth_is_open() && !vth_timer_active() && apps_tracked_count() == 1, "terminal: `v. exit` returns to the desktop, closes the app, tracker back to Desktop only");

    click_ctl(ctl_of(VEXUI_CK_TERM));
    check(vexui_screen() == VEXUI_TERMINAL && apps_tracked_count() == 2, "taskbar: the pinned terminal icon launches the app");
    tap(VEX_KEY_ESCAPE);
    check(vexui_screen() == VEXUI_DESKTOP && apps_tracked_count() == 1, "terminal: Esc closes it (no duplicate instance left behind)");
    click_ctl(ctl_of(VEXUI_CK_SEARCH));
    check(vexui_popup() == VEXUI_POPUP_SEARCH, "search bar: clicking opens results");
    typestr("vex");
    check(vexui_popup_count() == 1 && seq(vexui_search_text(), "vex"), "search bar: query 'vex' lists exactly the matching app");
    tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_TERMINAL, "search bar: ENTER launches the first match");
    run_line("v. exit");
    click_ctl(0); click_item(apps_registry_count());
    check(vexui_screen() == VEXUI_LOCK, "V menu: clicking Lock (item after the 3 apps) locks");
    vexui_test_end();

    vexui_test_begin(1280, 800, 1, 1);
    tap(VEX_KEY_ENTER);
    click_ctl(0); click_item(apps_registry_count());                     /* Lock is item na == 3 (three pinned apps) */
    check(vexui_screen() == VEXUI_LOCK && vexui_session_user() == -1 && apps_tracked_count() == 0, "lock: V menu -> Lock returns to the lock screen, session ends, tracker emptied");
    tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_DESKTOP, "lock: signing in again works");
    click_ctl(0); click_item(apps_registry_count() + 1);
    check(vexui_pending_action() == VEXUI_ACT_SHUTDOWN, "V menu: Shut down queues a shutdown request"); vexui_clear_pending();
    vexui_test_end();
}


static const char *hexs(const uint8_t *b)
{
    static char h[65]; static const char d[] = "0123456789abcdef";
    for (int i = 0; i < 32; i++) { h[2 * i] = d[b[i] >> 4]; h[2 * i + 1] = d[b[i] & 15]; } h[64] = 0; return h;
}
static int contains_bytes(const void *hay, int hn, const char *needle)
{
    const uint8_t *h = hay; int nl = 0; while (needle[nl]) nl++;
    for (int i = 0; i + nl <= hn; i++) { int k = 0; while (k < nl && h[i + k] == (uint8_t)needle[k]) k++; if (k == nl) return 1; }
    return 0;
}
static void t_crypto_auth(void)
{
    uint8_t o[32]; Sha256 c;
    sha256_init(&c); sha256_update(&c, "abc", 3); sha256_final(&c, o);
    check(seq(hexs(o), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"), "crypto: SHA-256(\"abc\") matches the FIPS 180 vector");
    pbkdf2_hmac_sha256((const uint8_t *)"password", 8, (const uint8_t *)"salt", 4, 1, o);
    check(seq(hexs(o), "120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b"), "crypto: PBKDF2-HMAC-SHA256 (c=1) known-answer vector");
    pbkdf2_hmac_sha256((const uint8_t *)"password", 8, (const uint8_t *)"salt", 4, 4096, o);
    check(seq(hexs(o), "c5e478d59288c841aa530db6845c4c8d962893a001ce4e11a4963873aa98134a"), "crypto: PBKDF2-HMAC-SHA256 (c=4096) known-answer vector");
    hmac_sha256((const uint8_t *)"key", 3, (const uint8_t *)"The quick brown fox jumps over the lazy dog", 43, o);
    check(seq(hexs(o), "f7bc83f430538424b13298e6aa6fb143ef4d59a14946175997479dbc2d1a3cd8"), "crypto: HMAC-SHA256 known-answer vector");
    uint8_t a1[4] = {1,2,3,4}, a2[4] = {1,2,3,4}, a3[4] = {1,2,3,5};
    check(ct_equal(a1, a2, 4) && !ct_equal(a1, a3, 4), "crypto: constant-time compare");

    TINIT();
    check(acct_create_pw("Alpha", "short", -1) == ACCT_ERR_PWSHORT && acct_create_pw("Alpha", "alpha\x01zz", -1) == ACCT_ERR_PWCHAR && acct_count() == 0, "auth: password policy (>=6, printable ASCII) enforced; nothing created on rejection");
    check(acct_create_pw("Alpha", "alpha123", -1) == ACCT_OK && acct_role(0) == ACCT_ROLE_ADMIN && acct_has_password(0), "auth: first-run account is the administrator and has a password");
    check(acct_create_pw("Bravo", "bravo456", -1) == ACCT_ERR_DENIED && acct_create_pw("Bravo", "bravo456", 0) == ACCT_ERR_DENIED && acct_count() == 1, "auth: a second account cannot be created anonymously or by an UNAUTHENTICATED admin (enforced in the store)");
    check(!acct_login(0, "wrongpass") && acct_active() == -1 && !acct_login(0, "") && acct_active() == -1, "auth: wrong or empty password is rejected and establishes no identity");
    check(acct_login(0, "alpha123") && acct_active() == 0, "auth: correct password logs in");
    check(acct_create_pw("Bravo", "bravo456", 0) == ACCT_OK && acct_role(1) == ACCT_ROLE_STANDARD && acct_count() == 2, "auth: authenticated admin creates a standard user (account B)");
    check(acct_create_pw("alpha", "otherpw1", 0) == ACCT_ERR_DUP && acct_count() == 2, "auth: duplicate username rejected (case-insensitive)");
    acct_logout();
    check(acct_active() == -1 && acct_login(1, "bravo456") && acct_active() == 1 && !acct_login(1, "alpha123") && acct_active() == -1, "auth: B logs in with B's password; A's password does not work for B; failed login clears identity");
    check(acct_login(1, "bravo456") && acct_create_pw("Carol", "carol789", 1) == ACCT_ERR_DENIED && acct_count() == 2, "auth: a standard user is REFUSED admin-only account creation");
    check(acct_login(0, "alpha123") && acct_active() == 0 && acct_active() != 1, "auth: switching accounts changes the active identity (no carry-over)");
    check(!contains_bytes(acct_get(0), (int)sizeof(Account), "alpha123") && !contains_bytes(acct_get(1), (int)sizeof(Account), "bravo456"), "auth: no plaintext password appears anywhere in the stored account records");
    check(acct_get(0)->iters >= 1 && !(acct_get(0)->hash[0] == 0 && acct_get(0)->hash[1] == 0 && acct_get(0)->hash[2] == 0 && acct_get(0)->hash[3] == 0), "auth: a derived key and iteration count are stored");
    TINIT(); acct_test_set_iters(4); (void)acct_create_pw("Aaaa", "samepass1", -1); (void)acct_login(0, "samepass1"); (void)acct_create_pw("Bbbb", "samepass1", 0);
    check(!ct_equal(acct_get(0)->salt, acct_get(1)->salt, 16) && !ct_equal(acct_get(0)->hash, acct_get(1)->hash, 32), "auth: two accounts with the SAME password get different salts and hashes");
    check(acct_verify(0, "samepass1") && acct_verify(1, "samepass1") && !acct_verify(0, "samepass2") && !acct_verify(7, "x") && !acct_verify(-1, "x"), "auth: verify accepts the right password, rejects others and bad indices");
}

static void t_vfs_cpu(void)
{
    vfs_init();
    int tmp = vfs_resolve("/tmp"), home = vfs_resolve("/home");
    check(tmp > 0 && home > 0 && vfs_resolve("/") == 0 && vfs_resolve("/nope") == VFS_ERR_NOTFOUND, "vfs: root, /home and /tmp exist; unknown paths report not-found");
    check(vfs_resolve("/home/../tmp") == VFS_ERR_PATH && vfs_resolve("..") == VFS_ERR_PATH && vfs_resolve("/tmp/./x") == VFS_ERR_PATH, "vfs: '..', '.' and relative paths are rejected (no traversal)");
    check(!vfs_persistent(), "vfs: reports itself as NOT persistent");
    int f = vfs_create(tmp, "notes.txt", 0, 1001, 0);
    check(f > 0 && seq(vfs_node(f)->name, "notes.txt") && !vfs_node(f)->is_dir && vfs_node(f)->owner_uid == 1001, "vfs: a standard user creates a file in world-writable /tmp");
    int n0 = vfs_count();
    check(vfs_create(tmp, "notes.txt", 0, 1002, 0) == VFS_ERR_EXISTS && vfs_count() == n0, "vfs: an existing name is refused and nothing is overwritten or duplicated");
    check(vfs_create(tmp, "a/b", 0, 1, 1) == VFS_ERR_NAME && vfs_create(tmp, "..", 0, 1, 1) == VFS_ERR_NAME && vfs_create(tmp, "", 0, 1, 1) == VFS_ERR_NAME && vfs_create(tmp, " x", 0, 1, 1) == VFS_ERR_NAME
          && vfs_create(tmp, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0, 1, 1) == VFS_ERR_NAME && vfs_create(tmp, "x\ty", 0, 1, 1) == VFS_ERR_NAME && vfs_count() == n0, "vfs: invalid names (slash, '..', empty, leading space, 33 chars, control char) rejected, no entry created");
    check(vfs_create(0, "evil", 0, 1001, 0) == VFS_ERR_DENIED && vfs_create(home, "evil", 0, 1001, 0) == VFS_ERR_DENIED, "vfs: a standard user cannot write in '/' or in the admin-owned /home");
    int h1 = vfs_ensure_home(1001, "alpha"), h2 = vfs_ensure_home(1002, "bravo");
    check(h1 > 0 && h2 > 0 && vfs_create(h2, "mine", 0, 1001, 0) == VFS_ERR_DENIED && vfs_create(h1, "mine", 0, 1001, 0) > 0, "vfs: users can write in their own home and NOT in another user's");
    check(vfs_create(h2, "by-admin", 0, 1, 1) > 0, "vfs: an administrator may write anywhere");
    check(vfs_create(f, "x", 0, 1, 1) == VFS_ERR_NOTDIR && vfs_create(99, "x", 0, 1, 1) == VFS_ERR_NOTFOUND, "vfs: a file is not a folder; missing folder reported");
    int ls[64]; int k = vfs_list(h1, ls, 64); char pth[64];
    check(k == 1 && seq(vfs_node(ls[0])->name, "mine") && vfs_path(ls[0], pth, sizeof pth) > 0 && seq(pth, "/home/alpha/mine") && vfs_parent(0) == 0 && vfs_parent(ls[0]) == h1, "vfs: listing, absolute path and parent are correct");
    int made = 0, last = 0; char nm[8]; for (int i = 0; i < 200; i++) { nm[0] = 'f'; nm[1] = (char)('a' + i / 26 % 26); nm[2] = (char)('a' + i % 26); nm[3] = 0; last = vfs_create(tmp, nm, 0, 1, 1); if (last > 0) made++; else break; }
    check(last == VFS_ERR_FULL && made > 50 && vfs_resolve("/tmp/notes.txt") == f, "vfs: pool exhaustion returns VFS_ERR_FULL and earlier files are intact");
    vfs_init();
    check(cpuacct_permille(1000, 250) == 750 && cpuacct_permille(1000, 0) == 1000 && cpuacct_permille(1000, 1000) == 0 && cpuacct_permille(0, 0) == 0 && cpuacct_permille(1000, 2000) == 0, "cpu: busy fraction = (elapsed-idle)/elapsed, clamped to 0..1000 permille");
    check(cpuacct_permille(1ull << 62, 1ull << 61) == 500 && cpuacct_permille(~0ull, 0) == 1000, "cpu: no overflow on very large TSC deltas");
}


static void rclick(int32_t x, int32_t y) { mv(x, y, 0); mv(x, y, 2); mv(x, y, 0); }
static void ctl_xy(int c, int32_t *x, int32_t *y) { int32_t w, h; vexui_ctl_rect(c, x, y, &w, &h); *x += w / 2; *y += h / 2; }
static int row_ctl_for(int node) { for (int i = 0; i < vexui_nctl(); i++) if (vexui_ctl_kind(i) == VEXUI_CK_XROW && vexui_explorer_entry(i - 4) == node) return i; return -1; }
static void r3_login(void)
{
    TINIT(); vfs_init(); apps_tracker_reset(); vth_close();
    (void)acct_create_pw("Alpha", "alpha123", -1); (void)acct_login(0, "alpha123"); (void)acct_create_pw("Bravo", "bravo456", 0); acct_logout(); acct_select(0);
    vexui_test_begin(1280, 800, 1, 1); typestr("alpha123"); tap(VEX_KEY_ENTER);
}
static void t_release03_typing(void)
{
    uint32_t h0;
    TINIT(); vexui_test_begin(1280, 800, 1, 1);                       /* no accounts: first-run screen */
    h0 = vexui_heavy_redraws(); typestr("Alphaname"); tap(VEX_KEY_TAB); typestr("secret12"); tap(VEX_KEY_TAB); typestr("secret12"); tap(VEX_KEY_BACKSPACE); tap(VEX_KEY_BACKSPACE);
    check(vexui_heavy_redraws() == h0 && seq(vexui_name_text(), "Alphaname"), "typing: first-run name/password/confirm fields (type + backspace) cause NO full or region redraw");
    vexui_test_end();
    TINIT(); (void)acct_create_pw("Alpha", "alpha123", -1); acct_select(0); vexui_test_begin(1280, 800, 1, 1);
    h0 = vexui_heavy_redraws(); typestr("wrong"); tap(VEX_KEY_BACKSPACE); tap(VEX_KEY_ENTER); typestr("zz");
    check(vexui_heavy_redraws() == h0, "typing: lock-screen password (type, backspace, rejected sign-in message, retype) causes no heavy redraw");
    vexui_test_end();
    r3_login();
    click_ctl(ctl_of(VEXUI_CK_SEARCH)); h0 = vexui_heavy_redraws(); typestr("abc"); tap(VEX_KEY_BACKSPACE);
    check(vexui_heavy_redraws() == h0, "typing: desktop search bar + results list: no heavy redraw"); tap(VEX_KEY_ESCAPE);
    click_ctl(0); h0 = vexui_heavy_redraws(); typestr("va"); tap(VEX_KEY_BACKSPACE);
    check(vexui_heavy_redraws() == h0, "typing: V-menu search box: no heavy redraw"); tap(VEX_KEY_ESCAPE);
    click_ctl(ctl_of(VEXUI_CK_TERM)); vexui_poll(); h0 = vexui_heavy_redraws(); typestr("abcdefgh"); vexui_poll(); tap(VEX_KEY_BACKSPACE); vexui_poll();
    check(vexui_heavy_redraws() == h0, "typing: Verminal prompt: only the prompt row is invalidated (no terminal-output redraw)");
    tap(VEX_KEY_ESCAPE);
    click_ctl(ctl_of(VEXUI_CK_EXPL)); click_ctl(3); h0 = vexui_heavy_redraws(); typestr("abcdef"); tap(VEX_KEY_BACKSPACE);
    check(vexui_heavy_redraws() == h0, "typing: Explorer file-name dialog: no heavy redraw"); tap(VEX_KEY_ESCAPE); tap(VEX_KEY_ESCAPE);
    click_ctl(ctl_of(VEXUI_CK_VALB)); h0 = vexui_heavy_redraws(); typestr("hello world"); tap(VEX_KEY_ENTER); typestr("line2"); tap(VEX_KEY_BACKSPACE); tap(VEX_KEY_LEFT);
    check(vexui_heavy_redraws() == h0 && has(vexui_valbook_text(), "hello world\nline"), "typing: Valbook editing incl. newline/backspace/cursor moves: only text lines are invalidated");
    vexui_test_end();
}
static void t_release03_valbook_explorer(void)
{
    char buf[200]; r3_login(); vfs_ensure_home(1000, "alpha");
    click_ctl(ctl_of(VEXUI_CK_VALB));
    check(vexui_screen() == VEXUI_VALBOOK && !vexui_valbook_modified() && vexui_valbook_node() < 0, "valbook: opens with a new empty document");
    typestr("hi"); tap(VEX_KEY_BACKSPACE);
    check(seq(vexui_valbook_text(), "h") && vexui_valbook_modified(), "valbook: typing and Backspace edit the text; the document is marked modified");
    click_ctl(ctl_of(VEXUI_CK_VBSAVE)); typestr("doc.txt"); tap(VEX_KEY_ENTER);
    int n = vfs_resolve("/home/alpha/doc.txt");
    check(n > 0 && vexui_valbook_node() == n && !vexui_valbook_modified() && vfs_read(n, buf, sizeof buf) == 1 && buf[0] == 'h', "valbook: Save (untitled) asks for a name, creates the file through the VFS and writes its content");
    typestr("!"); key(22, VEX_KEY_PRESS, VEX_MOD_LCTRL); key(22, VEX_KEY_RELEASE, 0);
    check(vfs_read(n, buf, sizeof buf) == 2 && seq(buf, "h!") && !vexui_valbook_modified(), "valbook: Ctrl+S saves changes to the existing file");
    click_ctl(ctl_of(VEXUI_CK_VBSAVE)); typestr("x"); click_ctl(0);
    check(vexui_screen() == VEXUI_VALBOOK && apps_running(APP_ID_VALBOOK), "valbook: closing with unsaved changes asks (Save/Discard/Cancel) instead of closing");
    click_ctl(ctl_of(VEXUI_CK_VBDISCARD));
    check(vexui_screen() == VEXUI_DESKTOP && !apps_running(APP_ID_VALBOOK) && vfs_read(n, buf, sizeof buf) == 2 && seq(buf, "h!"), "valbook: Discard closes without writing the unsaved edit");
    click_ctl(ctl_of(VEXUI_CK_VALB)); click_ctl(ctl_of(VEXUI_CK_VBOPEN)); typestr("nofile.txt"); tap(VEX_KEY_ENTER);
    check(vexui_valbook_node() < 0 && vexui_screen() == VEXUI_VALBOOK, "valbook: opening a missing file reports an error and changes nothing");
    for (int i = 0; i < 10; i++) { tap(VEX_KEY_BACKSPACE); } typestr("doc.txt"); tap(VEX_KEY_ENTER);
    check(vexui_valbook_node() == n && seq(vexui_valbook_text(), "h!"), "valbook: Open loads the saved content from the filesystem");
    for (int i = 0; i < 2100; i++) typech('a');
    check(strlen_(vexui_valbook_text()) == 2047, "valbook: input stops at the 2047-byte limit (no overflow)");
    click_ctl(0); click_ctl(ctl_of(VEXUI_CK_VBDISCARD));

    /* File Explorer: sorting, context menus, rename, delete, new folder, Vex Code file */
    int a = vfs_create(vfs_resolve("/home/alpha"), "a.vex", 0, 1000, 0), b = vfs_create(vfs_resolve("/home/alpha"), "b.txt", 0, 1000, 0), c = vfs_create(vfs_resolve("/home/alpha"), "c.txt", 0, 1000, 0), z = vfs_create(vfs_resolve("/home/alpha"), "zdir", 1, 1000, 0);
    (void)vfs_write(b, "12345", 5, 1000, 0); (void)vfs_write(c, "1", 1, 1000, 0);
    click_ctl(ctl_of(VEXUI_CK_EXPL));
    check(vexui_explorer_entry(0) == z && (vexui_explorer_entry(1) == n || vexui_explorer_entry(1) == a), "explorer: folders are listed before files");
    int e0 = vexui_explorer_entry(1), e1 = vexui_explorer_entry(2);
    check(e0 == a && e1 == b, "explorer sort: Name A-Z (a.vex, b.txt, ...)");
    click_ctl(ctl_of(VEXUI_CK_XSORT));
    check(vexui_sort_mode() == 1 && vexui_explorer_entry(0) == z && (vexui_explorer_entry(1) == n || vexui_explorer_entry(1) == c), "explorer sort: Name Z-A");
    click_ctl(ctl_of(VEXUI_CK_XSORT));
    check(vexui_sort_mode() == 2 && vexui_explorer_entry(vexui_explorer_entries() - 1) == a, "explorer sort: by Type (.vex after .txt)");
    click_ctl(ctl_of(VEXUI_CK_XSORT));
    check(vexui_sort_mode() == 3 && vexui_explorer_entry(1) == a && vexui_explorer_entry(vexui_explorer_entries() - 1) == b, "explorer sort: by Size (0 bytes first, 5 bytes last)");
    click_ctl(ctl_of(VEXUI_CK_XSORT)); click_ctl(ctl_of(VEXUI_CK_XSORT));
    check(vexui_sort_mode() == 0 && vfs_resolve("/home/alpha/b.txt") == b && vfs_node(b)->size == 5, "explorer sort: cycles back; sorting changed only the display order, never the stored files");
    int32_t wx, wy; vexui_win_pos(&wx, &wy);
    rclick(wx + 200, wy + 330);
    check(vexui_popup() == VEXUI_POPUP_CTX && vexui_ctx_count() == 4, "context menu: right-click on empty space offers New File / New Folder / New Vex Code File / Refresh");
    click_item(1); typestr("newdir"); tap(VEX_KEY_ENTER);
    check(vfs_resolve("/home/alpha/newdir") > 0 && vfs_node(vfs_resolve("/home/alpha/newdir"))->is_dir, "context menu: New Folder creates a real folder");
    vexui_win_pos(&wx, &wy); rclick(wx + 200, wy + 330); click_item(2); typestr("prog"); tap(VEX_KEY_ENTER);
    int pv = vfs_resolve("/home/alpha/prog.vex");
    check(pv > 0 && vfs_read(pv, buf, sizeof buf) > 10 && has(buf, "fn main() -> i32"), "context menu: New Vex Code File creates prog.vex (.vex extension appended) with a valid VexScript starter");
    int rc = row_ctl_for(pv); int32_t rx, ry; ctl_xy(rc, &rx, &ry); rclick(rx, ry);
    check(vexui_popup() == VEXUI_POPUP_CTX && vexui_ctx_count() == 4, "context menu: right-click on an editable file offers Open / Edit / Rename / Delete");
    click_item(1);
    check(vexui_screen() == VEXUI_VALBOOK && has(vexui_valbook_text(), "// New Vex Code file"), "context menu: Edit opens the .vex file in Valbook with its content");
    click_ctl(0); click_ctl(ctl_of(VEXUI_CK_EXPL));
    rc = row_ctl_for(b); ctl_xy(rc, &rx, &ry); rclick(rx, ry); click_item(2); for (int i = 0; i < 10; i++) { tap(VEX_KEY_BACKSPACE); } typestr("c.txt"); tap(VEX_KEY_ENTER);
    check(vfs_resolve("/home/alpha/b.txt") == b && has(vexui_explorer_message(), "already exists"), "rename: a colliding name is refused and the file keeps its name");
    for (int i = 0; i < 10; i++) { tap(VEX_KEY_BACKSPACE); } typestr("renamed.txt"); tap(VEX_KEY_ENTER);
    check(vfs_resolve("/home/alpha/renamed.txt") == b && vfs_resolve("/home/alpha/b.txt") < 0, "rename: a free name renames the file (same node, content kept)");
    rc = row_ctl_for(b); ctl_xy(rc, &rx, &ry); rclick(rx, ry); click_item(3);
    check(vfs_resolve("/home/alpha/renamed.txt") == b, "delete: choosing Delete only asks for confirmation (file still exists)");
    tap(VEX_KEY_ENTER);
    check(vfs_resolve("/home/alpha/renamed.txt") < 0, "delete: confirming removes the file");
    rc = row_ctl_for(vfs_resolve("/home/alpha/newdir")); (void)rc;
    check(vfs_delete(z, 1000, 0) == 0 && vfs_delete(vfs_resolve("/home/alpha"), 1000, 1) == VFS_ERR_NOTEMPTY, "delete: an empty folder can be removed; a non-empty folder is refused");
    check(vfs_delete(1, 0, 1) == VFS_ERR_DENIED && vfs_delete(0, 0, 1) == VFS_ERR_DENIED, "delete: '/' and /home are protected even from administrators");
    tap(VEX_KEY_ESCAPE);
}
static void t_release03_wm(void)
{
    r3_login(); click_ctl(ctl_of(VEXUI_CK_VALB)); typestr("keep");
    click_ctl(ctl_of(VEXUI_CK_TMIN));
    check(vexui_screen() == VEXUI_DESKTOP && vexui_win_minimized(APP_ID_VALBOOK) && apps_running(APP_ID_VALBOOK), "window: minimize hides the window but the app keeps running");
    click_ctl(ctl_of(VEXUI_CK_VALB));
    check(vexui_screen() == VEXUI_VALBOOK && !vexui_win_minimized(APP_ID_VALBOOK) && seq(vexui_valbook_text(), "keep") && vexui_valbook_modified(), "window: restore from the taskbar brings it back with its state (text, modified flag) intact");
    int32_t x, y, w, h, cx, cy; vexui_win_pos(&x, &y);
    int ci = ctl_of(VEXUI_CK_TCLOSE); vexui_ctl_rect(ci, &cx, &cy, &w, &h);
    mv(x + 300, y + 12, 0); mv(x + 300, y + 12, 1); mv(x + 400, y + 72, 1); mv(x + 400, y + 72, 0);
    int32_t x2, y2, cx2, cy2; vexui_win_pos(&x2, &y2); vexui_ctl_rect(ci, &cx2, &cy2, &w, &h);
    check(x2 == x + 100 && y2 == y + 60 && cx2 == cx + 100 && cy2 == cy + 60, "window: dragging the title bar moves the window AND its controls consistently (hit-testing follows)");
    check(seq(vexui_valbook_text(), "keep"), "window: dragging never types into the application");
    typestr("!"); check(seq(vexui_valbook_text(), "keep!"), "window: keyboard focus still goes to the moved window");
    mv(x2 + 300, y2 + 12, 0); mv(x2 + 300, y2 + 12, 1); mv(5000, 5000, 1); mv(5000, 5000, 0); vexui_win_pos(&x, &y);
    check(x <= 1280 - 140 && y <= 800 - 56 - 40 && x >= -(1000 - 140) && y >= 0, "window: cannot be dragged so far that its title bar becomes unreachable");
    mv(x + 20, y + 12, 0); mv(x + 20, y + 12, 1); mv(-5000, -5000, 1); mv(-5000, -5000, 0); vexui_win_pos(&x, &y);
    check(x >= -(1000 - 140) && y >= 0, "window: clamped at the top/left as well");
    click_ctl(ctl_of(VEXUI_CK_TERM));
    check(vexui_screen() == VEXUI_TERMINAL && apps_running(APP_ID_VALBOOK) && apps_running(APP_ID_TERMINAL), "window: taskbar switches between running apps; both stay open");
    click_ctl(ctl_of(VEXUI_CK_VALB)); click_ctl(ctl_of(VEXUI_CK_VBTN)); typestr("q");
    check(vexui_popup() == VEXUI_POPUP_VMENU && seq(vexui_valbook_text(), "keep!") && seq(vexui_search_text(), "q"), "window: with the V menu open over an app, keystrokes go to the menu, not the app");
    tap(VEX_KEY_ESCAPE);
    click_ctl(ctl_of(VEXUI_CK_VBTN)); click_item(apps_registry_count());
    check(vexui_screen() == VEXUI_VALBOOK, "lock from an app with unsaved work is deferred (asks to save/discard first)");
    click_ctl(ctl_of(VEXUI_CK_VBDISCARD));
    check(vexui_screen() == VEXUI_LOCK && acct_active() == -1, "after discarding, the pending lock completes and the identity is cleared");
    vexui_test_end();
}
static void t_release03_commands(void)
{
    char buf[200]; r3_login(); vfs_ensure_home(1000, "alpha"); int b0 = vfs_ensure_home(1001, "bravo");
    (void)vfs_create(vfs_resolve("/home/alpha"), "notes.txt", 0, 1000, 0); (void)vfs_create(b0, "secret-notes.txt", 0, 1001, 0);
    click_ctl(ctl_of(VEXUI_CK_TERM));
    run_line("v. open Valbook");
    check(vexui_screen() == VEXUI_VALBOOK && apps_running(APP_ID_VALBOOK) && vth_is_open() && vexui_win_minimized(APP_ID_TERMINAL), "v. open: launches the app and keeps Verminal running behind it");
    click_ctl(ctl_of(VEXUI_CK_TERM)); check(row_has("Opening Valbook"), "v. open: reports what it did");
    run_line("v. open Valbook"); check(row_has("Bringing to the foreground: Valbook") && vexui_screen() == VEXUI_VALBOOK, "v. open: an already-running app is brought to the foreground");
    typestr("x"); click_ctl(ctl_of(VEXUI_CK_TMIN)); click_ctl(ctl_of(VEXUI_CK_TERM)); run_line("v. open valbook");
    check(row_has("Restoring Valbook") && vexui_screen() == VEXUI_VALBOOK, "v. open: a minimized app is restored (name matching is case-insensitive)");
    click_ctl(ctl_of(VEXUI_CK_TERM)); run_line("v. close Valbook");
    check(vexui_screen() == VEXUI_VALBOOK && apps_running(APP_ID_VALBOOK) && seq(vexui_valbook_text(), "x"), "v. close: an app with unsaved changes is NOT killed - it is asked to Save/Discard/Cancel");
    click_ctl(ctl_of(VEXUI_CK_VBDISCARD)); click_ctl(ctl_of(VEXUI_CK_TERM));
    run_line("v. close Valbook"); check(row_has("is not running"), "v. close: an app that is not running is reported, nothing else is touched");
    run_line("v. open Valbook"); click_ctl(ctl_of(VEXUI_CK_TERM)); run_line("v. close Valbook");
    check(row_has("Closed Valbook.") && !apps_running(APP_ID_VALBOOK) && vexui_screen() == VEXUI_TERMINAL, "v. close: a clean app closes; Verminal and everything else keep running");
    run_line("v. open Nope"); check(row_has("Unknown application 'Nope'"), "v. open: unknown application is reported");
    run_line("v. open \"File Explorer\""); check(vexui_screen() == VEXUI_EXPLORER, "v. open \"File Explorer\": a quoted name with a space works");
    click_ctl(ctl_of(VEXUI_CK_TERM)); run_line("v. open \"File"); check(row_has("Unterminated quote") && vexui_screen() == VEXUI_TERMINAL, "malformed quoting is rejected cleanly and Verminal keeps working");
    run_line("v. open Verminal"); check(row_has("already open"), "v. open Verminal: refuses to launch a second copy");
    run_line("v. search notes");
    check(row_has("/home/alpha/notes.txt") && row_has("/home/bravo/secret-notes.txt") && row_has("2 result"), "v. search: finds matches by name (administrator can read all homes) and prints full paths");
    run_line("v. search zzzzq"); check(row_has("No results for 'zzzzq'"), "v. search: no-result case reported");
    run_line("v. search"); check(row_has("Usage: v. search"), "v. search: missing argument prints usage");
    run_line("v. audio test"); check(row_has("PC speaker") && row_has("cannot detect audibility"), "v. audio test: reports honestly what it did and what it cannot know");
    uint32_t n0 = (uint32_t)acct_count();
    run_line("v. add user carol carol789");
    check(acct_count() == (int)n0 + 1 && row_has("Created user 'carol' (standard user)") && !row_has("carol789") && !row_has("alpha123"), "v. add user: an authenticated administrator creates a standard user; the password is never shown");
    run_line("v. add user carol carol789"); check(row_has("already in use") && acct_count() == (int)n0 + 1, "v. add user: duplicate rejected");
    run_line("v. add user dave abc"); check(row_has("at least 6") && acct_count() == (int)n0 + 1, "v. add user: weak password rejected");
    run_line("v. add user \"Mary Jane\" secret99"); check(acct_find("Mary Jane") >= 0 && vfs_resolve("/home/mary jane") > 0, "v. add user: quoted name with a space works and gets a home folder");
    run_line("v. add user onlyname"); check(row_has("Usage: v. add user"), "v. add user: missing password prints usage");
    run_line("v. change users");
    check(vexui_screen() == VEXUI_LOCK && acct_active() == -1 && !apps_running(APP_ID_TERMINAL), "v. change users: locks the session, closes apps, clears the identity");
    click_ctl(1); click_item(1); typestr("bravo456"); tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_DESKTOP && acct_active() == 1, "v. change users: the next user must authenticate with their own password");
    click_ctl(ctl_of(VEXUI_CK_TERM)); int cnt = acct_count();
    run_line("v. add user mallory mallory12");
    check(acct_count() == cnt && row_has("Only an administrator can create accounts"), "v. add user: a STANDARD user is refused (checked in the account store, not the UI)");
    run_line("v. search notes"); check(row_has("/home/bravo/secret-notes.txt") && !row_has("/home/alpha/notes.txt"), "v. search: a standard user only finds what they may read (not another user's files)");
    (void)buf; vexui_test_end();
}

static void t_ui_auth_apps(void)
{
    TINIT(); vfs_init(); apps_tracker_reset();
    (void)acct_create_pw("Alpha", "alpha123", -1); (void)acct_login(0, "alpha123"); (void)acct_create_pw("Bravo", "bravo456", 0); acct_logout();
    acct_select(0);
    vexui_test_begin(1280, 800, 1, 1);
    check(vexui_screen() == VEXUI_LOCK && vexui_nctl() == 5 && vexui_ctl_kind(4) == VEXUI_CK_PASS, "lock: a password-protected account shows a password field");
    typestr("wrongpass"); tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_LOCK && has(vexui_auth_message(), "Incorrect") && acct_active() == -1 && vexui_session_user() == -1, "lock: a wrong password is rejected with a message; no identity is established");
    tap(VEX_KEY_SPACE); tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_LOCK && acct_active() == -1, "lock: SPACE is a password character (not a bypass) and an empty/short entry is rejected");
    typestr("alpha123"); tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_DESKTOP && vexui_session_user() == 0 && acct_active() == 0, "lock: the correct password signs in as Alpha");
    click_ctl(0);
    check(vexui_popup_count() == apps_registry_count() + 4, "desktop: the administrator's V menu includes Add user");
    tap(VEX_KEY_ESCAPE);
    check(vexui_nctl() == 7 && vexui_ctl_kind(3) == VEXUI_CK_EXPL && vexui_ctl_kind(4) == VEXUI_CK_TASK, "desktop: File Explorer and Task Manager icons are present");
    click_ctl(0); click_item(apps_registry_count() + 3);
    check(vexui_screen() == VEXUI_SETUP && vexui_add_mode(), "add user: the admin opens the Add user form");
    fill_setup("Carol", "carol789"); tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_DESKTOP && acct_count() == 3 && acct_role(2) == ACCT_ROLE_STANDARD && !vexui_add_mode() && acct_active() == 0, "add user: Carol is created as a STANDARD user and the admin stays signed in");
    click_ctl(0); click_item(apps_registry_count() + 3); tap(VEX_KEY_ESCAPE);
    check(vexui_screen() == VEXUI_DESKTOP && acct_count() == 3, "add user: Esc cancels without creating anything");
    click_ctl(0); click_item(apps_registry_count() + 3); fill_setup("Dave", "dave1234"); tap(VEX_KEY_BACKSPACE); tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_SETUP && has(vexui_setup_message(), "do not match") && acct_count() == 3, "add user: mismatched confirmation is rejected");
    tap(VEX_KEY_ESCAPE);

    /* Task Manager */
    click_ctl(4);
    check(vexui_screen() == VEXUI_TASKMGR && apps_tracked_count() == 2 && vexui_cpu_permille() == -1, "task manager: opens, is tracked, and shows 'measuring' (no fabricated CPU value) until a real sample exists");
    tap(VEX_KEY_ESCAPE);
    for (int i = 0; i < 5; i++) { click_ctl(4); tap(VEX_KEY_ESCAPE); }
    check(vexui_screen() == VEXUI_DESKTOP && apps_tracked_count() == 1, "task manager: open/close x5 leaves no leftover tracked instance");

    /* File Explorer */
    click_ctl(3);
    char pth[64];
    check(vexui_screen() == VEXUI_EXPLORER && vfs_path(vexui_explorer_dir(), pth, sizeof pth) > 0 && seq(pth, "/home/alpha") && vexui_explorer_entries() == 0, "explorer: opens in the user's own (empty) home folder");
    { int32_t x, y, w, h; (void)x; (void)y; (void)w; (void)h; }
    click_ctl(3);                                                       /* New File */
    typestr("notes.txt"); tap(VEX_KEY_ENTER);
    check(vexui_explorer_entries() == 1 && has(vexui_explorer_message(), "Created") && vfs_resolve("/home/alpha/notes.txt") > 0, "explorer: New File creates a REAL file through the filesystem API and the listing shows it");
    click_ctl(3); typestr("notes.txt"); tap(VEX_KEY_ENTER);
    check(vexui_explorer_entries() == 1 && has(vexui_explorer_message(), "already exists"), "explorer: creating a duplicate is refused with a message (no overwrite)");
    for (int i = 0; i < 9; i++) tap(VEX_KEY_BACKSPACE);
    typestr("a/b"); tap(VEX_KEY_ENTER);
    check(vexui_explorer_entries() == 1 && has(vexui_explorer_message(), "Invalid file name"), "explorer: an invalid name is rejected and the dialog stays open");
    tap(VEX_KEY_ESCAPE);
    click_ctl(1);
    check(vfs_path(vexui_explorer_dir(), pth, sizeof pth) > 0 && seq(pth, "/home") && vexui_explorer_entries() >= 1, "explorer: Up navigates to /home");
    click_ctl(2);
    check(seq((vfs_path(vexui_explorer_dir(), pth, sizeof pth), pth), "/home/alpha") && vexui_explorer_entries() == 1, "explorer: Home returns; the file is still listed after navigating away and back");
    tap(VEX_KEY_ESCAPE);
    check(vexui_screen() == VEXUI_DESKTOP && apps_tracked_count() == 1, "explorer: Esc closes it");

    /* lock + switch to standard user B */
    click_ctl(0); click_item(apps_registry_count());
    check(vexui_screen() == VEXUI_LOCK && acct_active() == -1 && vexui_session_user() == -1, "lock: locking invalidates the previous identity");
    click_ctl(1); click_item(1);
    check(acct_selected() == 1 && acct_active() == -1, "users: selecting Bravo does not authenticate as Bravo (or keep Alpha)");
    typestr("alpha123"); tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_LOCK && acct_active() == -1, "lock: Alpha's password does NOT sign in as Bravo");
    typestr("bravo456"); tap(VEX_KEY_ENTER);
    check(vexui_screen() == VEXUI_DESKTOP && vexui_session_user() == 1 && acct_active() == 1, "lock: Bravo signs in with Bravo's own password - active identity changed");
    click_ctl(0);
    check(vexui_popup_count() == apps_registry_count() + 3, "desktop: a standard user's V menu has NO Add user item");
    tap(VEX_KEY_ESCAPE);
    check(acct_create_pw("Mallory", "mallory12", acct_active()) == ACCT_ERR_DENIED && acct_count() == 3, "authorization: even a direct call by the signed-in standard user is refused by the account store");
    click_ctl(3);
    check(vfs_path(vexui_explorer_dir(), pth, sizeof pth) > 0 && seq(pth, "/home/bravo"), "explorer: Bravo starts in /home/bravo");
    click_ctl(1); click_ctl(3); typestr("hack.txt"); tap(VEX_KEY_ENTER);
    check(has(vexui_explorer_message(), "Permission denied") && vfs_resolve("/home/hack.txt") < 0, "explorer: Bravo cannot create files in /home (permission checked, nothing created)");
    tap(VEX_KEY_ESCAPE); tap(VEX_KEY_ESCAPE);
    vexui_test_end();
}
void desktop01_run_tests(Desktop01Results *out)
{
    R = out; out->checks_run = 0; out->checks_failed = 0;
    t_accounts(); t_time_keys_apps(); t_timer_contract(); t_crypto_auth(); t_vfs_cpu(); t_setup_flow(); t_lock_users(); t_desktop_terminal(); t_ui_auth_apps(); t_release03_typing(); t_release03_valbook_explorer(); t_release03_wm(); t_release03_commands();
    acct_init(); apps_tracker_reset(); vth_close(); vfs_init();
}
void desktop01_print_summary(const Desktop01Results *r)
{
    serial_puts("[test] ===== "); serial_put_dec64(r->checks_run - r->checks_failed); serial_puts("/"); serial_put_dec64(r->checks_run);
    serial_puts(" DESKTOP-01 checks passed =====\n");
}
int desktop01_all_passed(const Desktop01Results *r) { return r->checks_run > 0 && r->checks_failed == 0; }
