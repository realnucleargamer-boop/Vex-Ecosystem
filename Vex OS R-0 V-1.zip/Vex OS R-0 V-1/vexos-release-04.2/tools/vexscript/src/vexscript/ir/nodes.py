"""Vex IR 1.5 data model (backwards-compatible evolution of 0.1 / 1.0-style SSA)."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

# Type strings used by VexScript pipeline:
#   i8 i16 i32 i64 u8 u16 u32 u64 bool void string
#   T[] for arrays, struct names, *T / *mut T (annotations)
IRType = str

IR_VERSION = "1.5"


@dataclass
class Value:
    """SSA value or literal."""
    kind: str  # "ssa" | "lit"
    text: str  # "%v0" or "42" or "true"
    ty: IRType


@dataclass
class Instruction:
    dest: str | None  # "%v0" or None for side-effect only
    op: str
    ty: IRType
    args: list[Value]
    extra: Any = None  # field name, callee, array len, etc.


@dataclass
class Block:
    name: str
    instructions: list[Instruction] = field(default_factory=list)
    terminator: Instruction | None = None


@dataclass
class FunctionIR:
    name: str
    params: list[tuple[str, IRType]]  # (ssa_name, type)
    return_type: IRType
    blocks: list[Block] = field(default_factory=list)


@dataclass
class ModuleIR:
    functions: list[FunctionIR] = field(default_factory=list)
    # IR 1.5 metadata
    ir_version: str = IR_VERSION
    # optional struct layouts: name -> [(field, type), ...]
    structs: dict[str, list[tuple[str, str]]] = field(default_factory=dict)
    calling_conv: str = "vex_hosted"  # temporary; not Vex OS syscall ABI
