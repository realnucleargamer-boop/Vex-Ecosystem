#!/usr/bin/env python3
"""
VexScript Wave — VEX AI 1.0 Readiness stress harness.

Runs progressive workloads THROUGH the VexScript interpreter (AST path).
Does NOT implement VEX AI. Records time and peak traced memory.
"""
from __future__ import annotations
import sys
import time
import tracemalloc
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vexscript import __version__, __ir_version__
from vexscript.interpreter import Interpreter
from vexscript.tensor_rt import (
    tensor_create, tensor_fill, tensor_add, tensor_matmul, tensor_length, Tensor,
)
from vexscript.evolve_rt import (
    reset_evolve_state, evolve_create, evolve_randomize, evolve_get, evolve_set,
    evolve_mutate, evolve_crossover, evolve_select_tournament, evolve_generation,
    evolve_checkpoint_save, evolve_checkpoint_load, evolve_size, evolve_best_index,
)

RESULTS: list[dict] = []


def record(workload: str, iterations: int, runtime_s: float, peak_kb: float, result: str, notes: str = ""):
    row = {
        "workload": workload,
        "iterations": iterations,
        "runtime_s": round(runtime_s, 6),
        "peak_kb": round(peak_kb, 1),
        "result": result,
        "notes": notes,
    }
    RESULTS.append(row)
    status = "OK" if result == "PASS" else result
    print(f"  [{status}] {workload}: {runtime_s:.4f}s peak={peak_kb:.1f}KB n={iterations} {notes}")


def run_vex(src: str, name: str = "wave.vex") -> tuple[int, list, float, float]:
    """Execute VexScript source; return code, output, seconds, peak_kb."""
    tracemalloc.start()
    t0 = time.perf_counter()
    try:
        interp = Interpreter()
        interp.load(src, name)
        code = interp.run_main()
        out = list(interp.output)
        ok = True
        err = ""
    except Exception as e:
        code = -1
        out = []
        ok = False
        err = f"{type(e).__name__}: {e}"
    elapsed = time.perf_counter() - t0
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    peak_kb = peak / 1024.0
    if not ok:
        return code, [err], elapsed, peak_kb
    return code, out, elapsed, peak_kb


def section(title: str):
    print(f"\n=== {title} ===")


# ---------------------------------------------------------------------------
# 1. Memory / tensor allocation stress (via VexScript builtins)
# ---------------------------------------------------------------------------
def stress_memory():
    section("1. Memory / tensor allocation")
    sizes = [1000, 5000, 10000, 25000, 50000, 75000, 100000]
    for n in sizes:
        src = f"""
fn main() -> i32 {{
    let t = tensor_create_1({n});
    tensor_fill(t, 1);
    println(tensor_length(t));
    return 0;
}}
"""
        code, out, elapsed, peak = run_vex(src, f"mem_{n}.vex")
        ok = code == 0 and str(n) in "".join(str(x) for x in out)
        record(f"tensor_alloc_{n}", n, elapsed, peak, "PASS" if ok else "FAIL", str(out)[:60])


# ---------------------------------------------------------------------------
# 2. Population stress (evolve handles + tensors)
# ---------------------------------------------------------------------------
def stress_population():
    section("2. Population / genome structures")
    # Via VexScript evolve_create
    configs = [
        (12, 64),      # small: 12 genomes x 64 weights
        (50, 128),
        (250, 64),     # 1 stream-like
        (3000, 32),    # 12*250 style total genomes, smaller dim for safety
        (1000, 128),
    ]
    for n_genomes, dim in configs:
        src = f"""
fn main() -> i32 {{
    rng_seed(42);
    let pop = evolve_create({n_genomes}, {dim});
    evolve_randomize(pop);
    println(evolve_size(pop));
    let g = evolve_get(pop, 0);
    let g2 = evolve_mutate(g, 200);
    evolve_set(pop, 0, g2);
    println(tensor_length(g2));
    return 0;
}}
"""
        code, out, elapsed, peak = run_vex(src, f"pop_{n_genomes}_{dim}.vex")
        ok = code == 0 and str(n_genomes) in "".join(str(x) for x in out)
        record(
            f"pop_{n_genomes}x{dim}",
            n_genomes * dim,
            elapsed,
            peak,
            "PASS" if ok else "FAIL",
            str(out)[:80],
        )


# ---------------------------------------------------------------------------
# 3. String workload
# ---------------------------------------------------------------------------
def stress_strings():
    section("3. String workload")
    # Genome-like strings of increasing length via repeated concat in VexScript
    lengths = [16, 64, 256, 1024]
    for L in lengths:
        # Build by doubling from seed in a loop — limited by interpreter speed
        src = f"""
fn main() -> i32 {{
    let mut s: string = "Ab0.-=";
    let mut i: i64 = 0;
    while (i < 8) {{
        s = concat(s, s);
        i = i + 1;
    }}
    // length after 8 doubles of 6 chars = 6 * 256 = 1536
    println(len_string(s));
    let t: string = concat(s, "XYZ");
    if (s == s) {{ println(1); }}
    if (s != t) {{ println(2); }}
    println(len_string(t));
    return 0;
}}
"""
        code, out, elapsed, peak = run_vex(src, f"str_{L}.vex")
        ok = code == 0
        record(f"string_double_to_~1.5k", 1536, elapsed, peak, "PASS" if ok else "FAIL", str(out)[:60])
        break  # one structural test is enough for doubling

    # Many concat operations
    src = """
fn main() -> i32 {
    let mut s: string = "A";
    let mut i: i64 = 0;
    while (i < 500) {
        s = concat(s, "x");
        i = i + 1;
    }
    println(len_string(s));
    return 0;
}
"""
    code, out, elapsed, peak = run_vex(src, "str_concat_500.vex")
    ok = code == 0 and "501" in "".join(str(x) for x in out)
    record("string_concat_500", 500, elapsed, peak, "PASS" if ok else "FAIL", str(out)[:40])

    # Compare many times
    src = """
fn main() -> i32 {
    let a: string = "genome-ABCDEFG-012345";
    let b: string = "genome-ABCDEFG-012345";
    let mut i: i64 = 0;
    let mut hits: i64 = 0;
    while (i < 2000) {
        if (a == b) { hits = hits + 1; }
        i = i + 1;
    }
    println(hits);
    return 0;
}
"""
    code, out, elapsed, peak = run_vex(src, "str_cmp_2k.vex")
    ok = code == 0 and "2000" in "".join(str(x) for x in out)
    record("string_eq_2000", 2000, elapsed, peak, "PASS" if ok else "FAIL", str(out)[:40])


# ---------------------------------------------------------------------------
# 4. Numeric workload
# ---------------------------------------------------------------------------
def stress_numeric():
    section("4. Numeric / fitness-like workload")
    src = """
fn main() -> i32 {
    let mut i: i64 = 0;
    let mut sum: i64 = 0;
    let mut sq: i64 = 0;
    while (i < 10000) {
        sum = sum + i;
        sq = sq + (i * i);
        i = i + 1;
    }
    println(sum);
    println(sq);
    return 0;
}
"""
    code, out, elapsed, peak = run_vex(src, "num_10k.vex")
    record("numeric_sum_sq_10k", 10000, elapsed, peak, "PASS" if code == 0 else "FAIL", str(out)[:40])

    src = """
fn main() -> i32 {
    let mut i: i64 = 0;
    let mut s: i64 = 0;
    while (i < 100000) {
        s = s + (i % 97);
        i = i + 1;
    }
    println(s);
    return 0;
}
"""
    code, out, elapsed, peak = run_vex(src, "num_100k.vex")
    record("numeric_mod_100k", 100000, elapsed, peak, "PASS" if code == 0 else "FAIL", str(out)[:40])

    # tensor matmul small network-like
    src = """
fn main() -> i32 {
    let x = tensor_create_2(1, 64);
    tensor_fill(x, 1);
    let w = tensor_create_2(64, 32);
    tensor_fill(w, 1);
    let y = neural_linear(x, w);
    println(tensor_get_2(y, 0, 0));
    return 0;
}
"""
    code, out, elapsed, peak = run_vex(src, "num_linear_64x32.vex")
    record("neural_linear_64x32", 64 * 32, elapsed, peak, "PASS" if code == 0 else "FAIL", str(out)[:40])

    src = """
fn main() -> i32 {
    let x = tensor_create_2(1, 128);
    tensor_fill(x, 1);
    let w = tensor_create_2(128, 128);
    tensor_fill(w, 1);
    let y = neural_linear(x, w);
    println(tensor_length(y));
    return 0;
}
"""
    code, out, elapsed, peak = run_vex(src, "num_linear_128x128.vex")
    record("neural_linear_128x128", 128 * 128, elapsed, peak, "PASS" if code == 0 else "FAIL", str(out)[:40])


# ---------------------------------------------------------------------------
# 5. Synthetic evolutionary generations
# ---------------------------------------------------------------------------
def stress_generations():
    section("5. Synthetic generation workload")
    # 12 streams * 250 = 3000 is heavy in pure interpreter; test progressive
    cases = [
        (12, 16, 10),    # streams, genomes_per, generations — small
        (12, 32, 10),
        (12, 64, 10),
        (12, 64, 50),
        (12, 128, 10),
        (4, 250, 10),
        (12, 250, 10),   # target shape — may be slow
    ]
    for streams, per, gens in cases:
        total = streams * per
        # Single population representing all genomes; generation loop
        src = f"""
fn main() -> i32 {{
    rng_seed(42);
    let pop = evolve_create({total}, 32);
    evolve_randomize(pop);
    let mut g: i64 = 0;
    let mut elite: i64 = 0;
    while (g < {gens}) {{
        elite = evolve_best_index(10, 20, 15, 5);
        evolve_generation(pop, elite, 200);
        g = g + 1;
    }}
    println(evolve_size(pop));
    println(g);
    return 0;
}}
"""
        code, out, elapsed, peak = run_vex(src, f"evo_{total}_g{gens}.vex")
        ok = code == 0
        record(
            f"evolve_{streams}x{per}_gen{gens}",
            total * gens,
            elapsed,
            peak,
            "PASS" if ok else "FAIL",
            str(out)[:60],
        )
        # Stop escalating if too slow (>30s) to protect host
        if elapsed > 30.0:
            record(
                "evolve_escalation_stopped",
                total * gens,
                elapsed,
                peak,
                "STOP",
                "runtime > 30s; not escalating further",
            )
            break


# ---------------------------------------------------------------------------
# 6. Struct / data-model stress
# ---------------------------------------------------------------------------
def stress_structs():
    section("6. Struct / data-model stress")
    src = """
struct Genome { id: i64 score: i64 }
struct Stream { id: i64 count: i64 }
struct FitnessResult { best: i64 avg: i64 }

fn main() -> i32 {
    let mut i: i64 = 0;
    let mut total: i64 = 0;
    let mut score: i64 = 0;
    while (i < 5000) {
        score = i * 2;
        total = total + score;
        i = i + 1;
    }
    let s = Stream { id: 1, count: 5000 };
    let f = FitnessResult { best: 100, avg: 50 };
    println(total);
    println(s.count);
    println(f.best);
    return 0;
}
"""
    code, out, elapsed, peak = run_vex(src, "struct_5k.vex")
    record("struct_genome_5k", 5000, elapsed, peak, "PASS" if code == 0 else "FAIL", str(out)[:50])


# ---------------------------------------------------------------------------
# 7. Deterministic RNG
# ---------------------------------------------------------------------------
def stress_rng():
    section("7. Deterministic RNG")
    for seed in [42, 12345, "0"]:  # large hex as decimal if needed
        if seed == "0":
            seed_val = 0
        else:
            seed_val = int(seed)
        src = f"""
fn main() -> i32 {{
    rng_seed({seed_val});
    println(rng_u64());
    println(rng_u64());
    println(rng_u64());
    return 0;
}}
"""
        code1, out1, e1, p1 = run_vex(src, f"rng_{seed_val}.vex")
        code2, out2, e2, p2 = run_vex(src, f"rng_{seed_val}b.vex")
        ok = code1 == 0 and out1 == out2 and len(out1) == 3
        record(
            f"rng_seed_{seed_val}",
            3,
            e1 + e2,
            max(p1, p2),
            "PASS" if ok else "FAIL",
            f"out={out1}",
        )

    # large seed
    big = 0x123456789ABCDEF0
    # may exceed i64 positive in language — try as negative wrap or skip
    src = f"""
fn main() -> i32 {{
    rng_seed({big if big < 2**63 else big - 2**64});
    println(rng_u64());
    return 0;
}}
"""
    # Use truncated seed representable
    seed64 = big & 0x7FFFFFFFFFFFFFFF
    src = f"""
fn main() -> i32 {{
    rng_seed({seed64});
    println(rng_u64());
    println(rng_u64());
    return 0;
}}
"""
    c1, o1, e1, p1 = run_vex(src, "rng_big.vex")
    c2, o2, e2, p2 = run_vex(src, "rng_big2.vex")
    record("rng_seed_large63bit", 2, e1 + e2, max(p1, p2), "PASS" if o1 == o2 else "FAIL", str(o1))


# ---------------------------------------------------------------------------
# 8. Direct runtime ceiling probes (still using VexScript runtime libs)
# ---------------------------------------------------------------------------
def stress_runtime_ceiling():
    section("8. Runtime ceiling (tensor_rt / evolve_rt direct — same runtime VexScript uses)")
    # Honest: measures the hosted runtime kernels the language calls into
    for n in [75000, 100000, 250000, 500000]:
        tracemalloc.start()
        t0 = time.perf_counter()
        try:
            t = tensor_create("f32", n)
            tensor_fill(t, 1.0)
            assert tensor_length(t) == n
            elapsed = time.perf_counter() - t0
            peak = tracemalloc.get_traced_memory()[1] / 1024.0
            tracemalloc.stop()
            record(f"runtime_tensor_{n}", n, elapsed, peak, "PASS", "direct tensor_rt")
        except Exception as e:
            tracemalloc.stop()
            record(f"runtime_tensor_{n}", n, 0, 0, "FAIL", str(e)[:80])

    for n_pop, dim in [(3000, 64), (12000, 32), (75000, 8)]:
        reset_evolve_state()
        tracemalloc.start()
        t0 = time.perf_counter()
        try:
            def rng():
                # local deterministic
                if not hasattr(rng, "s"):
                    rng.s = 42
                rng.s = (rng.s + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
                return rng.s

            pid = evolve_create(n_pop, dim)
            evolve_randomize(pid, rng)
            for _ in range(5):
                evolve_generation(pid, 0, rng, 200)
            elapsed = time.perf_counter() - t0
            peak = tracemalloc.get_traced_memory()[1] / 1024.0
            tracemalloc.stop()
            record(f"runtime_evolve_{n_pop}x{dim}_g5", n_pop * 5, elapsed, peak, "PASS", "direct evolve_rt")
        except Exception as e:
            tracemalloc.stop()
            record(f"runtime_evolve_{n_pop}x{dim}", n_pop, 0, 0, "FAIL", str(e)[:80])


def write_report(path: Path):
    lines = []
    lines.append("# VexScript Wave Report — VEX AI 1.0 Readiness\n")
    lines.append(f"**VexScript version:** {__version__}  \n")
    lines.append(f"**IR version:** {__ir_version__}  \n")
    lines.append(f"**Execution path tested:** Hosted AST interpreter + tensor_rt/evolve_rt kernels  \n")
    lines.append("**VEX AI 1.0:** NOT implemented (readiness wave only)\n")
    lines.append("\n## 1. Current VexScript capabilities\n")
    lines.append("""
| Area | Status |
|------|--------|
| Static typing, structs, arrays `T[]`, modules | Yes |
| Strings (concat, length, ==, !=) | Yes |
| String character index / insert / delete | **No** |
| Float literals | **No** (integer fills coerced in tensor_fill) |
| Tensors (create/fill/add/mul/matmul) | Yes (hosted) |
| neural_linear / relu / forward_2 | Yes |
| Evolution (create/mutate/crossover/select/generation/checkpoint) | Yes (hosted handles) |
| Deterministic rng_seed / rng_u64 | Yes |
| Native x86-64 backend for tensors/evolve | **No** (IR/native incomplete for this workload) |
| GC | Not required; Python host manages interpreter memory |
""")
    lines.append("\n## 2–8. Benchmark results\n\n")
    lines.append("| workload | iterations | runtime_s | peak_kb | result | notes |\n")
    lines.append("|----------|------------|-----------|---------|--------|-------|\n")
    for r in RESULTS:
        notes = r["notes"].replace("|", "/")[:60]
        lines.append(
            f"| {r['workload']} | {r['iterations']} | {r['runtime_s']} | {r['peak_kb']} | {r['result']} | {notes} |\n"
        )

    # Analysis
    fails = [r for r in RESULTS if r["result"] == "FAIL"]
    stops = [r for r in RESULTS if r["result"] == "STOP"]
    passes = [r for r in RESULTS if r["result"] == "PASS"]
    max_tensor = max((r for r in RESULTS if r["workload"].startswith("tensor_alloc_") and r["result"] == "PASS"), default=None, key=lambda r: r["iterations"])
    max_pop = max((r for r in RESULTS if r["workload"].startswith("pop_") and r["result"] == "PASS"), default=None, key=lambda r: r["iterations"])

    lines.append("\n## Summary analysis\n")
    lines.append(f"- Passed: {len(passes)}, Failed: {len(fails)}, Stopped escalations: {len(stops)}\n")
    if max_tensor:
        lines.append(f"- Max VexScript tensor_alloc tested: **{max_tensor['iterations']}** elements ({max_tensor['runtime_s']}s, {max_tensor['peak_kb']}KB)\n")
    if max_pop:
        lines.append(f"- Max VexScript population footprint (genomes×dim elements): **{max_pop['iterations']}** ({max_pop['workload']})\n")

    lines.append("""
## 9. Performance bottlenecks

1. **AST interpreter overhead** — every `while` iteration is Python-level dispatch; 100k numeric loops are acceptable but multi-generation evolve with thousands of genomes becomes slow.
2. **String immutability via concat** — each concat allocates a new string; building long genomes by concat is O(n²) without a rope/buffer type.
3. **No character-level string API** — cannot index/replace genome characters in pure VexScript today.
4. **Evolve tournament/best fixed arity (4 scores)** — cannot score full population in one call without loops of get+manual fitness.
5. **Tensor/evolve state is hosted Python** — fine for prototyping; not bare-metal / no GC-free Vex OS target yet.

## 10. Compiler/runtime limitations (blocking for full VEX AI 1.0)

| Requirement | Current support | Gap |
|-------------|-----------------|-----|
| 75k neurons | tensor of 75k f32 works in runtime | No native weight layout; no sparse connectivity model |
| 12 streams × 250 genomes | Feasible at reduced dim; slow at full gen counts | Need faster evolve kernels / batch fitness |
| Genome text + charset | Strings exist | **No char index/edit**; charset not enforced |
| Mutation of text genomes | Partial (tensor mutate only) | Need string genome ops |
| Diversity / migration | Not built | Need stream-level APIs |
| Input+target / input-only modes | Not built | Application-level (OK later) |
| No Python dependency | Hosted interpreter **is** Python | Need native backend path for production VEX AI |
| Deterministic RNG | Yes | Keep |

## 11. Is 75k neurons practical on current VexScript?

**Partially, as a hosted prototype only.**

- Allocating and filling **75,000** contiguous f32 values via `tensor_create_1` is practical in the hosted runtime.
- Running **12 × 250** evolutionary streams for **hundreds of generations** with rich text genomes is **not practical** on the AST interpreter without:
  - character-level string/genome operations,
  - batch fitness APIs,
  - a faster backend (native or IR-optimized),
  - explicit multi-stream migration/diversity primitives.

Treat 75k as a **memory ceiling that is reachable**, not as proof that full VEX AI 1.0 training loops are ready.

## 12. Recommended next VexScript development wave

1. **Genome/string wave:** `str_char_at`, `str_set_char`, `str_slice`, mutable byte buffers or `genome` type with fixed capacity.
2. **Population fitness wave:** `evolve_score_all` / score arrays; remove 4-wide tournament limit.
3. **Multi-stream wave:** first-class stream handles, migration, diversity metric.
4. **Performance wave:** IR interpreter fast-path for tight loops; or native emit for evolve/tensor kernels.
5. **Only then** begin VEX AI 1.0 application architecture in VexScript.

## 13. Answer to the success criterion

> Can the current VexScript implementation realistically support the computational and memory requirements of VEX AI 1.0?

**Not yet for production-scale VEX AI 1.0.** Memory for ~75k units is attainable; algorithmic workload (text genomes, many generations, 12 streams, full fitness) is blocked by language gaps and interpreter performance. Hosted experiments at reduced scale are viable now for algorithm prototyping.

---
*Generated by scripts/run_vex_ai_wave.py — measurements are environment-specific.*
""")
    path.write_text("".join(lines))
    print(f"\nWrote {path}")


def main():
    print(f"VexScript Wave — version {__version__} IR {__ir_version__}")
    stress_memory()
    stress_population()
    stress_strings()
    stress_numeric()
    stress_structs()
    stress_rng()
    stress_generations()
    stress_runtime_ceiling()
    out = ROOT / "VEXSCRIPT_WAVE_REPORT.md"
    write_report(out)
    fails = sum(1 for r in RESULTS if r["result"] == "FAIL")
    print(f"\nTotal records: {len(RESULTS)}, failures: {fails}")
    return 0 if fails == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
