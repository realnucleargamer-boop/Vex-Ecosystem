#!/usr/bin/env python3
"""Vex OS - scripts/verify_winpath_on_linux.py

Replays build.ps1's toolchain steps (clang x86_64-unknown-elf, nasm, ld.lld,
llvm-objcopy; bootloader via clang x86_64-unknown-windows + lld-link) on Linux,
using the source lists PARSED FROM build.ps1 itself and the same flags, then
packages a FAT ESP image and boots it.  Purpose: prove the clang/lld output of
the Windows pipeline compiles, links and boots - the part of build.ps1 that is
independent of PowerShell/diskpart.

It does NOT run PowerShell, diskpart or the VHD step, so it does not prove
build.ps1 itself executes on Windows.
Usage (repo root): python3 scripts/verify_winpath_on_linux.py
"""
import os, re, subprocess, sys, shutil
sys.path.insert(0, os.path.dirname(__file__))
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = os.path.join(root, "build-winpath"); O = os.path.join(B, "kernel-obj")
shutil.rmtree(B, ignore_errors=True); os.makedirs(O)
ps = open(os.path.join(root, "build.ps1"), encoding="utf-8", errors="replace").read()
def lst(n):
    m = re.search(r"\$" + n + r"\s*=\s*@\((.*?)\n\)", ps, re.S)
    return [p.replace("\\", "/") for p in re.findall(r'"(kernel\\src\\[^"]+)"', m.group(1))]
cs, asm = lst("CSources"), lst("AsmSources")
inc, cinc = os.path.join(root, "kernel/include"), os.path.join(root, "common/include")
def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode: print("FAILED:", " ".join(cmd[:4]), "\n", r.stderr[-1500:]); sys.exit(1)
    return r.stderr
objs, warn = [], 0
for rel in cs:
    obj = os.path.join(O, os.path.basename(rel)[:-2] + ".o")
    e = run(["clang", "--target=x86_64-unknown-elf", "-ffreestanding", "-fno-stack-protector", "-fno-stack-check", "-fno-pic", "-fno-pie",
             "-mno-red-zone", "-mcmodel=kernel", "-mno-mmx", "-mno-sse", "-mno-sse2", "-Wall", "-Wextra", "-std=gnu11",
             "-DGRAPHICS2_VISUAL_DEMO=0", "-I", inc, "-I", cinc, "-c", os.path.join(root, rel), "-o", obj])
    w = len(re.findall(r"warning:", e)); warn += w
    if w and any(k in rel for k in ("ui/", "power", "rtc", "netstatus", "ps2_mouse", "input03", "keyboard.c")): print(f"  clang warnings in {rel}:\n{e[:800]}")
    objs.append(obj)
# DESKTOP-01: assemble the generated VexScript output exactly as build.ps1 does
vexobj = os.path.join(O, "vex_terminal.o")
run(["clang", "--target=x86_64-unknown-elf", "-c", "-x", "assembler", os.path.join(root, "kernel/src/apps/generated/vex_terminal.s"), "-o", vexobj]); objs.append(vexobj)
tb = os.path.join(B, "ap_trampoline.bin")
run(["nasm", "-f", "bin", os.path.join(root, "kernel/src/arch/x86_64/smp/ap_trampoline.asm"), "-o", tb])
assert os.path.getsize(tb) == 4096
os.makedirs(os.path.join(root, "build"), exist_ok=True)
shutil.copy(tb, os.path.join(root, "build/ap_trampoline.bin"))     # incbin path is repo-root relative
for rel in asm:
    obj = os.path.join(O, os.path.basename(rel)[:-4] + ".o")
    run(["nasm", "-f", "elf64", "-i", root + "/", os.path.join(root, rel), "-o", obj]); objs.append(obj)
elf, flat = os.path.join(B, "kernel.elf"), os.path.join(B, "KERNEL.ELF")
run(["ld.lld", "-nostdlib", "-no-pie", "-T", os.path.join(root, "kernel/linker.ld")] + objs + ["-o", elf])
run(["llvm-objcopy", "-O", "binary", elf, flat])
bobj, efi = os.path.join(B, "main_win.obj"), os.path.join(B, "BOOTX64.EFI")
run(["clang", "--target=x86_64-unknown-windows", "-ffreestanding", "-fshort-wchar", "-fno-stack-protector", "-mno-red-zone", "-Wall", "-Wextra",
     "-I", os.path.join(root, "bootloader/include"), "-I", cinc, "-c", os.path.join(root, "bootloader/src/main_win.c"), "-o", bobj])
run(["lld-link", bobj, "/entry:efi_main", "/subsystem:efi_application", "/machine:x64", "/nodefaultlib", f"/out:{efi}"])
img = os.path.join(B, "vexos-win.img")
run(["dd", "if=/dev/zero", f"of={img}", "bs=1M", "count=12", "status=none"]); run(["mformat", "-i", img, "::"])
run(["mmd", "-i", img, "::/EFI"]); run(["mmd", "-i", img, "::/EFI/BOOT"])
run(["mcopy", "-i", img, efi, "::/EFI/BOOT/BOOTX64.EFI"]); run(["mcopy", "-i", img, flat, "::/KERNEL.ELF"])
print(f"clang/lld build OK: {len(cs)} C + {len(asm)} asm sources, KERNEL.ELF={os.path.getsize(flat)} bytes, BOOTX64.EFI={os.path.getsize(efi)} bytes, {warn} clang warning(s) total")
from qemu_drive import Vm
vm = Vm(img, B, tag="win"); ok = vm.wait_serial(r"\[ui\] (setup|lock) screen shown", 120); import time; time.sleep(2); s = vm.serial(); vm.stop()
for pat, nm in [(r"105/105 checks passed", "BOOT-03"), (r"210/210 KERNEL-01", "KERNEL-01"), (r"97/97 SECURITY-01", "SECURITY-01"),
                (r"108/108 SECURITY-02", "SECURITY-02"), (r"(\d+)/\1 INPUT-03", "INPUT-03"), (r"(\d+)/\1 DESKTOP-01", "DESKTOP-01"), (r"DESKTOP-01 budget 20 MiB \(20971520 B\): PASS", "memory < 20 MiB budget"), (r"SYSTEM READY", "SYSTEM READY")]:
    print(("PASS  " if re.search(pat, s) else "FAIL  ") + "clang/lld image: " + nm); ok = ok and bool(re.search(pat, s))
print("memory:", re.search(r"TOTAL: .*", s).group(0))
sys.exit(0 if ok else 1)
