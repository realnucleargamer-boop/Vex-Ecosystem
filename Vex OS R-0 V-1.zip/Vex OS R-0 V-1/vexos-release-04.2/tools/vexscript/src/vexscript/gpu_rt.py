"""
VEX AI 1.2 GPU-friendly, batched population/genome runtime.

Honesty first, because this module's whole point is not to overclaim:

  - This sandbox has NO NVIDIA GPU and NO working PyTorch install (a real
    `pip install torch` was attempted and failed on disk space pulling in
    the CUDA wheel set; see docs/ARCHITECTURE_MAP_1.2.md "GPU status" for
    the exact transcript). `torch.cuda.is_available()` cannot be exercised
    as True anywhere in this pass.
  - This module is therefore written against a small `xp` (array-module)
    abstraction: it imports `torch` if available and dispatches to
    `torch.device('cuda')` when `torch.cuda.is_available()` is True, to
    `torch.device('cpu')` when torch is present but CUDA is not, and falls
    back to plain NumPy (CPU-only, no PyTorch at all) when torch cannot be
    imported -- which is the actual, exercised path in this environment.
  - Every function below is fully vectorized (no Python loop over
    individuals) regardless of which backend is active, which is the part
    of the spec ("batch everything", "GPU-native representation") that
    does not require real GPU hardware to implement and test correctly.
    What DOES require real hardware -- actual CUDA kernel execution, real
    VRAM residency, measured GPU utilization -- is implemented as the code
    path that would run if `backend_name() == "cuda"`, but is UNTESTED on
    real silicon in this pass. `device_info()` reports this distinction
    honestly rather than reporting fabricated VRAM numbers.
"""
from __future__ import annotations

import math

try:
    import torch as _torch
    _HAVE_TORCH = True
except Exception:  # pragma: no cover - exercised in this sandbox
    _torch = None
    _HAVE_TORCH = False

import numpy as _np

CHARSET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 .,/'\\;[]-=+{}><?"
_CHARSET_CODES = _np.array([ord(c) for c in CHARSET], dtype=_np.int64)


def backend_name() -> str:
    """'cuda' | 'torch-cpu' | 'numpy-cpu' -- always the REAL, currently
    active backend, never a claim about hardware that isn't there."""
    if _HAVE_TORCH:
        try:
            if _torch.cuda.is_available():
                return "cuda"
        except Exception:
            pass
        return "torch-cpu"
    return "numpy-cpu"


def device_info() -> dict:
    """Real, measured device info. VRAM fields are 0 / None when not on
    CUDA -- never fabricated."""
    name = backend_name()
    info = {
        "backend": name,
        "gpu_name": None,
        "vram_total_bytes": 0,
        "vram_allocated_bytes": 0,
        "vram_reserved_bytes": 0,
        "vram_peak_allocated_bytes": 0,
        "cpu_count": _cpu_count(),
    }
    if name == "cuda":
        info["gpu_name"] = _torch.cuda.get_device_name(0)
        info["vram_total_bytes"] = _torch.cuda.get_device_properties(0).total_memory
        info["vram_allocated_bytes"] = _torch.cuda.memory_allocated(0)
        info["vram_reserved_bytes"] = _torch.cuda.memory_reserved(0)
        info["vram_peak_allocated_bytes"] = _torch.cuda.max_memory_allocated(0)
    return info


def _cpu_count() -> int:
    import os
    return os.cpu_count() or 1


# ---- population handles -------------------------------------------------

_POPULATIONS: dict[int, dict] = {}
_NEXT_HANDLE = 1


def _array_module():
    if _HAVE_TORCH:
        return _torch
    return _np


def _new_rng(seed: int):
    if _HAVE_TORCH:
        g = _torch.Generator()
        g.manual_seed(int(seed))
        return g
    return _np.random.default_rng(int(seed))


def pop_create(pop_size: int, gene_len: int, seed: int) -> int:
    """Allocate a pop_size x gene_len integer-code population tensor,
    randomly filled from CHARSET, fully vectorized (a single random draw
    over the whole population, not a per-individual loop)."""
    global _NEXT_HANDLE
    pop_size, gene_len, seed = int(pop_size), int(gene_len), int(seed)
    if _HAVE_TORCH:
        device = _torch.device("cuda" if backend_name() == "cuda" else "cpu")
        g = _torch.Generator(device="cpu")
        g.manual_seed(seed)
        idx = _torch.randint(0, len(CHARSET), (pop_size, gene_len), generator=g)
        codes = _torch.tensor(_CHARSET_CODES, dtype=_torch.int64)[idx].to(device)
        fitness = _torch.zeros(pop_size, dtype=_torch.int64, device=device)
    else:
        rng = _np.random.default_rng(seed)
        idx = rng.integers(0, len(CHARSET), size=(pop_size, gene_len))
        codes = _CHARSET_CODES[idx]
        fitness = _np.zeros(pop_size, dtype=_np.int64)

    h = _NEXT_HANDLE
    _NEXT_HANDLE += 1
    _POPULATIONS[h] = {
        "codes": codes, "fitness": fitness, "pop_size": pop_size,
        "gene_len": gene_len, "seed": seed, "gen_counter": 0,
    }
    return h


def pop_size_of(handle: int) -> int:
    return _POPULATIONS[int(handle)]["pop_size"]


def pop_gene_len(handle: int) -> int:
    return _POPULATIONS[int(handle)]["gene_len"]


def pop_generation(handle: int) -> int:
    return _POPULATIONS[int(handle)]["gen_counter"]


def _codes_to_str(codes_row) -> str:
    if _HAVE_TORCH and isinstance(codes_row, _torch.Tensor):
        codes_row = codes_row.cpu().numpy()
    return "".join(chr(int(c)) for c in codes_row)


def pop_string_at(handle: int, index: int) -> str:
    p = _POPULATIONS[int(handle)]
    return _codes_to_str(p["codes"][int(index)])


# ---- batched fitness ------------------------------------------------------

def pop_fitness_structural_batch(handle: int) -> int:
    """Input-Only mode fitness (no target string anywhere): a deterministic
    structural proxy -- count of letter characters (A-Z or a-z) per
    individual, fully vectorized. Same honest-placeholder spirit as 1.0's
    evaluate_input_only / 1.1's reasoning heuristic: this does not
    represent finished intelligence, it exists so the batched
    Generation/Logic pipeline can be exercised without a supervised
    target. Returns the best index."""
    p = _POPULATIONS[int(handle)]
    codes = p["codes"]
    is_letter = ((codes >= 65) & (codes <= 90)) | ((codes >= 97) & (codes <= 122))
    if _HAVE_TORCH:
        score = is_letter.sum(dim=1)
        p["fitness"] = score
        best = int(_torch.argmax(score).item())
    else:
        score = is_letter.sum(axis=1)
        p["fitness"] = score
        best = int(_np.argmax(score))
    return best


def pop_fitness_target_batch(handle: int, target: str) -> int:
    """Vectorized character-position match count against `target` for
    every individual at once. Returns the best index."""
    p = _POPULATIONS[int(handle)]
    codes = p["codes"]
    gene_len = p["gene_len"]
    tgt_codes = [ord(c) for c in target[:gene_len]]
    tgt_len = len(tgt_codes)

    if _HAVE_TORCH:
        tgt = _torch.tensor(tgt_codes, dtype=codes.dtype, device=codes.device)
        matches = (codes[:, :tgt_len] == tgt).sum(dim=1)
        p["fitness"] = matches
        best = int(_torch.argmax(matches).item())
    else:
        tgt = _np.array(tgt_codes, dtype=codes.dtype)
        matches = (codes[:, :tgt_len] == tgt[None, :]).sum(axis=1)
        p["fitness"] = matches
        best = int(_np.argmax(matches))
    return best


def pop_reasoning_bonus_batch(handle: int, reference_upper_count: int) -> int:
    """Vectorized structural-consistency bonus: how close each individual's
    uppercase-letter count is to `reference_upper_count` (the Logic
    population's elite's uppercase count). Adds the bonus into the stored
    fitness (the actual Generation<->Logic feedback path). Returns the new
    best index."""
    p = _POPULATIONS[int(handle)]
    codes = p["codes"]
    is_upper = (codes >= 65) & (codes <= 90)

    if _HAVE_TORCH:
        upper_count = is_upper.sum(dim=1)
        diff = (upper_count - int(reference_upper_count)).abs()
        bonus = _torch.clamp(3 - diff, min=0, max=3)
        p["fitness"] = p["fitness"] + bonus
        best = int(_torch.argmax(p["fitness"]).item())
    else:
        upper_count = is_upper.sum(axis=1)
        diff = _np.abs(upper_count - int(reference_upper_count))
        bonus = _np.clip(3 - diff, 0, 3)
        p["fitness"] = p["fitness"] + bonus
        best = int(_np.argmax(p["fitness"]))
    return best


def pop_upper_count_at(handle: int, index: int) -> int:
    p = _POPULATIONS[int(handle)]
    row = p["codes"][int(index)]
    if _HAVE_TORCH:
        return int((((row >= 65) & (row <= 90)).sum()).item())
    return int(((row >= 65) & (row <= 90)).sum())


def pop_best_index(handle: int) -> int:
    p = _POPULATIONS[int(handle)]
    if _HAVE_TORCH:
        return int(_torch.argmax(p["fitness"]).item())
    return int(_np.argmax(p["fitness"]))


def pop_best_fitness(handle: int) -> int:
    p = _POPULATIONS[int(handle)]
    i = pop_best_index(handle)
    if _HAVE_TORCH:
        return int(p["fitness"][i].item())
    return int(p["fitness"][i])


def pop_avg_fitness_milli(handle: int) -> int:
    """Average fitness * 1000, as an integer (VexScript has no floats in
    this API path -- consistent with evolve_rt.fitness_average's int style)."""
    p = _POPULATIONS[int(handle)]
    if _HAVE_TORCH:
        avg = float(p["fitness"].float().mean().item())
    else:
        avg = float(p["fitness"].mean())
    return int(avg * 1000)


# ---- batched elitism + crossover + mutation (one full generation step) ---

def pop_advance_batch(handle: int, elite_count: int, mutate_rate_milli: int, seed_step: int) -> int:
    """One full generation step, fully vectorized:
      1. elite_count fittest individuals are copied into the front of the
         next generation unchanged (argsort once, no per-individual loop).
      2. every remaining slot gets a single-point crossover of two parents
         drawn (with replacement) from the whole current population, with
         the crossover point chosen independently per offspring -- built
         with one batch of random draws and one broadcasted comparison
         against arange(gene_len), not a Python loop over offspring.
      3. point mutation is applied with probability mutate_rate_milli/1000
         per character, again as one batched random draw + one masked
         write, not a per-character Python loop.
    Returns the (possibly shifted) best index, which is always 0 after
    this call since elites are sorted to the front.
    """
    p = _POPULATIONS[int(handle)]
    codes = p["codes"]
    fitness = p["fitness"]
    pop_size, gene_len = p["pop_size"], p["gene_len"]
    elite_count = max(1, int(elite_count))
    rate = int(mutate_rate_milli)

    if _HAVE_TORCH:
        device = codes.device
        order = _torch.argsort(fitness, descending=True)
        sorted_codes = codes[order]
        n_children = pop_size - elite_count
        g = _torch.Generator(device="cpu")
        g.manual_seed(int(p["seed"]) + int(seed_step))
        parents_a = _torch.randint(0, pop_size, (n_children,), generator=g).to(device)
        parents_b = _torch.randint(0, pop_size, (n_children,), generator=g).to(device)
        cut = _torch.randint(0, gene_len, (n_children, 1), generator=g).to(device)
        pos = _torch.arange(gene_len, device=device).unsqueeze(0)
        take_a = pos < cut
        child = _torch.where(take_a, sorted_codes[parents_a], sorted_codes[parents_b])
        mut_mask = (_torch.rand((n_children, gene_len), generator=g).to(device) * 1000 < rate)
        rand_chars = _torch.tensor(_CHARSET_CODES, dtype=codes.dtype, device=device)[
            _torch.randint(0, len(CHARSET), (n_children, gene_len), generator=g).to(device)
        ]
        child = _torch.where(mut_mask, rand_chars, child)
        new_codes = _torch.cat([sorted_codes[:elite_count], child], dim=0)
        new_fitness = _torch.zeros(pop_size, dtype=fitness.dtype, device=device)
        new_fitness[:elite_count] = fitness[order][:elite_count]
        p["codes"] = new_codes
        p["fitness"] = new_fitness
    else:
        order = _np.argsort(-fitness)
        sorted_codes = codes[order]
        n_children = pop_size - elite_count
        rng = _np.random.default_rng(int(p["seed"]) + int(seed_step))
        parents_a = rng.integers(0, pop_size, size=n_children)
        parents_b = rng.integers(0, pop_size, size=n_children)
        cut = rng.integers(0, gene_len, size=(n_children, 1))
        pos = _np.arange(gene_len)[None, :]
        take_a = pos < cut
        child = _np.where(take_a, sorted_codes[parents_a], sorted_codes[parents_b])
        mut_mask = rng.integers(0, 1000, size=(n_children, gene_len)) < rate
        rand_idx = rng.integers(0, len(CHARSET), size=(n_children, gene_len))
        rand_chars = _CHARSET_CODES[rand_idx]
        child = _np.where(mut_mask, rand_chars, child)
        new_codes = _np.concatenate([sorted_codes[:elite_count], child], axis=0)
        new_fitness = _np.zeros(pop_size, dtype=fitness.dtype)
        new_fitness[:elite_count] = fitness[order][:elite_count]
        p["codes"] = new_codes
        p["fitness"] = new_fitness

    p["gen_counter"] += 1
    return 0


def pop_elite_unchanged_check(handle: int, saved_row) -> bool:
    """Test helper: compare a previously-saved elite row to the current
    front row (used by the regression test, not by the VEX AI driver)."""
    p = _POPULATIONS[int(handle)]
    row = p["codes"][0]
    if _HAVE_TORCH:
        row = row.cpu().numpy()
        saved_row = saved_row if not isinstance(saved_row, _torch.Tensor) else saved_row.cpu().numpy()
    return bool((_np.array(row) == _np.array(saved_row)).all())
