/*
 * Vex OS - kernel/src/arch/x86_64/time/pit_delay.c
 *
 * See kernel/include/pit_delay.h for why the PIT is used here instead
 * of a spin loop.
 */

#include "pit_delay.h"
#include "serial.h"

#define PIT_PORT_CH2_DATA 0x42
#define PIT_PORT_COMMAND  0x43
#define PORT_SPEAKER_CTRL 0x61

/* Mode/Command register: select channel 2, access mode "lobyte/hibyte",
 * operating mode 0 (interrupt on terminal count - for channel 2 this
 * simply means the output goes high when the count reaches zero, which
 * is precisely the edge being polled), binary counting. */
#define PIT_CMD_CH2_ONESHOT 0xB0

/* Port 0x61: bit 0 = channel 2 gate (must be 1 for the counter to
 * run), bit 1 = speaker data enable (left 0 so nothing is audible),
 * bit 5 = channel 2 output status, readable. */
#define SPEAKER_GATE_CH2  0x01
#define SPEAKER_DATA_EN   0x02
#define SPEAKER_CH2_OUT   0x20

static int pit_usable = 0;
static int pit_probed = 0;

static inline void outb(uint16_t port, uint8_t val)
{
    __asm__ volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint8_t inb(uint16_t port)
{
    uint8_t v;
    __asm__ volatile ("inb %1, %0" : "=a"(v) : "Nd"(port));
    return v;
}

/* Runs one PIT channel-2 shot of `ticks` and polls until its output
 * goes high. `max_spin` bounds the poll so a machine that does not
 * implement the status bit cannot hang the kernel here.
 *
 * Returns 1 if the output transition was observed, 0 if the bound was
 * hit first. */
static int pit_one_shot(uint16_t ticks, uint32_t max_spin)
{
    uint8_t ctrl = inb(PORT_SPEAKER_CTRL);

    /* Drop the gate first so the counter is reloaded from a known
     * state, and make sure the speaker itself stays disabled. */
    ctrl = (uint8_t)((ctrl & ~(SPEAKER_GATE_CH2 | SPEAKER_DATA_EN)));
    outb(PORT_SPEAKER_CTRL, ctrl);

    outb(PIT_PORT_COMMAND, PIT_CMD_CH2_ONESHOT);
    outb(PIT_PORT_CH2_DATA, (uint8_t)(ticks & 0xFF));
    outb(PIT_PORT_CH2_DATA, (uint8_t)((ticks >> 8) & 0xFF));

    /* Raise the gate: the counter starts now. */
    outb(PORT_SPEAKER_CTRL, (uint8_t)(ctrl | SPEAKER_GATE_CH2));

    for (uint32_t i = 0; i < max_spin; i++) {
        if (inb(PORT_SPEAKER_CTRL) & SPEAKER_CH2_OUT) {
            /* Drop the gate again so the channel is left idle. */
            outb(PORT_SPEAKER_CTRL, ctrl);
            return 1;
        }
        __asm__ volatile ("pause");
    }

    outb(PORT_SPEAKER_CTRL, ctrl);
    return 0;
}

int pit_delay_probe(void)
{
    if (pit_probed) {
        return pit_usable;
    }
    pit_probed = 1;

    /* Ask for a very short shot (~100 us) and require the output
     * transition to be observed. A machine that does not implement the
     * channel-2 status bit will either never set it or have it stuck
     * set; both are caught here.
     *
     * A stuck-high status bit is checked first: if the output already
     * reads high while the gate is down, polling it proves nothing. */
    uint8_t ctrl = inb(PORT_SPEAKER_CTRL);
    outb(PORT_SPEAKER_CTRL, (uint8_t)(ctrl & ~(SPEAKER_GATE_CH2 | SPEAKER_DATA_EN)));
    outb(PIT_PORT_COMMAND, PIT_CMD_CH2_ONESHOT);
    outb(PIT_PORT_CH2_DATA, 0xFF);
    outb(PIT_PORT_CH2_DATA, 0xFF);
    if (inb(PORT_SPEAKER_CTRL) & SPEAKER_CH2_OUT) {
        serial_puts("[kernel] PIT: channel 2 output reads high with gate low"
                    " - status bit not usable\n");
        pit_usable = 0;
        return 0;
    }

    if (!pit_one_shot(120, 20000000u)) {
        serial_puts("[kernel] PIT: channel 2 output never asserted"
                    " - polled delays not available\n");
        pit_usable = 0;
        return 0;
    }

    pit_usable = 1;
    return 1;
}

/* Fallback used only when the PIT status bit is unusable.
 *
 * This is explicitly NOT calibrated. It is a bounded spin whose real
 * duration is unknown, and it exists so that a machine without a usable
 * PIT still gets *some* separation between INIT and SIPI instead of
 * none. Any milestone that depends on accurate delays needs a real
 * timer; this is not one. */
static void uncalibrated_spin(uint32_t us)
{
    /* Deliberately pessimistic: assume a very fast CPU so the loop errs
     * on the side of waiting too long rather than too little. */
    volatile uint32_t sink = 0;
    for (uint32_t i = 0; i < us; i++) {
        for (uint32_t j = 0; j < 20000u; j++) {
            sink += j;
            __asm__ volatile ("pause");
        }
    }
    (void)sink;
}

void pit_delay_us(uint32_t us)
{
    if (us == 0) {
        return;
    }

    if (!pit_probed) {
        pit_delay_probe();
    }
    if (!pit_usable) {
        uncalibrated_spin(us);
        return;
    }

    /* Convert microseconds to PIT ticks. Done in 64-bit to avoid
     * overflow, and rounded UP so a requested minimum wait is never
     * undershot by truncation. */
    uint64_t ticks = ((uint64_t)us * (uint64_t)PIT_FREQUENCY_HZ
                      + 999999u) / 1000000u;
    if (ticks == 0) {
        ticks = 1;
    }

    while (ticks > 0) {
        uint64_t chunk = ticks > PIT_MAX_TICKS ? PIT_MAX_TICKS : ticks;
        /* The spin bound is large enough to cover the full chunk on any
         * plausible CPU, but still finite. */
        if (!pit_one_shot((uint16_t)chunk, 200000000u)) {
            /* The PIT worked during probing and has now stopped
             * responding. Report it once and degrade rather than
             * spinning here forever. */
            serial_puts("[kernel] PIT: shot timed out mid-delay,"
                        " falling back to uncalibrated spin\n");
            pit_usable = 0;
            uncalibrated_spin(us);
            return;
        }
        ticks -= chunk;
    }
}
