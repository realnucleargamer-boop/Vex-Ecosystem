# VEX OS Runtime Upgrade

This isolated package is copied from the validated VEX OS baseline. It adds a
live runtime status UI and a QEMU PS/2 keyboard polling frontend that publishes
INPUT-02 events. The original validated source is not used or modified at run time.

After a build, launch with:
`powershell -ExecutionPolicy Bypass -File .\run-vexos.ps1`

See `docs/RUNTIME-UPGRADE.md` for limits and validation status.

## SECURITY-02
Ring 3 foundation, Graphics/kernel audit, runtime-ESP hash sync. See `docs/SECURITY-02.md`.

## LOCK-01 / INPUT-03
Graphical lock screen, PS/2 mouse, passwordless `Vex` session, real power controls. See `docs/LOCK-01.md`.

## DESKTOP-01
First-run account setup, desktop shell, and the Vex Terminal (VexScript). See `docs/DESKTOP-01.md`.

## RELEASE-02
Passwords, multi-user, File Explorer, Task Manager, <15 MiB image. See `docs/RELEASE-02.md`.

## RELEASE-03
See `docs/RELEASE-03.md`.
