/*
 * Vex OS - kernel/src/graphics/gfx_fb.c
 *
 * Framebuffer initialisation and pixel-round-trip selftest.
 * Reads directly from BootInfo.  No Limine.  No external types.
 */

#include "gfx/fb.h"
#include "serial.h"

int gfx_fb_init(GfxFb *fb, const BootInfo *info)
{
    /* SECURITY-02: a failed (or repeated) init must not leave the
     * previous call's pixels/width/height behind. Before this, a second
     * gfx_fb_init() that FAILED left fb->ok == 0 but kept the old
     * pointer and dimensions, and any primitive that did not test ok
     * would keep drawing through a stale pointer. Zeroing everything
     * first means every failure path ends in a descriptor that clips
     * every draw away, whether or not the caller checks ok. */
    fb->ok = 0;
    fb->pixels = 0;
    fb->width = 0;
    fb->height = 0;
    fb->pitch_px = 0;
    fb->r_shift = fb->g_shift = fb->b_shift = 0;

    if (info->framebuffer_addr == 0 || info->framebuffer_size == 0) {
        serial_puts("[gfx] no framebuffer from bootloader\n");
        return 0;
    }
    if (info->framebuffer_width == 0 || info->framebuffer_height == 0) {
        serial_puts("[gfx] framebuffer has zero dimensions\n");
        return 0;
    }
    if (info->framebuffer_bpp != 32) {
        serial_puts("[gfx] unsupported bpp (not 32): ");
        serial_put_dec64(info->framebuffer_bpp);
        serial_puts("\n");
        return 0;
    }

    VexPixelFormat fmt = (VexPixelFormat)info->framebuffer_pixel_format;
    uint8_t rs, gs, bs;
    switch (fmt) {
        case VEX_PIXEL_FORMAT_RGBX8:
            rs = 0; gs = 8; bs = 16; break;
        case VEX_PIXEL_FORMAT_BGRX8:
            bs = 0; gs = 8; rs = 16; break;
        default:
            serial_puts("[gfx] unsupported pixel format (not RGBX8/BGRX8)\n");
            return 0;
    }

    /* pitch is in bytes; we want it in 32-bit words. */
    uint32_t pitch_bytes = info->framebuffer_pitch;
    if (pitch_bytes % 4 != 0) {
        serial_puts("[gfx] framebuffer pitch not divisible by 4\n");
        return 0;
    }

    /* SECURITY-02 Graphics audit finding: every draw primitive (gfx_put,
     * gfx_fill_rect, gfx_clear, ...) computes its pixel offset as
     * `row * pitch_px + col` and trusts fb->width/height/pitch_px as the
     * bound it clips against. None of that protects anything if those
     * fields themselves describe a region LARGER than the framebuffer
     * BootInfo actually reported - every "in-bounds" write per those
     * fields would then be an out-of-bounds write against the real
     * allocation. This was never checked before now. Two checks, both
     * done in 64-bit arithmetic so the validation itself cannot
     * overflow even if the inputs are hostile:
     *
     *   (a) a scanline must fit within its own stride: width <= pitch_px
     *   (b) the whole image must fit within the reported size:
     *       pitch_bytes * height <= framebuffer_size
     *
     * Rejecting here, once, is what makes every later gfx_* primitive's
     * "clip to fb->width/height" actually mean "clip to the real
     * framebuffer" rather than "clip to numbers BootInfo happened to
     * report". */
    uint64_t pitch_px_64 = (uint64_t)pitch_bytes / 4;
    if ((uint64_t)info->framebuffer_width > pitch_px_64) {
        serial_puts("[gfx] framebuffer width exceeds pitch (would alias rows)\n");
        return 0;
    }
    uint64_t required_bytes = (uint64_t)pitch_bytes * (uint64_t)info->framebuffer_height;
    if (required_bytes > info->framebuffer_size) {
        serial_puts("[gfx] framebuffer pitch*height exceeds reported size\n");
        return 0;
    }
    /* The draw primitives index with 32-bit arithmetic
     * (row * pitch_px + col). If the whole image spans under 4 GiB, then
     * pitch_px * height < 2^30, so every in-bounds index fits in 32 bits
     * with room to spare - the arithmetic is provably overflow-free for
     * anything this check lets through, instead of merely unlikely to
     * overflow. */
    if (required_bytes > 0xFFFFFFFFULL) {
        serial_puts("[gfx] framebuffer span exceeds 4 GiB, refusing\n");
        return 0;
    }
    /* Sanity ceiling: keeps every later `pitch_px * y` / `x + width`
     * computation (done in 32-bit arithmetic in the draw primitives, by
     * design, for performance) comfortably clear of overflow for any
     * input that passes the checks above, with wide margin -
     * 65536x65536 is already far beyond any real display mode. */
    if (info->framebuffer_width > 65536 || info->framebuffer_height > 65536) {
        serial_puts("[gfx] framebuffer dimensions implausibly large, refusing\n");
        return 0;
    }

    fb->pixels   = (volatile uint32_t *)(uintptr_t)info->framebuffer_addr;
    fb->width    = info->framebuffer_width;
    fb->height   = info->framebuffer_height;
    fb->pitch_px = pitch_bytes / 4;
    fb->r_shift  = rs;
    fb->g_shift  = gs;
    fb->b_shift  = bs;
    fb->ok       = 1;

    serial_puts("[gfx] framebuffer: ");
    serial_put_dec64(fb->width);
    serial_puts("x");
    serial_put_dec64(fb->height);
    serial_puts(" bpp=32 pitch_px=");
    serial_put_dec64(fb->pitch_px);
    serial_puts(fmt == VEX_PIXEL_FORMAT_RGBX8 ? " RGBX8\n" : " BGRX8\n");

    return 1;
}

int gfx_fb_selftest(GfxFb *fb)
{
    if (!fb->ok) return 0;

    /* Bottom-right corner: least likely to be visible if left dirty. */
    int32_t tx = (int32_t)fb->width  - 1;
    int32_t ty = (int32_t)fb->height - 1;

    /* Probe colour chosen to exercise all three channels distinctly. */
    GfxColor probe = gfx_rgb(0x12, 0x34, 0x56);

    /* Save original pixel. */
    uint32_t saved = fb->pixels[(uint32_t)ty * fb->pitch_px + (uint32_t)tx];

    /* Write probe. */
    gfx_put(fb, tx, ty, probe);

    /* Read back and decode. */
    GfxColor got = gfx_get(fb, tx, ty);

    /* Restore. */
    fb->pixels[(uint32_t)ty * fb->pitch_px + (uint32_t)tx] = saved;

    /* Tolerate ±8 for any quantisation in unusual modes. */
    int dr = (int)got.r - (int)probe.r; if (dr < 0) dr = -dr;
    int dg = (int)got.g - (int)probe.g; if (dg < 0) dg = -dg;
    int db = (int)got.b - (int)probe.b; if (db < 0) db = -db;
    int pass = (dr <= 8 && dg <= 8 && db <= 8);

    serial_puts(pass ? "[gfx] selftest: PASS\n" : "[gfx] selftest: FAIL\n");
    return pass;
}
