/*
 * Vex OS - kernel/include/context.h
 *
 * BOOT-03 kernel execution contexts.
 *
 * A KernelContext is the minimum needed to stop executing one kernel
 * thread of control and start another on the same CPU: a stack, and a
 * saved stack pointer. Everything the System V AMD64 ABI requires to be
 * preserved across a call is saved ON that stack by context_switch,
 * which is why the struct itself is nearly empty.
 *
 * THIS IS NOT A SCHEDULER, and BOOT-03 does not add one. There is no run
 * queue, no priority, no preemption, no yielding on a timer tick, and no
 * blocking. The switch is strictly cooperative and explicit: code calls
 * context_switch and control moves. The purpose in BOOT-03 is to
 * establish and PROVE the mechanism - that a second stack can be entered
 * and returned from without corrupting the first - so that a scheduler
 * built later is built on something already known to work.
 *
 * WHAT IS SAVED
 *
 *   context_switch saves the callee-saved registers (RBX, RBP, R12-R15)
 *   and RFLAGS on the outgoing stack, stores RSP into the outgoing
 *   context, loads RSP from the incoming context, and restores. The
 *   caller-saved registers are deliberately NOT saved: by the ABI, the
 *   caller of context_switch has already accepted that they may be
 *   clobbered by any call. Saving them would be dead work.
 *
 *   Not saved, and stated rather than implied: FPU/SSE/AVX state (no
 *   context here uses it, and CR0/CR4 are not configured for it), the
 *   segment registers (flat, and GS base is per-CPU, not per-context),
 *   and CR3 (all kernel contexts share the kernel address space).
 */

#ifndef VEXOS_CONTEXT_H
#define VEXOS_CONTEXT_H

#include <stdint.h>
#include "kstack.h"

#define CONTEXT_MAGIC 0x564558334354584BULL   /* "VEX3CTXK" */

typedef void (*ContextEntry)(uint64_t arg);

typedef struct KernelContext {
    /* Saved stack pointer. MUST be at offset 0: context_switch.asm
     * addresses it as [rdi] and [rsi] with no displacement. */
    uint64_t rsp;

    uint64_t magic;
    KernelStack stack;
    ContextEntry entry;
    uint64_t arg;
    const char *name;
    uint64_t started;      /* 1 once the entry function has been reached */
    uint64_t switches_in;  /* times this context has been switched TO */
} KernelContext;

_Static_assert(__builtin_offsetof(KernelContext, rsp) == 0,
               "KernelContext.rsp must be at offset 0 - context_switch.asm "
               "depends on it");

/* Prepares `ctx` to begin executing `entry(arg)` on a freshly allocated
 * guarded kernel stack. Returns 1 on success, 0 if a stack could not be
 * allocated. Does not switch to it. */
int context_create(KernelContext *ctx, const char *name,
                   ContextEntry entry, uint64_t arg);

/* Initializes `ctx` to describe the CURRENTLY executing context, so
 * there is something to switch back to. No stack is allocated - the
 * context adopts the stack it is already running on. */
void context_adopt_current(KernelContext *ctx, const char *name);

/* Saves the current execution state into `from` and resumes `to`.
 * Implemented in context_switch.asm.
 *
 * Returns to its caller when some other code switches BACK to `from`.
 * That is the whole trick and the only surprising thing about it. */
void context_switch(KernelContext *from, KernelContext *to);

/* Where a context entry function goes if it ever returns. Panics: a
 * context with nothing to return to must not fall off the end of its
 * stack into whatever the next quadword happens to be. Exposed so the
 * test can reference it. */
void context_entry_returned(void);

#endif /* VEXOS_CONTEXT_H */
