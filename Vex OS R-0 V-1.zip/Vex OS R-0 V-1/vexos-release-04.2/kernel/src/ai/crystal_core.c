/*
 * crystal_core.c - VEX AI 1.5-Crystal native inference core. See kernel/include/crystal_core.h and
 * docs/CRYSTAL-NATIVE-01.md. Every behaviour here mirrors a specific part of vex-ai-1.5-crystal/scripts/engine.py
 * (function names are cited in comments). Integer fixed point only: the kernel has no FPU/SSE state management.
 *
 * Freestanding: <stdint.h>/<stddef.h> only. No libc, no heap, no globals that are written, no recursion.
 * __int128 is used for multiplies/shifts/adds only (compiled inline); 128-bit division is never used.
 */
#include "crystal_core.h"

#define ONE_Q30 1073741824LL
#define W_STEM  644245094LL   /* 0.6 */
#define W_BI    858993459LL   /* 0.8 */
#define W_TRI   536870912LL   /* 0.5 */
#define W_FIRST 1288490189LL  /* 1.2 */
#define W_LEN   429496730LL   /* 0.4 */
#define W_Q     536870912LL   /* 0.5 */
#define W_QUOTE 322122547LL   /* 0.3 */
#define LN2_Q40 762123384786LL
#define HID_CLAMP_Q30 (16LL << 30)   /* hidden activations are clamped to 16.0 (bounded arithmetic; trained model stays far below) */

/* ------------------------------------------------------------------ tiny helpers */
static int isd(int c) { return c >= '0' && c <= '9'; }
static int isl(int c) { return c >= 'a' && c <= 'z'; }
static int isw(int c) { return isd(c) || isl(c) || (c >= 'A' && c <= 'Z') || c == '_'; }   /* regex \w, ASCII */
static int lower_c(int c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }
static size_t slen(const char *s) { size_t n = 0; while (s[n]) n++; return n; }
static int mem_eq(const char *a, const char *b, size_t n) { for (size_t i = 0; i < n; i++) if (a[i] != b[i]) return 0; return 1; }

static uint32_t rd32u(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }
static int32_t  rd32s(const uint8_t *p) { return (int32_t)rd32u(p); }

/* ------------------------------------------------------------------ CRC-32 (zlib-compatible), nibble table */
static const uint32_t crc_nib[16] = {
    0x00000000u, 0x1DB71064u, 0x3B6E20C8u, 0x26D930ACu,
    0x76DC4190u, 0x6B6B51F4u, 0x4DB26158u, 0x5005713Cu,
    0xEDB88320u, 0xF00F9344u, 0xD6D6A3E8u, 0xCB61B38Cu,
    0x9B64C2B0u, 0x86D3D2D4u, 0xA00AE278u, 0xBDBDF21Cu };
static uint32_t crc_upd(uint32_t c, const uint8_t *p, size_t n)
{
    for (size_t i = 0; i < n; i++) { c ^= p[i]; c = (c >> 4) ^ crc_nib[c & 15u]; c = (c >> 4) ^ crc_nib[c & 15u]; }
    return c;
}
uint32_t vxc_crc32(const uint8_t *p, size_t n) { return crc_upd(0xFFFFFFFFu, p, n) ^ 0xFFFFFFFFu; }

/* ------------------------------------------------------------------ model open */
static int str_is(const uint8_t *rec, const char *lit)
{
    size_t i = 0;
    for (; lit[i]; i++) if (rec[i] != (uint8_t)lit[i]) return 0;
    return rec[i] == 0;
}

int vxc_model_open(VxcModel *m, const uint8_t *b, size_t len, int verify_crc)
{
    if (!m) return VXC_E_MODEL;
    m->blob = 0; m->len = 0; m->feat = m->hidden = m->nint = m->reject_q = 0;
    m->w1 = m->b1 = m->wi = m->bi = m->labels = 0;
    for (int i = 0; i < VXC_MAX_INTENTS; i++) m->is_math[i] = m->is_mem[i] = 0;
    if (!b || len < 68) return VXC_E_MODEL;
    if (!(b[0] == 'V' && b[1] == 'X' && b[2] == 'C' && b[3] == 'R')) return VXC_E_MODEL;
    if (rd32u(b + 4) != 1u) return VXC_E_MODEL;
    uint32_t feat = rd32u(b + 8), hid = rd32u(b + 12), nint = rd32u(b + 16), frac = rd32u(b + 20), rq = rd32u(b + 24), hsz = rd32u(b + 28);
    if (frac != 30u || hsz != 64u) return VXC_E_MODEL;
    if (feat < 1 || feat > VXC_MAX_FEAT || hid < 1 || hid > VXC_MAX_HIDDEN || nint < 1 || nint > VXC_MAX_INTENTS) return VXC_E_MODEL;
    if (rq > (1u << 30)) return VXC_E_MODEL;
    uint64_t nw1 = (uint64_t)feat * hid, nwi = (uint64_t)hid * nint;
    uint64_t total = 64u + 4u * (nw1 + hid + nwi + nint) + (uint64_t)nint * 48u + 4u;
    if (total != (uint64_t)len) return VXC_E_MODEL;
    if (verify_crc && vxc_crc32(b, len - 4) != rd32u(b + len - 4)) return VXC_E_MODEL;
    const uint8_t *p = b + 64;
    m->w1 = p;  p += 4u * nw1;
    m->b1 = p;  p += 4u * hid;
    m->wi = p;  p += 4u * nwi;
    m->bi = p;  p += 4u * nint;
    m->labels = p;
    for (uint32_t i = 0; i < nint; i++) {            /* label/family must be NUL-terminated within their 24-byte fields */
        const uint8_t *rec = m->labels + (size_t)i * 48u; int l = 0, f = 0;
        for (int k = 0; k < 24; k++) { if (rec[k] == 0) l = 1; if (rec[24 + k] == 0) f = 1; }
        if (!l || !f) return VXC_E_MODEL;
        m->is_math[i] = str_is(rec + 24, "math") ? 1 : 0;
        m->is_mem[i]  = str_is(rec + 24, "memory_operations") ? 1 : 0;
    }
    m->blob = b; m->len = len; m->feat = feat; m->hidden = hid; m->nint = nint; m->reject_q = rq;
    return VXC_OK;
}

const char *vxc_intent_label(const VxcModel *m, int id)  { return (m && m->labels && id >= 0 && (uint32_t)id < m->nint) ? (const char *)(m->labels + (size_t)id * 48u) : ""; }
const char *vxc_intent_family(const VxcModel *m, int id) { return (m && m->labels && id >= 0 && (uint32_t)id < m->nint) ? (const char *)(m->labels + (size_t)id * 48u + 24u) : ""; }

/* ------------------------------------------------------------------ bounded writer */
typedef struct { char *p; size_t cap, n; int trunc; } Wr;
static void wc(Wr *w, char c) { if (w->n + 1 < w->cap) w->p[w->n++] = c; else w->trunc = 1; }
static void ws(Wr *w, const char *s) { while (*s) wc(w, *s++); }
static void wi64(Wr *w, int64_t v)
{
    char t[24]; int k = 0; uint64_t u = v < 0 ? (uint64_t)0 - (uint64_t)v : (uint64_t)v;
    if (v < 0) wc(w, '-');
    do { t[k++] = (char)('0' + (int)(u % 10u)); u /= 10u; } while (u && k < 23);
    while (k) wc(w, t[--k]);
}
static void wfin(Wr *w) { w->p[w->n] = 0; }   /* cap >= 1 is guaranteed by vxc_infer, and n <= cap-1 always */

/* ------------------------------------------------------------------ numbers (find_numbers / parse_math) */
typedef struct { int64_t v; int flags; } Num;   /* flags: 1 = non-integral decimal, 2 = |value| > 1e9 */
#define NF_DEC 1
#define NF_BIG 2

static Num mknum(const char *t, int neg, size_t ds, size_t de, size_t fs, size_t fe, int has_frac)
{
    Num r; r.v = 0; r.flags = 0; int64_t v = 0;
    for (size_t i = ds; i < de; i++) { v = v * 10 + (t[i] - '0'); if (v > 4000000000LL) { v = 4000000000LL; r.flags |= NF_BIG; } }
    if (has_frac) for (size_t i = fs; i < fe; i++) if (t[i] != '0') r.flags |= NF_DEC;     /* "3.0" == int 3 in Python; "3.5" is not */
    if (v > VXC_MAX_NUM_OPERAND) r.flags |= NF_BIG;
    r.v = neg ? -v : v;
    return r;
}

static const struct { const char *w; int v; } numw[] = {
    {"zero",0},{"one",1},{"two",2},{"three",3},{"four",4},{"five",5},{"six",6},{"seven",7},{"eight",8},{"nine",9},{"ten",10},
    {"eleven",11},{"twelve",12},{"thirteen",13},{"fourteen",14},{"fifteen",15},{"sixteen",16},{"seventeen",17},{"eighteen",18},
    {"nineteen",19},{"twenty",20},{"thirty",30},{"forty",40},{"fifty",50},{"sixty",60},{"seventy",70},{"eighty",80},{"ninety",90},
    {"hundred",100},{"thousand",1000} };

/* find_numbers: re.finditer(r"(?<![\w.])-?\d+(?:\.\d+)?|[a-z]+", tl) */
static void scan_numbers(const char *t, size_t n, Num out[2], int *count)
{
    size_t i = 0; *count = 0;
    while (i < n) {
        int c = (unsigned char)t[i];
        int prev_ok = (i == 0) || !(isw((unsigned char)t[i - 1]) || t[i - 1] == '.');
        if (prev_ok && (isd(c) || (c == '-' && i + 1 < n && isd((unsigned char)t[i + 1])))) {
            size_t j = i; int neg = 0;
            if (c == '-') { neg = 1; j++; }
            size_t ds = j; while (j < n && isd((unsigned char)t[j])) j++;
            size_t de = j, fs = 0, fe = 0; int hf = 0;
            if (j + 1 < n && t[j] == '.' && isd((unsigned char)t[j + 1])) { j++; fs = j; while (j < n && isd((unsigned char)t[j])) j++; fe = j; hf = 1; }
            if (*count < 2) out[*count] = mknum(t, neg, ds, de, fs, fe, hf);
            (*count)++; i = j; continue;
        }
        if (isl(c)) {
            size_t j = i; while (j < n && isl((unsigned char)t[j])) j++;
            for (size_t k = 0; k < sizeof numw / sizeof numw[0]; k++) {
                size_t L = slen(numw[k].w);
                if (L == j - i && mem_eq(t + i, numw[k].w, L)) {
                    if (*count < 2) { out[*count].v = numw[k].v; out[*count].flags = 0; }
                    (*count)++; break;
                }
            }
            i = j; continue;
        }
        i++;
    }
}

/* regex \b word search. need_end: also require a boundary after the word (full-word pattern). */
static int find_word(const char *t, size_t n, const char *w, int need_end, size_t from, size_t *endpos)
{
    size_t L = slen(w);
    if (n < L) return 0;
    for (size_t i = from; i + L <= n; i++) {
        if (!mem_eq(t + i, w, L)) continue;
        if (i > 0 && isw((unsigned char)t[i - 1])) continue;
        if (need_end && i + L < n && isw((unsigned char)t[i + L])) continue;
        if (endpos) *endpos = i + L;
        return 1;
    }
    return 0;
}

/* parse_math's first regex: NUM, optional spaces, one operator char (plus, star, slash, letter x, minus), optional spaces, NUM -- leftmost search. NUM = -?digits(.digits)? */
static int parse_operand(const char *t, size_t n, size_t *pos, Num *o)
{
    size_t j = *pos; int neg = 0;
    if (j < n && t[j] == '-') { neg = 1; j++; }
    if (!(j < n && isd((unsigned char)t[j]))) return 0;
    size_t ds = j; while (j < n && isd((unsigned char)t[j])) j++;
    size_t de = j, fs = 0, fe = 0; int hf = 0;
    if (j + 1 < n && t[j] == '.' && isd((unsigned char)t[j + 1])) { j++; fs = j; while (j < n && isd((unsigned char)t[j])) j++; fe = j; hf = 1; }
    *o = mknum(t, neg, ds, de, fs, fe, hf); *pos = j; return 1;
}
static int try_symbol_match(const char *t, size_t n, size_t s, Num *a, Num *b, char *op)
{
    size_t j = s;
    if (!parse_operand(t, n, &j, a)) return 0;
    while (j < n && t[j] == ' ') j++;
    if (!(j < n && (t[j] == '+' || t[j] == '*' || t[j] == '/' || t[j] == 'x' || t[j] == '-'))) return 0;
    *op = t[j] == 'x' ? '*' : t[j]; j++;
    while (j < n && t[j] == ' ') j++;
    return parse_operand(t, n, &j, b);
}

/* returns 1 and fills a,b,op; 0 if parse_math would return None */
static int parse_math(const char *t, size_t n, const Num nums[2], int count, Num *a, Num *b, char *op)
{
    if (count < 2) return 0;
    for (size_t s = 0; s < n; s++) if (try_symbol_match(t, n, s, a, b, op)) return 1;
    size_t e;
    *a = nums[0]; *b = nums[1];
    if (find_word(t, n, "subtract", 1, 0, &e) && find_word(t, n, "from", 1, e, 0)) { Num x = *a; *a = *b; *b = x; *op = '-'; return 1; }
    if (find_word(t, n, "minus", 1, 0, 0) || find_word(t, n, "subtract", 0, 0, 0) || find_word(t, n, "less", 1, 0, 0)) { *op = '-'; return 1; }
    if (find_word(t, n, "times", 1, 0, 0) || find_word(t, n, "multipl", 0, 0, 0) || find_word(t, n, "product", 1, 0, 0)) { *op = '*'; return 1; }
    if (find_word(t, n, "divided", 1, 0, 0) || find_word(t, n, "divide", 1, 0, 0) || find_word(t, n, "over", 1, 0, 0)) { *op = '/'; return 1; }
    if (find_word(t, n, "plus", 1, 0, 0) || find_word(t, n, "add", 1, 0, 0) || find_word(t, n, "sum", 1, 0, 0) || find_word(t, n, "and", 1, 0, 0)) { *op = '+'; return 1; }
    return 0;
}

/* Exact division formatted like Python: compute_arith(a/b) -> int if exact else float(format(q,".10g")), then fmt_num/str(). */
static void w_div(Wr *w, int64_t a, int64_t b)
{
    int neg = (a < 0) != (b < 0);
    uint64_t A = a < 0 ? (uint64_t)0 - (uint64_t)a : (uint64_t)a, B = b < 0 ? (uint64_t)0 - (uint64_t)b : (uint64_t)b;
    if (A % B == 0) { uint64_t q = A / B; wi64(w, (neg && q) ? -(int64_t)q : (int64_t)q); return; }
    uint64_t ip = A / B, rem = A % B; char dg[12]; int nd = 0, E = 0;
    if (ip > 0) { char t[24]; int k = 0; uint64_t v = ip; while (v) { t[k++] = (char)('0' + (int)(v % 10u)); v /= 10u; } E = k; for (int q = k - 1; q >= 0 && nd < 11; q--) dg[nd++] = t[q]; }
    while (nd < 11) {
        rem *= 10u; unsigned d = (unsigned)(rem / B); rem %= B;
        if (nd == 0 && d == 0) { E--; continue; }
        dg[nd++] = (char)('0' + d);
    }
    int sticky = rem != 0;
    int up = dg[10] > '5' || (dg[10] == '5' && (sticky || ((dg[9] - '0') & 1)));   /* round-half-even on the exact remainder */
    if (up) { int k = 9; while (k >= 0) { if (dg[k] == '9') { dg[k] = '0'; k--; } else { dg[k]++; break; } } if (k < 0) { dg[0] = '1'; for (int z = 1; z < 10; z++) dg[z] = '0'; E++; } }
    int ns = 10; while (ns > 1 && dg[ns - 1] == '0') ns--;
    int x = E - 1;
    if (neg) wc(w, '-');
    if (x >= 0 && ns <= x + 1) { for (int i = 0; i <= x; i++) wc(w, i < ns ? dg[i] : '0'); return; }   /* rounded to an integer -> fmt_num prints int */
    if (x >= -4 && x < 16) {
        if (x >= 0) { for (int i = 0; i <= x; i++) wc(w, dg[i]); wc(w, '.'); for (int i = x + 1; i < ns; i++) wc(w, dg[i]); }
        else { ws(w, "0."); for (int i = 0; i < -x - 1; i++) wc(w, '0'); for (int i = 0; i < ns; i++) wc(w, dg[i]); }
    } else {                                                                                       /* repr() switches to scientific below 1e-4 */
        wc(w, dg[0]); if (ns > 1) { wc(w, '.'); for (int i = 1; i < ns; i++) wc(w, dg[i]); }
        wc(w, 'e'); int ex = x; if (ex < 0) { wc(w, '-'); ex = -ex; } else wc(w, '+');
        if (ex < 10) { wc(w, '0'); }
        wi64(w, ex);
    }
}

static const char *op_word(char op) { return op == '+' ? "plus" : op == '-' ? "minus" : op == '*' ? "times" : "divided by"; }

/* ------------------------------------------------------------------ prompt-injection pre-filter (_INJECTION) */
static int inj_at(const char *t, size_t n, size_t i, const char *p, int need_end)
{
    size_t L = slen(p);
    if (i + L > n || !mem_eq(t + i, p, L)) return 0;
    if (i > 0 && (isl((unsigned char)t[i - 1]) || isd((unsigned char)t[i - 1]))) return 0;        /* (?<![a-z0-9]) */
    if (need_end && i + L < n && (isl((unsigned char)t[i + L]) || isd((unsigned char)t[i + L]))) return 0;   /* (?![a-z0-9]) */
    return 1;
}
static int looks_like_injection(const char *t, size_t n)
{
    static const struct { const char *p; int end; } pat[] = {
        {"ignore previous",1},{"ignore the above",1},{"disregard the above",1},{"disregard previous",1},{"you are now",1},
        {"new instructions:",0},{"system:",0},{"act as",1},{"pretend you are",1},{"forget your instructions",1},{"override",1},{"jailbreak",1} };
    for (size_t i = 0; i < n; i++) for (size_t k = 0; k < sizeof pat / sizeof pat[0]; k++) if (inj_at(t, n, i, pat[k].p, pat[k].end)) return 1;
    return 0;
}

/* regex \b(?:remember|recall|...)\b : some maximal \w-run equals a memory word */
static int has_memory_word(const char *t, size_t n)
{
    static const char *const mw[] = {"remember","recall","forget","memory","memories","update","change","delete","note","save","store","erase","clear","know","told","tell"};
    size_t i = 0;
    while (i < n) {
        if (!isw((unsigned char)t[i])) { i++; continue; }
        size_t j = i; while (j < n && isw((unsigned char)t[j])) j++;
        for (size_t k = 0; k < sizeof mw / sizeof mw[0]; k++) if (slen(mw[k]) == j - i && mem_eq(t + i, mw[k], j - i)) return 1;
        i = j;
    }
    return 0;
}

/* ------------------------------------------------------------------ features (extract_features) */
static uint32_t cs(uint32_t c, const char *s) { return crc_upd(c, (const uint8_t *)s, slen(s)); }
static uint32_t ct(uint32_t c, const VxcScratch *s, unsigned i)
{
    if (s->tok_num[i]) return cs(c, "<n>");
    return crc_upd(c, (const uint8_t *)s->lc + s->tok_off[i], s->tok_len[i]);
}
static void fadd(const VxcModel *m, VxcScratch *s, uint32_t crc_state, int64_t w)
{
    uint32_t h = crc_state ^ 0xFFFFFFFFu;
    s->acc[h % m->feat] += ((h >> 31) & 1u) ? w : -w;
}

static unsigned tokenize(VxcScratch *s, size_t n)   /* feature_tokens: number | word with optional 'word | one of the symbols + - star slash % = ? ! */
{
    const char *t = s->lc; size_t i = 0; unsigned nt = 0;
    while (i < n) {
        int c = (unsigned char)t[i]; size_t j = i; int num = 0, ok = 1;
        if (isd(c)) { while (j < n && isd((unsigned char)t[j])) j++; if (j + 1 < n && t[j] == '.' && isd((unsigned char)t[j + 1])) { j++; while (j < n && isd((unsigned char)t[j])) j++; } num = 1; }
        else if (isl(c)) { while (j < n && isl((unsigned char)t[j])) j++; if (j + 1 < n && t[j] == '\'' && isl((unsigned char)t[j + 1])) { j++; while (j < n && isl((unsigned char)t[j])) j++; } }
        else if (c == '+' || c == '-' || c == '*' || c == '/' || c == '%' || c == '=' || c == '?' || c == '!') j = i + 1;
        else ok = 0;
        if (!ok) { i++; continue; }
        s->tok_off[nt] = (uint16_t)i; s->tok_len[nt] = (uint16_t)(j - i); s->tok_num[nt] = (uint8_t)num; nt++; i = j;
    }
    return nt;
}

static void build_features(const VxcModel *m, VxcScratch *s, size_t n)
{
    for (uint32_t i = 0; i < m->feat; i++) s->acc[i] = 0;
    unsigned nt = tokenize(s, n);
    if (nt == 0) return;
    for (unsigned i = 0; i < nt; i++) {
        fadd(m, s, ct(cs(0xFFFFFFFFu, "w:"), s, i), ONE_Q30);
        if (!s->tok_num[i] && s->tok_len[i] >= 5 && isl((unsigned char)s->lc[s->tok_off[i]]))
            fadd(m, s, crc_upd(cs(0xFFFFFFFFu, "s:"), (const uint8_t *)s->lc + s->tok_off[i], 4), W_STEM);
    }
    for (unsigned i = 0; i + 1 < nt; i++) fadd(m, s, ct(cs(ct(cs(0xFFFFFFFFu, "b:"), s, i), "_"), s, i + 1), W_BI);
    for (unsigned i = 0; i + 2 < nt; i++) fadd(m, s, ct(cs(ct(cs(ct(cs(0xFFFFFFFFu, "t:"), s, i), "_"), s, i + 1), "_"), s, i + 2), W_TRI);
    fadd(m, s, ct(cs(0xFFFFFFFFu, "f:"), s, 0), W_FIRST);
    if (nt > 1) fadd(m, s, ct(cs(ct(cs(0xFFFFFFFFu, "f2:"), s, 0), "_"), s, 1), ONE_Q30);
    { char lb[2]; lb[0] = (char)('0' + (nt < 8 ? nt : 8)); lb[1] = 0; fadd(m, s, cs(cs(0xFFFFFFFFu, "l:"), lb), W_LEN); }
    int q = 0, dgt = 0, qt = 0;
    for (size_t i = 0; i < n; i++) { char c = s->lc[i]; if (c == '?') q = 1; if (isd((unsigned char)c)) dgt = 1; if (c == '"' || c == '\'') qt = 1; }
    if (q)   fadd(m, s, cs(0xFFFFFFFFu, "q:?"), W_Q);
    if (dgt) fadd(m, s, cs(0xFFFFFFFFu, "q:digit"), W_Q);
    if (qt)  fadd(m, s, cs(0xFFFFFFFFu, "q:quote"), W_QUOTE);
}

static uint64_t isqrt128(unsigned __int128 n)
{
    unsigned __int128 res = 0, bit = (unsigned __int128)1 << 126;
    while (bit > n) bit >>= 2;
    while (bit) { if (n >= res + bit) { n -= res + bit; res = (res >> 1) + bit; } else res >>= 1; bit >>= 2; }
    return (uint64_t)res;
}

/* ------------------------------------------------------------------ network (forward) + softmax */
/* e^-d for d >= 0 in Q40, result Q40. Range reduction d = k*ln2 + r, Taylor(r) with 16 terms (error < 1e-13). */
static int64_t exp_neg_q40(int64_t d)
{
    int64_t k = d / LN2_Q40;
    if (k >= 62) return 0;
    int64_t r = d - k * LN2_Q40, term = 1LL << 40, sum = 1LL << 40;
    for (int n = 1; n <= 16; n++) {
        term = (int64_t)(((__int128)term * r) >> 40) / n;
        sum += (n & 1) ? -term : term;
    }
    if (sum < 0) sum = 0;
    return sum >> k;
}

static void forward(const VxcModel *m, VxcScratch *s)
{
    uint32_t F = m->feat, H = m->hidden, K = m->nint;
    unsigned __int128 ss = 0;
    for (uint32_t i = 0; i < F; i++) { int64_t x = s->acc[i]; uint64_t ax = x < 0 ? (uint64_t)0 - (uint64_t)x : (uint64_t)x; ss += (unsigned __int128)ax * ax; }
    uint64_t norm = isqrt128(ss);                                  /* Q30 L2 norm; 0 => leave the vector as is (Python: `if n > 0`) */
    uint64_t recip = norm ? ((uint64_t)1 << 60) / norm : 0;        /* 1/norm in Q30 */
    for (uint32_t j = 0; j < H; j++) s->hid[j] = (int64_t)rd32s(m->b1 + 4u * j) * (1LL << 20);   /* Q50 (multiply, not shift: bias may be negative) */
    for (uint32_t i = 0; i < F; i++) {
        if (s->acc[i] == 0) continue;
        int64_t xn = norm ? (int64_t)(((__int128)s->acc[i] * (__int128)recip) >> 30) : s->acc[i];
        if (xn == 0) continue;
        const uint8_t *row = m->w1 + (size_t)i * H * 4u;
        for (uint32_t j = 0; j < H; j++) s->hid[j] += ((int64_t)xn * (int64_t)rd32s(row + 4u * j)) >> 10;
    }
    for (uint32_t j = 0; j < H; j++) { int64_t h = s->hid[j]; h = h > 0 ? (h >> 20) : 0; if (h > HID_CLAMP_Q30) h = HID_CLAMP_Q30; s->hid[j] = h; }   /* ReLU, Q30 */
    __int128 la[VXC_MAX_INTENTS];
    for (uint32_t k = 0; k < K; k++) la[k] = (__int128)rd32s(m->bi + 4u * k) * ((__int128)1 << 30);                /* Q60 (multiply: negative-safe) */
    for (uint32_t j = 0; j < H; j++) {
        int64_t h = s->hid[j]; if (h == 0) continue;
        const uint8_t *row = m->wi + (size_t)j * K * 4u;
        for (uint32_t k = 0; k < K; k++) la[k] += (__int128)h * (__int128)rd32s(row + 4u * k);
    }
    for (uint32_t k = 0; k < K; k++) s->logit[k] = (int64_t)(la[k] >> 20);                                          /* Q40 */
}

/* The arithmetic specialist: infer()'s `family == "math"` branch (parse_math -> compute_arith -> fmt_num). t = lower-cased text. */
static int run_math(Wr *w, const char *t, size_t n)
{
    Num nums[2]; int cnt = 0; Num x, y; char op = '+';
    scan_numbers(t, n, nums, &cnt);
    if (!parse_math(t, n, nums, cnt, &x, &y, &op)) { ws(w, "I need two numbers and an operation to calculate (for example '12 plus 30')."); return VXC_H_BOUNDARY; }
    if ((x.flags | y.flags) != 0) { ws(w, "The native port supports whole-number operands up to 1000000000 in magnitude; decimal or larger operands are not supported yet."); return VXC_H_UNSUPPORTED; }
    if (op == '/' && y.v == 0) { ws(w, "(could not compute - division by zero)"); return VXC_H_MATH; }   /* Python replies with ONLY this text */
    wi64(w, x.v); wc(w, ' '); ws(w, op_word(op)); wc(w, ' '); wi64(w, y.v); ws(w, " = ");
    if (op == '+') wi64(w, x.v + y.v);
    else if (op == '-') wi64(w, x.v - y.v);
    else if (op == '*') wi64(w, x.v * y.v);
    else w_div(w, x.v, y.v);
    return VXC_H_MATH;
}

int vxc_arith(VxcScratch *s, const char *text, size_t len, char *out, size_t cap, int *handler)
{
    if (!s || !out || cap == 0 || !handler || (!text && len != 0)) return VXC_E_ARG;
    if (len > VXC_MAX_INPUT) return VXC_E_TOO_LONG;
    for (size_t i = 0; i < len; i++) { unsigned char c = (unsigned char)text[i]; if (c < 0x20 || c > 0x7E) return VXC_E_CHARSET; s->lc[i] = (char)lower_c(c); }
    s->lc[len] = 0;
    Wr w; w.p = out; w.cap = cap; w.n = 0; w.trunc = 0;
    *handler = run_math(&w, s->lc, len);
    wfin(&w);
    return w.trunc ? 1 : VXC_OK;     /* 1 = reply truncated to fit `out` */
}

/* ------------------------------------------------------------------ inference */
static void msg_boundary(Wr *w, const char *s) { ws(w, s); }

int vxc_infer(const VxcModel *m, VxcScratch *s, const char *text, size_t len, VxcResult *r, char *out, size_t cap)
{
    if (!m || !m->blob || !s || !r || !out || cap == 0 || (!text && len != 0)) return VXC_E_ARG;
    if (len > VXC_MAX_INPUT) return VXC_E_TOO_LONG;
    for (size_t i = 0; i < len; i++) { unsigned char c = (unsigned char)text[i]; if (c < 0x20 || c > 0x7E) return VXC_E_CHARSET; }
    r->intent = -1; r->neural_top = -1; r->confidence = 0; r->prob_q30 = 0; r->source = VXC_SRC_NONE; r->handler = VXC_H_BOUNDARY; r->truncated = 0; r->n_numbers = 0;
    Wr w; w.p = out; w.cap = cap; w.n = 0; w.trunc = 0;

    /* parse_input */
    size_t a = 0, e = len;
    while (a < e && text[a] == ' ') a++;
    while (e > a && text[e - 1] == ' ') e--;
    if (e - a >= 3 && lower_c((unsigned char)text[a]) == 'v' && text[a + 1] == '.' && text[a + 2] == ' ') { a += 3; while (a < e && text[a] == ' ') a++; while (e > a && text[e - 1] == ' ') e--; }
    if (e - a >= 5 && lower_c((unsigned char)text[a]) == 'v' && lower_c((unsigned char)text[a + 1]) == 'e' && lower_c((unsigned char)text[a + 2]) == 'x' && text[a + 3] == '.' && text[a + 4] == ' ') { a += 5; while (a < e && text[a] == ' ') a++; while (e > a && text[e - 1] == ' ') e--; }
    if (e - a >= 6 && mem_eq(text + a, "input=", 6)) a += 6;
    if (e - a >= 2 && ((text[a] == '"' && text[e - 1] == '"') || (text[a] == '\'' && text[e - 1] == '\''))) { a++; e--; }
    size_t n = e - a;
    if (n == 0) { msg_boundary(&w, "(no input provided)"); goto done; }
    for (size_t i = 0; i < n; i++) s->lc[i] = (char)lower_c((unsigned char)text[a + i]);
    s->lc[n] = 0;

    if (looks_like_injection(s->lc, n)) { msg_boundary(&w, "input rejected: potential prompt injection detected. quoted instructions cannot override system rules."); goto done; }

    build_features(m, s, n);
    forward(m, s);

    uint32_t K = m->nint; int top = 0;
    for (uint32_t k = 1; k < K; k++) if (s->logit[k] > s->logit[top]) top = (int)k;            /* first max, like np.argmax */
    uint64_t sum = 0;
    for (uint32_t k = 0; k < K; k++) sum += (uint64_t)exp_neg_q40(s->logit[top] - s->logit[k]);
    uint64_t prob = ((uint64_t)1 << 60) / (sum >> 10);                                          /* Q30; sum >= 2^40 */
    if (prob > ONE_Q30) prob = ONE_Q30;
    r->neural_top = top; r->prob_q30 = (int32_t)prob;

    Num nums[2]; int cnt = 0; scan_numbers(s->lc, n, nums, &cnt); r->n_numbers = cnt;
    int ok = prob >= m->reject_q;
    if (m->is_math[top]) ok = ok && cnt >= 2;
    else if (m->is_mem[top]) ok = ok && has_memory_word(s->lc, n);

    if (!ok) {
        r->intent = 49; r->confidence = 100; r->source = VXC_SRC_REJECTED; r->handler = VXC_H_BOUNDARY;
        msg_boundary(&w, "I am not confident what you are asking (the native Crystal port has no rule/evidence fallback). Please rephrase, for example '12 plus 30'.");
        goto done;
    }
    r->intent = top; r->source = VXC_SRC_NEURAL; r->confidence = (int32_t)((prob * 1000u) >> 30);

    if (m->is_math[top]) { r->handler = run_math(&w, s->lc, n); goto done; }
    r->handler = VXC_H_NOT_IMPL;
    ws(&w, "Recognised intent: "); ws(&w, vxc_intent_label(m, top)); ws(&w, " ("); ws(&w, vxc_intent_family(m, top)); ws(&w, "), confidence ");
    wi64(&w, r->confidence); ws(&w, "/1000. The native port only implements arithmetic; this handler is not available yet.");
done:
    wfin(&w); r->truncated = w.trunc;
    return VXC_OK;
}
