#!/usr/bin/env python3
"""Vex OS - scripts/qemu_drive.py

Headless QEMU driver for runtime verification (Linux/WSL).  Boots the SAME
image/firmware/machine as scripts/run-qemu.sh (q35, TCG, OVMF, 4 vCPU, 512M,
-no-reboot -no-shutdown) but with the serial port captured to a file and the
QEMU human monitor on a unix socket, so a test can inject real PS/2 key and
mouse events (sendkey / mouse_move / mouse_button) and capture the real
framebuffer (screendump).

This module is a library + tiny CLI; the actual test scripts import it.
It does not fake anything: every event goes through QEMU's emulated i8042.
"""
import os, socket, subprocess, time, re, sys, shutil

OVMF_DIR  = os.environ.get("OVMF_DIR", "/usr/share/OVMF")
OVMF_CODE = os.environ.get("OVMF_CODE", f"{OVMF_DIR}/OVMF_CODE_4M.fd")
OVMF_VARS = os.environ.get("OVMF_VARS", f"{OVMF_DIR}/OVMF_VARS_4M.fd")

class Vm:
    def __init__(self, img, workdir, smp=4, extra=None, tag="vm", allow_reboot=False, nic=True):
        self.img = img
        self.dir = workdir
        os.makedirs(workdir, exist_ok=True)
        self.serial_path = os.path.join(workdir, f"{tag}.serial.log")
        self.mon_path    = os.path.join(workdir, f"{tag}.mon")
        self.vars_path   = os.path.join(workdir, f"{tag}.vars.fd")
        for p in (self.serial_path, self.mon_path):
            if os.path.exists(p): os.remove(p)
        shutil.copy(OVMF_VARS, self.vars_path)
        cmd = ["qemu-system-x86_64", "-machine", "q35,accel=tcg", "-cpu", "qemu64",
               "-smp", str(smp), "-m", "512M",
               "-drive", f"if=pflash,format=raw,readonly=on,file={OVMF_CODE}",
               "-drive", f"if=pflash,format=raw,file={self.vars_path}",
               "-drive", f"format=raw,file={img}",
               "-serial", f"file:{self.serial_path}",
               "-monitor", f"unix:{self.mon_path},server,nowait",
               "-qmp", f"unix:{workdir}/{tag}.qmp,server,nowait",
               "-display", "none", "-no-shutdown"]
        if not allow_reboot: cmd.append("-no-reboot")     # the project launcher uses -no-reboot
        if extra: cmd += extra
        self.qmp_path = f"{workdir}/{tag}.qmp"
        self.cmd = cmd
        self.proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        self.sock = None
        t0 = time.time()
        while time.time() - t0 < 10:
            if os.path.exists(self.mon_path):
                try:
                    s = socket.socket(socket.AF_UNIX); s.connect(self.mon_path)
                    self.sock = s; break
                except OSError: pass
            time.sleep(0.05)
        if not self.sock: raise RuntimeError("monitor socket never appeared")
        self._read_until_prompt()

    # ---- monitor ----
    def _read_until_prompt(self, timeout=10):
        self.sock.settimeout(timeout); buf = b""
        t0 = time.time()
        while time.time() - t0 < timeout:
            try: d = self.sock.recv(4096)
            except socket.timeout: break
            if not d: break
            buf += d
            if buf.rstrip().endswith(b"(qemu)"): break
        return buf.decode(errors="replace")
    def hmp(self, line):
        self.sock.sendall(line.encode() + b"\n")
        return self._read_until_prompt()
    def sendkey(self, k, hold_ms=None):
        return self.hmp(f"sendkey {k}" + (f" {hold_ms}" if hold_ms else ""))
    def mouse_move(self, dx, dy): return self.hmp(f"mouse_move {dx} {dy}")
    def mouse_button(self, mask): return self.hmp(f"mouse_button {mask}")
    def click(self, mask=1, hold=0.08):
        self.mouse_button(mask); time.sleep(hold); self.mouse_button(0)
    def screendump(self, path):
        self.hmp(f"screendump {path}"); 
        t0=time.time()
        while time.time()-t0<5 and not (os.path.exists(path) and os.path.getsize(path)>0): time.sleep(0.05)
        return path
    def status(self): return self.hmp("info status")

    # ---- QMP (needed to inject key-DOWN events without a matching UP, i.e. typematic repeat) ----
    def _qmp(self, obj):
        import json
        if not getattr(self, "_q", None):
            q = socket.socket(socket.AF_UNIX)
            for _ in range(100):
                try: q.connect(self.qmp_path); break
                except OSError: time.sleep(0.05)
            q.settimeout(5); q.recv(4096)
            q.sendall(b'{"execute":"qmp_capabilities"}\n'); q.recv(4096); self._q = q
        self._q.sendall(json.dumps(obj).encode() + b"\n"); return self._q.recv(4096)
    def key_event(self, qcode, down):
        return self._qmp({"execute": "input-send-event", "arguments": {"events": [
            {"type": "key", "data": {"down": bool(down), "key": {"type": "qcode", "data": qcode}}}]}})

    # ---- serial ----
    def serial(self):
        try: return open(self.serial_path, "rb").read().decode(errors="replace")
        except FileNotFoundError: return ""
    def wait_serial(self, pattern, timeout=60):
        rx = re.compile(pattern); t0 = time.time()
        while time.time() - t0 < timeout:
            if rx.search(self.serial()): return True
            if self.proc.poll() is not None: return bool(rx.search(self.serial()))
            time.sleep(0.1)
        return False
    def alive(self): return self.proc.poll() is None
    def stop(self):
        try:
            if self.alive(): self.proc.kill()
            self.proc.wait(timeout=5)
        except Exception: pass

def ppm_to_png(ppm, png):
    try:
        from PIL import Image
        Image.open(ppm).save(png); return png
    except Exception as e:
        return None


def load_ppm(path):
    from PIL import Image
    return Image.open(path).convert("RGB")

def find_cursor(img):
    """Locate the pointer sprite by its exact fill colour; returns hot-spot (x, y) or None.
    Fill (F4,F7,FF) first appears at sprite row 2, col 1 in raster order."""
    w, h = img.size; px = img.load()
    for y in range(h):
        for x in range(w):
            if px[x, y] == (0xF4, 0xF7, 0xFF):
                return (x - 1, y - 2)
    return None
