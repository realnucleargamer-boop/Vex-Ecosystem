"""Shared helpers for the real-QEMU end-to-end scripts that drive the desktop with PS/2 keyboard + mouse and read the framebuffer."""
import os, re, sys, time
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
from qemu_drive import Vm, ppm_to_png, load_ppm
from PIL import Image, ImageChops
import make_wallpapers as MW
SRC = os.path.join(os.path.dirname(__file__), "..", "assets", "wallpapers", "src")
STEM = {1: "midnight-horizon", 2: "deep-arcs", 3: "blue-flow", 4: "morning-haze", 5: "glass-ribbons", 6: "above-the-clouds"}
NAVY = (5, 18, 34)
class Ctx:
    out = "build/e2e"; res = []
def check(ok, w, d=""): Ctx.res.append(bool(ok)); print(("PASS  " if ok else "FAIL  ") + w + (f"  [{d}]" if d and not ok else ""), flush=True)
def cnt(vm, p): return len(re.findall(p, vm.serial()))
def last_line(vm, tag):
    ls = [l for l in vm.serial().splitlines() if tag in l]; return ls[-1] if ls else ""
def rects(vm, tag):
    l = last_line(vm, tag); return {m.group(1): tuple(map(int, m.groups()[1:])) for m in re.finditer(r"(\w+)=\((\d+),(\d+),(\d+),(\d+)\)", l)}
def all_rects(vm, tag, name): return [tuple(map(int, m.groups())) for m in re.finditer(r"\b" + name + r"=\((\d+),(\d+),(\d+),(\d+)\)", last_line(vm, tag))]
def mr(vm, dx, dy):
    while dx or dy:
        sx = max(-100, min(100, dx)); sy = max(-100, min(100, dy)); vm.mouse_move(sx, sy); dx -= sx; dy -= sy; time.sleep(0.03)
    time.sleep(0.3)
def clk(vm, x, y): mr(vm, -3000, -2000); mr(vm, x, y); vm.mouse_button(1); time.sleep(0.25); vm.mouse_button(0); time.sleep(0.8)
def click(vm, r): clk(vm, r[0] + r[2] // 2, r[1] + r[3] // 2)
K = {" ": "spc", ".": "dot", "-": "minus", "\n": "ret", "~": "shift-grave_accent", "/": "slash"}
def typ(vm, s):
    for c in s: vm.sendkey(K.get(c) or ("shift-" + c.lower() if c.isupper() else c)); time.sleep(0.11)
    time.sleep(0.5)
def shot(vm, n):
    os.makedirs(Ctx.out, exist_ok=True); p = f"{Ctx.out}/{n}.ppm"; vm.screendump(p); ppm_to_png(p, f"{Ctx.out}/{n}.png"); return load_ppm(p).convert("RGB")
def expected(W, H, i):
    im = MW.remove_corner_mark(Image.open(os.path.join(SRC, STEM[i] + ".png")).convert("RGB"))
    if W * im.height >= H * im.width: sw, sh = W, max(H, -(-im.height * W // im.width))
    else: sw, sh = max(W, -(-im.width * H // im.height)), H
    r = im.resize((sw, sh), Image.BICUBIC); cx, cy = (sw - W) // 2, (sh - H) // 2; return r.crop((cx, cy, cx + W, cy + H))
def mae(a, b, box):
    d = ImageChops.difference(a.crop(box), b.crop(box)).convert("L"); h = d.histogram(); return sum(k * v for k, v in enumerate(h)) / max(1, sum(h))
def strip_err(img, i): W, H = img.size; e = expected(W, H, i); return max(mae(img, e, (0, 30, 128, H - 60)), mae(img, e, (W - 132, 70, W, H - 60)))
def wait_lock(vm, n_before=0, timeout=200):
    t = time.time()
    while time.time() - t < timeout and cnt(vm, r"\[ui\] lock screen shown") <= n_before: time.sleep(1)
    time.sleep(1.5); return cnt(vm, r"\[ui\] lock screen shown") > n_before
def signin(vm, pw="vexpass1\n"): typ(vm, pw); time.sleep(1.8); return rects(vm, "desktop shown")
def open_wallpaper_page(vm, D):
    click(vm, D["sett"]); time.sleep(0.5); S = rects(vm, "settings view shown"); rows = all_rects(vm, "settings view shown", "srow"); click(vm, rows[5]); time.sleep(0.6)
    return S, all_rects(vm, "[ui] layout", "wptile"), all_rects(vm, "[ui] layout", "wpapply")[0], all_rects(vm, "[ui] layout", "wpreset")[0]
def term_cmd(vm, cmd, wait=1.0):
    n = cnt(vm, r"(?m)^\[term\]"); typ(vm, cmd + "\n"); time.sleep(wait)
    return [l[len("[term] "):] for l in vm.serial().splitlines() if l.startswith("[term] ")][n:]
