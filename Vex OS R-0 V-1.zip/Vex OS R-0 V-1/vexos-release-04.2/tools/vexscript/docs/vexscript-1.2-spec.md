# VEX-Script 1.2 Language Specification

**Status**: Implemented (reference interpreter)  
**Baseline**: VEX-Script 1.1 (superset of frozen 1.0)

## New in 1.2

### Structs
```vex
struct Point {
    x: i64
    y: i64
}

let mut p = Point { x: 10, y: 20 };
println(p.x);
p.x = 50;
```

- Struct definitions at top level
- Construction with `Name { field: expr, ... }`
- Field access: `obj.field`
- Field mutation requires a mutable binding holding the struct
- Nested structs supported
- Missing/unknown fields are errors

### Modules (upgraded)
```vex
use math_mod;   // loads math_mod.vex from the same directory
```

- Multi-file resolution relative to the importing file
- Duplicate function/struct definitions are errors
- Import cycles are detected and rejected
- Missing modules produce clear diagnostics
- Loaded module symbols are registered into the global function/struct tables

### Standard library additions
- `abs(x)`, `min(a,b)`, `max(a,b)`
- `str_contains(s, sub)`

## Unchanged from 1.1
Control flow, Option/Result helpers, strings (`len_string`, `concat`), assert, 1.0 surface compatibility.

## Not in 1.2
Generics, ownership, methods, visibility modifiers, package manager, compiler backend.
