/*
 * Vex OS - kernel/include/serial.h
 *
 * Minimal 16550 UART driver on COM1 (0x3F8), used for early
 * boot/debug/panic output before the framebuffer console exists.
 * Per architecture: "a serial/debug output path is strongly
 * preferred in addition to framebuffer output" during early bring-up.
 */

#ifndef VEXOS_SERIAL_H
#define VEXOS_SERIAL_H

#include <stdint.h>

void serial_init(void);
void serial_putc(char c);
void serial_puts(const char *s);
void serial_put_hex64(uint64_t v);
void serial_put_dec64(uint64_t v);

#endif /* VEXOS_SERIAL_H */
