/*
 * Vex OS - kernel/include/boot_progress.h
 *
 * Graphics 2: the boot-progress state interface.
 *
 * This is the "Boot subsystem -> Boot progress state -> Graphics 2
 * renderer" pipeline described in the Graphics 2 brief. It is
 * deliberately independent of the gfx layer - this header does not include
 * gfx/fb.h or any other graphics type, and boot_progress.c does not
 * call a single gfx_* function. The boot subsystem (kernel_entry.c)
 * reports real stage transitions here; a renderer (Graphics 2's
 * gfx_progress.c, today) registers itself as a callback and is invoked
 * whenever the state changes. Nothing in this file assumes a renderer
 * exists at all - boot_progress_set() is always safe to call, with or
 * without a framebuffer, with or without graphics having initialised.
 *
 * Why this indirection exists (not just decoration): it is the exact
 * seam the brief asks Security 2 and VEX AI to eventually use.
 * Security 2 will report "scanning" / "PASS" / "FAIL" through this same
 * boot_progress_set()-shaped call, not through a new framebuffer
 * dependency. A future VEX AI status surface reads state through
 * boot_progress_get(), never through a raw pointer into graphics
 * memory. See docs/GRAPHICS-2.md "Integration boundary" for the full
 * picture.
 */

#ifndef VEXOS_BOOT_PROGRESS_H
#define VEXOS_BOOT_PROGRESS_H

#include <stdint.h>

/* Real boot stages, in the order kernel_entry.c actually executes them.
 * These are discovered stages from BOOT-01/02A/02B/02C/03's existing
 * sequence, not invented examples - see docs/GRAPHICS-2.md "Stage
 * mapping" for the justification of each percentage. */
typedef enum {
    BOOT_STAGE_START           = 0,
    BOOT_STAGE_FRAMEBUFFER     = 1,
    BOOT_STAGE_CPU_TABLES      = 2,  /* GDT, IDT                        */
    BOOT_STAGE_MEMORY          = 3,  /* PMM, AP stack allocation        */
    BOOT_STAGE_ACPI            = 4,  /* ACPI/MADT, LAPIC                */
    BOOT_STAGE_PAGING          = 5,  /* kernel page tables activated    */
    BOOT_STAGE_SMP             = 6,  /* secondary CPUs started          */
    BOOT_STAGE_TIMER           = 7,  /* LAPIC timer, interrupts enabled */
    BOOT_STAGE_SELFTEST        = 8,  /* BOOT-03/KERNEL-01/SECURITY-01   */
    BOOT_STAGE_SERVICES        = 9,  /* INPUT-02, USER-02               */
    BOOT_STAGE_DONE            = 10,
    BOOT_STAGE_COUNT
} BootStage;

#define BOOT_PROGRESS_MSG_MAX 48

typedef struct {
    BootStage stage;
    int       percent;        /* 0..100, always clamped on the way in  */
    char      message[BOOT_PROGRESS_MSG_MAX];
    uint32_t  update_count;   /* how many times boot_progress_set() ran */
} BootProgress;

/* Renderer callback shape. A renderer must not block and must not
 * assume it is the only thing ever registered across the process
 * lifetime (boot_progress_attach_renderer() simply replaces whatever
 * was registered before, which is sufficient for Graphics 2's single
 * active renderer model today). */
typedef void (*BootProgressRenderFn)(const BootProgress *state);

/* Resets state to stage=START, percent=0, message="". Safe to call
 * exactly once, at the very top of kernel_entry(), before anything else
 * - it performs no I/O and touches no hardware. */
void boot_progress_init(void);

/* Registers (or clears, with NULL) the renderer invoked by
 * boot_progress_set(). Graphics 2 calls this once, right after
 * gfx_fb_init() succeeds. If no renderer is ever attached - e.g. no
 * framebuffer was present - boot_progress_set() still records state
 * correctly, it just has nothing to render it with. */
void boot_progress_attach_renderer(BootProgressRenderFn render_fn);

/* Records a real stage transition and, if a renderer is attached,
 * invokes it synchronously with the new state. `percent` is clamped to
 * [0,100] - an out-of-range value is a caller bug, not a reason to
 * corrupt displayed state or crash. `message` is copied (truncated to
 * BOOT_PROGRESS_MSG_MAX-1 bytes); the caller's buffer need not outlive
 * the call. */
void boot_progress_set(BootStage stage, int percent, const char *message);

/* Read-only snapshot of current state, for any future consumer
 * (Security 2, a VEX AI status service) that wants to query rather
 * than render. Never returns NULL. */
const BootProgress *boot_progress_get(void);

#endif /* VEXOS_BOOT_PROGRESS_H */
