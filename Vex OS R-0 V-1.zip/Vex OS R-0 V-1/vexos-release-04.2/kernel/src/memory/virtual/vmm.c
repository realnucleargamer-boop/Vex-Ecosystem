/*
 * Vex OS - kernel/src/memory/virtual/vmm.c
 *
 * BOOT-03 kernel paging. See kernel/include/vmm.h for the address space
 * layout and the design rationale.
 *
 * IMPORTANT: every page table is accessed here through its IDENTITY
 * address. That is valid both before activation (firmware left an
 * identity-ish mapping in place, which is what BOOT-01/02C already rely
 * on) and after activation (the tables we build include an identity
 * map). If the identity map is ever dropped, every (uint64_t *) cast in
 * this file must move to the direct physical map window instead - that
 * is the single mechanical change that makes this file survive the
 * kernel moving to the higher half.
 */

#include "vmm.h"
#include "pmm.h"
#include "efi_memmap.h"
#include "serial.h"
#include "panic.h"
#include "tlb.h"
#include "boot03_inject.h"

#define ENTRIES 512

#define ADDR_MASK 0x000FFFFFFFFFF000ULL

#define PML4_INDEX(v) (((v) >> 39) & 0x1FF)
#define PDPT_INDEX(v) (((v) >> 30) & 0x1FF)
#define PD_INDEX(v)   (((v) >> 21) & 0x1FF)
#define PT_INDEX(v)   (((v) >> 12) & 0x1FF)

#define IA32_EFER      0xC0000080U
#define EFER_NXE_BIT   (1ULL << 11)

static VmmInfo g_vmm;
static uint64_t *g_pml4;          /* identity pointer to the PML4 */
static uint64_t g_kmap_next;      /* bump cursor in the kmap window */

/* Serialises page-table modification. Same interrupt-flag discipline as
 * the PMM lock, and the same invariant: interrupt handlers must not
 * call the mapping primitives. The BOOT-03 page-fault self-test handler
 * is the one deliberate exception, and it runs only while the BSP is
 * single-threaded inside the test and holds no lock. */
static volatile int g_lock;

static inline uint64_t irq_save_disable(void)
{
    uint64_t flags;
    __asm__ volatile ("pushfq; pop %0; cli" : "=r"(flags) : : "memory");
    return flags;
}

static inline void irq_restore(uint64_t flags)
{
    if (flags & (1ULL << 9)) {
        __asm__ volatile ("sti" : : : "memory");
    }
}

static uint64_t vmm_lock(void)
{
    uint64_t flags = irq_save_disable();
    while (__atomic_test_and_set(&g_lock, __ATOMIC_ACQUIRE)) {
        __asm__ volatile ("pause");
    }
    return flags;
}

static void vmm_unlock(uint64_t flags)
{
    __atomic_clear(&g_lock, __ATOMIC_RELEASE);
    irq_restore(flags);
}

static inline uint64_t align_down(uint64_t v, uint64_t a) { return v & ~(a - 1); }
static inline uint64_t align_up(uint64_t v, uint64_t a)   { return (v + a - 1) & ~(a - 1); }

static void zero_page(uint64_t phys)
{
    uint64_t *p = (uint64_t *)(uintptr_t)phys;
    for (int i = 0; i < ENTRIES; i++) p[i] = 0;
}

static inline void invlpg(uint64_t virt)
{
    __asm__ volatile ("invlpg (%0)" : : "r"((void *)(uintptr_t)virt) : "memory");
}

const char *vmm_result_name(VmmResult r)
{
    switch (r) {
    case VMM_OK:                  return "OK";
    case VMM_ERR_NO_MEMORY:       return "out of memory for page tables";
    case VMM_ERR_NOT_ALIGNED:     return "not page aligned";
    case VMM_ERR_ALREADY_MAPPED:  return "already mapped";
    case VMM_ERR_NOT_MAPPED:      return "not mapped";
    case VMM_ERR_LARGE_PAGE:      return "covered by a 2 MiB mapping";
    case VMM_ERR_NOT_INITIALIZED: return "VMM not initialized";
    case VMM_ERR_BAD_REQUEST:     return "bad request";
    case VMM_ERR_NO_SUCH_RANGE:   return "not a reserved kmap range base";
    case VMM_ERR_ALREADY_FREE:    return "kmap range already free";
    default:                      return "unknown";
    }
}

const VmmInfo *vmm_info(void) { return &g_vmm; }

uint64_t vmm_read_cr3(void)
{
    uint64_t v;
    __asm__ volatile ("mov %%cr3, %0" : "=r"(v));
    return v;
}

/* ------------------------------------------------------------------ *
 * Table allocation
 * ------------------------------------------------------------------ */

/* Allocates and zeroes one page-table frame, and reserves it in the PMM
 * so it can never be handed out as ordinary memory. Returns 0 on
 * failure - never panics, so a mapping failure is reportable. */
static uint64_t alloc_table(void)
{
    uint64_t p = pmm_alloc_page();
    if (p == 0) return 0;
    zero_page(p);
    pmm_reserve_range(p, VMM_PAGE_SIZE, PMM_RSV_PAGE_TABLE);
    g_vmm.table_pages++;
    return p;
}

/* Walks to the table one level below `table[index]`, creating it if
 * `create` is set. Returns an identity pointer, or 0. */
static uint64_t *next_level(uint64_t *table, uint64_t index, int create)
{
    uint64_t e = table[index];

    if (e & VMM_PRESENT) {
        if (e & VMM_LARGE) return 0;   /* caller must handle this case */
        return (uint64_t *)(uintptr_t)(e & ADDR_MASK);
    }
    if (!create) return 0;

    uint64_t phys = alloc_table();
    if (phys == 0) return 0;

    /* Intermediate entries are permissive (present + write, no NX);
     * the effective permission of a mapping is the AND of the
     * write/user bits and the OR of NX along the walk, so restrictions
     * are expressed at the leaf. Keeping intermediates uniform avoids a
     * class of bug where a leaf is correct but an ancestor silently
     * removes write access. */
    table[index] = phys | VMM_PRESENT | VMM_WRITE;
    return (uint64_t *)(uintptr_t)phys;
}

/* ------------------------------------------------------------------ *
 * 2 MiB range mapping (used to build the identity and direct maps)
 * ------------------------------------------------------------------ */

static VmmResult map_large(uint64_t virt, uint64_t phys, uint64_t flags)
{
    if ((virt | phys) & (VMM_LARGE_PAGE_SIZE - 1)) return VMM_ERR_NOT_ALIGNED;

    uint64_t *pdpt = next_level(g_pml4, PML4_INDEX(virt), 1);
    if (pdpt == 0) return VMM_ERR_NO_MEMORY;

    uint64_t *pd = next_level(pdpt, PDPT_INDEX(virt), 1);
    if (pd == 0) return VMM_ERR_NO_MEMORY;

    uint64_t idx = PD_INDEX(virt);
    if (pd[idx] & VMM_PRESENT) return VMM_ERR_ALREADY_MAPPED;

    pd[idx] = phys | flags | VMM_LARGE;
    return VMM_OK;
}

/* ------------------------------------------------------------------ *
 * Memory map interrogation
 * ------------------------------------------------------------------ */

typedef struct {
    uint8_t *map;
    uint64_t desc_size;
    uint64_t count;
} MemMapView;

static MemMapView memmap_view(BootInfo *info)
{
    MemMapView v;
    v.map = (uint8_t *)(uintptr_t)info->memory_map;
    v.desc_size = info->memory_map_desc_size;
    v.count = info->memory_map_size / info->memory_map_desc_size;
    return v;
}

/* True only if EVERY byte of [base, base+len) is described as RAM by
 * the memory map. Deliberately conservative: a range that is partly
 * unmapped address space, partly MMIO, or not described at all is not
 * RAM, and will be mapped uncacheable. */
static int range_is_all_ram(const MemMapView *v, uint64_t base, uint64_t len)
{
    uint64_t cursor = base;
    uint64_t end = base + len;

    /* The memory map is not guaranteed sorted, so this walks it once per
     * gap rather than assuming order. O(descriptors) per 2 MiB page is
     * acceptable at 120 descriptors and a few hundred pages; it is a
     * boot-time cost only. */
    while (cursor < end) {
        int advanced = 0;
        for (uint64_t i = 0; i < v->count; i++) {
            EfiMemoryDescriptor *d =
                (EfiMemoryDescriptor *)(v->map + i * v->desc_size);
            uint64_t ds = d->PhysicalStart;
            uint64_t de = ds + d->NumberOfPages * VMM_PAGE_SIZE;

            if (cursor >= ds && cursor < de) {
                if (!efi_mem_type_is_ram(d->Type)) return 0;
                cursor = de;
                advanced = 1;
                break;
            }
        }
        if (!advanced) return 0;   /* address not described at all */
    }
    return 1;
}

/* ------------------------------------------------------------------ *
 * Build
 * ------------------------------------------------------------------ */

static int cpuid_has_nx(void)
{
    uint32_t eax, ebx, ecx, edx;
    /* Check the extended-function leaf is available first; reading
     * 0x80000001 on a CPU that does not implement it returns whatever
     * the highest supported leaf returns, which would be a wrong
     * answer rather than a missing one. */
    __asm__ volatile ("cpuid" : "=a"(eax), "=b"(ebx), "=c"(ecx), "=d"(edx)
                      : "a"(0x80000000U));
    if (eax < 0x80000001U) return 0;

    __asm__ volatile ("cpuid" : "=a"(eax), "=b"(ebx), "=c"(ecx), "=d"(edx)
                      : "a"(0x80000001U));
    return (edx & (1u << 20)) != 0;   /* NX / XD bit */
}

int vmm_build_kernel_tables(BootInfo *info, VmmInfo *out)
{
    g_vmm.pml4_phys = 0;
    g_vmm.identity_top = 0;
    g_vmm.table_pages = 0;
    g_vmm.large_pages_wb = 0;
    g_vmm.large_pages_uc = 0;
    g_vmm.active = 0;
    g_vmm.nx_supported = cpuid_has_nx();
    g_vmm.nx_enabled = 0;
    g_kmap_next = VEX_KMAP_BASE;

    /* The PML4 must be below 4 GiB: the BOOT-02C AP trampoline loads
     * CR3 with a 32-bit `mov cr3, eax` while still in protected mode.
     * BOOT-02C detected a too-high CR3 and refused to start APs; now
     * that the kernel owns the tables it can simply place them
     * correctly, so the constraint is enforced at allocation. */
    uint64_t pml4 = pmm_alloc_page_below(0x100000000ULL);
    if (pml4 == 0) {
        serial_puts("[kernel] VMM: FAILED - no free frame below 4 GiB for the PML4\n");
        return 0;
    }
    zero_page(pml4);
    pmm_reserve_range(pml4, VMM_PAGE_SIZE, PMM_RSV_PAGE_TABLE);
    g_vmm.table_pages++;
    g_vmm.pml4_phys = pml4;
    g_pml4 = (uint64_t *)(uintptr_t)pml4;

    MemMapView v = memmap_view(info);

    /* Identity-map (and direct-map) every 2 MiB page up to the top of
     * the address range the memory map describes, rounded up. This
     * covers RAM, the framebuffer, ACPI tables and the LAPIC MMIO
     * window wherever firmware put them, so no per-device special case
     * is needed. */
    uint64_t top = pmm_highest_address();

    /* Guarantee coverage of the legacy LAPIC/IOAPIC MMIO region even if
     * the memory map does not mention it. 0xFEE00000 is the
     * architectural default LAPIC base; a memory map that omits it
     * would otherwise leave the LAPIC unmapped and turn the first APIC
     * access after activation into a page fault. */
    if (top < 0xFFE00000ULL) top = 0xFFE00000ULL;

    /* Also guarantee coverage of the framebuffer, which on some
     * firmware is not listed in the memory map at all. */
    if (info->framebuffer_addr != 0 && info->framebuffer_size != 0) {
        uint64_t fb_end = info->framebuffer_addr + info->framebuffer_size;
        if (fb_end > top) top = fb_end;
    }

    top = align_up(top, VMM_LARGE_PAGE_SIZE);
    g_vmm.identity_top = top;

    for (uint64_t p = 0; p < top; p += VMM_LARGE_PAGE_SIZE) {
        int is_ram = range_is_all_ram(&v, p, VMM_LARGE_PAGE_SIZE);

        /* NX on data-only mappings would be preferable, but the kernel
         * image itself lives inside the identity map and must remain
         * executable. Per-section protection of the kernel image needs
         * linker-provided section symbols and is recorded as future
         * work; setting NX across the whole identity map would fault
         * the kernel on its own next instruction. */
        uint64_t flags = is_ram ? VMM_KERNEL_RW
                                : (VMM_PRESENT | VMM_WRITE | VMM_PCD | VMM_PWT);

        /* SECURITY-01: the DIRECT MAP, unlike the identity map, contains
         * no code the kernel ever executes. It exists to reach arbitrary
         * physical memory as data. So it can be NX even though the
         * identity map cannot, and making it NX is real W^X progress
         * rather than a comment about future work: it removes a second,
         * writable, executable alias of every physical page - which is
         * exactly the alias an attacker who can write anywhere would
         * rather jump to.
         *
         * Gated on nx_supported, NOT on nx_enabled: EFER.NXE is still 0
         * at build time and is set by vmm_activate() a few lines before
         * it loads CR3, so by the time these entries are ever consulted
         * NXE is on. Testing nx_enabled here would silently produce no NX
         * mappings at all - which would look like a passing build and be
         * exactly the kind of security feature that is present in the
         * source and absent from the machine. The tests assert on the
         * live tables for that reason.
         *
         * Setting bit 63 without NXE would be a reserved-bit violation,
         * hence the support check rather than setting it unconditionally. */
        uint64_t dm_flags = flags;
#if !VEX_INJECTED(16)
        if (g_vmm.nx_supported) dm_flags |= VMM_NX;
#endif

        VmmResult r = map_large(p, p, flags);
        if (r != VMM_OK) {
            serial_puts("[kernel] VMM: FAILED identity mapping at ");
            serial_put_hex64(p);
            serial_puts(" - ");
            serial_puts(vmm_result_name(r));
            serial_puts("\n");
            return 0;
        }

        /* Same physical page, second virtual window. */
        r = map_large(VEX_PHYS_MAP_BASE + p, p, dm_flags);
        if (r != VMM_OK) {
            serial_puts("[kernel] VMM: FAILED direct-map mapping at ");
            serial_put_hex64(VEX_PHYS_MAP_BASE + p);
            serial_puts(" - ");
            serial_puts(vmm_result_name(r));
            serial_puts("\n");
            return 0;
        }

        if (is_ram) g_vmm.large_pages_wb++;
        else        g_vmm.large_pages_uc++;
    }

    serial_puts("[kernel] VMM: kernel tables built - PML4 @ ");
    serial_put_hex64(g_vmm.pml4_phys);
    serial_puts(", identity+direct map 0..");
    serial_put_hex64(top);
    serial_puts("\n");
    serial_puts("[kernel] VMM: ");
    serial_put_dec64(g_vmm.large_pages_wb);
    serial_puts(" x 2 MiB write-back, ");
    serial_put_dec64(g_vmm.large_pages_uc);
    serial_puts(" x 2 MiB uncacheable, ");
    serial_put_dec64(g_vmm.table_pages);
    serial_puts(" page-table frames, NX ");
    serial_puts(g_vmm.nx_supported ? "supported\n" : "NOT supported by this CPU\n");

    if (out) *out = g_vmm;
    return 1;
}

/* ------------------------------------------------------------------ *
 * Pre-activation verification
 * ------------------------------------------------------------------ */

static int check_mapped(const char *what, uint64_t addr)
{
    uint64_t phys = 0;
    /* Verification walks the NEW tables directly, which is the point:
     * asking the CPU would answer for the tables currently in CR3. */
    VmmResult r = vmm_translate(addr, &phys);
    if (r != VMM_OK) {
        serial_puts("[kernel] VMM: PRE-ACTIVATION CHECK FAILED - ");
        serial_puts(what);
        serial_puts(" @ ");
        serial_put_hex64(addr);
        serial_puts(" is not mapped\n");
        return 0;
    }
    if (phys != addr) {
        /* Everything checked here is expected to be identity mapped. */
        serial_puts("[kernel] VMM: PRE-ACTIVATION CHECK FAILED - ");
        serial_puts(what);
        serial_puts(" @ ");
        serial_put_hex64(addr);
        serial_puts(" translates to ");
        serial_put_hex64(phys);
        serial_puts(", expected identity\n");
        return 0;
    }
    return 1;
}

int vmm_verify_before_activation(BootInfo *info, uint64_t lapic_base)
{
    int ok = 1;

    /* Anything the kernel is actively using at the moment CR3 changes.
     * A missing entry here is a triple fault with no diagnostic if it
     * is discovered by loading CR3 instead of by this check. */

    /* Currently-executing code and the current stack. */
    uint64_t rip_here = (uint64_t)(uintptr_t)&vmm_verify_before_activation;
    uint64_t rsp_here;
    __asm__ volatile ("mov %%rsp, %0" : "=r"(rsp_here));

    ok &= check_mapped("kernel code", align_down(rip_here, VMM_PAGE_SIZE));
    ok &= check_mapped("current stack", align_down(rsp_here, VMM_PAGE_SIZE));

    /* The page tables themselves - they are walked through identity
     * addresses after activation too. */
    ok &= check_mapped("PML4", g_vmm.pml4_phys);

    /* BootInfo, the memory map array, the kernel image. */
    ok &= check_mapped("BootInfo", align_down((uint64_t)(uintptr_t)info,
                                              VMM_PAGE_SIZE));
    ok &= check_mapped("EFI memory map",
                       align_down(info->memory_map, VMM_PAGE_SIZE));
    ok &= check_mapped("kernel image base",
                       align_down(info->kernel_physical_base, VMM_PAGE_SIZE));

    if (info->kernel_physical_size > 0) {
        ok &= check_mapped("kernel image end",
                           align_down(info->kernel_physical_base +
                                      info->kernel_physical_size - 1,
                                      VMM_PAGE_SIZE));
    }

    /* Framebuffer: first and last byte. */
    if (info->framebuffer_addr != 0 && info->framebuffer_size != 0) {
        ok &= check_mapped("framebuffer start",
                           align_down(info->framebuffer_addr, VMM_PAGE_SIZE));
        ok &= check_mapped("framebuffer end",
                           align_down(info->framebuffer_addr +
                                      info->framebuffer_size - 1,
                                      VMM_PAGE_SIZE));
    }

    /* ACPI RSDP. */
    if (info->rsdp_address != 0) {
        ok &= check_mapped("ACPI RSDP",
                           align_down(info->rsdp_address, VMM_PAGE_SIZE));
    }

    /* LAPIC MMIO - the very next thing the kernel touches after this. */
    if (lapic_base != 0) {
        ok &= check_mapped("LAPIC MMIO", align_down(lapic_base, VMM_PAGE_SIZE));

        /* And confirm it is NOT write-back. Mapping the LAPIC cacheable
         * would appear to work in QEMU and be a genuine bug on real
         * hardware, so it is checked rather than assumed. */
        uint64_t entry = 0, size = 0;
        if (vmm_query(lapic_base, &entry, &size) == VMM_OK) {
            if ((entry & (VMM_PCD | VMM_PWT)) != (VMM_PCD | VMM_PWT)) {
                serial_puts("[kernel] VMM: PRE-ACTIVATION CHECK FAILED - LAPIC MMIO"
                            " is not mapped uncacheable (entry=");
                serial_put_hex64(entry);
                serial_puts(")\n");
                ok = 0;
            }
        }
    }

    /* The direct physical map must agree with the identity map for a
     * sample address, otherwise the second window is decoration. */
    {
        uint64_t phys = 0;
        uint64_t probe = VEX_PHYS_MAP_BASE + info->kernel_physical_base;
        if (vmm_translate(probe, &phys) != VMM_OK ||
            phys != info->kernel_physical_base) {
            serial_puts("[kernel] VMM: PRE-ACTIVATION CHECK FAILED - direct map"
                        " does not resolve to the expected physical address\n");
            ok = 0;
        }
    }

    if (ok) {
        serial_puts("[kernel] VMM: pre-activation checks PASS"
                    " (code, stack, tables, BootInfo, memory map, kernel image,"
                    " framebuffer, ACPI, LAPIC, direct map)\n");
    }
    return ok;
}

/* ------------------------------------------------------------------ *
 * Activation
 * ------------------------------------------------------------------ */

static uint64_t read_msr(uint32_t msr)
{
    uint32_t lo, hi;
    __asm__ volatile ("rdmsr" : "=a"(lo), "=d"(hi) : "c"(msr));
    return ((uint64_t)hi << 32) | lo;
}

static void write_msr(uint32_t msr, uint64_t value)
{
    __asm__ volatile ("wrmsr" : :
        "c"(msr), "a"((uint32_t)(value & 0xFFFFFFFF)),
        "d"((uint32_t)(value >> 32)));
}

void vmm_activate(void)
{
    if (g_vmm.pml4_phys == 0) {
        panic("VMM: vmm_activate() with no tables built", 0, 0);
    }

    /* EFER.NXE must be set before any NX bit is meaningful, and before
     * CR3 is loaded below - SECURITY-01 marks the direct map NX at build
     * time, so the tables about to go live already contain NX bits.
     * Safe because the kernel executes only out of the identity map,
     * which is deliberately left executable. */
    if (g_vmm.nx_supported) {
        uint64_t efer = read_msr(IA32_EFER);
        if (!(efer & EFER_NXE_BIT)) {
            write_msr(IA32_EFER, efer | EFER_NXE_BIT);
        }
        g_vmm.nx_enabled = (read_msr(IA32_EFER) & EFER_NXE_BIT) != 0;
    }

    /* CR0.WP (bit 16). Without it, a RING-0 write to a read-only page
     * does NOT fault - the write-protect bit is only enforced for
     * supervisor accesses when WP is set (Intel SDM Vol.3, "Access
     * Rights"). Firmware state cannot be assumed either way, so it is
     * set explicitly.
     *
     * This is not cosmetic: without WP, marking kernel .rodata or a page
     * table read-only would silently do nothing, and BOOT-03's
     * read-only-page test would pass while proving the opposite of what
     * it claims. */
    uint64_t cr0;
    __asm__ volatile ("mov %%cr0, %0" : "=r"(cr0));
    cr0 |= (1ULL << 16);
    __asm__ volatile ("mov %0, %%cr0" : : "r"(cr0) : "memory");

    __asm__ volatile ("mov %0, %%cr3" : : "r"(g_vmm.pml4_phys) : "memory");
    g_vmm.active = 1;
}

int vmm_write_protect_enabled(void)
{
    uint64_t cr0;
    __asm__ volatile ("mov %%cr0, %0" : "=r"(cr0));
    return (cr0 & (1ULL << 16)) != 0;
}

/* ------------------------------------------------------------------ *
 * 4 KiB mapping primitives
 * ------------------------------------------------------------------ */

/* Walks to the PTE for `virt`. Returns the PT pointer and index, or a
 * result code. Caller holds the lock. */
static VmmResult walk_to_pt(uint64_t virt, int create,
                            uint64_t **out_pt, uint64_t *out_index)
{
    if (g_pml4 == 0) return VMM_ERR_NOT_INITIALIZED;

    uint64_t *pdpt = next_level(g_pml4, PML4_INDEX(virt), create);
    if (pdpt == 0) {
        return (g_pml4[PML4_INDEX(virt)] & VMM_PRESENT)
            ? VMM_ERR_LARGE_PAGE : (create ? VMM_ERR_NO_MEMORY : VMM_ERR_NOT_MAPPED);
    }

    /* A 1 GiB mapping would show up here. Vex OS never creates one, but
     * refusing explicitly beats corrupting an entry we do not
     * understand. */
    uint64_t pdpte = pdpt[PDPT_INDEX(virt)];
    if ((pdpte & VMM_PRESENT) && (pdpte & VMM_LARGE)) return VMM_ERR_LARGE_PAGE;

    uint64_t *pd = next_level(pdpt, PDPT_INDEX(virt), create);
    if (pd == 0) return create ? VMM_ERR_NO_MEMORY : VMM_ERR_NOT_MAPPED;

    uint64_t pde = pd[PD_INDEX(virt)];
    if ((pde & VMM_PRESENT) && (pde & VMM_LARGE)) return VMM_ERR_LARGE_PAGE;

    uint64_t *pt = next_level(pd, PD_INDEX(virt), create);
    if (pt == 0) return create ? VMM_ERR_NO_MEMORY : VMM_ERR_NOT_MAPPED;

    *out_pt = pt;
    *out_index = PT_INDEX(virt);
    return VMM_OK;
}

/* SECURITY-01: refuse VMM_USER outright.
 *
 * next_level() creates intermediate entries as PRESENT|WRITE with no
 * USER bit, and the effective permission of a mapping is the AND of the
 * USER bits along the whole walk. A caller passing VMM_USER therefore
 * gets a leaf marked user-accessible underneath ancestors that are not,
 * i.e. a mapping the hardware denies to Ring 3 anyway - a request that
 * SILENTLY does not do what it says.
 *
 * Two ways to fix that: propagate USER up the walk, or refuse the
 * request. Propagation is a real address-space design decision (which
 * ancestors become user-visible, and what that means for every other
 * mapping sharing them) and it belongs to whichever milestone actually
 * introduces Ring 3, with tests that can observe CPL 3. Refusing is the
 * smaller, honest option available now: a caller gets an error instead
 * of a mapping that quietly means something else.
 *
 * This is also the enforcement point for "the kernel must never
 * accidentally inherit the USER bit" - not a comment saying it doesn't,
 * but a check that makes it impossible through this path. The audit in
 * secure.c independently verifies the live tables, in case some other
 * path ever appears. */
static int vmm_flags_request_user(uint64_t flags)
{
#if VEX_INJECTED(14)
    /* INJECTION 14: the USER-bit refusal is removed, so a kernel mapping
     * can be created with USER set. The page-table audit must notice. */
    (void)flags;
    return 0;
#else
    return (flags & VMM_USER) != 0;
#endif
}

VmmResult vmm_map_page(uint64_t virt, uint64_t phys, uint64_t flags)
{
    if ((virt | phys) & (VMM_PAGE_SIZE - 1)) return VMM_ERR_NOT_ALIGNED;
    if (vmm_flags_request_user(flags)) return VMM_ERR_BAD_REQUEST;

    uint64_t lf = vmm_lock();

    uint64_t *pt; uint64_t idx;
    VmmResult r = walk_to_pt(virt, 1, &pt, &idx);
    if (r != VMM_OK) { vmm_unlock(lf); return r; }

    if (pt[idx] & VMM_PRESENT) {
        /* Silently replacing a live mapping is how one subsystem
         * corrupts another's memory. Make the caller be explicit. */
        vmm_unlock(lf);
        return VMM_ERR_ALREADY_MAPPED;
    }

    pt[idx] = (phys & ADDR_MASK) | (flags | VMM_PRESENT);

    /* Invalidate even though the entry was not present: a negative TLB
     * entry or a speculative walk may have cached the absence. */
    invlpg(virt);

    vmm_unlock(lf);
    return VMM_OK;
}

/* SECURITY-02: the narrow, separately-named door vmm_map_page()'s own
 * comment said this milestone would need to add.
 *
 * WHY A SEPARATE FUNCTION, NOT A RELAXATION OF vmm_map_page()'s CHECK.
 * As that comment explains: a leaf PTE with VMM_USER set is still
 * denied to Ring 3 by hardware if ANY ancestor (PML4E/PDPTE/PDE) along
 * the walk has its U/S bit clear - the CPU ANDs the user bit across
 * every level. next_level() creates ancestors as PRESENT|WRITE with no
 * USER bit. So making a leaf user-accessible requires ALSO setting
 * VMM_USER on every ancestor on that specific path - a real
 * address-space design decision, not a flag to pass through.
 *
 * WHY THIS IS SAFE TO DO WITHOUT WEAKENING ANYTHING ELSE. Setting
 * VMM_USER on an intermediate table's entry does not, by itself, expose
 * anything: the effective permission of EVERY page under that table is
 * STILL the AND of its own leaf bit with this ancestor bit. A sibling
 * leaf that was mapped kernel-only (VMM_USER clear) through the SAME
 * ancestor remains exactly as protected as before - promoting the
 * ancestor only removes a necessary-but-not-sufficient restriction for
 * that one sibling, and its own PTE.USER=0 is still sufficient on its
 * own to deny Ring 3. This is standard x86-64 paging semantics (every
 * mainstream kernel promotes ancestors this way for the same reason),
 * not a VEX OS-specific relaxation.
 *
 * WHAT THIS FUNCTION REFUSES, SO THE PROMOTION STAYS NARROW:
 *   - `flags` without VMM_USER set: calling this for a non-user mapping
 *     would be a caller bug (use vmm_map_page()), not a legitimate use.
 *   - Everything vmm_map_page() already refuses: misalignment, an
 *     already-present leaf, a 1 GiB/2 MiB large-page collision along the
 *     walk. walk_to_pt() is reused unchanged, so those checks are
 *     identical, not reimplemented and possibly drifted. */
static void promote_ancestors_user(uint64_t virt)
{
    /* Re-derives each ancestor pointer the exact same way walk_to_pt()
     * does (next_level with create=0 - the path was just created by the
     * walk_to_pt() call in vmm_map_user_page(), so every level is
     * already present). OR-ing VMM_USER in is safe to do blindly: it
     * can only ever ADD the bit, never remove VMM_PRESENT/VMM_WRITE or
     * any other bit already there. */
    uint64_t *pdpt = next_level(g_pml4, PML4_INDEX(virt), 0);
    if (!pdpt) return;
    g_pml4[PML4_INDEX(virt)] |= VMM_USER;

    uint64_t *pd = next_level(pdpt, PDPT_INDEX(virt), 0);
    if (!pd) return;
    pdpt[PDPT_INDEX(virt)] |= VMM_USER;

    uint64_t *pt = next_level(pd, PD_INDEX(virt), 0);
    if (!pt) return;
    pd[PD_INDEX(virt)] |= VMM_USER;

    /* The leaf (pt[PT_INDEX(virt)]) already got VMM_USER from the
     * caller's own flags - that is the actual, fine-grained gate for
     * this one page, and it is set by vmm_map_user_page() itself, not
     * here. */
}

VmmResult vmm_map_user_page(uint64_t virt, uint64_t phys, uint64_t flags)
{
    if ((virt | phys) & (VMM_PAGE_SIZE - 1)) return VMM_ERR_NOT_ALIGNED;
    if ((flags & VMM_USER) == 0) return VMM_ERR_BAD_REQUEST;

    uint64_t lf = vmm_lock();

    uint64_t *pt; uint64_t idx;
    VmmResult r = walk_to_pt(virt, 1, &pt, &idx);
    if (r != VMM_OK) { vmm_unlock(lf); return r; }

    if (pt[idx] & VMM_PRESENT) {
        vmm_unlock(lf);
        return VMM_ERR_ALREADY_MAPPED;
    }

    pt[idx] = (phys & ADDR_MASK) | (flags | VMM_PRESENT);
    promote_ancestors_user(virt);
    invlpg(virt);

    vmm_unlock(lf);
    return VMM_OK;
}

VmmResult vmm_unmap_page(uint64_t virt)
{
    if (virt & (VMM_PAGE_SIZE - 1)) return VMM_ERR_NOT_ALIGNED;

    uint64_t lf = vmm_lock();

    uint64_t *pt; uint64_t idx;
    VmmResult r = walk_to_pt(virt, 0, &pt, &idx);
    if (r != VMM_OK) { vmm_unlock(lf); return r; }

    if (!(pt[idx] & VMM_PRESENT)) { vmm_unlock(lf); return VMM_ERR_NOT_MAPPED; }

#if VEX_INJECTED(1)
    /* NEGATIVE CONTROL: leave the entry present and report success. The
     * PAGING test must catch this. See kernel/include/boot03_inject.h. */
    (void)0;
#else
    pt[idx] = 0;
#endif
    invlpg(virt);

    /* The now-possibly-empty page table is NOT freed. Freeing it would
     * require proving no other CPU is mid-walk through it, which needs
     * TLB shootdown IPIs that BOOT-03 does not have. Leaking an empty
     * table is a bounded, documented cost; freeing it unsafely is a
     * silent corruption. See docs/BOOT-03.md. */

    vmm_unlock(lf);
    return VMM_OK;
}

/* ------------------------------------------------------------------ *
 * KERNEL-01 Phase 5 - page-table reclamation
 *
 * WHAT WAS WRONG. vmm_unmap_page() cleared the PTE and left the now-empty
 * page table allocated forever. BOOT-03 documented that as a deliberate
 * choice, and it was the right one at the time: freeing the table needs
 * proof that no other CPU is mid-walk through it, and proving that needs
 * TLB shootdown IPIs, which BOOT-03 did not have. Phase 4 built them.
 *
 * WHY THE FIX IS A NEW ENTRY POINT RATHER THAN A CHANGE TO
 * vmm_unmap_page()
 *
 * Not for API tidiness - because vmm_unmap_page() physically cannot do it.
 * It runs entirely inside vmm_lock(), which clears IF, and a remote
 * shootdown with interrupts disabled is refused by design (tlb.h explains
 * why: waiting for another CPU while unable to answer it livelocks). The
 * required sequence therefore has to release the lock in the middle:
 *
 *   1. under the lock: clear the leaf entry, and clear each parent that
 *      the removal just emptied, remembering the frames
 *   2. release the lock
 *   3. shoot down the address on every CPU, and CONFIRM completion
 *   4. only then hand the frames back to the allocator
 *
 * vmm_unmap_page() keeps its exact previous behaviour, including the
 * documented leak, so every existing BOOT-03 test and its fault injection
 * 1 continue to describe the code they were written against.
 *
 * WHY PARENTS ARE CLEARED BEFORE THE SHOOTDOWN, NOT AFTER
 *
 * This is the ordering the whole thing turns on. Intel SDM Vol.3
 * ("Invalidation of TLBs and Paging-Structure Caches") specifies that
 * INVLPG invalidates the paging-structure caches for the linear address it
 * names, not just the final translation. So if every entry along the walk
 * for `virt` is already cleared BEFORE the shootdown runs, then after the
 * shootdown no CPU holds any cached reference - final or intermediate - to
 * any of those tables, and there is no path by which one could acquire a
 * new reference, because the entries that would let it walk there are
 * gone. Freeing the frames at that point is safe.
 *
 * Doing it the other way round - shoot down the leaf, then clear parents,
 * then free - would leave a window in which another CPU could re-walk
 * through a parent that is still present and re-cache the very table about
 * to be freed.
 *
 * WHAT IS NEVER FREED
 *
 *   - The PML4. It is the address space; a CR3 pointing at freed memory is
 *     not a recoverable condition.
 *   - Anything outside the kmap window. The identity map and the direct
 *     map are built from 2 MiB entries whose parent tables are shared by
 *     the kernel image, the framebuffer, MMIO and every AP's view of
 *     memory. Restricting reclamation to the kmap window is what makes
 *     "never free a shared or static table" a structural property rather
 *     than a promise: an address outside the window is rejected before any
 *     entry is touched.
 *   - Any table that still has a present entry. Emptiness is verified by
 *     reading all 512 entries, not inferred from a count that could drift.
 *
 * FAILURE DIRECTION. If the shootdown does not complete, the frames are
 * LEAKED rather than freed, and the call reports the failure. A leak is a
 * bounded, observable cost; a premature free is silent corruption whose
 * cause is arbitrarily far from its effect. Every error path here leaks.
 * ------------------------------------------------------------------ */

/* Statistics. Separate accessors rather than new VmmInfo fields, so the
 * struct BOOT-03's tests read stays exactly as it was. */
static uint64_t g_reclaim_attempts;
static uint64_t g_tables_reclaimed;
static uint64_t g_reclaim_leaks;         /* frames left behind after a
                                          * failed or refused shootdown */
static uint64_t g_reclaim_violations;    /* frames freed WITHOUT a
                                          * completed shootdown */

uint64_t vmm_reclaim_attempts(void)   { return g_reclaim_attempts; }
uint64_t vmm_tables_reclaimed(void)   { return g_tables_reclaimed; }
uint64_t vmm_reclaim_leaks(void)      { return g_reclaim_leaks; }
uint64_t vmm_reclaim_violations(void) { return g_reclaim_violations; }

/* 1 if every entry in `table` is absent. Reads all 512 entries rather
 * than trusting a maintained counter: a count that drifted would cause a
 * live table to be freed, which is exactly the failure this whole path is
 * built to avoid, and the read is 4 KiB of already-cached memory. */
static int table_is_empty(const uint64_t *table)
{
    for (int i = 0; i < ENTRIES; i++) {
        if (table[i] & VMM_PRESENT) return 0;
    }
    return 1;
}

VmmResult vmm_unmap_page_reclaim(uint64_t virt)
{
    if (virt & (VMM_PAGE_SIZE - 1)) return VMM_ERR_NOT_ALIGNED;

    /* Rejected before anything is touched. Outside the kmap window the
     * intermediate tables are shared with the identity map, the direct
     * map, the kernel image and the framebuffer, and freeing one would
     * unmap memory belonging to subsystems that never asked. */
    if (virt < VEX_KMAP_BASE || virt >= VEX_KMAP_BASE + VEX_KMAP_SIZE) {
        return VMM_ERR_BAD_REQUEST;
    }

    g_reclaim_attempts++;

    /* Frames the removal orphaned, deepest first. At most three: PT, PD,
     * PDPT. The PML4 is never a candidate. */
    uint64_t orphans[3];
    int orphan_count = 0;

    /* ---- step 1: all entry edits, under the lock ---- */
    uint64_t lf = vmm_lock();

    if (g_pml4 == 0) { vmm_unlock(lf); return VMM_ERR_NOT_INITIALIZED; }

    /* Walked by hand rather than through walk_to_pt(), because the parents
     * are needed in order to clear them and walk_to_pt() returns only the
     * leaf table. `create` is never implied. */
    uint64_t pml4i = PML4_INDEX(virt);
    uint64_t e = g_pml4[pml4i];
    if (!(e & VMM_PRESENT)) { vmm_unlock(lf); return VMM_ERR_NOT_MAPPED; }
    if (e & VMM_LARGE)      { vmm_unlock(lf); return VMM_ERR_LARGE_PAGE; }
    uint64_t pdpt_phys = e & ADDR_MASK;
    uint64_t *pdpt = (uint64_t *)(uintptr_t)pdpt_phys;

    uint64_t pdpti = PDPT_INDEX(virt);
    e = pdpt[pdpti];
    if (!(e & VMM_PRESENT)) { vmm_unlock(lf); return VMM_ERR_NOT_MAPPED; }
    if (e & VMM_LARGE)      { vmm_unlock(lf); return VMM_ERR_LARGE_PAGE; }
    uint64_t pd_phys = e & ADDR_MASK;
    uint64_t *pd = (uint64_t *)(uintptr_t)pd_phys;

    uint64_t pdi = PD_INDEX(virt);
    e = pd[pdi];
    if (!(e & VMM_PRESENT)) { vmm_unlock(lf); return VMM_ERR_NOT_MAPPED; }
    if (e & VMM_LARGE)      { vmm_unlock(lf); return VMM_ERR_LARGE_PAGE; }
    uint64_t pt_phys = e & ADDR_MASK;
    uint64_t *pt = (uint64_t *)(uintptr_t)pt_phys;

    uint64_t pti = PT_INDEX(virt);
    if (!(pt[pti] & VMM_PRESENT)) { vmm_unlock(lf); return VMM_ERR_NOT_MAPPED; }

    pt[pti] = 0;

    /* Climb, clearing each parent the removal just emptied. Stops at the
     * first level that still has a live entry - a non-empty table means
     * every level above it is non-empty too. */
    if (table_is_empty(pt)) {
        pd[pdi] = 0;
        orphans[orphan_count++] = pt_phys;

        if (table_is_empty(pd)) {
            pdpt[pdpti] = 0;
            orphans[orphan_count++] = pd_phys;

            if (table_is_empty(pdpt)) {
                /* Clearing a PML4 ENTRY, never the PML4 itself. */
                g_pml4[pml4i] = 0;
                orphans[orphan_count++] = pdpt_phys;
            }
        }
    }

    /* Local invalidation while still holding the lock, matching what the
     * other primitives do. The remote half cannot happen here - the lock
     * has interrupts disabled. */
    invlpg(virt);

    vmm_unlock(lf);

    /* ---- step 2: shoot down, and prove it completed ---- */

    /* Every entry along the walk is already cleared, so from this point no
     * CPU can acquire a new cached reference to any orphaned table. The
     * shootdown removes the references that already exist. */
    uint64_t completed_before = tlb_completed_count();

#if VEX_INJECTED(6) || VEX_INJECTED(7)
    /* NEGATIVE CONTROL, both injections: skip the required shootdown
     * entirely.
     *
     * Injection 6 stops here. The gate below must refuse to free the
     * orphaned frames, so the reclamation count stays flat and the
     * K01-RECLAIM tests must catch it.
     *
     * Injection 7 goes further and frees anyway despite the refusal (see
     * below), which is why it must skip the shootdown too - otherwise the
     * gate would be satisfied and the refused branch it attacks would
     * never be reached. See kernel/include/boot03_inject.h. */
    TlbResult tr = TLB_OK;
    (void)tr;
#else
    TlbResult tr = tlb_shootdown_page(virt);
    (void)tr;
#endif

    /* THE GATE. Deliberately checks the completed-shootdown COUNTER rather
     * than the return value above. "The call I made returned OK" is a
     * weaker claim than "a shootdown demonstrably completed between my
     * entry edits and my free" - and it is the weaker claim that a removed,
     * bypassed, or stubbed-out shootdown could still satisfy. */
    int shootdown_completed = (tlb_completed_count() > completed_before);

    /* ---- step 3: hand the frames back, only if permitted ---- */

    if (!shootdown_completed) {
        /* LEAK, on purpose. The entries are already gone so the address
         * space is correct; the frames are simply not returned. A bounded
         * leak that is counted and reported is a far better outcome than
         * freeing a frame another CPU may still be able to translate. */
        g_reclaim_leaks += (uint64_t)orphan_count;

#if VEX_INJECTED(7)
        /* NEGATIVE CONTROL: free the frames anyway, despite the gate
         * having refused. The violation counter below still records it -
         * the injection removes the refusal, not the observation - so the
         * K01-RECLAIM tests must catch it. */
        for (int i = 0; i < orphan_count; i++) {
            g_reclaim_violations++;
            if (pmm_release_reserved_page(orphans[i], PMM_RSV_PAGE_TABLE)
                == PMM_OK) {
                g_vmm.table_pages--;
                g_tables_reclaimed++;
            }
        }
        return VMM_OK;
#endif
        return VMM_ERR_BAD_REQUEST;
    }

    for (int i = 0; i < orphan_count; i++) {
        if (pmm_release_reserved_page(orphans[i], PMM_RSV_PAGE_TABLE)
            == PMM_OK) {
            g_vmm.table_pages--;
            g_tables_reclaimed++;
        } else {
            /* The allocator refused. Counted as a leak rather than
             * retried: the refusal means this frame is not what we believe
             * it is, and forcing the point would be the corruption the
             * refusal exists to prevent. */
            g_reclaim_leaks++;
        }
    }

    return VMM_OK;
}

VmmResult vmm_protect_page(uint64_t virt, uint64_t flags)
{
    if (virt & (VMM_PAGE_SIZE - 1)) return VMM_ERR_NOT_ALIGNED;
    /* SECURITY-01: same refusal as vmm_map_page. Changing permissions is
     * exactly as good a way to hand Ring 3 a kernel page as creating the
     * mapping was, so it cannot be the unguarded door. */
    if (vmm_flags_request_user(flags)) return VMM_ERR_BAD_REQUEST;

    uint64_t lf = vmm_lock();

    uint64_t *pt; uint64_t idx;
    VmmResult r = walk_to_pt(virt, 0, &pt, &idx);
    if (r != VMM_OK) { vmm_unlock(lf); return r; }

    if (!(pt[idx] & VMM_PRESENT)) { vmm_unlock(lf); return VMM_ERR_NOT_MAPPED; }

    uint64_t phys = pt[idx] & ADDR_MASK;
    pt[idx] = phys | (flags | VMM_PRESENT);
    invlpg(virt);

    vmm_unlock(lf);
    return VMM_OK;
}

/* ------------------------------------------------------------------ *
 * Translation / query
 *
 * These walk the tables in software rather than asking the CPU, so they
 * work before activation (which is what makes
 * vmm_verify_before_activation possible) and can describe a mapping the
 * current CR3 knows nothing about.
 * ------------------------------------------------------------------ */

VmmResult vmm_query(uint64_t virt, uint64_t *out_entry, uint64_t *out_size)
{
    if (g_pml4 == 0) return VMM_ERR_NOT_INITIALIZED;

    uint64_t e = g_pml4[PML4_INDEX(virt)];
    if (!(e & VMM_PRESENT)) return VMM_ERR_NOT_MAPPED;

    uint64_t *pdpt = (uint64_t *)(uintptr_t)(e & ADDR_MASK);
    e = pdpt[PDPT_INDEX(virt)];
    if (!(e & VMM_PRESENT)) return VMM_ERR_NOT_MAPPED;
    if (e & VMM_LARGE) {
        if (out_entry) *out_entry = e;
        if (out_size) *out_size = 0x40000000ULL;   /* 1 GiB */
        return VMM_OK;
    }

    uint64_t *pd = (uint64_t *)(uintptr_t)(e & ADDR_MASK);
    e = pd[PD_INDEX(virt)];
    if (!(e & VMM_PRESENT)) return VMM_ERR_NOT_MAPPED;
    if (e & VMM_LARGE) {
        if (out_entry) *out_entry = e;
        if (out_size) *out_size = VMM_LARGE_PAGE_SIZE;
        return VMM_OK;
    }

    uint64_t *pt = (uint64_t *)(uintptr_t)(e & ADDR_MASK);
    e = pt[PT_INDEX(virt)];
    if (!(e & VMM_PRESENT)) return VMM_ERR_NOT_MAPPED;

    if (out_entry) *out_entry = e;
    if (out_size) *out_size = VMM_PAGE_SIZE;
    return VMM_OK;
}

VmmResult vmm_translate(uint64_t virt, uint64_t *out_phys)
{
    uint64_t entry = 0, size = 0;
    VmmResult r = vmm_query(virt, &entry, &size);
    if (r != VMM_OK) return r;

    uint64_t base = entry & ADDR_MASK;

    /* For a large mapping the low bits of the entry's address field are
     * reserved-zero, so masking to the page size and adding the offset
     * within the page is the correct reconstruction. */
    uint64_t offset = virt & (size - 1);
    if (out_phys) *out_phys = (base & ~(size - 1)) + offset;
    return VMM_OK;
}

/* ------------------------------------------------------------------ *
 * kmap virtual address space
 * ------------------------------------------------------------------ */

/* KERNEL-01 Phase 6 - reclaimable kmap virtual ranges.
 *
 * WHAT WAS WRONG. The kmap allocator was a bump cursor with no free. Every
 * range ever handed out consumed window space permanently, so a subsystem
 * that repeatedly mapped and unmapped anything - and any failed kernel-stack
 * allocation, which unwinds its physical frames but could not return its
 * virtual range - burned address space it could never get back.
 *
 * WHY A RANGE TABLE AND NOT A REAL VIRTUAL-MEMORY ALLOCATOR. The milestone
 * says explicitly not to build a general-purpose one unless the architecture
 * requires it, and it does not: the consumers are kernel stacks, one per CPU,
 * and the self-tests. What is needed is reserve, free, and reuse, with every
 * malformed free refused. That is a small fixed table of records and an
 * exact-size first-fit search over it - no trees, no coalescing, no splitting.
 *
 * WHAT IS DELIBERATELY NOT DONE, AND THE COST OF NOT DOING IT. Free ranges
 * are neither split nor coalesced, so reuse requires an exact page-count
 * match. A workload that freed many 4-page ranges and then asked for one
 * 8-page range would bump the cursor instead of merging two neighbours. With
 * a 512 GiB window and single-digit consumers that cost is unreachable, and
 * naming it is better than adding a merge path that nothing exercises and no
 * test could distinguish from a bug. If a future milestone adds a consumer
 * with churn of mixed sizes, this is the place that has to change.
 *
 * THE BUMP CURSOR STILL NEVER MOVES BACKWARD. BOOT-03 sec.9 lists that as an
 * invariant, and it is preserved literally rather than argued around: reuse
 * comes from the record table, never from rewinding g_kmap_next. A range that
 * was freed and re-issued has the same base as before precisely because the
 * record remembered it, not because the cursor went back.
 *
 * WHY FREEING A RANGE THAT IS STILL MAPPED IS REFUSED. If a range were
 * returned while pages inside it were still mapped, the next consumer to be
 * handed that range would get vmm_map_page() failing with ALREADY_MAPPED at
 * an arbitrary offset - or worse, would inherit live mappings to frames
 * belonging to someone else. So the free path walks the range and refuses if
 * any page is still present. Unmap first, then free the range.
 * ------------------------------------------------------------------ */

/* One record per outstanding or freed range. Sized for the maximum CPU count
 * (one stack range each), the BOOT-03 and KERNEL-01 self-tests, and headroom.
 * A fixed array rather than a linked structure because it must be usable
 * before any general allocator exists and must not itself need the window it
 * manages. */
#define KMAP_MAX_RANGES 96

typedef struct {
    uint64_t base;
    uint64_t pages;
    int      in_use;    /* 1 = handed out, 0 = free and reusable */
    int      valid;     /* 1 = this record describes a real range */
} KmapRange;

static KmapRange g_kmap_ranges[KMAP_MAX_RANGES];
static uint64_t  g_kmap_live_ranges;
static uint64_t  g_kmap_free_ranges;
static uint64_t  g_kmap_reuses;        /* reservations satisfied without
                                        * moving the cursor */

/* Caller holds the lock. Finds the record for an exact base, or 0. */
static KmapRange *kmap_find(uint64_t base)
{
    for (int i = 0; i < KMAP_MAX_RANGES; i++) {
        if (g_kmap_ranges[i].valid && g_kmap_ranges[i].base == base) {
            return &g_kmap_ranges[i];
        }
    }
    return 0;
}

/* Caller holds the lock. 1 if [base, base+pages) intersects any range that
 * is currently handed out. This is the overlap guarantee: it is checked
 * against the record table rather than assumed from the cursor, so a bug in
 * reuse cannot hand the same address to two consumers. */
static int kmap_overlaps_live(uint64_t base, uint64_t pages)
{
    uint64_t end = base + pages * VMM_PAGE_SIZE;
    for (int i = 0; i < KMAP_MAX_RANGES; i++) {
        const KmapRange *r = &g_kmap_ranges[i];
        if (!r->valid || !r->in_use) continue;
        uint64_t rend = r->base + r->pages * VMM_PAGE_SIZE;
        if (base < rend && r->base < end) return 1;
    }
    return 0;
}

uint64_t vmm_kmap_reserve_virtual(uint64_t pages)
{
    if (pages == 0) return 0;

    uint64_t lf = vmm_lock();

    /* --- reuse first: exact size, first fit --- */
    for (int i = 0; i < KMAP_MAX_RANGES; i++) {
        KmapRange *r = &g_kmap_ranges[i];
        if (!r->valid || r->in_use || r->pages != pages) continue;

        /* Checked even though it should be impossible: a free record that
         * overlapped a live one would mean the table is corrupt, and handing
         * the range out anyway would turn that into two subsystems writing
         * the same addresses. */
        if (kmap_overlaps_live(r->base, pages)) continue;

        r->in_use = 1;
        g_kmap_free_ranges--;
        g_kmap_live_ranges++;
        g_kmap_reuses++;
        uint64_t base = r->base;
        vmm_unlock(lf);
        return base;
    }

    /* --- otherwise take fresh space from the cursor --- */

    /* A free record must be available BEFORE the cursor moves. Handing out a
     * range that cannot be recorded would produce an address that can never
     * be freed and that overlap checking cannot see - worse than refusing. */
    KmapRange *slot = 0;
    for (int i = 0; i < KMAP_MAX_RANGES; i++) {
        if (!g_kmap_ranges[i].valid) { slot = &g_kmap_ranges[i]; break; }
    }
    if (slot == 0) { vmm_unlock(lf); return 0; }

    uint64_t need = pages * VMM_PAGE_SIZE;
    if (g_kmap_next < VEX_KMAP_BASE ||
        g_kmap_next + need > VEX_KMAP_BASE + VEX_KMAP_SIZE ||
        g_kmap_next + need < g_kmap_next) {          /* overflow */
        vmm_unlock(lf);
        return 0;
    }

    uint64_t base = g_kmap_next;
    g_kmap_next += need;

    slot->base = base;
    slot->pages = pages;
    slot->in_use = 1;
    slot->valid = 1;
    g_kmap_live_ranges++;

    vmm_unlock(lf);
    return base;
}

VmmResult vmm_kmap_free_virtual(uint64_t base, uint64_t pages)
{
    if (pages == 0) return VMM_ERR_BAD_REQUEST;
    if (base & (VMM_PAGE_SIZE - 1)) return VMM_ERR_NOT_ALIGNED;
    if (base < VEX_KMAP_BASE ||
        base + pages * VMM_PAGE_SIZE > VEX_KMAP_BASE + VEX_KMAP_SIZE) {
        return VMM_ERR_BAD_REQUEST;
    }

    /* Checked before the lock is taken, because vmm_query() takes it. The
     * range must be fully unmapped first: reissuing a range with live
     * mappings inside it would hand the next consumer someone else's frames.
     * A page covered by a large mapping is impossible inside the kmap
     * window, but it is refused rather than ignored. */
    for (uint64_t i = 0; i < pages; i++) {
        uint64_t entry = 0, size = 0;
        if (vmm_query(base + i * VMM_PAGE_SIZE, &entry, &size) == VMM_OK) {
            return VMM_ERR_ALREADY_MAPPED;
        }
    }

    uint64_t lf = vmm_lock();

    KmapRange *r = kmap_find(base);
    if (r == 0) {
        /* Either never reserved, or an address in the middle of a range
         * rather than its base. Both are caller bugs and both are refused;
         * accepting a mid-range address would silently free a different
         * range than the caller named. */
        vmm_unlock(lf);
        return VMM_ERR_NO_SUCH_RANGE;
    }
#if VEX_INJECTED(9)
    /* NEGATIVE CONTROL: accept a double free of a virtual range. The range
     * is already on the free list, so accepting this would let it be handed
     * to two consumers at once. The K01-KMAP tests must catch it. See
     * kernel/include/boot03_inject.h. */
    if (0) {
#else
    if (!r->in_use) {
#endif
        vmm_unlock(lf);
        return VMM_ERR_ALREADY_FREE;      /* double free */
    }
    if (r->pages != pages) {
        /* The size must match what was handed out. A caller that returns a
         * different length than it asked for has lost track of the range,
         * and trusting the wrong length would leave part of it either leaked
         * or, worse, marked free while still in use. */
        vmm_unlock(lf);
        return VMM_ERR_BAD_REQUEST;
    }

    r->in_use = 0;
    g_kmap_live_ranges--;
    g_kmap_free_ranges++;

    vmm_unlock(lf);
    return VMM_OK;
}

void vmm_kmap_stats(VmmKmapStats *out)
{
    if (out == 0) return;

    uint64_t lf = vmm_lock();
    out->cursor        = g_kmap_next;
    out->window_base   = VEX_KMAP_BASE;
    out->window_size   = VEX_KMAP_SIZE;
    out->live_ranges   = g_kmap_live_ranges;
    out->free_ranges   = g_kmap_free_ranges;
    out->reuses        = g_kmap_reuses;
    out->max_ranges    = KMAP_MAX_RANGES;
    vmm_unlock(lf);
}
