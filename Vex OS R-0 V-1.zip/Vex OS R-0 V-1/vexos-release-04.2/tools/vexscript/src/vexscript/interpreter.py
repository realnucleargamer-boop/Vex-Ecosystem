"""VEX-Script 1.2 reference interpreter"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable
from pathlib import Path
from .ast_nodes import *
from .lexer import TokenKind, Lexer
from .parser import Parser
from .errors import VexError, RuntimeError_, SourceLocation


class ReturnSignal(Exception):
    def __init__(self, value: Any):
        self.value = value


class BreakSignal(Exception):
    pass


class ContinueSignal(Exception):
    pass


@dataclass
class Binding:
    value: Any
    mutable: bool


class Environment:
    def __init__(self, parent: Environment | None = None):
        self.parent = parent
        self.vars: dict[str, Binding] = {}

    def define(self, name: str, value: Any, mutable: bool, loc: SourceLocation):
        if name in self.vars:
            raise RuntimeError_(f"redefinition of '{name}'", loc)
        self.vars[name] = Binding(value, mutable)

    def get(self, name: str, loc: SourceLocation) -> Any:
        if name in self.vars:
            return self.vars[name].value
        if self.parent:
            return self.parent.get(name, loc)
        raise RuntimeError_(f"undefined variable '{name}'", loc)

    def set(self, name: str, value: Any, loc: SourceLocation):
        if name in self.vars:
            if not self.vars[name].mutable:
                raise RuntimeError_(f"cannot assign to immutable '{name}'", loc)
            self.vars[name].value = value
            return
        if self.parent:
            self.parent.set(name, value, loc)
            return
        raise RuntimeError_(f"undefined variable '{name}'", loc)

    def is_mutable(self, name: str, loc: SourceLocation) -> bool:
        if name in self.vars:
            return self.vars[name].mutable
        if self.parent:
            return self.parent.is_mutable(name, loc)
        raise RuntimeError_(f"undefined variable '{name}'", loc)


# Runtime representation of a struct instance
@dataclass
class StructInstance:
    type_name: str
    fields: dict[str, Any]

    def __str__(self) -> str:
        parts = [f"{k}: {v}" for k, v in self.fields.items()]
        return f"{self.type_name} {{ {', '.join(parts)} }}"


class Interpreter:
    def __init__(self, module_paths: list[str] | None = None):
        self.functions: dict[str, Function] = {}
        self.structs: dict[str, StructDef] = {}
        self.exported: set[str] = set()  # keys that are pub (module::name or entry names)
        self.loaded_modules: set[str] = set()
        self.imported_modules: set[str] = set()  # successfully imported in this session
        self.loading_stack: list[str] = []  # for cycle detection
        self.module_paths = list(module_paths or [])
        # Phase C: always search package stdlib/
        _stdlib = Path(__file__).resolve().parent.parent.parent / "stdlib"
        if _stdlib.is_dir() and str(_stdlib) not in self.module_paths:
            self.module_paths.append(str(_stdlib))

        self.aliases: dict[str, str] = {}  # selective import: local name -> module::name
        self.enum_values: dict[str, int] = {}  # Enum::Variant -> discriminant
        self.type_aliases: dict[str, str] = {}

        self.builtins: dict[str, Callable] = {
            "println": self._builtin_println,
            "print": self._builtin_print,
            "assert": self._builtin_assert,
            "len_string": self._builtin_len_string,
            "concat": self._builtin_concat,
            "some": self._builtin_some,
            "none": self._builtin_none,
            "is_some": self._builtin_is_some,
            "unwrap": self._builtin_unwrap,
            "ok": self._builtin_ok,
            "err": self._builtin_err,
            "is_ok": self._builtin_is_ok,
            "unwrap_ok": self._builtin_unwrap_ok,
            "abs": self._builtin_abs,
            "min": self._builtin_min,
            "max": self._builtin_max,
            "str_contains": self._builtin_str_contains,
            "str_len": self._builtin_len_string,
            "array_length": self._builtin_array_length,
            "str_length": self._builtin_len_string,
            "str_equals": self._builtin_str_equals,
            "str_starts_with": self._builtin_str_starts_with,
            "str_char_at": self._builtin_str_char_at,
            "str_ends_with": self._builtin_str_ends_with,
            "rng_seed": self._builtin_rng_seed,
            "rng_u64": self._builtin_rng_u64,
            "tensor_create_1": self._builtin_tensor_create_1,
            "tensor_create_2": self._builtin_tensor_create_2,
            "tensor_fill": self._builtin_tensor_fill,
            "tensor_add": self._builtin_tensor_add,
            "tensor_mul": self._builtin_tensor_mul,
            "tensor_dot": self._builtin_tensor_dot,
            "tensor_matmul": self._builtin_tensor_matmul,
            "tensor_get_1": self._builtin_tensor_get_1,
            "tensor_get_2": self._builtin_tensor_get_2,
            "tensor_set_1": self._builtin_tensor_set_1,
            "tensor_set_2": self._builtin_tensor_set_2,
            "tensor_length": self._builtin_tensor_length,
            "neural_relu": self._builtin_neural_relu,
            "neural_linear": self._builtin_neural_linear,
            "neural_linear_bias": self._builtin_neural_linear_bias,
            "neural_forward_2": self._builtin_neural_forward_2,
            "evolve_create": self._builtin_evolve_create,
            "evolve_size": self._builtin_evolve_size,
            "evolve_get": self._builtin_evolve_get,
            "evolve_set": self._builtin_evolve_set,
            "evolve_randomize": self._builtin_evolve_randomize,
            "evolve_mutate": self._builtin_evolve_mutate,
            "evolve_crossover": self._builtin_evolve_crossover,
            "evolve_select_tournament": self._builtin_evolve_select_tournament,
            "evolve_checkpoint_save": self._builtin_evolve_checkpoint_save,
            "evolve_checkpoint_load": self._builtin_evolve_checkpoint_load,
            "evolve_checkpoint_exists": self._builtin_evolve_checkpoint_exists,
            "evolve_best_index": self._builtin_evolve_best_index,
            "evolve_generation": self._builtin_evolve_generation,
            # genome
            "genome_create": self._builtin_genome_create,
            "genome_from_string": self._builtin_genome_from_string,
            "genome_length": self._builtin_genome_length,
            "genome_char_at": self._builtin_genome_char_at,
            "genome_set_char": self._builtin_genome_set_char,
            "genome_slice": self._builtin_genome_slice,
            "genome_copy": self._builtin_genome_copy,
            "genome_compare": self._builtin_genome_compare,
            "genome_append_char": self._builtin_genome_append_char,
            "genome_to_string": self._builtin_genome_to_string,
            "genome_fill": self._builtin_genome_fill,
            "genome_char_code_at": self._builtin_genome_char_code_at,
            "genome_set_char_code": self._builtin_genome_set_char_code,
            "genome_fill_code": self._builtin_genome_fill_code,
            "genome_match": self._builtin_genome_match,
            # streams / fitness / migration
            "stream_create": self._builtin_stream_create,
            "stream_pop": self._builtin_stream_pop,
            "stream_generation": self._builtin_stream_generation,
            "stream_size": self._builtin_stream_size,
            "stream_set_elite_count": self._builtin_stream_set_elite_count,
            "stream_advance": self._builtin_stream_advance,
            "fitness_set": self._builtin_fitness_set,
            "fitness_get": self._builtin_fitness_get,
            "fitness_best_index": self._builtin_fitness_best_index,
            "fitness_worst_index": self._builtin_fitness_worst_index,
            "fitness_average": self._builtin_fitness_average,
            "fitness_sum": self._builtin_fitness_sum,
            "diversity_hamming_avg": self._builtin_diversity_hamming_avg,
            "migrate_copy": self._builtin_migrate_copy,
            "migrate_best": self._builtin_migrate_best,
            "elite_preserve_count": self._builtin_elite_preserve_count,
            "gpu_available": self._builtin_gpu_available,
            "device_set": self._builtin_device_set,
            "device_get_code": self._builtin_device_get_code,
            "workers_set": self._builtin_workers_set,
            "workers_get": self._builtin_workers_get,
            "accel_tensor_zeros_2": self._builtin_accel_tensor_zeros_2,
            "accel_tensor_fill": self._builtin_accel_tensor_fill,
            "accel_matmul": self._builtin_accel_matmul,
            "stream_advance_batch2": self._builtin_stream_advance_batch2,
            "stream_advance_batch4": self._builtin_stream_advance_batch4,
            # VEX AI 1.2: GPU-friendly batched population runtime (gpu_rt.py)
            "gpop_create": self._builtin_gpop_create,
            "gpop_size": self._builtin_gpop_size,
            "gpop_gene_len": self._builtin_gpop_gene_len,
            "gpop_generation": self._builtin_gpop_generation,
            "gpop_fitness_target": self._builtin_gpop_fitness_target,
            "gpop_fitness_structural": self._builtin_gpop_fitness_structural,
            "gpop_reasoning_bonus": self._builtin_gpop_reasoning_bonus,
            "gpop_upper_count_at": self._builtin_gpop_upper_count_at,
            "gpop_advance": self._builtin_gpop_advance,
            "gpop_best_index": self._builtin_gpop_best_index,
            "gpop_best_fitness": self._builtin_gpop_best_fitness,
            "gpop_avg_fitness_milli": self._builtin_gpop_avg_fitness_milli,
            "gpop_best_string": self._builtin_gpop_best_string,
            "gpop_backend_code": self._builtin_gpop_backend_code,
        }
        self.output: list[str] = []
        self._rng_state: int = 0x9E3779B97F4A7C15
        from .hosted import HOSTED_BUILTINS, HOSTED_NAMESPACES, reset_hosted_state
        reset_hosted_state()
        from .evolve_rt import reset_evolve_state
        reset_evolve_state()
        from .genome_rt import reset_genome_state
        reset_genome_state()
        from .accel_rt import reset_accel_state
        reset_accel_state()
        self.builtins.update(HOSTED_BUILTINS)
        self._hosted_namespaces = HOSTED_NAMESPACES


    # ── builtins ──────────────────────────────────────
    def _builtin_println(self, *args):
        text = " ".join(str(a) for a in args)
        self.output.append(text)
        print(text)
        return 0

    def _builtin_print(self, *args):
        text = " ".join(str(a) for a in args)
        print(text, end="")
        return 0

    def _builtin_assert(self, cond):
        if not cond:
            raise RuntimeError_("assertion failed", None)
        return 0

    def _builtin_len_string(self, s):
        return len(str(s))

    def _builtin_concat(self, a, b):
        return str(a) + str(b)

    def _builtin_some(self, v):
        return ("Some", v)

    def _builtin_none(self):
        return ("None", None)

    def _builtin_is_some(self, opt):
        return isinstance(opt, tuple) and opt[0] == "Some"

    def _builtin_unwrap(self, opt):
        if isinstance(opt, tuple) and opt[0] == "Some":
            return opt[1]
        raise RuntimeError_("unwrap on None", None)

    def _builtin_ok(self, v):
        return ("Ok", v)

    def _builtin_err(self, e):
        return ("Err", e)

    def _builtin_is_ok(self, r):
        return isinstance(r, tuple) and r[0] == "Ok"

    def _builtin_unwrap_ok(self, r):
        if isinstance(r, tuple) and r[0] == "Ok":
            return r[1]
        raise RuntimeError_("unwrap_ok on Err", None)

    def _builtin_abs(self, x):
        return abs(x)

    def _builtin_min(self, a, b):
        return a if a < b else b

    def _builtin_max(self, a, b):
        return a if a > b else b

    def _rng_fn(self):
        return self._builtin_rng_u64()

    def _builtin_evolve_checkpoint_save(self, pid, name):
        from .evolve_rt import evolve_checkpoint_save
        return evolve_checkpoint_save(int(pid), str(name))

    def _builtin_evolve_checkpoint_load(self, name):
        from .evolve_rt import evolve_checkpoint_load
        return evolve_checkpoint_load(str(name))

    def _builtin_evolve_checkpoint_exists(self, name):
        from .evolve_rt import evolve_checkpoint_exists
        return evolve_checkpoint_exists(str(name))

    def _builtin_evolve_best_index(self, s0, s1, s2, s3):
        from .evolve_rt import evolve_best_index
        return evolve_best_index([float(s0), float(s1), float(s2), float(s3)])

    def _builtin_evolve_generation(self, pid, elite_index, rate_milli):
        from .evolve_rt import evolve_generation
        return evolve_generation(int(pid), int(elite_index), self._rng_fn, int(rate_milli))

    def _builtin_gpu_available(self):
        from .accel_rt import gpu_available
        return gpu_available()

    def _builtin_device_set(self, code):
        # 0=cpu, 1=cuda/gpu
        from .accel_rt import device_set
        return device_set("cuda" if int(code) == 1 else "cpu")

    def _builtin_device_get_code(self):
        from .accel_rt import device_get
        return 1 if device_get() == "cuda" else 0

    def _builtin_workers_set(self, n):
        from .accel_rt import workers_set
        return workers_set(int(n))

    def _builtin_workers_get(self):
        from .accel_rt import workers_get
        return workers_get()

    def _builtin_accel_tensor_zeros_2(self, d0, d1):
        from .accel_rt import accel_tensor_zeros
        return accel_tensor_zeros("f32", int(d0), int(d1))

    def _builtin_accel_tensor_fill(self, t, value):
        from .accel_rt import accel_tensor_fill
        return accel_tensor_fill(t, float(value))

    def _builtin_accel_matmul(self, a, b):
        from .accel_rt import accel_matmul
        return accel_matmul(a, b)

    def _builtin_stream_advance_batch2(self, s0, s1, rate):
        from .accel_rt import stream_advance_batch
        return stream_advance_batch([int(s0), int(s1)], int(rate), self._rng_fn)[0]

    def _builtin_stream_advance_batch4(self, s0, s1, s2, s3, rate):
        from .accel_rt import stream_advance_batch
        gens = stream_advance_batch([int(s0), int(s1), int(s2), int(s3)], int(rate), self._rng_fn)
        return gens[0]

    # ---- VEX AI 1.2: GPU-friendly batched population runtime ----------
    def _builtin_gpop_create(self, pop_size, gene_len, seed):
        from . import gpu_rt
        return gpu_rt.pop_create(int(pop_size), int(gene_len), int(seed))

    def _builtin_gpop_size(self, handle):
        from . import gpu_rt
        return gpu_rt.pop_size_of(int(handle))

    def _builtin_gpop_gene_len(self, handle):
        from . import gpu_rt
        return gpu_rt.pop_gene_len(int(handle))

    def _builtin_gpop_generation(self, handle):
        from . import gpu_rt
        return gpu_rt.pop_generation(int(handle))

    def _builtin_gpop_fitness_target(self, handle, target):
        from . import gpu_rt
        return gpu_rt.pop_fitness_target_batch(int(handle), str(target))

    def _builtin_gpop_fitness_structural(self, handle):
        from . import gpu_rt
        return gpu_rt.pop_fitness_structural_batch(int(handle))

    def _builtin_gpop_reasoning_bonus(self, handle, reference_upper_count):
        from . import gpu_rt
        return gpu_rt.pop_reasoning_bonus_batch(int(handle), int(reference_upper_count))

    def _builtin_gpop_upper_count_at(self, handle, index):
        from . import gpu_rt
        return gpu_rt.pop_upper_count_at(int(handle), int(index))

    def _builtin_gpop_advance(self, handle, elite_count, mutate_rate_milli):
        from . import gpu_rt
        if not hasattr(self, "_gpop_seed_step"):
            self._gpop_seed_step = 0
        self._gpop_seed_step += 1
        return gpu_rt.pop_advance_batch(int(handle), int(elite_count), int(mutate_rate_milli), self._gpop_seed_step)

    def _builtin_gpop_best_index(self, handle):
        from . import gpu_rt
        return gpu_rt.pop_best_index(int(handle))

    def _builtin_gpop_best_fitness(self, handle):
        from . import gpu_rt
        return gpu_rt.pop_best_fitness(int(handle))

    def _builtin_gpop_avg_fitness_milli(self, handle):
        from . import gpu_rt
        return gpu_rt.pop_avg_fitness_milli(int(handle))

    def _builtin_gpop_best_string(self, handle):
        from . import gpu_rt
        return gpu_rt.pop_string_at(int(handle), gpu_rt.pop_best_index(int(handle)))

    def _builtin_gpop_backend_code(self):
        from . import gpu_rt
        name = gpu_rt.backend_name()
        return {"cuda": 2, "torch-cpu": 1, "numpy-cpu": 0}.get(name, -1)

    def _builtin_genome_match(self, gid, target):
        from .genome_rt import genome_match
        return genome_match(int(gid), str(target))

    def _builtin_genome_char_code_at(self, gid, index):
        from .genome_rt import genome_char_code_at
        return genome_char_code_at(int(gid), int(index))

    def _builtin_genome_set_char_code(self, gid, index, code):
        from .genome_rt import genome_set_char_code
        return genome_set_char_code(int(gid), int(index), int(code))

    def _builtin_genome_fill_code(self, gid, code, length):
        from .genome_rt import genome_fill_code
        return genome_fill_code(int(gid), int(code), int(length))

    def _builtin_genome_create(self, capacity):
        from .genome_rt import genome_create
        return genome_create(int(capacity))

    def _builtin_genome_from_string(self, s):
        from .genome_rt import genome_from_string
        return genome_from_string(str(s))

    def _builtin_genome_length(self, gid):
        from .genome_rt import genome_length
        return genome_length(int(gid))

    def _builtin_genome_char_at(self, gid, index):
        from .genome_rt import genome_char_at
        return genome_char_at(int(gid), int(index))

    def _builtin_genome_set_char(self, gid, index, ch):
        from .genome_rt import genome_set_char
        return genome_set_char(int(gid), int(index), str(ch))

    def _builtin_genome_slice(self, gid, start, end):
        from .genome_rt import genome_slice
        return genome_slice(int(gid), int(start), int(end))

    def _builtin_genome_copy(self, gid):
        from .genome_rt import genome_copy
        return genome_copy(int(gid))

    def _builtin_genome_compare(self, a, b):
        from .genome_rt import genome_compare
        return genome_compare(int(a), int(b))

    def _builtin_genome_append_char(self, gid, ch):
        from .genome_rt import genome_append_char
        return genome_append_char(int(gid), str(ch))

    def _builtin_genome_to_string(self, gid):
        from .genome_rt import genome_to_string
        return genome_to_string(int(gid))

    def _builtin_genome_fill(self, gid, ch, length):
        from .genome_rt import genome_fill
        return genome_fill(int(gid), str(ch), int(length))

    def _builtin_stream_create(self, n, dim, elite_count):
        from .evolve_rt import stream_create
        return stream_create(int(n), int(dim), int(elite_count))

    def _builtin_stream_pop(self, sid):
        from .evolve_rt import stream_pop
        return stream_pop(int(sid))

    def _builtin_stream_generation(self, sid):
        from .evolve_rt import stream_generation
        return stream_generation(int(sid))

    def _builtin_stream_size(self, sid):
        from .evolve_rt import stream_size
        return stream_size(int(sid))

    def _builtin_stream_set_elite_count(self, sid, n):
        from .evolve_rt import stream_set_elite_count
        return stream_set_elite_count(int(sid), int(n))

    def _builtin_stream_advance(self, sid, rate):
        from .evolve_rt import stream_advance
        return stream_advance(int(sid), int(rate), self._rng_fn)

    def _builtin_fitness_set(self, sid, index, score):
        from .evolve_rt import fitness_set
        return fitness_set(int(sid), int(index), int(score))

    def _builtin_fitness_get(self, sid, index):
        from .evolve_rt import fitness_get
        return fitness_get(int(sid), int(index))

    def _builtin_fitness_best_index(self, sid):
        from .evolve_rt import fitness_best_index
        return fitness_best_index(int(sid))

    def _builtin_fitness_worst_index(self, sid):
        from .evolve_rt import fitness_worst_index
        return fitness_worst_index(int(sid))

    def _builtin_fitness_average(self, sid):
        from .evolve_rt import fitness_average
        return fitness_average(int(sid))

    def _builtin_fitness_sum(self, sid):
        from .evolve_rt import fitness_sum
        return fitness_sum(int(sid))

    def _builtin_diversity_hamming_avg(self, sid):
        from .evolve_rt import diversity_hamming_avg
        return diversity_hamming_avg(int(sid))

    def _builtin_migrate_copy(self, src, si, dst, di):
        from .evolve_rt import migrate_copy
        return migrate_copy(int(src), int(si), int(dst), int(di))

    def _builtin_migrate_best(self, src, dst, di):
        from .evolve_rt import migrate_best
        return migrate_best(int(src), int(dst), int(di))

    def _builtin_elite_preserve_count(self, sid):
        from .evolve_rt import elite_preserve_count
        return elite_preserve_count(int(sid))

    def _builtin_evolve_create(self, n, dim):
        from .evolve_rt import evolve_create
        return evolve_create(int(n), int(dim))

    def _builtin_evolve_size(self, pid):
        from .evolve_rt import evolve_size
        return evolve_size(int(pid))

    def _builtin_evolve_get(self, pid, index):
        from .evolve_rt import evolve_get
        return evolve_get(int(pid), int(index))

    def _builtin_evolve_set(self, pid, index, t):
        from .evolve_rt import evolve_set
        return evolve_set(int(pid), int(index), t)

    def _builtin_evolve_randomize(self, pid):
        from .evolve_rt import evolve_randomize
        return evolve_randomize(int(pid), self._rng_fn)

    def _builtin_evolve_mutate(self, t, rate_milli):
        from .evolve_rt import evolve_mutate
        return evolve_mutate(t, self._rng_fn, int(rate_milli))

    def _builtin_evolve_crossover(self, a, b):
        from .evolve_rt import evolve_crossover
        return evolve_crossover(a, b, self._rng_fn)

    def _builtin_evolve_select_tournament(self, s0, s1, s2, s3, k):
        # fixed-arity helper for up to 4 scores (3.0-D minimal)
        from .evolve_rt import evolve_select_tournament
        scores = [float(s0), float(s1), float(s2), float(s3)]
        return evolve_select_tournament(scores, int(k), self._rng_fn)

    def _builtin_neural_relu(self, t):
        from .tensor_rt import neural_relu
        return neural_relu(t)

    def _builtin_neural_linear(self, x, w):
        from .tensor_rt import neural_linear
        return neural_linear(x, w, None)

    def _builtin_neural_linear_bias(self, x, w, b):
        from .tensor_rt import neural_linear
        return neural_linear(x, w, b)

    def _builtin_neural_forward_2(self, x, w1, b1, w2, b2):
        from .tensor_rt import neural_forward_2layer
        return neural_forward_2layer(x, w1, b1, w2, b2)

    def _builtin_tensor_create_1(self, d0):
        from .tensor_rt import tensor_create
        return tensor_create("f32", int(d0))

    def _builtin_tensor_create_2(self, d0, d1):
        from .tensor_rt import tensor_create
        return tensor_create("f32", int(d0), int(d1))

    def _builtin_tensor_fill(self, t, value):
        from .tensor_rt import tensor_fill, Tensor
        if not isinstance(t, Tensor):
            raise RuntimeError_("tensor_fill expects tensor")
        return tensor_fill(t, float(value))

    def _builtin_tensor_add(self, a, b):
        from .tensor_rt import tensor_add
        return tensor_add(a, b)

    def _builtin_tensor_mul(self, a, b):
        from .tensor_rt import tensor_mul
        return tensor_mul(a, b)

    def _builtin_tensor_dot(self, a, b):
        from .tensor_rt import tensor_dot
        # return as scaled int milli for println? keep float; println will str()
        return tensor_dot(a, b)

    def _builtin_tensor_matmul(self, a, b):
        from .tensor_rt import tensor_matmul
        return tensor_matmul(a, b)

    def _builtin_tensor_get_1(self, t, i0):
        from .tensor_rt import tensor_get
        return tensor_get(t, int(i0))

    def _builtin_tensor_get_2(self, t, i0, i1):
        from .tensor_rt import tensor_get
        return tensor_get(t, int(i0), int(i1))

    def _builtin_tensor_set_1(self, t, value, i0):
        from .tensor_rt import tensor_set
        return tensor_set(t, float(value), int(i0))

    def _builtin_tensor_set_2(self, t, value, i0, i1):
        from .tensor_rt import tensor_set
        return tensor_set(t, float(value), int(i0), int(i1))

    def _builtin_tensor_length(self, t):
        from .tensor_rt import tensor_length
        return tensor_length(t)

    def _builtin_rng_seed(self, seed):
        self._rng_state = int(seed) & 0xFFFFFFFFFFFFFFFF
        if self._rng_state == 0:
            self._rng_state = 0x9E3779B97F4A7C15
        return 0

    def _builtin_rng_u64(self):
        # splitmix64-ish
        self._rng_state = (self._rng_state + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
        z = self._rng_state
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9 & 0xFFFFFFFFFFFFFFFF
        z = (z ^ (z >> 27)) * 0x94D049BB133111EB & 0xFFFFFFFFFFFFFFFF
        return z ^ (z >> 31)

    def _builtin_array_length(self, a):
        return len(a) if isinstance(a, list) else 0

    def _builtin_str_equals(self, a, b):
        return str(a) == str(b)

    def _builtin_str_char_at(self, s, i):
        s = str(s); i = int(i)
        return ord(s[i]) if 0 <= i < len(s) else -1

    def _builtin_str_starts_with(self, s, prefix):
        return str(s).startswith(str(prefix))

    def _builtin_str_ends_with(self, s, suffix):
        return str(s).endswith(str(suffix))

    def _builtin_str_contains(self, s, sub):
        return str(sub) in str(s)

    # ── public API ────────────────────────────────────
    def load(self, source: str, filename: str = "<input>"):
        tokens = Lexer(source, filename).tokenize()
        program = Parser(tokens, filename).parse()
        self._register_program(program, filename)
        # Resolve uses
        base = Path(filename).parent if filename != "<input>" else Path(".")
        for use in program.uses:
            self._load_module(use.module, base, use.loc, getattr(use, "items", None))
        # Static type check (1.3)
        from .typecheck import TypeChecker
        tc = TypeChecker()
        # Seed with already-registered structs/functions from modules
        for name, st in self.structs.items():
            if name not in tc.structs:
                fields = {f.name: (f.type.name if f.type else "unknown") for f in st.fields}
                from .typecheck import StructSig
                tc.structs[name] = StructSig(fields=fields)
        for name, fn in self.functions.items():
            if name not in tc.functions:
                from .typecheck import FnSig
                if fn is None:
                    from .hosted import HOSTED_SIGNATURES
                    if name in HOSTED_SIGNATURES:
                        params, ret = HOSTED_SIGNATURES[name]
                        tc.functions[name] = FnSig(params=params, ret=ret)
                    continue
                params = [p.type.name if p.type else "unknown" for p in fn.params]
                ret = fn.return_type.name if fn.return_type else "unknown"
                tc.functions[name] = FnSig(params=params, ret=ret)
        from .hosted import HOSTED_SIGNATURES
        from .typecheck import FnSig as _FnSig
        for hname, (params, ret) in HOSTED_SIGNATURES.items():
            if hname not in tc.functions:
                tc.functions[hname] = _FnSig(params=params, ret=ret)
        try:
            tc.check_program(program)
            self._check_private_calls(program)
        except VexError as e:
            if e.source is None:
                e.source = source
            raise
        return program

    def _check_private_calls(self, program):
        """Reject cross-module access to non-pub symbols (Phase A/C)."""
        from .ast_nodes import Function, Call, ExprStmt, Return, If, While, For, Loop, Block, Let

        def walk_expr(e):
            if e is None:
                return
            if isinstance(e, Call):
                name = e.name
                if "::" in name and name not in self.exported:
                    if name in self.functions:
                        raise RuntimeError_(
                            f"symbol '{name}' is private", e.loc, error_code="E0004"
                        )
                for a in e.args:
                    walk_expr(a)
            for attr in ("left", "right", "operand", "expr", "value", "obj", "cond", "init"):
                if hasattr(e, attr):
                    walk_expr(getattr(e, attr))
            if hasattr(e, "args"):
                for a in getattr(e, "args") or []:
                    walk_expr(a)
            if hasattr(e, "fields"):
                for _, fe in e.fields:
                    walk_expr(fe)

        def walk_stmt(s):
            if s is None:
                return
            if isinstance(s, (ExprStmt, Return, Let)):
                walk_expr(getattr(s, "expr", None) or getattr(s, "value", None) or getattr(s, "init", None))
            if isinstance(s, If):
                walk_expr(s.cond)
                for x in s.then_body:
                    walk_stmt(x)
                for x in s.else_body or []:
                    walk_stmt(x)
            if isinstance(s, While):
                walk_expr(s.cond)
                for x in s.body:
                    walk_stmt(x)
            if isinstance(s, For):
                walk_stmt(s.init)
                walk_expr(s.cond)
                walk_expr(s.step)
                for x in s.body:
                    walk_stmt(x)
            if isinstance(s, (Loop, Block)):
                body = getattr(s, "body", None) or getattr(s, "statements", [])
                for x in body or []:
                    walk_stmt(x)

        for fn in program.functions:
            for st in fn.body:
                walk_stmt(st)

    def _register_program(self, program: Program, filename: str, module_name: str | None = None):
        """Register structs/functions. If module_name is set, functions are
        stored as 'module_name::fn' for namespace isolation (1.4).
        Structs remain global by name (shared type namespace) with redefinition checks.
        """
        for st in program.structs:
            key = st.name
            if key in self.structs:
                raise RuntimeError_(f"redefinition of struct '{key}'", st.loc)
            self.structs[key] = st
        for ta in getattr(program, "type_aliases", []) or []:
            self.type_aliases[ta.name] = ta.target.name
        for en in getattr(program, "enums", []) or []:
            for i, v in enumerate(en.variants):
                key = f"{en.name}::{v}"
                if key in self.enum_values:
                    raise RuntimeError_(f"redefinition of '{key}'", en.loc, error_code="E0007")
                self.enum_values[key] = i
        for fn in program.functions:
            key = f"{module_name}::{fn.name}" if module_name else fn.name
            if key in self.functions:
                raise RuntimeError_(
                    f"redefinition of function '{key}'", fn.loc, error_code="E0007"
                )
            bare = fn.name
            if not module_name and bare in self.builtins:
                raise RuntimeError_(f"'{bare}' is a reserved builtin", fn.loc, error_code="E0007")
            self.functions[key] = fn
            fn.owner_module = module_name
            # Entry file: all top-level visible internally.
            # Module: only pub is externally accessible.
            if module_name is None or getattr(fn, "exported", False):
                self.exported.add(key)

    def _load_module(self, name: str, base: Path, loc: SourceLocation, items: list | None = None):
        if name in self.imported_modules and name in self.loaded_modules:
            raise RuntimeError_(
                f"duplicate import of module '{name}'", loc, error_code="E0005"
            )
        if name in self.loading_stack:
            cycle = " -> ".join(self.loading_stack + [name])
            raise RuntimeError_(
                f"import cycle detected: {cycle}", loc, error_code="E0002"
            )

        # Hosted vex::* namespaces (Phase D) — virtual modules
        if name in getattr(self, "_hosted_namespaces", {}):
            if name not in self.loaded_modules:
                for short in self._hosted_namespaces[name]:
                    key = f"{name}::{short}"
                    # Marker so privacy/export checks pass; call goes to builtins
                    self.functions[key] = None  # type: ignore
                    self.exported.add(key)
                self.loaded_modules.add(name)
            self.imported_modules.add(name)
            if items is not None:
                for item in items:
                    key = f"{name}::{item}"
                    if key not in self.exported:
                        raise RuntimeError_(
                            f"module '{name}' has no symbol '{item}'", loc, error_code="E0003"
                        )
                    self.aliases[item] = key
            return

        # Search: file dir, module_paths, std/, vex/
        candidates = [base / f"{name}.vex"]
        # nested path: vex::info → vex/info.vex
        if "::" in name:
            rel = name.replace("::", "/") + ".vex"
            candidates.append(base / rel)
            for mp in self.module_paths:
                candidates.append(Path(mp) / rel)
        for mp in self.module_paths:
            candidates.append(Path(mp) / f"{name}.vex")
        candidates.append(base / "std" / f"{name}.vex")
        candidates.append(base / "vex" / f"{name}.vex")

        path = None
        for c in candidates:
            if c.exists():
                path = c
                break
        if path is None:
            raise RuntimeError_(
                f"module not found: '{name}'", loc, error_code="E0001"
            )

        if name not in self.loaded_modules:
            self.loading_stack.append(name)
            source = path.read_text()
            tokens = Lexer(source, str(path)).tokenize()
            program = Parser(tokens, str(path)).parse()
            self._register_program(program, str(path), module_name=name)
            self.loaded_modules.add(name)

            mod_base = path.parent
            for use in program.uses:
                self._load_module(use.module, mod_base, use.loc, use.items)

            self.loading_stack.pop()

        self.imported_modules.add(name)

        # Selective import: bind aliases only for public symbols
        if items is not None:
            for item in items:
                key = f"{name}::{item}"
                if key not in self.functions:
                    raise RuntimeError_(
                        f"module '{name}' has no symbol '{item}'", loc, error_code="E0003"
                    )
                if key not in self.exported:
                    raise RuntimeError_(
                        f"symbol '{name}::{item}' is private", loc, error_code="E0004"
                    )
                self.aliases[item] = key

    def run_main(self) -> int:
        if "main" not in self.functions:
            raise RuntimeError_("no main function", None)
        env = Environment()
        try:
            result = self._call(self.functions["main"], [], env, self.functions["main"].loc)
            return int(result) if result is not None else 0
        except ReturnSignal as rs:
            return int(rs.value) if rs.value is not None else 0

    def _call(self, fn: Function, args: list[Any], caller_env: Environment, loc: SourceLocation) -> Any:
        if len(args) != len(fn.params):
            raise RuntimeError_(
                f"function '{fn.name}' expects {len(fn.params)} args, got {len(args)}", loc
            )
        env = Environment()
        for p, a in zip(fn.params, args):
            env.define(p.name, a, mutable=False, loc=p.loc)
        if not hasattr(self, "_module_stack"):
            self._module_stack = []
        self._module_stack.append(getattr(fn, "owner_module", None))
        try:
            for stmt in fn.body:
                self._exec_stmt(stmt, env)
            return 0
        except ReturnSignal as rs:
            return rs.value
        finally:
            self._module_stack.pop()

    def _exec_stmt(self, stmt: Stmt, env: Environment):
        if isinstance(stmt, Let):
            val = self._eval(stmt.init, env) if stmt.init else 0
            env.define(stmt.name, val, stmt.mutable, stmt.loc)

        elif isinstance(stmt, Return):
            val = self._eval(stmt.value, env) if stmt.value else 0
            raise ReturnSignal(val)

        elif isinstance(stmt, ExprStmt):
            self._eval(stmt.expr, env)

        elif isinstance(stmt, If):
            if self._eval(stmt.cond, env):
                for s in stmt.then_body:
                    self._exec_stmt(s, env)
            elif stmt.else_body:
                for s in stmt.else_body:
                    self._exec_stmt(s, env)

        elif isinstance(stmt, Match):
            val = self._eval(stmt.expr, env)
            matched = False
            for arm in stmt.arms:
                if arm.pattern == "_":
                    for s in arm.body:
                        self._exec_stmt(s, env)
                    matched = True
                    break
                if arm.pattern.isdigit() or (arm.pattern.startswith("-") and arm.pattern[1:].isdigit()):
                    if int(val) == int(arm.pattern):
                        for s in arm.body:
                            self._exec_stmt(s, env)
                        matched = True
                        break
                elif arm.pattern in self.enum_values:
                    if int(val) == self.enum_values[arm.pattern]:
                        for s in arm.body:
                            self._exec_stmt(s, env)
                        matched = True
                        break
                else:
                    # try as enum if val is int and pattern maps
                    if arm.pattern in self.enum_values and int(val) == self.enum_values[arm.pattern]:
                        for s in arm.body:
                            self._exec_stmt(s, env)
                        matched = True
                        break
            if not matched:
                raise RuntimeError_("match: no arm matched", stmt.loc)

        elif isinstance(stmt, While):
            while self._eval(stmt.cond, env):
                try:
                    for s in stmt.body:
                        self._exec_stmt(s, env)
                except BreakSignal:
                    break
                except ContinueSignal:
                    continue

        elif isinstance(stmt, For):
            if stmt.init:
                self._exec_stmt(stmt.init, env)
            while True:
                if stmt.cond is not None and not self._eval(stmt.cond, env):
                    break
                try:
                    for s in stmt.body:
                        self._exec_stmt(s, env)
                except BreakSignal:
                    break
                except ContinueSignal:
                    pass
                if stmt.step:
                    self._eval(stmt.step, env)

        elif isinstance(stmt, Loop):
            while True:
                try:
                    for s in stmt.body:
                        self._exec_stmt(s, env)
                except BreakSignal:
                    break
                except ContinueSignal:
                    continue

        elif isinstance(stmt, Break):
            raise BreakSignal()

        elif isinstance(stmt, Continue):
            raise ContinueSignal()

        elif isinstance(stmt, Block):
            child = Environment(env)
            for s in stmt.body:
                self._exec_stmt(s, child)

        else:
            raise RuntimeError_(f"unhandled statement {type(stmt).__name__}", stmt.loc)

    def _eval(self, expr: Expr, env: Environment) -> Any:
        if isinstance(expr, IntLit):
            return expr.value
        if isinstance(expr, BoolLit):
            return expr.value
        if isinstance(expr, StringLit):
            return expr.value
        if isinstance(expr, Name):
            if expr.name in self.enum_values:
                return self.enum_values[expr.name]
            # function reference foundation (1.5): bare function name yields callable key
            if expr.name in self.functions or expr.name in self.builtins:
                try:
                    return env.get(expr.name, expr.loc)
                except RuntimeError_:
                    return expr.name  # function value = its qualified/bare name
            return env.get(expr.name, expr.loc)

        if isinstance(expr, Assign):
            val = self._eval(expr.value, env)
            env.set(expr.name, val, expr.loc)
            return val

        if isinstance(expr, FieldAccess):
            obj = self._eval(expr.obj, env)
            if not isinstance(obj, StructInstance):
                raise RuntimeError_(f"field access on non-struct value", expr.loc)
            if expr.field not in obj.fields:
                raise RuntimeError_(f"struct '{obj.type_name}' has no field '{expr.field}'", expr.loc)
            return obj.fields[expr.field]

        if isinstance(expr, FieldAssign):
            obj = self._eval(expr.obj, env)
            if not isinstance(obj, StructInstance):
                raise RuntimeError_(f"field assignment on non-struct value", expr.loc)
            if expr.field not in obj.fields:
                raise RuntimeError_(f"struct '{obj.type_name}' has no field '{expr.field}'", expr.loc)
            # Mutability: walk to root binding for chained assigns (e.g. r.origin.x = ...)
            root = expr.obj
            while isinstance(root, FieldAccess):
                root = root.obj
            if isinstance(root, Name):
                if not env.is_mutable(root.name, expr.loc):
                    raise RuntimeError_(
                        f"cannot mutate field of immutable binding '{root.name}'", expr.loc
                    )
            val = self._eval(expr.value, env)
            obj.fields[expr.field] = val
            return val

        if isinstance(expr, StructLit):
            if expr.name not in self.structs:
                raise RuntimeError_(f"undefined struct type '{expr.name}'", expr.loc)
            st = self.structs[expr.name]
            expected = {f.name for f in st.fields}
            provided = {}
            for fname, fexpr in expr.fields:
                if fname not in expected:
                    raise RuntimeError_(f"struct '{expr.name}' has no field '{fname}'", expr.loc)
                provided[fname] = self._eval(fexpr, env)
            missing = expected - set(provided.keys())
            if missing:
                raise RuntimeError_(
                    f"struct '{expr.name}' missing fields: {', '.join(sorted(missing))}", expr.loc
                )
            return StructInstance(type_name=expr.name, fields=provided)

        if isinstance(expr, ArrayLit):
            return [self._eval(e, env) for e in expr.elements]

        if isinstance(expr, Index):
            obj = self._eval(expr.obj, env)
            idx = int(self._eval(expr.index, env))
            if not isinstance(obj, list):
                raise RuntimeError_("index on non-array", expr.loc)
            if idx < 0 or idx >= len(obj):
                raise RuntimeError_(f"array index {idx} out of bounds (len={len(obj)})", expr.loc)
            return obj[idx]

        if isinstance(expr, IndexAssign):
            obj = self._eval(expr.obj, env)
            if not isinstance(obj, list):
                raise RuntimeError_("index assignment on non-array", expr.loc)
            idx = int(self._eval(expr.index, env))
            if idx < 0 or idx >= len(obj):
                raise RuntimeError_(f"array index {idx} out of bounds (len={len(obj)})", expr.loc)
            root = expr.obj
            while isinstance(root, FieldAccess):
                root = root.obj
            if isinstance(root, Name):
                if not env.is_mutable(root.name, expr.loc):
                    raise RuntimeError_(
                        f"cannot mutate element of immutable binding '{root.name}'", expr.loc
                    )
            val = self._eval(expr.value, env)
            obj[idx] = val
            return val

        if isinstance(expr, Unary):
            v = self._eval(expr.operand, env)
            if expr.op == TokenKind.MINUS:
                return -v
            if expr.op == TokenKind.BANG:
                return not bool(v)
            raise RuntimeError_(f"unsupported unary {expr.op.name}", expr.loc)

        if isinstance(expr, Binary):
            op = expr.op
            # short-circuit logical
            if op == TokenKind.ANDAND:
                l = self._eval(expr.left, env)
                if not l:
                    return False
                return bool(self._eval(expr.right, env))
            if op == TokenKind.OROR:
                l = self._eval(expr.left, env)
                if l:
                    return True
                return bool(self._eval(expr.right, env))
            l = self._eval(expr.left, env)
            r = self._eval(expr.right, env)
            if op == TokenKind.PLUS:
                if isinstance(l, str) or isinstance(r, str):
                    return str(l) + str(r)
                return l + r
            if op == TokenKind.MINUS: return l - r
            if op == TokenKind.STAR: return l * r
            if op == TokenKind.SLASH: return l // r if isinstance(l, int) else l / r
            if op == TokenKind.PERCENT: return l % r
            if op == TokenKind.EQ: return l == r
            if op == TokenKind.NE: return l != r
            if op == TokenKind.LT: return l < r
            if op == TokenKind.LE: return l <= r
            if op == TokenKind.GT: return l > r
            if op == TokenKind.GE: return l >= r
            raise RuntimeError_(f"unsupported binary {op.name}", expr.loc)

        if isinstance(expr, Cast):
            val = self._eval(expr.expr, env)
            target = expr.target.name
            if target == "i64":
                return int(val)
            if target == "i32":
                iv = int(val)
                if iv < -2147483648 or iv > 2147483647:
                    raise RuntimeError_(
                        f"cast to i32 out of range: {iv}", expr.loc
                    )
                # keep as Python int; type system tracks width
                return iv
            raise RuntimeError_(f"unsupported cast to '{target}'", expr.loc)

        if isinstance(expr, Call):
            args = [self._eval(a, env) for a in expr.args]
            # callable value: Name bound to function object
            if isinstance(expr, Call) and expr.name not in self.builtins and expr.name not in self.functions:
                # try resolve as variable holding function name string
                try:
                    fval = env.get(expr.name, expr.loc)
                    if isinstance(fval, str) and fval in self.functions:
                        return self._call(self.functions[fval], args, env, expr.loc)
                    if isinstance(fval, str) and fval in self.builtins:
                        return self.builtins[fval](*args)
                except RuntimeError_:
                    pass
            if expr.name in self.builtins:
                return self.builtins[expr.name](*args)
            # VEX AI 1.0 language wave (Bug 2 fix): same-module unqualified
            # call. If a bare name isn't a builtin/global function/alias,
            # and we're currently executing inside module M, try "M::name"
            # before giving up. Already-qualified calls are untouched.
            if "::" not in expr.name:
                cur_module = self._module_stack[-1] if getattr(self, "_module_stack", None) else None
                if cur_module:
                    qualified = f"{cur_module}::{expr.name}"
                    if qualified in self.functions:
                        fn2 = self.functions[qualified]
                        if fn2 is not None:
                            return self._call(fn2, args, env, expr.loc)
            # selective import alias
            fname = self.aliases.get(expr.name, expr.name)
            if fname in self.builtins:
                return self.builtins[fname](*args)
            if fname in self.functions:
                if "::" in fname and fname not in self.exported:
                    raise RuntimeError_(
                        f"symbol '{fname}' is private", expr.loc, error_code="E0004"
                    )
                fn = self.functions[fname]
                if fn is None:
                    if fname in self.builtins:
                        return self.builtins[fname](*args)
                    raise RuntimeError_(f"undefined function '{fname}'", expr.loc, error_code="E0003")
                return self._call(fn, args, env, expr.loc)
            raise RuntimeError_(
                f"undefined function '{expr.name}'", expr.loc, error_code="E0003"
            )

        raise RuntimeError_(f"unhandled expr {type(expr).__name__}", expr.loc)
