# VexScript 3.2 — VEX AI 1.0 Readiness Expansion

**Does not implement VEX AI 1.0.**

## Before → After

| Capability | Before (3.1) | After (3.2) |
|------------|--------------|-------------|
| Char-level genome ops | No | `genome_*` mutable buffers |
| Batch fitness | 4-wide tournament only | Per-index `fitness_set/get`, best/worst/avg/sum |
| Streams | No | `stream_create/advance/...` (N not hardcoded) |
| Migration | No | `migrate_copy`, `migrate_best` |
| Diversity | No | `diversity_hamming_avg` |
| Elite count | Partial | `stream_set_elite_count`, preserved in `stream_advance` |
| RNG | `rng_seed` / `rng_u64` | Unchanged, still deterministic |

## Native vs hosted

| Layer | Status |
|-------|--------|
| Genome / stream / fitness / migration APIs | **Hosted** (`genome_rt`, `evolve_rt`) callable from VexScript |
| IR first-class opcodes for these | **Not yet** — still `call @…` into hosted runtime |
| VEX-C / x86-64 lowering | **Not yet** for genome/stream |
| Python as language runtime | Hosted interpreter still Python; **not** a Vex OS native target |

Honest limitation: production VEX AI 1.0 still needs IR/native kernels before dropping the hosted path.

## Memory / ownership

- Genome and population handles are integer IDs.
- `reset_*_state()` on each program load clears tables (no GC).
- Capacity on `genome_create(cap)` caps length; 0 = unbounded within process limits.
- Stream owns one population; migrate **copies** tensors (no shared alias).

## Remaining blockers for VEX AI 1.0

1. IR + native lowering of genome/stream/fitness
2. Text-genome fitness against targets at scale
3. Application-level 12-stream policy (not language-level)
4. Optional float fitness (currently integer scores)

## Tests

`scripts/test_readiness_expansion.py`
