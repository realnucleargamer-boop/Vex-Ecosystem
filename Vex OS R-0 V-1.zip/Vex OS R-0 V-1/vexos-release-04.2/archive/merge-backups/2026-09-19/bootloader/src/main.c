/*
 * Vex OS - bootloader/src/main.c
 *
 * UEFI bootloader skeleton (BOOT-01 milestone).
 *
 * Responsibilities, per the approved architecture:
 *   1. Start from UEFI                       -> efi_main() is the entry
 *   2. Obtain the EFI memory map              -> get_memory_map()
 *   3. Locate/load the kernel                 -> load_kernel()
 *   4. Obtain framebuffer information          -> init_graphics()
 *   5. Obtain the ACPI RSDP                    -> find_rsdp()
 *   6. Collect kernel physical location/size   -> load_kernel()
 *   7. Construct BootInfo                      -> build_bootinfo()
 *   8. Transfer control to kernel entry point  -> jump_to_kernel()
 *
 * No fixed-RAM-size assumptions. No hardcoded addresses beyond what
 * the frozen architecture specifies (kernel_virtual_base). Built with
 * gnu-efi against freestanding conventions - no libc.
 */

#include <efi.h>
#include <efilib.h>
#include "bootinfo.h"
#include "boot_layout.h"

/* Kernel is expected as a flat ELF64 image named \\KERNEL.ELF at the
 * root of the ESP for BOOT-01. A real loader will grow into parsing
 * program headers; for the first milestone we load a single flat
 * segment. This is a DRAFT loading strategy, not architecturally
 * frozen beyond "the bootloader loads a kernel image and records its
 * physical base/size in BootInfo." */
#define KERNEL_PATH L"\\KERNEL.ELF"

/* Kernel entry signature - System V AMD64: first arg in RDI. */
typedef void (*KernelEntry)(BootInfo *info);

/* ---------------------------------------------------------------- */
/* Memory map                                                        */
/* ---------------------------------------------------------------- */

static EFI_STATUS get_memory_map(EFI_MEMORY_DESCRIPTOR **map_out,
                                  UINTN *map_size_out,
                                  UINTN *map_key_out,
                                  UINTN *desc_size_out,
                                  UINT32 *desc_version_out)
{
    EFI_STATUS status;
    UINTN map_size = 0;
    EFI_MEMORY_DESCRIPTOR *map = NULL;

    /* First call deliberately fails with EFI_BUFFER_TOO_SMALL to
     * learn the required size. */
    status = uefi_call_wrapper(BS->GetMemoryMap, 5, &map_size, map,
                                map_key_out, desc_size_out, desc_version_out);
    if (status != EFI_BUFFER_TOO_SMALL) {
        Print(L"[boot] GetMemoryMap size probe failed: %r\n", status);
        return status;
    }

    /* Pad - allocating the buffer itself changes the memory map. */
    map_size += 2 * (*desc_size_out);

    status = uefi_call_wrapper(BS->AllocatePool, 3, EfiLoaderData,
                                map_size, (void **)&map);
    if (EFI_ERROR(status)) {
        Print(L"[boot] AllocatePool for memory map failed: %r\n", status);
        return status;
    }

    status = uefi_call_wrapper(BS->GetMemoryMap, 5, &map_size, map,
                                map_key_out, desc_size_out, desc_version_out);
    if (EFI_ERROR(status)) {
        Print(L"[boot] GetMemoryMap failed: %r\n", status);
        uefi_call_wrapper(BS->FreePool, 1, map);
        return status;
    }

    *map_out = map;
    *map_size_out = map_size;
    return EFI_SUCCESS;
}

/* ---------------------------------------------------------------- */
/* Graphics (UEFI GOP)                                                */
/* ---------------------------------------------------------------- */

static EFI_STATUS init_graphics(BootInfo *info)
{
    EFI_STATUS status;
    EFI_GRAPHICS_OUTPUT_PROTOCOL *gop;

    status = uefi_call_wrapper(BS->LocateProtocol, 3,
                                &GraphicsOutputProtocol, NULL, (void **)&gop);
    if (EFI_ERROR(status)) {
        Print(L"[boot] GOP not available: %r (no framebuffer)\n", status);
        info->framebuffer_addr = 0;
        info->framebuffer_size = 0;
        info->framebuffer_pixel_format = VEX_PIXEL_FORMAT_UNKNOWN;
        return status;
    }

    EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *mode_info = gop->Mode->Info;

    info->framebuffer_addr = gop->Mode->FrameBufferBase;
    info->framebuffer_size = gop->Mode->FrameBufferSize;
    info->framebuffer_width = mode_info->HorizontalResolution;
    info->framebuffer_height = mode_info->VerticalResolution;
    info->framebuffer_pitch = mode_info->PixelsPerScanLine * 4; /* 32bpp formats below */
    info->framebuffer_bpp = 32;

    switch (mode_info->PixelFormat) {
        case PixelRedGreenBlueReserved8BitPerColor:
            info->framebuffer_pixel_format = VEX_PIXEL_FORMAT_RGBX8;
            break;
        case PixelBlueGreenRedReserved8BitPerColor:
            info->framebuffer_pixel_format = VEX_PIXEL_FORMAT_BGRX8;
            break;
        case PixelBitMask:
            info->framebuffer_pixel_format = VEX_PIXEL_FORMAT_BITMASK;
            break;
        default:
            info->framebuffer_pixel_format = VEX_PIXEL_FORMAT_UNKNOWN;
            break;
    }

    Print(L"[boot] Framebuffer: %dx%d @ 0x%lx (%ld bytes)\n",
          info->framebuffer_width, info->framebuffer_height,
          info->framebuffer_addr, info->framebuffer_size);

    return EFI_SUCCESS;
}

/* ---------------------------------------------------------------- */
/* ACPI RSDP                                                          */
/* ---------------------------------------------------------------- */

/* This gnu-efi build only exports `AcpiTableGuid` (ACPI 1.0) as an
 * extern symbol; both GUIDs are therefore defined locally from the
 * EFI spec constants in efiapi.h (ACPI_20_TABLE_GUID / ACPI_TABLE_GUID).
 * ACPI 2.0+ is checked first and preferred. */
static EFI_GUID Acpi20TableGuidLocal = ACPI_20_TABLE_GUID;
static EFI_GUID Acpi10TableGuidLocal = ACPI_TABLE_GUID;

/* Compare two EFI_GUIDs field-by-field.
 *
 * Deliberately NOT using gnu-efi's CompareGuid(). That name is a macro
 * whose meaning depends on GNU_EFI_USE_COMPAREGUID_ABI:
 *
 *   ABI == 0 -> CompareGuid_0, returns INTN  0     when EQUAL
 *   ABI == 1 -> CompareGuid_1, returns BOOLEAN TRUE when EQUAL
 *
 * and current gnu-efi defaults the macro to 1 (see legacy.h). Code that
 * tests `CompareGuid(a,b) == 0` therefore inverts on modern gnu-efi and
 * matches the FIRST NON-MATCHING configuration table entry. That is a
 * silent wrong-pointer bug, not a compile error: the bootloader hands
 * the kernel a valid-looking address that is not the RSDP, and the
 * kernel then reports "RSDP signature mismatch" and loses ACPI/MADT
 * (and therefore all SMP CPU discovery).
 *
 * A local comparison has no ABI ambiguity and behaves identically under
 * GCC/gnu-efi and the Clang/LLD build path. */
static BOOLEAN guid_eq(const EFI_GUID *a, const EFI_GUID *b)
{
    if (a->Data1 != b->Data1) return FALSE;
    if (a->Data2 != b->Data2) return FALSE;
    if (a->Data3 != b->Data3) return FALSE;
    for (UINTN i = 0; i < 8; i++) {
        if (a->Data4[i] != b->Data4[i]) return FALSE;
    }
    return TRUE;
}

static UINT64 find_rsdp(EFI_SYSTEM_TABLE *st)
{
    /* ACPI 2.0+ GUID is preferred over the ACPI 1.0 GUID. */
    for (UINTN i = 0; i < st->NumberOfTableEntries; i++) {
        EFI_CONFIGURATION_TABLE *cfg = &st->ConfigurationTable[i];
        if (guid_eq(&cfg->VendorGuid, &Acpi20TableGuidLocal)) {
            return (UINT64)(UINTN)cfg->VendorTable;
        }
    }
    for (UINTN i = 0; i < st->NumberOfTableEntries; i++) {
        EFI_CONFIGURATION_TABLE *cfg = &st->ConfigurationTable[i];
        if (guid_eq(&cfg->VendorGuid, &Acpi10TableGuidLocal)) {
            return (UINT64)(UINTN)cfg->VendorTable;
        }
    }
    Print(L"[boot] WARNING: no ACPI RSDP found\n");
    return 0;
}

/* ---------------------------------------------------------------- */
/* Kernel loading                                                    */
/* ---------------------------------------------------------------- */

static EFI_STATUS load_kernel(EFI_HANDLE image_handle, BootInfo *info)
{
    EFI_STATUS status;
    EFI_LOADED_IMAGE *loaded_image;
    EFI_FILE_IO_INTERFACE *fs;
    EFI_FILE_HANDLE root, kernel_file;

    status = uefi_call_wrapper(BS->HandleProtocol, 3, image_handle,
                                &LoadedImageProtocol, (void **)&loaded_image);
    if (EFI_ERROR(status)) {
        Print(L"[boot] HandleProtocol(LoadedImage) failed: %r\n", status);
        return status;
    }

    status = uefi_call_wrapper(BS->HandleProtocol, 3, loaded_image->DeviceHandle,
                                &FileSystemProtocol, (void **)&fs);
    if (EFI_ERROR(status)) {
        Print(L"[boot] HandleProtocol(FileSystem) failed: %r\n", status);
        return status;
    }

    status = uefi_call_wrapper(fs->OpenVolume, 2, fs, &root);
    if (EFI_ERROR(status)) {
        Print(L"[boot] OpenVolume failed: %r\n", status);
        return status;
    }

    status = uefi_call_wrapper(root->Open, 5, root, &kernel_file, KERNEL_PATH,
                                EFI_FILE_MODE_READ, 0);
    if (EFI_ERROR(status)) {
        Print(L"[boot] Failed to open %s: %r\n", KERNEL_PATH, status);
        return status;
    }

    /* Query file size via EFI_FILE_INFO. */
    UINTN info_size = 0;
    EFI_FILE_INFO *file_info = NULL;
    status = uefi_call_wrapper(kernel_file->GetInfo, 4, kernel_file,
                                &GenericFileInfo, &info_size, file_info);
    if (status != EFI_BUFFER_TOO_SMALL) {
        Print(L"[boot] GetInfo size probe failed: %r\n", status);
        return status;
    }
    status = uefi_call_wrapper(BS->AllocatePool, 3, EfiLoaderData,
                                info_size, (void **)&file_info);
    if (EFI_ERROR(status)) return status;

    status = uefi_call_wrapper(kernel_file->GetInfo, 4, kernel_file,
                                &GenericFileInfo, &info_size, file_info);
    if (EFI_ERROR(status)) {
        Print(L"[boot] GetInfo failed: %r\n", status);
        return status;
    }

    UINT64 kernel_size = file_info->FileSize;
    uefi_call_wrapper(BS->FreePool, 1, file_info);

    /* BOOT-01 contract (see common/include/boot_layout.h): the
     * kernel has no relocation/paging support yet, so it is linked
     * to run at a fixed physical address and MUST be loaded at
     * exactly that address - not wherever the allocator happens to
     * place it. AllocateAddress enforces this; if that address is
     * already reserved/unavailable on a given machine, boot fails
     * loudly here rather than silently corrupting or mis-jumping. */
    /* Reserve the kernel's RUN-TIME footprint, not its file size - the
     * flat binary excludes .bss (see VEX_KERNEL_RESERVE_BYTES). */
    UINTN reserve = (UINTN)VEX_KERNEL_RESERVE_BYTES;
    if (kernel_size > reserve) reserve = kernel_size;
    UINTN pages = (reserve + EFI_PAGE_SIZE - 1) / EFI_PAGE_SIZE;
    EFI_PHYSICAL_ADDRESS kernel_addr = VEX_KERNEL_LOAD_PHYS;
    status = uefi_call_wrapper(BS->AllocatePages, 4, AllocateAddress,
                                EfiLoaderData, pages, &kernel_addr);
    if (EFI_ERROR(status)) {
        Print(L"[boot] AllocatePages(fixed @ 0x%lx) for kernel failed: %r\n",
              (UINT64)VEX_KERNEL_LOAD_PHYS, status);
        return status;
    }

    UINTN read_size = kernel_size;
    status = uefi_call_wrapper(kernel_file->Read, 3, kernel_file,
                                &read_size, (void *)(UINTN)kernel_addr);
    if (EFI_ERROR(status) || read_size != kernel_size) {
        Print(L"[boot] Kernel read failed: %r (got %ld of %ld bytes)\n",
              status, read_size, kernel_size);
        return EFI_ERROR(status) ? status : EFI_LOAD_ERROR;
    }

    uefi_call_wrapper(kernel_file->Close, 1, kernel_file);

    info->kernel_physical_base = kernel_addr;
    info->kernel_physical_size = kernel_size;
    info->kernel_virtual_base = 0xFFFFFFFF80000000ULL;

    Print(L"[boot] Kernel loaded: %ld bytes @ physical 0x%lx\n",
          kernel_size, kernel_addr);

    return EFI_SUCCESS;
}

/* ---------------------------------------------------------------- */
/* Entry point                                                       */
/* ---------------------------------------------------------------- */

EFI_STATUS efi_main(EFI_HANDLE image_handle, EFI_SYSTEM_TABLE *system_table)
{
    EFI_STATUS status;

    InitializeLib(image_handle, system_table);
    Print(L"Vex OS Bootloader - BOOT-01\n");

    /* Allocate BootInfo itself from EfiLoaderData so it survives
     * ExitBootServices and remains valid for the kernel to read. */
    BootInfo *info = NULL;
    status = uefi_call_wrapper(BS->AllocatePool, 3, EfiLoaderData,
                                sizeof(BootInfo), (void **)&info);
    if (EFI_ERROR(status)) {
        Print(L"[boot] Failed to allocate BootInfo: %r\n", status);
        return status;
    }
    ZeroMem(info, sizeof(BootInfo));

    info->magic = VEXOS_BOOTINFO_MAGIC;
    info->version = VEXOS_BOOTINFO_VERSION;
    info->header_size = sizeof(BootInfo);
    info->bootloader_version = 1;
    info->boot_flags = 0;

    /* Step 5: ACPI RSDP */
    info->rsdp_address = find_rsdp(system_table);

    /* Step 4: framebuffer */
    init_graphics(info);

    /* Steps 3/6: locate and load the kernel image */
    status = load_kernel(image_handle, info);
    if (EFI_ERROR(status)) {
        Print(L"[boot] FATAL: kernel load failed, halting.\n");
        goto halt;
    }

    /* Step 2: memory map - MUST be the last EFI call before
     * ExitBootServices, since any further allocation invalidates
     * the map key. */
    EFI_MEMORY_DESCRIPTOR *map = NULL;
    UINTN map_size = 0, map_key = 0, desc_size = 0;
    UINT32 desc_version = 0;

    status = get_memory_map(&map, &map_size, &map_key, &desc_size, &desc_version);
    if (EFI_ERROR(status)) {
        Print(L"[boot] FATAL: could not obtain memory map, halting.\n");
        goto halt;
    }

    info->memory_map = (UINT64)(UINTN)map;
    info->memory_map_size = map_size;
    info->memory_map_desc_size = desc_size;
    info->memory_map_desc_version = desc_version;

    /* Step 7: BootInfo is now fully constructed. */

    status = uefi_call_wrapper(BS->ExitBootServices, 2, image_handle, map_key);
    if (EFI_ERROR(status)) {
        /* Per UEFI spec, the memory map may have changed; retry once
         * with a fresh map. If it fails twice, something is
         * seriously wrong - halt rather than proceed on stale state. */
        status = get_memory_map(&map, &map_size, &map_key, &desc_size, &desc_version);
        if (EFI_ERROR(status)) goto halt;

        info->memory_map = (UINT64)(UINTN)map;
        info->memory_map_size = map_size;
        info->memory_map_desc_size = desc_size;
        info->memory_map_desc_version = desc_version;

        status = uefi_call_wrapper(BS->ExitBootServices, 2, image_handle, map_key);
        if (EFI_ERROR(status)) {
            /* Cannot Print() safely after a failed second attempt in
             * some firmware, but we haven't exited boot services yet
             * in this branch, so it's still safe here. */
            Print(L"[boot] FATAL: ExitBootServices failed twice: %r\n", status);
            goto halt;
        }
    }

    /* Step 8: no more UEFI boot services from here on. No Print(),
     * no allocation, no protocol calls. Jump straight to the kernel. */
    {
        KernelEntry entry = (KernelEntry)(UINTN)info->kernel_physical_base;
        entry(info);
    }

    /* Kernel entry must never return. If it does, something is
     * catastrophically wrong and there is no UEFI console left to
     * report it - halt the CPU. */
    for (;;) {
        __asm__ volatile ("cli; hlt");
    }

halt:
    Print(L"[boot] Halting.\n");
    for (;;) {
        uefi_call_wrapper(BS->Stall, 1, 1000000);
    }

    return EFI_SUCCESS;
}
