"""Hosted tensor runtime for VexScript 3.0-B (no NumPy dependency).

Tensors are contiguous row-major float lists with static shape metadata.
Compatible with Vex IR 1.3 tensor ops; design path remains IR 2.0 for full neural dialect.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any


@dataclass
class Tensor:
    dtype: str  # "f32" | "f64"
    shape: tuple[int, ...]
    data: list[float]

    def size(self) -> int:
        n = 1
        for d in self.shape:
            n *= d
        return n

    def __repr__(self) -> str:
        return f"tensor<{self.dtype}, {list(self.shape)}>[{self.size()} el]"


def _shape_size(shape: tuple[int, ...]) -> int:
    n = 1
    for d in shape:
        if d <= 0:
            raise ValueError("tensor dims must be positive")
        n *= d
    return n


def tensor_create(dtype: str, *dims: int) -> Tensor:
    shape = tuple(int(d) for d in dims)
    n = _shape_size(shape)
    return Tensor(dtype=dtype or "f32", shape=shape, data=[0.0] * n)


def tensor_fill(t: Tensor, value: float) -> Tensor:
    v = float(value)
    t.data = [v] * t.size()
    return t


def tensor_from_list(dtype: str, shape: tuple[int, ...], values: list[float]) -> Tensor:
    n = _shape_size(shape)
    if len(values) != n:
        raise ValueError(f"expected {n} values, got {len(values)}")
    return Tensor(dtype=dtype, shape=shape, data=[float(x) for x in values])


def tensor_get(t: Tensor, *indices: int) -> float:
    if len(indices) != len(t.shape):
        raise ValueError("rank mismatch in tensor_get")
    off = 0
    stride = 1
    # row-major
    for i in range(len(t.shape) - 1, -1, -1):
        idx = int(indices[i])
        if idx < 0 or idx >= t.shape[i]:
            raise ValueError(f"index {idx} out of bounds for dim {t.shape[i]}")
        off += idx * stride
        stride *= t.shape[i]
    return t.data[off]


def tensor_set(t: Tensor, value: float, *indices: int) -> int:
    if len(indices) != len(t.shape):
        raise ValueError("rank mismatch in tensor_set")
    off = 0
    stride = 1
    for i in range(len(t.shape) - 1, -1, -1):
        idx = int(indices[i])
        if idx < 0 or idx >= t.shape[i]:
            raise ValueError(f"index {idx} out of bounds for dim {t.shape[i]}")
        off += idx * stride
        stride *= t.shape[i]
    t.data[off] = float(value)
    return 0


def tensor_add(a: Tensor, b: Tensor) -> Tensor:
    if a.shape != b.shape:
        raise ValueError(f"tensor_add shape mismatch {a.shape} vs {b.shape}")
    return Tensor(a.dtype, a.shape, [x + y for x, y in zip(a.data, b.data)])


def tensor_mul(a: Tensor, b: Tensor) -> Tensor:
    """Element-wise multiply."""
    if a.shape != b.shape:
        raise ValueError(f"tensor_mul shape mismatch {a.shape} vs {b.shape}")
    return Tensor(a.dtype, a.shape, [x * y for x, y in zip(a.data, b.data)])


def tensor_dot(a: Tensor, b: Tensor) -> float:
    if a.shape != b.shape or len(a.shape) != 1:
        raise ValueError("tensor_dot requires equal rank-1 tensors")
    return sum(x * y for x, y in zip(a.data, b.data))


def tensor_matmul(a: Tensor, b: Tensor) -> Tensor:
    """a[M,K] @ b[K,N] -> [M,N]  (Torch-accelerated when available)"""
    if len(a.shape) != 2 or len(b.shape) != 2:
        raise ValueError("tensor_matmul requires rank-2 tensors")
    m, k1 = a.shape
    k2, n = b.shape
    if k1 != k2:
        raise ValueError(f"matmul inner dim mismatch {k1} vs {k2}")
    # torch acceleration
    try:
        import torch
        ta = torch.tensor(a.data, dtype=torch.float32).reshape(m, k1)
        tb = torch.tensor(b.data, dtype=torch.float32).reshape(k2, n)
        out = (ta @ tb).flatten().tolist()
        return Tensor(a.dtype, (m, n), out)
    except Exception:
        pass
    out = [0.0] * (m * n)
    for i in range(m):
        for j in range(n):
            s = 0.0
            for k in range(k1):
                s += a.data[i * k1 + k] * b.data[k * n + j]
            out[i * n + j] = s
    return Tensor(a.dtype, (m, n), out)


def tensor_length(t: Tensor) -> int:
    return t.size()


def tensor_print(t: Any) -> int:
    """Return 0; actual printing done by caller via println(str)."""
    return 0


# --- 3.0-C neural helpers (desugared layer ops) ---

def neural_relu(t: Tensor) -> Tensor:
    return Tensor(t.dtype, t.shape, [x if x > 0.0 else 0.0 for x in t.data])


def neural_add_bias(x: Tensor, b: Tensor) -> Tensor:
    """Broadcast bias: x[M,N] + b[N] or x[N] + b[N]."""
    if len(b.shape) == 1 and len(x.shape) == 2 and b.shape[0] == x.shape[1]:
        m, n = x.shape
        out = []
        for i in range(m):
            for j in range(n):
                out.append(x.data[i * n + j] + b.data[j])
        return Tensor(x.dtype, x.shape, out)
    if x.shape == b.shape:
        return tensor_add(x, b)
    raise ValueError(f"neural_add_bias shape mismatch {x.shape} + {b.shape}")


def neural_linear(x: Tensor, w: Tensor, bias: Tensor | None = None) -> Tensor:
    """Dense: y = x @ W (+ bias).
    x: [M,K] or [K], W: [K,N], bias optional [N].
    """
    if len(x.shape) == 1:
        # treat as [1,K]
        x2 = Tensor(x.dtype, (1, x.shape[0]), list(x.data))
        y = tensor_matmul(x2, w)
        y = Tensor(y.dtype, (y.shape[1],), list(y.data))  # squeeze batch
    elif len(x.shape) == 2:
        y = tensor_matmul(x, w)
    else:
        raise ValueError("neural_linear expects rank-1 or rank-2 x")
    if bias is not None:
        if len(y.shape) == 1:
            if bias.shape != y.shape:
                raise ValueError("bias shape must match output")
            y = tensor_add(y, bias)
        else:
            y = neural_add_bias(y, bias)
    return y


def neural_forward_2layer(
    x: Tensor,
    w1: Tensor,
    b1: Tensor,
    w2: Tensor,
    b2: Tensor,
) -> Tensor:
    """Simple MLP: relu(linear(x,w1,b1)) then linear(...,w2,b2)."""
    h = neural_linear(x, w1, b1)
    h = neural_relu(h)
    return neural_linear(h, w2, b2)
