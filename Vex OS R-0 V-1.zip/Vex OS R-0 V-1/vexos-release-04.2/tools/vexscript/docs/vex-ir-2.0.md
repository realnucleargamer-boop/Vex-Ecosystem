# Vex IR 2.0 — Design Specification

**Status:** Design (companion to VexScript 3.0)  
**Does not replace:** Vex IR 1.2 for non-tensor programs

## Version header

```text
; Vex IR 2.0
ir_version 2.0
calling_conv vex_hosted
```

## Relationship to 1.2

- All 1.2 ops remain valid.
- New tensor / neural / evolve ops are **additive**.
- Verifier rejects tensor ops on IR 1.2 modules.

## New types (IR-level)

| Type | Meaning |
|------|---------|
| `tensor<f32, [N]>` | Rank-1 f32 |
| `tensor<f32, [M, N]>` | Rank-2 f32 |
| `tensor<f64, […]>` | Optional |

Shapes are static in IR 2.0 initial revision.

## New ops (planned)

### Tensor

```text
tensor.create
tensor.load
tensor.store
tensor.add
tensor.mul
tensor.dot
tensor.matmul
tensor.fill
tensor.copy
```

### Neural (lowered helpers)

```text
neural.linear      ; y = x @ W + b
neural.relu
neural.sigmoid     ; optional
neural.forward     ; optional composite
```

### Evolution

```text
evolve.mutate
evolve.crossover
evolve.select
evolve.fitness
```

### RNG

```text
rng.seed
rng.u64
rng.f32
```

## Determinism

- `rng.seed` sets module-local or process-local PRNG state.
- Evolve ops must use that PRNG only (no host `random` without seed).

## Non-goals for IR 2.0 initial

- Autodiff IR
- CUDA / GPU dialect
- Dynamic rank polymorphism
- Vex OS syscall encoding

## Lowering policy

Layers in source **desugar** to tensor + neural ops before or during emit. No opaque “layer object” required in IR if expanded to matmul + add + relu.
