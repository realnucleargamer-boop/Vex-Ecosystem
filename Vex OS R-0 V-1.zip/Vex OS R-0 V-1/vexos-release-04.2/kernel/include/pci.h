/*
 * Vex OS - kernel/include/pci.h
 * STORAGE-01: PCI configuration-space enumeration (legacy 0xCF8/0xCFC mechanism #1, bus 0..255).
 * Read-mostly: the only writes are the command register (memory space + bus master) for a device a driver has claimed.
 */
#ifndef VEXOS_PCI_H
#define VEXOS_PCI_H
#include <stdint.h>

#define PCI_MAX_DEVICES 64

typedef struct {
    uint8_t bus, slot, func, cls, sub, prog, hdr;
    uint16_t vendor, device;
    uint32_t bar[6];            /* raw BAR registers as found (header type 0 only; zero otherwise) */
} PciDev;

/* Scans the bus. Returns the number of devices recorded (0 if config space is unreachable). Idempotent. */
int pci_scan(void);
int pci_count(void);
const PciDev *pci_get(int i);
/* First device with this class/subclass/prog-if (prog 0xFF = any), or 0. */
const PciDev *pci_find_class(uint8_t cls, uint8_t sub, int prog);
uint32_t pci_read32(const PciDev *d, uint8_t off);
void pci_write32(const PciDev *d, uint8_t off, uint32_t v);
/* Sets memory-space + bus-master (and clears nothing else). */
void pci_enable_mem_dma(const PciDev *d);
/* Physical base of a memory BAR (handles 64-bit BARs). Returns 0 for I/O or absent BARs. */
uint64_t pci_bar_mem(const PciDev *d, int n);
const char *pci_class_name(uint8_t cls, uint8_t sub);
#endif
