#!/usr/bin/env python3
"""VexScript 2+ Phase B — match + non-generic Result foundation"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vexscript.interpreter import Interpreter
from vexscript.errors import VexError
from vexscript.compile_ir import run_via_ir

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

def run(src):
    i = Interpreter()
    i.load(src, "<t>")
    return i.run_main(), i.output

print("VexScript 2+ Phase B")

c, o = run("""
enum InputState { None, Pressed, Released }
fn main() -> i32 {
    let s: InputState = InputState::Released;
    match (s) {
        InputState::Pressed => { println(1); }
        InputState::Released => { println(2); }
        _ => { println(0); }
    }
    return 0;
}
""")
check("match enum", c == 0 and o == ["2"], o)

c, o = run("""
fn main() -> i32 {
    let x: i64 = 3;
    match (x) {
        1 => { println(10); }
        3 => { println(30); }
        _ => { println(0); }
    }
    return 0;
}
""")
check("match int", c == 0 and o == ["30"], o)

try:
    run("""
enum E { A, B }
fn main() -> i32 {
    let e: E = E::A;
    match (e) {
        E::A => { println(1); }
    }
    return 0;
}
""")
    check("non-exhaustive", False)
except VexError as e:
    check("non-exhaustive", "non-exhaustive" in str(e).lower() or "missing" in str(e).lower(), str(e))

# Non-generic Result-style enum
c, o = run("""
enum ResultCode { Ok, Err }
fn main() -> i32 {
    let r: ResultCode = ResultCode::Ok;
    match (r) {
        ResultCode::Ok => { println(100); }
        ResultCode::Err => { println(200); }
    }
    return 0;
}
""")
check("result-style enum", c == 0 and o == ["100"], o)

code, out = run_via_ir("""
enum Flag { Off, On }
fn main() -> i32 {
    let f: Flag = Flag::On;
    match (f) {
        Flag::Off => { println(0); }
        Flag::On => { println(1); }
    }
    return 0;
}
""")
check("match via IR", code == 0 and "1" in out, out)

print(f"\n=== 2+ Phase B Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
