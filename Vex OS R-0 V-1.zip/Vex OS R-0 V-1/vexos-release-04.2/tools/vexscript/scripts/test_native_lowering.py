#!/usr/bin/env python3
"""Native lowering e2e: VexScript → IR → x86-64 + C runtime (no Python for core ops)."""
import sys
import time
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vexscript import __version__, __ir_version__
from vexscript.native import compile_native, run_native
from vexscript.interpreter import Interpreter
from vexscript.compile_ir import emit_ir_text

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

print(f"Native lowering  VS={__version__} IR={__ir_version__}")

# 1) RNG native e2e
src = """
fn main() -> i32 {
    rng_seed(42);
    println(rng_u64());
    println(rng_u64());
    return 0;
}
"""
try:
    code, out = run_native(src, "rng_native.vex")
    lines = [ln for ln in out.strip().splitlines() if ln.strip()]
    check("native rng runs", code == 0 and len(lines) >= 2, (code, out))
    code2, out2 = run_native(src, "rng_native2.vex")
    check("native rng deterministic", out == out2, (out, out2))
except Exception as e:
    check("native rng runs", False, str(e))
    check("native rng deterministic", False, str(e))

# 2) Genome native
src = """
fn main() -> i32 {
    let g = genome_create(64);
    genome_fill_code(g, 65, 10);
    println(genome_length(g));
    println(genome_char_code_at(g, 0));
    genome_set_char_code(g, 0, 66);
    println(genome_char_code_at(g, 0));
    let h = genome_copy(g);
    println(genome_compare(g, h));
    return 0;
}
"""
try:
    code, out = run_native(src, "gen_native.vex")
    lines = out.strip().splitlines()
    check("native genome", code == 0 and lines[:4] == ["10", "65", "66", "0"], out)
except Exception as e:
    check("native genome", False, str(e))

# 3) Stream / fitness / advance
src = """
fn main() -> i32 {
    rng_seed(7);
    let s = stream_create(8, 16, 2);
    println(stream_size(s));
    println(elite_preserve_count(s));
    fitness_set(s, 0, 10);
    fitness_set(s, 1, 50);
    fitness_set(s, 2, 20);
    println(fitness_best_index(s));
    println(fitness_sum(s));
    stream_advance(s, 200);
    println(stream_generation(s));
    return 0;
}
"""
try:
    code, out = run_native(src, "stream_native.vex")
    lines = out.strip().splitlines()
    check("native stream", code == 0 and len(lines) >= 5 and lines[0] == "8" and lines[2] == "1", out)
except Exception as e:
    check("native stream", False, str(e))

# 4) Migration
src = """
fn main() -> i32 {
    rng_seed(3);
    let a = stream_create(4, 8, 1);
    let b = stream_create(4, 8, 1);
    fitness_set(a, 0, 100);
    fitness_set(a, 1, 10);
    migrate_best(a, b, 3);
    println(fitness_get(b, 3));
    return 0;
}
"""
try:
    code, out = run_native(src, "mig_native.vex")
    check("native migrate", code == 0 and "100" in out, out)
except Exception as e:
    check("native migrate", False, str(e))

# 5) IR contains calls
text = emit_ir_text("""
fn main() -> i32 {
    rng_seed(1);
    let g = genome_create(8);
    return 0;
}
""")
check("ir version 1.5", "ir_version 1.5" in text, text[:80])
check("ir has genome call", "genome_create" in text or "@genome_create" in text, text[:400])

# 6) Hosted still works
i = Interpreter(); i.load("""
fn main() -> i32 {
    let g = genome_create(8);
    genome_fill_code(g, 65, 4);
    println(genome_char_code_at(g, 0));
    return 0;
}
""", "h.vex")
i.run_main()
check("hosted genome_code", i.output == ["65"], i.output)

# 7) Micro benchmark hosted vs native (rng loop approximated by stream)
src_bench = """
fn main() -> i32 {
    rng_seed(42);
    let s = stream_create(32, 16, 2);
    let mut i: i64 = 0;
    while (i < 32) {
        fitness_set(s, i, i);
        i = i + 1;
    }
    let mut g: i64 = 0;
    while (g < 20) {
        stream_advance(s, 100);
        g = g + 1;
    }
    println(stream_generation(s));
    return 0;
}
"""
t0 = time.perf_counter()
ih = Interpreter(); ih.load(src_bench, "b.vex"); ih.run_main()
th = time.perf_counter() - t0
t0 = time.perf_counter()
code_n, on = run_native(src_bench, "b_native.vex")
tn = time.perf_counter() - t0
check("bench both complete", "20" in "".join(str(x) for x in ih.output) and "20" in on, (ih.output, on))
print(f"  BENCH hosted={th:.4f}s native={tn:.4f}s (includes compile for native)")

print(f"\n=== Native lowering: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
