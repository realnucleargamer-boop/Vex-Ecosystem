.text
.globl main
.extern vex_rt_print_i64
.extern vex_rt_println_i64
.extern vex_rt_print_cstr
.extern vex_rt_println_cstr
.extern vex_rt_rng_seed
.extern vex_rt_rng_u64
.extern vex_rt_genome_create
.extern vex_rt_genome_length
.extern vex_rt_genome_char_code_at
.extern vex_rt_genome_set_char_code
.extern vex_rt_genome_fill_code
.extern vex_rt_genome_copy
.extern vex_rt_genome_compare
.extern vex_rt_genome_slice
.extern vex_rt_stream_create
.extern vex_rt_stream_size
.extern vex_rt_stream_generation
.extern vex_rt_stream_set_elite_count
.extern vex_rt_stream_advance
.extern vex_rt_stream_pop
.extern vex_rt_fitness_set
.extern vex_rt_fitness_get
.extern vex_rt_fitness_best_index
.extern vex_rt_fitness_worst_index
.extern vex_rt_fitness_average
.extern vex_rt_fitness_sum
.extern vex_rt_diversity_hamming_avg
.extern vex_rt_migrate_copy
.extern vex_rt_migrate_best
.extern vex_rt_elite_preserve_count
.extern vex_rt_evo_reset
.extern vex_rt_genome_from_cstr
.extern vex_rt_genome_to_cstr
.extern vex_rt_genome_char_at
.extern vex_rt_genome_set_char
.extern vex_rt_genome_append_char
.extern vex_rt_genome_fill
.extern vex_rt_genome_match_cstr

# ----- vt_is_ws -----
.globl vt_is_ws
vt_is_ws:
    pushq %rbp
    movq %rsp, %rbp
    subq $80, %rsp
    movq %rdi, -8(%rbp)
.Lvt_is_ws_entry:
    movq -8(%rbp), %rax
    movq %rax, -16(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -24(%rbp)
    movq $32, %rax
    movq %rax, -32(%rbp)
    movq -24(%rbp), %rax
    pushq %rax
    movq -32(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -40(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -48(%rbp)
    movq $9, %rax
    movq %rax, -56(%rbp)
    movq -48(%rbp), %rax
    pushq %rax
    movq -56(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -64(%rbp)
    movq -40(%rbp), %rax
    pushq %rax
    movq -64(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    orq %rcx, %rax
    cmpq $0, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -72(%rbp)
    movq -72(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_cmd_is -----
.globl vt_cmd_is
vt_cmd_is:
    pushq %rbp
    movq %rsp, %rbp
    subq $736, %rsp
    movq %rdi, -8(%rbp)
    movq %rsi, -16(%rbp)
.Lvt_cmd_is_entry:
    movq -8(%rbp), %rax
    movq %rax, -24(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -32(%rbp)
    movq -24(%rbp), %rax
    movq %rax, -40(%rbp)
    movq -40(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_rt_str_len
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -56(%rbp)
    movq -32(%rbp), %rax
    movq %rax, -64(%rbp)
    movq -64(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_rt_str_len
    movq %rax, -72(%rbp)
    movq -72(%rbp), %rax
    movq %rax, -80(%rbp)
    movq $0, %rax
    movq %rax, -88(%rbp)
    movq -88(%rbp), %rax
    movq %rax, -96(%rbp)
    jmp .Lvt_cmd_is_loop1
.Lvt_cmd_is_loop1:
    movq -96(%rbp), %rax
    movq %rax, -104(%rbp)
    movq -56(%rbp), %rax
    movq %rax, -112(%rbp)
    movq -104(%rbp), %rax
    pushq %rax
    movq -112(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setl %al
    movzbq %al, %rax
    movq %rax, -120(%rbp)
    movq -24(%rbp), %rax
    movq %rax, -128(%rbp)
    movq -96(%rbp), %rax
    movq %rax, -136(%rbp)
    movq -128(%rbp), %rax
    pushq %rax
    movq -136(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_char_at
    movq %rax, -144(%rbp)
    movq -144(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_is_ws
    movq %rax, -152(%rbp)
    movq -120(%rbp), %rax
    pushq %rax
    movq -152(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    andq %rcx, %rax
    cmpq $0, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -160(%rbp)
    movq -160(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_is_body2
    jmp .Lvt_cmd_is_end3
.Lvt_cmd_is_body2:
    movq -96(%rbp), %rax
    movq %rax, -168(%rbp)
    movq $1, %rax
    movq %rax, -176(%rbp)
    movq -168(%rbp), %rax
    pushq %rax
    movq -176(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    addq %rcx, %rax
    movq %rax, -184(%rbp)
    movq -184(%rbp), %rax
    movq %rax, -96(%rbp)
    jmp .Lvt_cmd_is_loop1
.Lvt_cmd_is_end3:
    movq -56(%rbp), %rax
    movq %rax, -192(%rbp)
    movq -192(%rbp), %rax
    movq %rax, -200(%rbp)
    jmp .Lvt_cmd_is_loop4
.Lvt_cmd_is_loop4:
    movq -200(%rbp), %rax
    movq %rax, -208(%rbp)
    movq -96(%rbp), %rax
    movq %rax, -216(%rbp)
    movq -208(%rbp), %rax
    pushq %rax
    movq -216(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setg %al
    movzbq %al, %rax
    movq %rax, -224(%rbp)
    movq -24(%rbp), %rax
    movq %rax, -232(%rbp)
    movq -200(%rbp), %rax
    movq %rax, -240(%rbp)
    movq $1, %rax
    movq %rax, -248(%rbp)
    movq -240(%rbp), %rax
    pushq %rax
    movq -248(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    subq %rcx, %rax
    movq %rax, -256(%rbp)
    movq -232(%rbp), %rax
    pushq %rax
    movq -256(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_char_at
    movq %rax, -264(%rbp)
    movq -264(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_is_ws
    movq %rax, -272(%rbp)
    movq -224(%rbp), %rax
    pushq %rax
    movq -272(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    andq %rcx, %rax
    cmpq $0, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -280(%rbp)
    movq -280(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_is_body5
    jmp .Lvt_cmd_is_end6
.Lvt_cmd_is_body5:
    movq -200(%rbp), %rax
    movq %rax, -288(%rbp)
    movq $1, %rax
    movq %rax, -296(%rbp)
    movq -288(%rbp), %rax
    pushq %rax
    movq -296(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    subq %rcx, %rax
    movq %rax, -304(%rbp)
    movq -304(%rbp), %rax
    movq %rax, -200(%rbp)
    jmp .Lvt_cmd_is_loop4
.Lvt_cmd_is_end6:
    movq $0, %rax
    movq %rax, -312(%rbp)
    movq -312(%rbp), %rax
    movq %rax, -320(%rbp)
    jmp .Lvt_cmd_is_loop7
.Lvt_cmd_is_loop7:
    movq -96(%rbp), %rax
    movq %rax, -328(%rbp)
    movq -200(%rbp), %rax
    movq %rax, -336(%rbp)
    movq -328(%rbp), %rax
    pushq %rax
    movq -336(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setl %al
    movzbq %al, %rax
    movq %rax, -344(%rbp)
    movq -344(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_is_body8
    jmp .Lvt_cmd_is_end9
.Lvt_cmd_is_body8:
    movq -24(%rbp), %rax
    movq %rax, -352(%rbp)
    movq -96(%rbp), %rax
    movq %rax, -360(%rbp)
    movq -352(%rbp), %rax
    pushq %rax
    movq -360(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_char_at
    movq %rax, -368(%rbp)
    movq -368(%rbp), %rax
    movq %rax, -376(%rbp)
    movq -376(%rbp), %rax
    movq %rax, -384(%rbp)
    movq -384(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_is_ws
    movq %rax, -392(%rbp)
    movq -392(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_is_then10
    jmp .Lvt_cmd_is_else11
.Lvt_cmd_is_end9:
    movq -320(%rbp), %rax
    movq %rax, -400(%rbp)
    movq -80(%rbp), %rax
    movq %rax, -408(%rbp)
    movq -400(%rbp), %rax
    pushq %rax
    movq -408(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -416(%rbp)
    movq -416(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_cmd_is_then10:
    movq -320(%rbp), %rax
    movq %rax, -424(%rbp)
    movq -80(%rbp), %rax
    movq %rax, -432(%rbp)
    movq -424(%rbp), %rax
    pushq %rax
    movq -432(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setge %al
    movzbq %al, %rax
    movq %rax, -440(%rbp)
    movq -440(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_is_then13
    jmp .Lvt_cmd_is_else14
.Lvt_cmd_is_else11:
    movq -320(%rbp), %rax
    movq %rax, -448(%rbp)
    movq -80(%rbp), %rax
    movq %rax, -456(%rbp)
    movq -448(%rbp), %rax
    pushq %rax
    movq -456(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setge %al
    movzbq %al, %rax
    movq %rax, -464(%rbp)
    movq -464(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_is_then22
    jmp .Lvt_cmd_is_else23
.Lvt_cmd_is_join12:
    jmp .Lvt_cmd_is_loop7
.Lvt_cmd_is_then13:
    movq $0, %rax
    movq %rax, -472(%rbp)
    movq -472(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_cmd_is_else14:
    jmp .Lvt_cmd_is_join15
.Lvt_cmd_is_join15:
    movq -32(%rbp), %rax
    movq %rax, -480(%rbp)
    movq -320(%rbp), %rax
    movq %rax, -488(%rbp)
    movq -480(%rbp), %rax
    pushq %rax
    movq -488(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_char_at
    movq %rax, -496(%rbp)
    movq $32, %rax
    movq %rax, -504(%rbp)
    movq -496(%rbp), %rax
    pushq %rax
    movq -504(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -512(%rbp)
    movq -512(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_is_then16
    jmp .Lvt_cmd_is_else17
.Lvt_cmd_is_then16:
    movq $0, %rax
    movq %rax, -520(%rbp)
    movq -520(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_cmd_is_else17:
    jmp .Lvt_cmd_is_join18
.Lvt_cmd_is_join18:
    movq -320(%rbp), %rax
    movq %rax, -528(%rbp)
    movq $1, %rax
    movq %rax, -536(%rbp)
    movq -528(%rbp), %rax
    pushq %rax
    movq -536(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    addq %rcx, %rax
    movq %rax, -544(%rbp)
    movq -544(%rbp), %rax
    movq %rax, -320(%rbp)
    jmp .Lvt_cmd_is_loop19
.Lvt_cmd_is_loop19:
    movq -96(%rbp), %rax
    movq %rax, -552(%rbp)
    movq -200(%rbp), %rax
    movq %rax, -560(%rbp)
    movq -552(%rbp), %rax
    pushq %rax
    movq -560(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setl %al
    movzbq %al, %rax
    movq %rax, -568(%rbp)
    movq -24(%rbp), %rax
    movq %rax, -576(%rbp)
    movq -96(%rbp), %rax
    movq %rax, -584(%rbp)
    movq -576(%rbp), %rax
    pushq %rax
    movq -584(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_char_at
    movq %rax, -592(%rbp)
    movq -592(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_is_ws
    movq %rax, -600(%rbp)
    movq -568(%rbp), %rax
    pushq %rax
    movq -600(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    andq %rcx, %rax
    cmpq $0, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -608(%rbp)
    movq -608(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_is_body20
    jmp .Lvt_cmd_is_end21
.Lvt_cmd_is_body20:
    movq -96(%rbp), %rax
    movq %rax, -616(%rbp)
    movq $1, %rax
    movq %rax, -624(%rbp)
    movq -616(%rbp), %rax
    pushq %rax
    movq -624(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    addq %rcx, %rax
    movq %rax, -632(%rbp)
    movq -632(%rbp), %rax
    movq %rax, -96(%rbp)
    jmp .Lvt_cmd_is_loop19
.Lvt_cmd_is_end21:
    jmp .Lvt_cmd_is_join12
.Lvt_cmd_is_then22:
    movq $0, %rax
    movq %rax, -640(%rbp)
    movq -640(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_cmd_is_else23:
    jmp .Lvt_cmd_is_join24
.Lvt_cmd_is_join24:
    movq -32(%rbp), %rax
    movq %rax, -648(%rbp)
    movq -320(%rbp), %rax
    movq %rax, -656(%rbp)
    movq -648(%rbp), %rax
    pushq %rax
    movq -656(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_char_at
    movq %rax, -664(%rbp)
    movq -376(%rbp), %rax
    movq %rax, -672(%rbp)
    movq -664(%rbp), %rax
    pushq %rax
    movq -672(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -680(%rbp)
    movq -680(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_is_then25
    jmp .Lvt_cmd_is_else26
.Lvt_cmd_is_then25:
    movq $0, %rax
    movq %rax, -688(%rbp)
    movq -688(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_cmd_is_else26:
    jmp .Lvt_cmd_is_join27
.Lvt_cmd_is_join27:
    movq -320(%rbp), %rax
    movq %rax, -696(%rbp)
    movq $1, %rax
    movq %rax, -704(%rbp)
    movq -696(%rbp), %rax
    pushq %rax
    movq -704(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    addq %rcx, %rax
    movq %rax, -712(%rbp)
    movq -712(%rbp), %rax
    movq %rax, -320(%rbp)
    movq -96(%rbp), %rax
    movq %rax, -720(%rbp)
    movq $1, %rax
    movq %rax, -728(%rbp)
    movq -720(%rbp), %rax
    pushq %rax
    movq -728(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    addq %rcx, %rax
    movq %rax, -736(%rbp)
    movq -736(%rbp), %rax
    movq %rax, -96(%rbp)
    jmp .Lvt_cmd_is_join12

# ----- vt_cmd_prefix -----
.globl vt_cmd_prefix
vt_cmd_prefix:
    pushq %rbp
    movq %rsp, %rbp
    subq $720, %rsp
    movq %rdi, -8(%rbp)
    movq %rsi, -16(%rbp)
.Lvt_cmd_prefix_entry:
    movq -8(%rbp), %rax
    movq %rax, -24(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -32(%rbp)
    movq -24(%rbp), %rax
    movq %rax, -40(%rbp)
    movq -40(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_rt_str_len
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -56(%rbp)
    movq -32(%rbp), %rax
    movq %rax, -64(%rbp)
    movq -64(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_rt_str_len
    movq %rax, -72(%rbp)
    movq -72(%rbp), %rax
    movq %rax, -80(%rbp)
    movq $0, %rax
    movq %rax, -88(%rbp)
    movq -88(%rbp), %rax
    movq %rax, -96(%rbp)
    jmp .Lvt_cmd_prefix_loop1
.Lvt_cmd_prefix_loop1:
    movq -96(%rbp), %rax
    movq %rax, -104(%rbp)
    movq -56(%rbp), %rax
    movq %rax, -112(%rbp)
    movq -104(%rbp), %rax
    pushq %rax
    movq -112(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setl %al
    movzbq %al, %rax
    movq %rax, -120(%rbp)
    movq -24(%rbp), %rax
    movq %rax, -128(%rbp)
    movq -96(%rbp), %rax
    movq %rax, -136(%rbp)
    movq -128(%rbp), %rax
    pushq %rax
    movq -136(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_char_at
    movq %rax, -144(%rbp)
    movq -144(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_is_ws
    movq %rax, -152(%rbp)
    movq -120(%rbp), %rax
    pushq %rax
    movq -152(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    andq %rcx, %rax
    cmpq $0, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -160(%rbp)
    movq -160(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_prefix_body2
    jmp .Lvt_cmd_prefix_end3
.Lvt_cmd_prefix_body2:
    movq -96(%rbp), %rax
    movq %rax, -168(%rbp)
    movq $1, %rax
    movq %rax, -176(%rbp)
    movq -168(%rbp), %rax
    pushq %rax
    movq -176(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    addq %rcx, %rax
    movq %rax, -184(%rbp)
    movq -184(%rbp), %rax
    movq %rax, -96(%rbp)
    jmp .Lvt_cmd_prefix_loop1
.Lvt_cmd_prefix_end3:
    movq $0, %rax
    movq %rax, -192(%rbp)
    movq -192(%rbp), %rax
    movq %rax, -200(%rbp)
    jmp .Lvt_cmd_prefix_loop4
.Lvt_cmd_prefix_loop4:
    movq -200(%rbp), %rax
    movq %rax, -208(%rbp)
    movq -80(%rbp), %rax
    movq %rax, -216(%rbp)
    movq -208(%rbp), %rax
    pushq %rax
    movq -216(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setl %al
    movzbq %al, %rax
    movq %rax, -224(%rbp)
    movq -224(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_prefix_body5
    jmp .Lvt_cmd_prefix_end6
.Lvt_cmd_prefix_body5:
    movq -96(%rbp), %rax
    movq %rax, -232(%rbp)
    movq -56(%rbp), %rax
    movq %rax, -240(%rbp)
    movq -232(%rbp), %rax
    pushq %rax
    movq -240(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setge %al
    movzbq %al, %rax
    movq %rax, -248(%rbp)
    movq -248(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_prefix_then7
    jmp .Lvt_cmd_prefix_else8
.Lvt_cmd_prefix_end6:
    movq -96(%rbp), %rax
    movq %rax, -256(%rbp)
    movq -56(%rbp), %rax
    movq %rax, -264(%rbp)
    movq -256(%rbp), %rax
    pushq %rax
    movq -264(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setl %al
    movzbq %al, %rax
    movq %rax, -272(%rbp)
    movq -24(%rbp), %rax
    movq %rax, -280(%rbp)
    movq -96(%rbp), %rax
    movq %rax, -288(%rbp)
    movq -280(%rbp), %rax
    pushq %rax
    movq -288(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_char_at
    movq %rax, -296(%rbp)
    movq -296(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_is_ws
    movq %rax, -304(%rbp)
    movq $0, %rax
    movq %rax, -312(%rbp)
    movq -304(%rbp), %rax
    pushq %rax
    movq -312(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -320(%rbp)
    movq -272(%rbp), %rax
    pushq %rax
    movq -320(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    andq %rcx, %rax
    cmpq $0, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -328(%rbp)
    movq -328(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_prefix_then22
    jmp .Lvt_cmd_prefix_else23
.Lvt_cmd_prefix_then7:
    movq $1, %rax
    movq %rax, -336(%rbp)
    movq $0, %rax
    movq %rax, -344(%rbp)
    movq -344(%rbp), %rax
    pushq %rax
    movq -336(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    subq %rcx, %rax
    movq %rax, -352(%rbp)
    movq -352(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_cmd_prefix_else8:
    jmp .Lvt_cmd_prefix_join9
.Lvt_cmd_prefix_join9:
    movq -24(%rbp), %rax
    movq %rax, -360(%rbp)
    movq -96(%rbp), %rax
    movq %rax, -368(%rbp)
    movq -360(%rbp), %rax
    pushq %rax
    movq -368(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_char_at
    movq %rax, -376(%rbp)
    movq -376(%rbp), %rax
    movq %rax, -384(%rbp)
    movq -384(%rbp), %rax
    movq %rax, -392(%rbp)
    movq -392(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_is_ws
    movq %rax, -400(%rbp)
    movq -400(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_prefix_then10
    jmp .Lvt_cmd_prefix_else11
.Lvt_cmd_prefix_then10:
    movq -32(%rbp), %rax
    movq %rax, -408(%rbp)
    movq -200(%rbp), %rax
    movq %rax, -416(%rbp)
    movq -408(%rbp), %rax
    pushq %rax
    movq -416(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_char_at
    movq %rax, -424(%rbp)
    movq $32, %rax
    movq %rax, -432(%rbp)
    movq -424(%rbp), %rax
    pushq %rax
    movq -432(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -440(%rbp)
    movq -440(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_prefix_then13
    jmp .Lvt_cmd_prefix_else14
.Lvt_cmd_prefix_else11:
    movq -32(%rbp), %rax
    movq %rax, -448(%rbp)
    movq -200(%rbp), %rax
    movq %rax, -456(%rbp)
    movq -448(%rbp), %rax
    pushq %rax
    movq -456(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_char_at
    movq %rax, -464(%rbp)
    movq -384(%rbp), %rax
    movq %rax, -472(%rbp)
    movq -464(%rbp), %rax
    pushq %rax
    movq -472(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -480(%rbp)
    movq -480(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_prefix_then19
    jmp .Lvt_cmd_prefix_else20
.Lvt_cmd_prefix_join12:
    jmp .Lvt_cmd_prefix_loop4
.Lvt_cmd_prefix_then13:
    movq $1, %rax
    movq %rax, -488(%rbp)
    movq $0, %rax
    movq %rax, -496(%rbp)
    movq -496(%rbp), %rax
    pushq %rax
    movq -488(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    subq %rcx, %rax
    movq %rax, -504(%rbp)
    movq -504(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_cmd_prefix_else14:
    jmp .Lvt_cmd_prefix_join15
.Lvt_cmd_prefix_join15:
    movq -200(%rbp), %rax
    movq %rax, -512(%rbp)
    movq $1, %rax
    movq %rax, -520(%rbp)
    movq -512(%rbp), %rax
    pushq %rax
    movq -520(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    addq %rcx, %rax
    movq %rax, -528(%rbp)
    movq -528(%rbp), %rax
    movq %rax, -200(%rbp)
    jmp .Lvt_cmd_prefix_loop16
.Lvt_cmd_prefix_loop16:
    movq -96(%rbp), %rax
    movq %rax, -536(%rbp)
    movq -56(%rbp), %rax
    movq %rax, -544(%rbp)
    movq -536(%rbp), %rax
    pushq %rax
    movq -544(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setl %al
    movzbq %al, %rax
    movq %rax, -552(%rbp)
    movq -24(%rbp), %rax
    movq %rax, -560(%rbp)
    movq -96(%rbp), %rax
    movq %rax, -568(%rbp)
    movq -560(%rbp), %rax
    pushq %rax
    movq -568(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_char_at
    movq %rax, -576(%rbp)
    movq -576(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_is_ws
    movq %rax, -584(%rbp)
    movq -552(%rbp), %rax
    pushq %rax
    movq -584(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    andq %rcx, %rax
    cmpq $0, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -592(%rbp)
    movq -592(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_cmd_prefix_body17
    jmp .Lvt_cmd_prefix_end18
.Lvt_cmd_prefix_body17:
    movq -96(%rbp), %rax
    movq %rax, -600(%rbp)
    movq $1, %rax
    movq %rax, -608(%rbp)
    movq -600(%rbp), %rax
    pushq %rax
    movq -608(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    addq %rcx, %rax
    movq %rax, -616(%rbp)
    movq -616(%rbp), %rax
    movq %rax, -96(%rbp)
    jmp .Lvt_cmd_prefix_loop16
.Lvt_cmd_prefix_end18:
    jmp .Lvt_cmd_prefix_join12
.Lvt_cmd_prefix_then19:
    movq $1, %rax
    movq %rax, -624(%rbp)
    movq $0, %rax
    movq %rax, -632(%rbp)
    movq -632(%rbp), %rax
    pushq %rax
    movq -624(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    subq %rcx, %rax
    movq %rax, -640(%rbp)
    movq -640(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_cmd_prefix_else20:
    jmp .Lvt_cmd_prefix_join21
.Lvt_cmd_prefix_join21:
    movq -200(%rbp), %rax
    movq %rax, -648(%rbp)
    movq $1, %rax
    movq %rax, -656(%rbp)
    movq -648(%rbp), %rax
    pushq %rax
    movq -656(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    addq %rcx, %rax
    movq %rax, -664(%rbp)
    movq -664(%rbp), %rax
    movq %rax, -200(%rbp)
    movq -96(%rbp), %rax
    movq %rax, -672(%rbp)
    movq $1, %rax
    movq %rax, -680(%rbp)
    movq -672(%rbp), %rax
    pushq %rax
    movq -680(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    addq %rcx, %rax
    movq %rax, -688(%rbp)
    movq -688(%rbp), %rax
    movq %rax, -96(%rbp)
    jmp .Lvt_cmd_prefix_join12
.Lvt_cmd_prefix_then22:
    movq $1, %rax
    movq %rax, -696(%rbp)
    movq $0, %rax
    movq %rax, -704(%rbp)
    movq -704(%rbp), %rax
    pushq %rax
    movq -696(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    subq %rcx, %rax
    movq %rax, -712(%rbp)
    movq -712(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_cmd_prefix_else23:
    jmp .Lvt_cmd_prefix_join24
.Lvt_cmd_prefix_join24:
    movq -96(%rbp), %rax
    movq %rax, -720(%rbp)
    movq -720(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_run_extra -----
.globl vt_run_extra
vt_run_extra:
    pushq %rbp
    movq %rsp, %rbp
    subq $608, %rsp
    movq %rdi, -8(%rbp)
.Lvt_run_extra_entry:
    movq -8(%rbp), %rax
    movq %rax, -16(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -24(%rbp)
    leaq .Lstr0(%rip), %rax
    movq %rax, -32(%rbp)
    movq -24(%rbp), %rax
    pushq %rax
    movq -32(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_prefix
    movq %rax, -40(%rbp)
    movq -40(%rbp), %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -56(%rbp)
    movq $0, %rax
    movq %rax, -64(%rbp)
    movq -56(%rbp), %rax
    pushq %rax
    movq -64(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setge %al
    movzbq %al, %rax
    movq %rax, -72(%rbp)
    movq -72(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_run_extra_then1
    jmp .Lvt_run_extra_else2
.Lvt_run_extra_then1:
    movq $1, %rax
    movq %rax, -80(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -88(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -96(%rbp)
    movq -88(%rbp), %rax
    pushq %rax
    movq -96(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_skip
    movq %rax, -104(%rbp)
    movq -80(%rbp), %rax
    pushq %rax
    movq -104(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_os_cmd
    movq %rax, -112(%rbp)
    movq $1, %rax
    movq %rax, -120(%rbp)
    movq -120(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_run_extra_else2:
    jmp .Lvt_run_extra_join3
.Lvt_run_extra_join3:
    movq -16(%rbp), %rax
    movq %rax, -128(%rbp)
    leaq .Lstr1(%rip), %rax
    movq %rax, -136(%rbp)
    movq -128(%rbp), %rax
    pushq %rax
    movq -136(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_prefix
    movq %rax, -144(%rbp)
    movq -144(%rbp), %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -152(%rbp)
    movq $0, %rax
    movq %rax, -160(%rbp)
    movq -152(%rbp), %rax
    pushq %rax
    movq -160(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setge %al
    movzbq %al, %rax
    movq %rax, -168(%rbp)
    movq -168(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_run_extra_then4
    jmp .Lvt_run_extra_else5
.Lvt_run_extra_then4:
    movq $2, %rax
    movq %rax, -176(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -184(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -192(%rbp)
    movq -184(%rbp), %rax
    pushq %rax
    movq -192(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_skip
    movq %rax, -200(%rbp)
    movq -176(%rbp), %rax
    pushq %rax
    movq -200(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_os_cmd
    movq %rax, -208(%rbp)
    movq $1, %rax
    movq %rax, -216(%rbp)
    movq -216(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_run_extra_else5:
    jmp .Lvt_run_extra_join6
.Lvt_run_extra_join6:
    movq -16(%rbp), %rax
    movq %rax, -224(%rbp)
    leaq .Lstr2(%rip), %rax
    movq %rax, -232(%rbp)
    movq -224(%rbp), %rax
    pushq %rax
    movq -232(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_prefix
    movq %rax, -240(%rbp)
    movq -240(%rbp), %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -248(%rbp)
    movq $0, %rax
    movq %rax, -256(%rbp)
    movq -248(%rbp), %rax
    pushq %rax
    movq -256(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setge %al
    movzbq %al, %rax
    movq %rax, -264(%rbp)
    movq -264(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_run_extra_then7
    jmp .Lvt_run_extra_else8
.Lvt_run_extra_then7:
    movq $3, %rax
    movq %rax, -272(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -280(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -288(%rbp)
    movq -280(%rbp), %rax
    pushq %rax
    movq -288(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_skip
    movq %rax, -296(%rbp)
    movq -272(%rbp), %rax
    pushq %rax
    movq -296(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_os_cmd
    movq %rax, -304(%rbp)
    movq $1, %rax
    movq %rax, -312(%rbp)
    movq -312(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_run_extra_else8:
    jmp .Lvt_run_extra_join9
.Lvt_run_extra_join9:
    movq -16(%rbp), %rax
    movq %rax, -320(%rbp)
    leaq .Lstr3(%rip), %rax
    movq %rax, -328(%rbp)
    movq -320(%rbp), %rax
    pushq %rax
    movq -328(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_prefix
    movq %rax, -336(%rbp)
    movq -336(%rbp), %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -344(%rbp)
    movq $0, %rax
    movq %rax, -352(%rbp)
    movq -344(%rbp), %rax
    pushq %rax
    movq -352(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setge %al
    movzbq %al, %rax
    movq %rax, -360(%rbp)
    movq -360(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_run_extra_then10
    jmp .Lvt_run_extra_else11
.Lvt_run_extra_then10:
    movq $4, %rax
    movq %rax, -368(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -376(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -384(%rbp)
    movq -376(%rbp), %rax
    pushq %rax
    movq -384(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_skip
    movq %rax, -392(%rbp)
    movq -368(%rbp), %rax
    pushq %rax
    movq -392(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_os_cmd
    movq %rax, -400(%rbp)
    movq $1, %rax
    movq %rax, -408(%rbp)
    movq -408(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_run_extra_else11:
    jmp .Lvt_run_extra_join12
.Lvt_run_extra_join12:
    movq -16(%rbp), %rax
    movq %rax, -416(%rbp)
    leaq .Lstr4(%rip), %rax
    movq %rax, -424(%rbp)
    movq -416(%rbp), %rax
    pushq %rax
    movq -424(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_prefix
    movq %rax, -432(%rbp)
    movq -432(%rbp), %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -440(%rbp)
    movq $0, %rax
    movq %rax, -448(%rbp)
    movq -440(%rbp), %rax
    pushq %rax
    movq -448(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setge %al
    movzbq %al, %rax
    movq %rax, -456(%rbp)
    movq -456(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_run_extra_then13
    jmp .Lvt_run_extra_else14
.Lvt_run_extra_then13:
    movq $5, %rax
    movq %rax, -464(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -472(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -480(%rbp)
    movq -472(%rbp), %rax
    pushq %rax
    movq -480(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_skip
    movq %rax, -488(%rbp)
    movq -464(%rbp), %rax
    pushq %rax
    movq -488(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_os_cmd
    movq %rax, -496(%rbp)
    movq $1, %rax
    movq %rax, -504(%rbp)
    movq -504(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_run_extra_else14:
    jmp .Lvt_run_extra_join15
.Lvt_run_extra_join15:
    movq -16(%rbp), %rax
    movq %rax, -512(%rbp)
    leaq .Lstr5(%rip), %rax
    movq %rax, -520(%rbp)
    movq -512(%rbp), %rax
    pushq %rax
    movq -520(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_prefix
    movq %rax, -528(%rbp)
    movq -528(%rbp), %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -536(%rbp)
    movq $0, %rax
    movq %rax, -544(%rbp)
    movq -536(%rbp), %rax
    pushq %rax
    movq -544(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setge %al
    movzbq %al, %rax
    movq %rax, -552(%rbp)
    movq -552(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_run_extra_then16
    jmp .Lvt_run_extra_else17
.Lvt_run_extra_then16:
    movq $6, %rax
    movq %rax, -560(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -568(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -576(%rbp)
    movq -568(%rbp), %rax
    pushq %rax
    movq -576(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_skip
    movq %rax, -584(%rbp)
    movq -560(%rbp), %rax
    pushq %rax
    movq -584(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_os_cmd
    movq %rax, -592(%rbp)
    movq $1, %rax
    movq %rax, -600(%rbp)
    movq -600(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_run_extra_else17:
    jmp .Lvt_run_extra_join18
.Lvt_run_extra_join18:
    movq $0, %rax
    movq %rax, -608(%rbp)
    movq -608(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_is_blank -----
.globl vt_is_blank
vt_is_blank:
    pushq %rbp
    movq %rsp, %rbp
    subq $176, %rsp
    movq %rdi, -8(%rbp)
.Lvt_is_blank_entry:
    movq -8(%rbp), %rax
    movq %rax, -16(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -24(%rbp)
    movq -24(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_rt_str_len
    movq %rax, -32(%rbp)
    movq -32(%rbp), %rax
    movq %rax, -40(%rbp)
    movq $0, %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -56(%rbp)
    jmp .Lvt_is_blank_loop1
.Lvt_is_blank_loop1:
    movq -56(%rbp), %rax
    movq %rax, -64(%rbp)
    movq -40(%rbp), %rax
    movq %rax, -72(%rbp)
    movq -64(%rbp), %rax
    pushq %rax
    movq -72(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setl %al
    movzbq %al, %rax
    movq %rax, -80(%rbp)
    movq -80(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_is_blank_body2
    jmp .Lvt_is_blank_end3
.Lvt_is_blank_body2:
    movq -16(%rbp), %rax
    movq %rax, -88(%rbp)
    movq -56(%rbp), %rax
    movq %rax, -96(%rbp)
    movq -88(%rbp), %rax
    pushq %rax
    movq -96(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_rt_str_char_at
    movq %rax, -104(%rbp)
    movq -104(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_is_ws
    movq %rax, -112(%rbp)
    movq $0, %rax
    movq %rax, -120(%rbp)
    movq -112(%rbp), %rax
    pushq %rax
    movq -120(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -128(%rbp)
    movq -128(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_is_blank_then4
    jmp .Lvt_is_blank_else5
.Lvt_is_blank_end3:
    movq $1, %rax
    movq %rax, -136(%rbp)
    movq -136(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_is_blank_then4:
    movq $0, %rax
    movq %rax, -144(%rbp)
    movq -144(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_is_blank_else5:
    jmp .Lvt_is_blank_join6
.Lvt_is_blank_join6:
    movq -56(%rbp), %rax
    movq %rax, -152(%rbp)
    movq $1, %rax
    movq %rax, -160(%rbp)
    movq -152(%rbp), %rax
    pushq %rax
    movq -160(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    addq %rcx, %rax
    movq %rax, -168(%rbp)
    movq -168(%rbp), %rax
    movq %rax, -56(%rbp)
    jmp .Lvt_is_blank_loop1

# ----- vt_spaces -----
.globl vt_spaces
vt_spaces:
    pushq %rbp
    movq %rsp, %rbp
    subq $112, %rsp
    movq %rdi, -8(%rbp)
.Lvt_spaces_entry:
    movq -8(%rbp), %rax
    movq %rax, -16(%rbp)
    movq $0, %rax
    movq %rax, -24(%rbp)
    movq -24(%rbp), %rax
    movq %rax, -32(%rbp)
    jmp .Lvt_spaces_loop1
.Lvt_spaces_loop1:
    movq -32(%rbp), %rax
    movq %rax, -40(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -48(%rbp)
    movq -40(%rbp), %rax
    pushq %rax
    movq -48(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setl %al
    movzbq %al, %rax
    movq %rax, -56(%rbp)
    movq -56(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_spaces_body2
    jmp .Lvt_spaces_end3
.Lvt_spaces_body2:
    leaq .Lstr6(%rip), %rax
    movq %rax, -64(%rbp)
    movq -64(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_print_cstr
    movq $0, %rax
    movq %rax, -72(%rbp)
    movq -32(%rbp), %rax
    movq %rax, -80(%rbp)
    movq $1, %rax
    movq %rax, -88(%rbp)
    movq -80(%rbp), %rax
    pushq %rax
    movq -88(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    addq %rcx, %rax
    movq %rax, -96(%rbp)
    movq -96(%rbp), %rax
    movq %rax, -32(%rbp)
    jmp .Lvt_spaces_loop1
.Lvt_spaces_end3:
    movq $0, %rax
    movq %rax, -104(%rbp)
    movq -104(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_digits -----
.globl vt_digits
vt_digits:
    pushq %rbp
    movq %rsp, %rbp
    subq $128, %rsp
    movq %rdi, -8(%rbp)
.Lvt_digits_entry:
    movq -8(%rbp), %rax
    movq %rax, -16(%rbp)
    movq $1, %rax
    movq %rax, -24(%rbp)
    movq -24(%rbp), %rax
    movq %rax, -32(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -40(%rbp)
    movq -40(%rbp), %rax
    movq %rax, -48(%rbp)
    jmp .Lvt_digits_loop1
.Lvt_digits_loop1:
    movq -48(%rbp), %rax
    movq %rax, -56(%rbp)
    movq $10, %rax
    movq %rax, -64(%rbp)
    movq -56(%rbp), %rax
    pushq %rax
    movq -64(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setge %al
    movzbq %al, %rax
    movq %rax, -72(%rbp)
    movq -72(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_digits_body2
    jmp .Lvt_digits_end3
.Lvt_digits_body2:
    movq -48(%rbp), %rax
    movq %rax, -80(%rbp)
    movq $10, %rax
    movq %rax, -88(%rbp)
    movq -80(%rbp), %rax
    pushq %rax
    movq -88(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cqto
    idivq %rcx
    movq %rax, -96(%rbp)
    movq -96(%rbp), %rax
    movq %rax, -48(%rbp)
    movq -32(%rbp), %rax
    movq %rax, -104(%rbp)
    movq $1, %rax
    movq %rax, -112(%rbp)
    movq -104(%rbp), %rax
    pushq %rax
    movq -112(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    addq %rcx, %rax
    movq %rax, -120(%rbp)
    movq -120(%rbp), %rax
    movq %rax, -32(%rbp)
    jmp .Lvt_digits_loop1
.Lvt_digits_end3:
    movq -32(%rbp), %rax
    movq %rax, -128(%rbp)
    movq -128(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_pad2 -----
.globl vt_pad2
vt_pad2:
    pushq %rbp
    movq %rsp, %rbp
    subq $80, %rsp
    movq %rdi, -8(%rbp)
.Lvt_pad2_entry:
    movq -8(%rbp), %rax
    movq %rax, -16(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -24(%rbp)
    movq $10, %rax
    movq %rax, -32(%rbp)
    movq -24(%rbp), %rax
    pushq %rax
    movq -32(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setl %al
    movzbq %al, %rax
    movq %rax, -40(%rbp)
    movq -40(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_pad2_then1
    jmp .Lvt_pad2_else2
.Lvt_pad2_then1:
    leaq .Lstr7(%rip), %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_print_cstr
    movq $0, %rax
    movq %rax, -56(%rbp)
    jmp .Lvt_pad2_join3
.Lvt_pad2_else2:
    jmp .Lvt_pad2_join3
.Lvt_pad2_join3:
    movq -16(%rbp), %rax
    movq %rax, -64(%rbp)
    movq -64(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_print_i64
    movq $0, %rax
    movq %rax, -72(%rbp)
    movq $0, %rax
    movq %rax, -80(%rbp)
    movq -80(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_banner -----
.globl vt_banner
vt_banner:
    pushq %rbp
    movq %rsp, %rbp
    subq $64, %rsp
.Lvt_banner_entry:
    leaq .Lstr8(%rip), %rax
    movq %rax, -8(%rbp)
    movq -8(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -16(%rbp)
    leaq .Lstr9(%rip), %rax
    movq %rax, -24(%rbp)
    movq -24(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -32(%rbp)
    leaq .Lstr10(%rip), %rax
    movq %rax, -40(%rbp)
    movq -40(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -48(%rbp)
    movq $0, %rax
    movq %rax, -56(%rbp)
    movq -56(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_set_view -----
.globl vt_set_view
vt_set_view:
    pushq %rbp
    movq %rsp, %rbp
    subq $48, %rsp
    movq %rdi, -8(%rbp)
.Lvt_set_view_entry:
    movq -8(%rbp), %rax
    movq %rax, -16(%rbp)
    movq $0, %rax
    movq %rax, -24(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -32(%rbp)
    movq -24(%rbp), %rax
    pushq %rax
    movq -32(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_os_state_set
    movq %rax, -40(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_cmd_help -----
.globl vt_cmd_help
vt_cmd_help:
    pushq %rbp
    movq %rsp, %rbp
    subq $336, %rsp
.Lvt_cmd_help_entry:
    leaq .Lstr11(%rip), %rax
    movq %rax, -8(%rbp)
    movq -8(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -16(%rbp)
    leaq .Lstr12(%rip), %rax
    movq %rax, -24(%rbp)
    movq -24(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -32(%rbp)
    leaq .Lstr13(%rip), %rax
    movq %rax, -40(%rbp)
    movq -40(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -48(%rbp)
    leaq .Lstr14(%rip), %rax
    movq %rax, -56(%rbp)
    movq -56(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -64(%rbp)
    leaq .Lstr15(%rip), %rax
    movq %rax, -72(%rbp)
    movq -72(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -80(%rbp)
    leaq .Lstr16(%rip), %rax
    movq %rax, -88(%rbp)
    movq -88(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -96(%rbp)
    leaq .Lstr17(%rip), %rax
    movq %rax, -104(%rbp)
    movq -104(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -112(%rbp)
    leaq .Lstr18(%rip), %rax
    movq %rax, -120(%rbp)
    movq -120(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -128(%rbp)
    leaq .Lstr19(%rip), %rax
    movq %rax, -136(%rbp)
    movq -136(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -144(%rbp)
    leaq .Lstr20(%rip), %rax
    movq %rax, -152(%rbp)
    movq -152(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -160(%rbp)
    leaq .Lstr21(%rip), %rax
    movq %rax, -168(%rbp)
    movq -168(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -176(%rbp)
    leaq .Lstr22(%rip), %rax
    movq %rax, -184(%rbp)
    movq -184(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -192(%rbp)
    leaq .Lstr23(%rip), %rax
    movq %rax, -200(%rbp)
    movq -200(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -208(%rbp)
    leaq .Lstr24(%rip), %rax
    movq %rax, -216(%rbp)
    movq -216(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -224(%rbp)
    leaq .Lstr10(%rip), %rax
    movq %rax, -232(%rbp)
    movq -232(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -240(%rbp)
    leaq .Lstr25(%rip), %rax
    movq %rax, -248(%rbp)
    movq -248(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -256(%rbp)
    leaq .Lstr26(%rip), %rax
    movq %rax, -264(%rbp)
    movq -264(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -272(%rbp)
    leaq .Lstr27(%rip), %rax
    movq %rax, -280(%rbp)
    movq -280(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -288(%rbp)
    leaq .Lstr28(%rip), %rax
    movq %rax, -296(%rbp)
    movq -296(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -304(%rbp)
    leaq .Lstr29(%rip), %rax
    movq %rax, -312(%rbp)
    movq -312(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -320(%rbp)
    movq $0, %rax
    movq %rax, -328(%rbp)
    movq -328(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_release04_info -----
.globl vt_release04_info
vt_release04_info:
    pushq %rbp
    movq %rsp, %rbp
    subq $512, %rsp
    movq %rdi, -8(%rbp)
.Lvt_release04_info_entry:
    movq -8(%rbp), %rax
    movq %rax, -16(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -24(%rbp)
    leaq .Lstr30(%rip), %rax
    movq %rax, -32(%rbp)
    movq -24(%rbp), %rax
    pushq %rax
    movq -32(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -40(%rbp)
    movq -40(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_release04_info_then1
    jmp .Lvt_release04_info_else2
.Lvt_release04_info_then1:
    leaq .Lstr31(%rip), %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -56(%rbp)
    movq $1, %rax
    movq %rax, -64(%rbp)
    movq -64(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_release04_info_else2:
    jmp .Lvt_release04_info_join3
.Lvt_release04_info_join3:
    movq -16(%rbp), %rax
    movq %rax, -72(%rbp)
    leaq .Lstr32(%rip), %rax
    movq %rax, -80(%rbp)
    movq -72(%rbp), %rax
    pushq %rax
    movq -80(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -88(%rbp)
    movq -88(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_release04_info_then4
    jmp .Lvt_release04_info_else5
.Lvt_release04_info_then4:
    leaq .Lstr33(%rip), %rax
    movq %rax, -96(%rbp)
    movq -96(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -104(%rbp)
    movq $1, %rax
    movq %rax, -112(%rbp)
    movq -112(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_release04_info_else5:
    jmp .Lvt_release04_info_join6
.Lvt_release04_info_join6:
    movq -16(%rbp), %rax
    movq %rax, -120(%rbp)
    leaq .Lstr34(%rip), %rax
    movq %rax, -128(%rbp)
    movq -120(%rbp), %rax
    pushq %rax
    movq -128(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -136(%rbp)
    movq -136(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_release04_info_then7
    jmp .Lvt_release04_info_else8
.Lvt_release04_info_then7:
    leaq .Lstr35(%rip), %rax
    movq %rax, -144(%rbp)
    movq -144(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -152(%rbp)
    movq $1, %rax
    movq %rax, -160(%rbp)
    movq -160(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_release04_info_else8:
    jmp .Lvt_release04_info_join9
.Lvt_release04_info_join9:
    movq -16(%rbp), %rax
    movq %rax, -168(%rbp)
    leaq .Lstr36(%rip), %rax
    movq %rax, -176(%rbp)
    movq -168(%rbp), %rax
    pushq %rax
    movq -176(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -184(%rbp)
    movq -184(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_release04_info_then10
    jmp .Lvt_release04_info_else11
.Lvt_release04_info_then10:
    leaq .Lstr37(%rip), %rax
    movq %rax, -192(%rbp)
    movq -192(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -200(%rbp)
    movq $1, %rax
    movq %rax, -208(%rbp)
    movq -208(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_release04_info_else11:
    jmp .Lvt_release04_info_join12
.Lvt_release04_info_join12:
    movq -16(%rbp), %rax
    movq %rax, -216(%rbp)
    leaq .Lstr38(%rip), %rax
    movq %rax, -224(%rbp)
    movq -216(%rbp), %rax
    pushq %rax
    movq -224(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -232(%rbp)
    movq -232(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_release04_info_then13
    jmp .Lvt_release04_info_else14
.Lvt_release04_info_then13:
    leaq .Lstr39(%rip), %rax
    movq %rax, -240(%rbp)
    movq -240(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -248(%rbp)
    movq $1, %rax
    movq %rax, -256(%rbp)
    movq -256(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_release04_info_else14:
    jmp .Lvt_release04_info_join15
.Lvt_release04_info_join15:
    movq -16(%rbp), %rax
    movq %rax, -264(%rbp)
    leaq .Lstr40(%rip), %rax
    movq %rax, -272(%rbp)
    movq -264(%rbp), %rax
    pushq %rax
    movq -272(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -280(%rbp)
    movq -280(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_release04_info_then16
    jmp .Lvt_release04_info_else17
.Lvt_release04_info_then16:
    leaq .Lstr41(%rip), %rax
    movq %rax, -288(%rbp)
    movq -288(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -296(%rbp)
    movq $1, %rax
    movq %rax, -304(%rbp)
    movq -304(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_release04_info_else17:
    jmp .Lvt_release04_info_join18
.Lvt_release04_info_join18:
    movq -16(%rbp), %rax
    movq %rax, -312(%rbp)
    leaq .Lstr42(%rip), %rax
    movq %rax, -320(%rbp)
    movq -312(%rbp), %rax
    pushq %rax
    movq -320(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -328(%rbp)
    movq -328(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_release04_info_then19
    jmp .Lvt_release04_info_else20
.Lvt_release04_info_then19:
    leaq .Lstr43(%rip), %rax
    movq %rax, -336(%rbp)
    movq -336(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -344(%rbp)
    movq $1, %rax
    movq %rax, -352(%rbp)
    movq -352(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_release04_info_else20:
    jmp .Lvt_release04_info_join21
.Lvt_release04_info_join21:
    movq -16(%rbp), %rax
    movq %rax, -360(%rbp)
    leaq .Lstr44(%rip), %rax
    movq %rax, -368(%rbp)
    movq -360(%rbp), %rax
    pushq %rax
    movq -368(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -376(%rbp)
    movq -376(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_release04_info_then22
    jmp .Lvt_release04_info_else23
.Lvt_release04_info_then22:
    leaq .Lstr45(%rip), %rax
    movq %rax, -384(%rbp)
    movq -384(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -392(%rbp)
    movq $1, %rax
    movq %rax, -400(%rbp)
    movq -400(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_release04_info_else23:
    jmp .Lvt_release04_info_join24
.Lvt_release04_info_join24:
    movq -16(%rbp), %rax
    movq %rax, -408(%rbp)
    leaq .Lstr46(%rip), %rax
    movq %rax, -416(%rbp)
    movq -408(%rbp), %rax
    pushq %rax
    movq -416(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -424(%rbp)
    movq -424(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_release04_info_then25
    jmp .Lvt_release04_info_else26
.Lvt_release04_info_then25:
    leaq .Lstr47(%rip), %rax
    movq %rax, -432(%rbp)
    movq -432(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -440(%rbp)
    movq $1, %rax
    movq %rax, -448(%rbp)
    movq -448(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_release04_info_else26:
    jmp .Lvt_release04_info_join27
.Lvt_release04_info_join27:
    movq -16(%rbp), %rax
    movq %rax, -456(%rbp)
    leaq .Lstr48(%rip), %rax
    movq %rax, -464(%rbp)
    movq -456(%rbp), %rax
    pushq %rax
    movq -464(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -472(%rbp)
    movq -472(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_release04_info_then28
    jmp .Lvt_release04_info_else29
.Lvt_release04_info_then28:
    leaq .Lstr49(%rip), %rax
    movq %rax, -480(%rbp)
    movq -480(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -488(%rbp)
    movq $1, %rax
    movq %rax, -496(%rbp)
    movq -496(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_release04_info_else29:
    jmp .Lvt_release04_info_join30
.Lvt_release04_info_join30:
    movq $0, %rax
    movq %rax, -504(%rbp)
    movq -504(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_render_processes -----
.globl vt_render_processes
vt_render_processes:
    pushq %rbp
    movq %rsp, %rbp
    subq $768, %rsp
.Lvt_render_processes_entry:
    call vex_os_out_clear
    movq %rax, -8(%rbp)
    leaq .Lstr50(%rip), %rax
    movq %rax, -16(%rbp)
    movq -16(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -24(%rbp)
    leaq .Lstr10(%rip), %rax
    movq %rax, -32(%rbp)
    movq -32(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -40(%rbp)
    leaq .Lstr51(%rip), %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_print_cstr
    movq $0, %rax
    movq %rax, -56(%rbp)
    movq $4, %rax
    movq %rax, -64(%rbp)
    movq -64(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_spaces
    movq %rax, -72(%rbp)
    leaq .Lstr52(%rip), %rax
    movq %rax, -80(%rbp)
    movq -80(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_print_cstr
    movq $0, %rax
    movq %rax, -88(%rbp)
    movq $14, %rax
    movq %rax, -96(%rbp)
    movq -96(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_spaces
    movq %rax, -104(%rbp)
    leaq .Lstr53(%rip), %rax
    movq %rax, -112(%rbp)
    movq -112(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_print_cstr
    movq $0, %rax
    movq %rax, -120(%rbp)
    movq $8, %rax
    movq %rax, -128(%rbp)
    movq -128(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_spaces
    movq %rax, -136(%rbp)
    leaq .Lstr54(%rip), %rax
    movq %rax, -144(%rbp)
    movq -144(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -152(%rbp)
    call vex_os_now_ms
    movq %rax, -160(%rbp)
    movq -160(%rbp), %rax
    movq %rax, -168(%rbp)
    call vex_os_app_count
    movq %rax, -176(%rbp)
    movq -176(%rbp), %rax
    movq %rax, -184(%rbp)
    movq $0, %rax
    movq %rax, -192(%rbp)
    movq -192(%rbp), %rax
    movq %rax, -200(%rbp)
    jmp .Lvt_render_processes_loop1
.Lvt_render_processes_loop1:
    movq -200(%rbp), %rax
    movq %rax, -208(%rbp)
    movq -184(%rbp), %rax
    movq %rax, -216(%rbp)
    movq -208(%rbp), %rax
    pushq %rax
    movq -216(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setl %al
    movzbq %al, %rax
    movq %rax, -224(%rbp)
    movq -224(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_render_processes_body2
    jmp .Lvt_render_processes_end3
.Lvt_render_processes_body2:
    movq -200(%rbp), %rax
    movq %rax, -232(%rbp)
    movq -232(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_app_id
    movq %rax, -240(%rbp)
    movq -240(%rbp), %rax
    movq %rax, -248(%rbp)
    movq -248(%rbp), %rax
    movq %rax, -256(%rbp)
    movq -256(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_print_i64
    movq $0, %rax
    movq %rax, -264(%rbp)
    movq $6, %rax
    movq %rax, -272(%rbp)
    movq -248(%rbp), %rax
    movq %rax, -280(%rbp)
    movq -280(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_digits
    movq %rax, -288(%rbp)
    movq -272(%rbp), %rax
    pushq %rax
    movq -288(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    subq %rcx, %rax
    movq %rax, -296(%rbp)
    movq -296(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_spaces
    movq %rax, -304(%rbp)
    movq -200(%rbp), %rax
    movq %rax, -312(%rbp)
    movq -312(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_app_name
    movq %rax, -320(%rbp)
    movq -320(%rbp), %rax
    movq %rax, -328(%rbp)
    movq -328(%rbp), %rax
    movq %rax, -336(%rbp)
    movq -336(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_print_cstr
    movq $0, %rax
    movq %rax, -344(%rbp)
    movq $18, %rax
    movq %rax, -352(%rbp)
    movq -328(%rbp), %rax
    movq %rax, -360(%rbp)
    movq -360(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_rt_str_len
    movq %rax, -368(%rbp)
    movq -352(%rbp), %rax
    pushq %rax
    movq -368(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    subq %rcx, %rax
    movq %rax, -376(%rbp)
    movq -376(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_spaces
    movq %rax, -384(%rbp)
    movq -200(%rbp), %rax
    movq %rax, -392(%rbp)
    movq -392(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_app_kind
    movq %rax, -400(%rbp)
    movq -400(%rbp), %rax
    movq %rax, -408(%rbp)
    movq -408(%rbp), %rax
    movq %rax, -416(%rbp)
    movq -416(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_print_cstr
    movq $0, %rax
    movq %rax, -424(%rbp)
    movq $12, %rax
    movq %rax, -432(%rbp)
    movq -408(%rbp), %rax
    movq %rax, -440(%rbp)
    movq -440(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_rt_str_len
    movq %rax, -448(%rbp)
    movq -432(%rbp), %rax
    pushq %rax
    movq -448(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    subq %rcx, %rax
    movq %rax, -456(%rbp)
    movq -456(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_spaces
    movq %rax, -464(%rbp)
    movq -168(%rbp), %rax
    movq %rax, -472(%rbp)
    movq -200(%rbp), %rax
    movq %rax, -480(%rbp)
    movq -480(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_app_started_ms
    movq %rax, -488(%rbp)
    movq -472(%rbp), %rax
    pushq %rax
    movq -488(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    subq %rcx, %rax
    movq %rax, -496(%rbp)
    movq $1000, %rax
    movq %rax, -504(%rbp)
    movq -496(%rbp), %rax
    pushq %rax
    movq -504(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cqto
    idivq %rcx
    movq %rax, -512(%rbp)
    movq -512(%rbp), %rax
    movq %rax, -520(%rbp)
    movq -520(%rbp), %rax
    movq %rax, -528(%rbp)
    movq $3600, %rax
    movq %rax, -536(%rbp)
    movq -528(%rbp), %rax
    pushq %rax
    movq -536(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cqto
    idivq %rcx
    movq %rax, -544(%rbp)
    movq -544(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_pad2
    movq %rax, -552(%rbp)
    leaq .Lstr55(%rip), %rax
    movq %rax, -560(%rbp)
    movq -560(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_print_cstr
    movq $0, %rax
    movq %rax, -568(%rbp)
    movq -520(%rbp), %rax
    movq %rax, -576(%rbp)
    movq $60, %rax
    movq %rax, -584(%rbp)
    movq -576(%rbp), %rax
    pushq %rax
    movq -584(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cqto
    idivq %rcx
    movq %rax, -592(%rbp)
    movq $60, %rax
    movq %rax, -600(%rbp)
    movq -592(%rbp), %rax
    pushq %rax
    movq -600(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cqto
    idivq %rcx
    movq %rdx, %rax
    movq %rax, -608(%rbp)
    movq -608(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_pad2
    movq %rax, -616(%rbp)
    leaq .Lstr55(%rip), %rax
    movq %rax, -624(%rbp)
    movq -624(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_print_cstr
    movq $0, %rax
    movq %rax, -632(%rbp)
    movq -520(%rbp), %rax
    movq %rax, -640(%rbp)
    movq $60, %rax
    movq %rax, -648(%rbp)
    movq -640(%rbp), %rax
    pushq %rax
    movq -648(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cqto
    idivq %rcx
    movq %rdx, %rax
    movq %rax, -656(%rbp)
    movq -656(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_pad2
    movq %rax, -664(%rbp)
    leaq .Lstr10(%rip), %rax
    movq %rax, -672(%rbp)
    movq -672(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -680(%rbp)
    movq -200(%rbp), %rax
    movq %rax, -688(%rbp)
    movq $1, %rax
    movq %rax, -696(%rbp)
    movq -688(%rbp), %rax
    pushq %rax
    movq -696(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    addq %rcx, %rax
    movq %rax, -704(%rbp)
    movq -704(%rbp), %rax
    movq %rax, -200(%rbp)
    jmp .Lvt_render_processes_loop1
.Lvt_render_processes_end3:
    leaq .Lstr10(%rip), %rax
    movq %rax, -712(%rbp)
    movq -712(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -720(%rbp)
    movq -184(%rbp), %rax
    movq %rax, -728(%rbp)
    movq -728(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_print_i64
    movq $0, %rax
    movq %rax, -736(%rbp)
    leaq .Lstr56(%rip), %rax
    movq %rax, -744(%rbp)
    movq -744(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -752(%rbp)
    movq $0, %rax
    movq %rax, -760(%rbp)
    movq -760(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_enter_processes -----
.globl vt_enter_processes
vt_enter_processes:
    pushq %rbp
    movq %rsp, %rbp
    subq $64, %rsp
.Lvt_enter_processes_entry:
    movq $1, %rax
    movq %rax, -8(%rbp)
    movq -8(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_set_view
    movq %rax, -16(%rbp)
    movq $0, %rax
    movq %rax, -24(%rbp)
    movq -24(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_buf_clear
    movq %rax, -32(%rbp)
    call vt_render_processes
    movq %rax, -40(%rbp)
    movq $1000, %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_timer_start
    movq %rax, -56(%rbp)
    movq $1, %rax
    movq %rax, -64(%rbp)
    movq -64(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_enter_input_test -----
.globl vt_enter_input_test
vt_enter_input_test:
    pushq %rbp
    movq %rsp, %rbp
    subq $128, %rsp
.Lvt_enter_input_test_entry:
    movq $2, %rax
    movq %rax, -8(%rbp)
    movq -8(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_set_view
    movq %rax, -16(%rbp)
    call vex_os_out_clear
    movq %rax, -24(%rbp)
    movq $0, %rax
    movq %rax, -32(%rbp)
    movq -32(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_buf_clear
    movq %rax, -40(%rbp)
    movq $1, %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_buf_clear
    movq %rax, -56(%rbp)
    leaq .Lstr57(%rip), %rax
    movq %rax, -64(%rbp)
    movq -64(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -72(%rbp)
    leaq .Lstr58(%rip), %rax
    movq %rax, -80(%rbp)
    movq -80(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -88(%rbp)
    leaq .Lstr59(%rip), %rax
    movq %rax, -96(%rbp)
    movq -96(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -104(%rbp)
    leaq .Lstr10(%rip), %rax
    movq %rax, -112(%rbp)
    movq -112(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -120(%rbp)
    movq $1, %rax
    movq %rax, -128(%rbp)
    movq -128(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_leave_to_terminal -----
.globl vt_leave_to_terminal
vt_leave_to_terminal:
    pushq %rbp
    movq %rsp, %rbp
    subq $64, %rsp
.Lvt_leave_to_terminal_entry:
    call vex_os_timer_stop
    movq %rax, -8(%rbp)
    movq $0, %rax
    movq %rax, -16(%rbp)
    movq -16(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_set_view
    movq %rax, -24(%rbp)
    movq $1, %rax
    movq %rax, -32(%rbp)
    movq -32(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_buf_clear
    movq %rax, -40(%rbp)
    call vex_os_out_clear
    movq %rax, -48(%rbp)
    call vt_banner
    movq %rax, -56(%rbp)
    movq $1, %rax
    movq %rax, -64(%rbp)
    movq -64(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_run_line -----
.globl vt_run_line
vt_run_line:
    pushq %rbp
    movq %rsp, %rbp
    subq $464, %rsp
.Lvt_run_line_entry:
    movq $0, %rax
    movq %rax, -8(%rbp)
    movq -8(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_buf_text
    movq %rax, -16(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -24(%rbp)
    movq -24(%rbp), %rax
    movq %rax, -32(%rbp)
    leaq .Lstr5(%rip), %rax
    movq %rax, -40(%rbp)
    movq -32(%rbp), %rax
    pushq %rax
    movq -40(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_prefix
    movq %rax, -48(%rbp)
    movq $0, %rax
    movq %rax, -56(%rbp)
    movq -48(%rbp), %rax
    pushq %rax
    movq -56(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setge %al
    movzbq %al, %rax
    movq %rax, -64(%rbp)
    movq -64(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_run_line_then1
    jmp .Lvt_run_line_else2
.Lvt_run_line_then1:
    leaq .Lstr60(%rip), %rax
    movq %rax, -72(%rbp)
    movq -72(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -80(%rbp)
    jmp .Lvt_run_line_join3
.Lvt_run_line_else2:
    leaq .Lstr61(%rip), %rax
    movq %rax, -88(%rbp)
    movq -88(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_print_cstr
    movq $0, %rax
    movq %rax, -96(%rbp)
    movq -24(%rbp), %rax
    movq %rax, -104(%rbp)
    movq -104(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -112(%rbp)
    jmp .Lvt_run_line_join3
.Lvt_run_line_join3:
    movq $1, %rax
    movq %rax, -120(%rbp)
    movq -120(%rbp), %rax
    movq %rax, -128(%rbp)
    movq -24(%rbp), %rax
    movq %rax, -136(%rbp)
    movq -136(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_is_blank
    movq %rax, -144(%rbp)
    movq -144(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_run_line_then4
    jmp .Lvt_run_line_else5
.Lvt_run_line_then4:
    movq $1, %rax
    movq %rax, -152(%rbp)
    movq -152(%rbp), %rax
    movq %rax, -128(%rbp)
    jmp .Lvt_run_line_join6
.Lvt_run_line_else5:
    movq -24(%rbp), %rax
    movq %rax, -160(%rbp)
    leaq .Lstr62(%rip), %rax
    movq %rax, -168(%rbp)
    movq -160(%rbp), %rax
    pushq %rax
    movq -168(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -176(%rbp)
    movq -176(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_run_line_then7
    jmp .Lvt_run_line_else8
.Lvt_run_line_join6:
    movq $0, %rax
    movq %rax, -184(%rbp)
    movq -184(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_buf_clear
    movq %rax, -192(%rbp)
    movq -128(%rbp), %rax
    movq %rax, -200(%rbp)
    movq -200(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_run_line_then7:
    movq $0, %rax
    movq %rax, -208(%rbp)
    movq -208(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_buf_clear
    movq %rax, -216(%rbp)
    call vt_cmd_help
    movq %rax, -224(%rbp)
    jmp .Lvt_run_line_join9
.Lvt_run_line_else8:
    movq -24(%rbp), %rax
    movq %rax, -232(%rbp)
    leaq .Lstr63(%rip), %rax
    movq %rax, -240(%rbp)
    movq -232(%rbp), %rax
    pushq %rax
    movq -240(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -248(%rbp)
    movq -248(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_run_line_then10
    jmp .Lvt_run_line_else11
.Lvt_run_line_join9:
    jmp .Lvt_run_line_join6
.Lvt_run_line_then10:
    call vt_enter_processes
    movq %rax, -256(%rbp)
    movq -256(%rbp), %rax
    movq %rax, -128(%rbp)
    jmp .Lvt_run_line_join12
.Lvt_run_line_else11:
    movq -24(%rbp), %rax
    movq %rax, -264(%rbp)
    leaq .Lstr64(%rip), %rax
    movq %rax, -272(%rbp)
    movq -264(%rbp), %rax
    pushq %rax
    movq -272(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -280(%rbp)
    movq -280(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_run_line_then13
    jmp .Lvt_run_line_else14
.Lvt_run_line_join12:
    jmp .Lvt_run_line_join9
.Lvt_run_line_then13:
    call vt_enter_input_test
    movq %rax, -288(%rbp)
    movq -288(%rbp), %rax
    movq %rax, -128(%rbp)
    jmp .Lvt_run_line_join15
.Lvt_run_line_else14:
    movq -24(%rbp), %rax
    movq %rax, -296(%rbp)
    leaq .Lstr65(%rip), %rax
    movq %rax, -304(%rbp)
    movq -296(%rbp), %rax
    pushq %rax
    movq -304(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -312(%rbp)
    movq -312(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_run_line_then16
    jmp .Lvt_run_line_else17
.Lvt_run_line_join15:
    jmp .Lvt_run_line_join12
.Lvt_run_line_then16:
    movq $0, %rax
    movq %rax, -320(%rbp)
    movq -320(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_buf_clear
    movq %rax, -328(%rbp)
    call vex_os_out_clear
    movq %rax, -336(%rbp)
    jmp .Lvt_run_line_join18
.Lvt_run_line_else17:
    movq -24(%rbp), %rax
    movq %rax, -344(%rbp)
    leaq .Lstr66(%rip), %rax
    movq %rax, -352(%rbp)
    movq -344(%rbp), %rax
    pushq %rax
    movq -352(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vt_cmd_is
    movq %rax, -360(%rbp)
    movq -360(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_run_line_then19
    jmp .Lvt_run_line_else20
.Lvt_run_line_join18:
    jmp .Lvt_run_line_join15
.Lvt_run_line_then19:
    movq $2, %rax
    movq %rax, -368(%rbp)
    movq -368(%rbp), %rax
    movq %rax, -128(%rbp)
    jmp .Lvt_run_line_join21
.Lvt_run_line_else20:
    movq -24(%rbp), %rax
    movq %rax, -376(%rbp)
    movq -376(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_release04_info
    movq %rax, -384(%rbp)
    movq $0, %rax
    movq %rax, -392(%rbp)
    movq -384(%rbp), %rax
    pushq %rax
    movq -392(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -400(%rbp)
    movq -24(%rbp), %rax
    movq %rax, -408(%rbp)
    movq -408(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_run_extra
    movq %rax, -416(%rbp)
    movq $0, %rax
    movq %rax, -424(%rbp)
    movq -416(%rbp), %rax
    pushq %rax
    movq -424(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -432(%rbp)
    movq -400(%rbp), %rax
    pushq %rax
    movq -432(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    andq %rcx, %rax
    cmpq $0, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -440(%rbp)
    movq -440(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_run_line_then22
    jmp .Lvt_run_line_else23
.Lvt_run_line_join21:
    jmp .Lvt_run_line_join18
.Lvt_run_line_then22:
    leaq .Lstr67(%rip), %rax
    movq %rax, -448(%rbp)
    movq -448(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -456(%rbp)
    jmp .Lvt_run_line_join24
.Lvt_run_line_else23:
    jmp .Lvt_run_line_join24
.Lvt_run_line_join24:
    jmp .Lvt_run_line_join21

# ----- vt_init -----
.globl vt_init
vt_init:
    pushq %rbp
    movq %rsp, %rbp
    subq $80, %rsp
.Lvt_init_entry:
    call vex_os_timer_stop
    movq %rax, -8(%rbp)
    movq $0, %rax
    movq %rax, -16(%rbp)
    movq -16(%rbp), %rax
    pushq %rax
    popq %rdi
    call vt_set_view
    movq %rax, -24(%rbp)
    movq $0, %rax
    movq %rax, -32(%rbp)
    movq -32(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_buf_clear
    movq %rax, -40(%rbp)
    movq $1, %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_buf_clear
    movq %rax, -56(%rbp)
    call vex_os_out_clear
    movq %rax, -64(%rbp)
    call vt_banner
    movq %rax, -72(%rbp)
    movq $1, %rax
    movq %rax, -80(%rbp)
    movq -80(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_on_key -----
.globl vt_on_key
vt_on_key:
    pushq %rbp
    movq %rsp, %rbp
    subq $656, %rsp
    movq %rdi, -8(%rbp)
    movq %rsi, -16(%rbp)
.Lvt_on_key_entry:
    movq -8(%rbp), %rax
    movq %rax, -24(%rbp)
    movq -16(%rbp), %rax
    movq %rax, -32(%rbp)
    movq $0, %rax
    movq %rax, -40(%rbp)
    movq -40(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_state_get
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rax, -56(%rbp)
    movq -56(%rbp), %rax
    movq %rax, -64(%rbp)
    movq $1, %rax
    movq %rax, -72(%rbp)
    movq -64(%rbp), %rax
    pushq %rax
    movq -72(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -80(%rbp)
    movq -80(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_on_key_then1
    jmp .Lvt_on_key_else2
.Lvt_on_key_then1:
    movq -24(%rbp), %rax
    movq %rax, -88(%rbp)
    movq $41, %rax
    movq %rax, -96(%rbp)
    movq -88(%rbp), %rax
    pushq %rax
    movq -96(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -104(%rbp)
    movq -32(%rbp), %rax
    movq %rax, -112(%rbp)
    movq $113, %rax
    movq %rax, -120(%rbp)
    movq -112(%rbp), %rax
    pushq %rax
    movq -120(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -128(%rbp)
    movq -104(%rbp), %rax
    pushq %rax
    movq -128(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    orq %rcx, %rax
    cmpq $0, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -136(%rbp)
    movq -136(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_on_key_then4
    jmp .Lvt_on_key_else5
.Lvt_on_key_else2:
    jmp .Lvt_on_key_join3
.Lvt_on_key_join3:
    movq -56(%rbp), %rax
    movq %rax, -144(%rbp)
    movq $2, %rax
    movq %rax, -152(%rbp)
    movq -144(%rbp), %rax
    pushq %rax
    movq -152(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -160(%rbp)
    movq -160(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_on_key_then7
    jmp .Lvt_on_key_else8
.Lvt_on_key_then4:
    call vt_leave_to_terminal
    movq %rax, -168(%rbp)
    movq -168(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_on_key_else5:
    jmp .Lvt_on_key_join6
.Lvt_on_key_join6:
    movq $0, %rax
    movq %rax, -176(%rbp)
    movq -176(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_on_key_then7:
    movq -24(%rbp), %rax
    movq %rax, -184(%rbp)
    movq $41, %rax
    movq %rax, -192(%rbp)
    movq -184(%rbp), %rax
    pushq %rax
    movq -192(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -200(%rbp)
    movq -200(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_on_key_then10
    jmp .Lvt_on_key_else11
.Lvt_on_key_else8:
    jmp .Lvt_on_key_join9
.Lvt_on_key_join9:
    movq -24(%rbp), %rax
    movq %rax, -208(%rbp)
    movq $41, %rax
    movq %rax, -216(%rbp)
    movq -208(%rbp), %rax
    pushq %rax
    movq -216(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -224(%rbp)
    movq -224(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_on_key_then22
    jmp .Lvt_on_key_else23
.Lvt_on_key_then10:
    call vt_leave_to_terminal
    movq %rax, -232(%rbp)
    movq -232(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_on_key_else11:
    jmp .Lvt_on_key_join12
.Lvt_on_key_join12:
    movq -24(%rbp), %rax
    movq %rax, -240(%rbp)
    movq $42, %rax
    movq %rax, -248(%rbp)
    movq -240(%rbp), %rax
    pushq %rax
    movq -248(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -256(%rbp)
    movq -256(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_on_key_then13
    jmp .Lvt_on_key_else14
.Lvt_on_key_then13:
    movq $1, %rax
    movq %rax, -264(%rbp)
    movq -264(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_buf_pop
    movq %rax, -272(%rbp)
    movq $1, %rax
    movq %rax, -280(%rbp)
    movq -280(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_on_key_else14:
    jmp .Lvt_on_key_join15
.Lvt_on_key_join15:
    movq -24(%rbp), %rax
    movq %rax, -288(%rbp)
    movq $40, %rax
    movq %rax, -296(%rbp)
    movq -288(%rbp), %rax
    pushq %rax
    movq -296(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -304(%rbp)
    movq -304(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_on_key_then16
    jmp .Lvt_on_key_else17
.Lvt_on_key_then16:
    leaq .Lstr68(%rip), %rax
    movq %rax, -312(%rbp)
    movq -312(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_print_cstr
    movq $0, %rax
    movq %rax, -320(%rbp)
    movq $1, %rax
    movq %rax, -328(%rbp)
    movq -328(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_buf_text
    movq %rax, -336(%rbp)
    movq -336(%rbp), %rax
    movq %rax, %rdi
    call vex_rt_println_cstr
    movq $0, %rax
    movq %rax, -344(%rbp)
    movq $1, %rax
    movq %rax, -352(%rbp)
    movq -352(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_buf_clear
    movq %rax, -360(%rbp)
    movq $1, %rax
    movq %rax, -368(%rbp)
    movq -368(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_on_key_else17:
    jmp .Lvt_on_key_join18
.Lvt_on_key_join18:
    movq -32(%rbp), %rax
    movq %rax, -376(%rbp)
    movq $32, %rax
    movq %rax, -384(%rbp)
    movq -376(%rbp), %rax
    pushq %rax
    movq -384(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setge %al
    movzbq %al, %rax
    movq %rax, -392(%rbp)
    movq -32(%rbp), %rax
    movq %rax, -400(%rbp)
    movq $127, %rax
    movq %rax, -408(%rbp)
    movq -400(%rbp), %rax
    pushq %rax
    movq -408(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setl %al
    movzbq %al, %rax
    movq %rax, -416(%rbp)
    movq -392(%rbp), %rax
    pushq %rax
    movq -416(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    andq %rcx, %rax
    cmpq $0, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -424(%rbp)
    movq -424(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_on_key_then19
    jmp .Lvt_on_key_else20
.Lvt_on_key_then19:
    movq $1, %rax
    movq %rax, -432(%rbp)
    movq -32(%rbp), %rax
    movq %rax, -440(%rbp)
    movq -432(%rbp), %rax
    pushq %rax
    movq -440(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_os_buf_push
    movq %rax, -448(%rbp)
    movq $1, %rax
    movq %rax, -456(%rbp)
    movq -456(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_on_key_else20:
    jmp .Lvt_on_key_join21
.Lvt_on_key_join21:
    movq $0, %rax
    movq %rax, -464(%rbp)
    movq -464(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_on_key_then22:
    movq $2, %rax
    movq %rax, -472(%rbp)
    movq -472(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_on_key_else23:
    jmp .Lvt_on_key_join24
.Lvt_on_key_join24:
    movq -24(%rbp), %rax
    movq %rax, -480(%rbp)
    movq $42, %rax
    movq %rax, -488(%rbp)
    movq -480(%rbp), %rax
    pushq %rax
    movq -488(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -496(%rbp)
    movq -496(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_on_key_then25
    jmp .Lvt_on_key_else26
.Lvt_on_key_then25:
    movq $0, %rax
    movq %rax, -504(%rbp)
    movq -504(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_buf_pop
    movq %rax, -512(%rbp)
    movq $1, %rax
    movq %rax, -520(%rbp)
    movq -520(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_on_key_else26:
    jmp .Lvt_on_key_join27
.Lvt_on_key_join27:
    movq -24(%rbp), %rax
    movq %rax, -528(%rbp)
    movq $40, %rax
    movq %rax, -536(%rbp)
    movq -528(%rbp), %rax
    pushq %rax
    movq -536(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -544(%rbp)
    movq -544(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_on_key_then28
    jmp .Lvt_on_key_else29
.Lvt_on_key_then28:
    call vt_run_line
    movq %rax, -552(%rbp)
    movq -552(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_on_key_else29:
    jmp .Lvt_on_key_join30
.Lvt_on_key_join30:
    movq -32(%rbp), %rax
    movq %rax, -560(%rbp)
    movq $32, %rax
    movq %rax, -568(%rbp)
    movq -560(%rbp), %rax
    pushq %rax
    movq -568(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setge %al
    movzbq %al, %rax
    movq %rax, -576(%rbp)
    movq -32(%rbp), %rax
    movq %rax, -584(%rbp)
    movq $127, %rax
    movq %rax, -592(%rbp)
    movq -584(%rbp), %rax
    pushq %rax
    movq -592(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    setl %al
    movzbq %al, %rax
    movq %rax, -600(%rbp)
    movq -576(%rbp), %rax
    pushq %rax
    movq -600(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    andq %rcx, %rax
    cmpq $0, %rax
    setne %al
    movzbq %al, %rax
    movq %rax, -608(%rbp)
    movq -608(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_on_key_then31
    jmp .Lvt_on_key_else32
.Lvt_on_key_then31:
    movq $0, %rax
    movq %rax, -616(%rbp)
    movq -32(%rbp), %rax
    movq %rax, -624(%rbp)
    movq -616(%rbp), %rax
    pushq %rax
    movq -624(%rbp), %rax
    pushq %rax
    popq %rsi
    popq %rdi
    call vex_os_buf_push
    movq %rax, -632(%rbp)
    movq $1, %rax
    movq %rax, -640(%rbp)
    movq -640(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_on_key_else32:
    jmp .Lvt_on_key_join33
.Lvt_on_key_join33:
    movq $0, %rax
    movq %rax, -648(%rbp)
    movq -648(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- vt_on_tick -----
.globl vt_on_tick
vt_on_tick:
    pushq %rbp
    movq %rsp, %rbp
    subq $64, %rsp
.Lvt_on_tick_entry:
    movq $0, %rax
    movq %rax, -8(%rbp)
    movq -8(%rbp), %rax
    pushq %rax
    popq %rdi
    call vex_os_state_get
    movq %rax, -16(%rbp)
    movq $1, %rax
    movq %rax, -24(%rbp)
    movq -16(%rbp), %rax
    pushq %rax
    movq -24(%rbp), %rax
    movq %rax, %rcx
    popq %rax
    cmpq %rcx, %rax
    sete %al
    movzbq %al, %rax
    movq %rax, -32(%rbp)
    movq -32(%rbp), %rax
    cmpq $0, %rax
    jne .Lvt_on_tick_then1
    jmp .Lvt_on_tick_else2
.Lvt_on_tick_then1:
    call vt_render_processes
    movq %rax, -40(%rbp)
    movq $1, %rax
    movq %rax, -48(%rbp)
    movq -48(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret
.Lvt_on_tick_else2:
    jmp .Lvt_on_tick_join3
.Lvt_on_tick_join3:
    call vex_os_timer_stop
    movq %rax, -56(%rbp)
    movq $0, %rax
    movq %rax, -64(%rbp)
    movq -64(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

# ----- main -----
.globl main
main:
    pushq %rbp
    movq %rsp, %rbp
    subq $16, %rsp
.Lmain_entry:
    movq $0, %rax
    movq %rax, -8(%rbp)
    movq -8(%rbp), %rax
    movq %rbp, %rsp
    popq %rbp
    ret

.section .rodata
.Lstr0:
    .asciz "v. open"
.Lstr1:
    .asciz "v. close"
.Lstr2:
    .asciz "v. search"
.Lstr3:
    .asciz "v. audio test"
.Lstr4:
    .asciz "v. change users"
.Lstr5:
    .asciz "v. add user"
.Lstr6:
    .asciz " "
.Lstr7:
    .asciz "0"
.Lstr8:
    .asciz "Verminal  (VexScript application)"
.Lstr9:
    .asciz "Type `v. help` for a list of commands."
.Lstr10:
    .asciz ""
.Lstr11:
    .asciz "Available commands:"
.Lstr12:
    .asciz "  v. help        Show this help."
.Lstr13:
    .asciz "  v. processes   Show tracked applications (refreshes every 1 s)."
.Lstr14:
    .asciz "  v. input test  Open the interactive text-input test."
.Lstr15:
    .asciz "  v. open <app>        Open, restore or focus an app (v. open Valbook)."
.Lstr16:
    .asciz "  v. close <app>       Close an app; asks first if it has unsaved work."
.Lstr17:
    .asciz "  v. search <name>     Find files/folders you can read by name."
.Lstr18:
    .asciz "  v. audio test        Beep the PC speaker (audible only if the host routes it)."
.Lstr19:
    .asciz "  v. change users      Lock the session and sign in as another user."
.Lstr20:
    .asciz "  v. add user <name> <password>   Administrators only."
.Lstr21:
    .asciz "  v. version | v. status | v. horizon | v. zen | v. security"
.Lstr22:
    .asciz "  v. usb | v. drivers | v. storage | v. ai | v. roadmap"
.Lstr23:
    .asciz "Quote names with spaces:  v. open \"File Explorer\""
.Lstr24:
    .asciz "Also: v. clear (clear the screen), v. exit (close the terminal)."
.Lstr25:
    .asciz "Navigation:"
.Lstr26:
    .asciz "  In `v. processes` or `v. input test`: press Esc to return here."
.Lstr27:
    .asciz "  In the terminal: press Esc, run `v. exit`, or click the X to close."
.Lstr28:
    .asciz "Note: `v. processes` lists applications tracked by the desktop shell,"
.Lstr29:
    .asciz "not a kernel process table."
.Lstr30:
    .asciz "v. version"
.Lstr31:
    .asciz "VEX OS Release 04 (Zen Horizon preview), based on Release 03."
.Lstr32:
    .asciz "v. status"
.Lstr33:
    .asciz "Status: desktop shell, PS/2 input, RAM VFS and PC speaker are active. Network, persistence and USB drivers are unavailable."
.Lstr34:
    .asciz "v. horizon"
.Lstr35:
    .asciz "Zen Horizon: the Release-04 dark horizon palette and window chrome are active."
.Lstr36:
    .asciz "v. zen"
.Lstr37:
    .asciz "Zen Horizon is visual only; it does not add a compositor, display driver or persistence."
.Lstr38:
    .asciz "v. security"
.Lstr39:
    .asciz "Security: local accounts, password hashing and the existing SECURITY-02 checks remain enabled."
.Lstr40:
    .asciz "v. usb"
.Lstr41:
    .asciz "USB boot can be validated in QEMU through UEFI USB mass storage. The kernel has no USB driver."
.Lstr42:
    .asciz "v. drivers"
.Lstr43:
    .asciz "Drivers: PS/2 keyboard/mouse and PC speaker only. No USB, HDA, AC97, network or display driver."
.Lstr44:
    .asciz "v. storage"
.Lstr45:
    .asciz "Storage: RAM filesystem only; files and settings are volatile after reboot."
.Lstr46:
    .asciz "v. ai"
.Lstr47:
    .asciz "VEX AI 1.5 Crystal is available only through the Release-04 host bridge, not inside this kernel."
.Lstr48:
    .asciz "v. roadmap"
.Lstr49:
    .asciz "Next hardening: USB controller/storage drivers, persistent storage, and a native AI runtime ABI."
.Lstr50:
    .asciz "Applications tracked by the desktop shell        (Esc: back to terminal)"
.Lstr51:
    .asciz "ID"
.Lstr52:
    .asciz "NAME"
.Lstr53:
    .asciz "TYPE"
.Lstr54:
    .asciz "UPTIME"
.Lstr55:
    .asciz ":"
.Lstr56:
    .asciz " application(s). Updates every 1 second while this view is open."
.Lstr57:
    .asciz "Input test.  Type anything; it is shown live on the input line below."
.Lstr58:
    .asciz "  Backspace edits    Enter submits (and clears the line)    Esc returns"
.Lstr59:
    .asciz "  Input is 7-bit ASCII: letters, digits, space and punctuation."
.Lstr60:
    .asciz "> v. add user ********"
.Lstr61:
    .asciz "> "
.Lstr62:
    .asciz "v. help"
.Lstr63:
    .asciz "v. processes"
.Lstr64:
    .asciz "v. input test"
.Lstr65:
    .asciz "v. clear"
.Lstr66:
    .asciz "v. exit"
.Lstr67:
    .asciz "Unknown command. Type `v. help` for available commands."
.Lstr68:
    .asciz "You typed: "

