; Vex OS - kernel/src/arch/x86_64/idt/isr_stubs.asm
;
; Generates one stub per IDT vector (0-255) and a common trampoline
; that saves registers and calls idt_common_handler(InterruptFrame*).
;
; Vectors 8, 10, 11, 12, 13, 14, 17, 21 push a hardware error code;
; all others do not. To give the C handler one consistent frame
; shape regardless of vector, every no-error-code stub pushes a dummy
; 0 in the error code's place before pushing the vector number.
;
; Stack layout at the moment isr_common's C call executes (ascending
; from RSP - see kernel/include/idt.h's InterruptFrame, which this
; must stay in exact lockstep with):
;
;   r15 r14 r13 r12 r11 r10 r9 r8 rbp rdi rsi rdx rcx rbx rax
;   vector  error_code
;   rip  cs  rflags  rsp  ss          <- pushed by the CPU itself
;
; (SS:RSP is unconditionally pushed by the CPU in 64-bit mode even
; without a privilege-level change - Intel SDM Vol.3 6.14.2.)

BITS 64

extern idt_common_handler

section .text

%macro ISR_NOERR 1
global isr_stub_%1
isr_stub_%1:
    push qword 0        ; dummy error code, keeps frame shape uniform
    push qword %1        ; vector number
    jmp isr_common
%endmacro

%macro ISR_ERR 1
global isr_stub_%1
isr_stub_%1:
    push qword %1        ; vector number (real error code already on stack)
    jmp isr_common
%endmacro

; --- CPU exceptions, vectors 0-31 ---
ISR_NOERR 0   ; #DE  Divide Error
ISR_NOERR 1   ; #DB  Debug
ISR_NOERR 2   ; NMI
ISR_NOERR 3   ; #BP  Breakpoint (used by idt_self_test)
ISR_NOERR 4   ; #OF  Overflow
ISR_NOERR 5   ; #BR  Bound Range Exceeded
ISR_NOERR 6   ; #UD  Invalid Opcode
ISR_NOERR 7   ; #NM  Device Not Available
ISR_ERR   8   ; #DF  Double Fault (uses IST1, see gdt.c)
ISR_NOERR 9   ; Coprocessor Segment Overrun (legacy, unused on x86-64)
ISR_ERR   10  ; #TS  Invalid TSS
ISR_ERR   11  ; #NP  Segment Not Present
ISR_ERR   12  ; #SS  Stack-Segment Fault
ISR_ERR   13  ; #GP  General Protection Fault
ISR_ERR   14  ; #PF  Page Fault
ISR_NOERR 15  ; Reserved
ISR_NOERR 16  ; #MF  x87 Floating-Point Exception
ISR_ERR   17  ; #AC  Alignment Check
ISR_NOERR 18  ; #MC  Machine Check
ISR_NOERR 19  ; #XM  SIMD Floating-Point Exception
ISR_NOERR 20  ; #VE  Virtualization Exception
ISR_ERR   21  ; #CP  Control Protection Exception
ISR_NOERR 22
ISR_NOERR 23
ISR_NOERR 24
ISR_NOERR 25
ISR_NOERR 26
ISR_NOERR 27
ISR_NOERR 28
ISR_NOERR 29  ; #VC  VMM Communication (AMD SEV-ES) - treated as no-error here for simplicity
ISR_NOERR 30  ; #SX  Security Exception - same simplification
ISR_NOERR 31  ; Reserved

; --- Vectors 32-255: no external interrupts are expected (interrupts
; are never enabled with `sti` in BOOT-02A), so these exist purely as
; a defensive catch-all in case something unexpected (e.g. an NMI
; routed oddly, or firmware SMI-adjacent behavior) reaches here. ---
%assign i 32
%rep 224
    ISR_NOERR i
%assign i i+1
%endrep

; --- Common trampoline ---
isr_common:
    ; SECURITY-02: GS base discipline for Ring 3. The kernel reaches its
    ; per-CPU block through %gs:0 (IA32_GS_BASE, see percpu.c). While
    ; Ring 3 runs, IA32_GS_BASE holds the USER value and the kernel's
    ; per-CPU pointer sits in IA32_KERNEL_GS_BASE; `swapgs` exchanges
    ; them. Doing it only when the interrupted code was Ring 3 (saved CS
    ; RPL != 0) means every interrupt that arrives from Ring 0 - which is
    ; every interrupt that existed before SECURITY-02 - takes the
    ; not-taken branch and behaves byte-for-byte as before. Without this,
    ; Ring 3 could reload GS (mov gs, ax resets the base to 0) and the
    ; next interrupt would run kernel code reading %gs:0 from address 0.
    ; Stack at this point: [rsp]=vector [rsp+8]=error_code [rsp+16]=rip
    ; [rsp+24]=cs (hardware frame, always 5 qwords in long mode).
    test qword [rsp + 24], 3
    jz .entered_from_kernel
    swapgs
.entered_from_kernel:
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15

    mov rdi, rsp             ; InterruptFrame* argument (System V: arg1 = rdi)
    call idt_common_handler

    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    add rsp, 16               ; discard vector + error_code
    ; SECURITY-02: mirror of the entry swap - restore the user GS base
    ; only when returning to Ring 3. Saved CS is now at [rsp+8].
    test qword [rsp + 8], 3
    jz .returning_to_kernel
    swapgs
.returning_to_kernel:
    iretq

; --- IDT load helper ---
global idt_load
idt_load:
    lidt [rdi]
    ret

; --- Stub address table, so idt.c can install all 256 gates without
; 256 hand-written extern declarations. One qword per vector, in
; vector order. ---
section .rodata
global isr_stub_table
isr_stub_table:
%assign i 0
%rep 256
    dq isr_stub_ %+ i
%assign i i+1
%endrep

section .note.GNU-stack noalloc noexec nowrite progbits
