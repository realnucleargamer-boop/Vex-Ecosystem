#include "cpuacct.h"
static uint64_t tsc(void) { uint32_t lo, hi; __asm__ volatile("rdtsc" : "=a"(lo), "=d"(hi)); return ((uint64_t)hi << 32) | lo; }
static uint64_t idle_acc, idle_since, last_tsc, last_idle; static int in_idle;
void cpuacct_init(void) { idle_acc = 0; in_idle = 0; last_tsc = tsc(); last_idle = 0; }
void cpuacct_idle_begin(void) { idle_since = tsc(); in_idle = 1; }
void cpuacct_idle_end(void) { if (in_idle) { idle_acc += tsc() - idle_since; in_idle = 0; } }
uint32_t cpuacct_permille(uint64_t elapsed, uint64_t idle)
{
    if (elapsed == 0) return 0;
    if (idle >= elapsed) return 0;
    uint64_t busy = elapsed - idle;
    /* avoid 64-bit overflow of busy*1000: scale down when large */
    while (busy > (~0ull) / 1000u) { busy >>= 1; elapsed >>= 1; if (!elapsed) return 1000; }
    uint64_t p = busy * 1000u / elapsed; return p > 1000 ? 1000 : (uint32_t)p;
}
int cpuacct_sample(uint32_t *out)
{
    uint64_t now = tsc(), el = now - last_tsc, id = idle_acc - last_idle;
    if (el < 1000) return 0;
    *out = cpuacct_permille(el, id); last_tsc = now; last_idle = idle_acc; return 1;
}
