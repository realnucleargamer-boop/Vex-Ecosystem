#!/usr/bin/env bash
# Vex OS - scripts/run-qemu.sh
#
# Launches the integrated BOOT-03 baseline in QEMU + OVMF. Per Development Rule 6, this is the
# ONLY sanctioned way to test boot code until VM bring-up is stable -
# never test on real hardware yet.
#
# Requires: qemu-system-x86_64, an OVMF firmware build (OVMF_CODE.fd /
# OVMF_VARS.fd). On Debian/Ubuntu: `apt install qemu-system-x86 ovmf`.
# Common OVMF paths differ by distro; adjust OVMF_DIR below if needed.

set -euo pipefail

IMG="build/vexos.img"

OVMF_DIR="${OVMF_DIR:-/usr/share/OVMF}"
# Verified filenames on Ubuntu 24.04 (package `ovmf`): OVMF_CODE_4M.fd /
# OVMF_VARS_4M.fd. Other distros may still use the plain OVMF_CODE.fd /
# OVMF_VARS.fd names - override via OVMF_CODE/OVMF_VARS env vars if so.
OVMF_CODE="${OVMF_CODE:-$OVMF_DIR/OVMF_CODE_4M.fd}"
OVMF_VARS_SRC="${OVMF_VARS:-$OVMF_DIR/OVMF_VARS_4M.fd}"
OVMF_VARS_LOCAL="build/OVMF_VARS.local.fd"

if [ ! -f "$IMG" ]; then
    echo "error: $IMG not found - run 'make image' first" >&2
    exit 1
fi

if [ ! -f "$OVMF_CODE" ] || [ ! -f "$OVMF_VARS_SRC" ]; then
    echo "error: OVMF firmware not found at $OVMF_DIR" >&2
    echo "  install it (e.g. 'apt install ovmf') or set OVMF_DIR/OVMF_CODE/OVMF_VARS" >&2
    exit 1
fi

# Use a local writable copy of OVMF_VARS so the repo's/system's copy
# is never mutated by NVRAM writes during test boots.
cp -n "$OVMF_VARS_SRC" "$OVMF_VARS_LOCAL" 2>/dev/null || true

# Default to 4 virtual CPUs so ACPI/MADT detection (BOOT-02B) has
# more than one CPU to actually find. Override with VEXOS_SMP=N if
# needed - BOOT-02B only detects CPUs, it doesn't start them yet, so
# any count here is safe.
SMP="${VEXOS_SMP:-4}"

# STORAGE-01: optional persistent data disk (a SECOND SATA disk). VEXOS_DATA_DISK=path attaches it, creating a blank 16 MiB file if missing.
# Run `v. storage format` once (administrator) in Verminal to use it; the boot image itself is never written by the kernel.
DATA_ARGS=()
if [ -n "${VEXOS_DATA_DISK:-}" ]; then
    [ -e "$VEXOS_DATA_DISK" ] || truncate -s 16M "$VEXOS_DATA_DISK"
    DATA_ARGS=(-drive format=raw,file="$VEXOS_DATA_DISK")
fi

exec qemu-system-x86_64 \
    -machine q35,accel=tcg \
    -cpu qemu64 \
    -smp "$SMP" \
    -m 512M \
    -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" \
    -drive if=pflash,format=raw,file="$OVMF_VARS_LOCAL" \
    -drive format=raw,file="$IMG" \
    ${DATA_ARGS[@]+"${DATA_ARGS[@]}"} \
    -serial stdio \
    -no-reboot \
    -no-shutdown
