/*
 * Vex OS - kernel/include/rtc.h
 * Read-only CMOS real-time-clock access (MC146818-compatible, ports 0x70/0x71).
 *
 * This is a WALL CLOCK as the hardware reports it - UTC on QEMU's default
 * `-rtc base=utc`, but the kernel has no timezone support and cannot know
 * what a physical machine's RTC is set to, so callers must label it "RTC".
 * rtc_read() returns 0 (and the UI omits the clock) if the values cannot be
 * validated.
 */
#ifndef VEXOS_RTC_H
#define VEXOS_RTC_H
#include <stdint.h>
typedef struct { uint16_t year; uint8_t month, day, hour, minute, second; } RtcTime;

int rtc_read(RtcTime *out);                 /* 1 = valid time */
/* Pure helpers (unit-tested). */
int rtc_validate(const RtcTime *t);         /* 1 = every field in range incl. days-in-month */
int rtc_weekday(uint16_t y, uint8_t m, uint8_t d); /* 0 = Sunday .. 6 = Saturday */
uint8_t rtc_bcd_to_bin(uint8_t v);
#endif
