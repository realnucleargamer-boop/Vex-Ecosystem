# VexScript Final Native Readiness (Pre–VEX AI 1.0)

**Gate decision: READY FOR VEX AI 1.0** (toolchain only — AI not implemented)

| Component | Version |
|-----------|---------|
| VexScript | **3.2.2** |
| Vex IR | **1.5** |
| VEX-C | **5.1.1** |

## Pipeline

```text
VexScript → Vex IR 1.5 → x86-64 → gcc + vex_rt.c + vex_evo_rt.c → native executable
```

## Native coverage

| Capability | Status |
|------------|--------|
| RNG | **NATIVE** |
| Integer genomes | **NATIVE** |
| String genomes (`from_string`, `char_at`, `set_char`, `to_string`, `slice`, …) | **NATIVE** |
| Text fitness (`genome_match`) | **NATIVE** |
| Fitness set/get/stats | **NATIVE** |
| Streams | **NATIVE** |
| Migration | **NATIVE** |
| Diversity | **NATIVE** |
| Elites | **NATIVE** |
| Tensor / neural | **OPTIONAL** (hosted; not required for evolutionary VEX AI 1.0 foundation) |

## RNG contract

- **Native:** same seed ⇒ same native sequence (deterministic).
- **Hosted:** same seed ⇒ same hosted sequence (deterministic).
- **Cross-backend bitwise identity is not required.**

## 75k-scale results (measured)

| Item | Result |
|------|--------|
| Capacity tested | **75,000** characters in one genome |
| Hard ceiling | **81,920** (`VEX_MAX_GENOME_LEN`); excess fill clamped |
| 75k fill + access + copy + compare | PASS (~0.10 s including compile) |
| Failure behavior | Invalid handles return 0/-1/empty; no crash |

## Multi-stream stress

| Item | Result |
|------|--------|
| 12 independent streams (app-level count) | PASS |
| 16 candidates × 16 dim, 25 generations | PASS |
| Migration + elites | PASS |
| Deterministic repeat | PASS |

## Safety

Bounds checks on genome indices, stream/pop handles, migration indices; capacity clamp; no GC.

## Remaining (non-blocking for starting VEX AI 1.0 in VexScript)

- Larger multi-population tables if 12× large pops exceed fixed C limits  
- Tensor/neural native only if a future AI mode needs them  
- Hosted interpreter still used for interactive/`run` without compile  

## Gate rationale

Core genome (text + integer), fitness, streams, migration, diversity, elites, and RNG execute on the **native** path without Python in the hot path. That is sufficient to implement VEX AI 1.0 evolutionary logic in VexScript.
