/*
 * Vex OS - kernel/include/ps2_mouse.h
 *
 * INPUT-03: polled PS/2 mouse driver (i8042 auxiliary port).
 *
 * WHY POLLED, NOT IRQ12
 *   The PIC is masked and the kernel has no IOAPIC driver (only the LAPIC),
 *   so no legacy ISA IRQ can be delivered today.  The keyboard already runs
 *   polled for exactly this reason (docs/RUNTIME-UPGRADE.md).  Adding an
 *   IOAPIC driver is the correct long-term fix but it changes validated
 *   interrupt routing, which this milestone deliberately does not touch.
 *   The mouse therefore follows the keyboard: everything runs in the BSP
 *   main loop, never in interrupt context, so there is nothing to race.
 *
 * ONE READER FOR PORT 0x60
 *   Keyboard and mouse bytes arrive through the SAME output buffer; status
 *   bit 5 says which device a byte came from.  Two independent pollers would
 *   steal each other's bytes, so ps2_keyboard_poll() is the single reader and
 *   routes aux bytes to ps2_mouse_feed().
 */
#ifndef VEXOS_PS2_MOUSE_H
#define VEXOS_PS2_MOUSE_H
#include <stdint.h>

/* Decoded 3-byte packet (pure data - no hardware access). */
typedef struct {
    int32_t dx;        /* +right */
    int32_t dy;        /* +DOWN (already inverted from the device's +up) */
    uint8_t buttons;   /* VEX_MOUSE_BTN_* */
    int     overflow;  /* device flagged X/Y overflow; movement discarded */
} Ps2MousePacket;

/* Pure: decode b0..b2.  Returns 0 (and fills nothing) if b0 lacks the
 * always-1 sync bit (bit 3) - i.e. the stream is out of step. */
int ps2_mouse_decode(uint8_t b0, uint8_t b1, uint8_t b2, Ps2MousePacket *out);

/* Initialise the aux port + device (reset, defaults, enable reporting).
 * Returns 1 if a mouse answered and is streaming, 0 if none/unusable (the
 * system then runs keyboard-only).  Safe to call with no mouse attached. */
int  ps2_mouse_init(void);
int  ps2_mouse_present(void);

/* Feed one byte that the i8042 flagged as auxiliary-device data.
 * `now_ticks` is timer_ticks() (0 if no timer) and is used only to drop a
 * stale half-packet.  Publishes through input_publish_mouse(). */
void ps2_mouse_feed(uint8_t byte, uint64_t now_ticks);

/* Resets the packet assembler (tests; also on resync). */
void ps2_mouse_reset_decoder(void);

/* Diagnostics. */
uint64_t ps2_mouse_packets(void);
uint64_t ps2_mouse_resyncs(void);
#endif
