# VexScript Acceleration Layer (3.2.3)

## Goal
Speed VEX AI–oriented workloads without pretending a GPU exists when it does not.

## Design
| Feature | Behavior |
|---------|----------|
| **Device** | `device_set(0)=cpu`, `device_set(1)=cuda`; `gpu_available()` |
| **Workers** | Hard cap **1–2** CPU threads (`workers_set` / `workers_get`) |
| **Tensors** | Torch backend when installed; pure list fallback |
| **matmul** | Torch-accelerated in `tensor_matmul` |
| **stream_advance_batch*** | Parallel stream advance on ≤2 cores |

## GPU
If CUDA is available via PyTorch, `device_set(1)` places accel tensors on GPU.
If not, the call returns **-1** and device stays **cpu**. No silent fake GPU.

## Not included
- Full PyTorch API surface
- Autograd / training loops
- VEX AI 1.0 itself
