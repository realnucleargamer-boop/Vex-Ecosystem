"""Validate Vex IR 1.5 modules."""
from __future__ import annotations
from .nodes import ModuleIR, FunctionIR, Instruction
from ..errors import VexError

ARITH = {"add", "sub", "mul", "div", "mod"}
CMP = {"eq", "ne", "lt", "le", "gt", "ge"}
BOOL_BIN = {"and", "or"}
KNOWN = ARITH | CMP | BOOL_BIN | {
    "const", "copy", "not", "call",
    "extract", "insert", "make_struct", "make_array", "index", "index_set",
    "tensor_create", "tensor_add", "tensor_mul", "tensor_matmul", "tensor_dot",
    "tensor_fill", "tensor_get", "tensor_set",
    "load", "store", "load_local", "store_local",
    "ret", "br", "br_cond",
}

TERMINATORS = {"ret", "br", "br_cond"}


def validate_module(mod: ModuleIR) -> None:
    ver = getattr(mod, "ir_version", "1.5")
    if ver not in ("0.1", "1.0", "1.1", "1.2", "1.3", "1.4", "1.5"):
        raise VexError(f"IR: unsupported ir_version '{ver}'", error_code="E0300")
    names = {f.name for f in mod.functions}
    for fn in mod.functions:
        _validate_fn(fn, names)


def _validate_fn(fn: FunctionIR, known_fns: set[str]) -> None:
    block_names = {b.name for b in fn.blocks}
    if len(block_names) != len(fn.blocks):
        raise VexError(f"IR: duplicate block name in @{fn.name}", error_code="E0301")
    if not fn.blocks:
        raise VexError(f"IR: @{fn.name} has no blocks", error_code="E0301")
    defined: set[str] = set()
    for pname, _ in fn.params:
        defined.add(pname)
    for b in fn.blocks:
        if b.terminator is None:
            raise VexError(
                f"IR: block '{b.name}' in @{fn.name} missing terminator",
                error_code="E0302",
            )
        if b.terminator.op not in TERMINATORS:
            raise VexError(
                f"IR: block '{b.name}' bad terminator '{b.terminator.op}'",
                error_code="E0302",
            )
        for inst in b.instructions:
            _validate_inst(inst, defined, known_fns, fn.name, b.name)
            if inst.dest:
                if inst.dest in defined:
                    raise VexError(
                        f"IR: duplicate SSA {inst.dest} in @{fn.name}/{b.name}",
                        error_code="E0303",
                    )
                defined.add(inst.dest)
        # terminator operands
        _validate_inst(b.terminator, defined, known_fns, fn.name, b.name, is_term=True)
        if b.terminator.op == "br":
            if b.terminator.extra not in block_names:
                raise VexError(
                    f"IR: unknown branch target '{b.terminator.extra}' in @{fn.name}",
                    error_code="E0304",
                )
        if b.terminator.op == "br_cond":
            t, f = b.terminator.extra
            if t not in block_names or f not in block_names:
                raise VexError(
                    f"IR: unknown cond_br target in @{fn.name}/{b.name}",
                    error_code="E0304",
                )


def _validate_inst(
    inst: Instruction,
    defined: set[str],
    known_fns: set[str],
    fn: str,
    block: str,
    is_term: bool = False,
) -> None:
    if inst.op not in KNOWN:
        raise VexError(
            f"IR: unknown op '{inst.op}' in @{fn}/{block}",
            error_code="E0305",
        )
    for a in inst.args:
        if a.kind == "ssa" and a.text not in defined:
            raise VexError(
                f"IR: use of undefined {a.text} in @{fn}/{block}",
                error_code="E0306",
            )
    if inst.op == "const":
        if inst.ty == "string" and inst.extra is not None and not isinstance(inst.extra, str):
            # allow non-str only if coerced
            pass
    if inst.op in ARITH:
        if len(inst.args) != 2:
            raise VexError(f"IR: {inst.op} needs 2 args", error_code="E0307")
    if inst.op in CMP | BOOL_BIN:
        if len(inst.args) != 2:
            raise VexError(f"IR: {inst.op} needs 2 args", error_code="E0307")
    if inst.op == "index":
        if len(inst.args) != 2:
            raise VexError("IR: index needs array and index", error_code="E0307")
    if inst.op == "make_array":
        pass  # variable arity
    if inst.op == "index_set":
        if len(inst.args) != 3:
            raise VexError("IR: index_set needs array, index, value", error_code="E0307")
    if inst.op == "call" and inst.extra:
        # externs / builtins allowed without being in module
        pass
