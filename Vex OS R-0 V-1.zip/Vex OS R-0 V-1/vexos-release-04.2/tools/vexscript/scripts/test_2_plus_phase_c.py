#!/usr/bin/env python3
"""VexScript 2+ Phase C — stdlib + pointer type foundations"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vexscript.interpreter import Interpreter
from vexscript.errors import VexError

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

def run(src):
    i = Interpreter()
    i.load(src, "<t>")
    return i.run_main(), i.output

print("VexScript 2+ Phase C")

c, o = run("""
import math;
fn main() -> i32 {
    println(math::abs(0 - 12));
    println(math::min(4, 2));
    println(math::max(4, 2));
    println(math::clamp(50, 0, 10));
    return 0;
}
""")
check("stdlib math", c == 0 and o == ["12", "2", "4", "10"], o)

c, o = run("""
import std::math;
fn main() -> i32 {
    println(std::math::abs(0 - 3));
    return 0;
}
""")
check("std::math path", c == 0 and o == ["3"], o)

c, o = run("""
fn main() -> i32 {
    let p: *i64 = 0;
    let q: *mut i64 = 0;
    return 0;
}
""")
check("pointer type annotations", c == 0, o)

c, o = run("""
import result;
fn main() -> i32 {
    let r: ResultCode = ResultCode::Ok;
    if (result::is_ok_code(r)) {
        println(1);
    }
    return 0;
}
""")
check("stdlib result", c == 0 and o == ["1"], o)

print(f"\n=== 2+ Phase C Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
