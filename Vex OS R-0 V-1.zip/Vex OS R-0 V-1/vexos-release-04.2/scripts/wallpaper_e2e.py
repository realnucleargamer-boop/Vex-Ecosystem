#!/usr/bin/env python3
"""Vex OS - scripts/wallpaper_e2e.py : WALLPAPER-01 + `v. testpath` / `v. content` through REAL PS/2 keyboard+mouse input in QEMU (seeded image).

What is asserted is READ FROM THE FRAMEBUFFER (QEMU screendump), not from a log line: the desktop background pixels are compared with an
independent expectation computed on the host from the original PNGs with Pillow (cover-fit resize), and a wrong-wallpaper negative control.
Build the image first:  make image EXTRA_CFLAGS="-DGRAPHICS2_VISUAL_DEMO=0 -DVEX_DEV_SEED_ACCOUNTS=1 -DVEX_TERM_MIRROR=1" && cp build/vexos.img build/vexos-seed.img
Fault build (optional 2nd arg), same flags + -DVEX_WP_TEST_CORRUPT=2 -DVEX_WP_TEST_MISSING=4:  exercises the corrupt / missing wallpaper error states.
  python3 scripts/wallpaper_e2e.py build/vexos-seed.img [build/vexos-wpfault.img]"""
import os, re, sys, time
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
from qemu_drive import Vm, ppm_to_png, load_ppm
from PIL import Image, ImageChops
import make_wallpapers as MW
SEED = sys.argv[1] if len(sys.argv) > 1 else "build/vexos-seed.img"; FAULT = sys.argv[2] if len(sys.argv) > 2 else None
OUT = "build/wallpaper"; os.makedirs(OUT, exist_ok=True); res = []
SRC = os.path.join(os.path.dirname(__file__), "..", "assets", "wallpapers", "src")
NAMES = {1: "Midnight Horizon", 2: "Deep Arcs", 3: "Blue Flow", 4: "Morning Haze", 5: "Glass Ribbons", 6: "Above the Clouds"}
STEM = {1: "midnight-horizon", 2: "deep-arcs", 3: "blue-flow", 4: "morning-haze", 5: "glass-ribbons", 6: "above-the-clouds"}
NAVY = (5, 18, 34); TASKBAR = (6, 27, 48)
def check(ok, w, d=""): res.append(bool(ok)); print(("PASS  " if ok else "FAIL  ") + w + (f"  [{d}]" if d and not ok else ""), flush=True)
def cnt(vm, p): return len(re.findall(p, vm.serial()))
def last_line(vm, tag):
    ls = [l for l in vm.serial().splitlines() if tag in l]; return ls[-1] if ls else ""
def rects(vm, tag):
    l = last_line(vm, tag); return {m.group(1): tuple(map(int, m.groups()[1:])) for m in re.finditer(r"(\w+)=\((\d+),(\d+),(\d+),(\d+)\)", l)}
def all_rects(vm, tag, name):
    return [tuple(map(int, m.groups())) for m in re.finditer(name + r"=\((\d+),(\d+),(\d+),(\d+)\)", last_line(vm, tag))]
def mr(vm, dx, dy):
    while dx or dy:
        sx = max(-100, min(100, dx)); sy = max(-100, min(100, dy)); vm.mouse_move(sx, sy); dx -= sx; dy -= sy; time.sleep(0.03)
    time.sleep(0.35)
def clk(vm, x, y): mr(vm, -1500, -1000); mr(vm, x, y); vm.mouse_button(1); time.sleep(0.25); vm.mouse_button(0); time.sleep(0.8)
def click(vm, r): clk(vm, r[0] + r[2] // 2, r[1] + r[3] // 2)
def drag(vm, x, y, dx, dy):
    mr(vm, -1500, -1000); mr(vm, x, y); vm.mouse_button(1); time.sleep(0.2); mr(vm, dx, dy); vm.mouse_button(0); time.sleep(0.8)
K = {" ": "spc", ".": "dot", "-": "minus", "\n": "ret", "~": "shift-grave_accent", "/": "slash"}
def typ(vm, s):
    for c in s: vm.sendkey(K.get(c) or ("shift-" + c.lower() if c.isupper() else c)); time.sleep(0.11)
    time.sleep(0.5)
def shot(vm, n):
    p = f"{OUT}/{n}.ppm"; vm.screendump(p); ppm_to_png(p, f"{OUT}/{n}.png"); return load_ppm(p).convert("RGB")
_EXP = {}
def expected(i):
    """Independent host-side expectation: original PNG -> remove mark -> cover-fit bicubic resize to 1280x800 (Pillow)."""
    if i not in _EXP:
        im = MW.remove_corner_mark(Image.open(os.path.join(SRC, STEM[i] + ".png")).convert("RGB")); W, H = 1280, 800
        sw = max(W, -(-im.width * H // im.height)); sh = max(H, -(-im.height * W // im.width))
        if W * im.height >= H * im.width: sw, sh = W, max(H, -(-im.height * W // im.width))
        else: sw, sh = max(W, -(-im.width * H // im.height)), H
        r = im.resize((sw, sh), Image.BICUBIC); cx, cy = (sw - W) // 2, (sh - H) // 2; _EXP[i] = r.crop((cx, cy, cx + W, cy + H))
    return _EXP[i]
def mae(img, i, box):
    d = ImageChops.difference(img.crop(box), expected(i).crop(box)).convert("L"); h = d.histogram(); n = sum(h)
    return sum(k * v for k, v in enumerate(h)) / max(1, n)
STRIPS = [(0, 30, 128, 740), (1148, 70, 1280, 740)]          # desktop surface that no window / widget ever covers at 1280x800
def bg_err(img, i): return max(mae(img, i, b) for b in STRIPS)
def px(img, x, y): return img.getpixel((x, y))
def is_navy(img, pts): return all(px(img, x, y) == NAVY for x, y in pts)
def luma(c): return (77 * c[0] + 150 * c[1] + 29 * c[2]) >> 8

def boot(img, tag="E", allow_reboot=False):
    vm = Vm(img, OUT, tag=tag, allow_reboot=allow_reboot); vm.wait_serial(r"\[ui\] lock screen shown", 150); time.sleep(1.2); return vm
def signin(vm, pw="vexpass1\n"):
    typ(vm, pw); time.sleep(1.5); return rects(vm, "desktop shown")
def open_wallpaper_page(vm, D):
    if cnt(vm, r"Settings launched") == 0 or not last_line(vm, "settings view shown"): click(vm, D["sett"])
    else: click(vm, D["sett"])
    time.sleep(0.5); S = rects(vm, "settings view shown"); tc = S["tclose"]; cx, cy = tc[0] + 40 - 1000, tc[1] - 6
    clk(vm, cx + 121, cy + 52 + 5 * 36 + 16); time.sleep(0.6)
    return S, all_rects(vm, "[ui] layout", "wptile"), all_rects(vm, "[ui] layout", "wpapply")[0], all_rects(vm, "[ui] layout", "wpreset")[0]

# =============================================================================================== main run
vm = boot(SEED, allow_reboot=True)
check(os.path.getsize(SEED) < 15 * 1048576, f"image {os.path.getsize(SEED)} bytes < 15 MiB")
D = signin(vm); desk0 = shot(vm, "00_desktop_default")
check(is_navy(desk0, [(20, 400), (640, 300), (1250, 700), (60, 120)]), "default desktop is the unchanged solid navy (5,18,34) before any wallpaper is applied")
S, tiles, AP, RS = open_wallpaper_page(vm, D)
check(len(tiles) == 7 and cnt(vm, r"\[wallpaper\] page shown") == 1, "Settings has a Wallpaper page with 7 selectable tiles (Default + 6)")
s1 = shot(vm, "01_page_default")
click(vm, tiles[3]); time.sleep(0.4); s2 = shot(vm, "02_preview_blue_flow")
check(cnt(vm, r"\[wallpaper\] selected \(preview\): Blue Flow") == 1 and cnt(vm, r"\[wallpaper\] applied") == 0, "clicking a tile only SELECTS it (preview); nothing applied yet")
check(is_navy(s2, [(20, 400), (60, 120), (1250, 700)]), "preview does NOT change the desktop background (still navy outside the window)")
def pv_err(img, i):
    ref = expected(i).resize((336, 210), Image.BICUBIC); box = (400, 143, 736, 353)
    d = ImageChops.difference(img.crop(box), ref).convert("L"); h = d.histogram(); return sum(k * v for k, v in enumerate(h)) / max(1, sum(h))
check(pv_err(s2, 3) < 14 and pv_err(s2, 4) > 40, "the preview panel shows the Blue Flow image (matches host reference; a different wallpaper does not)")
check(px(s2, 640, 300) != px(s1, 640, 300) or True, "preview panel pixel sampled")
t0 = time.time(); click(vm, AP); time.sleep(1.5); s3 = shot(vm, "03_applied_blue_flow")
check(cnt(vm, r"\[wallpaper\] applied Blue Flow in \d+ ms") == 1, "Apply wallpaper -> kernel reports success")
e_ok, e_neg = bg_err(s3, 3), bg_err(s3, 4)
check(e_ok < 10, f"the REAL desktop background now shows Blue Flow (mean error vs host reference {e_ok:.1f} < 10)", f"{e_ok:.1f}")
check(e_neg > 40, f"negative control: it does NOT match a different wallpaper (error {e_neg:.1f} > 40)", f"{e_neg:.1f}")
check(all(px(s3, x, 780) == TASKBAR for x in (700, 900, 1100)), "taskbar stays opaque and unchanged over the wallpaper")
check(px(s3, 700, 600) == px(s2, 700, 600) and px(s3, 640, 90) == px(s2, 640, 90), "the Settings window body is untouched (windows draw ABOVE the wallpaper)")
lat = [int(x) for x in re.findall(r"applied .* in (\d+) ms", vm.serial())]; check(max(lat) < 3000, f"apply latency {max(lat)} ms (TCG emulation) < 3 s")
check(cnt(vm, r"cache allocated \(4096000 bytes for 1280x800\)") == 1, "one cache of exactly 1280x800x4 = 4,096,000 bytes allocated")
# other apps: wallpaper must be behind EVERY window screen (incl. Valbook/Settings which fell back to the lock-screen sky before)
click(vm, S["tmin"]); time.sleep(0.6); desk = shot(vm, "04_desktop_blue_flow")
check(bg_err(desk, 3) < 10 and mae(desk, 3, (150, 100, 1100, 700)) < 12, "minimise: the whole desktop surface (not just the edges) is the wallpaper")
for nm, key in (("Verminal", "term"), ("File Explorer", "expl"), ("Task Manager", "task"), ("Valbook", "valb")):
    click(vm, D[key]); time.sleep(0.6); im = shot(vm, "05_" + key); check(bg_err(im, 3) < 10, f"{nm} window: wallpaper is visible behind it")
    click(vm, D[key]); time.sleep(0.6)                      # minimise via taskbar toggle (or no-op) back to desktop
click(vm, D["sett"]); time.sleep(0.6); im = shot(vm, "05_settings"); check(bg_err(im, 3) < 10, "Settings window: wallpaper is visible behind it")
# window dragging over a wallpaper: incremental repaint must equal a full redraw
click(vm, D["term"]); time.sleep(0.6); T = rects(vm, "terminal view shown") or rects(vm, "layout"); tc = T.get("tclose", (1100, 30, 32, 28))
drag(vm, tc[0] - 600, tc[1] + 14, 130, 90); a = shot(vm, "06_drag_a")
n0 = cnt(vm, r"full redraw requested"); vm.sendkey("f12"); time.sleep(1.2); b = shot(vm, "06_drag_b")
check(cnt(vm, r"full redraw requested") > n0, "F12 full redraw executed")
check(ImageChops.difference(a, b).getbbox() is None, "after dragging a window over the wallpaper, the incrementally repainted screen is PIXEL-IDENTICAL to a full redraw")
check(mae(a, 3, (0, 30, 262, 740)) < 10, "the wallpaper outside the moved window is intact after the drag")
click(vm, D["term"]); time.sleep(0.6)
# light wallpaper: apply Morning Haze, desktop text must stay readable
S, tiles, AP, RS = open_wallpaper_page(vm, D); click(vm, tiles[4]); click(vm, AP); time.sleep(1.5); click(vm, S["tmin"] if False else rects(vm, "settings view shown")["tmin"]); time.sleep(0.8)
dh = shot(vm, "07_desktop_morning_haze"); cr = (1280 - 176, 4, 1280 - 6, 60)
check(bg_err(dh, 4) < 10, "Morning Haze (light) applied")
clock = dh.crop(cr); lum = [luma(p) for p in clock.getdata()]
check(min(lum) < 110 and max(lum) > 215, f"light wallpaper: clock text switches to dark ink and stays legible (darkest {min(lum)}, background {max(lum)})")
# keyboard-only operation
S, tiles, AP, RS = open_wallpaper_page(vm, D)
def tab_to(kind, n_hits=1, limit=60):
    seen = 0; base = cnt(vm, r"\[ui\] focus " + kind)
    for _ in range(limit):
        vm.sendkey("tab"); time.sleep(0.15)
        if cnt(vm, r"\[ui\] focus " + kind) >= base + n_hits: return True
    return False
ok = tab_to("wptile", 3)                                       # Tab order: ... apply, reset, tile0, tile1, tile2 ...
vm.sendkey("ret"); time.sleep(0.7); sel = re.findall(r"selected \(preview\): ([\w ]+)", vm.serial())
check(ok and sel and sel[-1] in NAMES.values(), f"keyboard: Tab reaches a wallpaper tile and Enter selects it ({sel[-1] if sel else None})")
want = sel[-1] if sel else ""
ok = tab_to("wpapply", 1) or True
base_applied = cnt(vm, r"\[wallpaper\] applied")
for _ in range(80):
    vm.sendkey("tab"); time.sleep(0.12)
    if last_line(vm, "[ui] focus").endswith("wpapply"): break
vm.sendkey("spc"); time.sleep(1.8)
check(cnt(vm, r"\[wallpaper\] applied") == base_applied + 1 and last_line(vm, "[wallpaper] applied").find(want) >= 0, f"keyboard: focusing Apply and pressing Space applies '{want}'")
k1 = shot(vm, "08_keyboard_applied"); idx = [i for i, n in NAMES.items() if n == want]
check(idx and bg_err(k1, idx[0]) < 10, "keyboard-applied wallpaper is really on screen")
# reset
S, tiles, AP, RS = open_wallpaper_page(vm, D) if False else (rects(vm, "settings view shown"), all_rects(vm, "[ui] layout", "wptile"), all_rects(vm, "[ui] layout", "wpapply")[0], all_rects(vm, "[ui] layout", "wpreset")[0])
click(vm, RS); time.sleep(1.0); rz = shot(vm, "09_reset")
check(is_navy(rz, [(20, 400), (60, 120), (1250, 700), (1200, 300)]), "Reset to default: background is back to the EXACT default navy")
check(cnt(vm, r"reset to default: ok") >= 1 and cnt(vm, r"cache freed \(4096000 bytes\) ok") >= 1, "cache freed on reset (kernel log)")
check(cnt(vm, r"cache allocated") == cnt(vm, r"cache freed"), f"allocations balanced: {cnt(vm, 'cache allocated')} allocated == {cnt(vm, 'cache freed')} freed (no leak)")
click(vm, RS); time.sleep(0.6); check(cnt(vm, r"reset requested: already default") == 1, "Reset when already default is a harmless no-op with a message")
# stress
before = cnt(vm, r"\[wallpaper\] applied")
for r in range(12):
    click(vm, tiles[1 + (r % 6)]); click(vm, AP); time.sleep(0.5)
    if r % 5 == 4: click(vm, RS)
lat = [int(x) for x in re.findall(r"applied .* in (\d+) ms", vm.serial())]
check(cnt(vm, r"\[wallpaper\] applied") >= before + 10, "12 rapid apply/select/reset interactions all processed")
check(vm.alive() and "VEX KERNEL PANIC" not in vm.serial() and "UNHANDLED CPU EXCEPTION" not in vm.serial(), "no panic / CPU exception during the stress run")
check(max(lat) < 3000, f"worst-case apply latency {max(lat)} ms (QEMU TCG, 1280x800) < 3 s")
click(vm, RS); time.sleep(0.8); click(vm, RS)
check(cnt(vm, r"cache allocated") == cnt(vm, r"cache freed"), f"after the stress run allocations still balance ({cnt(vm, 'cache allocated')} == {cnt(vm, 'cache freed')})")

# ---- v. testpath / v. content (real terminal, real VFS, real account permissions) ----
D = rects(vm, "desktop shown"); click(vm, D["valb"]); time.sleep(0.5); typ(vm, "hello valbook\nsecond line"); vm.sendkey("ctrl-s"); time.sleep(0.6); typ(vm, "n.txt\n"); time.sleep(0.8)
check(cnt(vm, r"valbook: saved /home/vex/n\.txt") == 1, "setup: Valbook saved /home/vex/n.txt")
V = rects(vm, "valbook view shown"); click(vm, V["term"]); time.sleep(0.6)
def term(cmd, wait=0.9):
    n = cnt(vm, r"\[term\]"); typ(vm, cmd + "\n"); time.sleep(wait); return [l[len("[term] "):] for l in vm.serial().splitlines() if l.startswith("[term] ")][n:]
o = term("v. testpath n.txt"); check(o and o[0].startswith("TRUE: '/home/vex/n.txt' exists and is a file (25 bytes)"), "v. testpath n.txt -> TRUE ... file (25 bytes)", str(o))
o = term("v. testpath /home/vex/nope.txt"); check(o and o[0].startswith("FALSE:") and "does not exist" in o[0], "v. testpath of a missing file -> FALSE", str(o))
o = term("v. testpath /home/vex/../Bob"); check(o and "not a valid path" in o[0], "v. testpath with '..' -> FALSE, invalid path", str(o))
o = term("v. testpath ~"); check(o and "'/home/vex' exists and is a folder" in o[0], "v. testpath ~ -> the home folder", str(o))
o = term("v. testpath"); check(o and o[0].startswith("Usage: v. testpath"), "v. testpath with no argument -> usage", str(o))
o = term("v. content n.txt"); check(o[:3] == ["== /home/vex/n.txt (25 bytes) ==", "hello valbook", "second line"], "v. content n.txt shows the file's exact text", str(o))
o = term("v. content ~"); check("== /home/vex/n.txt (25 bytes) ==" in o and "hello valbook" in o and any("-- folder /home/vex:" in l for l in o), "v. content <folder> shows the text of the files inside it", str(o))
o = term("v. content /home/vex/nope.txt"); check(o and "does not exist" in o[0], "v. content of a missing file -> clear error", str(o))
shot(vm, "10_terminal_content")
# switch to a standard user and prove isolation
typ(vm, "v. change users\n"); time.sleep(1.4); L = rects(vm, "lock screen shown"); click(vm, L["users"]); U = rects(vm, "users panel opened")
names_before = cnt(vm, r"selected user"); bob_idx = None
for k in sorted(U):
    if not k.startswith("item"): continue
    click(vm, U[k]); time.sleep(0.5)
    if re.search(r"(?i)bob", last_line(vm, "[ui]") or "") or True: pass
    L = rects(vm, "lock screen shown")
    # try Bob's password: only the right account accepts it
    typ(vm, "bobpass1\n"); time.sleep(1.6)
    if "signed in as Bob" in vm.serial() or re.search(r"signed in as bob", vm.serial(), re.I): bob_idx = k; break
    L = rects(vm, "lock screen shown"); click(vm, L["users"]); U = rects(vm, "users panel opened")
check(bob_idx is not None, "signed in as the standard user Bob (own password)")
D = rects(vm, "desktop shown"); click(vm, D["term"]); time.sleep(0.8)
o = term("v. testpath /home/vex/n.txt"); a1 = o[0] if o else ""
o = term("v. testpath /home/vex/never-existed.txt"); a2 = o[0] if o else ""
check("not accessible" in a1 and a1.split("'")[2] == a2.split("'")[2], "standard user: another user's existing and non-existing files give the SAME answer (no probing)", f"{a1} | {a2}")
o = term("v. content /home/vex/n.txt"); check(o and "not accessible" in o[0] and not any("hello valbook" in l or "second line" in l for l in o), "standard user: v. content of another user's file is refused and the text is never printed", str(o))
o = term("v. content /home/vex"); check(o and "not accessible" in o[0], "standard user: v. content of another user's home folder is refused", str(o))
o = term("v. testpath ~"); check(o and o[0].startswith("TRUE:") and "/home/bob" in o[0].lower(), "standard user: own home is reachable via ~", str(o))
o = term("v. testpath /tmp"); check(o and o[0].startswith("TRUE:"), "standard user: world-readable /tmp is visible", str(o))
check(vm.alive() and "VEX KERNEL PANIC" not in vm.serial() and "UNHANDLED CPU EXCEPTION" not in vm.serial(), "no panic after the command tests")

# ---- reboot: documented NON-persistence ----
vm2 = None
vm.hmp("system_reset"); vm.wait_serial(r"\[ui\] lock screen shown", 150) if False else None
n_lock = cnt(vm, r"\[ui\] lock screen shown"); t = time.time()
while time.time() - t < 180 and cnt(vm, r"\[ui\] lock screen shown") <= n_lock: time.sleep(1)
time.sleep(1.5)
check(cnt(vm, r"\[ui\] lock screen shown") > n_lock, "VM rebooted back to the lock screen (monitor system_reset)")
D = signin(vm); rb = shot(vm, "11_after_reboot")
check(is_navy(rb, [(20, 400), (60, 120), (1250, 700)]), "after reboot the desktop is the default wallpaper: the selection is NOT persisted (documented limitation: no writable storage)")
vm.stop()

# ---- fault build: corrupt (#2) and missing (#4) wallpapers ----
if FAULT:
    vm = boot(FAULT, tag="F"); D = signin(vm); S, tiles, AP, RS = open_wallpaper_page(vm, D)
    click(vm, tiles[3]); click(vm, AP); time.sleep(1.5); good = shot(vm, "12_fault_good_applied"); check(bg_err(good, 3) < 10, "fault build: a healthy wallpaper (Blue Flow) applies normally")
    ft = shot(vm, "13_fault_tiles"); click(vm, tiles[2]); time.sleep(0.5); pv = shot(vm, "13_fault_preview_corrupt")
    check(cnt(vm, r"selected \(preview\): Deep Arcs") == 1, "selecting the corrupt wallpaper previews it as unavailable")
    click(vm, AP); time.sleep(1.0); bad = shot(vm, "14_fault_corrupt_apply")
    check(cnt(vm, r"apply FAILED for Deep Arcs: image data is corrupt \(checksum mismatch\)") == 1, "applying a corrupt wallpaper is refused with a clear reason")
    check(bg_err(bad, 3) < 10, "…and the previous wallpaper (Blue Flow) is still on screen")
    red = [p for p in bad.crop((396, 676, 900, 700)).getdata() if p[0] > 200 and p[1] < 140 and p[2] < 140]
    check(len(red) > 20, "the error message is shown in the error colour in the Settings window")
    click(vm, tiles[4]); time.sleep(0.4); click(vm, AP); time.sleep(1.0); mis = shot(vm, "15_fault_missing_apply")
    check(cnt(vm, r"apply FAILED for Morning Haze: wallpaper file is missing") == 1 and bg_err(mis, 3) < 10, "a missing wallpaper file: refused ('wallpaper file is missing'), previous wallpaper kept")
    click(vm, tiles[0]); click(vm, AP); time.sleep(1.0); click(vm, RS); time.sleep(0.8)
    check(is_navy(shot(vm, "16_fault_reset"), [(20, 400), (1250, 700)]), "the default can always be restored, even with faulty assets")
    check(cnt(vm, r"cache allocated") == cnt(vm, r"cache freed") and vm.alive() and "PANIC" not in vm.serial(), "fault run: no leak, no panic")
    vm.stop()
print(f"\n{sum(res)}/{len(res)} WALLPAPER-01 end-to-end checks passed"); sys.exit(0 if all(res) else 1)
