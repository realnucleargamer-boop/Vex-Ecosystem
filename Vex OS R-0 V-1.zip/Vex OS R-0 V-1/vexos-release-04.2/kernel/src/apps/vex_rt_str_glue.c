/* Single source of truth for the freestanding VexScript string runtime lives in the vendored toolchain.
 * This unit exists only so the kernel build lists compile it. */
#include "../../../tools/vexscript/src/runtime/vex_rt_str.c"
