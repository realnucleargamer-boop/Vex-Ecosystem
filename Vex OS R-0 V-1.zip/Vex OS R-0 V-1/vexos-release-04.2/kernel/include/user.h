#ifndef VEXOS_USER_H
#define VEXOS_USER_H
#include <stdint.h>
typedef uint32_t VexHandle;
enum { VEX_CAP_NONE=0, VEX_CAP_INPUT=1u<<0, VEX_CAP_GRAPHICS=1u<<1, VEX_CAP_IPC=1u<<2 };
void user_init(void);
VexHandle user_kernel_service_register(uint32_t capabilities);
int user_handle_validate(VexHandle handle, uint32_t required_capability);
uint32_t user_service_count(void);
#endif
