/*
 * Vex OS - kernel/include/gfx/text.h
 *
 * Glyph renderer and scrolling text console for BOOT-03's native
 * graphics layer.
 *
 * Uses the same 8x16 font bitmap data that the original VISUALS-1.0
 * build shipped (it is a public-domain VGA BIOS font — the only
 * non-trivial data in the old port that made sense to keep).  The font
 * data is embedded in gfx_font8x16.c as a plain C array of uint8_t;
 * it has no coupling to any VISUALS-1.0 type or header.
 *
 * GfxConsole is completely statically allocated — a fixed character
 * grid backed by the framebuffer directly.  No heap, no malloc.
 */

#ifndef VEXOS_GFX_TEXT_H
#define VEXOS_GFX_TEXT_H

#include <stdint.h>
#include "gfx/fb.h"
#include "gfx/draw.h"

#define GFX_FONT_W  8
#define GFX_FONT_H  16

/* Draw one glyph (ASCII 0x20-0x7E) at pixel position (px, py). */
void gfx_draw_char(const GfxFb *fb, int32_t px, int32_t py,
                   char c, GfxColor fg, GfxColor bg);

/* Draw a NUL-terminated string on a single row — no wrap, no newline
 * handling.  Returns the pixel X after the last glyph drawn. */
int32_t gfx_draw_str(const GfxFb *fb, int32_t px, int32_t py,
                     const char *s, GfxColor fg, GfxColor bg);

/* Right-aligned string within a pixel-width column ending at `rx`. */
void gfx_draw_str_right(const GfxFb *fb, int32_t rx, int32_t py,
                        const char *s, GfxColor fg, GfxColor bg);

/* ------------------------------------------------------------------ */
/* Scrolling console                                                   */
/* ------------------------------------------------------------------ */

#define GFX_CONSOLE_MAX_COLS 160
#define GFX_CONSOLE_MAX_ROWS 60

typedef struct {
    const GfxFb *fb;
    int32_t  origin_x, origin_y; /* pixel origin of the text area     */
    int32_t  area_w,   area_h;   /* pixel dimensions of the text area */
    uint32_t cols, rows;          /* character grid dimensions         */
    uint32_t cx, cy;              /* current cursor (col, row)         */
    GfxColor fg, bg;
    int      ok;
} GfxConsole;

/* Initialise a console inside a pixel rectangle of *fb.
 * Returns 1 on success (area large enough for at least 1 char). */
int gfx_console_init(GfxConsole *con, const GfxFb *fb,
                     int32_t x, int32_t y, int32_t w, int32_t h,
                     GfxColor fg, GfxColor bg);

/* Emit one character; handle '\n' and horizontal wrap.  Scrolls the
 * character grid up by one row when the last row is full — no off-
 * screen backing store, scroll is a pixel blit followed by a blank
 * row fill. */
void gfx_console_putc(GfxConsole *con, char c);

/* Emit a NUL-terminated string. */
void gfx_console_puts(GfxConsole *con, const char *s);

/* Emit a string in a specific colour, restoring the console's default
 * fg colour afterwards. */
void gfx_console_puts_col(GfxConsole *con, const char *s, GfxColor col);

/* Emit an unsigned decimal integer. */
void gfx_console_put_u64(GfxConsole *con, uint64_t v);

/* Emit a signed decimal integer. */
void gfx_console_put_i64(GfxConsole *con, int64_t v);

#endif /* VEXOS_GFX_TEXT_H */
