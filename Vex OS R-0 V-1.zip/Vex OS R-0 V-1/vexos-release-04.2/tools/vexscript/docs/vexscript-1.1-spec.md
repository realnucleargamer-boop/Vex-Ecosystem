# VEX-Script 1.1 Language Specification

**Status**: Implemented  
**Baseline**: VEX-Script 1.0 (frozen)  
**Compatibility**: All valid 1.0 programs that use only the frozen surface remain valid.

---

## 1. Relationship to 1.0

VEX-Script 1.1 is a strict evolutionary superset of the frozen 1.0 surface.  
Anything that was valid under the 1.0 freeze remains valid.

## 2. New / Clarified in 1.1

### 2.1 Modules (minimal)

```vex
// file: math.vex
fn add(a: i64, b: i64) -> i64 {
    return a + b;
}

// file: main.vex
use math;
fn main() -> i32 {
    let x: i64 = math.add(10, 20);
    println(x);
    return 0;
}
```

Rules:
- One module per file (filename without extension = module name).
- `use name;` brings the module into scope.
- No nested modules or visibility modifiers in 1.1.

### 2.2 Standard library foundations

```vex
// always available
println(value);          // prints any supported value + newline
print(value);

// std::option (library type)
type Option = ...;       // Some(v) | None

// std::result
type Result = ...;       // Ok(v) | Err(e)
```

Concrete functions provided by the 1.1 runtime:

```vex
fn println(v);           // polymorphic print + newline
fn print(v);
fn assert(cond: bool);   // panics on false
fn len_string(s: string) -> i64;
fn concat(a: string, b: string) -> string;
```

### 2.3 Option & Result (library types, no new keywords)

```vex
let a: Option = some(42);
let b: Option = none();

if (is_some(a)) {
    let v: i64 = unwrap(a);
}

let r: Result = ok(10);
let e: Result = err("fail");
```

These are ordinary values implemented by the runtime.  
No special language syntax beyond ordinary function calls.

### 2.4 Control-flow clarifications

- `for (let i: i64 = start; cond; step) { body }` is fully defined.
- `loop { body }` is an infinite loop.
- `break` and `continue` work inside `while`, `for`, and `loop`.
- Nested loops: `break`/`continue` affect the innermost loop only (1.1).

### 2.5 String operations (minimal, safe)

```vex
let s: string = "hello";
let n: i64 = len_string(s);          // 5
let t: string = concat(s, " world"); // "hello world"
```

Indexing and mutation of strings are **not** provided in 1.1.

### 2.6 Improved diagnostics

The 1.1 implementation reports:
- file, line, column
- clear messages for type mismatches, undefined names, arity errors, immutable assignment, etc.

## 3. Unchanged from 1.0

All frozen items in `docs/vexscript-1.0-spec.md` remain exactly as specified.

## 4. Intentionally postponed (see also roadmap)

- Generics, traits, real modules with visibility
- Ownership / borrow checking
- Async, concurrency
- Macros, packages
- Full standard library
- Compiler backend (Vex IR → machine code)
- Tight Vex AI or Vex OS coupling

## 5. Runtime model for 1.1

1.1 ships as a **reference interpreter**.  
This lets the language surface be tested thoroughly while a future compiler backend is designed.  
The interpreter is not the final execution model; it is a correctness and evolution vehicle.
