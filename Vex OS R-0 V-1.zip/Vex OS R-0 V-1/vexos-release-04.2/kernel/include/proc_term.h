/* proc_term.h - PROC-01 terminal entry points (`v. proc ...`). Output is emitted line by line through `emit`. */
#ifndef VEX_PROC_TERM_H
#define VEX_PROC_TERM_H
typedef void (*proc_emit_fn)(const char *line);
void proc_term(const char *arg, proc_emit_fn emit);       /* handles the argument text of `v. proc <arg>` */
void proc_selftest(proc_emit_fn emit);                    /* the full in-kernel verification */
#endif
