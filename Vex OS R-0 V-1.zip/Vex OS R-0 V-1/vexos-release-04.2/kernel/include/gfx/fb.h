/*
 * Vex OS - kernel/include/gfx/fb.h
 *
 * Native framebuffer abstraction for BOOT-03.
 *
 * Reads the framebuffer description directly from BootInfo
 * (common/include/bootinfo.h) — the one authoritative contract
 * between the Vex bootloader and the Vex kernel.  No Limine
 * structures, no vex_fb_info translation layer, no external types.
 *
 * The UEFI bootloader maps the framebuffer uncacheable in the identity
 * map before kernel entry.  vmm_build_kernel_tables() re-maps it the
 * same way (VMM_KERNEL_MMIO) in the kernel's own page tables, so the
 * pointer is valid immediately after paging is activated.
 *
 * Pixel format: BOOT-03 supports RGBX8 and BGRX8 (the two formats
 * UEFI GOP actually reports in practice).  BITMASK and UNKNOWN are
 * treated as no-framebuffer: gfx_fb_init() returns 0 and nothing
 * draws.
 *
 * No dynamic allocation.  No SSE/MMX (kernel CFLAGS already prohibit
 * them).  The kernel's static memset/memcpy convention is followed —
 * gfx_memset32 and gfx_memcpy32 below are private helpers used only
 * for scanline fills; they deliberately avoid __builtin_memset because
 * the compiler may lower that to SSE on this target even with
 * -mno-sse2 depending on the GCC version.
 */

#ifndef VEXOS_GFX_FB_H
#define VEXOS_GFX_FB_H

#include <stdint.h>
#include <stddef.h>
#include "bootinfo.h"   /* BootInfo, VexPixelFormat */

/* ------------------------------------------------------------------ */
/* Colour representation                                               */
/* ------------------------------------------------------------------ */

/* 24-bit RGB, no alpha — the framebuffer word is always 32 bits wide  */
typedef struct { uint8_t r, g, b; } GfxColor;

static inline GfxColor gfx_rgb(uint8_t r, uint8_t g, uint8_t b)
{
    GfxColor c; c.r = r; c.g = g; c.b = b; return c;
}

/* Common palette — defined here so every graphics source uses the
 * exact same constants, not ad-hoc hex values scattered everywhere. */
#define GFX_BLACK      gfx_rgb(0x00,0x00,0x00)
#define GFX_WHITE      gfx_rgb(0xFF,0xFF,0xFF)
#define GFX_DARK_BG    gfx_rgb(0x0D,0x0F,0x15)   /* main background   */
#define GFX_PANEL_BG   gfx_rgb(0x12,0x16,0x1E)   /* status panel      */
#define GFX_TERM_BG    gfx_rgb(0x0A,0x0C,0x10)   /* terminal area     */
#define GFX_BORDER     gfx_rgb(0x22,0x2A,0x38)   /* panel borders     */
#define GFX_ACCENT     gfx_rgb(0x3A,0x8C,0xFF)   /* blue accent line  */
#define GFX_TEXT       gfx_rgb(0xCC,0xD6,0xE8)   /* primary text      */
#define GFX_DIM        gfx_rgb(0x55,0x60,0x72)   /* dim/label text    */
#define GFX_GREEN      gfx_rgb(0x4C,0xC7,0x5A)   /* PASS / ONLINE     */
#define GFX_RED        gfx_rgb(0xE0,0x40,0x40)   /* FAIL / ERROR      */
#define GFX_YELLOW     gfx_rgb(0xF0,0xC0,0x40)   /* WARNING           */
#define GFX_HEADER_BG  gfx_rgb(0x08,0x0A,0x10)   /* top bar           */
#define GFX_CURSOR     gfx_rgb(0xE0,0xE8,0xFF)   /* cursor sprite     */

/* ------------------------------------------------------------------ */
/* Framebuffer descriptor                                              */
/* ------------------------------------------------------------------ */

typedef struct {
    volatile uint32_t *pixels; /* writable pointer to the linear buffer */
    uint32_t  width;
    uint32_t  height;
    uint32_t  pitch_px;    /* stride in 32-bit words (pitch_bytes / 4)  */
    uint8_t   r_shift;     /* bit offset of the red   channel in a word */
    uint8_t   g_shift;
    uint8_t   b_shift;
    int       ok;          /* 1 if init succeeded and drawing is safe    */
} GfxFb;

/* Initialises *fb from BootInfo.  Returns 1 on success (RGBX8 or
 * BGRX8 mode, non-zero address), 0 otherwise.  Must be called after
 * vmm_activate() so the identity map the bootloader established is
 * replaced by the kernel's own uncacheable mapping for the same PA. */
int  gfx_fb_init(GfxFb *fb, const BootInfo *info);

/* Pixel encode: pack GfxColor into the 32-bit word format for *fb. */
static inline uint32_t gfx_encode(const GfxFb *fb, GfxColor c)
{
    return ((uint32_t)c.r << fb->r_shift)
         | ((uint32_t)c.g << fb->g_shift)
         | ((uint32_t)c.b << fb->b_shift);
}

/* Raw pixel access — bounds checked, no-op when out of range. */
static inline void gfx_put(const GfxFb *fb, int32_t x, int32_t y, GfxColor c)
{
    /* SECURITY-02: also refuse a NULL descriptor or one whose init did
     * not succeed. gfx_fb_init() now zeroes width/height on failure, so
     * the bounds test below would already reject everything - the explicit
     * check is the second, independent layer, not the only one. */
    if (!fb || !fb->ok || !fb->pixels) return;
    if ((uint32_t)x >= fb->width || (uint32_t)y >= fb->height) return;
    fb->pixels[(uint32_t)y * fb->pitch_px + (uint32_t)x] = gfx_encode(fb, c);
}

static inline GfxColor gfx_get(const GfxFb *fb, int32_t x, int32_t y)
{
    /* SECURITY-02 Graphics audit finding: this function had NO bounds
     * check - an out-of-range coordinate was an out-of-bounds READ of
     * whatever lay past (or before) the framebuffer. gfx_put() always
     * clipped; its mirror image did not. Out of range now yields black,
     * the same value a cleared pixel has, rather than a fault or a leak
     * of adjacent memory. */
    if (!fb || !fb->ok || !fb->pixels ||
        (uint32_t)x >= fb->width || (uint32_t)y >= fb->height) {
        GfxColor z; z.r = 0; z.g = 0; z.b = 0;
        return z;
    }
    uint32_t w = fb->pixels[(uint32_t)y * fb->pitch_px + (uint32_t)x];
    GfxColor c;
    c.r = (uint8_t)(w >> fb->r_shift);
    c.g = (uint8_t)(w >> fb->g_shift);
    c.b = (uint8_t)(w >> fb->b_shift);
    return c;
}

/* Pixel-copy selftest: write a probe pixel to (x,y), read it back,
 * restore the original.  Returns 1 if the decoded value matches.
 * This is a real hardware round-trip, not a memcmp of the encoded
 * word — it catches channel-swap bugs. */
int gfx_fb_selftest(GfxFb *fb);

#endif /* VEXOS_GFX_FB_H */
