# Vex OS - scripts/VexToolchain.ps1
#
# Toolchain discovery for the Windows-native build. Dot-source this from
# build.ps1 / run-qemu.ps1:
#
#     . (Join-Path $RepoRoot "scripts\VexToolchain.ps1")
#     $tc = Resolve-VexToolchain -RepoRoot $RepoRoot -Require @("llvm","nasm")
#
# WHY THIS FILE EXISTS
# --------------------
# The previous build.ps1 called Get-Command for each tool and failed if the
# tool was not on PATH. That is a real problem on Windows specifically for
# NASM: the official NASM Windows installer does not add its directory to
# PATH. This is a known, still-open upstream NASM bug
# (https://bugzilla.nasm.us/show_bug.cgi?id=3392224) and is why
# `winget install NASM.NASM` also leaves nasm.exe off PATH
# (https://github.com/microsoft/winget-cli/issues/2452 and /issues/2453).
# LLVM's installer *offers* to add itself to PATH but the checkbox is easy to
# miss, and a PATH edit made in one terminal never reaches an already-open
# one, because a process inherits its environment block at creation time.
#
# So: resolve tools by searching known install locations, and inject the
# resulting directories into the *current process* PATH only. Nothing is
# written to the user or machine environment, so there is no dependency on
# terminal restarts and nothing to clean up later.
#
# DISCOVERY ORDER (first hit wins, per tool)
#   1. Explicit env override      - $env:VEXOS_NASM / VEXOS_LLVM_BIN / VEXOS_QEMU
#   2. Cache from a previous run  - build\toolchain.local.json (re-validated)
#   3. PATH                       - Get-Command
#   4. Known install directories  - Program Files, winget, choco, scoop, msys2, VS
#   5. Registry uninstall entries - HKLM/HKCU InstallLocation
#   6. Bounded filesystem probe   - depth-limited, last resort
#
# Everything is best-effort and read-only; a failed probe never aborts the
# search, and genuine absence produces a specific error naming what was
# looked for and where.

#Requires -Version 5.1

Set-StrictMode -Off

# ------------------------------------------------------------------
# Small helpers
# ------------------------------------------------------------------

function Get-VexEnvPath([string]$name) {
    $v = [Environment]::GetEnvironmentVariable($name, "Process")
    if ([string]::IsNullOrWhiteSpace($v)) { return $null }
    return $v
}

# Expand a candidate that may contain wildcards (winget package dirs and
# Visual Studio's versioned Llvm path both need this) into real directories.
function Expand-VexDirCandidate([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path)) { return @() }
    if ($path -notmatch '[\*\?]') {
        if (Test-Path -LiteralPath $path -PathType Container) { return @($path) }
        return @()
    }
    try {
        return @(Get-ChildItem -Path $path -Directory -ErrorAction SilentlyContinue |
                 Sort-Object FullName -Descending |
                 ForEach-Object { $_.FullName })
    } catch { return @() }
}

function Test-VexExeInDir([string]$dir, [string]$exe) {
    if ([string]::IsNullOrWhiteSpace($dir)) { return $null }
    $p = Join-Path $dir $exe
    if (Test-Path -LiteralPath $p -PathType Leaf) { return (Resolve-Path -LiteralPath $p).Path }
    return $null
}

# ------------------------------------------------------------------
# Candidate directory tables
#
# These are ordinary install locations, not guesses about a particular
# machine. If a tool lives somewhere unusual, the env override is the
# supported escape hatch and is documented in docs/WINDOWS-BUILD.md.
# ------------------------------------------------------------------

function Get-VexLlvmCandidateDirs {
    $pf    = Get-VexEnvPath "ProgramFiles"
    $pf86  = [Environment]::GetEnvironmentVariable("ProgramFiles(x86)", "Process")
    $lad   = Get-VexEnvPath "LOCALAPPDATA"
    $pdata = Get-VexEnvPath "ProgramData"
    $up    = Get-VexEnvPath "USERPROFILE"

    $c = @()
    if ($pf)    { $c += (Join-Path $pf   "LLVM\bin") }
    if ($pf86)  { $c += (Join-Path $pf86 "LLVM\bin") }
    if ($lad)   { $c += (Join-Path $lad  "Programs\LLVM\bin") }
    if ($lad)   { $c += (Join-Path $lad  "Microsoft\WinGet\Links") }
    if ($lad)   { $c += (Join-Path $lad  "Microsoft\WinGet\Packages\LLVM.LLVM_*\bin") }
    if ($lad)   { $c += (Join-Path $lad  "Microsoft\WinGet\Packages\LLVM.LLVM_*") }
    if ($pdata) { $c += (Join-Path $pdata "chocolatey\lib\llvm\tools\LLVM\bin") }
    if ($pdata) { $c += (Join-Path $pdata "chocolatey\bin") }
    if ($up)    { $c += (Join-Path $up   "scoop\apps\llvm\current\bin") }
    if ($up)    { $c += (Join-Path $up   "scoop\shims") }
    # Visual Studio ships a bundled LLVM under the C++ workload.
    if ($pf)    { $c += (Join-Path $pf   "Microsoft Visual Studio\*\*\VC\Tools\Llvm\x64\bin") }
    if ($pf86)  { $c += (Join-Path $pf86 "Microsoft Visual Studio\*\*\VC\Tools\Llvm\x64\bin") }
    $c += "C:\msys64\clang64\bin"
    $c += "C:\msys64\mingw64\bin"
    $c += "C:\LLVM\bin"
    return $c
}

function Get-VexNasmCandidateDirs {
    $pf    = Get-VexEnvPath "ProgramFiles"
    $pf86  = [Environment]::GetEnvironmentVariable("ProgramFiles(x86)", "Process")
    $lad   = Get-VexEnvPath "LOCALAPPDATA"
    $pdata = Get-VexEnvPath "ProgramData"
    $up    = Get-VexEnvPath "USERPROFILE"

    $c = @()
    # Admin install of the official NASM win64 installer.
    if ($pf)    { $c += (Join-Path $pf   "NASM") }
    if ($pf86)  { $c += (Join-Path $pf86 "NASM") }
    # Per-user install of the same installer - this is the location reported
    # in winget-cli issue #2453.
    if ($lad)   { $c += (Join-Path $lad  "bin\NASM") }
    if ($lad)   { $c += (Join-Path $lad  "NASM") }
    if ($lad)   { $c += (Join-Path $lad  "Microsoft\WinGet\Links") }
    if ($lad)   { $c += (Join-Path $lad  "Microsoft\WinGet\Packages\NASM.NASM_*") }
    if ($pdata) { $c += (Join-Path $pdata "chocolatey\lib\nasm\tools") }
    if ($pdata) { $c += (Join-Path $pdata "chocolatey\bin") }
    if ($up)    { $c += (Join-Path $up   "scoop\apps\nasm\current") }
    if ($up)    { $c += (Join-Path $up   "scoop\shims") }
    $c += "C:\NASM"
    $c += "C:\nasm"
    $c += "C:\tools\nasm"
    $c += "C:\msys64\mingw64\bin"
    return $c
}

function Get-VexQemuCandidateDirs {
    $pf    = Get-VexEnvPath "ProgramFiles"
    $pf86  = [Environment]::GetEnvironmentVariable("ProgramFiles(x86)", "Process")
    $lad   = Get-VexEnvPath "LOCALAPPDATA"
    $pdata = Get-VexEnvPath "ProgramData"
    $up    = Get-VexEnvPath "USERPROFILE"

    $c = @()
    if ($pf)    { $c += (Join-Path $pf   "qemu") }
    if ($pf86)  { $c += (Join-Path $pf86 "qemu") }
    if ($lad)   { $c += (Join-Path $lad  "Microsoft\WinGet\Links") }
    if ($lad)   { $c += (Join-Path $lad  "Microsoft\WinGet\Packages\SoftwareFreedomConservancy.QEMU_*") }
    if ($pdata) { $c += (Join-Path $pdata "chocolatey\lib\qemu\tools") }
    if ($pdata) { $c += (Join-Path $pdata "chocolatey\bin") }
    if ($up)    { $c += (Join-Path $up   "scoop\apps\qemu\current") }
    if ($up)    { $c += (Join-Path $up   "scoop\shims") }
    $c += "C:\qemu"
    $c += "C:\Program Files\qemu"
    return $c
}

# ------------------------------------------------------------------
# Registry probe
#
# Windows installers conventionally record InstallLocation under the
# Uninstall keys. Read-only, wrapped so a permission error on any single
# subkey cannot abort discovery.
# ------------------------------------------------------------------
function Get-VexRegistryInstallDirs([string]$displayNameLike) {
    $roots = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
        "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"
    )
    $found = @()
    foreach ($root in $roots) {
        if (-not (Test-Path $root)) { continue }
        try {
            $keys = Get-ChildItem $root -ErrorAction SilentlyContinue
        } catch { continue }
        foreach ($k in $keys) {
            try {
                $p = Get-ItemProperty -Path $k.PSPath -ErrorAction SilentlyContinue
            } catch { continue }
            if (-not $p) { continue }
            if ($p.DisplayName -and ($p.DisplayName -like $displayNameLike)) {
                if ($p.InstallLocation -and -not [string]::IsNullOrWhiteSpace($p.InstallLocation)) {
                    $loc = $p.InstallLocation.Trim().TrimEnd('\')
                    $found += $loc
                    $found += (Join-Path $loc "bin")
                }
            }
        }
    }
    return ($found | Select-Object -Unique)
}

# ------------------------------------------------------------------
# Bounded filesystem probe - last resort only.
#
# Depth-limited and rooted at a handful of directories so this cannot turn
# into a whole-drive walk. If this is what finds the tool, the discovery
# tables above should probably be extended.
# ------------------------------------------------------------------
function Find-VexExeByProbe([string]$exe, [int]$maxDepth = 3) {
    $roots = @(
        (Get-VexEnvPath "ProgramFiles"),
        ([Environment]::GetEnvironmentVariable("ProgramFiles(x86)", "Process")),
        (Get-VexEnvPath "LOCALAPPDATA"),
        (Get-VexEnvPath "ProgramData")
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }

    foreach ($root in $roots) {
        try {
            $hit = Get-ChildItem -Path $root -Filter $exe -File -Recurse -Depth $maxDepth `
                       -ErrorAction SilentlyContinue | Select-Object -First 1
        } catch { $hit = $null }
        if ($hit) { return $hit.FullName }
    }
    return $null
}

# ------------------------------------------------------------------
# Core resolver for one executable
# ------------------------------------------------------------------
function Resolve-VexTool {
    param(
        [Parameter(Mandatory=$true)][string]$Exe,          # e.g. "nasm.exe"
        [string[]]$CandidateDirs = @(),
        [string]$RegistryDisplayNameLike,
        [string]$OverrideValue,                            # env override: file OR directory
        [switch]$AllowProbe
    )

    # 1. Explicit override.
    if (-not [string]::IsNullOrWhiteSpace($OverrideValue)) {
        # Trim whitespace first, then quotes, then whitespace again: users
        # paste values like `  "C:\Program Files\NASM"  ` and the quotes are
        # not necessarily the outermost characters.
        $ov = $OverrideValue.Trim().Trim('"').Trim("'").Trim()
        if (Test-Path -LiteralPath $ov -PathType Leaf) {
            return (Resolve-Path -LiteralPath $ov).Path
        }
        $hit = Test-VexExeInDir $ov $Exe
        if ($hit) { return $hit }
        $hit = Test-VexExeInDir (Join-Path $ov "bin") $Exe
        if ($hit) { return $hit }
        # An override that points nowhere is a configuration error, not
        # something to silently fall through - say so.
        throw "Override path '$OverrideValue' does not contain $Exe (checked the path itself, and its 'bin' subdirectory)."
    }

    # 2. PATH.
    $baseName = [IO.Path]::GetFileNameWithoutExtension($Exe)
    $cmd = Get-Command $baseName -CommandType Application -ErrorAction SilentlyContinue |
           Select-Object -First 1
    if ($cmd -and $cmd.Source -and (Test-Path -LiteralPath $cmd.Source)) {
        return (Resolve-Path -LiteralPath $cmd.Source).Path
    }

    # 3. Known install directories.
    foreach ($cand in $CandidateDirs) {
        foreach ($dir in (Expand-VexDirCandidate $cand)) {
            $hit = Test-VexExeInDir $dir $Exe
            if ($hit) { return $hit }
            $hit = Test-VexExeInDir (Join-Path $dir "bin") $Exe
            if ($hit) { return $hit }
        }
    }

    # 4. Registry.
    if ($RegistryDisplayNameLike) {
        foreach ($dir in (Get-VexRegistryInstallDirs $RegistryDisplayNameLike)) {
            $hit = Test-VexExeInDir $dir $Exe
            if ($hit) { return $hit }
        }
    }

    # 5. Bounded probe.
    if ($AllowProbe) {
        $hit = Find-VexExeByProbe $Exe
        if ($hit) { return $hit }
    }

    return $null
}

# ------------------------------------------------------------------
# Cache
#
# Discovery is cheap but not free (the registry scan and the probe both cost
# real time). Cache resolved paths in build\toolchain.local.json and
# re-validate each entry with Test-Path on load, so an uninstall or a moved
# install can never produce a stale-path build failure.
#
# This file is machine-specific: it should not be committed.
# ------------------------------------------------------------------
function Get-VexToolchainCachePath([string]$RepoRoot) {
    return (Join-Path (Join-Path $RepoRoot "build") "toolchain.local.json")
}

function Read-VexToolchainCache([string]$RepoRoot) {
    $path = Get-VexToolchainCachePath $RepoRoot
    if (-not (Test-Path -LiteralPath $path)) { return @{} }
    try {
        $raw = Get-Content -LiteralPath $path -Raw -ErrorAction Stop
        if ([string]::IsNullOrWhiteSpace($raw)) { return @{} }
        $obj = $raw | ConvertFrom-Json -ErrorAction Stop
    } catch {
        # A corrupt cache must never be fatal - discard and rediscover.
        return @{}
    }
    $out = @{}
    foreach ($p in $obj.PSObject.Properties) {
        if ($p.Value -and (Test-Path -LiteralPath $p.Value -PathType Leaf)) {
            $out[$p.Name] = $p.Value
        }
    }
    return $out
}

function Write-VexToolchainCache([string]$RepoRoot, [hashtable]$Tools) {
    $path = Get-VexToolchainCachePath $RepoRoot
    try {
        $dir = Split-Path -Parent $path
        if (-not (Test-Path -LiteralPath $dir)) {
            New-Item -ItemType Directory -Force -Path $dir | Out-Null
        }
        $obj = New-Object psobject
        foreach ($k in ($Tools.Keys | Sort-Object)) {
            Add-Member -InputObject $obj -MemberType NoteProperty -Name $k -Value $Tools[$k]
        }
        ($obj | ConvertTo-Json) | Set-Content -LiteralPath $path -Encoding ASCII
    } catch {
        # Caching is an optimisation. Never fail a build over it.
        Write-Verbose "Could not write toolchain cache: $($_.Exception.Message)"
    }
}

# ------------------------------------------------------------------
# Tool table
# ------------------------------------------------------------------
function Get-VexToolSpecs {
    $llvmDirs = Get-VexLlvmCandidateDirs
    $llvmHint = "Install LLVM (provides clang, lld-link, ld.lld, llvm-objcopy): https://releases.llvm.org/ or 'winget install LLVM.LLVM'. If it is already installed somewhere unusual, set `$env:VEXOS_LLVM_BIN to its bin directory."
    $nasmHint = "Install NASM: https://www.nasm.us/ or 'winget install NASM.NASM'. The NASM installer does not add itself to PATH (upstream bug 3392224), which is fine - this script searches the standard install locations. If yours is elsewhere, set `$env:VEXOS_NASM to the directory containing nasm.exe."
    $qemuHint = "Install QEMU: https://www.qemu.org/download/#windows or 'winget install SoftwareFreedomConservancy.QEMU'. If it is already installed somewhere unusual, set `$env:VEXOS_QEMU to the directory containing qemu-system-x86_64.exe."

    return @(
        @{ Key="clang";        Exe="clang.exe";              Group="llvm"; Dirs=$llvmDirs;                    Reg="LLVM*";  Override=(Get-VexEnvPath "VEXOS_LLVM_BIN"); Hint=$llvmHint }
        @{ Key="lld-link";     Exe="lld-link.exe";           Group="llvm"; Dirs=$llvmDirs;                    Reg="LLVM*";  Override=(Get-VexEnvPath "VEXOS_LLVM_BIN"); Hint=$llvmHint }
        @{ Key="ld.lld";       Exe="ld.lld.exe";             Group="llvm"; Dirs=$llvmDirs;                    Reg="LLVM*";  Override=(Get-VexEnvPath "VEXOS_LLVM_BIN"); Hint=$llvmHint }
        @{ Key="llvm-objcopy"; Exe="llvm-objcopy.exe";       Group="llvm"; Dirs=$llvmDirs;                    Reg="LLVM*";  Override=(Get-VexEnvPath "VEXOS_LLVM_BIN"); Hint=$llvmHint }
        @{ Key="nasm";         Exe="nasm.exe";               Group="nasm"; Dirs=(Get-VexNasmCandidateDirs);   Reg="NASM*";  Override=(Get-VexEnvPath "VEXOS_NASM");     Hint=$nasmHint }
        @{ Key="qemu";         Exe="qemu-system-x86_64.exe"; Group="qemu"; Dirs=(Get-VexQemuCandidateDirs);   Reg="QEMU*";  Override=(Get-VexEnvPath "VEXOS_QEMU");     Hint=$qemuHint }
    )
}

# ------------------------------------------------------------------
# Public entry point
#
# -Require takes group names: "llvm", "nasm", "qemu". Only the requested
# groups are resolved, so run-qemu.ps1 does not pay for LLVM discovery and
# build.ps1 does not require QEMU to be installed at all.
# ------------------------------------------------------------------
function Resolve-VexToolchain {
    param(
        [Parameter(Mandatory=$true)][string]$RepoRoot,
        [string[]]$Require = @("llvm","nasm"),
        [switch]$Refresh,
        [switch]$Quiet
    )

    $cache = @{}
    if (-not $Refresh) { $cache = Read-VexToolchainCache $RepoRoot }

    $specs   = Get-VexToolSpecs | Where-Object { $Require -contains $_.Group }
    $tools   = @{}
    $missing = @()
    $newDirs = @()

    foreach ($spec in $specs) {
        $path = $null

        # Cache is only trusted when there is no env override in play, so an
        # override always takes effect immediately rather than next -Refresh.
        if ([string]::IsNullOrWhiteSpace($spec.Override) -and $cache.ContainsKey($spec.Key)) {
            $path = $cache[$spec.Key]
        }

        if (-not $path) {
            try {
                $path = Resolve-VexTool -Exe $spec.Exe -CandidateDirs $spec.Dirs `
                            -RegistryDisplayNameLike $spec.Reg -OverrideValue $spec.Override -AllowProbe
            } catch {
                $missing += @{ Key=$spec.Key; Exe=$spec.Exe; Hint=$_.Exception.Message }
                continue
            }
        }

        if ($path) {
            $tools[$spec.Key] = $path
            $newDirs += (Split-Path -Parent $path)
        } else {
            $missing += @{ Key=$spec.Key; Exe=$spec.Exe; Hint=$spec.Hint }
        }
    }

    if ($missing.Count -gt 0) {
        $lines = @("Required build tools were not found.", "")
        foreach ($m in $missing) {
            $lines += "  MISSING: $($m.Exe)"
            $lines += "    $($m.Hint)"
            $lines += ""
        }
        $lines += "Searched, in order: env override, build\toolchain.local.json cache, PATH,"
        $lines += "standard install directories (Program Files, winget, chocolatey, scoop, msys2,"
        $lines += "Visual Studio), registry uninstall entries, then a depth-limited filesystem probe."
        $lines += "If the tool really is installed, set the env override shown above and re-run."
        throw ($lines -join "`n")
    }

    # Put every resolved directory on the PATH of THIS process only. Child
    # processes (clang invoking its own subtools, nasm loading its DLLs) then
    # inherit a working environment, and the user's persistent PATH is left
    # exactly as it was.
    $sep = [IO.Path]::PathSeparator
    $existing = ($env:PATH -split [regex]::Escape($sep)) |
                Where-Object { $_ } |
                ForEach-Object { $_.TrimEnd('\','/') }
    $toAdd = @()
    foreach ($d in ($newDirs | Select-Object -Unique)) {
        $norm = $d.TrimEnd('\','/')
        # Windows paths are case-insensitive, so compare case-insensitively -
        # otherwise a differently-cased PATH entry causes a duplicate on
        # every single run.
        $already = $false
        foreach ($e in $existing) {
            if ([string]::Equals($e, $norm, [StringComparison]::OrdinalIgnoreCase)) { $already = $true; break }
        }
        if (-not $already) { $toAdd += $d }
    }
    if ($toAdd.Count -gt 0) {
        $env:PATH = (($toAdd -join $sep) + $sep + $env:PATH)
    }

    Write-VexToolchainCache $RepoRoot $tools

    if (-not $Quiet) {
        foreach ($k in ($tools.Keys | Sort-Object)) {
            Write-Host ("  {0,-13} {1}" -f $k, $tools[$k])
        }
        if ($toAdd.Count -gt 0) {
            Write-Host "  (added to this session's PATH only: $($toAdd -join '; '))" -ForegroundColor DarkGray
        }
    }

    return $tools
}
