#include "accounts.h"
#include "crypto.h"
#include "timer.h"
static int active_ = -1; static uint32_t kdf_iters = ACCT_KDF_ITERS; static uint64_t salt_ctr;
static uint64_t rdtsc_(void) { uint32_t lo, hi; __asm__ volatile("rdtsc" : "=a"(lo), "=d"(hi)); return ((uint64_t)hi << 32) | lo; }
static int rdrand_(uint64_t *v) { uint32_t a = 1, b, c, d; __asm__ volatile("cpuid" : "+a"(a), "=b"(b), "=c"(c), "=d"(d)); if (!((c >> 30) & 1)) return 0;
    for (int i = 0; i < 10; i++) { unsigned char ok; __asm__ volatile("rdrand %0; setc %1" : "=r"(*v), "=qm"(ok)); if (ok) return 1; } return 0; }
/* Salts need UNIQUENESS, not secrecy. Source: RDRAND when the CPU has it, always mixed with TSC + tick + a counter
 * through SHA-256. QEMU's default CPU has no RDRAND, so there the salt is TSC/tick-derived: unique, but not a CSPRNG. */
static void make_salt(uint8_t out[16])
{
    uint64_t in[5]; Sha256 c; uint8_t d[32];
    in[0] = rdtsc_(); in[1] = timer_ticks(); in[2] = ++salt_ctr; in[3] = 0; if (!rdrand_(&in[3])) in[3] = rdtsc_() * 0x9E3779B97F4A7C15ull; in[4] = rdtsc_();
    sha256_init(&c); sha256_update(&c, in, sizeof in); sha256_final(&c, d);
    for (int i = 0; i < 16; i++) out[i] = d[i];
}
static int slen_(const char *s) { int n = 0; while (s && s[n] && n < 4096) n++; return n; }
static Account tab[ACCT_MAX]; static int n, sel = -1; static uint32_t next_uid = 1000; static int inject_fail;
static int ram_store(const Account *a, int cnt) { (void)a; (void)cnt; if (inject_fail) { inject_fail = 0; return -1; } return 0; }
static const AcctBackend ram = { "RAM (temporary - lost on reboot)", 0, ram_store };
static const AcctBackend *be = &ram;
void acct_init(void) { n = 0; sel = -1; active_ = -1; kdf_iters = ACCT_KDF_ITERS; next_uid = 1000; inject_fail = 0; be = &ram; }
const AcctBackend *acct_backend(void) { return be; }
void acct_test_fail_next_store(int f) { inject_fail = f; }
static char lower(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
static int alnum(char c) { return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9'); }
static int streq_ci(const char *a, const char *b) { while (*a && lower(*a) == lower(*b)) { a++; b++; } return lower(*a) == lower(*b); }
AcctResult acct_validate(const char *s)
{
    if (!s) return ACCT_ERR_EMPTY;
    int len = 0; while (s[len] && len < 256) len++;
    if (len >= 256) return ACCT_ERR_LONG;
    int blank = 1; for (int i = 0; i < len; i++) if (s[i] != ' ' && s[i] != '\t') blank = 0;
    if (blank) return ACCT_ERR_EMPTY;
    if (s[0] == ' ' || s[len - 1] == ' ') return ACCT_ERR_SPACE;
    for (int i = 0; i < len; i++) {
        char c = s[i];
        if (c == ' ') { if (s[i + 1] == ' ') return ACCT_ERR_SPACE; continue; }
        if (!(alnum(c) || c == '_' || c == '.' || c == '-')) return ACCT_ERR_CHAR;
    }
    if (!alnum(s[0])) return ACCT_ERR_CHAR;
    if (len < ACCT_NAME_MIN) return ACCT_ERR_SHORT;
    if (len > ACCT_NAME_MAX) return ACCT_ERR_LONG;
    return ACCT_OK;
}
int acct_find(const char *name) { for (int i = 0; i < n; i++) if (streq_ci(tab[i].id, name)) return i; return -1; }
static AcctResult add_account(const char *name, const char *pw, int role)
{
    AcctResult v = acct_validate(name);
    if (v != ACCT_OK) return v;
    if (acct_find(name) >= 0) return ACCT_ERR_DUP;
    if (n >= ACCT_MAX) return ACCT_ERR_FULL;
    Account *a = &tab[n]; int i = 0;
    for (; name[i] && i < ACCT_NAME_MAX; i++) { a->display[i] = name[i]; a->id[i] = lower(name[i]); }
    a->display[i] = a->id[i] = 0; a->uid = next_uid; a->role = (uint8_t)role; a->has_pw = pw != 0; a->iters = kdf_iters;
    for (int k = 0; k < 16; k++) { a->salt[k] = 0; }
    for (int k = 0; k < 32; k++) { a->hash[k] = 0; }
    if (pw) { make_salt(a->salt); pbkdf2_hmac_sha256((const uint8_t *)pw, (size_t)slen_(pw), a->salt, 16, a->iters, a->hash); }
    n++;
    if (be->store(tab, n) != 0) { n--; return ACCT_ERR_STORE; }           /* roll back: nothing half-created */
    if (acct_find(name) != n - 1) { n--; return ACCT_ERR_STORE; }          /* verify it can be retrieved */
    next_uid++;
    return ACCT_OK;
}
/* Passwordless creation: kept for unit tests and the dev seed only. The UI never offers it. */
AcctResult acct_create(const char *name) { return add_account(name, 0, n == 0 ? ACCT_ROLE_ADMIN : ACCT_ROLE_STANDARD); }
AcctResult acct_validate_password(const char *pw)
{
    int l = slen_(pw);
    if (l < ACCT_PW_MIN) return ACCT_ERR_PWSHORT;
    if (l > ACCT_PW_MAX) return ACCT_ERR_PWLONG;
    for (int i = 0; i < l; i++) if (pw[i] < 32 || pw[i] > 126) return ACCT_ERR_PWCHAR;
    return ACCT_OK;
}
AcctResult acct_create_pw(const char *name, const char *pw, int caller)
{
    if (n == 0) { if (caller != -1) return ACCT_ERR_DENIED; }                         /* first-run: no one is authenticated yet */
    else if (caller < 0 || caller >= n || tab[caller].role != ACCT_ROLE_ADMIN || active_ != caller) return ACCT_ERR_DENIED;   /* must be the AUTHENTICATED admin */
    AcctResult v = acct_validate(name); if (v != ACCT_OK) return v;
    v = acct_validate_password(pw); if (v != ACCT_OK) return v;
    return add_account(name, pw, n == 0 ? ACCT_ROLE_ADMIN : ACCT_ROLE_STANDARD);
}
#ifdef VEX_DEV_SEED_ACCOUNTS
AcctResult acct_dev_create_pw(const char *name, const char *pw, int role) { return add_account(name, pw, role); }
#endif
int acct_has_password(int i) { return i >= 0 && i < n && tab[i].has_pw; }
int acct_role(int i) { return (i >= 0 && i < n) ? tab[i].role : -1; }
int acct_verify(int i, const char *pw)
{
    if (i < 0 || i >= n) return 0;
    if (!pw) pw = "";
    if (!tab[i].has_pw) return slen_(pw) == 0;
    uint8_t d[32]; pbkdf2_hmac_sha256((const uint8_t *)pw, (size_t)slen_(pw), tab[i].salt, 16, tab[i].iters, d);
    int ok = ct_equal(d, tab[i].hash, 32); secure_zero(d, 32); return ok;
}
int acct_login(int i, const char *pw) { active_ = -1; if (!acct_verify(i, pw)) return 0; active_ = i; return 1; }
void acct_logout(void) { active_ = -1; }
int acct_active(void) { return active_; }
void acct_test_set_iters(uint32_t k) { kdf_iters = k ? k : 1; }

const char *acct_result_msg(AcctResult r)
{
    switch (r) {
    case ACCT_OK: return "Account created.";
    case ACCT_ERR_EMPTY: return "Account name cannot be empty.";
    case ACCT_ERR_SHORT: return "Account name must be at least 3 characters.";
    case ACCT_ERR_LONG: return "Account name must be at most 32 characters.";
    case ACCT_ERR_CHAR: return "Use letters, digits, space, _ . - (start with a letter or digit).";
    case ACCT_ERR_SPACE: return "No leading, trailing or repeated spaces.";
    case ACCT_ERR_DUP: return "That account name is already in use.";
    case ACCT_ERR_FULL: return "The account list is full (16 accounts).";
    case ACCT_ERR_DENIED: return "Only an administrator can create accounts.";
    case ACCT_ERR_PWSHORT: return "Password must be at least 6 characters.";
    case ACCT_ERR_PWLONG: return "Password must be at most 64 characters.";
    case ACCT_ERR_PWCHAR: return "Password may use printable ASCII only.";
    default: return "Could not store the account. Please try again.";
    }
}
int acct_count(void) { return n; }
const Account *acct_get(int i) { return (i >= 0 && i < n) ? &tab[i] : 0; }
int acct_selected(void) { return sel; }
int acct_select(int i) { if (i < 0 || i >= n) return 0; sel = i; return 1; }
