/*
 * Vex OS - kernel/include/apps.h : application registry + application tracker (DESKTOP-01).
 *
 * REGISTRY: static metadata for apps the desktop can launch (name, description, pinned). Pinned list and
 * search are driven from it, so adding an app is one table entry.
 * TRACKER: records applications LAUNCHED THROUGH THE DESKTOP SHELL: an instance id, name, kind and start
 * time. It is NOT a kernel process table: there are no PIDs of kernel tasks, no memory/CPU figures. VEX OS
 * has no scheduler or process model yet, and nothing here pretends otherwise.
 * Instance ids are issued by the tracker, monotonic from 1001 within a desktop session (numbering restarts when a
 * session begins) and never reused inside it.
 */
#ifndef VEXOS_APPS_H
#define VEXOS_APPS_H
#include <stdint.h>
#define APP_ID_TERMINAL 1u
#define APP_ID_TASKMGR 2u
#define APP_ID_EXPLORER 3u
#define APP_ID_VALBOOK 4u
#define APP_ID_SETTINGS 5u
#define APPS_TRACK_MAX 8
typedef struct { uint32_t app_id; const char *name; const char *desc; int pinned; } AppInfo;
typedef struct { uint32_t inst_id, app_id; const char *name, *kind; uint64_t started_ms; } AppInst;
int  apps_registry_count(void);
const AppInfo *apps_registry_get(int i);
int  apps_search(const char *query, int *out, int max);       /* case-insensitive substring; empty = all; returns hits */
uint64_t apps_now_ms(void);
void apps_tracker_reset(void);
int  apps_session_begin(void);                                  /* tracks "Desktop" (System) */
void apps_session_end(void);                                    /* closes every tracked app */
uint32_t apps_launch(uint32_t app_id, int *already_running);    /* 0 = failure; single instance per app */
void apps_close(uint32_t app_id);
int  apps_running(uint32_t app_id);                             /* 1 if a shell-launched instance exists */
int  apps_tracked_count(void);
const AppInst *apps_tracked_get(int i);
#endif
