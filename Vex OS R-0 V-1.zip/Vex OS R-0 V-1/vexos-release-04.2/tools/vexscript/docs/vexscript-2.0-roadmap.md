# VexScript 2.0 Roadmap — COMPLETE

| Phase | Status |
|-------|--------|
| A Modules | done |
| B Vex IR | done |
| C Projects/CLI | done |
| D Hosted vex::* | done |
| E x86-64 backend | done |
| F Multi-file + strings | done |

Next generation: **VexScript+** (not started in 2.0).
