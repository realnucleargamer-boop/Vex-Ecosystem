/*
 * Vex OS - kernel/src/arch/x86_64/apic/ipi.c
 *
 * KERNEL-01 Phase 3 - fixed-delivery IPIs. See kernel/include/ipi.h for
 * scope, guarantees, and the locking argument.
 *
 * Register numbers and ICR field encodings are from the Intel SDM Volume
 * 3A, Chapter 11: Table 11-1 "Local APIC Register Address Map" and
 * Figure 11-12 "Interrupt Command Register (ICR)".
 */

#include "ipi.h"
#include "irq.h"
#include "lapic.h"
#include "acpi.h"
#include "serial.h"

/* ICR halves. Defined here rather than shared with lapic.c because
 * lapic.c keeps its register map private and timer.c already sets the
 * precedent of a subsystem declaring the registers it touches. The two
 * offsets are also asserted against lapic.c's behaviour indirectly: if
 * they were wrong, no IPI would ever be delivered and every Phase 3
 * test would fail rather than quietly pass. */
#define ICR_LOW  0x300
#define ICR_HIGH 0x310

/* ICR low fields. Delivery mode 000 = Fixed and destination mode 0 =
 * Physical are both encoded as zero, so they are named here for the
 * reader rather than OR'd in. */
#define ICR_LEVEL_ASSERT     (1u << 14)  /* must be 1 for fixed delivery */
#define ICR_DELIVERY_PENDING (1u << 12)  /* read-only: send in progress */
#define ICR_DEST_ALL_EXCL_SELF (3u << 18)

/* Spin budget for the delivery-status bit, in iterations.
 *
 * This is a bound, not a duration, and that limitation is stated rather
 * than hidden: there is no calibrated time source usable here (the PIT is
 * a shared device and this path may run in interrupt context), so the
 * budget cannot be expressed in microseconds. What matters for the
 * guarantee in ipi.h is that it is FINITE - a send cannot hang the
 * sender - not that it corresponds to a specific wall-clock time.
 *
 * lapic.c's lapic_wait_ipi_idle() uses the same order of magnitude for
 * AP startup, where it has proven sufficient across every CPU count
 * tested. Sized generously because the cost of an over-long budget is a
 * slow failure on a broken machine, while the cost of a short one is a
 * spurious timeout on a working one. */
#define IPI_DELIVERY_SPIN_BUDGET 1000000u

static const SmpInfo *g_smp;
static uint64_t       g_base;
static int            g_ready;

static uint64_t g_sent;
static uint64_t g_rejects;
static uint64_t g_timeouts;

const char *ipi_result_name(IpiResult r)
{
    switch (r) {
    case IPI_OK:                   return "ok";
    case IPI_ERR_NOT_READY:        return "IPI layer not initialized";
    case IPI_ERR_BAD_VECTOR:       return "vector invalid or unhandled";
    case IPI_ERR_TARGET_OFFLINE:   return "target APIC ID is not online";
    case IPI_ERR_TARGET_IS_SELF:   return "target is the calling CPU";
    case IPI_ERR_BUSY:             return "previous IPI never accepted";
    case IPI_ERR_DELIVERY_TIMEOUT: return "delivery status never cleared";
    default:                       return "unknown";
    }
}

int ipi_init(const SmpInfo *smp, uint64_t lapic_base)
{
    g_smp   = smp;
    g_base  = lapic_base;
    g_ready = (smp != 0 && lapic_base != 0) ? 1 : 0;
    return g_ready;
}

int ipi_target_is_online(uint32_t apic_id)
{
    if (g_smp == 0) return 0;

    for (uint32_t i = 0; i < ACPI_MAX_CPUS; i++) {
        const CpuInfo *c = &g_smp->cpus[i];
        if (c->state != CPU_STATE_ONLINE && c->state != CPU_STATE_BSP) {
            continue;
        }
        /* The BSP never reports its own ID through ap_entry(), so its
         * MADT-declared ID is the only one available for it; an AP has
         * both, and they were already checked equal by the SMP tests. */
        if (c->expected_apic_id == apic_id) return 1;
    }
    return 0;
}

uint64_t ipi_sent_count(void)    { return g_sent; }
uint64_t ipi_reject_count(void)  { return g_rejects; }
uint64_t ipi_timeout_count(void) { return g_timeouts; }

/* Validates the vector for every send path.
 *
 * Requiring a REGISTERED handler is the non-obvious rule here, and it is
 * deliberate. Hardware will happily deliver a vector nothing handles;
 * the receiver's dispatcher would count it as unhandled, EOI it, and
 * carry on, while the sender saw a successful send. That combination -
 * "sent fine" plus "silently discarded" - is the single most misleading
 * state this layer could produce, and it is the exact failure mode a
 * shootdown that never runs would present as. Refusing at the sender
 * turns it into an error at the place that can still report one. */
static IpiResult validate_vector(uint32_t vector)
{
    if (vector < IRQ_FIRST_VECTOR || vector > 255) return IPI_ERR_BAD_VECTOR;
    if (vector == lapic_spurious_vector())         return IPI_ERR_BAD_VECTOR;
    if (irq_handler_for(vector) == 0)              return IPI_ERR_BAD_VECTOR;
    return IPI_OK;
}

/* Spins until the local APIC reports the last IPI accepted, or the budget
 * runs out. Returns 1 if idle. */
static int wait_delivery_idle(void)
{
    for (uint32_t i = 0; i < IPI_DELIVERY_SPIN_BUDGET; i++) {
        if ((lapic_reg_read(g_base, ICR_LOW) & ICR_DELIVERY_PENDING) == 0) {
            return 1;
        }
        __asm__ volatile ("pause");
    }
    return 0;
}

/* The one place that writes the ICR.
 *
 * `icr_high` and `icr_low` are fully formed by the caller so that this
 * function contains no policy - it is purely the ordered, interrupt-safe
 * register write plus the bounded waits around it.
 *
 * ORDERING IS LOAD-BEARING: ICR_HIGH (the destination) must be written
 * BEFORE ICR_LOW, because writing the low half is what triggers the
 * send. Reversing them sends to whatever destination was left over from
 * the previous IPI. lapic.c's INIT/SIPI path depends on the same order.
 */
static IpiResult write_icr(uint32_t icr_high, uint32_t icr_low)
{
    /* Mask interrupts across the pair. Without this, an interrupt taken
     * between the two writes whose handler also sends an IPI would
     * overwrite ICR_HIGH and this send would go to the wrong CPU. Saving
     * and restoring RFLAGS rather than unconditionally re-enabling
     * matters because this function may be called from interrupt context,
     * where a bare `sti` would enable interrupts inside a handler that
     * was entered with them disabled. */
    uint64_t flags;
    __asm__ volatile ("pushfq; pop %0; cli" : "=r"(flags) :: "memory");

    IpiResult r = IPI_OK;

    /* A previous send still pending means the LAPIC has not accepted it.
     * Reported as BUSY rather than waited on indefinitely, and
     * distinguished from this send timing out, because the two point at
     * different problems: BUSY means the machine was already wedged
     * before this call. */
    if (!wait_delivery_idle()) {
        r = IPI_ERR_BUSY;
    } else {
        lapic_reg_write(g_base, ICR_HIGH, icr_high);
        lapic_reg_write(g_base, ICR_LOW,  icr_low);

        /* Wait for THIS send to be accepted, so that a caller which then
         * waits on a memory acknowledgement can distinguish "the message
         * never left" from "the receiver never ran". */
        if (!wait_delivery_idle()) {
            r = IPI_ERR_DELIVERY_TIMEOUT;
        }
    }

    __asm__ volatile ("push %0; popfq" :: "r"(flags) : "memory", "cc");

    if (r == IPI_OK) {
        __atomic_fetch_add(&g_sent, 1, __ATOMIC_RELAXED);
    } else if (r == IPI_ERR_DELIVERY_TIMEOUT || r == IPI_ERR_BUSY) {
        __atomic_fetch_add(&g_timeouts, 1, __ATOMIC_RELAXED);
    }
    return r;
}

static IpiResult reject(IpiResult r)
{
    __atomic_fetch_add(&g_rejects, 1, __ATOMIC_RELAXED);
    return r;
}

/* This CPU's APIC ID, read from its own LAPIC. Read rather than taken
 * from per-CPU storage so that the self-targeting check does not depend
 * on percpu being up on the calling CPU. */
static uint32_t my_apic_id(void)
{
    return lapic_read_own_id(g_base);
}

IpiResult ipi_send(uint32_t apic_id, uint32_t vector)
{
    if (!g_ready) return reject(IPI_ERR_NOT_READY);

    IpiResult v = validate_vector(vector);
    if (v != IPI_OK) return reject(v);

    if (!ipi_target_is_online(apic_id)) {
        return reject(IPI_ERR_TARGET_OFFLINE);
    }
    if (apic_id == my_apic_id()) {
        return reject(IPI_ERR_TARGET_IS_SELF);
    }

    return write_icr(apic_id << 24, vector | ICR_LEVEL_ASSERT);
}

IpiResult ipi_send_self(uint32_t vector)
{
    if (!g_ready) return reject(IPI_ERR_NOT_READY);

    IpiResult v = validate_vector(vector);
    if (v != IPI_OK) return reject(v);

    /* Physical destination mode addressed at this CPU's own ID, rather
     * than the "self" destination shorthand. Both work; using the same
     * encoding as a targeted send means this path exercises the identical
     * code, so a passing self-IPI test is evidence about the mechanism a
     * real targeted send uses. */
    return write_icr(my_apic_id() << 24, vector | ICR_LEVEL_ASSERT);
}

IpiResult ipi_broadcast_others(uint32_t vector)
{
    if (!g_ready) return reject(IPI_ERR_NOT_READY);

    IpiResult v = validate_vector(vector);
    if (v != IPI_OK) return reject(v);

    /* ICR_HIGH is irrelevant with a destination shorthand, but is written
     * as zero rather than left stale so that the register state after a
     * broadcast is not a leftover from an unrelated targeted send. */
    return write_icr(0, vector | ICR_LEVEL_ASSERT | ICR_DEST_ALL_EXCL_SELF);
}
