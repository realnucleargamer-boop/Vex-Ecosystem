# Vex IR 1.4

**Status:** Current emit version  
**Producers:** VexScript **3.1.0**, VEX-C **5.1.0**

## Compatibility

Accepts modules tagged `0.1` … `1.4`.  
Default emit: `ir_version 1.4`.

Additive vs 1.3: version tag only (instruction set unchanged).  
Tensor / neural / evolve remain hosted `call @…` builtins.

```text
; Vex IR 1.4
ir_version 1.4
calling_conv vex_hosted
```
