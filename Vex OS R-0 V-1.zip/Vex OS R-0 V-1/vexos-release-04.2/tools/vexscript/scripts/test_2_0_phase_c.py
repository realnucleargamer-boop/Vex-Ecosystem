#!/usr/bin/env python3
"""VexScript 2.0 Phase C — projects, vex.toml, vexc CLI"""
import sys, os, tempfile, shutil, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vexscript.project import load_manifest, load_project, find_project_root
from vexscript.errors import VexError
from vexscript.cli import main as vexc_main

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

def vexc(args, cwd=None):
    old = os.getcwd()
    try:
        if cwd:
            os.chdir(cwd)
        # capture via subprocess for isolation
        env = os.environ.copy()
        env["PYTHONPATH"] = str(ROOT / "src")
        r = subprocess.run(
            [sys.executable, "-m", "vexscript.cli", *args],
            capture_output=True, text=True, cwd=cwd or old, env=env,
        )
        return r.returncode, r.stdout, r.stderr
    finally:
        os.chdir(old)

print("VexScript 2.0 Phase C Tests")

hello = ROOT / "examples" / "hello_project"

print("\n=== Manifest ===")
cfg = load_manifest(hello)
check("valid vex.toml", cfg.name == "hello" and cfg.version == "0.1.0")

try:
    find_project_root(Path("/tmp"))
    check("missing manifest", False)
except VexError as e:
    check("missing manifest", "E0401" in str(e), str(e))

with tempfile.TemporaryDirectory() as td:
    td = Path(td)
    (td / "vex.toml").write_text("not = [valid\n")
    try:
        load_manifest(td)
        check("malformed TOML", False)
    except VexError as e:
        check("malformed TOML", "E0402" in str(e), str(e))

with tempfile.TemporaryDirectory() as td:
    td = Path(td)
    (td / "vex.toml").write_text('[package]\nname = "x"\nversion = "1"\n[build]\nentry = "nope.vex"\n')
    try:
        load_manifest(td)
        check("invalid entry", False)
    except VexError as e:
        check("invalid entry", "E0403" in str(e), str(e))

with tempfile.TemporaryDirectory() as td:
    td = Path(td)
    (td / "vex.toml").write_text('[package]\nname = "x"\n')
    try:
        load_manifest(td)
        check("missing build", False)
    except VexError as e:
        check("missing build", "E0402" in str(e), str(e))

print("\n=== CLI ===")
rc, out, err = vexc(["check", str(hello)])
check("vexc check", rc == 0 and "check ok" in out, err or out)

rc, out, err = vexc(["build", str(hello)])
check("vexc build", rc == 0 and (hello / "build" / "project.ir").is_file(), err or out)

rc, out, err = vexc(["run", str(hello)])
check("vexc run", rc == 0 and "30" in out, err or out)

rc, out, err = vexc(["emit-ir", str(hello)])
check("vexc emit-ir", rc == 0 and "func @main" in out, err)

a = out
rc, out2, _ = vexc(["emit-ir", str(hello)])
check("IR deterministic", out == out2)

rc, out, err = vexc(["nope"])
check("invalid command", rc != 0)

rc, out, err = vexc(["check"], cwd="/tmp")
check("missing project cwd", rc != 0 and ("E0401" in err or "vex.toml" in err), err)

print("\n=== Multi-file privacy ===")
with tempfile.TemporaryDirectory() as td:
    td = Path(td)
    (td / "vex.toml").write_text(
        '[package]\nname = "t"\nversion = "0.1.0"\n[build]\nentry = "src/main.vex"\n'
    )
    (td / "src").mkdir()
    (td / "src" / "m.vex").write_text("fn secret() -> i64 { return 1; }\npub fn ok() -> i64 { return 2; }\n")
    (td / "src" / "main.vex").write_text("import m;\nfn main() -> i32 { m::secret(); return 0; }\n")
    rc, out, err = vexc(["check", str(td)])
    check("private rejected", rc != 0 and "E0004" in err, err)

    (td / "src" / "main.vex").write_text("import m;\nfn main() -> i32 { println(m::ok()); return 0; }\n")
    rc, out, err = vexc(["run", str(td)])
    check("public ok", rc == 0 and "2" in out, err or out)

print(f"\n=== Phase C Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
