/*
 * Vex OS - kernel/include/ipi.h
 *
 * KERNEL-01 Phase 3: inter-processor interrupts.
 *
 * SCOPE. Fixed-delivery IPIs only, to one CPU by APIC ID or to all CPUs
 * except the sender. That is exactly what Phase 4's TLB shootdown needs
 * and nothing more: no lowest-priority delivery, no logical destination
 * mode, no NMI or SMI delivery, no cluster addressing, no x2APIC. INIT
 * and SIPI already have their own paths in lapic.c for AP startup and
 * are deliberately not reachable through here - a general "send any
 * delivery mode" entry point would make it possible to reset a CPU by
 * passing the wrong enum.
 *
 * WHAT THIS LAYER GUARANTEES
 *
 *   - The vector is one that can actually be handled. Sending a vector
 *     with no registered handler is refused rather than delivered,
 *     because the receiver would count it as unhandled and the sender
 *     would have no way to know.
 *   - The target exists and is online. Sending to an APIC ID that never
 *     came up is refused, not attempted: a fixed-delivery IPI to an
 *     absent CPU is never accepted, so the delivery-status bit would
 *     stay set and the sender would spin out its whole timeout budget
 *     for a mistake that is knowable in advance.
 *   - Sending is bounded in time. Every send waits for the LAPIC to
 *     report the previous IPI accepted, before and after writing the
 *     ICR, with a finite spin budget. A send NEVER blocks forever, even
 *     if the target is wedged.
 *
 * WHAT IT DOES NOT GUARANTEE
 *
 *   Delivery-status clear means the LOCAL APIC accepted the message for
 *   transmission. It does not mean the target CPU has run the handler,
 *   and it must not be read as an acknowledgement. Anything that needs
 *   to know the receiver actually executed something has to carry its
 *   own acknowledgement in memory - which is precisely what Phase 4's
 *   shootdown protocol does, and why the ack there is a memory flag and
 *   not an ICR bit.
 *
 * LOCKING. None, and none is possible to need: the ICR is a per-CPU
 * register, so two CPUs sending at once are writing different physical
 * registers. The only re-entrancy hazard is this CPU taking an interrupt
 * between the two halves of its own ICR write and sending a second IPI
 * from the handler, which would corrupt the pair. ipi_send() therefore
 * masks interrupts around the ICR sequence only - it takes no VMM or PMM
 * lock, which is what allows it to be called from interrupt context, as
 * Phase 4 requires.
 */

#ifndef VEXOS_IPI_H
#define VEXOS_IPI_H

#include <stdint.h>
#include "smp.h"

typedef enum {
    IPI_OK = 0,
    IPI_ERR_NOT_READY,        /* ipi_init() has not run, or no LAPIC */
    IPI_ERR_BAD_VECTOR,       /* exception range, spurious, or unhandled */
    IPI_ERR_TARGET_OFFLINE,   /* no online CPU has that APIC ID */
    IPI_ERR_TARGET_IS_SELF,   /* use of the targeted path to reach self */
    IPI_ERR_BUSY,             /* a previous IPI never got accepted */
    IPI_ERR_DELIVERY_TIMEOUT  /* this IPI was not accepted in budget */
} IpiResult;

/* Records the LAPIC base and the CPU inventory used to validate targets.
 * Must be called on the BSP after SMP startup has finished, so that the
 * online set it reads is final. Returns 0 if there is no LAPIC or no
 * inventory, in which case every send will report IPI_ERR_NOT_READY
 * rather than writing to a base of zero. */
int ipi_init(const SmpInfo *smp, uint64_t lapic_base);

/* Sends `vector` to the single CPU whose LAPIC ID is `apic_id`, using
 * fixed delivery and physical destination mode.
 *
 * Refuses to target the calling CPU: a self-IPI is legal in hardware but
 * every caller in this kernel wants "the other CPUs", and silently
 * including self is how a shootdown initiator ends up waiting for its
 * own acknowledgement. ipi_send_self() exists for the one case that
 * genuinely wants it. */
IpiResult ipi_send(uint32_t apic_id, uint32_t vector);

/* Sends `vector` to the calling CPU, via the same fixed-delivery path.
 * Provided so that the delivery mechanism can be tested on one CPU with
 * no dependence on any AP being up, and so a caller that really does
 * mean "including me" has to say so. */
IpiResult ipi_send_self(uint32_t vector);

/* Sends `vector` to every CPU except the sender, using the
 * all-excluding-self destination shorthand - one ICR write regardless of
 * CPU count, rather than a loop of targeted sends.
 *
 * NOTE ON WHAT "EVERY CPU" MEANS: the shorthand is interpreted by
 * hardware and reaches every LAPIC on the bus, including any CPU this
 * kernel considers offline. A CPU that never came up will not respond,
 * which is why any caller that waits for acknowledgements must wait only
 * on the CPUs it knows are online rather than on the number it sent to.
 */
IpiResult ipi_broadcast_others(uint32_t vector);

/* Counters. Sends counts ICR writes that were accepted; rejects counts
 * validation failures that never touched the ICR; timeouts counts sends
 * whose delivery status never cleared. A non-zero timeout count is the
 * signal that the interconnect or a target is misbehaving. */
uint64_t ipi_sent_count(void);
uint64_t ipi_reject_count(void);
uint64_t ipi_timeout_count(void);

/* 1 if an online CPU has this APIC ID. */
int ipi_target_is_online(uint32_t apic_id);

const char *ipi_result_name(IpiResult r);

#endif /* VEXOS_IPI_H */
