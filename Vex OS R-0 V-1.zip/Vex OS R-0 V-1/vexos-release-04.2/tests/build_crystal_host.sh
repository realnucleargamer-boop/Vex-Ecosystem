#!/bin/bash
# Builds the HOSTED test libraries for crystal_core.c (tests only; the kernel build is separate).
set -e; cd "$(dirname "$0")/.."; mkdir -p build/crystal-host
SRC="kernel/src/ai/crystal_core.c tests/crystal_host_shim.c"
gcc -O2 -shared -fPIC -Wall -Wextra -std=gnu11 -Ikernel/include $SRC -o build/crystal-host/libcrystal_O2.so
gcc -O0 -shared -fPIC -Wall -Wextra -std=gnu11 -Ikernel/include $SRC -o build/crystal-host/libcrystal_O0.so
gcc -O1 -g -shared -fPIC -fsanitize=address,undefined -fno-sanitize-recover=undefined -fno-omit-frame-pointer -Wall -Wextra -std=gnu11 -Ikernel/include $SRC -o build/crystal-host/libcrystal_asan.so
echo "built: $(ls build/crystal-host)"
