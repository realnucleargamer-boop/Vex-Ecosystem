#!/usr/bin/env bash
# Vex OS - scripts/fault-inject.sh
#
# BOOT-03 negative controls.
#
# The BOOT-03 self-tests report 105/105 passing. On its own that number
# means nothing: a suite that checks nothing passes just as loudly as a
# suite that checks everything. This script builds the kernel with each
# fault injection in turn (see kernel/include/boot03_inject.h), boots it,
# and asserts that the intended subsystem actually reports FAIL.
#
# An injection that boots clean is a FAILURE of this script, because it
# means the corresponding test does not exercise the invariant it claims
# to.
#
# Each injection breaks the REAL implementation, not the test - with the
# single exception of injection 5, which fabricates a failure in order to
# demonstrate that the summary gate and the external harness are both
# load-bearing.
#
#   ./scripts/fault-inject.sh [ncpus]
#
# Leaves the tree rebuilt with VEX_FAULT_INJECT=0 on exit, so it cannot
# accidentally leave an injected image behind.

set -uo pipefail

NCPUS="${1:-4}"
TIMEOUT=90
LOGDIR="build/fault-logs"
mkdir -p "$LOGDIR"

# injection | subsystem line that must report FAIL | must SYSTEM READY appear?
#
# "no" is the normal case: a broken subsystem must not produce the string
# the rest of scripts/ keys on. Injection 5 is the deliberate exception.
EXPECT=(
    "1|PAGING|no"
    "2|TIMER|no"
    "3|MEMORY|no"
    "4|SMP|no"
    "5|MEMORY|yes"
)

overall=0

restore() {
    echo ""
    echo "--- restoring a clean (VEX_FAULT_INJECT=0) build ---"
    make clean >/dev/null 2>&1
    if make image >/dev/null 2>&1; then
        echo "clean build restored"
    else
        echo "WARNING: could not restore a clean build - rebuild manually"
    fi
}
trap restore EXIT

for spec in "${EXPECT[@]}"; do
    n="${spec%%|*}"
    rest="${spec#*|}"
    sub="${rest%%|*}"
    want_ready="${rest##*|}"

    log="$LOGDIR/inject${n}.log"

    echo ""
    echo "=== fault injection $n : expecting '${sub}: FAIL' ==="

    make clean >/dev/null 2>&1

    # Confirm the injection will actually be compiled in, BEFORE building.
    # A silently ignored -D would make every injection "pass" by booting
    # clean, which is the exact failure mode this script exists to rule
    # out. Checked on a clean tree on purpose: after a successful build
    # `make -n` has nothing left to print.
    # NB: the output is captured first rather than piped straight into
    # `grep -q`. Under `set -o pipefail`, grep -q exits on its first match
    # and SIGPIPEs make, which makes the whole pipeline report failure
    # even though the string was found.
    dryrun=$(make -n VEX_FAULT_INJECT="$n" image 2>/dev/null)
    if ! printf '%s' "$dryrun" | grep -c -- "-DVEX_FAULT_INJECT=$n" >/dev/null; then
        echo "FAIL  injection $n : VEX_FAULT_INJECT=$n never reached the compiler"
        overall=1
        continue
    fi

    if ! make VEX_FAULT_INJECT="$n" image >/dev/null 2>&1; then
        echo "FAIL  injection $n : build failed"
        overall=1
        continue
    fi

    ./scripts/smp-test.sh "$NCPUS" "$TIMEOUT" "$log" "inject$n" >/dev/null 2>&1

    clean=$(tr -d '\000' < "$log" | sed 's/\x1b\[[0-9;=]*[a-zA-Z]//g')

    fail=""

    # 1. The kernel must have got far enough to print a summary at all.
    #    An injection that merely crashes the boot proves nothing about
    #    the test - it has to be the TEST that catches it.
    echo "$clean" | grep -q "^VEX OS BOOT-03" \
        || fail="$fail never-reached-summary"

    # 2. The targeted subsystem must report FAIL.
    echo "$clean" | grep -q "^${sub}: FAIL" || fail="$fail ${sub}-did-not-FAIL"

    # 3. SYSTEM READY must appear only where expected.
    if echo "$clean" | grep -q "^SYSTEM READY"; then
        [ "$want_ready" = "yes" ] || fail="$fail claimed-SYSTEM-READY-anyway"
    else
        [ "$want_ready" = "no" ] || fail="$fail expected-SYSTEM-READY-but-absent"
    fi

    # 4. At least one individual check must have printed FAIL, except for
    #    injection 5, which fabricates the verdict rather than breaking a
    #    real invariant.
    if [ "$n" != "5" ]; then
        cnt=$(echo "$clean" | grep -c "^\[test\] .*: FAIL")
        [ "$cnt" -gt 0 ] || fail="$fail no-individual-check-FAILed"
    fi

    if [ -z "$fail" ]; then
        detail=$(echo "$clean" | grep -m3 "^\[test\] .*: FAIL" | sed 's/^/        /')
        echo "PASS  injection $n : ${sub} correctly reported FAIL"
        [ -n "$detail" ] && echo "$detail"
    else
        echo "FAIL  injection $n :$fail"
        overall=1
    fi

    # 5. The full matrix harness must also reject this build. The kernel
    #    policing itself is not enough; scripts/ must not be fooled.
    if [ "$n" = "5" ]; then
        if ./scripts/smp-matrix.sh 1 "$NCPUS" >/dev/null 2>&1; then
            echo "FAIL  injection 5 : smp-matrix.sh accepted a dishonest summary"
            overall=1
        else
            echo "PASS  injection 5 : smp-matrix.sh rejected the dishonest summary"
        fi
    fi
done

echo ""
if [ "$overall" -eq 0 ]; then
    echo "ALL NEGATIVE CONTROLS BEHAVED AS EXPECTED"
else
    echo "SOME NEGATIVE CONTROLS DID NOT BEHAVE AS EXPECTED"
fi
exit "$overall"
