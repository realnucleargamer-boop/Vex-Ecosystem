#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "vstore.h"
static int fails, total;
#define CHECK(c, m) do { total++; if (c) printf("PASS  %s\n", m); else { fails++; printf("FAIL  %s\n", m); } } while (0)
typedef struct { uint8_t d[16][512]; int writes; int fail_write_at; int fail_read_lba; int torn_at; } Disk;
static int rd(void *c, uint64_t l, void *b) { Disk *k = c; if ((int)l == k->fail_read_lba) return -2; memcpy(b, k->d[l], 512); return 0; }
static int wr(void *c, uint64_t l, const void *b) { Disk *k = c; k->writes++; if (k->fail_write_at && k->writes == k->fail_write_at) return -2;
    if (k->torn_at && k->writes == k->torn_at) { memcpy(k->d[l], b, 200); return 0; }       /* torn: only the first 200 bytes land */
    memcpy(k->d[l], b, 512); return 0; }
static Disk *mk(void) { Disk *d = calloc(1, sizeof *d); d->fail_read_lba = -1; return d; }
static VStoreIo io(Disk *k) { VStoreIo i = { k, rd, wr, 16 }; return i; }
int main(void)
{
    Disk *k = mk(); VStore s; VStoreIo i = io(k); uint32_t w = 99;
    CHECK(vstore_probe(&s, &i) == VS_BLANK, "all-zero disk is classified BLANK");
    CHECK(vstore_set_wallpaper(&s, 3) == 0 && k->writes == 0, "set on a BLANK (unformatted) store is refused and writes nothing");
    CHECK(vstore_get_wallpaper(&s, &w) == 0, "BLANK store has no saved settings");
    CHECK(vstore_format(&s) == 1 && s.state == VS_READY, "format of a BLANK disk succeeds -> READY");
    CHECK(vstore_get_wallpaper(&s, &w) == 1 && w == 0, "fresh store reports wallpaper 0 (default)");
    CHECK(vstore_set_wallpaper(&s, 4) == 1 && vstore_get_wallpaper(&s, &w) && w == 4, "save wallpaper 4");
    VStore s2; i = io(k); CHECK(vstore_probe(&s2, &i) == VS_READY && vstore_get_wallpaper(&s2, &w) && w == 4, "re-probe (simulated reboot) reads back 4");
    CHECK(vstore_set_wallpaper(&s2, 6) && vstore_set_wallpaper(&s2, 2), "two more saves (A/B alternate)");
    VStore s3; vstore_probe(&s3, &i); CHECK(vstore_get_wallpaper(&s3, &w) && w == 2, "newest of the two slots wins after reboot");
    /* torn write of the NEXT save must not lose the previous value */
    k->writes = 0; k->torn_at = 1; CHECK(vstore_set_wallpaper(&s3, 5) == 0, "torn write is detected by read-back verify (reports failure)");
    k->torn_at = 0; VStore s4; vstore_probe(&s4, &i); CHECK(vstore_get_wallpaper(&s4, &w) && w == 2, "after a torn write the previous value (2) survives");
    k->writes = 0; k->fail_write_at = 1; CHECK(vstore_set_wallpaper(&s4, 1) == 0, "write error is reported"); k->fail_write_at = 0;
    CHECK(vstore_get_wallpaper(&s4, &w) && w == 2, "failed save leaves in-memory state unchanged");
    /* corrupt the best slot -> fall back to the other */
    VStore s5; vstore_probe(&s5, &i); vstore_set_wallpaper(&s5, 7); int best = s5.best; k->d[1 + best][9] ^= 0x40;   /* now both slots hold valid data: 7 (newest) and 2 */
    VStore s6; vstore_probe(&s6, &i); CHECK(s6.state == VS_READY && s6.best != best && vstore_get_wallpaper(&s6, &w) && w == 2, "corrupt newest slot -> older valid slot (2) is used");
    k->d[1][9] ^= 0x40; k->d[2][9] ^= 0x40; k->d[1][1] ^= 1; k->d[2][1] ^= 1;
    VStore s7; vstore_probe(&s7, &i); CHECK(s7.state == VS_READY && !vstore_get_wallpaper(&s7, &w), "both slots corrupt -> READY with no settings (default), no crash");
    CHECK(vstore_set_wallpaper(&s7, 5) && vstore_get_wallpaper(&s7, &w) && w == 5, "store recovers by writing a fresh slot");
    /* foreign disks are never written */
    Disk *f = mk(); f->d[0][510] = 0x55; f->d[0][511] = 0xAA; i = io(f); VStore sf;
    CHECK(vstore_probe(&sf, &i) == VS_FOREIGN, "disk with an MBR/boot signature is FOREIGN");
    CHECK(vstore_format(&sf) == 0 && vstore_set_wallpaper(&sf, 1) == 0 && f->writes == 0, "FOREIGN disk: format and set refused, ZERO writes");
    Disk *g = mk(); g->d[2][100] = 7; i = io(g);
    CHECK(vstore_probe(&sf, &i) == VS_FOREIGN, "zero LBA0 but non-zero data in slot area is FOREIGN, not blank");
    Disk *h = mk(); memcpy(h->d[0], "VEXSTOR1", 8); i = io(h);
    CHECK(vstore_probe(&sf, &i) == VS_FOREIGN, "header with a bad CRC is not trusted (FOREIGN)");
    Disk *e = mk(); e->fail_read_lba = 0; i = io(e);
    CHECK(vstore_probe(&sf, &i) == VS_IOERR, "unreadable LBA0 -> IOERR");
    VStoreIo tiny = { k, rd, wr, 2 }; CHECK(vstore_probe(&sf, &tiny) == VS_NONE, "disk smaller than 3 sectors -> NONE");
    VStore sb; Disk *bl = mk(); i = io(bl); vstore_probe(&sb, &i); bl->fail_write_at = 2;
    CHECK(vstore_format(&sb) == 0, "failed format reports failure"); memset(bl->d[0], 0, 512);
    VStore sc; i = io(bl); bl->fail_write_at = 0; CHECK(vstore_probe(&sc, &i) != VS_READY, "interrupted format never leaves a READY store (header is written last)");
    /* sequence wraparound */
    VStore sw; Disk *wd = mk(); i = io(wd); vstore_probe(&sw, &i); vstore_format(&sw); sw.seq = 0xFFFFFFFEu;
    CHECK(vstore_set_wallpaper(&sw, 1) && vstore_set_wallpaper(&sw, 2) && vstore_set_wallpaper(&sw, 3), "saves across sequence-number wraparound");
    VStore sx; vstore_probe(&sx, &i); CHECK(vstore_get_wallpaper(&sx, &w) && w == 3, "wraparound: newest slot still wins after reboot");
    printf("\n%d/%d vstore host checks passed\n", total - fails, total); return fails != 0;
}
