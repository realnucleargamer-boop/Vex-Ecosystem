#include "runtime_ui.h"
#include "gfx/draw.h"
#include "gfx/text.h"
#include "input.h"
#include "ps2_keyboard.h"
static GfxFb *screen;
static void text(int x,int y,const char *s,GfxColor c){gfx_draw_str(screen,x,y,s,c,GFX_DARK_BG);}
void runtime_ui_init(GfxFb *fb,int g,int i,int u){screen=fb;if(!fb||!fb->ok)return;gfx_clear(fb,GFX_DARK_BG);gfx_fill_rect(fb,0,0,fb->width,34,GFX_HEADER_BG);text(18,10,"VEX OS RUNTIME UPGRADE",GFX_WHITE);text(18,58,"VEX BOOTLOADER",GFX_ACCENT);text(18,82,"[ OK ] UEFI     [ OK ] BOOT-03     [ OK ] KERNEL-01",GFX_GREEN);text(18,102,"[ OK ] SECURITY-01",GFX_GREEN);text(18,130,g?"[ OK ] GRAPHICS":"[FAIL] GRAPHICS",g?GFX_GREEN:GFX_RED);text(18,150,i?"[ OK ] INPUT / PS2 KEYBOARD":"[FAIL] INPUT",i?GFX_GREEN:GFX_RED);text(18,170,u?"[ OK ] USER-02 SERVICES":"[FAIL] USER-02",u?GFX_GREEN:GFX_RED);text(18,206,"SYSTEM READY - Press a key",GFX_WHITE);text(18,246,"Keyboard: READY (PS/2 polling)    Mouse: NOT IMPLEMENTED",GFX_YELLOW);text(18,286,"INPUT TEST",GFX_ACCENT);text(18,310,"Last key: waiting",GFX_TEXT);}
void runtime_ui_update(void){VexKeyEvent e; if(!screen||!screen->ok)return;while(input_poll_key(&e)){gfx_fill_rect(screen,18,310,520,18,GFX_DARK_BG);char b[32];const char *p="Last key code: ";int n=0;while(p[n]){b[n]=p[n];n++;} uint64_t v=(uint64_t)e.key;char d[8];int q=0;do{d[q++]=(char)('0'+v%10);v/=10;}while(v);while(q)b[n++]=d[--q];p=e.action==VEX_KEY_PRESS?" PRESS":" RELEASE";for(int j=0;p[j];j++)b[n++]=p[j];b[n]=0;text(18,310,b,GFX_TEXT);} }
