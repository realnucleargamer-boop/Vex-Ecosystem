# Hosted runtime (`src/runtime/vex_rt.c`)
- vex_rt_print_i64 / println_i64
- vex_rt_print_cstr / println_cstr
- vex_rt_print_str / println_str (ptr+len)
Not the Vex OS kernel.
