/* Vex OS - kernel/src/drivers/storage/vstore.c : STORAGE-01 settings store. See include/vstore.h. */
#include "vstore.h"

static const char MAGIC[8] = { 'V', 'E', 'X', 'S', 'T', 'O', 'R', '1' };
#define REC_MAGIC 0x54455356u              /* "VSET" little-endian */
#define CRC_OFF 508
static uint32_t crc32(const uint8_t *p, uint32_t n)
{
    static const uint32_t T[16] = { 0, 0x1DB71064, 0x3B6E20C8, 0x26D930AC, 0x76DC4190, 0x6B6B51F4, 0x4DB26158, 0x5005713C, 0xEDB88320, 0xF00F9344, 0xD6D6A3E8, 0xCB61B38C, 0x9B64C2B0, 0x86D3D2D4, 0xA00AE278, 0xBDBDF21C };
    uint32_t c = 0xFFFFFFFFu; while (n--) { c ^= *p++; c = (c >> 4) ^ T[c & 15]; c = (c >> 4) ^ T[c & 15]; } return ~c;
}
static void put32(uint8_t *b, int o, uint32_t v) { b[o] = (uint8_t)v; b[o + 1] = (uint8_t)(v >> 8); b[o + 2] = (uint8_t)(v >> 16); b[o + 3] = (uint8_t)(v >> 24); }
static uint32_t get32(const uint8_t *b, int o) { return (uint32_t)b[o] | ((uint32_t)b[o + 1] << 8) | ((uint32_t)b[o + 2] << 16) | ((uint32_t)b[o + 3] << 24); }
static int all_zero(const uint8_t *b) { for (int i = 0; i < 512; i++) if (b[i]) return 0; return 1; }
static int header_ok(const uint8_t *b, uint64_t sectors)
{
    for (int i = 0; i < 8; i++) if (b[i] != (uint8_t)MAGIC[i]) return 0;
    if (get32(b, 8) != 1u || crc32(b, CRC_OFF) != get32(b, CRC_OFF)) return 0;
    uint64_t n = (uint64_t)get32(b, 12) | ((uint64_t)get32(b, 16) << 32); return n <= sectors && n >= 3;
}
static void make_rec(uint8_t *b, uint32_t seq, uint32_t wp) { for (int i = 0; i < 512; i++) b[i] = 0; put32(b, 0, REC_MAGIC); put32(b, 4, seq); put32(b, 8, wp); put32(b, CRC_OFF, crc32(b, CRC_OFF)); }
static int rec_ok(const uint8_t *b) { return get32(b, 0) == REC_MAGIC && crc32(b, CRC_OFF) == get32(b, CRC_OFF); }
static int newer(uint32_t a, uint32_t b) { return (int32_t)(a - b) > 0; }          /* wrap-safe */
static const char *const NM[] = { "no data disk", "blank (not formatted)", "ready", "not a Vex data disk (left untouched)", "I/O error" };
const char *vstore_state_text(VStoreState st) { return (unsigned)st < 5 ? NM[st] : "?"; }

static void load_slots(VStore *s)
{
    uint8_t b[512]; s->have_settings = 0; s->best = -1; s->seq = 0; s->wallpaper = 0;
    for (int k = 0; k < 2; k++) {
        if (s->io.read(s->io.ctx, 1u + (uint64_t)k, b) != 0 || !rec_ok(b)) continue;
        uint32_t q = get32(b, 4);
        if (!s->have_settings || newer(q, s->seq)) { s->have_settings = 1; s->seq = q; s->best = k; s->wallpaper = get32(b, 8); }
    }
}
VStoreState vstore_probe(VStore *s, const VStoreIo *io)
{
    uint8_t b[512]; s->io = *io; s->have_settings = 0; s->best = -1; s->seq = 0; s->wallpaper = 0;
    if (!io->read || !io->write || io->sectors < 3) { s->state = VS_NONE; return s->state; }
    if (io->read(io->ctx, 0, b) != 0) { s->state = VS_IOERR; return s->state; }
    if (header_ok(b, io->sectors)) { s->state = VS_READY; load_slots(s); return s->state; }
    if (all_zero(b)) {                                            /* blank only if the slot area is blank too */
        for (int k = 1; k <= 2; k++) {
            if (io->read(io->ctx, (uint64_t)k, b) != 0) { s->state = VS_IOERR; return s->state; }
            if (!all_zero(b)) { s->state = VS_FOREIGN; return s->state; }
        }
        s->state = VS_BLANK; return s->state;
    }
    s->state = VS_FOREIGN; return s->state;
}
int vstore_format(VStore *s)
{
    uint8_t b[512];
    if (s->state != VS_BLANK) return 0;                           /* hard refusal: never format anything but a verified-blank disk */
    make_rec(b, 1, 0);
    if (s->io.write(s->io.ctx, 1, b)) return 0;
    for (int i = 0; i < 512; i++) b[i] = 0;
    if (s->io.write(s->io.ctx, 2, b)) return 0;
    for (int i = 0; i < 512; i++) b[i] = 0;
    for (int i = 0; i < 8; i++) b[i] = (uint8_t)MAGIC[i];
    put32(b, 8, 1u); put32(b, 12, (uint32_t)s->io.sectors); put32(b, 16, (uint32_t)(s->io.sectors >> 32)); put32(b, CRC_OFF, crc32(b, CRC_OFF));
    if (s->io.write(s->io.ctx, 0, b)) return 0;                   /* header last = commit point */
    VStoreIo io = s->io; return vstore_probe(s, &io) == VS_READY;
}
int vstore_get_wallpaper(const VStore *s, uint32_t *idx) { if (s->state != VS_READY || !s->have_settings) return 0; *idx = s->wallpaper; return 1; }
int vstore_set_wallpaper(VStore *s, uint32_t idx)
{
    uint8_t b[512], v[512];
    if (s->state != VS_READY) return 0;
    int slot = s->best == 0 ? 1 : 0; uint32_t seq = s->have_settings ? s->seq + 1u : 1u;
    make_rec(b, seq, idx);
    if (s->io.write(s->io.ctx, 1u + (uint64_t)slot, b)) return 0;
    if (s->io.read(s->io.ctx, 1u + (uint64_t)slot, v) || !rec_ok(v) || get32(v, 4) != seq || get32(v, 8) != idx) return 0;   /* verify by read-back */
    s->have_settings = 1; s->seq = seq; s->best = slot; s->wallpaper = idx; return 1;
}
