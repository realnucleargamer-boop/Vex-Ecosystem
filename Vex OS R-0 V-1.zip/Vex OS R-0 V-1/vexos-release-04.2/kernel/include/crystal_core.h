/*
 * crystal_core.h - VEX AI 1.5-Crystal native inference core (CRYSTAL-NATIVE-01).
 *
 * INDEPENDENCE RULE: this core includes only <stdint.h>/<stddef.h>, calls NO kernel API, uses no libc, no heap,
 * no globals, no floating point and no recursion. All memory it touches is passed in by the caller. That is what lets
 * it be moved behind a Ring 3 service boundary later without change. While it runs inside the kernel it is NOT
 * isolated (see docs/CRYSTAL-NATIVE-01.md s5.3).
 *
 * WHAT IT IMPLEMENTS (and only this): prompt-injection pre-filter, input normalisation, signed feature hashing,
 * the 2048->256->64 ReLU network, softmax top-1 probability, the calibrated reject gate with the math/memory vetoes,
 * and the two-operand arithmetic specialist. It does NOT implement the regex rule/evidence layer, code templates,
 * wiki retrieval, memory or history (see s7 of the doc). Those inputs get an explicit "not implemented" reply.
 *
 * Numerics: integer fixed point. Not bit-identical to the numpy float32 engine; the measured difference is in the doc.
 */
#ifndef VEX_CRYSTAL_CORE_H
#define VEX_CRYSTAL_CORE_H

#include <stdint.h>
#include <stddef.h>

#define VXC_MAX_INPUT    256   /* bytes of user text accepted per call */
#define VXC_MAX_FEAT     2048  /* largest feat_dim the scratch supports */
#define VXC_MAX_HIDDEN   256
#define VXC_MAX_INTENTS  64
#define VXC_MAX_NUM_OPERAND 1000000000LL   /* whole-number operands up to +/-1e9 are supported */

/* status codes (negative = nothing was written to `out`, except VXC_E_MODEL which also writes nothing) */
#define VXC_OK            0
#define VXC_E_ARG        (-1)  /* NULL pointer, cap == 0, or text==NULL with len != 0 */
#define VXC_E_TOO_LONG   (-2)  /* len > VXC_MAX_INPUT */
#define VXC_E_CHARSET    (-3)  /* a byte outside printable ASCII 0x20..0x7E */
#define VXC_E_MODEL      (-4)  /* model blob invalid / unsupported (see vxc_model_open) */

/* VxcResult.source */
#define VXC_SRC_NONE      0    /* no classification happened (empty input, injection filter, ...) */
#define VXC_SRC_NEURAL    1    /* the trained network decided (prob >= gate and vetoes passed) */
#define VXC_SRC_REJECTED  2    /* network was below the gate / vetoed. The Python engine would now try rules/evidence
                                  (NOT ported) and else answer "clarification" (intent 49); this core reports 49. */

/* VxcResult.handler: what produced the text in `out` */
#define VXC_H_BOUNDARY    0    /* fixed boundary message (empty input, injection, need-two-numbers, rejected) */
#define VXC_H_MATH        1    /* arithmetic specialist produced a result */
#define VXC_H_NOT_IMPL    2    /* intent recognised, but its handler is not part of the native port */
#define VXC_H_UNSUPPORTED 3    /* math request outside the native subset (decimal / > 1e9 operand) */

typedef struct VxcModel {
    const uint8_t *blob; size_t len;
    uint32_t feat, hidden, nint, reject_q;       /* reject_q: probability gate in Q30 */
    const uint8_t *w1, *b1, *wi, *bi, *labels;   /* pointers into blob (little-endian int32 / records) */
    uint8_t is_math[VXC_MAX_INTENTS];            /* family == "math"             */
    uint8_t is_mem[VXC_MAX_INTENTS];             /* family == "memory_operations" */
} VxcModel;

typedef struct VxcScratch {
    char     lc[VXC_MAX_INPUT + 1];
    int64_t  acc[VXC_MAX_FEAT];          /* feature vector, Q30            */
    int64_t  hid[VXC_MAX_HIDDEN];        /* pre-activation Q50, then hidden Q30 */
    int64_t  logit[VXC_MAX_INTENTS];     /* Q40 */
    uint16_t tok_off[VXC_MAX_INPUT];
    uint16_t tok_len[VXC_MAX_INPUT];
    uint8_t  tok_num[VXC_MAX_INPUT];
} VxcScratch;

typedef struct VxcResult {
    int32_t intent;         /* final intent id 0..63 (49 when rejected)          */
    int32_t neural_top;     /* network's own argmax (valid when stage reached)   */
    int32_t confidence;     /* milli-confidence, like Python: int(prob*1000) or 100 when rejected */
    int32_t prob_q30;       /* softmax top-1 probability, Q30 (0 if not computed) */
    int32_t source;         /* VXC_SRC_*   */
    int32_t handler;        /* VXC_H_*     */
    int32_t truncated;      /* 1 if `out` was too small and the text was cut      */
    int32_t n_numbers;      /* numeric operands found in the text                 */
} VxcResult;

/* Validate a VXCR v1 blob and fill *m. Checks magic, version, frac_bits==30, header size, dimensions against the
 * compiled limits, exact total length (overflow-safe 64-bit arithmetic), label table, and - if verify_crc - the
 * trailing CRC-32 over the whole blob. Returns VXC_OK or VXC_E_MODEL. Never reads outside [blob, blob+len). */
int vxc_model_open(VxcModel *m, const uint8_t *blob, size_t len, int verify_crc);

/* One inference. `text` need not be NUL-terminated. Writes a NUL-terminated reply of at most cap-1 bytes to `out`.
 * Returns VXC_OK (result filled) or a negative VXC_E_* (nothing written to out). Re-entrancy: `s` must not be shared
 * between concurrent calls. */
int vxc_infer(const VxcModel *m, VxcScratch *s, const char *text, size_t len,
              VxcResult *r, char *out, size_t cap);

/* intent label / family strings from the model's table (never NULL for 0 <= id < nint; "" otherwise). */
const char *vxc_intent_label(const VxcModel *m, int id);
const char *vxc_intent_family(const VxcModel *m, int id);

/* The arithmetic specialist alone (what infer() runs after classifying an input as math): parse two operands and an
 * operator from `text`, compute, format. `text` is lower-cased internally into s->lc. *handler receives VXC_H_MATH,
 * VXC_H_BOUNDARY (need two numbers/operation) or VXC_H_UNSUPPORTED (decimal or |operand| > 1e9). Returns VXC_OK,
 * 1 if the reply was truncated to fit `out`, or a negative VXC_E_*. */
int vxc_arith(VxcScratch *s, const char *text, size_t len, char *out, size_t cap, int *handler);

/* zlib-compatible CRC-32 (exposed for tests). */
uint32_t vxc_crc32(const uint8_t *p, size_t n);

#endif
