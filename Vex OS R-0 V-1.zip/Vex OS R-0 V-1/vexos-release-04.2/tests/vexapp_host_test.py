#!/usr/bin/env python3
"""Compiles apps/vex_terminal with the REAL vendored VexScript toolchain, builds the generated x86-64
assembly against a C mock of the OS services (apps/vex_terminal/tests/host_mock.c) with the shared
freestanding string runtime, and runs it.  Proves the command logic that lives in VexScript behaves
correctly natively.  It does not prove kernel integration (see scripts/desktop_e2e.py)."""
import os, subprocess, sys, tempfile
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
env = dict(os.environ, PYTHONPATH=os.path.join(root, "tools/vexscript/src"))
d = tempfile.mkdtemp()
s = os.path.join(d, "vt.s")
r = subprocess.run([sys.executable, "-m", "vexscript.cli", "emit-asm", os.path.join(root, "apps/vex_terminal")], env=env, capture_output=True, text=True)
if r.returncode: print(r.stderr); sys.exit(1)
open(s, "w").write(r.stdout)
exe = os.path.join(d, "t")
o = os.path.join(d, "vt.o")
subprocess.run(["gcc", "-c", s, "-o", o], check=True, capture_output=True)
subprocess.run(["objcopy", "--redefine-sym", "main=vexapp_main", o], check=True)   # the app's mandatory fn main
c = subprocess.run(["gcc", "-no-pie", "-o", exe, o, os.path.join(root, "apps/vex_terminal/tests/host_mock.c"),
                    os.path.join(root, "tools/vexscript/src/runtime/vex_rt_str.c")], capture_output=True, text=True)
if c.returncode: print(c.stderr); sys.exit(1)
p = subprocess.run([exe]); sys.exit(p.returncode)
