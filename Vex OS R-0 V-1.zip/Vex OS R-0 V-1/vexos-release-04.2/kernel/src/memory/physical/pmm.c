/*
 * Vex OS - kernel/src/memory/physical/pmm.c
 *
 * BOOT-03 bitmap physical page allocator. See kernel/include/pmm.h for
 * the design rationale and the interrupt-handler invariant.
 */

#include "pmm.h"
#include "efi_memmap.h"
#include "serial.h"
#include "boot03_inject.h"
#include "panic.h"
#include "boot_layout.h"

/* ------------------------------------------------------------------ *
 * State
 * ------------------------------------------------------------------ */

static uint64_t *g_reserved;      /* 1 = never allocatable */
static uint64_t *g_alloc;         /* 1 = currently allocated */
static uint64_t  g_total_frames;
static uint64_t  g_bitmap_words;
static uint64_t  g_highest_addr;

static uint64_t  g_reserved_count;
static uint64_t  g_allocated_count;

/* Rotating search hint. Purely an optimisation: allocation is still
 * correct if this is stale, because the scan wraps and re-checks. */
static uint64_t  g_next_hint;

static volatile int g_lock;
static int g_initialized;

/* Per-reason frame counts, for the boot summary. */
static uint64_t g_reason_frames[PMM_RSV_COUNT];

/* ------------------------------------------------------------------ *
 * Locking
 *
 * Test-and-set spinlock that also saves/clears the interrupt flag. The
 * BSP runs with interrupts enabled from BOOT-03 onward, so without the
 * cli a timer interrupt landing between the test-and-set and the
 * critical section would be harmless, but a handler that itself called
 * into the PMM would deadlock. Clearing IF removes the interesting half
 * of that problem; the other half (handlers must not allocate) is an
 * invariant stated in pmm.h and honoured by the BOOT-03 timer handler.
 * ------------------------------------------------------------------ */

static inline uint64_t irq_save_disable(void)
{
    uint64_t flags;
    __asm__ volatile ("pushfq; pop %0; cli" : "=r"(flags) : : "memory");
    return flags;
}

static inline void irq_restore(uint64_t flags)
{
    /* Only re-enable if it was enabled before. Blindly executing sti
     * here would silently enable interrupts on a path that had them
     * deliberately disabled - including on an AP, which must never run
     * with interrupts on (no TSS, therefore no IST; see BOOT-02C). */
    if (flags & (1ULL << 9)) {
        __asm__ volatile ("sti" : : : "memory");
    }
}

static uint64_t pmm_lock(void)
{
    uint64_t flags = irq_save_disable();
    while (__atomic_test_and_set(&g_lock, __ATOMIC_ACQUIRE)) {
        __asm__ volatile ("pause");
    }
    return flags;
}

static void pmm_unlock(uint64_t flags)
{
    __atomic_clear(&g_lock, __ATOMIC_RELEASE);
    irq_restore(flags);
}

/* ------------------------------------------------------------------ *
 * Bitmap primitives (callers hold the lock)
 * ------------------------------------------------------------------ */

static inline int bit_get(const uint64_t *bm, uint64_t i)
{
    return (bm[i >> 6] >> (i & 63)) & 1ULL;
}

static inline void bit_set(uint64_t *bm, uint64_t i)
{
    bm[i >> 6] |= (1ULL << (i & 63));
}

static inline void bit_clear(uint64_t *bm, uint64_t i)
{
    bm[i >> 6] &= ~(1ULL << (i & 63));
}

/* ------------------------------------------------------------------ *
 * Init helpers
 * ------------------------------------------------------------------ */

static void k_bzero(void *dst, uint64_t n)
{
    uint8_t *d = (uint8_t *)dst;
    for (uint64_t i = 0; i < n; i++) d[i] = 0;
}

static void k_fill_ones(void *dst, uint64_t n)
{
    uint8_t *d = (uint8_t *)dst;
    for (uint64_t i = 0; i < n; i++) d[i] = 0xFF;
}

static inline uint64_t align_down(uint64_t v, uint64_t a) { return v & ~(a - 1); }
static inline uint64_t align_up(uint64_t v, uint64_t a)   { return (v + a - 1) & ~(a - 1); }

const char *pmm_reserve_reason_name(PmmReserveReason why)
{
    switch (why) {
    case PMM_RSV_FIRMWARE:     return "firmware/non-conventional";
    case PMM_RSV_LOW_1MIB:     return "below 1 MiB (legacy)";
    case PMM_RSV_KERNEL_IMAGE: return "kernel image";
    case PMM_RSV_BOOTINFO:     return "BootInfo + EFI memory map";
    case PMM_RSV_FRAMEBUFFER:  return "framebuffer";
    case PMM_RSV_ACPI:         return "ACPI tables";
    case PMM_RSV_BITMAP:       return "PMM bitmaps";
    case PMM_RSV_TRAMPOLINE:   return "AP trampoline";
    case PMM_RSV_PAGE_TABLE:   return "page tables";
    case PMM_RSV_KERNEL_STACK: return "kernel stacks";
    default:                   return "unknown";
    }
}

const char *pmm_result_name(PmmResult r)
{
    switch (r) {
    case PMM_OK:                return "OK";
    case PMM_ERR_NOT_ALIGNED:   return "not page aligned";
    case PMM_ERR_OUT_OF_RANGE:  return "outside managed range";
    case PMM_ERR_NOT_ALLOCATED: return "not allocated (double free?)";
    case PMM_ERR_RESERVED:      return "permanently reserved";
    case PMM_ERR_NO_MEMORY:     return "out of memory";
    case PMM_ERR_BAD_REQUEST:   return "bad request";
    default:                    return "unknown";
    }
}

/* Marks frames reserved without taking the lock - init only. */
static void reserve_frames_locked(uint64_t base, uint64_t len,
                                  PmmReserveReason why)
{
    if (len == 0) return;

    uint64_t first = align_down(base, PMM_PAGE_SIZE) / PMM_PAGE_SIZE;
    uint64_t last  = align_up(base + len, PMM_PAGE_SIZE) / PMM_PAGE_SIZE;

    if (first >= g_total_frames) return;
    if (last > g_total_frames) last = g_total_frames;

    for (uint64_t f = first; f < last; f++) {
        if (!bit_get(g_reserved, f)) {
            bit_set(g_reserved, f);
            g_reserved_count++;
            g_reason_frames[why]++;
        }
        /* A reserved frame must never look allocatable. If it was
         * allocated before being reserved that is a bug in init
         * ordering, but leaving the alloc bit set keeps the invariant
         * "never handed out" true regardless. */
    }
}

void pmm_reserve_range(uint64_t base, uint64_t len, PmmReserveReason why)
{
    if (!g_initialized) {
        /* Called before init - nothing to record into yet. This would
         * be a boot-ordering bug, so say so rather than ignore it. */
        serial_puts("[kernel] PMM: WARNING - pmm_reserve_range() before pmm_init()\n");
        return;
    }
    uint64_t flags = pmm_lock();
    reserve_frames_locked(base, len, why);
    pmm_unlock(flags);
}

/* Provided by kernel/linker.ld. `__kernel_end` is one past the last
 * byte the kernel occupies at RUN TIME, which - unlike
 * BootInfo.kernel_physical_size - includes .bss and therefore the boot
 * stack. Declared as arrays so that taking the address does not read
 * through them. */
extern uint8_t __kernel_start[];
extern uint8_t __kernel_end[];

/* The kernel's true footprint, defended against a bootloader that
 * under-reports it. The BootInfo range is honoured too, in case a future
 * bootloader loads the kernel somewhere other than where it is linked;
 * if the two ever disagree, both get reserved. */
static uint64_t kernel_runtime_end(BootInfo *info)
{
    uint64_t linked_end = (uint64_t)(uintptr_t)__kernel_end;
    uint64_t loaded_end = info->kernel_physical_base + info->kernel_physical_size;
    return linked_end > loaded_end ? linked_end : loaded_end;
}

void pmm_init(BootInfo *info)
{
    if (info->memory_map == 0 || info->memory_map_desc_size == 0) {
        panic("PMM: BootInfo has no usable memory map", 0, 0);
    }

    uint8_t *map = (uint8_t *)(uintptr_t)info->memory_map;
    uint64_t desc_size = info->memory_map_desc_size;
    uint64_t count = info->memory_map_size / desc_size;

    /* --- Pass 1: how much address space must the bitmaps cover, and
     * where can they physically live? ---
     *
     * Sizing rule, and it matters a lot:
     *
     * The obvious rule - "cover the top of the highest descriptor" -
     * is wrong, expensively wrong. Firmware routinely describes huge
     * non-RAM regions very high in the address space. Measured on this
     * exact setup (QEMU q35 + OVMF, 512 MB of guest RAM), the memory
     * map contains an EfiReservedMemoryType descriptor spanning
     * 0xFD00000000..0x10000000000. Sizing to the highest descriptor
     * therefore produced bitmaps covering 1 TiB: 268435456 frames,
     * 32 MiB per bitmap, 64 MiB for the pair - roughly 16% of the
     * 398 MiB of usable RAM, spent to track a reserved hole that can
     * never be allocated. On real hardware, where MMIO apertures sit
     * even higher, that overhead grows without bound.
     *
     * So the bitmaps cover only frames the allocator could ever own or
     * must explicitly account for:
     *
     *   - every RAM-like descriptor (see efi_mem_type_is_ram),
     *   - the framebuffer, which is explicitly reserved so that the
     *     reservation accounting stays truthful,
     *   - the ACPI RSDP page, for the same reason.
     *
     * Everything above that top is simply outside the managed range,
     * and the out-of-range behaviour is already the safe one:
     * pmm_is_reserved() answers 1, pmm_is_allocated() answers 0, and
     * pmm_free_page() answers PMM_ERR_OUT_OF_RANGE. Unmanaged memory is
     * unallocatable memory, which is exactly the intended semantics -
     * this is a smaller bitmap, not a weaker guarantee. */
    uint64_t highest_desc = 0;   /* top of every descriptor, for reporting */
    uint64_t tracked = 0;        /* top of what the bitmaps actually cover */
    uint64_t conv_regions = 0;
    uint64_t conv_frames = 0;

    for (uint64_t i = 0; i < count; i++) {
        EfiMemoryDescriptor *d = (EfiMemoryDescriptor *)(map + i * desc_size);
        uint64_t end = d->PhysicalStart + d->NumberOfPages * PMM_PAGE_SIZE;
        if (end > highest_desc) highest_desc = end;
        if (efi_mem_type_is_ram(d->Type) && end > tracked) tracked = end;
        if (d->Type == EFI_MEM_TYPE_CONVENTIONAL) {
            conv_regions++;
            conv_frames += d->NumberOfPages;
        }
    }

    /* Extend over the regions that are reserved by name rather than by
     * descriptor type, so their frames land in the accounting. */
    if (info->framebuffer_addr != 0 && info->framebuffer_size != 0) {
        uint64_t fb_end = info->framebuffer_addr + info->framebuffer_size;
        if (fb_end > tracked) tracked = fb_end;
    }
    if (info->rsdp_address != 0) {
        uint64_t rsdp_end = info->rsdp_address + PMM_PAGE_SIZE;
        if (rsdp_end > tracked) tracked = rsdp_end;
    }

    if (tracked == 0) {
        panic("PMM: memory map describes no RAM", 0, 0);
    }

    uint64_t highest = tracked;

    g_highest_addr = align_up(highest, PMM_PAGE_SIZE);
    g_total_frames = g_highest_addr / PMM_PAGE_SIZE;
    g_bitmap_words = (g_total_frames + 63) / 64;

    uint64_t bitmap_bytes = g_bitmap_words * 8;
    uint64_t need_bytes = bitmap_bytes * 2;          /* reserved[] + alloc[] */
    uint64_t need_pages = align_up(need_bytes, PMM_PAGE_SIZE) / PMM_PAGE_SIZE;

    /* --- Pass 2: place the bitmaps.
     *
     * Bootstrap problem: the allocator cannot allocate its own bitmaps.
     * So pick a conventional region big enough by hand, at or above
     * 1 MiB, and reserve those frames immediately afterwards. Choosing
     * the LOWEST suitable region keeps the bitmaps out of the way of
     * large contiguous allocations later. */
    uint64_t bm_phys = 0;
    for (uint64_t i = 0; i < count; i++) {
        EfiMemoryDescriptor *d = (EfiMemoryDescriptor *)(map + i * desc_size);
        if (d->Type != EFI_MEM_TYPE_CONVENTIONAL) continue;
        if (d->NumberOfPages < need_pages) continue;

        uint64_t start = d->PhysicalStart;
        if (start < 0x100000ULL) {
            /* Skip the sub-1 MiB part rather than the whole region. */
            uint64_t skip = (0x100000ULL - start) / PMM_PAGE_SIZE;
            if (d->NumberOfPages - skip < need_pages) continue;
            start = 0x100000ULL;
        }
        /* Do not place the bitmaps on top of the kernel.
         *
         * This uses the RUN-TIME end, not the loaded image size. Using
         * the loaded size placed the bitmaps at __bss_start exactly - on
         * top of the live boot stack - which killed the machine the
         * moment the bitmaps were cleared. */
        uint64_t kend = kernel_runtime_end(info);
        if (start < kend && (start + need_bytes) > info->kernel_physical_base) {
            start = align_up(kend, PMM_PAGE_SIZE);
            uint64_t region_end = d->PhysicalStart + d->NumberOfPages * PMM_PAGE_SIZE;
            if (start + need_bytes > region_end) continue;
        }

        bm_phys = start;
        break;
    }

    if (bm_phys == 0) {
        panic("PMM: no conventional region large enough for the frame bitmaps",
              need_bytes, 0);
    }

    g_reserved = (uint64_t *)(uintptr_t)bm_phys;
    g_alloc    = (uint64_t *)(uintptr_t)(bm_phys + bitmap_bytes);

    /* Default-deny: everything reserved, nothing allocated. */
    k_fill_ones(g_reserved, bitmap_bytes);
    k_bzero(g_alloc, bitmap_bytes);
    g_reserved_count = g_total_frames;
    g_allocated_count = 0;
    for (int i = 0; i < PMM_RSV_COUNT; i++) g_reason_frames[i] = 0;
    g_reason_frames[PMM_RSV_FIRMWARE] = g_total_frames;
    g_next_hint = 0;
    g_initialized = 1;

    /* --- Pass 3: release conventional memory. --- */
    for (uint64_t i = 0; i < count; i++) {
        EfiMemoryDescriptor *d = (EfiMemoryDescriptor *)(map + i * desc_size);
        if (d->Type != EFI_MEM_TYPE_CONVENTIONAL) continue;

        uint64_t first = d->PhysicalStart / PMM_PAGE_SIZE;
        uint64_t last = first + d->NumberOfPages;
        if (last > g_total_frames) last = g_total_frames;

        for (uint64_t f = first; f < last; f++) {
            if (bit_get(g_reserved, f)) {
                bit_clear(g_reserved, f);
                g_reserved_count--;
                if (g_reason_frames[PMM_RSV_FIRMWARE] > 0) {
                    g_reason_frames[PMM_RSV_FIRMWARE]--;
                }
            }
        }
    }

    /* --- Pass 4: re-reserve what the kernel must keep. ---
     *
     * Everything here is memory the kernel is actively using or that
     * hardware owns. Handing any of it out would corrupt a running
     * system, so the reservations happen before the first allocation
     * can occur, not lazily. */

    /* Below 1 MiB: real-mode IVT, BDA, EBDA, legacy device windows, and
     * the page the BOOT-02C AP trampoline gets copied into. The
     * trampoline page is found separately by smp.c walking the memory
     * map, and is reserved explicitly by the caller once known. */
    reserve_frames_locked(0, 0x100000ULL, PMM_RSV_LOW_1MIB);

    /* The kernel image itself - and, critically, everything else the
     * kernel occupies at run time.
     *
     * Reserved from the LINKED extent (__kernel_start..__kernel_end) as
     * well as the loaded extent, because the loaded extent excludes .bss
     * and the boot stack lives in .bss. Reserving only the loaded extent
     * leaves the running kernel's own stack allocatable. */
    {
        uint64_t kstart = (uint64_t)(uintptr_t)__kernel_start;
        uint64_t kend   = kernel_runtime_end(info);
        if (kend > kstart) {
            reserve_frames_locked(kstart, kend - kstart, PMM_RSV_KERNEL_IMAGE);
        }
        /* Also honour whatever the bootloader actually reserved at the
         * load address, so the two never disagree in the unsafe
         * direction. */
        if (kend < VEX_KERNEL_LOAD_PHYS + VEX_KERNEL_RESERVE_BYTES) {
            reserve_frames_locked(VEX_KERNEL_LOAD_PHYS,
                                  VEX_KERNEL_RESERVE_BYTES,
                                  PMM_RSV_KERNEL_IMAGE);
        } else {
            /* The kernel has outgrown the region the bootloader reserves
             * for it. That means .bss is partly sitting in memory the
             * firmware still considers free - refuse to continue rather
             * than corrupt it later. */
            panic("PMM: kernel runtime footprint exceeds "
                  "VEX_KERNEL_RESERVE_BYTES - raise it in boot_layout.h",
                  kend, VEX_KERNEL_LOAD_PHYS + VEX_KERNEL_RESERVE_BYTES);
        }
    }

    if (info->kernel_physical_size > 0) {
        reserve_frames_locked(info->kernel_physical_base,
                              info->kernel_physical_size,
                              PMM_RSV_KERNEL_IMAGE);
    } else {
        /* Should not happen, but never leave the image unprotected on
         * the strength of a zero field. */
        serial_puts("[kernel] PMM: WARNING - BootInfo kernel_physical_size is 0,"
                    " reserving a conservative 4 MiB at the load address\n");
        reserve_frames_locked(VEX_KERNEL_LOAD_PHYS, 4ULL * 1024 * 1024,
                              PMM_RSV_KERNEL_IMAGE);
    }

    /* BootInfo and the EFI memory map array. These usually live in
     * EfiLoaderData and so are already reserved by default-deny, but
     * reserving them explicitly means the protection does not depend on
     * which type the firmware happened to use. */
    reserve_frames_locked((uint64_t)(uintptr_t)info, sizeof(BootInfo),
                          PMM_RSV_BOOTINFO);
    reserve_frames_locked(info->memory_map, info->memory_map_size,
                          PMM_RSV_BOOTINFO);

    /* Framebuffer. */
    if (info->framebuffer_addr != 0 && info->framebuffer_size != 0) {
        reserve_frames_locked(info->framebuffer_addr, info->framebuffer_size,
                              PMM_RSV_FRAMEBUFFER);
    }

    /* ACPI: the RSDP page. Reserving the whole table tree needs the
     * tables parsed, which has not happened yet at this point in boot;
     * acpi_init() calls pmm_reserve_range() for the tables it walks.
     * In practice firmware reports ACPI memory as AcpiReclaim/AcpiNvs,
     * which default-deny already covers. */
    if (info->rsdp_address != 0) {
        reserve_frames_locked(info->rsdp_address, PMM_PAGE_SIZE, PMM_RSV_ACPI);
    }

    /* The bitmaps themselves. */
    reserve_frames_locked(bm_phys, need_bytes, PMM_RSV_BITMAP);

    /* --- Summary --- */
    uint64_t usable = g_total_frames - g_reserved_count;

    serial_puts("[kernel] PMM: bitmap allocator over ");
    serial_put_dec64(g_total_frames);
    serial_puts(" frames (");
    serial_put_dec64((g_total_frames * PMM_PAGE_SIZE) / (1024 * 1024));
    serial_puts(" MiB address range), bitmaps @ ");
    serial_put_hex64(bm_phys);
    serial_puts(" (");
    serial_put_dec64(need_bytes / 1024);
    serial_puts(" KiB)\n");

    /* Made visible on purpose: if these two numbers ever converge, the
     * bitmaps have started tracking a high non-RAM aperture again. */
    serial_puts("[kernel] PMM: managed range tops out at ");
    serial_put_hex64(g_highest_addr);
    serial_puts("; highest descriptor of any type ends at ");
    serial_put_hex64(highest_desc);
    serial_puts(" (excess deliberately untracked)\n");

    serial_puts("[kernel] PMM: ");
    serial_put_dec64(usable);
    serial_puts(" frames usable (");
    serial_put_dec64((usable * PMM_PAGE_SIZE) / (1024 * 1024));
    serial_puts(" MiB) from ");
    serial_put_dec64(conv_regions);
    serial_puts(" conventional region(s) totalling ");
    serial_put_dec64(conv_frames);
    serial_puts(" frames\n");

    serial_puts("[kernel] PMM: reserved ");
    serial_put_dec64(g_reserved_count);
    serial_puts(" frames -");
    for (int i = 0; i < PMM_RSV_COUNT; i++) {
        if (g_reason_frames[i] == 0) continue;
        serial_puts(" ");
        serial_puts(pmm_reserve_reason_name((PmmReserveReason)i));
        serial_puts("=");
        serial_put_dec64(g_reason_frames[i]);
    }
    serial_puts("\n");
}

/* ------------------------------------------------------------------ *
 * Allocation
 * ------------------------------------------------------------------ */

/* Finds `n` contiguous frames that are neither reserved nor allocated,
 * with every frame strictly below `limit`. Caller holds the lock.
 * Returns 0 if none. */
static uint64_t find_run_locked(uint64_t n, uint64_t limit)
{
    if (n == 0) return 0;

    uint64_t limit_frame = g_total_frames;
    if (limit != 0) {
        uint64_t lf = limit / PMM_PAGE_SIZE;
        if (lf < limit_frame) limit_frame = lf;
    }
    if (n > limit_frame) return 0;

    /* Two sweeps so the hint can start mid-range without missing
     * anything: [hint, limit) then [0, hint). */
    uint64_t starts[2];
    uint64_t ends[2];
    uint64_t hint = g_next_hint < limit_frame ? g_next_hint : 0;
    starts[0] = hint;      ends[0] = limit_frame;
    starts[1] = 0;         ends[1] = hint;

    for (int pass = 0; pass < 2; pass++) {
        uint64_t f = starts[pass];
        uint64_t end = ends[pass];

        while (f + n <= end) {
            /* Skip whole words that are fully unavailable, which is the
             * common case for the large firmware-reserved stretches. */
            if ((f & 63) == 0 && n <= 64) {
                uint64_t w = f >> 6;
                if ((g_reserved[w] | g_alloc[w]) == ~0ULL) {
                    f += 64;
                    continue;
                }
            }

            uint64_t k = 0;
            while (k < n) {
                uint64_t idx = f + k;
                if (bit_get(g_reserved, idx) || bit_get(g_alloc, idx)) break;
                k++;
            }
            if (k == n) return f;

            /* The frame at f+k is unavailable, so no run can start at
             * or before it. */
            f = f + k + 1;
        }
    }
    return 0;
}

static uint64_t alloc_run(uint64_t n, uint64_t limit)
{
    if (n == 0 || !g_initialized) return 0;

    uint64_t flags = pmm_lock();

    /* Frame 0 is unconditionally reserved (it is below 1 MiB), so a
     * run can never legitimately start there and a return of 0 from
     * find_run_locked is unambiguously "no run found". */
    uint64_t f = find_run_locked(n, limit);
    if (f == 0) {
        pmm_unlock(flags);
        return 0;
    }

    for (uint64_t k = 0; k < n; k++) {
        bit_set(g_alloc, f + k);
    }
    g_allocated_count += n;
    g_next_hint = f + n;
    if (g_next_hint >= g_total_frames) g_next_hint = 0;

    pmm_unlock(flags);
    return f * PMM_PAGE_SIZE;
}

uint64_t pmm_alloc_page(void)
{
    return alloc_run(1, 0);
}

uint64_t pmm_alloc_page_below(uint64_t limit)
{
    return alloc_run(1, limit);
}

uint64_t pmm_try_alloc_pages(uint64_t n)
{
    return alloc_run(n, 0);
}

uint64_t pmm_alloc_pages(uint64_t n)
{
    if (n == 0) {
        /* BOOT-02A's version returned the bump cursor for n == 0, which
         * no caller relies on and which cannot be expressed here.
         * Treat it as the programming error it is. */
        panic("PMM: pmm_alloc_pages(0)", 0, 0);
    }
    uint64_t p = alloc_run(n, 0);
    if (p == 0) {
        panic("PMM: out of physical memory", n, pmm_free_frames());
    }
    return p;
}

/* ------------------------------------------------------------------ *
 * Freeing
 * ------------------------------------------------------------------ */

PmmResult pmm_free_page(uint64_t phys)
{
    if (!g_initialized) return PMM_ERR_BAD_REQUEST;
    if (phys & (PMM_PAGE_SIZE - 1)) return PMM_ERR_NOT_ALIGNED;

    uint64_t f = phys / PMM_PAGE_SIZE;
    if (f >= g_total_frames) return PMM_ERR_OUT_OF_RANGE;

    uint64_t flags = pmm_lock();

    PmmResult r;
#if VEX_INJECTED(3)
    /* NEGATIVE CONTROL: accept a free of reserved memory, adding
     * firmware/kernel/MMIO frames to the free pool. The MEMORY test must
     * catch this. See kernel/include/boot03_inject.h. */
    if (0) {
#else
    if (bit_get(g_reserved, f)) {
#endif
        /* Refusing this is the whole point of keeping reserved-ness in
         * a separate bitmap: a stray free must not be able to add
         * firmware, MMIO or kernel memory to the free pool. */
        r = PMM_ERR_RESERVED;
    } else if (!bit_get(g_alloc, f)) {
        r = PMM_ERR_NOT_ALLOCATED;
    } else {
        bit_clear(g_alloc, f);
        g_allocated_count--;
        r = PMM_OK;
    }

    pmm_unlock(flags);
    return r;
}

/* KERNEL-01 Phase 5. See pmm.h for the full rationale, including why
 * this is a separate entry point instead of a relaxation of
 * pmm_free_page(), and why requiring the frame to be ALLOCATED as well as
 * reserved is what makes it structurally unable to release firmware, the
 * kernel image, the framebuffer, ACPI tables or the bitmaps. */
PmmResult pmm_release_reserved_page(uint64_t phys, PmmReserveReason why)
{
    if (!g_initialized) return PMM_ERR_BAD_REQUEST;
    if (phys & (PMM_PAGE_SIZE - 1)) return PMM_ERR_NOT_ALIGNED;

    /* Checked, not trusted. Page tables are the only class KERNEL-01
     * reclaims; everything else that is reserved must stay reserved. */
    if (why != PMM_RSV_PAGE_TABLE) return PMM_ERR_BAD_REQUEST;

    uint64_t f = phys / PMM_PAGE_SIZE;
    if (f >= g_total_frames) return PMM_ERR_OUT_OF_RANGE;

    uint64_t flags = pmm_lock();

    PmmResult r;
    if (!bit_get(g_reserved, f)) {
        /* Not reserved, so there is nothing to release. Reported as a bad
         * request rather than silently forwarded to the ordinary free
         * path, so a caller that has lost track of a frame's state finds
         * out instead of getting a free it did not ask for. */
        r = PMM_ERR_BAD_REQUEST;
    } else if (!bit_get(g_alloc, f)) {
        /* Reserved but never allocated: this is firmware, the kernel
         * image, the framebuffer, ACPI, the bitmaps, or low memory. The
         * one check that makes this function safe regardless of what
         * reason the caller claimed. */
        r = PMM_ERR_RESERVED;
    } else if (g_reason_frames[why] == 0) {
        /* The aggregate accounting says no frame of this class is
         * outstanding, so decrementing would underflow. Refusing keeps
         * the reported statistics trustworthy, which matters because the
         * tests read them as evidence. */
        r = PMM_ERR_BAD_REQUEST;
    } else {
        bit_clear(g_reserved, f);
        g_reserved_count--;
        g_reason_frames[why]--;

        bit_clear(g_alloc, f);
        g_allocated_count--;
        r = PMM_OK;
    }

    pmm_unlock(flags);
    return r;
}

PmmResult pmm_free_pages(uint64_t phys, uint64_t n)
{
    if (n == 0) return PMM_ERR_BAD_REQUEST;
    for (uint64_t i = 0; i < n; i++) {
        PmmResult r = pmm_free_page(phys + i * PMM_PAGE_SIZE);
        if (r != PMM_OK) return r;
    }
    return PMM_OK;
}

/* ------------------------------------------------------------------ *
 * Queries
 * ------------------------------------------------------------------ */

uint64_t pmm_total_frames(void)   { return g_total_frames; }
uint64_t pmm_highest_address(void){ return g_highest_addr; }

uint64_t pmm_usable_frames(void)
{
    uint64_t flags = pmm_lock();
    uint64_t v = g_total_frames - g_reserved_count;
    pmm_unlock(flags);
    return v;
}

uint64_t pmm_allocated_frames(void)
{
    uint64_t flags = pmm_lock();
    uint64_t v = g_allocated_count;
    pmm_unlock(flags);
    return v;
}

uint64_t pmm_free_frames(void)
{
    uint64_t flags = pmm_lock();
    uint64_t v = g_total_frames - g_reserved_count - g_allocated_count;
    pmm_unlock(flags);
    return v;
}

int pmm_is_reserved(uint64_t phys)
{
    if (!g_initialized) return 1;
    uint64_t f = phys / PMM_PAGE_SIZE;
    if (f >= g_total_frames) return 1;

    uint64_t flags = pmm_lock();
    int v = bit_get(g_reserved, f);
    pmm_unlock(flags);
    return v;
}

int pmm_is_allocated(uint64_t phys)
{
    if (!g_initialized) return 0;
    uint64_t f = phys / PMM_PAGE_SIZE;
    if (f >= g_total_frames) return 0;

    uint64_t flags = pmm_lock();
    int v = bit_get(g_alloc, f);
    pmm_unlock(flags);
    return v;
}

/* --- BOOT-02A compatibility shims --------------------------------- */

uint64_t pmm_arena_total_pages(void)
{
    return pmm_usable_frames();
}

uint64_t pmm_arena_used_pages(void)
{
    return pmm_allocated_frames();
}
