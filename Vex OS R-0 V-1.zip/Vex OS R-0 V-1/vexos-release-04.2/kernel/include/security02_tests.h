/*
 * Vex OS - kernel/include/security02_tests.h
 *
 * SECURITY-02 in-kernel validation suite: Graphics 2 audit, kernel
 * privilege/memory audit, and the Ring 3 boundary.
 *
 * Every check has a unique ID (SECURITY-02-NNN), a stated purpose, a
 * deterministic result, and prints PASS/FAIL. The total is COUNTED, never
 * hardcoded: the closing line reports however many checks actually ran.
 *
 * AREA LINES ("[security] SECURITY-02: <area> PASS") are printed only if
 * at least one check in that area executed AND every one passed. An area
 * with zero executed checks prints nothing - never a PASS by omission.
 *
 * PRECONDITION: ring3_init() has been called. The suite refuses to claim
 * the Ring 3 areas otherwise.
 */
#ifndef VEXOS_SECURITY02_TESTS_H
#define VEXOS_SECURITY02_TESTS_H

#include <stdint.h>

typedef struct {
    uint32_t checks_run;
    uint32_t checks_failed;
    int      all_areas_pass;     /* 1 if every area printed PASS */
} Security02Results;

void security02_run_tests(Security02Results *out);
void security02_print_summary(const Security02Results *r);
int  security02_all_passed(const Security02Results *r);

#endif
