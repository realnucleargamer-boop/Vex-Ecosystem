#!/usr/bin/env python3
"""Vex OS - tests/check_build_lists.py

Static consistency check between the two build systems:
  kernel/Makefile (Linux/WSL)   vs   build.ps1 (Windows, clang/lld)
Both must compile exactly the same set of kernel sources, every listed file
must exist, every .c/.asm under kernel/src must be listed (no orphan that
silently drops out of one build), and - because build.ps1 names objects by
BASENAME only - no two sources may share a basename.

This does NOT run PowerShell and does not prove build.ps1 executes; it
catches the specific failure that already happened once (SECURITY-02 sources
present in the Makefile but missing from build.ps1, so the Windows link would
fail with undefined ring3_init).
Run from the repo root:  python3 tests/check_build_lists.py
"""
import re, os, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
mk = open(os.path.join(root, "kernel/Makefile")).read()
ps = open(os.path.join(root, "build.ps1"), encoding="utf-8", errors="replace").read()

def mk_list(name):
    m = re.search(name + r"\s*:=\s*((?:[^\n]*\\\n)*[^\n]*)", mk)
    return set(re.findall(r"src/[\w/]+\.(?:c|asm)", m.group(1)))
def ps_list(name):
    m = re.search(r"\$" + name + r"\s*=\s*@\((.*?)\n\)", ps, re.S)
    return set(p.replace("\\", "/")[len("kernel/"):] for p in re.findall(r'"(kernel\\src\\[^"]+)"', m.group(1)))

fail = 0
def check(ok, msg):
    global fail
    print(("PASS  " if ok else "FAIL  ") + msg); fail += (not ok)

for kind, ext in (("C_SRCS", "c"), ("ASM_SRCS", "asm")):
    a, b = mk_list(kind), ps_list("CSources" if ext == "c" else "AsmSources")
    check(a == b, f"{kind}: Makefile and build.ps1 list the same {len(a)} files"
          + ("" if a == b else f"  only-in-Makefile={sorted(a-b)} only-in-build.ps1={sorted(b-a)}"))
    check(all(os.path.isfile(os.path.join(root, "kernel", f)) for f in a | b), f"{kind}: every listed file exists")

listed = mk_list("C_SRCS") | mk_list("ASM_SRCS")
on_disk = set()
for d, _, fs in os.walk(os.path.join(root, "kernel/src")):
    for f in fs:
        if f.endswith((".c", ".asm")) and f != "ap_trampoline.asm":   # built separately as a flat binary
            on_disk.add(os.path.relpath(os.path.join(d, f), os.path.join(root, "kernel")).replace("\\", "/"))
orph = sorted(on_disk - listed)
# runtime_ui.c etc. are listed; anything on disk but unlisted would be silently dropped
check(not orph, "no source file under kernel/src is missing from the build lists" + (f"  orphans={orph}" if orph else ""))
bn = [os.path.basename(f).rsplit(".", 1)[0] for f in listed]
dup = sorted({x for x in bn if bn.count(x) > 1})
check(not dup, "object basenames are unique (build.ps1 names objects by basename only)" + (f"  dup={dup}" if dup else ""))
sys.exit(1 if fail else 0)
