/* Vex OS - kernel/include/crypto.h : SHA-256, HMAC-SHA256, PBKDF2-HMAC-SHA256 (FIPS 180-4, RFC 2104, RFC 8018).
 * Standard algorithms only; nothing invented. Freestanding, no allocation, no globals (re-entrant). */
#ifndef VEXOS_CRYPTO_H
#define VEXOS_CRYPTO_H
#include <stdint.h>
#include <stddef.h>
typedef struct { uint32_t h[8]; uint8_t buf[64]; uint64_t len; uint32_t fill; } Sha256;
void sha256_init(Sha256 *c);
void sha256_update(Sha256 *c, const void *d, size_t n);
void sha256_final(Sha256 *c, uint8_t out[32]);
void hmac_sha256(const uint8_t *key, size_t kl, const uint8_t *msg, size_t ml, uint8_t out[32]);
void pbkdf2_hmac_sha256(const uint8_t *pw, size_t pl, const uint8_t *salt, size_t sl, uint32_t iters, uint8_t out[32]);
int  ct_equal(const uint8_t *a, const uint8_t *b, size_t n);     /* constant-time compare: 1 = equal */
void secure_zero(void *p, size_t n);                              /* not optimised away */
#endif
