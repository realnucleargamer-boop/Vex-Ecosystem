"""Simple IR optimization passes (VexScript 2+ Phase D).

Preserves behavior. No speculative opts.
"""
from __future__ import annotations
from .nodes import ModuleIR, FunctionIR, Instruction, Value, Block


def optimize_module(mod: ModuleIR) -> ModuleIR:
    for fn in mod.functions:
        _fold_constants(fn)
        _remove_unreachable(fn)
    return mod


def _is_const_val(v: Value) -> bool:
    return v.kind == "lit" or (v.kind == "ssa" and False)


def _fold_constants(fn: FunctionIR) -> None:
    """Fold const op const arithmetic and comparisons in-place."""
    # Map ssa -> constant int if known
    known: dict[str, int] = {}
    for b in fn.blocks:
        new_inst: list[Instruction] = []
        for inst in b.instructions:
            # Track pure consts
            if inst.op == "const" and inst.dest and inst.ty != "string":
                try:
                    known[inst.dest] = int(inst.extra)
                except (TypeError, ValueError):
                    pass
                new_inst.append(inst)
                continue
            if inst.op in ("add", "sub", "mul", "div", "mod", "eq", "ne", "lt", "le", "gt", "ge") and len(inst.args) == 2:
                a, b_ = inst.args[0], inst.args[1]
                av = _val_const(a, known)
                bv = _val_const(b_, known)
                if av is not None and bv is not None:
                    try:
                        res = _eval_op(inst.op, av, bv)
                    except ZeroDivisionError:
                        new_inst.append(inst)
                        continue
                    if inst.dest:
                        known[inst.dest] = int(res)
                        new_inst.append(
                            Instruction(inst.dest, "const", inst.ty or "i64", [], extra=int(res))
                        )
                        continue
            if inst.op == "copy" and inst.args:
                av = _val_const(inst.args[0], known)
                if av is not None and inst.dest:
                    known[inst.dest] = av
                    new_inst.append(
                        Instruction(inst.dest, "const", inst.ty or "i64", [], extra=av)
                    )
                    continue
            new_inst.append(inst)
        b.instructions = new_inst


def _val_const(v: Value, known: dict[str, int]) -> int | None:
    if v.kind == "lit":
        try:
            return int(v.text)
        except ValueError:
            return None
    if v.kind == "ssa" and v.text in known:
        return known[v.text]
    return None


def _eval_op(op: str, a: int, b: int) -> int:
    if op == "add":
        return a + b
    if op == "sub":
        return a - b
    if op == "mul":
        return a * b
    if op == "div":
        return int(a / b)  # toward zero for positives; Python // differs for neg
    if op == "mod":
        return a % b
    if op == "eq":
        return 1 if a == b else 0
    if op == "ne":
        return 1 if a != b else 0
    if op == "lt":
        return 1 if a < b else 0
    if op == "le":
        return 1 if a <= b else 0
    if op == "gt":
        return 1 if a > b else 0
    if op == "ge":
        return 1 if a >= b else 0
    raise ValueError(op)


def _remove_unreachable(fn: FunctionIR) -> None:
    if not fn.blocks:
        return
    entry = fn.blocks[0].name
    succ: dict[str, list[str]] = {b.name: [] for b in fn.blocks}
    for b in fn.blocks:
        t = b.terminator
        if not t:
            continue
        if t.op == "br":
            succ[b.name].append(t.extra)
        elif t.op == "br_cond":
            tgt, f = t.extra
            succ[b.name].extend([tgt, f])
    reachable = set()
    stack = [entry]
    while stack:
        n = stack.pop()
        if n in reachable:
            continue
        reachable.add(n)
        for s in succ.get(n, []):
            if s not in reachable:
                stack.append(s)
    fn.blocks = [b for b in fn.blocks if b.name in reachable]
