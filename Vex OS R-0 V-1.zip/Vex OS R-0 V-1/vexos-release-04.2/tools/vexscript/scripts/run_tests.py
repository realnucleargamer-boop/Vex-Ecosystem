#!/usr/bin/env python3
"""VEX-Script 1.2 test suite"""

import sys
import io
from pathlib import Path
from contextlib import redirect_stdout

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vexscript.lexer import Lexer, TokenKind
from vexscript.parser import Parser
from vexscript.interpreter import Interpreter
from vexscript.errors import VexError

PASSED = 0
FAILED = 0


def check(name: str, cond: bool, detail: str = ""):
    global PASSED, FAILED
    if cond:
        PASSED += 1
        print(f"  PASS  {name}")
    else:
        FAILED += 1
        print(f"  FAIL  {name}  {detail}")


def run_source(src: str, filename: str = "<test>") -> tuple[int, str]:
    interp = Interpreter()
    buf = io.StringIO()
    with redirect_stdout(buf):
        interp.load(src, filename)
        code = interp.run_main()
    return code, buf.getvalue()


def test_lexer():
    print("\n=== Lexer ===")
    toks = Lexer('fn main() -> i32 { println("hi"); }').tokenize()
    kinds = [t.kind for t in toks]
    check("fn keyword", TokenKind.FN in kinds)
    check("string lit", any(t.kind == TokenKind.STRING and t.value == "hi" for t in toks))
    kinds2 = [t.kind for t in Lexer("struct Point {}").tokenize()]
    check("struct keyword", TokenKind.STRUCT in kinds2)
    try:
        Lexer("@").tokenize()
        check("reject illegal", False)
    except VexError:
        check("reject illegal", True)


def test_parser_struct():
    print("\n=== Parser structs ===")
    src = """
    struct Point { x: i64 y: i64 }
    fn main() -> i32 {
        let p = Point { x: 1, y: 2 };
        return 0;
    }
    """
    prog = Parser(Lexer(src).tokenize()).parse()
    check("parses struct def", len(prog.structs) == 1 and prog.structs[0].name == "Point")
    check("struct has 2 fields", len(prog.structs[0].fields) == 2)


def test_compat_1_0():
    print("\n=== 1.0 Compatibility ===")
    src = Path(ROOT / "examples/compat_1_0.vex").read_text()
    code, out = run_source(src, "compat_1_0.vex")
    check("compat runs", code == 0)
    check("compat output", "43" in out)


def test_control():
    print("\n=== Control flow ===")
    src = Path(ROOT / "examples/control_1_1.vex").read_text()
    code, out = run_source(src)
    check("control exit 0", code == 0)
    lines = [l for l in out.strip().splitlines() if l.strip()]
    check("while+for+loop output count", len(lines) == 8, f"got {lines}")


def test_structs():
    print("\n=== Structs ===")
    src = Path(ROOT / "examples/structs.vex").read_text()
    code, out = run_source(src, str(ROOT / "examples/structs.vex"))
    check("structs exit 0", code == 0)
    lines = out.strip().splitlines()
    check("struct field read/write", lines == ["10", "20", "50", "1", "100"], f"got {lines}")


def test_struct_negative():
    print("\n=== Struct negative ===")
    try:
        run_source("""
        struct Point { x: i64 }
        fn main() -> i32 {
            let p = Point { x: 1, y: 2 };
            return 0;
        }
        """)
        check("reject unknown field in lit", False)
    except VexError:
        check("reject unknown field in lit", True)

    try:
        run_source("""
        struct Point { x: i64 y: i64 }
        fn main() -> i32 {
            let p = Point { x: 1 };
            return 0;
        }
        """)
        check("reject missing field", False)
    except VexError:
        check("reject missing field", True)

    try:
        run_source("""
        struct Point { x: i64 }
        fn main() -> i32 {
            let p = Point { x: 1 };
            p.x = 5;
            return 0;
        }
        """)
        check("reject mutate immutable", False)
    except VexError:
        check("reject mutate immutable", True)


def test_modules():
    print("\n=== Modules ===")
    src = Path(ROOT / "examples/use_math.vex").read_text()
    # load with correct base path so math_mod.vex resolves
    interp = Interpreter()
    buf = io.StringIO()
    with redirect_stdout(buf):
        interp.load(src, str(ROOT / "examples/use_math.vex"))
        code = interp.run_main()
    out = buf.getvalue()
    check("module load+run", code == 0)
    check("module functions", "25" in out and "30" in out, f"got {out!r}")


def test_module_missing():
    print("\n=== Module missing ===")
    try:
        run_source("use nonexistent;\nfn main() -> i32 { return 0; }", "t.vex")
        check("missing module error", False)
    except VexError as e:
        check("missing module error", "not found" in str(e).lower() or "module" in str(e).lower(), str(e))


def test_option_result():
    print("\n=== Option / Result ===")
    src = Path(ROOT / "examples/option_result.vex").read_text()
    code, out = run_source(src)
    check("option/result exit", code == 0)
    check("prints expected", "42" in out and "99" in out)


def test_strings():
    print("\n=== Strings ===")
    src = Path(ROOT / "examples/strings.vex").read_text()
    code, out = run_source(src)
    check("strings exit", code == 0)
    check("concat+len", "VexScript" in out and "9" in out)


def test_stdlib_helpers():
    print("\n=== Stdlib helpers ===")
    src = """
    fn main() -> i32 {
        println(abs(0 - 5));
        println(min(3, 7));
        println(max(3, 7));
        if (str_contains("hello", "ell")) { println(1); }
        return 0;
    }
    """
    code, out = run_source(src)
    check("abs/min/max/contains", code == 0 and "5" in out and "3" in out and "7" in out and "1" in out, f"got {out!r}")


def test_negative_core():
    print("\n=== Negative core ===")
    try:
        run_source("fn foo() -> i32 { return 0; }")
        check("missing main", False)
    except VexError:
        check("missing main", True)
    try:
        run_source("fn main() -> i32 { let x: i64 = 1; x = 2; return 0; }")
        check("immutable assign", False)
    except VexError:
        check("immutable assign", True)
    try:
        run_source("fn main() -> i32 { return x; }")
        check("undefined var", False)
    except VexError:
        check("undefined var", True)


def test_hello():
    print("\n=== Hello ===")
    src = Path(ROOT / "examples/hello.vex").read_text()
    code, out = run_source(src)
    check("hello", code == 0 and "Hello" in out)


def main():
    print("VEX-Script 1.2 Test Suite")
    test_lexer()
    test_parser_struct()
    test_hello()
    test_compat_1_0()
    test_control()
    test_structs()
    test_struct_negative()
    test_modules()
    test_module_missing()
    test_option_result()
    test_strings()
    test_stdlib_helpers()
    test_negative_core()
    print(f"\n=== Results: {PASSED} passed, {FAILED} failed ===")
    return 0 if FAILED == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
