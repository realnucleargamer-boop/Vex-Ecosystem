/* Host harness for kernel/src/apps/vfs_cmds.c over the REAL kernel/src/apps/vfs.c (timer stubbed). Built with ASan+UBSan. */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "vfs.h"
#include "vfs_cmds.h"
uint64_t timer_ticks(void) { return 7; }
static char cap[400][200]; static int ncap;
static void sink(const char *l) { if (ncap < 400) { strncpy(cap[ncap], l, 199); cap[ncap][199] = 0; ncap++; } }
static int fails, total;
#define CHECK(c, m) do { total++; if (!(c)) { fails++; printf("FAIL  %s\n", m); } else printf("PASS  %s\n", m); } while (0)
static int has(const char *s) { for (int i = 0; i < ncap; i++) if (strstr(cap[i], s)) return 1; return 0; }
static int mk(const char *path_dir, const char *name, const char *text, uint32_t uid, int admin)
{
    int d = vfs_resolve(path_dir); int n = vfs_create(d, name, text == NULL, uid, admin);
    if (n >= 0 && text) vfs_write(n, text, (int)strlen(text), uid, admin);
    return n;
}
int main(void)
{
    vfs_init();
    vfs_ensure_home(1, "vex"); vfs_ensure_home(2, "bob");
    mk("/home/vex", "n.txt", "hello valbook", 1, 1);
    mk("/home/vex", "multi.txt", "line one\nline two\ttabbed\r\nline\x01three \xc3\xa9", 1, 1);
    mk("/home/vex", "empty.txt", "", 1, 1);
    mk("/home/vex", "docs", NULL, 1, 1);
    mk("/home/vex/docs", "inner.txt", "inner text", 1, 1);
    mk("/home/bob", "secret.txt", "bob private", 2, 1);
    mk("/tmp", "shared.txt", "world readable", 1, 1);
    char big[2048]; for (int i = 0; i < 2047; i++) big[i] = (i % 60 == 59) ? '\n' : 'a' + i % 26; big[2047] = 0;
    mk("/tmp", "big.txt", big, 1, 1);

    /* ---- testpath ---- */
    ncap = 0; int r = vfs_cmd_testpath("/home/vex/n.txt", 1, 0, "vex", sink);
    CHECK(r == 1 && has("TRUE: '/home/vex/n.txt' exists and is a file (13 bytes)."), "testpath: existing file -> TRUE with size");
    ncap = 0; r = vfs_cmd_testpath("n.txt", 1, 0, "vex", sink); CHECK(r == 1 && has("/home/vex/n.txt"), "testpath: relative name resolves inside the user's home");
    ncap = 0; r = vfs_cmd_testpath("~/docs", 1, 0, "vex", sink); CHECK(r == 1 && has("folder (1 item(s))"), "testpath: ~/docs -> folder with item count");
    ncap = 0; r = vfs_cmd_testpath("~", 1, 0, "vex", sink); CHECK(r == 1 && has("'/home/vex' exists and is a folder"), "testpath: ~ is the home folder");
    ncap = 0; r = vfs_cmd_testpath("/home//vex///n.txt/", 1, 0, "vex", sink); CHECK(r == 1 && has("'/home/vex/n.txt'"), "testpath: repeated slashes normalised in the answer");
    ncap = 0; r = vfs_cmd_testpath("/home/vex/missing.txt", 1, 0, "vex", sink); CHECK(r == 0 && has("FALSE:") && has("does not exist"), "testpath: missing file -> FALSE does not exist");
    ncap = 0; r = vfs_cmd_testpath("/home/vex/n.txt/x", 1, 0, "vex", sink); CHECK(r == 0 && has("does not exist"), "testpath: a file used as a folder -> FALSE");
    ncap = 0; r = vfs_cmd_testpath("/home/vex/../bob/secret.txt", 1, 0, "vex", sink); CHECK(r == 0 && has("not a valid path"), "testpath: '..' traversal rejected as invalid");
    ncap = 0; r = vfs_cmd_testpath("/home/vex/./n.txt", 1, 0, "vex", sink); CHECK(r == 0 && has("not a valid path"), "testpath: '.' component rejected");
    ncap = 0; r = vfs_cmd_testpath("/home/vex/b\\ad", 1, 0, "vex", sink); CHECK(r == 0 && has("not a valid path"), "testpath: illegal characters rejected");
    ncap = 0; r = vfs_cmd_testpath("", 1, 0, "vex", sink); CHECK(r == 0 && has("Usage: v. testpath"), "testpath: empty argument prints usage");
    ncap = 0; r = vfs_cmd_testpath("   ", 1, 0, "vex", sink); CHECK(r == 0 && has("Usage: v. testpath"), "testpath: blank argument prints usage");
    { char p[400]; memset(p, 'a', 399); p[399] = 0; p[0] = '/'; ncap = 0; r = vfs_cmd_testpath(p, 1, 0, "vex", sink); CHECK(r == 0 && ncap == 1, "testpath: over-long path is refused safely (no overflow)"); }
    { char p[400]; memset(p, 'a', 399); p[399] = 0; ncap = 0; r = vfs_cmd_testpath(p, 1, 0, "vex", sink); CHECK(r == 0 && ncap == 1, "testpath: over-long relative path is refused safely"); }
    ncap = 0; int a1 = vfs_cmd_testpath("/home/bob/secret.txt", 1, 0, "vex", sink); char first[200]; strcpy(first, cap[0]);
    ncap = 0; int a2 = vfs_cmd_testpath("/home/bob/nothing-here.txt", 1, 0, "vex", sink);
    CHECK(a1 == 0 && a2 == 0 && strstr(first, "not accessible") && strstr(cap[0], "not accessible"), "testpath: standard user gets the SAME answer for another user's existing and non-existing file (no probing)");
    ncap = 0; r = vfs_cmd_testpath("/home/bob", 1, 0, "vex", sink); CHECK(r == 0 && has("not accessible"), "testpath: another user's home folder is not accessible");
    ncap = 0; r = vfs_cmd_testpath("/home/bob/secret.txt", 1, 1, "vex", sink); CHECK(r == 1 && has("TRUE"), "testpath: administrator can see another user's file");
    ncap = 0; r = vfs_cmd_testpath("/tmp/shared.txt", 2, 0, "bob", sink); CHECK(r == 1, "testpath: world-readable /tmp is visible to everyone");
    ncap = 0; r = vfs_cmd_testpath("/", 2, 0, "bob", sink); CHECK(r == 1 && has("folder"), "testpath: root is a folder");

    /* ---- content: file ---- */
    ncap = 0; r = vfs_cmd_content("/home/vex/n.txt", 1, 0, "vex", sink);
    CHECK(r == 2 && has("== /home/vex/n.txt (13 bytes) ==") && has("hello valbook"), "content: file -> header + text");
    ncap = 0; r = vfs_cmd_content("multi.txt", 1, 0, "vex", sink);
    CHECK(r == 4 && strcmp(cap[1], "line one") == 0 && strcmp(cap[2], "line two tabbed") == 0 && strstr(cap[3], "line?three") != NULL, "content: newlines split, tab->space, CR dropped, control/non-ASCII -> '?'");
    ncap = 0; r = vfs_cmd_content("empty.txt", 1, 0, "vex", sink); CHECK(r == 2 && has("(empty file)"), "content: empty file says so");
    ncap = 0; r = vfs_cmd_content("/home/bob/secret.txt", 1, 0, "vex", sink); CHECK(r == -1 && !has("bob private") && has("not accessible"), "content: another user's file is refused and its text never printed");
    ncap = 0; r = vfs_cmd_content("/home/bob/ghost.txt", 1, 0, "vex", sink); CHECK(r == -1 && has("not accessible"), "content: probing a non-existent file in another home gives the same refusal");
    ncap = 0; r = vfs_cmd_content("/home/vex/zzz", 1, 0, "vex", sink); CHECK(r == -1 && has("does not exist"), "content: missing path reported");
    ncap = 0; r = vfs_cmd_content("../x", 1, 0, "vex", sink); CHECK(r == -1 && has("not a valid path"), "content: relative '..' rejected");
    ncap = 0; r = vfs_cmd_content("", 1, 0, "vex", sink); CHECK(r == -1 && has("Usage: v. content"), "content: no argument prints usage");
    ncap = 0; r = vfs_cmd_content("/home/bob/secret.txt", 1, 1, "vex", sink); CHECK(r == 2 && has("bob private"), "content: administrator may read another user's file");
    ncap = 0; r = vfs_cmd_content("/tmp/big.txt", 1, 0, "vex", sink); CHECK(r > 20 && r <= VFSC_MAX_LINES + 1 && ncap <= VFSC_MAX_LINES + 2, "content: largest file stays within the line cap");

    /* ---- content: folder ---- */
    ncap = 0; r = vfs_cmd_content("/home/vex", 1, 0, "vex", sink);
    CHECK(has("== /home/vex/n.txt") && has("hello valbook") && has("== /home/vex/multi.txt") && has("== /home/vex/empty.txt") && !has("inner text"),
          "content: folder shows every file's text, does NOT recurse into subfolders");
    CHECK(has("-- folder /home/vex: 3 file(s), 1 subfolder(s) (not expanded) --"), "content: folder summary counts files and subfolders");
    ncap = 0; r = vfs_cmd_content("/home", 1, 0, "vex", sink); CHECK(!has("bob private") && !has("secret.txt"), "content: /home lists no file text and never leaks other users' files");
    CHECK(has("-- folder /home: 0 file(s), 2 subfolder(s) (not expanded), 1 hidden (not readable by you) --") || has("-- folder /home: 0 file(s), 1 subfolder(s) (not expanded), 1 hidden (not readable by you) --"), "content: unreadable children are counted as hidden, not silently omitted");
    ncap = 0; r = vfs_cmd_content("/home", 1, 1, "vex", sink); CHECK(r >= 0, "content: administrator can run it on /home");
    ncap = 0; r = vfs_cmd_content("/home/bob", 1, 0, "vex", sink); CHECK(r == -1 && !has("bob private"), "content: another user's folder refused");
    /* a folder with many files: only the first VFSC_MAX_FILES are expanded */
    vfs_ensure_home(3, "many");
    for (int i = 0; i < 40; i++) { char nm[32]; snprintf(nm, sizeof nm, "f%02d.txt", i); mk("/home/many", nm, "x", 3, 1); }
    ncap = 0; r = vfs_cmd_content("/home/many", 3, 0, "many", sink); CHECK(has("only the first 32 files shown") && r <= VFSC_MAX_LINES, "content: file-count cap reported honestly");
    printf("\n%d/%d vfs_cmds host checks passed\n", total - fails, total); return fails ? 1 : 0;
}
