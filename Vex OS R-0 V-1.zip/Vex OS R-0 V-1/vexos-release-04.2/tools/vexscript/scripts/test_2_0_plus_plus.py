#!/usr/bin/env python3
"""VexScript 2.0+++ language upgrade tests"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vexscript.interpreter import Interpreter
from vexscript.compile_ir import run_via_ir
from vexscript.errors import VexError

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

def run(src):
    i = Interpreter()
    i.load(src, "<t>")
    return i.run_main(), i.output

print("VexScript 2.0+++")

c, o = run('fn main() -> i32 { let n: str = "VEX AI"; println(n); return 0; }\n')
check("str type alias", c == 0 and o == ["VEX AI"], o)

c, o = run('fn main() -> i32 { println("Vex" + "Script"); return 0; }\n')
check("string +", c == 0 and o == ["VexScript"], o)

c, o = run('''
fn greet(name: str) -> str { return "Hello, " + name; }
fn main() -> i32 { println(greet("VEX")); return 0; }
''')
check("string param/return +", c == 0 and o == ["Hello, VEX"], o)

c, o = run('''
fn main() -> i32 {
    let nums: i64[] = [1, 2, 3, 4];
    println(nums[2]);
    println(array_length(nums));
    return 0;
}
''')
check("array index+len", c == 0 and o == ["3", "4"], o)

c, o = run('''
fn main() -> i32 {
    let a: bool = true;
    let b: bool = false;
    if (a && !b) { println(1); }
    if (a || b) { println(2); }
    return 0;
}
''')
check("bool && || !", c == 0 and o == ["1", "2"], o)

c, o = run('''
struct Intent { name: str priority: i64 }
fn main() -> i32 {
    let i = Intent { name: "hello", priority: 10 };
    println(i.name);
    println(i.priority);
    return 0;
}
''')
check("struct str fields", c == 0 and o == ["hello", "10"], o)

c, o = run('''
fn classify(input: str) -> str {
    if (input == "hello") { return "greeting"; }
    return "unknown";
}
fn main() -> i32 {
    println(classify("hello"));
    println(classify("x"));
    return 0;
}
''')
check("classify integration", c == 0 and o == ["greeting", "unknown"], o)

code, out = run_via_ir('''
fn classify(input: str) -> str {
    if (input == "hello") { return "greeting"; }
    return "unknown";
}
fn main() -> i32 {
    println(classify("hello"));
    let nums: i64[] = [7, 8, 9];
    println(nums[0]);
    println("A" + "B");
    return 0;
}
''')
check("IR path", code == 0 and "greeting" in out and "7" in out and "AB" in out, out)

try:
    run('fn main() -> i32 { let x: i64 = "hello"; return 0; }\n')
    check("reject i64=string", False)
except VexError:
    check("reject i64=string", True)

try:
    run('fn main() -> i32 { let x: i64 = true + 5; return 0; }\n')
    check("reject bool arith", False)
except VexError:
    check("reject bool arith", True)

print(f"\n=== 2.0+++ Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
