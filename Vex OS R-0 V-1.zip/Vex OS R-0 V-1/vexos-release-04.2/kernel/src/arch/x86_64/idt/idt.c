/*
 * Vex OS - kernel/src/arch/x86_64/idt/idt.c
 */

#include "idt.h"
#include "ring3.h"
#include "irq.h"
#include "gdt.h"
#include "serial.h"
#include "panic.h"
#include "lapic.h"
#include "vmm.h"
#include "secure.h"

static IdtEntry idt[256];
static IdtPtr idtr;

extern uint64_t isr_stub_table[256];
extern void idt_load(IdtPtr *ptr);

static volatile int self_test_hit = 0;

/* BOOT-03 page-fault expectation state. Single-slot by design; see
 * idt.h. Only ever armed and read by the BSP inside the test sequence,
 * so it carries no lock - and that constraint is what keeps it honest
 * rather than turning into an accidental demand-paging subsystem. */
static volatile int      pf_armed;
static volatile uint64_t pf_expect_page;
static volatile uint64_t pf_supply_phys;
static volatile int      pf_action;
static volatile int      pf_observed;
static volatile uint64_t pf_observed_cr2;
static volatile uint64_t pf_observed_error;
static volatile uint64_t pf_handled_count;

void idt_expect_page_fault(uint64_t virt, uint64_t phys,
                           IdtPageFaultAction action)
{
    pf_expect_page = virt & ~(VMM_PAGE_SIZE - 1);
    pf_supply_phys = phys;
    pf_action = (int)action;
    pf_observed = 0;
    pf_observed_cr2 = 0;
    pf_observed_error = 0;
    __atomic_thread_fence(__ATOMIC_RELEASE);
    pf_armed = 1;
}

void idt_clear_page_fault_expectation(void)
{
    pf_armed = 0;
    __atomic_thread_fence(__ATOMIC_RELEASE);
}

int idt_page_fault_observed(uint64_t *out_cr2, uint64_t *out_error_code)
{
    if (out_cr2) *out_cr2 = pf_observed_cr2;
    if (out_error_code) *out_error_code = pf_observed_error;
    return pf_observed;
}

uint64_t idt_page_faults_handled(void) { return pf_handled_count; }

/* Returns 1 if the fault was expected and has been repaired, so the
 * handler may iretq straight back to the faulting instruction and let it
 * re-execute. Returns 0 to fall through to the normal fatal path. */
static int handle_expected_page_fault(uint64_t cr2, uint64_t error_code)
{
    if (!pf_armed) return 0;

    uint64_t page = cr2 & ~(VMM_PAGE_SIZE - 1);
    if (page != pf_expect_page) {
        /* A page fault at some OTHER address while an expectation is
         * armed is a real bug, not the expected event. Do not repair it
         * and do not disarm - let it be fatal, loudly. */
        return 0;
    }

    VmmResult r;
    if (pf_action == IDT_PF_ACTION_MAP) {
        r = vmm_map_page(page, pf_supply_phys, VMM_KERNEL_RW_NX);
    } else if (pf_action == IDT_PF_ACTION_MAKE_WRITABLE) {
        r = vmm_protect_page(page, VMM_KERNEL_RW_NX);
    } else {
        return 0;
    }

    if (r != VMM_OK) {
        serial_puts("[kernel] #PF hook: repair FAILED - ");
        serial_puts(vmm_result_name(r));
        serial_puts("\n");
        return 0;   /* fall through to panic - do not loop forever */
    }

    pf_observed_cr2 = cr2;
    pf_observed_error = error_code;
    pf_handled_count++;
    pf_observed = 1;
    pf_armed = 0;
    __atomic_thread_fence(__ATOMIC_RELEASE);
    return 1;
}

static void idt_set_gate(int vec, uint64_t handler, uint8_t ist)
{
    IdtEntry *e = &idt[vec];
    e->offset_low = (uint16_t)(handler & 0xFFFF);
    e->selector = GDT_SEL_KERNEL_CODE;
    e->ist = ist & 0x7;
    e->type_attr = 0x8E; /* present, DPL0, 64-bit interrupt gate */
    e->offset_mid = (uint16_t)((handler >> 16) & 0xFFFF);
    e->offset_high = (uint32_t)((handler >> 32) & 0xFFFFFFFF);
    e->zero = 0;
}

/* Defensively mask the legacy 8259 PIC. We never call `sti` in
 * BOOT-02A, so nothing should fire regardless - this is cheap
 * insurance against any IRQ line firmware left unmasked, and against
 * any confusion with CPU-exception vectors 8-15 before real APIC
 * remapping happens in BOOT-02B. */
static void pic_mask_all(void)
{
    __asm__ volatile (
        "mov $0xFF, %%al\n"
        "out %%al, $0xA1\n"
        "out %%al, $0x21\n"
        : : : "al"
    );
}

static const char *exception_name(uint64_t vec)
{
    static const char *names[32] = {
        "Divide Error", "Debug", "NMI", "Breakpoint", "Overflow",
        "Bound Range Exceeded", "Invalid Opcode", "Device Not Available",
        "Double Fault", "Coprocessor Segment Overrun", "Invalid TSS",
        "Segment Not Present", "Stack-Segment Fault",
        "General Protection Fault", "Page Fault", "Reserved",
        "x87 Floating-Point Exception", "Alignment Check",
        "Machine Check", "SIMD Floating-Point Exception",
        "Virtualization Exception", "Control Protection Exception",
        "Reserved", "Reserved", "Reserved", "Reserved", "Reserved",
        "Reserved", "Reserved", "VMM Communication", "Security Exception",
        "Reserved"
    };
    if (vec < 32) return names[vec];
    return "Unexpected/Unhandled Interrupt";
}

/* ------------------------------------------------------------------ *
 * KERNEL-01 Phase 2: the interrupt-handler table.
 *
 * See kernel/include/irq.h for the concurrency rule that makes reading
 * this from interrupt context lock-free. In short: written only during
 * single-threaded init before the vector can be delivered, read-only
 * afterwards.
 *
 * The counters are the exception to "read-only": they are incremented
 * from the dispatch path on any CPU, so they are touched with relaxed
 * atomic adds. Relaxed is the right strength - nothing orders other
 * memory against them, they exist to be looked at afterwards, and a
 * fully-ordered RMW on every interrupt would be a real cost for no
 * correctness gain.
 * ------------------------------------------------------------------ */

static IrqHandler   irq_table[256];
static const char  *irq_names[256];
static uint64_t     irq_counts[256];
static uint64_t     irq_unhandled;
static uint64_t     irq_spurious;

/* Per-vector cap on the "nobody claims this vector" warning. An
 * unhandled interrupt that recurs at interrupt rate would otherwise turn
 * the serial log - the only debugging channel this kernel has - into a
 * single repeated line, which destroys the evidence for everything else
 * that happened. The counter is still exact; only the printing stops. */
#define IRQ_WARN_LIMIT 4
static uint32_t irq_warned[256];

const char *irq_result_name(IrqResult r)
{
    switch (r) {
    case IRQ_OK:                 return "ok";
    case IRQ_ERR_BAD_VECTOR:     return "vector not registerable";
    case IRQ_ERR_NULL_HANDLER:   return "null handler";
    case IRQ_ERR_TAKEN:          return "vector already taken";
    case IRQ_ERR_NOT_REGISTERED: return "vector not registered";
    default:                     return "unknown";
    }
}

/* Rejects exactly the vectors that must not be captured by a generic
 * handler: the exception range, which idt.c handles with decoded names
 * and the #PF recovery hook, and the LAPIC spurious vector, which must
 * never be EOI'd. */
static int vector_is_registerable(uint32_t vector)
{
    if (vector < IRQ_FIRST_VECTOR || vector > 255) return 0;
    if (vector == lapic_spurious_vector()) return 0;
    return 1;
}

IrqResult irq_register(uint32_t vector, IrqHandler fn, const char *name)
{
    if (!vector_is_registerable(vector)) return IRQ_ERR_BAD_VECTOR;
    if (fn == 0) return IRQ_ERR_NULL_HANDLER;

    if (irq_table[vector] != 0) {
        /* Idempotent for the same handler, refused for a different one.
         * See irq.h - timer_init() can legitimately run twice. */
        return (irq_table[vector] == fn) ? IRQ_OK : IRQ_ERR_TAKEN;
    }

    irq_names[vector] = name ? name : "(unnamed)";

    /* Publish the name before the pointer, and separate the two with a
     * release fence, so a handler observed as installed always has its
     * name already visible. This costs nothing at init time and removes
     * a class of confusing diagnostic where a live vector prints as
     * unnamed. */
    __atomic_store_n(&irq_table[vector], fn, __ATOMIC_RELEASE);
    return IRQ_OK;
}

IrqResult irq_unregister(uint32_t vector)
{
    if (!vector_is_registerable(vector)) return IRQ_ERR_BAD_VECTOR;
    if (irq_table[vector] == 0) return IRQ_ERR_NOT_REGISTERED;

    __atomic_store_n(&irq_table[vector], (IrqHandler)0, __ATOMIC_RELEASE);
    irq_names[vector] = 0;
    return IRQ_OK;
}

IrqHandler irq_handler_for(uint32_t vector)
{
    if (vector > 255) return 0;
    return irq_table[vector];
}

const char *irq_name_for(uint32_t vector)
{
    if (vector > 255 || irq_names[vector] == 0) return "(unregistered)";
    return irq_names[vector];
}

uint64_t irq_dispatch_count(uint32_t vector)
{
    if (vector > 255) return 0;
    return __atomic_load_n(&irq_counts[vector], __ATOMIC_RELAXED);
}

uint64_t irq_unhandled_count(void)
{
    return __atomic_load_n(&irq_unhandled, __ATOMIC_RELAXED);
}

uint64_t irq_spurious_count(void)
{
    return __atomic_load_n(&irq_spurious, __ATOMIC_RELAXED);
}

uint32_t irq_registered_count(void)
{
    uint32_t n = 0;
    for (int i = 0; i < 256; i++) {
        if (irq_table[i] != 0) n++;
    }
    return n;
}

/* Called from isr_common (isr_stubs.asm) for every vector. */
void idt_common_handler(InterruptFrame *frame)
{
    /* Breakpoint is the deliberate, non-fatal self-test path (see
     * idt_self_test below) - recognize it and return normally rather
     * than panicking, so a live int3 round-trip is provable without
     * halting the system. */
    if (frame->vector == 3) {
        self_test_hit = 1;
        serial_puts("[kernel] IDT self-test: INT3 caught, RIP=");
        serial_put_hex64(frame->rip);
        serial_puts(" - handler returned normally.\n");
        return;
    }

    /* KERNEL-01 Phase 2: registered interrupt sources, dispatched
     * through the handler table. Checked before the exception range
     * because it is the hot path and because no registerable vector is
     * an exception vector - vector_is_registerable() guarantees that, so
     * this cannot shadow an exception.
     *
     * BOOT-03's hardcoded `if (frame->vector == TIMER_VECTOR)` used to
     * live here. The timer now arrives through this same path, having
     * registered itself in timer_init(); it is no longer a special case
     * in the dispatcher.
     *
     * No lock is taken, and none may be: the TLB-shootdown receiver runs
     * from here and is required to acquire no VMM or PMM lock. */
    if (frame->vector >= IRQ_FIRST_VECTOR) {
        /* The LAPIC spurious vector first, because it is the one vector
         * whose correct handling is to do nothing at all - in
         * particular, NOT to EOI. Intel SDM Vol.3: no in-service bit is
         * set for a spurious interrupt, so an EOI here would dismiss an
         * unrelated interrupt that genuinely is in service. */
        if (frame->vector == lapic_spurious_vector()) {
            __atomic_fetch_add(&irq_spurious, 1, __ATOMIC_RELAXED);
            return;
        }

        IrqHandler h = __atomic_load_n(&irq_table[frame->vector],
                                       __ATOMIC_ACQUIRE);
        if (h != 0) {
            __atomic_fetch_add(&irq_counts[frame->vector], 1,
                               __ATOMIC_RELAXED);
            h(frame);
            /* EOI is the handler's responsibility - see irq.h. */
            return;
        }

        /* Nothing claims this vector. Two things must happen, and the
         * order matters less than that both do:
         *
         * (a) Count it. A silently swallowed interrupt is how "the
         *     shootdown vector was never actually delivered" gets
         *     mistaken for "the shootdown completed". The Phase 2 test
         *     asserts this counter is zero on a healthy boot, which is
         *     what makes it a check rather than a statistic.
         *
         * (b) EOI it anyway. This DIFFERS from BOOT-03, which issued no
         *     EOI on this path, and the change is deliberate: an
         *     unacknowledged LAPIC interrupt leaves its in-service bit
         *     set, which blocks every future interrupt at or below that
         *     priority on this CPU - forever. Before Phase 2 that could
         *     not happen, because the only CPU with interrupts enabled
         *     had exactly one unmasked source. Now that APs run with
         *     interrupts enabled, refusing to acknowledge an unexpected
         *     vector would convert a stray interrupt into a permanently
         *     deaf CPU, and a deaf CPU cannot acknowledge a shootdown.
         *     Losing one unexpected interrupt is strictly better than
         *     losing every subsequent one. The spurious vector is
         *     already excluded above, which is the one case where this
         *     reasoning would be wrong. */
        __atomic_fetch_add(&irq_unhandled, 1, __ATOMIC_RELAXED);

        if (irq_warned[frame->vector] < IRQ_WARN_LIMIT) {
            irq_warned[frame->vector]++;
            serial_puts("[kernel] WARNING: interrupt on unregistered"
                        " vector ");
            serial_put_dec64(frame->vector);
            serial_puts("\n");
        }

        uint64_t base = lapic_dispatch_base();
        if (base != 0) lapic_send_eoi(base);
        return;
    }

    if (frame->vector < 32) {
        /* SECURITY-02: an exception taken while executing Ring 3 code is
         * a fact about the USER task, not about the kernel, and must not
         * reach the fatal path below. If a Ring 3 run is armed this
         * records the fault and abandons this frame (it does not
         * return); if not, it returns 0 and we fall through to the
         * normal handling exactly as before. It sits ahead of every
         * kernel-probe fixup below on purpose: those all expect CS ==
         * kernel code, so a Ring 3 frame can never be one of them. */
        if ((frame->cs & 3) == 3 && ring3_handle_user_fault(frame)) {
            return;   /* not reached: ring3_handle_user_fault does not return on success */
        }

        uint64_t cr2 = 0;
        if (frame->vector == 14) {
            __asm__ volatile ("mov %%cr2, %0" : "=r" (cr2));

            /* BOOT-03: a page fault the kernel deliberately provoked and
             * has arranged to repair. Returning from here re-executes
             * the faulting instruction, which is the whole point - it
             * proves the fault was recoverable, not merely reported. */
            if (handle_expected_page_fault(cr2, frame->error_code)) {
                return;
            }
        }

        /* SECURITY-01: a faulting access probe.
         *
         * Checked AFTER BOOT-03's repair hook, so that existing
         * behaviour is reached first and is entirely unchanged. Unlike
         * that hook, this one repairs NOTHING - the access under test is
         * supposed to stay denied. It records what the CPU reported and
         * resumes at the probe's fixup, so the probe can return "that
         * faulted" to a test which then asserts on the vector and error
         * code rather than on anybody's say-so.
         *
         * Only #PF (14), #GP (13) and #UD (6) are eligible. Widening it
         * would turn a test instrument into a general exception swallower,
         * which is precisely the kind of thing that hides real faults.
         * Anything else still panics. */
        if (frame->vector == 14 || frame->vector == 13 || frame->vector == 6) {
            if (sec_probe_fixup(frame, frame->vector, frame->error_code, cr2)) {
                return;
            }
        }

        serial_puts("\n[kernel] UNHANDLED CPU EXCEPTION: ");
        serial_puts(exception_name(frame->vector));
        serial_puts("\n");
        serial_puts("  vector=");
        serial_put_dec64(frame->vector);
        serial_puts(" error_code=");
        serial_put_hex64(frame->error_code);
        serial_puts("\n");
        panic(exception_name(frame->vector), frame->rip, cr2);
        /* panic() does not return */
    }

    /* Unreachable: every vector is either < 32 (handled above, and that
     * path panics) or >= IRQ_FIRST_VECTOR == 32 (handled above, and that
     * path returns). Kept as a defensive no-op rather than deleted so
     * that a future change to IRQ_FIRST_VECTOR which opened a gap would
     * produce a visible warning instead of falling off the end of the
     * function. */
    serial_puts("[kernel] WARNING: interrupt fell through dispatch,"
                " vector=");
    serial_put_dec64(frame->vector);
    serial_puts("\n");
}

void idt_init(void)
{
    pic_mask_all();

    for (int i = 0; i < 256; i++) {
        uint8_t ist = (i == 8) ? TSS_IST_DOUBLE_FAULT : 0;
        idt_set_gate(i, isr_stub_table[i], ist);
    }

    idtr.limit = (uint16_t)(sizeof(idt) - 1);
    idtr.base = (uint64_t)(uintptr_t)&idt;
    idt_load(&idtr);
}

int idt_self_test(void)
{
    self_test_hit = 0;
    __asm__ volatile ("int3");
    return self_test_hit;
}

void idt_load_on_this_cpu(void)
{
    idt_load(&idtr);
}

/* SECURITY-02: the ONE deliberate, narrow exception to every gate being
 * DPL0. Software interrupts (the INT instruction, as opposed to a
 * hardware IRQ) require CPL <= gate DPL, so a DPL0 gate - what
 * idt_set_gate() installs for every vector in idt_init()'s loop above -
 * takes a #GP if Ring 3 ever executes `int vector`. That is exactly
 * right for every vector except the one syscall gate Ring 3 is
 * deliberately allowed to invoke.
 *
 * Deliberately does NOT take an arbitrary DPL argument: the only
 * legitimate caller is ring3_init() installing the one syscall vector,
 * and a function that can only ever produce a DPL3 gate cannot be
 * misused to accidentally open a different vector to Ring 3. Refuses
 * vectors below 32 (the CPU exception range) outright - a DPL3
 * exception gate would let Ring 3 trigger e.g. a debug exception
 * through software and reach handler paths that assume an exception
 * can only arrive from a fault or NMI. */
int idt_allow_user_syscall_vector(uint32_t vector)
{
    if (vector < 32 || vector > 255) return 0;
    idt[vector].type_attr = 0xEE; /* present, DPL3, 64-bit interrupt gate */
    return 1;
}
