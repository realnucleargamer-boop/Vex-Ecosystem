/*
 * Vex OS - kernel/include/pmm.h
 *
 * BOOT-03 physical memory manager.
 *
 * Replaces the BOOT-02A bump arena. That allocator could not free, only
 * covered one region, and deliberately ignored everything below 1 MiB;
 * it was fine for proving the memory-map pipeline and backing AP stacks
 * but could not be the permanent allocator.
 *
 * DESIGN
 *
 *   Two bitmaps over every 4 KiB frame from 0 to the top of the address
 *   range the EFI memory map describes:
 *
 *     reserved[]  1 = this frame may NEVER be allocated
 *     alloc[]     1 = this frame is currently allocated
 *
 *   Keeping "reserved" separate from "allocated" is what lets
 *   pmm_free_page() refuse to release a frame that was never
 *   allocatable in the first place, instead of silently adding
 *   firmware/MMIO/kernel memory to the free pool.
 *
 *   The allocator is DEFAULT-DENY: every frame starts reserved, and
 *   only EfiConventionalMemory is released. Firmware memory,
 *   EfiLoaderData (which holds BootInfo and the memory map array),
 *   ACPI tables, MMIO and anything unrecognised therefore stay
 *   unavailable by construction rather than by remembering to exclude
 *   them.
 *
 * SYNCHRONIZATION
 *
 *   A single spinlock guards both bitmaps. pmm_lock() clears the
 *   interrupt flag and pmm_unlock() restores it, because from BOOT-03
 *   the BSP runs with interrupts enabled and can be interrupted while
 *   holding the lock.
 *
 *   INVARIANT: interrupt handlers must not call any pmm_* function.
 *   The lock is not reentrant, so an allocating timer handler would
 *   deadlock against a BSP that already holds it. The BOOT-03 timer
 *   handler only increments a counter and sends EOI.
 *
 * BOOT-02A COMPATIBILITY
 *
 *   pmm_alloc_pages() keeps its old signature and panic-on-failure
 *   behaviour so ap_stack.c and smp.c work unchanged, but is now backed
 *   by a contiguous search over the bitmap instead of a bump pointer.
 */

#ifndef VEXOS_PMM_H
#define VEXOS_PMM_H

#include <stdint.h>
#include "bootinfo.h"

#define PMM_PAGE_SIZE 4096

/* Reason codes for reserving a range, purely for diagnostics so the
 * boot log can say *why* a frame is unavailable. */
typedef enum {
    PMM_RSV_FIRMWARE = 0,   /* not EfiConventionalMemory */
    PMM_RSV_LOW_1MIB,       /* legacy/real-mode territory below 1 MiB */
    PMM_RSV_KERNEL_IMAGE,
    PMM_RSV_BOOTINFO,       /* BootInfo struct + EFI memory map array */
    PMM_RSV_FRAMEBUFFER,
    PMM_RSV_ACPI,
    PMM_RSV_BITMAP,         /* the allocator's own bitmaps */
    PMM_RSV_TRAMPOLINE,     /* the BOOT-02C AP trampoline page */
    PMM_RSV_PAGE_TABLE,
    PMM_RSV_KERNEL_STACK,
    PMM_RSV_COUNT
} PmmReserveReason;

/* Return codes for the freeing/validating entry points. Returning a
 * code rather than panicking matters: "was this rejected correctly?"
 * is something the BOOT-03 test suite has to be able to ask without
 * halting the machine. */
typedef enum {
    PMM_OK = 0,
    PMM_ERR_NOT_ALIGNED,
    PMM_ERR_OUT_OF_RANGE,
    PMM_ERR_NOT_ALLOCATED,   /* double free, or never allocated */
    PMM_ERR_RESERVED,        /* attempt to free permanently reserved memory */
    PMM_ERR_NO_MEMORY,
    PMM_ERR_BAD_REQUEST      /* e.g. zero pages requested */
} PmmResult;

/* Phase 1 of init: walks the EFI memory map, sizes and places the
 * bitmaps, marks everything reserved, then releases
 * EfiConventionalMemory and re-reserves the regions the kernel must
 * keep (kernel image, BootInfo, memory map, framebuffer, ACPI, the
 * bitmaps themselves, and everything below 1 MiB).
 *
 * panic()s only if there is genuinely nowhere to put the bitmaps -
 * there is nothing safe to do without memory. Prints a summary. */
void pmm_init(BootInfo *info);

/* Marks [base, base+len) as permanently unavailable. Rounds outward to
 * whole frames, which is the safe direction: reserving a byte too much
 * loses a frame, reserving a byte too little hands out live memory.
 * Safe to call on already-reserved ranges. */
void pmm_reserve_range(uint64_t base, uint64_t len, PmmReserveReason why);

/* Allocates one frame. Returns 0 on failure - callers that cannot
 * proceed without it must check, not assume. */
uint64_t pmm_alloc_page(void);

/* Allocates one frame strictly below `limit`. Needed for the PML4:
 * the BOOT-02C AP trampoline loads CR3 in 32-bit protected mode, so
 * the top-level page table must be below 4 GiB. Returns 0 on failure. */
uint64_t pmm_alloc_page_below(uint64_t limit);

/* Allocates `n` CONTIGUOUS frames and returns the physical base.
 * panic()s on failure, preserving BOOT-02A behaviour that ap_stack.c
 * and smp.c already depend on. Use pmm_try_alloc_pages() where a
 * failure is a legitimate outcome. */
uint64_t pmm_alloc_pages(uint64_t n);

/* Same, but returns 0 instead of panicking. */
uint64_t pmm_try_alloc_pages(uint64_t n);

/* Frees one frame. Returns PMM_OK or the specific reason it refused. */
PmmResult pmm_free_page(uint64_t phys);

/* Frees `n` contiguous frames starting at `phys`. Stops and returns the
 * first error encountered; frames before that point are still freed. */
PmmResult pmm_free_pages(uint64_t phys, uint64_t n);

/* KERNEL-01 Phase 5: un-reserves and frees ONE frame that was reserved
 * for `why`, returning it to the free pool.
 *
 * WHY THIS EXISTS AS A SEPARATE ENTRY POINT AND NOT AS A RELAXATION OF
 * pmm_free_page(). Page-table frames are reserved as well as allocated,
 * and pmm_free_page() refuses every reserved frame - deliberately, because
 * that refusal is what stops a stray free from adding firmware, MMIO, or
 * kernel image memory to the free pool. BOOT-03's fault injection 3 exists
 * precisely to prove that refusal still works. Loosening pmm_free_page()
 * to permit page tables would weaken the guarantee for everything else and
 * would invalidate that negative control. So the narrow capability gets a
 * narrow, separately named door, and pmm_free_page() keeps refusing
 * everything it refused before.
 *
 * WHAT IT REFUSES, AND WHY EACH REFUSAL MATTERS
 *
 *   - Any `why` other than PMM_RSV_PAGE_TABLE. Page tables are the only
 *     class this milestone reclaims. Firmware, the kernel image, BootInfo,
 *     the framebuffer, ACPI tables, the frame bitmaps and the AP
 *     trampoline must never be freed at all, and kernel stacks are not
 *     reclaimed by KERNEL-01 - so the enum value is checked rather than
 *     trusted.
 *
 *   - A frame that is not currently reserved. Nothing to release.
 *
 *   - A frame that is not currently ALLOCATED. This is the load-bearing
 *     one. Every frame reserved at init - firmware, kernel image,
 *     framebuffer, ACPI, the bitmaps - was reserved WITHOUT ever being
 *     allocated, so its allocation bit is clear. Requiring both bits set
 *     therefore makes it structurally impossible to release any of them
 *     through this function, whatever reason the caller claims. The only
 *     frames that are both reserved and allocated are ones some subsystem
 *     obtained from pmm_alloc_page() and then reserved: page tables,
 *     kernel stacks, and the trampoline.
 *
 * THE CALLER'S REMAINING OBLIGATION. Reservation reasons are tracked in
 * aggregate, not per frame, so this function cannot verify that a
 * reserved-and-allocated frame was reserved as a page table rather than as
 * a kernel stack. The caller must have independently established that -
 * vmm.c does, because it only ever passes a physical address it just read
 * out of a page-table entry that it is clearing in the same operation, and
 * such an address is a page table by definition. That obligation is stated
 * here rather than left implicit. */
PmmResult pmm_release_reserved_page(uint64_t phys, PmmReserveReason why);

/* Query helpers - all O(1), read under the lock. */
uint64_t pmm_total_frames(void);      /* frames the bitmaps cover */
uint64_t pmm_usable_frames(void);     /* frames that are not reserved */
uint64_t pmm_free_frames(void);       /* usable and not currently allocated */
uint64_t pmm_allocated_frames(void);
uint64_t pmm_highest_address(void);   /* one past the last byte covered */

/* True if `phys` is permanently reserved. Used by the test suite to
 * assert that e.g. the kernel image and framebuffer really are
 * protected, rather than trusting that the reservation call happened. */
int pmm_is_reserved(uint64_t phys);

/* True if `phys` is currently allocated. */
int pmm_is_allocated(uint64_t phys);

/* Human-readable reservation reason, for diagnostics. */
const char *pmm_reserve_reason_name(PmmReserveReason why);

/* Human-readable PmmResult, for diagnostics. */
const char *pmm_result_name(PmmResult r);

/* --- BOOT-02A compatibility shims ---------------------------------- *
 * kernel_entry.c's existing diagnostic prints use these. They now
 * report GLOBAL figures rather than one bump arena's figures; the
 * wording at the call site was updated to match so the log does not
 * claim something the numbers do not mean. */
uint64_t pmm_arena_total_pages(void);
uint64_t pmm_arena_used_pages(void);

#endif /* VEXOS_PMM_H */
