/*
 * Vex OS - kernel/src/arch/x86_64/gdt/gdt.c
 */

#include "gdt.h"
#include "serial.h"
#include "percpu.h"

/* KERNEL-01 Phase 1: the GDT now carries one 16-byte TSS descriptor per
 * CPU, i.e. two 8-byte GdtEntry slots each, after the five fixed
 * null/code/data descriptors. See gdt.h for the selector arithmetic. */
static GdtEntry gdt[GDT_TOTAL_SLOTS];
static GdtPtr gdt_ptr;

/* One TSS per CPU. Sharing a TSS between CPUs is not merely unwise, it
 * is architecturally invalid (busy bit) and would mean two CPUs taking a
 * double fault onto the same stack. */
static Tss tss_percpu[GDT_MAX_CPUS];

/* One dedicated #DF stack per CPU. Distinctness is the whole point:
 * IST1 exists so a double fault lands on a stack that is known good
 * even when the interrupted stack is not, and that guarantee is void if
 * another CPU is using the same memory. */
static uint8_t df_stacks[GDT_MAX_CPUS][GDT_DF_STACK_SIZE]
    __attribute__((aligned(16)));

/* If these ever diverge, an AP with a legitimate percpu index could have
 * no TSS descriptor at all. Fail at compile time, not at `ltr`. */
_Static_assert(GDT_MAX_CPUS == PERCPU_MAX_CPUS,
               "GDT_MAX_CPUS must match PERCPU_MAX_CPUS");

/* The last TSS descriptor must fit inside the GDT array. */
_Static_assert(GDT_TSS_FIRST_SLOT + 2 * GDT_MAX_CPUS <= GDT_TOTAL_SLOTS,
               "GDT too small for GDT_MAX_CPUS TSS descriptors");

/* CPU 0's selector must still be the frozen BOOT-02A value, or the BSP's
 * observable behaviour has changed. */
_Static_assert(GDT_SEL_TSS_FOR(0) == GDT_SEL_TSS,
               "CPU 0 TSS selector must remain GDT_SEL_TSS (0x28)");

extern void gdt_flush(GdtPtr *ptr);
extern void tss_load(uint16_t selector);
extern uint16_t tss_read(void);

static void gdt_set_entry(int idx, uint32_t base, uint32_t limit,
                           uint8_t access, uint8_t gran)
{
    GdtEntry *e = &gdt[idx];
    e->limit_low = (uint16_t)(limit & 0xFFFF);
    e->base_low = (uint16_t)(base & 0xFFFF);
    e->base_mid = (uint8_t)((base >> 16) & 0xFF);
    e->access = access;
    e->granularity = (uint8_t)(((limit >> 16) & 0x0F) | (gran & 0xF0));
    e->base_high = (uint8_t)((base >> 24) & 0xFF);
}

static void tss_set_entry(int idx, uint64_t base, uint32_t limit)
{
    /* Occupies gdt[idx] and gdt[idx+1] as one 16-byte descriptor. */
    GdtTssEntry *e = (GdtTssEntry *)&gdt[idx];
    e->length = (uint16_t)(limit & 0xFFFF);
    e->base_low = (uint16_t)(base & 0xFFFF);
    e->base_mid = (uint8_t)((base >> 16) & 0xFF);
    e->access = 0x89; /* present, DPL0, type=0x9 (64-bit TSS, available) */
    e->granularity = (uint8_t)((limit >> 16) & 0x0F);
    e->base_high = (uint8_t)((base >> 24) & 0xFF);
    e->base_upper = (uint32_t)(base >> 32);
    e->reserved = 0;
}

void gdt_init(void)
{
    /* index 0: null */
    gdt_set_entry(0, 0, 0, 0, 0);

    /* index 1: kernel code, ring0. access=0x9A (present, DPL0,
     * code, executable, readable), gran=0xA0 (long-mode flag L=1,
     * limit unused in 64-bit mode). */
    gdt_set_entry(1, 0, 0, 0x9A, 0xA0);

    /* index 2: kernel data, ring0. access=0x92 (present, DPL0,
     * data, writable). */
    gdt_set_entry(2, 0, 0, 0x92, 0xA0);

    /* index 3: user code, ring3 (placeholder, unused until BOOT-04).
     * access=0xFA (present, DPL3, code, executable, readable). */
    gdt_set_entry(3, 0, 0, 0xFA, 0xA0);

    /* index 4: user data, ring3 (placeholder). access=0xF2. */
    gdt_set_entry(4, 0, 0, 0xF2, 0xA0);

    /* index 5 onward: one 16-byte TSS descriptor per CPU.
     *
     * All 32 are built here, on the BSP, before any AP exists. An AP
     * must never have to construct its own descriptor: it would be
     * writing into the same GDT the BSP and every other CPU is already
     * using, which is exactly the kind of concurrent mutation of shared
     * descriptor state that has no business existing before there is a
     * locking story. Building them all up front means the AP path is
     * read-only with respect to the GDT and needs no synchronization at
     * all. Descriptors for CPUs that never come online simply sit
     * unused, at a cost of 16 bytes each. */
    for (uint32_t i = 0; i < GDT_MAX_CPUS; i++) {
        Tss *t = &tss_percpu[i];

        uint8_t *p = (uint8_t *)t;
        for (uint64_t b = 0; b < sizeof(*t); b++) p[b] = 0;

        /* IST1 = top of THIS CPU's #DF stack. Stacks grow down on
         * x86_64, so the CPU wants the one-past-the-end address. The
         * array is 16-byte aligned and its size is a multiple of 16, so
         * the top is 16-byte aligned as the ABI expects. */
        t->ist1 = (uint64_t)(uintptr_t)(df_stacks[i] + GDT_DF_STACK_SIZE);

        /* No I/O permission bitmap: point iomap_base past the segment
         * limit, which the architecture defines as "no bitmap". */
        t->iomap_base = sizeof(Tss);

        /* rsp0 is deliberately left zero. It is only consulted on a
         * privilege-level transition into ring 0, and there is no ring 3
         * in this kernel yet. Filling it with a plausible-looking value
         * would be inventing readiness for a milestone that does not
         * exist. */

        tss_set_entry((int)(GDT_TSS_FIRST_SLOT + 2 * i),
                      (uint64_t)(uintptr_t)t, sizeof(Tss) - 1);
    }

    gdt_ptr.limit = (uint16_t)(sizeof(gdt) - 1);
    gdt_ptr.base = (uint64_t)(uintptr_t)&gdt;

    gdt_flush(&gdt_ptr);

    /* The BSP is CPU index 0, and GDT_SEL_TSS_FOR(0) == GDT_SEL_TSS, so
     * this is the identical instruction with the identical operand that
     * BOOT-02A executed here. Written via the per-CPU macro rather than
     * the legacy name so there is one source of truth for the mapping. */
    tss_load(GDT_SEL_TSS_FOR(0));
}

uint16_t gdt_read_cs(void)
{
    uint16_t cs;
    __asm__ volatile ("mov %%cs, %0" : "=r" (cs));
    return cs;
}

int gdt_load_on_this_cpu(uint32_t cpu_index)
{
    /* Same GDTR the BSP installed. The GDT is read-mostly data and is
     * safe to share; only the TSS it points at is per-CPU. */
    gdt_flush(&gdt_ptr);

    if (cpu_index >= GDT_MAX_CPUS) {
        /* No descriptor was ever built for this index. Loading the task
         * register with a selector past the GDT limit would #GP, and
         * guessing a different index would give this CPU another CPU's
         * IST stack - which is the precise bug the per-CPU stacks exist
         * to prevent. Refuse, and report the refusal. */
        return 0;
    }

    tss_load(GDT_SEL_TSS_FOR(cpu_index));

    /* Read the task register back rather than assuming the write took.
     * `ltr` on a bad descriptor faults instead of failing quietly, so in
     * practice this is belt-and-braces - but it costs one instruction and
     * turns "we issued ltr" into "the CPU is holding this selector". */
    return (tss_read() == GDT_SEL_TSS_FOR(cpu_index)) ? 1 : 0;
}

uint16_t gdt_read_tr(void)
{
    return tss_read();
}

const Tss *gdt_tss_for(uint32_t i)
{
    if (i >= GDT_MAX_CPUS) return 0;
    return &tss_percpu[i];
}

/* SECURITY-02: sets TSS.rsp0, the stack the CPU switches to on ANY
 * Ring 3 -> Ring 0 transition (interrupt, exception, int 0x80). gdt_init()
 * leaves it zero on purpose (see the comment there) because before Ring 3
 * existed nothing could consult it; once Ring 3 runs, a zero or stale
 * rsp0 means the first trap from Ring 3 pushes its frame at address 0 or
 * onto whatever memory the stale value points at - the privilege-switch
 * equivalent of a wild write. The hardware re-reads this field from
 * memory on every transition, so no `ltr` reload is needed after
 * changing it.
 *
 * Refuses (returns 0, changes nothing): CPU index out of range, a zero
 * value, a value not 16-byte aligned (the ABI requires the stack to be
 * 16-byte aligned at the point the handler's first push happens, and a
 * misaligned rsp0 shifts every later movaps-style access), and a
 * non-canonical address (the CPU would #GP on the very switch this value
 * exists to serve, turning the first Ring 3 trap into a #DF). */
int gdt_set_rsp0(uint32_t cpu_index, uint64_t rsp0)
{
    if (cpu_index >= GDT_MAX_CPUS) return 0;
    if (rsp0 == 0 || (rsp0 & 0xF) != 0) return 0;
    uint64_t top17 = rsp0 >> 47;
    if (top17 != 0 && top17 != 0x1FFFF) return 0;   /* non-canonical */
    tss_percpu[cpu_index].rsp0 = rsp0;
    __atomic_thread_fence(__ATOMIC_RELEASE);
    return 1;
}

uint64_t gdt_ist1_for(uint32_t i)
{
    if (i >= GDT_MAX_CPUS) return 0;
    return tss_percpu[i].ist1;
}

uint64_t gdt_tss_descriptor_base(uint32_t i)
{
    if (i >= GDT_MAX_CPUS) return 0;

    const GdtTssEntry *e =
        (const GdtTssEntry *)&gdt[GDT_TSS_FIRST_SLOT + 2 * i];

    /* Reassemble the base exactly the way the CPU does, from the
     * descriptor's own bytes. */
    return ((uint64_t)e->base_low)
         | ((uint64_t)e->base_mid   << 16)
         | ((uint64_t)e->base_high  << 24)
         | ((uint64_t)e->base_upper << 32);
}

uint8_t gdt_tss_descriptor_access(uint32_t i)
{
    if (i >= GDT_MAX_CPUS) return 0;

    const GdtTssEntry *e =
        (const GdtTssEntry *)&gdt[GDT_TSS_FIRST_SLOT + 2 * i];
    return e->access;
}

uint64_t gdt_percpu_footprint_bytes(void)
{
    return (uint64_t)sizeof(tss_percpu) + (uint64_t)sizeof(df_stacks);
}
