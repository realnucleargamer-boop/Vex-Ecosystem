/*
 * crystal_kernel.c - the ONLY kernel-specific part of the native Crystal integration (CRYSTAL-NATIVE-01).
 * See kernel/include/crystal_kernel.h and docs/CRYSTAL-NATIVE-01.md.
 *
 * Responsibilities: own the static model/scratch, open + CRC-verify the embedded model once (lazily, on first use, and
 * report how long that took), refuse re-entrant use, translate core status codes into honest terminal text, and run the
 * in-kernel selftest. It never prints the user's input to the serial log (only lengths and results).
 */
#include "crystal_kernel.h"
#include "crystal_core.h"
#include "crystal_kat.h"
#include "serial.h"
#include "apps.h"

extern const uint8_t crystal_model_blob_start[];
extern const uint8_t crystal_model_blob_end[];

static VxcModel  km;
static VxcScratch ks;
static int       kstate;          /* 0 = not opened yet, 1 = ready, -1 = model rejected */
static int       kbusy;           /* re-entrancy guard: the scratch is shared */
static uint64_t  open_ms;
static uint32_t  n_ok, n_err;

/* ---- tiny string helpers (no libc) ---- */
static size_t kslen(const char *s) { size_t n = 0; while (s[n]) n++; return n; }
static int kseq(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return *a == *b; }
typedef struct { char b[160]; size_t n; } Line;
static void lc_(Line *l, char c) { if (l->n + 1 < sizeof l->b) { l->b[l->n++] = c; l->b[l->n] = 0; } }
static void ls_(Line *l, const char *s) { while (*s) lc_(l, *s++); }
static void ld_(Line *l, int64_t v) { char t[24]; int k = 0; uint64_t u = v < 0 ? (uint64_t)0 - (uint64_t)v : (uint64_t)v; if (v < 0) lc_(l, '-'); do { t[k++] = (char)('0' + (int)(u % 10u)); u /= 10u; } while (u && k < 23); while (k) lc_(l, t[--k]); }
static void line_init(Line *l) { l->n = 0; l->b[0] = 0; }

static int ensure_ready(void)
{
    if (kstate != 0) return kstate;
    uint64_t t0 = apps_now_ms();
    int rc = vxc_model_open(&km, crystal_model_blob_start, (size_t)(crystal_model_blob_end - crystal_model_blob_start), 1);
    open_ms = apps_now_ms() - t0;
    kstate = (rc == VXC_OK) ? 1 : -1;
    serial_puts(kstate == 1 ? "[ai] crystal model opened and CRC-verified: " : "[ai] crystal model REJECTED: ");
    serial_put_dec64((uint64_t)(crystal_model_blob_end - crystal_model_blob_start)); serial_puts(" bytes, ");
    serial_put_dec64(open_ms); serial_puts(" ms\n");
    return kstate;
}

/* returns VXC_* status, or 100 = busy, 101 = model unavailable */
static int do_infer(const char *text, size_t len, char *out, size_t cap, VxcResult *r)
{
    if (__atomic_exchange_n(&kbusy, 1, __ATOMIC_ACQUIRE)) return 100;
    int rc = 101;
    if (ensure_ready() == 1) rc = vxc_infer(&km, &ks, text, len, r, out, cap);
    __atomic_store_n(&kbusy, 0, __ATOMIC_RELEASE);
    if (rc == VXC_OK) n_ok++; else n_err++;
    return rc;
}

static const char *status_text(int rc)
{
    switch (rc) {
    case VXC_E_ARG:      return "Rejected: invalid arguments.";
    case VXC_E_TOO_LONG: return "Rejected: input is longer than 256 bytes.";
    case VXC_E_CHARSET:  return "Rejected: only printable ASCII (letters, digits, punctuation, space) is supported.";
    case 100:            return "Crystal is busy with another request; try again.";
    case 101:            return "Crystal model unavailable: the embedded model failed validation (see serial log).";
    default:             return "Crystal failed.";
    }
}

static const char *src_text(int s) { return s == VXC_SRC_NEURAL ? "trained network" : s == VXC_SRC_REJECTED ? "network below reject gate / vetoed" : "pre-filter (no network run)"; }
static const char *handler_text(int h) { return h == VXC_H_MATH ? "arithmetic specialist" : h == VXC_H_NOT_IMPL ? "no native handler for this intent" : h == VXC_H_UNSUPPORTED ? "outside native arithmetic subset" : "boundary message"; }

int crystal_kernel_ask(const char *text, size_t len, char *out, size_t cap)
{
    VxcResult r;
    int rc = do_infer(text, len, out, cap, &r);
    if (rc == VXC_OK) return (int)kslen(out);
    return rc == 100 ? -100 : rc == 101 ? -101 : rc;
}

/* ---------------------------------------------------------------- selftest */
static int kat_pass(const CrystalKat *k, const char **why)
{
    char out[320]; VxcResult r; size_t len = kslen(k->in);
    int rc = do_infer(k->in, len, out, sizeof out, &r);
    if (rc != VXC_OK) { *why = "status"; return 0; }
    if (r.source != k->source) { *why = "source"; return 0; }
    if (r.intent != k->intent) { *why = "intent"; return 0; }
    if (k->source == VXC_SRC_NEURAL) { int d = r.confidence - k->conf; if (d < -1 || d > 1) { *why = "confidence"; return 0; } }
    if (r.handler != k->handler) { *why = "handler"; return 0; }
    if (k->text && !kseq(out, k->text)) { *why = "text"; return 0; }
    return 1;
}

static void selftest(crystal_emit_fn emit)
{
    int pass = 0, total = 0; Line l; const char *why = "";
    emit("Crystal in-kernel selftest: known answers taken from the Python engine, then boundary/hostile cases.");
    for (int i = 0; i < CRYSTAL_KAT_N; i++) {
        int ok = kat_pass(&crystal_kat[i], &why); total++; pass += ok;
        line_init(&l); ls_(&l, ok ? "PASS  known-answer #" : "FAIL  known-answer #"); ld_(&l, i + 1); if (!ok) { ls_(&l, " ("); ls_(&l, why); ls_(&l, ")"); }
        emit(l.b);
    }
    /* boundary cases: each must be refused with the right status and must not touch the output buffer */
    static char big[300]; for (int i = 0; i < 299; i++) big[i] = 'a'; big[299] = 0;
    char out[64]; VxcResult r; int rc;
    struct { const char *name; int want; } bc[8]; int nb = 0; int got[8];
    for (int i = 0; i < 64; i++) out[i] = 'Z';
    got[nb] = do_infer(big, 257, out, sizeof out, &r); bc[nb].name = "257-byte input -> too long"; bc[nb].want = VXC_E_TOO_LONG; nb++;
    got[nb] = do_infer(big, 256, out, sizeof out, &r); bc[nb].name = "256-byte input accepted"; bc[nb].want = VXC_OK; nb++;
    for (int i = 0; i < 64; i++) out[i] = 'Z';
    got[nb] = do_infer("caf\xC3\xA9", 5, out, sizeof out, &r); bc[nb].name = "non-ASCII byte -> charset error"; bc[nb].want = VXC_E_CHARSET; nb++;
    got[nb] = do_infer("a\x01" "b", 3, out, sizeof out, &r); bc[nb].name = "control byte 0x01 -> charset error"; bc[nb].want = VXC_E_CHARSET; nb++;
    got[nb] = do_infer(0, 5, out, sizeof out, &r); bc[nb].name = "NULL text with length -> arg error"; bc[nb].want = VXC_E_ARG; nb++;
    got[nb] = do_infer("hello", 5, out, 0, &r); bc[nb].name = "zero-size output buffer -> arg error"; bc[nb].want = VXC_E_ARG; nb++;
    for (int i = 0; i < nb; i++) {
        int ok = got[i] == bc[i].want; total++; pass += ok;
        line_init(&l); ls_(&l, ok ? "PASS  " : "FAIL  "); ls_(&l, bc[i].name); if (!ok) { ls_(&l, " (got "); ld_(&l, got[i]); ls_(&l, ")"); } emit(l.b);
    }
    { int ok = 1; for (int i = 0; i < 64; i++) out[i] = 'Z';                      /* rejected calls must not have written to out */
      do_infer("caf\xC3\xA9", 5, out, sizeof out, &r); for (int i = 0; i < 64; i++) if (out[i] != 'Z') ok = 0;
      total++; pass += ok; emit(ok ? "PASS  rejected call left the output buffer untouched" : "FAIL  rejected call modified the output buffer"); }
    { char tb[16]; for (int i = 0; i < 16; i++) tb[i] = (char)0xAA;               /* truncation: cap 8 -> at most 7 chars + NUL, guard intact, flag set */
      rc = do_infer("what is 12 plus 30", 18, tb, 8, &r);
      int ok = rc == VXC_OK && r.truncated == 1 && tb[7] == 0 && tb[8] == (char)0xAA && tb[15] == (char)0xAA;
      total++; pass += ok; emit(ok ? "PASS  8-byte output buffer: truncated + NUL-terminated, bytes after the buffer untouched" : "FAIL  output buffer containment"); }
    { VxcModel t; size_t len = (size_t)(crystal_model_blob_end - crystal_model_blob_start);     /* model validation must refuse bad blobs */
      int a = vxc_model_open(&t, crystal_model_blob_start, len - 1, 0), b = vxc_model_open(&t, crystal_model_blob_start, 40, 0), c = vxc_model_open(&t, 0, 0, 0);
      int ok = a == VXC_E_MODEL && b == VXC_E_MODEL && c == VXC_E_MODEL; total++; pass += ok;
      emit(ok ? "PASS  model validation refuses a truncated blob, a header-only blob and NULL" : "FAIL  model validation"); }
    line_init(&l); ls_(&l, "Crystal selftest: "); ld_(&l, pass); lc_(&l, '/'); ld_(&l, total); ls_(&l, pass == total ? " PASS" : " FAIL"); emit(l.b);
    serial_puts("[ai] selftest: "); serial_put_dec64((uint64_t)pass); serial_puts("/"); serial_put_dec64((uint64_t)total); serial_puts(pass == total ? " PASS\n" : " FAIL\n");
}

/* ---------------------------------------------------------------- terminal entry point */
void crystal_kernel_term(const char *arg, crystal_emit_fn emit)
{
    if (!arg || !emit) return;
    while (*arg == ' ') arg++;
    size_t len = kslen(arg);
    Line l;
    if (len == 0) {
        emit("VEX AI 1.5-Crystal (native). Usage: v. ai <text>   |   v. ai /status   |   v. ai /selftest");
        emit("What runs: the trained 2048-256-64 intent network, its reject gate, and a two-number arithmetic specialist.");
        emit("Try: v. ai what is 12 plus 30   |   v. ai 7 / 2   |   v. ai hello");
        emit("Not implemented natively: code templates, wiki retrieval, memory/history, rule layer. It is NOT a chat LLM.");
        return;
    }
    if (kseq(arg, "/status")) {
        int st = ensure_ready();
        line_init(&l); ls_(&l, "Model: "); ls_(&l, st == 1 ? "loaded and CRC-verified" : "REJECTED"); ls_(&l, " (embedded VXCR v1, "); ld_(&l, (int64_t)(crystal_model_blob_end - crystal_model_blob_start)); ls_(&l, " bytes)"); emit(l.b);
        if (st == 1) { line_init(&l); ls_(&l, "Network: "); ld_(&l, km.feat); ls_(&l, " features -> "); ld_(&l, km.hidden); ls_(&l, " hidden (ReLU) -> "); ld_(&l, km.nint); ls_(&l, " intents; reject gate prob >= "); ld_(&l, (int64_t)(((uint64_t)km.reject_q * 1000u) >> 30)); ls_(&l, "/1000"); emit(l.b); }
        line_init(&l); ls_(&l, "Open+verify took "); ld_(&l, (int64_t)open_ms); ls_(&l, " ms; scratch "); ld_(&l, (int64_t)sizeof(VxcScratch)); ls_(&l, " bytes (static, no heap); requests ok/refused: "); ld_(&l, n_ok); lc_(&l, '/'); ld_(&l, n_err); emit(l.b);
        emit("Runs INSIDE the kernel at Ring 0 with no process isolation (temporary; a Ring 3 service does not exist yet). Integer math only.");
        return;
    }
    if (kseq(arg, "/selftest")) { selftest(emit); return; }

    char out[512]; VxcResult r; uint64_t t0 = apps_now_ms();
    int rc = do_infer(arg, len, out, sizeof out, &r);
    uint64_t ms = apps_now_ms() - t0;
    serial_puts("[ai] v. ai: input "); serial_put_dec64((uint64_t)len); serial_puts(" bytes, status "); serial_put_dec64((uint64_t)(rc < 0 ? 0 : rc)); serial_puts(rc < 0 ? " (rejected)" : " (ok)");
    if (rc == VXC_OK) { serial_puts(", intent "); serial_put_dec64((uint64_t)(r.intent < 0 ? 0 : r.intent)); serial_puts(", conf "); serial_put_dec64((uint64_t)r.confidence); serial_puts("/1000, "); serial_put_dec64(ms); serial_puts(" ms"); }
    serial_puts("\n");
    if (rc != VXC_OK) { emit(status_text(rc)); return; }
    line_init(&l); ls_(&l, "[Crystal] ");
    if (r.intent >= 0) { ls_(&l, "intent "); ld_(&l, r.intent); ls_(&l, " "); ls_(&l, vxc_intent_label(&km, r.intent)); ls_(&l, " ("); ls_(&l, vxc_intent_family(&km, r.intent)); ls_(&l, "), confidence "); ld_(&l, r.confidence); ls_(&l, "/1000, "); }
    ls_(&l, "decided by: "); ls_(&l, src_text(r.source)); ls_(&l, "; answered by: "); ls_(&l, handler_text(r.handler)); ls_(&l, "; "); ld_(&l, (int64_t)ms); ls_(&l, " ms");
    emit(l.b);
    emit(out);
    if (r.truncated) emit("(reply truncated to fit the output buffer)");
}
