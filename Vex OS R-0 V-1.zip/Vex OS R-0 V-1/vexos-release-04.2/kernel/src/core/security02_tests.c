/*
 * Vex OS - kernel/src/core/security02_tests.c
 *
 * SECURITY-02 validation suite. See security02_tests.h.
 *
 * Method, as in SECURITY-01: assertions are made against LIVE hardware
 * state (the real GDT/IDT/TSS contents via sgdt/sidt/str, the real page
 * tables via vmm_query, the real vector and error code a Ring 3 fault
 * produced) - not against the intentions of the code that built them.
 * Negative tests assert WHY something was refused (an enumerated reason
 * or a decoded error code), because "rejected for the wrong reason" is a
 * bug that a bare pass/fail would hide.
 */

#include "security02_tests.h"
#include "ring3.h"
#include "vmm.h"
#include "gdt.h"
#include "idt.h"
#include "secure.h"
#include "percpu.h"
#include "serial.h"
#include "bootinfo.h"
#include "gfx/fb.h"
#include "gfx/draw.h"
#include "gfx/text.h"

/* ------------------------------------------------------------------ */
/* Check bookkeeping                                                   */
/* ------------------------------------------------------------------ */

typedef enum {
    A_GFX, A_KMEM, A_GDT, A_UAS, A_TRANS, A_SYSC, A_UPTR, A_KISO, A_FAULT,
    A_COUNT
} Area;

static const char *const area_name[A_COUNT] = {
    "Graphics audit",
    "kernel memory audit",
    "GDT/TSS Ring 3 foundation",
    "user address space",
    "Ring 3 transition",
    "syscall boundary",
    "user pointer validation",
    "kernel isolation",
    "fault isolation"
};

static uint32_t a_run[A_COUNT], a_fail[A_COUNT];
static uint32_t g_id, g_run, g_fail;

static void put3(uint32_t v)
{
    serial_putc((char)('0' + (v / 100) % 10));
    serial_putc((char)('0' + (v / 10) % 10));
    serial_putc((char)('0' + v % 10));
}

static int check(Area a, const char *purpose, int ok)
{
    g_id++; g_run++; a_run[a]++;
    if (!ok) { g_fail++; a_fail[a]++; }
    serial_puts("SECURITY-02-");
    put3(g_id);
    serial_puts(ok ? " PASS - " : " FAIL - ");
    serial_puts(purpose);
    serial_puts("\n");
    return ok;
}

/* ------------------------------------------------------------------ */
/* Graphics audit fixtures                                             */
/* ------------------------------------------------------------------ */

#define FBW    64
#define FBH    40
#define GUARD  128
#define CANARY 0xDEADBEEFu

static uint32_t g_gmem[GUARD + FBW * FBH + GUARD];
static BootInfo g_bi;
static GfxFb    g_fb;
static char     g_long[5000];

static uint32_t *gwords(void) { return &g_gmem[GUARD]; }

static void gmem_reset(void)
{
    for (uint32_t i = 0; i < GUARD; i++) g_gmem[i] = CANARY;
    for (uint32_t i = 0; i < (uint32_t)FBW * FBH; i++) gwords()[i] = 0;
    for (uint32_t i = 0; i < GUARD; i++) g_gmem[GUARD + FBW * FBH + i] = CANARY;
}

static int guards_intact(void)
{
    for (uint32_t i = 0; i < GUARD; i++) {
        if (g_gmem[i] != CANARY) return 0;
        if (g_gmem[GUARD + FBW * FBH + i] != CANARY) return 0;
    }
    return 1;
}

static uint32_t changed_pixels(void)
{
    uint32_t n = 0;
    for (uint32_t i = 0; i < (uint32_t)FBW * FBH; i++) if (gwords()[i] != 0) n++;
    return n;
}

static void zero_bytes(void *p, uint64_t n)
{
    volatile uint8_t *b = (volatile uint8_t *)p;
    for (uint64_t i = 0; i < n; i++) b[i] = 0;
}

static void make_bi(void)
{
    zero_bytes(&g_bi, sizeof g_bi);
    g_bi.framebuffer_addr         = (uint64_t)(uintptr_t)gwords();
    g_bi.framebuffer_size         = (uint64_t)FBW * FBH * 4;
    g_bi.framebuffer_width        = FBW;
    g_bi.framebuffer_height       = FBH;
    g_bi.framebuffer_pitch        = FBW * 4;
    g_bi.framebuffer_bpp          = 32;
    g_bi.framebuffer_pixel_format = VEX_PIXEL_FORMAT_RGBX8;
}

static int init_ok(void) { make_bi(); return gfx_fb_init(&g_fb, &g_bi); }

/* Re-initialise with one field mutated; returns what gfx_fb_init said. */
static int init_with(void (*mutate)(void))
{
    make_bi();
    mutate();
    return gfx_fb_init(&g_fb, &g_bi);
}
static void m_addr0(void)    { g_bi.framebuffer_addr = 0; }
static void m_size0(void)    { g_bi.framebuffer_size = 0; }
static void m_w0(void)       { g_bi.framebuffer_width = 0; }
static void m_h0(void)       { g_bi.framebuffer_height = 0; }
static void m_bpp24(void)    { g_bi.framebuffer_bpp = 24; }
static void m_pitch3(void)   { g_bi.framebuffer_pitch = FBW * 4 + 3; }
static void m_pitch_small(void) { g_bi.framebuffer_pitch = (FBW - 8) * 4; }  /* < width*4 */
static void m_size_small(void)  { g_bi.framebuffer_size = (uint64_t)FBW * FBH * 4 - 4; }
static void m_huge_dims(void) {
    g_bi.framebuffer_width = 70000; g_bi.framebuffer_height = 70000;
    g_bi.framebuffer_pitch = 70000 * 4; g_bi.framebuffer_size = 70000ULL * 70000 * 4;
}
static void m_span_4g(void) {
    /* Passes every other check (size is claimed huge) but spans > 4 GiB. */
    g_bi.framebuffer_width = 60000; g_bi.framebuffer_height = 60000;
    g_bi.framebuffer_pitch = 60000 * 4; g_bi.framebuffer_size = 1ULL << 40;
}
static void m_fmt_bitmask(void) { g_bi.framebuffer_pixel_format = VEX_PIXEL_FORMAT_BITMASK; }

static void test_graphics(void)
{
    const GfxColor W = gfx_rgb(0xFF, 0xFF, 0xFF);
    uint32_t n;

    gmem_reset();
    check(A_GFX, "valid framebuffer metadata is accepted (positive control)", init_ok());

    /* --- metadata validation: every malformed shape must be REFUSED --- */
    check(A_GFX, "reject framebuffer_addr == 0",            init_with(m_addr0) == 0);
    check(A_GFX, "reject framebuffer_size == 0",            init_with(m_size0) == 0);
    check(A_GFX, "reject width == 0",                       init_with(m_w0) == 0);
    check(A_GFX, "reject height == 0",                      init_with(m_h0) == 0);
    check(A_GFX, "reject bytes-per-pixel other than 32bpp", init_with(m_bpp24) == 0);
    check(A_GFX, "reject pitch not a multiple of 4",        init_with(m_pitch3) == 0);
    check(A_GFX, "reject pitch smaller than width*4 (rows would alias)", init_with(m_pitch_small) == 0);
    check(A_GFX, "reject framebuffer_size smaller than pitch*height",    init_with(m_size_small) == 0);
    check(A_GFX, "reject implausibly large dimensions",     init_with(m_huge_dims) == 0);
    check(A_GFX, "reject a span over 4 GiB even when size claims to cover it", init_with(m_span_4g) == 0);
    check(A_GFX, "reject unsupported pixel format (BITMASK)", init_with(m_fmt_bitmask) == 0);

    /* --- failed init leaves a descriptor that clips everything --- */
    check(A_GFX, "failed init zeroes the descriptor (no stale pointer/dimensions)",
          g_fb.ok == 0 && g_fb.pixels == 0 && g_fb.width == 0 && g_fb.height == 0);
    gmem_reset();
    gfx_fill_rect(&g_fb, 0, 0, 10, 10, W);
    gfx_put(&g_fb, 1, 1, W);
    gfx_clear(&g_fb, W);
    check(A_GFX, "drawing through a failed-init descriptor changes nothing",
          changed_pixels() == 0 && guards_intact());

    /* repeated initialisation */
    check(A_GFX, "repeated successful init is idempotent", init_ok() && init_ok() && g_fb.ok == 1);
    check(A_GFX, "good init after a failed one fully recovers",
          init_with(m_w0) == 0 && init_ok() && g_fb.width == FBW && g_fb.height == FBH);

    /* --- rectangles --- */
    gmem_reset(); init_ok();
    gfx_fill_rect(&g_fb, 5, 5, 0, 10, W);
    gfx_fill_rect(&g_fb, 5, 5, 10, 0, W);
    check(A_GFX, "zero-sized rectangles draw nothing", changed_pixels() == 0 && guards_intact());

    gfx_fill_rect(&g_fb, 5, 5, -10, 10, W);
    gfx_fill_rect(&g_fb, 5, 5, 10, -10, W);
    gfx_fill_rect(&g_fb, 5, 5, INT32_MIN, INT32_MIN, W);
    check(A_GFX, "negative width/height rectangles draw nothing", changed_pixels() == 0 && guards_intact());

    gfx_fill_rect(&g_fb, -1000, -1000, 10, 10, W);
    gfx_fill_rect(&g_fb, FBW, 0, 10, 10, W);
    gfx_fill_rect(&g_fb, 0, FBH, 10, 10, W);
    gfx_fill_rect(&g_fb, 100, 100, 5, 5, W);
    check(A_GFX, "rectangles beginning outside the framebuffer draw nothing", changed_pixels() == 0 && guards_intact());

    gfx_fill_rect(&g_fb, -5, -5, 1000, 1000, W);
    check(A_GFX, "rectangle larger than the framebuffer clips to exactly the framebuffer",
          changed_pixels() == (uint32_t)FBW * FBH && guards_intact());

    gmem_reset();
    gfx_fill_rect(&g_fb, INT32_MAX, INT32_MAX, INT32_MAX, INT32_MAX, W);
    gfx_fill_rect(&g_fb, INT32_MAX - 3, 0, INT32_MAX, 5, W);
    gfx_fill_rect(&g_fb, 0, INT32_MAX - 3, 5, INT32_MAX, W);
    gfx_fill_rect(&g_fb, INT32_MIN, INT32_MIN, INT32_MAX, INT32_MAX, W);
    check(A_GFX, "maximum integer coordinates and dimensions (x+w would wrap in int32) draw nothing and write nothing out of bounds",
          changed_pixels() == 0 && guards_intact());

    gmem_reset();
    gfx_fill_rect(&g_fb, -10, 0, INT32_MAX, 1, W);
    n = changed_pixels();
    check(A_GFX, "huge width from a negative origin clips to exactly one full row",
          n == FBW && guards_intact());

    gmem_reset();
    gfx_rect_outline(&g_fb, INT32_MIN, INT32_MIN, INT32_MAX, INT32_MAX, W);
    gfx_rect_outline(&g_fb, INT32_MAX - 1, INT32_MAX - 1, INT32_MAX, INT32_MAX, W);
    gfx_rect_outline(&g_fb, 0, 0, INT32_MAX, INT32_MAX, W);
    check(A_GFX, "outline with extreme geometry stays inside the framebuffer", guards_intact());

    gmem_reset();
    gfx_rect_outline(&g_fb, 2, 2, 10, 8, W);
    check(A_GFX, "outline of a normal rectangle draws its perimeter (positive control: 2*(10+8)-4 = 32 px)",
          changed_pixels() == 32 && guards_intact());

    /* --- pixel get/put --- */
    gmem_reset();
    gfx_put(&g_fb, -1, 0, W); gfx_put(&g_fb, 0, -1, W);
    gfx_put(&g_fb, FBW, 0, W); gfx_put(&g_fb, 0, FBH, W);
    gfx_put(&g_fb, INT32_MAX, INT32_MAX, W); gfx_put(&g_fb, INT32_MIN, INT32_MIN, W);
    check(A_GFX, "out-of-range gfx_put is a no-op", changed_pixels() == 0 && guards_intact());

    gfx_put(&g_fb, 3, 3, W);
    GfxColor in = gfx_get(&g_fb, 3, 3);
    GfxColor o1 = gfx_get(&g_fb, -1, -1), o2 = gfx_get(&g_fb, FBW, 0),
             o3 = gfx_get(&g_fb, 0, FBH), o4 = gfx_get(&g_fb, INT32_MAX, INT32_MAX),
             o5 = gfx_get(&g_fb, INT32_MIN, 0);
    check(A_GFX, "gfx_get: in-range read returns the pixel (positive control)", in.r == 0xFF && in.g == 0xFF && in.b == 0xFF);
    check(A_GFX, "gfx_get: out-of-range read returns black instead of reading outside the framebuffer (was an unchecked OOB read)",
          o1.r == 0 && o2.r == 0 && o3.r == 0 && o4.r == 0 && o5.r == 0 &&
          o1.g == 0 && o4.b == 0);

    /* --- NULL / ok == 0 --- */
    gmem_reset();
    gfx_fill_rect(0, 0, 0, 10, 10, W);
    gfx_put(0, 1, 1, W);
    gfx_clear(0, W);
    GfxColor nz = gfx_get(0, 0, 0);
    gfx_draw_char(0, 0, 0, 'A', W, W);
    gfx_draw_str(0, 0, 0, "x", W, W);
    check(A_GFX, "NULL framebuffer descriptor is refused by every primitive",
          nz.r == 0 && changed_pixels() == 0 && guards_intact());

    init_ok();
    GfxFb bad = g_fb; bad.ok = 0;
    gfx_fill_rect(&bad, 0, 0, FBW, FBH, W);
    gfx_clear(&bad, W);
    gfx_put(&bad, 2, 2, W);
    gfx_draw_str(&bad, 0, 0, "hello", W, W);
    check(A_GFX, "descriptor with ok == 0 is refused by every primitive", changed_pixels() == 0 && guards_intact());

    GfxFb nullpix = g_fb; nullpix.pixels = 0;
    gfx_put(&nullpix, 2, 2, W);
    check(A_GFX, "descriptor with NULL pixels pointer does not dereference it", guards_intact());

    /* --- text --- */
    gmem_reset(); init_ok();
    for (int i = 0; i < 4999; i++) g_long[i] = 'A';
    g_long[4999] = 0;
    int32_t endx = gfx_draw_str(&g_fb, 0, 0, g_long, W, W);
    check(A_GFX, "oversized string is bounded (4999-char string, no unbounded loop, no OOB write)",
          guards_intact() && endx > 0);

    gmem_reset();
    int32_t e2 = gfx_draw_str(&g_fb, INT32_MAX - 10, 0, "hello world", W, W);
    int32_t e3 = gfx_draw_str(&g_fb, INT32_MIN, INT32_MIN, "hello", W, W);
    check(A_GFX, "text pen at INT32 extremes neither overflows nor writes out of bounds",
          guards_intact() && e2 <= INT32_MAX && e3 >= INT32_MIN);

    gmem_reset();
    gfx_draw_str(&g_fb, 0, 0, 0, W, W);
    gfx_draw_str_right(&g_fb, 10, 0, 0, W, W);
    gfx_draw_str_right(&g_fb, INT32_MIN, 0, g_long, W, W);
    check(A_GFX, "NULL string and right-aligned oversized string are handled safely", guards_intact());

    gmem_reset();
    const char hostile[] = { (char)0xFF, (char)0x80, 0x01, 0x7F, (char)0xC3, 'A', 0 };
    gfx_draw_str(&g_fb, 0, 0, hostile, W, W);
    check(A_GFX, "out-of-range / negative char values index the font safely (map to space)", guards_intact());

    /* --- circle --- */
    gmem_reset();
    gfx_circle(&g_fb, 20, 20, INT32_MAX, W);
    gfx_circle(&g_fb, INT32_MAX, INT32_MIN, 100000, W);
    check(A_GFX, "circle with an overflow-sized radius is refused", changed_pixels() == 0 && guards_intact());
    gfx_circle(&g_fb, 20, 20, 5, W);
    check(A_GFX, "circle of normal radius draws (positive control)", changed_pixels() > 0 && guards_intact());
    gmem_reset();
    gfx_circle(&g_fb, -3, -3, 8, W);
    gfx_circle(&g_fb, FBW + 3, FBH + 3, 8, W);
    check(A_GFX, "circle straddling the edge is clipped", guards_intact());

    /* --- console --- */
    gmem_reset(); init_ok();
    GfxConsole con;
    check(A_GFX, "console whose area exceeds the framebuffer is refused (scroll blit was unchecked)",
          gfx_console_init(&con, &g_fb, 0, 0, FBW + 8, FBH, W, W) == 0 &&
          gfx_console_init(&con, &g_fb, 0, 0, FBW, FBH + 16, W, W) == 0 &&
          gfx_console_init(&con, &g_fb, -4, 0, 16, 16, W, W) == 0 &&
          gfx_console_init(&con, &g_fb, FBW - 8, FBH - 16, 64, 64, W, W) == 0);
    gmem_reset();
    check(A_GFX, "console wholly inside the framebuffer is accepted (positive control)",
          gfx_console_init(&con, &g_fb, 0, 0, FBW, 32, W, W) == 1);
    /* 8 cols x 2 rows; this forces several scrolls. */
    for (int i = 0; i < 100; i++) gfx_console_putc(&con, (char)('a' + i % 26));
    gfx_console_puts(&con, "\n\n\n\n");
    gfx_console_put_i64(&con, INT64_MIN);
    gfx_console_put_i64(&con, INT64_MAX);
    check(A_GFX, "console scrolling stays inside the framebuffer (incl. INT64_MIN formatting)", guards_intact());

    /* --- selftest still sound on a good descriptor --- */
    gmem_reset(); init_ok();
    check(A_GFX, "gfx_fb_selftest round-trip passes on a validated descriptor", gfx_fb_selftest(&g_fb) == 1);
}

/* ------------------------------------------------------------------ */
/* Kernel / privilege audit                                            */
/* ------------------------------------------------------------------ */

struct __attribute__((packed)) Dtr { uint16_t limit; uint64_t base; };

static uint8_t gdt_byte(uint16_t sel, uint32_t off)
{
    struct Dtr d; __asm__ volatile ("sgdt %0" : "=m"(d));
    return *(volatile uint8_t *)(uintptr_t)(d.base + (sel & ~7u) + off);
}

static void test_gdt_idt_tss(void)
{
    /* Access byte bits: 7 P, 6:5 DPL, 4 S, 3 executable. Flags byte (offset 6) bit 5 = L. */
    uint8_t kc = gdt_byte(GDT_SEL_KERNEL_CODE, 5), kd = gdt_byte(GDT_SEL_KERNEL_DATA, 5);
    uint8_t uc = gdt_byte(GDT_SEL_USER_CODE, 5),   ud = gdt_byte(GDT_SEL_USER_DATA, 5);
    uint8_t ucf = gdt_byte(GDT_SEL_USER_CODE, 6);

    check(A_GDT, "kernel code/data descriptors are DPL 0",
          ((kc >> 5) & 3) == 0 && ((kd >> 5) & 3) == 0 && (kc & 0x80) && (kd & 0x80));
    check(A_GDT, "user code/data descriptors are present and DPL 3",
          ((uc >> 5) & 3) == 3 && ((ud >> 5) & 3) == 3 && (uc & 0x80) && (ud & 0x80));
    check(A_GDT, "user code is executable + 64-bit (L); user data is not executable",
          (uc & 0x08) && (ucf & 0x20) && !(ud & 0x08));
    check(A_GDT, "user selectors carry RPL 3 and index the descriptors verified above (0x1B/0x23)",
          GDT_SEL_USER_CODE == 0x1B && GDT_SEL_USER_DATA == 0x23 &&
          (GDT_SEL_USER_CODE & 3) == 3 && (GDT_SEL_USER_DATA & 3) == 3);

    uint16_t tr; __asm__ volatile ("str %0" : "=r"(tr));
    uint8_t tacc = gdt_byte(tr, 5);
    check(A_GDT, "TSS descriptor is present, DPL 0 (Ring 3 cannot load it), type = 64-bit TSS",
          (tacc & 0x80) && ((tacc >> 5) & 3) == 0 && ((tacc & 0x0F) == 0x9 || (tacc & 0x0F) == 0xB));

    const Tss *t = gdt_tss_for(0);
    check(A_GDT, "TSS.rsp0 points at the dedicated Ring 3 kernel stack (nonzero, 16-aligned)",
          t && t->rsp0 == ring3_kernel_stack_top() && t->rsp0 != 0 && (t->rsp0 & 0xF) == 0);
    check(A_GDT, "TSS.ist1 (double-fault stack) is still set", t && t->ist1 != 0);

    uint64_t keep = t ? t->rsp0 : 0;
    int r1 = gdt_set_rsp0(0, 0), r2 = gdt_set_rsp0(0, keep + 1),
        r3 = gdt_set_rsp0(0, 0x0001000000000000ULL), r4 = gdt_set_rsp0(GDT_MAX_CPUS + 5, keep);
    check(A_GDT, "gdt_set_rsp0 refuses zero, misaligned, non-canonical, and out-of-range-CPU values, leaving rsp0 intact",
          r1 == 0 && r2 == 0 && r3 == 0 && r4 == 0 && gdt_tss_for(0)->rsp0 == keep);

    /* IDT: exactly one gate may be DPL 3, and it must be the syscall vector. */
    struct Dtr id; __asm__ volatile ("sidt %0" : "=m"(id));
    uint32_t dpl3 = 0, dpl3_vec = 0xFFFF, bad_exc = 0;
    for (uint32_t v = 0; v < 256; v++) {
        uint8_t a = *(volatile uint8_t *)(uintptr_t)(id.base + v * 16 + 5);
        if (!(a & 0x80)) continue;
        if (((a >> 5) & 3) == 3) { dpl3++; dpl3_vec = v; }
        if (v < 32 && ((a >> 5) & 3) != 0) bad_exc++;
    }
    check(A_GDT, "IDT: exactly one gate is callable from Ring 3, and it is the syscall vector 0x80",
          dpl3 == 1 && dpl3_vec == RING3_SYSCALL_VECTOR);
    check(A_GDT, "IDT: every CPU exception gate (0-31) is DPL 0",
          bad_exc == 0);

    uint8_t pre = *(volatile uint8_t *)(uintptr_t)(id.base + 14 * 16 + 5);
    int ok_lo = idt_allow_user_syscall_vector(14);
    int ok_hi = idt_allow_user_syscall_vector(256);
    uint8_t post = *(volatile uint8_t *)(uintptr_t)(id.base + 14 * 16 + 5);
    check(A_GDT, "idt_allow_user_syscall_vector refuses exception vectors / out-of-range and leaves #PF's gate DPL 0",
          ok_lo == 0 && ok_hi == 0 && pre == post && ((post >> 5) & 3) == 0);

    uint64_t cr0; __asm__ volatile ("mov %%cr0, %0" : "=r"(cr0));
    check(A_GDT, "CR0.WP is set (supervisor writes honour read-only pages, e.g. the user code page)",
          (cr0 >> 16) & 1);

    /* Informational, NOT counted as PASS: SMEP/SMAP are reported as observed. */
    uint32_t a, b, c, d;
    __asm__ volatile ("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "a"(7), "c"(0));
    serial_puts("SECURITY-02-INFO SMEP ");
    serial_puts((b >> 7) & 1 ? "advertised by CPU (not enabled by this milestone)" : "NOT advertised by this CPU model");
    serial_puts("; SMAP ");
    serial_puts((b >> 20) & 1 ? "advertised by CPU (not enabled by this milestone)\n" : "NOT advertised by this CPU model\n");
}

static int qry(uint64_t va, uint64_t *e, uint64_t *sz)
{
    *e = 0; *sz = 0;
    return vmm_query(va, e, sz) == VMM_OK && (*e & VMM_PRESENT);
}

static void test_memory_and_address_space(void)
{
    uint64_t e, sz;

    /* The user region, as built. */
    int code_ok = qry(ring3_code_va(), &e, &sz);
    check(A_UAS, "user code page: present, USER, read-only, executable (no NX), 4 KiB",
          code_ok && (e & VMM_USER) && !(e & VMM_WRITE) && !(e & VMM_NX) && sz == VMM_PAGE_SIZE);
    int st_ok = qry(ring3_stack_va(), &e, &sz);
    check(A_UAS, "user stack page: present, USER, writable, NX, 4 KiB",
          st_ok && (e & VMM_USER) && (e & VMM_WRITE) && (e & VMM_NX) && sz == VMM_PAGE_SIZE);
    check(A_UAS, "neither user page is both writable and executable (W^X)",
          1 /* conjunction of the two checks above; asserted explicitly: */ &&
          qry(ring3_code_va(), &e, &sz) && !((e & VMM_WRITE) && !(e & VMM_NX)) &&
          qry(ring3_stack_va(), &e, &sz) && !((e & VMM_WRITE) && !(e & VMM_NX)));
    check(A_UAS, "both guard pages (below and above the stack) are unmapped",
          !qry(ring3_guard_lo_va(), &e, &sz) && !qry(ring3_guard_hi_va(), &e, &sz));
    check(A_UAS, "user region is explicit: 4 pages, base page-aligned",
          ring3_region_bytes() == 4 * VMM_PAGE_SIZE && (ring3_region_base() & (VMM_PAGE_SIZE - 1)) == 0);

    /* Live page-table audit, post-Ring3. SECURITY-01 asserted ZERO user
     * entries and still does - at the point it runs, BEFORE ring3_init(). The
     * invariant that holds now is exact, not "some": the two pages above. */
    SecPageAudit a;
    int got = sec_audit_page_tables(&a);
    check(A_UAS, "page-table audit: EXACTLY 2 user-accessible leaf entries exist (the code page and the stack page) - no more",
          got && a.user_pt == 2);
    check(A_UAS, "page-table audit: user bit was promoted on the ancestors of that path only (>=1 each, and not on every table)",
          got && a.user_pml4 >= 1 && a.user_pdpt >= 1 && a.user_pd >= 1 &&
          a.user_pml4 <= 2 && a.user_pdpt <= 4 && a.user_pd <= 4);
    /* The identity map's W+X leaves are the kernel image itself (2 MiB
     * granularity, .text and .data share large pages). That is a known,
     * documented SECURITY-01 limitation, supervisor-only, and listed under
     * remaining risks in docs/SECURITY-02.md - not something this check
     * should pretend away. What SECURITY-02 must prove is that creating
     * Ring 3 added NO new W+X leaf anywhere else: not in the kmap window
     * where the user pages live, not in the direct map. */
    check(A_KMEM, "page-table audit: no W+X leaf outside the identity map after Ring 3 setup (user pages + kmap + direct map clean)",
          got && a.wx_direct_map == 0 && a.wx_kmap == 0 && a.wx_other == 0);

    /* Kernel-only memory stays kernel-only. */
    check(A_KMEM, "kernel image page (0x100000) is present and supervisor-only",
          qry(0x100000, &e, &sz) && !(e & VMM_USER));
    check(A_KMEM, "Ring 3 kernel stack is supervisor-only",
          qry((uint64_t)(uintptr_t)ring3_kernel_stack_top() - 16, &e, &sz) && !(e & VMM_USER));
    check(A_KMEM, "physical direct map is supervisor-only (this is how page-table frames are reachable)",
          qry(VEX_PHYS_MAP_BASE + 0x1000, &e, &sz) && !(e & VMM_USER));
    check(A_KMEM, "the live kernel stack (this function's own frame) is supervisor-only",
          qry((uint64_t)(uintptr_t)&e, &e, &sz) && !(e & VMM_USER));

    /* The two doors. */
    uint64_t scratch = vmm_kmap_reserve_virtual(1);
    check(A_UAS, "vmm_map_page still REFUSES VMM_USER (SECURITY-01 behaviour preserved)",
          scratch != 0 && vmm_map_page(scratch, 0x5000, VMM_USER | VMM_WRITE | VMM_NX) != VMM_OK);
    check(A_UAS, "vmm_map_user_page refuses a mapping without VMM_USER",
          vmm_map_user_page(scratch, 0x5000, VMM_WRITE | VMM_NX) == VMM_ERR_BAD_REQUEST);
    check(A_UAS, "vmm_map_user_page refuses a misaligned address",
          vmm_map_user_page(scratch + 1, 0x5000, VMM_USER) == VMM_ERR_NOT_ALIGNED);
    check(A_UAS, "vmm_map_user_page refuses to replace an existing mapping (the user code page)",
          vmm_map_user_page(ring3_code_va(), 0x5000, VMM_USER) == VMM_ERR_ALREADY_MAPPED);
    check(A_KMEM, "the refused requests created no mapping at the scratch address",
          !qry(scratch, &e, &sz));
}

/* ------------------------------------------------------------------ */
/* User pointer validation (called directly from the kernel)           */
/* ------------------------------------------------------------------ */

static void test_user_pointers(void)
{
    uint64_t msg = ring3_msg_va(), mlen = ring3_msg_len();
    uint64_t sbase = ring3_stack_va(), cbase = ring3_code_va();
    const uint64_t P = VMM_PAGE_SIZE;

    check(A_UPTR, "valid range inside the user stack page is accepted (positive control)",
          user_range_check(msg, mlen, 0) == UV_OK);
    check(A_UPTR, "valid writable range is accepted when write is required",
          user_range_check(sbase + 64, 32, 1) == UV_OK);
    check(A_UPTR, "read-only code page refuses a write-required check",
          user_range_check(cbase, 16, 1) == UV_ERR_NOT_WRITABLE);
    check(A_UPTR, "read-only code page accepts a read",
          user_range_check(cbase, 16, 0) == UV_OK);
    check(A_UPTR, "zero-length buffer at a valid user address is accepted",
          user_range_check(msg, 0, 0) == UV_OK);
    check(A_UPTR, "zero-length buffer at a wild kernel address is still rejected",
          user_range_check(0x100000, 0, 0) == UV_ERR_NOT_USER);
    check(A_UPTR, "NULL with length is rejected as NULL",   user_range_check(0, 16, 0) == UV_ERR_NULL);
    check(A_UPTR, "NULL with zero length is rejected as NULL", user_range_check(0, 0, 0) == UV_ERR_NULL);
    check(A_UPTR, "ptr = UINT64_MAX-15, len = 0x1000 is rejected as OVERFLOW (no wraparound)",
          user_range_check(UINT64_MAX - 15, 0x1000, 0) == UV_ERR_OVERFLOW);
    check(A_UPTR, "ptr = 1, len = UINT64_MAX is rejected as OVERFLOW",
          user_range_check(1, UINT64_MAX, 0) == UV_ERR_OVERFLOW);
    check(A_UPTR, "ptr = UINT64_MAX, len = 1 is rejected as OVERFLOW",
          user_range_check(UINT64_MAX, 1, 0) == UV_ERR_OVERFLOW);
    check(A_UPTR, "non-canonical pointer is rejected",
          user_range_check(0x0000800000000000ULL, 8, 0) == UV_ERR_NONCANONICAL);
    check(A_UPTR, "kernel image address (mapped + present) is rejected as NOT_USER, not merely 'unmapped'",
          user_range_check(0x100000, 16, 0) == UV_ERR_NOT_USER);
    check(A_UPTR, "kernel direct-map address is rejected",
          user_range_check(VEX_PHYS_MAP_BASE + 0x1000, 16, 0) != UV_OK);
    check(A_UPTR, "range crossing off the end of the stack page into the guard is rejected (every page checked)",
          user_range_check(sbase + P - 8, 64, 0) == UV_ERR_NOT_MAPPED);
    check(A_UPTR, "range starting in the guard below the stack is rejected",
          user_range_check(sbase - 8, 16, 0) == UV_ERR_NOT_MAPPED);
    check(A_UPTR, "range crossing off the end of the code page into the guard is rejected",
          user_range_check(cbase + P - 8, 64, 0) == UV_ERR_NOT_MAPPED);
    check(A_UPTR, "range ending exactly on the last valid byte of the stack page is accepted (boundary control)",
          user_range_check(sbase + P - 16, 16, 0) == UV_OK);
    check(A_UPTR, "one byte longer than that is rejected (boundary control)",
          user_range_check(sbase + P - 16, 17, 0) == UV_ERR_NOT_MAPPED);
    check(A_UPTR, "enormous length from a valid pointer is rejected",
          user_range_check(msg, 1ULL << 40, 0) != UV_OK);
}

/* ------------------------------------------------------------------ */
/* Ring 3 execution                                                    */
/* ------------------------------------------------------------------ */

static uint64_t rflags(void) { uint64_t f; __asm__ volatile ("pushfq; pop %0" : "=r"(f)); return f; }

static void test_ring3(void)
{
    Ring3Result r;
    volatile uint64_t *kw = (volatile uint64_t *)(uintptr_t)0x100000;
    uint64_t kernel_word_before = *kw;
    uint64_t fl_before = rflags() & 0x200;
    uint64_t faults_before = ring3_faults_isolated();

    /* 1. Clean entry and exit. */
    ring3_run(ring3_slot_exit_clean, 0, 0, &r);
    check(A_TRANS, "Ring 0 -> Ring 3 via iretq: program ran and returned through SYS_EXIT (code 0), one syscall",
          r.outcome == RING3_OUT_EXITED && r.exit_code == 0 && r.syscalls_seen == 1);

    /* 2. Valid access to its own memory, through the syscall boundary. */
    ring3_run(ring3_slot_syscall_valid, ring3_msg_va(), ring3_msg_len(), &r);
    check(A_TRANS, "Ring 3 reads its own mapped buffer via a validated SYS_WRITE (16 bytes), then exits",
          r.outcome == RING3_OUT_EXITED && r.last_write_ret == (int64_t)ring3_msg_len() &&
          r.bytes_written == ring3_msg_len() && r.syscalls_rejected == 0 && r.syscalls_seen == 2);

    /* 3. Syscall boundary. */
    ring3_run(ring3_slot_syscall_null, 0, 0, &r);
    check(A_SYSC, "SYS_WRITE with NULL is REJECTED (-1, reason NULL); kernel survives; program continues and exits",
          r.outcome == RING3_OUT_EXITED && r.syscalls_rejected == 1 &&
          r.last_write_ret == RING3_SYS_REJECTED && r.last_reject_reason == UV_ERR_NULL);

    ring3_run(ring3_slot_syscall_overflow, 0, 0, &r);
    check(A_SYSC, "SYS_WRITE with ptr+len past UINT64_MAX is REJECTED for overflow, without wraparound",
          r.outcome == RING3_OUT_EXITED && r.syscalls_rejected == 1 &&
          r.last_write_ret == RING3_SYS_REJECTED && r.last_reject_reason == UV_ERR_OVERFLOW);

    ring3_run(ring3_slot_syscall_kernel_ptr, 0, 0, &r);
    check(A_SYSC, "SYS_WRITE with a mapped KERNEL pointer is REJECTED as NOT_USER (the U/S bit, not mere presence, decides)",
          r.outcome == RING3_OUT_EXITED && r.syscalls_rejected == 1 &&
          r.last_write_ret == RING3_SYS_REJECTED && r.last_reject_reason == UV_ERR_NOT_USER);

    /* Buffer that overruns its mapping, from Ring 3: pointer in the stack page, length past it. */
    ring3_run(ring3_slot_syscall_valid, ring3_stack_va() + VMM_PAGE_SIZE - 8, 64, &r);
    check(A_SYSC, "SYS_WRITE whose buffer runs off the end of the user mapping is REJECTED (reason NOT_MAPPED)",
          r.outcome == RING3_OUT_EXITED && r.syscalls_rejected == 1 &&
          r.last_reject_reason == UV_ERR_NOT_MAPPED);

    ring3_run(ring3_slot_syscall_valid, ring3_msg_va(), RING3_WRITE_MAX + 1, &r);
    check(A_SYSC, "SYS_WRITE longer than the per-call cap is REJECTED even over valid memory (reason TOO_LARGE)",
          r.outcome == RING3_OUT_EXITED && r.syscalls_rejected == 1 &&
          r.last_reject_reason == UV_ERR_TOO_LARGE);

    int64_t rax = 1;
    __asm__ volatile ("int $0x80" : "+a"(rax) : : "rdi", "rsi", "memory");
    check(A_SYSC, "int 0x80 from Ring 0 with no Ring 3 run in flight is REJECTED (-1), not honoured",
          rax == RING3_SYS_REJECTED);

    /* 4. Kernel memory isolation. */
    ring3_run(ring3_slot_read_kernel, 0, 0, &r);
    check(A_KISO, "Ring 3 READ of kernel memory faults: #PF, error code P=1 U=1 W=0 (protection violation, user access), CR2 = target",
          r.outcome == RING3_OUT_FAULTED && r.fault_vector == 14 &&
          (r.fault_error_code & 0x7) == 0x5 && r.fault_cr2 == 0x100000);
    check(A_KISO, "the faulting instruction was inside the user code region",
          r.fault_rip >= ring3_code_va() && r.fault_rip < ring3_code_va() + VMM_PAGE_SIZE);

    ring3_run(ring3_slot_write_kernel, 0, 0, &r);
    check(A_KISO, "Ring 3 WRITE to kernel memory faults: #PF, error code P=1 W=1 U=1, CR2 = target",
          r.outcome == RING3_OUT_FAULTED && r.fault_vector == 14 &&
          (r.fault_error_code & 0x7) == 0x7 && r.fault_cr2 == 0x100000);
    check(A_KISO, "the kernel word Ring 3 tried to overwrite is unchanged",
          *kw == kernel_word_before);

    /* 5. Fault isolation: the kernel got here, in Ring 0, intact. */
    uint16_t cs; __asm__ volatile ("mov %%cs, %0" : "=r"(cs));
    check(A_FAULT, "after user faults the kernel is executing in Ring 0 (CS RPL 0)", (cs & 3) == 0);
    check(A_FAULT, "two user faults were isolated and counted", ring3_faults_isolated() - faults_before == 2);
    check(A_FAULT, "the interrupt flag is exactly as it was before the Ring 3 runs", (rflags() & 0x200) == fl_before);
    check(A_FAULT, "per-CPU storage (%gs:0) is intact after Ring 3 ran and faulted (swapgs discipline)",
          percpu_verify_this_cpu(0) == 1);

    /* Repeatability: a fault is not a one-shot. */
    ring3_run(ring3_slot_read_kernel, 0, 0, &r);
    Ring3Result r2;
    ring3_run(ring3_slot_exit_clean, 0, 0, &r2);
    check(A_FAULT, "after a fault the next Ring 3 run still works (fault, then clean exit)",
          r.outcome == RING3_OUT_FAULTED && r2.outcome == RING3_OUT_EXITED && percpu_verify_this_cpu(0) == 1);

    Ring3Result r3;
    ring3_run(0x100000, 0, 0, &r3);   /* slot far outside the program blob */
    check(A_FAULT, "a slot outside the program blob is refused without entering Ring 3",
          r3.outcome == RING3_OUT_NONE);
}

/* ------------------------------------------------------------------ */

void security02_run_tests(Security02Results *out)
{
    g_id = g_run = g_fail = 0;
    for (int i = 0; i < A_COUNT; i++) a_run[i] = a_fail[i] = 0;

    serial_puts("\n===== SECURITY-02 CHECKS =====\n");

    test_graphics();

    if (!ring3_initialised()) {
        serial_puts("SECURITY-02-FAIL ring3_init() did not succeed; Ring 3 areas cannot be claimed\n");
        g_run++; g_fail++;
    } else {
        test_gdt_idt_tss();
        test_memory_and_address_space();
        test_user_pointers();
        test_ring3();
    }

    int all = (g_fail == 0);
    for (int i = 0; i < A_COUNT; i++) {
        if (a_run[i] > 0 && a_fail[i] == 0) {
            serial_puts("[security] SECURITY-02: ");
            serial_puts(area_name[i]);
            serial_puts(" PASS\n");
        } else {
            serial_puts("[security] SECURITY-02: ");
            serial_puts(area_name[i]);
            serial_puts(a_run[i] == 0 ? " NOT RUN\n" : " FAIL\n");
            all = 0;
        }
    }

    out->checks_run = g_run;
    out->checks_failed = g_fail;
    out->all_areas_pass = all;
}

void security02_print_summary(const Security02Results *r)
{
    serial_puts("===== ");
    serial_put_dec64(r->checks_run - r->checks_failed);
    serial_puts("/");
    serial_put_dec64(r->checks_run);
    serial_puts(" SECURITY-02 checks passed =====\n");
}

int security02_all_passed(const Security02Results *r)
{
    return r->checks_failed == 0 && r->all_areas_pass;
}
