/*
 * Vex OS - kernel/include/ahci.h
 * STORAGE-01: minimal polled AHCI (SATA) driver: sector read / write / flush on ATA disks via 48-bit LBA DMA.
 * One command slot, one bounce page, no interrupts, no NCQ, no hot-plug, no ATAPI. Verified only in QEMU (ich9-ahci).
 */
#ifndef VEXOS_AHCI_H
#define VEXOS_AHCI_H
#include <stdint.h>

#define AHCI_MAX_DISKS 4
typedef struct { int port; uint64_t sectors; char model[41]; } AhciDisk;

/* Finds an AHCI controller on PCI, maps its registers, identifies ATA disks. Returns the number of usable disks (0 = none / no controller). */
int ahci_init(void);
int ahci_disk_count(void);
const AhciDisk *ahci_disk(int i);
/* 0 on success, negative on error (-1 bad args/range, -2 device error, -3 timeout). 512-byte sectors. */
int ahci_read(int disk, uint64_t lba, uint32_t count, void *buf);
int ahci_write(int disk, uint64_t lba, uint32_t count, const void *buf);   /* includes a cache flush */
#endif
