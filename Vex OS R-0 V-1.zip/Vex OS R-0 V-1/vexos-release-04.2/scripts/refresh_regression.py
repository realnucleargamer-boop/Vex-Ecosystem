#!/usr/bin/env python3
"""Vex OS - scripts/refresh_regression.py : desktop REFRESH regression harness.

INVARIANT: after any sequence of interactions, the incrementally updated framebuffer must be pixel-identical
to a fresh FULL redraw of the same state (F12 = explicit full redraw).  Any difference is a stale pixel / visual
trail / element that vanishes on the next redraw.  After every step this script takes screendump A (incremental),
presses F12, takes screendump B (full) and compares them EXACTLY (including the cursor, which is at the same
position in both).  The whole sequence is repeated REPEAT times to catch intermittent faults.
  python3 scripts/refresh_regression.py [image] [seed-image]"""
import os, re, sys, time
sys.path.insert(0, os.path.dirname(__file__))
from qemu_drive import Vm, load_ppm
from PIL import ImageChops, ImageDraw
IMG = sys.argv[1] if len(sys.argv) > 1 else "build/vexos.img"
SEED = sys.argv[2] if len(sys.argv) > 2 else "build/vexos-seed.img"
OUT = os.environ.get("E2E_OUT", "build/refresh"); os.makedirs(OUT, exist_ok=True)
REPEAT = int(os.environ.get("REPEAT", "2")); fails = []; steps = 0
def rects(vm, tag):
    ls = [l for l in vm.serial().splitlines() if tag in l]
    return {m.group(1): tuple(map(int, m.groups()[1:])) for m in re.finditer(r"(\w+)=\((\d+),(\d+),(\d+),(\d+)\)", ls[-1])} if ls else {}
def mr(vm, dx, dy):
    while dx or dy:
        sx = max(-100, min(100, dx)); sy = max(-100, min(100, dy)); vm.mouse_move(sx, sy); dx -= sx; dy -= sy; time.sleep(0.03)
    time.sleep(0.35)
def click(vm, r): mr(vm, -1500, -1000); mr(vm, r[0] + r[2] // 2, r[1] + r[3] // 2); vm.mouse_button(1); time.sleep(0.25); vm.mouse_button(0); time.sleep(0.6)
def keys(vm, *ks):
    for k in ks: vm.sendkey(k); time.sleep(0.12)
    time.sleep(0.4)
def compare(vm, label, tag):
    global steps; steps += 1
    pa, pb = f"{OUT}/{tag}_a.ppm", f"{OUT}/{tag}_b.ppm"
    time.sleep(0.5); vm.screendump(pa)
    n0 = len(re.findall(r"full redraw requested", vm.serial())); vm.sendkey("f12")
    for _ in range(40):
        if len(re.findall(r"full redraw requested", vm.serial())) > n0: break
        time.sleep(0.1)
    time.sleep(0.6); vm.screendump(pb)
    a, b = load_ppm(pa), load_ppm(pb); diff = ImageChops.difference(a, b)
    # LIVE-DATA regions legitimately differ between two captures taken ~1 s apart; they are excluded, nothing else is:
    #   top-right clock (minute digit) on lock/desktop, and the uptime column of the process view.
    dr = ImageDraw.Draw(diff); w = a.size[0]
    dr.rectangle((w - 180, 0, w, 64), fill=(0, 0, 0)); dr.rectangle((w // 2 - 200, 40, w // 2 + 200, 230), fill=(0, 0, 0)) if "lock" in label and "box" not in label else None
    if "process view after" in label: dr.rectangle((150, 110, 1100, 175), fill=(0, 0, 0))
    d = diff.getbbox()
    print(("PASS  " if d is None else "FAIL  ") + label + ("" if d is None else f"   [incremental != full redraw, differing bbox {d}]"), flush=True)
    if d is not None: fails.append((label, d)); a.save(f"{OUT}/{tag}_a.png"); b.save(f"{OUT}/{tag}_b.png")
def sequence(vm, r, accounts):
    L = rects(vm, "lock screen shown"); compare(vm, f"[{r}] lock screen after boot", f"{r}_01")
    for nm in ("users", "net", "power"):
        click(vm, L[nm]); compare(vm, f"[{r}] lock: {nm} panel open", f"{r}_02{nm}")
        keys(vm, "esc"); compare(vm, f"[{r}] lock: {nm} panel closed (no trail)", f"{r}_03{nm}")
    mr(vm, -1500, -1000); mr(vm, L["signin"][0] + 20, L["signin"][1] + 20); compare(vm, f"[{r}] lock: hover on Sign in", f"{r}_04")
    keys(vm, "x", "y", "z"); compare(vm, f"[{r}] lock: typing into the password field (incremental)", f"{r}_04a")
    keys(vm, "backspace", "backspace"); compare(vm, f"[{r}] lock: backspace in the password field", f"{r}_04a2")
    keys(vm, "ret"); compare(vm, f"[{r}] lock: wrong password -> message shown, field cleared", f"{r}_04a3")
    keys(vm, "q"); compare(vm, f"[{r}] lock: typing clears the error message (no text trail)", f"{r}_04a4")
    keys(vm, "backspace")
    keys(vm, "v", "e", "x", "p", "a", "s", "s", "1"); compare(vm, f"[{r}] lock: password typed (masked)", f"{r}_04b")
    keys(vm, "ret"); D = rects(vm, "desktop shown"); compare(vm, f"[{r}] desktop after password sign-in", f"{r}_05")
    click(vm, D["vbtn"]); compare(vm, f"[{r}] desktop: V menu open", f"{r}_06")
    keys(vm, "t", "e"); compare(vm, f"[{r}] V menu: search 'te'", f"{r}_07")
    keys(vm, "esc"); compare(vm, f"[{r}] V menu closed (no trail)", f"{r}_08")
    click(vm, D["search"]); keys(vm, "v"); compare(vm, f"[{r}] desktop search results", f"{r}_09")
    keys(vm, "e", "x"); compare(vm, f"[{r}] search bar: more typing, results shrink (no leftover panel pixels)", f"{r}_09b")
    keys(vm, "backspace", "backspace"); compare(vm, f"[{r}] search bar: backspace, results grow back", f"{r}_09c")
    keys(vm, "esc"); compare(vm, f"[{r}] search closed", f"{r}_10")
    # stress: hover sweep over every desktop control, press-and-drag-off, rapid popup cycling
    for nm in ("vbtn", "term", "search"): mr(vm, -1500, -1000); mr(vm, D[nm][0] + 6, D[nm][1] + 6)
    compare(vm, f"[{r}] desktop: hover sweep ends on search", f"{r}_10b")
    mr(vm, -1500, -1000); mr(vm, D["vbtn"][0] + 8, D["vbtn"][1] + 8); vm.mouse_button(1); time.sleep(0.3); mr(vm, 300, 200); vm.mouse_button(0); time.sleep(0.5)
    compare(vm, f"[{r}] desktop: press V then drag off and release (no fire, no stuck pressed look)", f"{r}_10c")
    for i in range(6): click(vm, D["vbtn"]); keys(vm, "esc")
    compare(vm, f"[{r}] desktop: 6 rapid V-menu open/close cycles", f"{r}_10d")
    click(vm, D["term"]); compare(vm, f"[{r}] terminal opened", f"{r}_11")
    keys(vm, "a", "b", "c"); compare(vm, f"[{r}] Verminal: typing in the prompt (prompt-row-only update)", f"{r}_11b")
    keys(vm, "backspace"); compare(vm, f"[{r}] Verminal: backspace in the prompt", f"{r}_11c")
    keys(vm, "backspace", "backspace")
    for k in ["v", "dot", "spc", "h", "e", "l", "p", "ret"]: vm.sendkey(k); time.sleep(0.1)
    compare(vm, f"[{r}] terminal: v. help output", f"{r}_12")
    for k in ["v", "dot", "spc", "p", "r", "o", "c", "e", "s", "s", "e", "s", "ret"]: vm.sendkey(k); time.sleep(0.1)
    time.sleep(2.2); compare(vm, f"[{r}] terminal: process view after refresh ticks", f"{r}_13")
    keys(vm, "esc"); compare(vm, f"[{r}] process view left", f"{r}_14")
    keys(vm, "esc"); compare(vm, f"[{r}] terminal closed -> desktop (no trail)", f"{r}_15")
    click(vm, D["expl"]); compare(vm, f"[{r}] File Explorer opened", f"{r}_20")
    keys(vm, "n"); compare(vm, f"[{r}] Explorer: New File dialog open", f"{r}_21")
    keys(vm, "a", "b"); compare(vm, f"[{r}] Explorer dialog: typing in the file-name field", f"{r}_21b")
    keys(vm, "backspace"); compare(vm, f"[{r}] Explorer dialog: backspace", f"{r}_21c")
    keys(vm, "backspace")
    keys(vm, "a", "dot", "t", "x", "t", "ret"); compare(vm, f"[{r}] Explorer: file created, listing refreshed", f"{r}_22")
    keys(vm, "n", "a", "dot", "t", "x", "t", "ret"); compare(vm, f"[{r}] Explorer: duplicate rejected (error shown, dialog still open)", f"{r}_23")
    keys(vm, "esc"); compare(vm, f"[{r}] Explorer: dialog cancelled (no trail)", f"{r}_24")
    keys(vm, "esc"); compare(vm, f"[{r}] Explorer closed -> desktop (no trail)", f"{r}_25")
    click(vm, D["task"]); time.sleep(2.2); keys(vm, "esc"); compare(vm, f"[{r}] Task Manager opened, refreshed, closed -> desktop (no trail)", f"{r}_26")
    click(vm, D["valb"]); W = rects(vm, "valbook view shown"); compare(vm, f"[{r}] Valbook opened", f"{r}_30")
    keys(vm, "h", "e", "l", "l", "o"); compare(vm, f"[{r}] Valbook: typing (line-only update)", f"{r}_31")
    keys(vm, "ret", "w", "o"); compare(vm, f"[{r}] Valbook: newline + typing", f"{r}_32")
    keys(vm, "backspace", "backspace", "backspace"); compare(vm, f"[{r}] Valbook: backspace across a line break", f"{r}_33")
    keys(vm, "left", "left"); compare(vm, f"[{r}] Valbook: cursor moved", f"{r}_34")
    tc = W["tclose"]; mr(vm, -1500, -1000); mr(vm, tc[0] - 300, tc[1] + 12); vm.mouse_button(1); time.sleep(0.3); mr(vm, 120, 70); vm.mouse_button(0); time.sleep(0.6)
    compare(vm, f"[{r}] window dragged by its title bar (no trail at the old position)", f"{r}_35")
    keys(vm, "x"); compare(vm, f"[{r}] typing into the MOVED window", f"{r}_36")
    tm = W["tmin"]; click(vm, (tm[0] + 120, tm[1] + 70, tm[2], tm[3])); compare(vm, f"[{r}] window minimized -> desktop (no trail)", f"{r}_37")
    click(vm, D["valb"]); compare(vm, f"[{r}] window restored from the taskbar", f"{r}_38")
    cardx, cardy = tc[0] + 40 - 1000 + 120, tc[1] - 6 + 70
    click(vm, (tc[0] + 120, tc[1] + 70, tc[2], tc[3])); time.sleep(0.4); compare(vm, f"[{r}] close with unsaved text -> Save/Discard/Cancel prompt", f"{r}_39")
    click(vm, (cardx + 500 - 1 - 55, cardy + 267 - 17, 110, 34)); compare(vm, f"[{r}] Discard -> window closed, desktop clean", f"{r}_40")
    click(vm, D["expl"]); mr(vm, 300, 400); vm.mouse_button(2); time.sleep(0.25); vm.mouse_button(0); time.sleep(0.6); compare(vm, f"[{r}] Explorer: right-click context menu open", f"{r}_41")
    keys(vm, "esc"); compare(vm, f"[{r}] context menu dismissed (no trail)", f"{r}_42")
    keys(vm, "esc"); compare(vm, f"[{r}] Explorer closed", f"{r}_43")
    click(vm, D["vbtn"]); V = rects(vm, "V menu opened"); click(vm, V["item5"]); compare(vm, f"[{r}] locked from V menu", f"{r}_16")
vm = Vm(SEED if os.path.exists(SEED) else IMG, OUT, tag="R"); vm.wait_serial(r"\[ui\] lock screen shown", 120); time.sleep(1.2)
for r in range(REPEAT): sequence(vm, r + 1, 3)
vm.stop()
print(f"\n{steps - len(fails)}/{steps} refresh-invariant checks passed")
for l, d in fails: print("  DIVERGED:", l, d)
sys.exit(1 if fails else 0)
