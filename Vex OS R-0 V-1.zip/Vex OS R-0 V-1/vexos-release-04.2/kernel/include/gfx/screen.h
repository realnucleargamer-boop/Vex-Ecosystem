/*
 * Vex OS - kernel/include/gfx/screen.h
 *
 * BOOT-03 boot screen: layout, status panel, and terminal area.
 *
 * All results displayed here come from real runtime data — Boot03Results
 * fields, acpi_ok/lapic_ok/paging_ok/timer_ok/smp flags — never
 * fabricated.  Each displayed PASS/FAIL/ONLINE value is gated on a
 * corresponding boolean that kernel_entry.c sets only when the relevant
 * subsystem actually succeeded.
 */

#ifndef VEXOS_GFX_SCREEN_H
#define VEXOS_GFX_SCREEN_H

#include <stdint.h>
#include "gfx/fb.h"
#include "gfx/text.h"
#include "boot03_tests.h"   /* Boot03Results */
#include "kernel01_tests.h"
#include "security01_tests.h"

/* The complete set of runtime facts kernel_entry.c knows at the point
 * it calls gfx_boot_screen_draw().  Only booleans the kernel has
 * actually verified are set; everything else is left 0/false so the
 * screen shows UNKNOWN rather than a fabricated PASS. */
typedef struct {
    /* Subsystem result flags — set only when actually confirmed OK. */
    int acpi_ok;
    int lapic_ok;
    int paging_ok;
    int timer_ok;
    int smp_ok;

    /* SMP: cpu_count is meaningful only when smp_ok. */
    uint32_t cpu_count;

    /* Memory stats from PMM (valid after pmm_init). */
    uint64_t usable_mib;
    uint64_t free_mib;

    /* BOOT-03 self-test results (passed after boot03_run_tests). */
    const Boot03Results *b03;  /* may be NULL */

    /* KERNEL-01 and SECURITY-01 results. */
    const Kernel01Results  *k01;  /* may be NULL */
    const Security01Results *s01; /* may be NULL */

    /* Framebuffer facts (populated by gfx_boot_screen_draw from GfxFb). */
    uint32_t fb_width;
    uint32_t fb_height;
    uint32_t fb_bpp;

    /* Renderer selftest outcome — set by gfx_boot_screen_draw itself
     * after running gfx_fb_selftest(). */
    int renderer_ok;
} GfxBootStatus;

/* Draw the complete BOOT-03 boot screen into *fb, populate *con with a
 * usable scrolling console in the terminal area, and fill in
 * st->renderer_ok with the live selftest result.
 *
 * Must be called after vmm_activate() (paging_ok == 1) because the
 * framebuffer must be live.  Safe to call with partial data (fields
 * left 0 display as UNKNOWN/NOT TESTED).
 *
 * Returns 1 if the renderer selftest passed, 0 otherwise. */
int gfx_boot_screen_draw(GfxFb *fb, GfxConsole *con, GfxBootStatus *st);

/* Write the BOOT-03 result detail lines into *con (called after
 * gfx_boot_screen_draw initialises the console). */
void gfx_boot_screen_write_status(GfxConsole *con, const GfxBootStatus *st);

#endif /* VEXOS_GFX_SCREEN_H */
