"""vexc — VexScript 2.0+++ compiler CLI."""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

from . import __version__
from .errors import VexError
from .project import load_project, find_project_root, load_manifest
from .interpreter import Interpreter
from .compile_ir import compile_to_ir, emit_ir_text, run_via_ir
from .native import emit_asm, compile_native, run_native
from .ir.text import module_to_text


def _fail(msg: str, code: int = 1) -> int:
    print(msg, file=sys.stderr)
    return code


def _project_module_paths(cfg) -> list[str]:
    """Search dirs: entry parent, project root, src/, stdlib."""
    paths = []
    entry_dir = cfg.entry.parent
    paths.append(str(entry_dir))
    paths.append(str(cfg.root))
    src = cfg.root / "src"
    if src.is_dir():
        paths.append(str(src))
    stdlib = Path(__file__).resolve().parent.parent.parent / "stdlib"
    if stdlib.is_dir():
        paths.append(str(stdlib))
    return paths


def cmd_check(args) -> int:
    try:
        cfg = load_project(Path(args.path) if args.path else None)
        interp = Interpreter(module_paths=_project_module_paths(cfg))
        interp.load(cfg.entry.read_text(), str(cfg.entry))
        print(f"check ok: {cfg.name} {cfg.version} ({cfg.entry.relative_to(cfg.root)})")
        return 0
    except VexError as e:
        return _fail(e.format())


def cmd_build(args) -> int:
    try:
        cfg = load_project(Path(args.path) if args.path else None)
        source = cfg.entry.read_text()
        # ensure modules resolve from project
        from .interpreter import Interpreter as I
        interp = I(module_paths=_project_module_paths(cfg))
        program = interp.load(source, str(cfg.entry))
        extra = {k: v for k, v in interp.functions.items()
                 if k != "main" and ("::" in k or k in interp.exported)}
        # VEX AI 1.0 language wave: private same-module helpers must still
        # be emitted to IR; pub only gates cross-module visibility.
        from .ir.emitter import emit_program
        from .ir.validate import validate_module
        mod = emit_program(program, extra)
        for fn in mod.functions:
            for b in fn.blocks:
                for inst in list(b.instructions) + ([b.terminator] if b.terminator else []):
                    if inst and inst.op == "call" and inst.extra and "::" in str(inst.extra):
                        extra = str(inst.extra)
                        if not extra.startswith("vex::"):
                            inst.extra = extra.replace("::", "_")
        validate_module(mod)
        text = module_to_text(mod)
        build_dir = cfg.root / "build"
        build_dir.mkdir(exist_ok=True)
        out = build_dir / "project.ir"
        out.write_text(text)
        target = getattr(args, "target", "ir")
        if target == "x86_64":
            from .native import compile_native, emit_asm as _ea
            bin_path = cfg.root / "build" / cfg.name
            compile_native(cfg.entry.read_text(), str(cfg.entry), bin_path)
            (cfg.root / "build" / "project.s").write_text(
                _ea(cfg.entry.read_text(), str(cfg.entry))
            )
            print(f"build ok: native {bin_path.relative_to(cfg.root)} + IR ({cfg.name})")
        else:
            print(f"build ok: wrote {out.relative_to(cfg.root)} ({cfg.name})")
        return 0
    except VexError as e:
        return _fail(e.format())


def cmd_run(args) -> int:
    try:
        cfg = load_project(Path(args.path) if args.path else None)
        # Temporarily set cwd-relative modules via Interpreter paths
        source = cfg.entry.read_text()
        # compile with project paths by patching load through Interpreter
        interp = Interpreter(module_paths=_project_module_paths(cfg))
        program = interp.load(source, str(cfg.entry))
        extra = {k: v for k, v in interp.functions.items()
                 if k != "main" and ("::" in k or k in interp.exported)}
        # VEX AI 1.0 language wave: private same-module helpers must still
        # be emitted to IR; pub only gates cross-module visibility.
        from .ir.emitter import emit_program
        from .ir.validate import validate_module
        from .ir.interpreter import run_module
        mod = emit_program(program, extra)
        for fn in mod.functions:
            for b in fn.blocks:
                for inst in list(b.instructions) + ([b.terminator] if b.terminator else []):
                    if inst and inst.op == "call" and inst.extra and "::" in str(inst.extra):
                        extra = str(inst.extra)
                        if not extra.startswith("vex::"):
                            inst.extra = extra.replace("::", "_")
        validate_module(mod)
        code, out = run_module(mod, "main")
        if out:
            sys.stdout.write(out)
        return int(code) if code is not None else 0
    except VexError as e:
        return _fail(e.format())


def cmd_emit_ir(args) -> int:
    try:
        cfg = load_project(Path(args.path) if args.path else None)
        interp = Interpreter(module_paths=_project_module_paths(cfg))
        program = interp.load(cfg.entry.read_text(), str(cfg.entry))
        extra = {k: v for k, v in interp.functions.items()
                 if k != "main" and ("::" in k or k in interp.exported)}
        # VEX AI 1.0 language wave: private same-module helpers must still
        # be emitted to IR; pub only gates cross-module visibility.
        from .ir.emitter import emit_program
        from .ir.validate import validate_module
        mod = emit_program(program, extra)
        for fn in mod.functions:
            for b in fn.blocks:
                for inst in list(b.instructions) + ([b.terminator] if b.terminator else []):
                    if inst and inst.op == "call" and inst.extra and "::" in str(inst.extra):
                        extra = str(inst.extra)
                        if not extra.startswith("vex::"):
                            inst.extra = extra.replace("::", "_")
        validate_module(mod)
        text = module_to_text(mod)
        sys.stdout.write(text)
        if not text.endswith("\n"):
            sys.stdout.write("\n")
        return 0
    except VexError as e:
        return _fail(e.format())


def cmd_emit_asm(args) -> int:
    try:
        cfg = load_project(Path(args.path) if args.path else None)
        interp = Interpreter(module_paths=_project_module_paths(cfg))
        # compile through project load for modules
        from .native import emit_asm as _ea
        # Need module-aware compile - use entry after load into IR
        from .compile_ir import compile_to_ir
        from .ir.x86_64 import ir_to_asm
        program = interp.load(cfg.entry.read_text(), str(cfg.entry))
        extra = {k: v for k, v in interp.functions.items() if k != "main" and k in interp.exported and v is not None}
        from .ir.emitter import emit_program
        from .ir.validate import validate_module
        mod = emit_program(program, extra)
        for fn in mod.functions:
            for b in fn.blocks:
                for inst in list(b.instructions) + ([b.terminator] if b.terminator else []):
                    if inst and inst.op == "call" and inst.extra and "::" in str(inst.extra):
                        extra_s = str(inst.extra)
                        if not extra_s.startswith("vex::"):
                            inst.extra = extra_s.replace("::", "_")
        validate_module(mod)
        sys.stdout.write(ir_to_asm(mod))
        return 0
    except VexError as e:
        return _fail(e.format())


def cmd_run_native(args) -> int:
    try:
        cfg = load_project(Path(args.path) if args.path else None)
        from .native import run_native as _rn
        # Use entry source; modules via compile_to_ir needs paths - set via Interpreter in compile
        code, out = _rn(cfg.entry.read_text(), str(cfg.entry))
        if out:
            sys.stdout.write(out)
        return int(code) if code is not None else 0
    except VexError as e:
        return _fail(e.format())


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="vexc",
        description="VexScript 2.0+++ compiler toolchain (VEX AI foundation)",
    )
    ap.add_argument("--version", action="version", version=f"vexc {__version__} (VexScript 2.0+++)")
    sub = ap.add_subparsers(dest="cmd")

    for name, help_ in (
        ("check", "Typecheck project (no IR)"),
        ("build", "Emit validated IR (or native with --target x86_64)"),
        ("run", "Run project via IR interpreter (hosted)"),
        ("emit-ir", "Print deterministic text IR to stdout"),
        ("emit-asm", "Print x86-64 AT&T assembly to stdout"),
        ("run-native", "Compile and run native x86-64 binary (hosted)"),
    ):
        p = sub.add_parser(name, help=help_)
        p.add_argument(
            "path",
            nargs="?",
            default=None,
            help="Project directory (default: discover from cwd)",
        )
        if name == "build":
            p.add_argument(
                "--target",
                default="ir",
                choices=["ir", "x86_64"],
                help="Output target: ir (default) or x86_64",
            )

    args = ap.parse_args(argv)
    if not args.cmd:
        ap.print_help()
        return 1
    try:
        if args.cmd == "check":
            return cmd_check(args)
        if args.cmd == "build":
            return cmd_build(args)
        if args.cmd == "run":
            return cmd_run(args)
        if args.cmd == "emit-ir":
            return cmd_emit_ir(args)
        if args.cmd == "emit-asm":
            return cmd_emit_asm(args)
        if args.cmd == "run-native":
            return cmd_run_native(args)
        return _fail(f"error[E0405]: unknown command", 1)
    except VexError as e:
        return _fail(e.format())


if __name__ == "__main__":
    sys.exit(main())
