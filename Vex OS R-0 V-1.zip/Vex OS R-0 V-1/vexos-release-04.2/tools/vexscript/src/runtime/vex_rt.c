/* Hosted runtime for VexScript 2.0 Phase F. Not Vex OS kernel. */
#include <stdio.h>
#include <stdint.h>
#include <string.h>

void vex_rt_print_i64(int64_t x) {
    printf("%lld", (long long)x);
    fflush(stdout);
}

void vex_rt_println_i64(int64_t x) {
    printf("%lld\n", (long long)x);
    fflush(stdout);
}

void vex_rt_print_cstr(const char *s) {
    if (s) fputs(s, stdout);
    fflush(stdout);
}

void vex_rt_println_cstr(const char *s) {
    if (s) fputs(s, stdout);
    fputc('\n', stdout);
    fflush(stdout);
}

/* pointer + length (provisional string representation) */
void vex_rt_print_str(const char *s, int64_t len) {
    if (s && len > 0) fwrite(s, 1, (size_t)len, stdout);
    fflush(stdout);
}

void vex_rt_println_str(const char *s, int64_t len) {
    if (s && len > 0) fwrite(s, 1, (size_t)len, stdout);
    fputc('\n', stdout);
    fflush(stdout);
}
