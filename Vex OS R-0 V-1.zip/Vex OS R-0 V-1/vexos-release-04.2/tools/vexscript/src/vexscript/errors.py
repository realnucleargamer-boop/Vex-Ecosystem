from __future__ import annotations
from pathlib import Path


class SourceLocation:
    def __init__(self, filename: str, line: int, column: int):
        self.filename = filename
        self.line = line
        self.column = column

    def __str__(self) -> str:
        return f"{self.filename}:{self.line}:{self.column}"


class VexError(Exception):
    """Base error with optional source snippet (Phase D)."""

    def __init__(
        self,
        message: str,
        loc: SourceLocation | None = None,
        error_code: str | None = None,
        note: str | None = None,
        source: str | None = None,
    ):
        self.message = message
        self.loc = loc
        self.error_code = error_code
        self.note = note
        self.source = source  # full source text if available
        super().__init__(self.format())

    def format(self) -> str:
        code = f" error[{self.error_code}]:" if self.error_code else " error:"
        if self.loc:
            head = f"{self.loc}:{code} {self.message}"
        else:
            head = f"error{code} {self.message}" if self.error_code else f"error: {self.message}"
        parts = [head]
        snippet = self._snippet()
        if snippet:
            parts.append(snippet)
        if self.note:
            parts.append(f"note: {self.note}")
        return "\n".join(parts)

    def _snippet(self) -> str | None:
        if not self.loc or self.loc.line < 1:
            return None
        text = self.source
        if text is None and self.loc.filename and self.loc.filename not in ("<t>", "<input>", "<stdin>"):
            try:
                path = Path(self.loc.filename)
                if path.is_file():
                    text = path.read_text()
            except OSError:
                return None
        if not text:
            return None
        lines = text.splitlines()
        idx = self.loc.line - 1
        if idx < 0 or idx >= len(lines):
            return None
        line = lines[idx]
        gutter = f"{self.loc.line} | "
        caret_col = max(self.loc.column - 1, 0)
        caret = " " * len(gutter) + " " * caret_col + "^"
        return f"{gutter}{line}\n{caret}"


class LexError(VexError):
    pass


class ParseError(VexError):
    pass


class RuntimeError_(VexError):
    pass


# Phase A+ codes: E0001–E0007 modules, E05xx native, E02xx IR, E03xx IR runtime
