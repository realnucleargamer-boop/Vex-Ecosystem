#!/usr/bin/env python3
"""Export a VEX AI 1.5-Crystal JSON checkpoint to the VXCR v1 binary model (see docs/CRYSTAL-NATIVE-01.md s5.2).

  python3 tools/crystal_export.py export --checkpoint <weights.json> --engine <engine.py> --out assets/crystal/crystal15.vxcr
  python3 tools/crystal_export.py verify --checkpoint <weights.json> --engine <engine.py> --blob assets/crystal/crystal15.vxcr

`export` is deterministic (no timestamps/paths). `verify` re-parses the blob with a SEPARATE reader (numpy.frombuffer
on explicit offsets, not the writer's code path) and compares every tensor, the dimensions, the reject threshold, the
source checksum, the label table and the trailing CRC-32 against the original JSON checkpoint and the Python engine.
Only intent-path tensors are exported: w_op/w_code are never consumed at inference (they are training-only).
"""
import argparse, hashlib, importlib.util, json, os, struct, sys, zlib
import numpy as np

MAGIC = b"VXCR"; VERSION = 1; FRAC = 30; HDR = 64; LABEL_REC = 48
SCALE = float(1 << FRAC)


def load_engine(path):
    os.environ.setdefault("VEX_CHECKPOINT_DIR", os.path.join(os.path.dirname(os.path.abspath(path)), "..", "checkpoints"))
    sys.dont_write_bytecode = True
    sys.path.insert(0, os.path.dirname(os.path.abspath(path)))
    spec = importlib.util.spec_from_file_location("crystal_engine", path)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod


def quant(a):
    """float32 array -> int32 Q30, round-half-even. Refuses values that do not fit (|v| >= 2)."""
    f = np.asarray(a, dtype=np.float32).astype(np.float64)
    if not np.isfinite(f).all():
        raise SystemExit("refusing to export: non-finite weight")
    if np.abs(f).max() >= 2.0:
        raise SystemExit("refusing to export: |weight| >= 2.0 does not fit Q2.30")
    return np.rint(f * SCALE).astype(np.int64).astype("<i4")


def export(ckpt_path, engine_path, out_path):
    d = json.load(open(ckpt_path))
    eng = load_engine(engine_path)
    feat, hid = int(d["feat_dim"]), int(d["hidden"])
    w1 = np.array(d["w1"], dtype=np.float32); b1 = np.array(d["b1"], dtype=np.float32).reshape(-1)
    wi = np.array(d["w_intent"], dtype=np.float32); bi = np.array(d["b_intent"], dtype=np.float32).reshape(-1)
    nint = wi.shape[1]
    assert w1.shape == (feat, hid) and b1.shape == (hid,) and wi.shape == (hid, nint) and bi.shape == (nint,), "shape mismatch"
    assert nint == len(eng.INTENT_TAXONOMY_64) == 64
    reject_q = int(round(float(d["reject_prob"]) * SCALE))
    src = bytes.fromhex(d["checksum"])[:16]
    assert len(src) == 16
    hdr = MAGIC + struct.pack("<7I", VERSION, feat, hid, nint, FRAC, reject_q, HDR) + src + b"\0" * 16
    assert len(hdr) == HDR
    body = quant(w1).tobytes() + quant(b1).tobytes() + quant(wi).tobytes() + quant(bi).tobytes()
    labels = b""
    for t in eng.INTENT_TAXONOMY_64:
        lab, fam = t[1].encode("ascii"), t[2].encode("ascii")
        assert len(lab) < 24 and len(fam) < 24
        labels += lab.ljust(24, b"\0") + fam.ljust(24, b"\0")
    blob = hdr + body + labels
    blob += struct.pack("<I", zlib.crc32(blob) & 0xFFFFFFFF)
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    with open(out_path, "wb") as f:
        f.write(blob)
    print(f"exported {out_path}: {len(blob)} bytes sha256={hashlib.sha256(blob).hexdigest()}")
    return blob


def verify(ckpt_path, engine_path, blob_path):
    """Independent re-read. Returns list of (name, ok, detail); raises nothing."""
    res = []
    def chk(n, ok, d=""): res.append((n, bool(ok), d))
    d = json.load(open(ckpt_path)); eng = load_engine(engine_path); blob = open(blob_path, "rb").read()
    chk("magic", blob[:4] == MAGIC)
    ver, feat, hid, nint, frac, rq, hsz = struct.unpack_from("<7I", blob, 4)
    chk("version==1", ver == 1); chk("frac_bits==30", frac == 30); chk("header_size==64", hsz == 64)
    chk("feat_dim matches checkpoint", feat == d["feat_dim"], f"{feat}")
    chk("hidden matches checkpoint", hid == d["hidden"], f"{hid}")
    chk("n_intents==64", nint == 64)
    chk("reject_q == round(reject_prob*2^30)", rq == int(round(d["reject_prob"] * SCALE)), f"{rq}")
    chk("source checksum bytes", blob[32:48] == bytes.fromhex(d["checksum"])[:16])
    chk("reserved zero", blob[48:64] == b"\0" * 16)
    n_w1, n_wi = feat * hid, hid * nint
    expect_len = HDR + 4 * (n_w1 + hid + n_wi + nint) + nint * LABEL_REC + 4
    chk("total length matches dimensions", len(blob) == expect_len, f"{len(blob)} vs {expect_len}")
    chk("trailing CRC-32 (zlib)", struct.unpack_from("<I", blob, len(blob) - 4)[0] == (zlib.crc32(blob[:-4]) & 0xFFFFFFFF))
    off = HDR
    def take(count):
        nonlocal off
        a = np.frombuffer(blob, dtype="<i4", count=count, offset=off); off += 4 * count; return a
    got = {"w1": take(n_w1).reshape(feat, hid), "b1": take(hid), "w_intent": take(n_wi).reshape(hid, nint), "b_intent": take(nint)}
    for k, a in got.items():
        src = np.array(d[k], dtype=np.float32).astype(np.float64).reshape(a.shape)
        err = float(np.abs(a.astype(np.float64) / SCALE - src).max())
        chk(f"{k}: shape {a.shape}", True)
        chk(f"{k}: max |dequant - float32| <= 2^-31", err <= 2.0 ** -31 + 1e-18, f"max err {err:.3e}")
        chk(f"{k}: exact round-half-even match", bool((a == np.rint(src * SCALE).astype(np.int64)).all()))
    labs_ok = True
    for i, t in enumerate(eng.INTENT_TAXONOMY_64):
        rec = blob[off + i * LABEL_REC: off + (i + 1) * LABEL_REC]
        if rec[:24].rstrip(b"\0").decode() != t[1] or rec[24:].rstrip(b"\0").decode() != t[2]: labs_ok = False
    chk("64 label/family records match engine taxonomy", labs_ok)
    return res


def main():
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    for n in ("export", "verify"):
        p = sub.add_parser(n); p.add_argument("--checkpoint", required=True); p.add_argument("--engine", required=True)
        p.add_argument("--out" if n == "export" else "--blob", required=True)
    a = ap.parse_args()
    if a.cmd == "export":
        export(a.checkpoint, a.engine, a.out); return 0
    res = verify(a.checkpoint, a.engine, a.blob)
    for n, ok, dtl in res: print(("PASS  " if ok else "FAIL  ") + n + (f"  [{dtl}]" if dtl else ""))
    print(f"{sum(ok for _, ok, _ in res)}/{len(res)} export-verification checks passed")
    return 0 if all(ok for _, ok, _ in res) else 1


if __name__ == "__main__":
    sys.exit(main())
