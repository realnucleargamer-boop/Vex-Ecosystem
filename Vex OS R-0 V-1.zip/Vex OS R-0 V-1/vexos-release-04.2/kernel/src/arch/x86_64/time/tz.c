#include "tz.h"
static int leap(uint16_t y) { return (y % 4 == 0 && y % 100 != 0) || y % 400 == 0; }
static int dim(uint16_t y, uint8_t m) { static const uint8_t d[12] = {31,28,31,30,31,30,31,31,30,31,30,31}; return (m == 2 && leap(y)) ? 29 : d[m - 1]; }
void tz_utc_to_local(const RtcTime *u, RtcTime *o)
{
    *o = *u;
    int32_t mins = (int32_t)u->hour * 60 + u->minute + VEX_TZ_OFFSET_MIN;
    int32_t days = 0;
    while (mins >= 1440) { mins -= 1440; days++; }
    while (mins < 0)     { mins += 1440; days--; }
    o->hour = (uint8_t)(mins / 60); o->minute = (uint8_t)(mins % 60);
    while (days > 0) { if (++o->day > dim(o->year, o->month)) { o->day = 1; if (++o->month > 12) { o->month = 1; o->year++; } } days--; }
    while (days < 0) { if (--o->day < 1) { if (--o->month < 1) { o->month = 12; o->year--; } o->day = (uint8_t)dim(o->year, o->month); } days++; }
}
int tz_local_now(RtcTime *out) { RtcTime u; if (!rtc_read(&u)) return 0; tz_utc_to_local(&u, out); return 1; }
