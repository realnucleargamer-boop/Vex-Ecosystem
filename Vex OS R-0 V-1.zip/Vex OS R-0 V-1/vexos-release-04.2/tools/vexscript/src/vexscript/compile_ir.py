"""Compile VexScript source to validated Vex IR 0.1."""
from __future__ import annotations
from pathlib import Path
from .lexer import Lexer
from .parser import Parser
from .interpreter import Interpreter  # for module loading + typecheck
from .ir.emitter import emit_program
from .ir.validate import validate_module
from .ir.optimize import optimize_module
from .ir.text import module_to_text
from .ir.interpreter import run_module
from .ir.nodes import ModuleIR


def compile_to_ir(source: str, filename: str = "<input>") -> ModuleIR:
    interp = Interpreter()
    program = interp.load(source, filename)
    # collect module functions (qualified keys)
    extra = {
        k: v for k, v in interp.functions.items()
        if k != "main" and k in interp.exported
    }
    mod = emit_program(program, extra, enum_values=getattr(interp, 'enum_values', {}))
    mod.ir_version = "1.5"
    # attach struct layouts from program
    st = {}
    for s in getattr(program, "structs", []) or []:
        st[s.name] = [(f.name, f.type.name if f.type else "i64") for f in s.fields]
    mod.structs = st
    mod.calling_conv = "vex_hosted"
    # rewrite call targets math_mod::add -> math_mod_add if present
    for fn in mod.functions:
        for b in fn.blocks:
            for inst in list(b.instructions) + ([b.terminator] if b.terminator else []):
                if inst and inst.op == "call" and inst.extra and "::" in str(inst.extra):
                    extra = str(inst.extra)
                    if not extra.startswith("vex::"):
                        inst.extra = extra.replace("::", "_")
    validate_module(mod)
    optimize_module(mod)
    validate_module(mod)
    return mod


def emit_ir_text(source: str, filename: str = "<input>") -> str:
    return module_to_text(compile_to_ir(source, filename))


def run_via_ir(source: str, filename: str = "<input>") -> tuple[int, str]:
    mod = compile_to_ir(source, filename)
    return run_module(mod, "main")
