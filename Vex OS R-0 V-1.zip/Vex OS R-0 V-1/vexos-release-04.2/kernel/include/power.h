/*
 * Vex OS - kernel/include/power.h
 *
 * Platform power control: ACPI S5 soft-off and reset.
 *
 * WHAT IS REAL HERE
 *   power_init() walks RSDP -> XSDT/RSDT -> FACP (FADT) and the DSDT's \_S5_
 *   object and records the hardware registers that exist.  Nothing is assumed
 *   from the machine type: on QEMU q35 this resolves PM1a_CNT_BLK = 0x604 and
 *   the reset register = I/O 0xCF9 from the firmware tables themselves.
 *
 *   power_can_shutdown() / power_can_reboot() are true only if the tables
 *   were parsed and validated.  The UI disables an option whose capability
 *   is false instead of faking it.
 *
 * WHEN IT MUST BE CALLED
 *   power_init() dereferences firmware table physical addresses exactly as
 *   acpi_init() does, so it is called right after acpi_init() while the
 *   firmware mapping is still active.  After paging, power_shutdown() /
 *   power_reboot() touch I/O ports only.
 *
 * power_shutdown() and power_reboot() DO NOT RETURN on success.  They return
 * only on failure, with interrupts re-enabled to their previous state.
 */
#ifndef VEXOS_POWER_H
#define VEXOS_POWER_H
#include <stdint.h>

typedef struct {
    int      fadt_ok;            /* FACP found, checksum + length valid     */
    int      shutdown_ok;        /* PM1a_CNT + \_S5 SLP_TYP both validated  */
    int      reboot_ok;          /* ACPI reset reg (I/O) or i8042 present   */
    uint16_t pm1a_cnt;           /* I/O port, 0 if unknown                  */
    uint16_t pm1b_cnt;           /* I/O port, 0 if absent                   */
    uint8_t  slp_typa, slp_typb; /* from \_S5_                              */
    uint16_t smi_cmd;            /* 0 if none                               */
    uint8_t  acpi_enable;
    uint16_t reset_port;         /* ACPI RESET_REG I/O port, 0 if none      */
    uint8_t  reset_value;
    int      reboot_via_acpi;    /* 1 = ACPI reset reg, 0 = i8042 pulse     */
} PowerInfo;

/* Pure parsers - exposed so tests can feed them synthetic/hostile tables. */
int power_parse_s5(const uint8_t *dsdt, uint32_t len, uint8_t *typa, uint8_t *typb);
int power_parse_fadt(const uint8_t *fadt, uint32_t len, PowerInfo *out);   /* fields only; no DSDT */

/* Discover capabilities.  Never panics.  Returns shutdown_ok || reboot_ok. */
int  power_init(uint64_t rsdp_physical_address);
const PowerInfo *power_info(void);
int  power_can_shutdown(void);
int  power_can_reboot(void);
const char *power_shutdown_method(void);   /* human-readable, for the UI */
const char *power_reboot_method(void);

void power_shutdown(void);   /* returns only on failure */
void power_reboot(void);     /* returns only on failure */
#endif
