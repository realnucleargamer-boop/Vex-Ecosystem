# VexScript 2.0 Changelog (design release)

## Design delivered
- Full 2.0 language specification
- Module/import/pub model
- Vex OS API boundary (Handle-based stubs)
- UI/graphics API foundation (above compositor)
- Compiler pipeline + Vex IR 0.1 design
- Migration notes from 1.5
- Example sketches

## Implementation status
- 1.5 interpreter remains the executable runtime
- 2.0 features land incrementally (see roadmap Phase A–F)
- No fake kernel or compositor inside the language
