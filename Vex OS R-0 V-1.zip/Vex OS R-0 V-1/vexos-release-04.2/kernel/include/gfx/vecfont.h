/*
 * gfx/vecfont.h - GFX-VEC-01 vector font: DejaVu Sans Mono outlines (ASCII) rendered with the anti-aliased rasteriser.
 *
 * Two uses:
 *  - vf_draw_cell(): draws one character into an 8x16 terminal cell from a coverage cache built once from the outlines. It
 *    keeps the existing fixed-cell layout, so every existing gfx_draw_char/gfx_draw_str call becomes smooth with no layout change.
 *  - vf_draw_text(): arbitrary size and SUB-PIXEL position (Q24.8), rendered straight from the outlines.
 * Only printable ASCII (0x20..0x7E) has outlines; vf_has_glyph() lets callers fall back to the old bitmap font for the rest.
 * Not reentrant (shares vec.c's scratch path). Not for interrupt context.
 */
#ifndef VEXOS_GFX_VECFONT_H
#define VEXOS_GFX_VECFONT_H

#include "gfx/vec.h"

#define VF_CELL_W 8
#define VF_CELL_H 16
/* Cell font metrics (Q24.8 px): size gives an 8.00 px advance; the baseline sits 12.39 px below the cell top. Multiply by an integer scale. */
#define VF_CELL_SIZE_Q8   3402
#define VF_CELL_BASE_Q8   (12 * 256 + 100)

int  vf_has_glyph(int ch);
/* Draw one 8x16 cell: coverage blended fg-over-bg across all 128 pixels (same contract as the bitmap gfx_draw_char). */
int  vf_draw_cell(const GfxFb *fb, int px, int py, int ch, GfxColor fg, GfxColor bg);   /* 1 = drawn; 0 = declined (no outline, or cell not fully on screen): caller falls back */
/* Transparent version: blends the cached coverage over whatever is already in the framebuffer, clipped per pixel. */
void vf_blend_cell(const GfxFb *fb, int px, int py, int ch, GfxColor col, uint8_t alpha);
/* Pre-build the cache (otherwise built lazily on first use). Returns the number of glyphs cached. */
int  vf_cache_init(void);
/* Raw 8x16 coverage (0..255) of a glyph, or NULL if it has no outline. For tests. */
const uint8_t *vf_cell_coverage(int ch);

/* Text at an arbitrary size and sub-pixel baseline position. size = pixel em size (Q24.8). Returns the advance in Q24.8. */
vfx  vf_text_width(const char *s, vfx size);
vfx  vf_draw_text(const GfxFb *fb, vfx x, vfx baseline, vfx size, const char *s, const VecPaint *paint, const VecClip *clip);
/* Build the outline of one glyph at (x, baseline) into `p` (appends subpaths). */
void vf_glyph_path(VecPath *p, int ch, vfx size, vfx x, vfx baseline);

#endif
