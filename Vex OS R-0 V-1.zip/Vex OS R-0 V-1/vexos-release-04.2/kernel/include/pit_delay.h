/*
 * Vex OS - kernel/include/pit_delay.h
 *
 * BOOT-02C: short, real-time delays measured against the 8254 PIT.
 *
 * WHY THIS EXISTS AT ALL. The documented AP startup sequence requires
 * specific WALL-CLOCK waits (a ~10 ms gap after INIT, and ~200 us
 * between the two SIPIs). Vex OS has no timekeeping yet, and an
 * uncalibrated "spin N times" loop is not a substitute: N that is
 * correct on one machine is far too short on a faster one, and a too-
 * short INIT wait produces exactly the kind of intermittent, machine-
 * dependent AP startup failure that is worst to debug. The PIT runs at
 * a fixed, architecturally-known 1193182 Hz regardless of CPU speed,
 * which makes it the cheapest source of a trustworthy short delay at
 * this stage of the port.
 *
 * Channel 2 is used rather than channel 0 because channel 0 is wired to
 * IRQ0. Channel 2's output is only routed to the PC speaker, and its
 * state is readable by polling bit 5 of port 0x61, so it can be used
 * purely as a stopwatch without involving the interrupt controller -
 * which matters because interrupts are still entirely disabled here.
 * The speaker-enable bit is left clear, so nothing audible happens.
 *
 * LIMITATION, stated rather than hidden: this is a POLLED delay with no
 * interrupt involvement, and its accuracy has not been measured against
 * an independent clock. It is used only to satisfy minimum waits in the
 * startup sequence, where being somewhat too slow is harmless and being
 * too fast is not. It is not a general timekeeping facility.
 */

#ifndef VEXOS_PIT_DELAY_H
#define VEXOS_PIT_DELAY_H

#include <stdint.h>

/* The PIT input frequency is fixed by the PC architecture. */
#define PIT_FREQUENCY_HZ 1193182u

/* Maximum single delay: the counter is 16-bit, so one shot cannot span
 * more than 65535 ticks (~54.9 ms). Longer requests are split into
 * several shots. */
#define PIT_MAX_TICKS 0xFFFFu

/* Probes whether polled channel-2 delays actually work on this machine
 * (some environments do not emulate the port 0x61 status bit). Returns
 * 1 if usable. Must be called once before pit_delay_us(); if it returns
 * 0, pit_delay_us() falls back to a documented uncalibrated spin and
 * says so. */
int pit_delay_probe(void);

/* Busy-waits approximately `us` microseconds. Never enables
 * interrupts. */
void pit_delay_us(uint32_t us);

#endif /* VEXOS_PIT_DELAY_H */
