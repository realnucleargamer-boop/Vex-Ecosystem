"""VEX-Script 1.1 Parser"""

from __future__ import annotations
from .lexer import Token, TokenKind, Lexer
from .ast_nodes import *
from .errors import ParseError


class Parser:
    def __init__(self, tokens: list[Token], filename: str = "<input>"):
        self.tokens = tokens
        self.filename = filename
        self.pos = 0

    def _cur(self) -> Token:
        return self.tokens[self.pos] if self.pos < len(self.tokens) else self.tokens[-1]

    def _adv(self) -> Token:
        t = self._cur()
        if t.kind != TokenKind.EOF:
            self.pos += 1
        return t

    def _check(self, k: TokenKind) -> bool:
        return self._cur().kind == k

    def _match(self, *ks: TokenKind) -> Token | None:
        if self._cur().kind in ks:
            return self._adv()
        return None

    def _expect(self, k: TokenKind, msg: str | None = None) -> Token:
        if self._cur().kind == k:
            return self._adv()
        raise ParseError(msg or f"expected {k.name}, got {self._cur().kind.name}", self._cur().loc)

    def parse(self) -> Program:
        uses: list[Use] = []
        structs: list[StructDef] = []
        functions: list[Function] = []
        type_aliases: list[TypeAlias] = []
        enums: list[EnumDef] = []
        while not self._check(TokenKind.EOF):
            if self._check(TokenKind.USE) or self._check(TokenKind.IMPORT):
                uses.append(self._parse_use())
            elif self._check(TokenKind.STRUCT):
                structs.append(self._parse_struct())
            elif self._check(TokenKind.TYPE):
                type_aliases.append(self._parse_type_alias())
            elif self._check(TokenKind.ENUM):
                enums.append(self._parse_enum())
            elif self._check(TokenKind.FN) or self._check(TokenKind.PUB):
                functions.append(self._parse_fn())
            else:
                raise ParseError(f"unexpected {self._cur().kind.name}", self._cur().loc)
        loc = (functions[0].loc if functions else
               structs[0].loc if structs else self._cur().loc)
        return Program(
            loc=loc, uses=uses, structs=structs, functions=functions,
            type_aliases=type_aliases, enums=enums,
        )

    def _parse_struct(self) -> StructDef:
        loc = self._expect(TokenKind.STRUCT).loc
        name = str(self._expect(TokenKind.IDENT).value)
        self._expect(TokenKind.LBRACE)
        fields: list[StructField] = []
        while not self._check(TokenKind.RBRACE) and not self._check(TokenKind.EOF):
            fname = str(self._expect(TokenKind.IDENT).value)
            ftype = None
            if self._match(TokenKind.COLON):
                ftype = self._parse_type()
            self._match(TokenKind.COMMA)  # optional trailing comma
            # also allow semicolon between fields
            self._match(TokenKind.SEMI)
            fields.append(StructField(loc=loc, name=fname, type=ftype))
        self._expect(TokenKind.RBRACE)
        return StructDef(loc=loc, name=name, fields=fields)

    def _parse_type_alias(self) -> TypeAlias:
        loc = self._expect(TokenKind.TYPE).loc
        name = str(self._expect(TokenKind.IDENT).value)
        self._expect(TokenKind.ASSIGN)
        target = self._parse_type()
        self._expect(TokenKind.SEMI)
        return TypeAlias(loc=loc, name=name, target=target)

    def _parse_enum(self) -> EnumDef:
        loc = self._expect(TokenKind.ENUM).loc
        name = str(self._expect(TokenKind.IDENT).value)
        self._expect(TokenKind.LBRACE)
        variants: list[str] = []
        while not self._check(TokenKind.RBRACE) and not self._check(TokenKind.EOF):
            v = str(self._expect(TokenKind.IDENT).value)
            variants.append(v)
            self._match(TokenKind.COMMA)
            self._match(TokenKind.SEMI)
        self._expect(TokenKind.RBRACE)
        if not variants:
            raise ParseError("enum must have at least one variant", loc)
        return EnumDef(loc=loc, name=name, variants=variants)


    def _parse_use(self) -> Use:
        """Parse `import mod;` / `import vex::info;` / `import mod::{ a };` / `use ...`"""
        tok = self._adv()  # use or import
        if tok.kind not in (TokenKind.USE, TokenKind.IMPORT):
            raise ParseError("expected import or use", tok.loc, error_code="E0006")
        name_tok = self._expect(TokenKind.IDENT)
        parts = [str(name_tok.value)]
        items = None
        while self._match(TokenKind.COLONCOLON):
            if self._check(TokenKind.LBRACE):
                self._expect(TokenKind.LBRACE)
                items = []
                if not self._check(TokenKind.RBRACE):
                    items.append(str(self._expect(TokenKind.IDENT).value))
                    while self._match(TokenKind.COMMA):
                        items.append(str(self._expect(TokenKind.IDENT).value))
                self._expect(TokenKind.RBRACE)
                break
            parts.append(str(self._expect(TokenKind.IDENT).value))
        self._expect(TokenKind.SEMI)
        return Use(loc=tok.loc, module="::".join(parts), items=items)


    def _parse_fn(self) -> Function:
        exported = False
        if self._match(TokenKind.PUB):
            exported = True
        loc = self._expect(TokenKind.FN).loc
        name = str(self._expect(TokenKind.IDENT).value)
        self._expect(TokenKind.LPAREN)
        params: list[Param] = []
        if not self._check(TokenKind.RPAREN):
            params.append(self._parse_param())
            while self._match(TokenKind.COMMA):
                params.append(self._parse_param())
        self._expect(TokenKind.RPAREN)
        ret = None
        if self._match(TokenKind.ARROW):
            ret = self._parse_type()
        self._expect(TokenKind.LBRACE)
        body = self._parse_stmts()
        self._expect(TokenKind.RBRACE)
        return Function(loc=loc, name=name, params=params, return_type=ret, body=body, exported=exported)

    def _parse_param(self) -> Param:
        name_tok = self._expect(TokenKind.IDENT)
        typ = None
        if self._match(TokenKind.COLON):
            typ = self._parse_type()
        return Param(loc=name_tok.loc, name=str(name_tok.value), type=typ)

    def _parse_type(self) -> TypeNode:
        tok = self._cur()
        # pointer types: *T / *mut T
        if self._match(TokenKind.STAR):
            mut = bool(self._match(TokenKind.MUT))
            inner = self._parse_type()
            name = f"*mut {inner.name}" if mut else f"*{inner.name}"
            return TypeNode(loc=tok.loc, name=name)
        type_map = {
            TokenKind.I8: "i8", TokenKind.I16: "i16", TokenKind.I32: "i32", TokenKind.I64: "i64",
            TokenKind.U8: "u8", TokenKind.U16: "u16", TokenKind.U32: "u32", TokenKind.U64: "u64",
            TokenKind.F32: "f32", TokenKind.F64: "f64", TokenKind.BOOL: "bool",
            TokenKind.STRING_TYPE: "string",
        }
        if tok.kind == TokenKind.TENSOR:
            self._adv()
            self._expect(TokenKind.LT)
            # element type
            et = self._cur()
            if et.kind in type_map:
                self._adv()
                elem = type_map[et.kind]
            elif et.kind == TokenKind.IDENT:
                self._adv()
                elem = str(et.value)
            else:
                raise ParseError("expected tensor element type", et.loc)
            self._expect(TokenKind.COMMA)
            self._expect(TokenKind.LBRACKET)
            dims = []
            dims.append(str(self._expect(TokenKind.INT).value))
            while self._match(TokenKind.COMMA):
                dims.append(str(self._expect(TokenKind.INT).value))
            self._expect(TokenKind.RBRACKET)
            self._expect(TokenKind.GT)
            name = f"tensor<{elem}, [{', '.join(dims)}]>"
        elif tok.kind in type_map:
            self._adv()
            name = type_map[tok.kind]
        elif tok.kind == TokenKind.IDENT:
            self._adv()
            name = str(tok.value)
        else:
            raise ParseError("expected type", tok.loc)
        # array suffixes: T[] T[][]
        while self._match(TokenKind.LBRACKET):
            self._expect(TokenKind.RBRACKET)
            name = f"{name}[]"
        return TypeNode(loc=tok.loc, name=name)


    def _parse_stmts(self) -> list[Stmt]:
        stmts: list[Stmt] = []
        while not self._check(TokenKind.RBRACE) and not self._check(TokenKind.EOF):
            stmts.append(self._parse_stmt())
        return stmts

    def _parse_stmt(self) -> Stmt:
        if self._check(TokenKind.LET) or self._check(TokenKind.CONST):
            return self._parse_let()
        if self._check(TokenKind.RETURN):
            return self._parse_return()
        if self._check(TokenKind.IF):
            return self._parse_if()
        if self._check(TokenKind.WHILE):
            return self._parse_while()
        if self._check(TokenKind.MATCH):
            return self._parse_match()
        if self._check(TokenKind.MATCH):
            return self._parse_match()
        if self._check(TokenKind.FOR):
            return self._parse_for()
        if self._check(TokenKind.LOOP):
            return self._parse_loop()
        if self._check(TokenKind.BREAK):
            tok = self._adv()
            self._expect(TokenKind.SEMI)
            return Break(loc=tok.loc)
        if self._check(TokenKind.CONTINUE):
            tok = self._adv()
            self._expect(TokenKind.SEMI)
            return Continue(loc=tok.loc)
        if self._check(TokenKind.LBRACE):
            return self._parse_block()
        expr = self._parse_expr()
        self._expect(TokenKind.SEMI)
        return ExprStmt(loc=expr.loc, expr=expr)

    def _parse_let(self) -> Let:
        tok = self._adv()
        mutable = bool(self._match(TokenKind.MUT))
        name = str(self._expect(TokenKind.IDENT).value)
        typ = None
        if self._match(TokenKind.COLON):
            typ = self._parse_type()
        init = None
        if self._match(TokenKind.ASSIGN):
            init = self._parse_expr()
        self._expect(TokenKind.SEMI)
        return Let(loc=tok.loc, name=name, mutable=mutable, type=typ, init=init)

    def _parse_return(self) -> Return:
        tok = self._adv()
        val = None
        if not self._check(TokenKind.SEMI):
            val = self._parse_expr()
        self._expect(TokenKind.SEMI)
        return Return(loc=tok.loc, value=val)

    def _parse_if(self) -> If:
        tok = self._adv()
        self._expect(TokenKind.LPAREN)
        cond = self._parse_expr()
        self._expect(TokenKind.RPAREN)
        self._expect(TokenKind.LBRACE)
        then = self._parse_stmts()
        self._expect(TokenKind.RBRACE)
        els = None
        if self._match(TokenKind.ELSE):
            self._expect(TokenKind.LBRACE)
            els = self._parse_stmts()
            self._expect(TokenKind.RBRACE)
        return If(loc=tok.loc, cond=cond, then_body=then, else_body=els)

    def _parse_while(self) -> While:
        tok = self._adv()
        self._expect(TokenKind.LPAREN)
        cond = self._parse_expr()
        self._expect(TokenKind.RPAREN)
        self._expect(TokenKind.LBRACE)
        body = self._parse_stmts()
        self._expect(TokenKind.RBRACE)
        return While(loc=tok.loc, cond=cond, body=body)

    def _parse_match(self) -> Match:
        loc = self._expect(TokenKind.MATCH).loc
        # Require parentheses so `match s {` is not parsed as struct literal
        self._expect(TokenKind.LPAREN)
        expr = self._parse_expr()
        self._expect(TokenKind.RPAREN)
        self._expect(TokenKind.LBRACE)
        arms: list[MatchArm] = []
        while not self._check(TokenKind.RBRACE) and not self._check(TokenKind.EOF):
            if self._check(TokenKind.IDENT):
                tok = self._adv()
                pat = str(tok.value)
                while self._match(TokenKind.COLONCOLON):
                    pat = f"{pat}::{self._expect(TokenKind.IDENT).value}"
            elif self._check(TokenKind.INT):
                tok = self._adv()
                pat = str(int(tok.value))
            else:
                raise ParseError("expected match pattern", self._cur().loc)
            if not self._match(TokenKind.FATARROW):
                # allow -> as alternate
                if not self._match(TokenKind.ARROW):
                    raise ParseError("expected => after match pattern", self._cur().loc)
            self._expect(TokenKind.LBRACE)
            body = self._parse_stmts()
            self._expect(TokenKind.RBRACE)
            arms.append(MatchArm(loc=loc, pattern=pat, body=body))
            self._match(TokenKind.COMMA)
        self._expect(TokenKind.RBRACE)
        if not arms:
            raise ParseError("match requires at least one arm", loc)
        return Match(loc=loc, expr=expr, arms=arms)


    def _parse_for(self) -> For:
        tok = self._adv()
        self._expect(TokenKind.LPAREN)
        init = None
        if not self._check(TokenKind.SEMI):
            # only support let as init for simplicity
            if self._check(TokenKind.LET):
                init = self._parse_let()
                # for-loop index variables are mutable by default (1.1)
                if isinstance(init, Let):
                    init.mutable = True
            else:
                e = self._parse_expr()
                self._expect(TokenKind.SEMI)
                init = ExprStmt(loc=e.loc, expr=e)
        else:
            self._adv()  # skip ;
        cond = None
        if not self._check(TokenKind.SEMI):
            cond = self._parse_expr()
        self._expect(TokenKind.SEMI)
        step = None
        if not self._check(TokenKind.RPAREN):
            step = self._parse_expr()
        self._expect(TokenKind.RPAREN)
        self._expect(TokenKind.LBRACE)
        body = self._parse_stmts()
        self._expect(TokenKind.RBRACE)
        return For(loc=tok.loc, init=init, cond=cond, step=step, body=body)

    def _parse_loop(self) -> Loop:
        tok = self._adv()
        self._expect(TokenKind.LBRACE)
        body = self._parse_stmts()
        self._expect(TokenKind.RBRACE)
        return Loop(loc=tok.loc, body=body)

    def _parse_block(self) -> Block:
        tok = self._expect(TokenKind.LBRACE)
        body = self._parse_stmts()
        self._expect(TokenKind.RBRACE)
        return Block(loc=tok.loc, body=body)

    # expressions
    def _parse_expr(self) -> Expr:
        return self._parse_assign()

    def _parse_assign(self) -> Expr:
        left = self._parse_or()
        if self._match(TokenKind.ASSIGN):
            right = self._parse_assign()
            if isinstance(left, Name):
                return Assign(loc=left.loc, name=left.name, value=right)
            if isinstance(left, FieldAccess):
                return FieldAssign(loc=left.loc, obj=left.obj, field=left.field, value=right)
            if isinstance(left, Index):
                return IndexAssign(loc=left.loc, obj=left.obj, index=left.index, value=right)
            raise ParseError("assignment target must be a name, field, or index", left.loc)
        return left

    def _parse_or(self) -> Expr:
        left = self._parse_and()
        while True:
            op = self._match(TokenKind.OROR)
            if not op:
                break
            right = self._parse_and()
            left = Binary(loc=left.loc, op=op.kind, left=left, right=right)
        return left

    def _parse_and(self) -> Expr:
        left = self._parse_cmp()
        while True:
            op = self._match(TokenKind.ANDAND)
            if not op:
                break
            right = self._parse_cmp()
            left = Binary(loc=left.loc, op=op.kind, left=left, right=right)
        return left

    def _parse_cmp(self) -> Expr:
        left = self._parse_term()
        while True:
            op = self._match(TokenKind.EQ, TokenKind.NE, TokenKind.LT, TokenKind.LE, TokenKind.GT, TokenKind.GE)
            if not op:
                break
            right = self._parse_term()
            left = Binary(loc=left.loc, op=op.kind, left=left, right=right)
        return left

    def _parse_term(self) -> Expr:
        left = self._parse_factor()
        while True:
            op = self._match(TokenKind.PLUS, TokenKind.MINUS)
            if not op:
                break
            right = self._parse_factor()
            left = Binary(loc=left.loc, op=op.kind, left=left, right=right)
        return left

    def _parse_factor(self) -> Expr:
        left = self._parse_unary()
        while True:
            op = self._match(TokenKind.STAR, TokenKind.SLASH, TokenKind.PERCENT)
            if not op:
                break
            right = self._parse_unary()
            left = Binary(loc=left.loc, op=op.kind, left=left, right=right)
        return left

    def _parse_unary(self) -> Expr:
        op = self._match(TokenKind.MINUS, TokenKind.BANG)
        if op:
            return Unary(loc=op.loc, op=op.kind, operand=self._parse_unary())
        expr = self._parse_primary()
        while True:
            if self._match(TokenKind.AS):
                target = self._parse_type()
                expr = Cast(loc=expr.loc, expr=expr, target=target)
            elif self._match(TokenKind.LBRACKET):
                idx = self._parse_expr()
                self._expect(TokenKind.RBRACKET)
                expr = Index(loc=expr.loc, obj=expr, index=idx)
            else:
                break
        return expr

    def _parse_primary(self) -> Expr:
        tok = self._cur()
        if self._match(TokenKind.INT):
            return IntLit(loc=tok.loc, value=int(tok.value))
        if self._match(TokenKind.TRUE):
            return BoolLit(loc=tok.loc, value=True)
        if self._match(TokenKind.FALSE):
            return BoolLit(loc=tok.loc, value=False)
        if self._match(TokenKind.STRING):
            return StringLit(loc=tok.loc, value=str(tok.value))
        if self._match(TokenKind.LBRACKET):
            elems = []
            if not self._check(TokenKind.RBRACKET):
                elems.append(self._parse_expr())
                while self._match(TokenKind.COMMA):
                    elems.append(self._parse_expr())
            self._expect(TokenKind.RBRACKET)
            return ArrayLit(loc=tok.loc, elements=elems)
        if self._match(TokenKind.IDENT):
            name = str(tok.value)
            # qualified name: module::symbol or vex::info::os_name
            while self._match(TokenKind.COLONCOLON):
                member = str(self._expect(TokenKind.IDENT).value)
                name = f"{name}::{member}"
            # call
            if self._match(TokenKind.LPAREN):
                args: list[Expr] = []
                if not self._check(TokenKind.RPAREN):
                    args.append(self._parse_expr())
                    while self._match(TokenKind.COMMA):
                        args.append(self._parse_expr())
                self._expect(TokenKind.RPAREN)
                expr: Expr = Call(loc=tok.loc, name=name, args=args)
            # struct literal: Name { field: expr, ... }
            elif self._match(TokenKind.LBRACE):
                fields: list[tuple[str, Expr]] = []
                if not self._check(TokenKind.RBRACE):
                    while True:
                        fname = str(self._expect(TokenKind.IDENT).value)
                        self._expect(TokenKind.COLON)
                        fval = self._parse_expr()
                        fields.append((fname, fval))
                        if not self._match(TokenKind.COMMA):
                            break
                self._expect(TokenKind.RBRACE)
                expr = StructLit(loc=tok.loc, name=name, fields=fields)
            else:
                expr = Name(loc=tok.loc, name=name)
            # postfix field access / module.func call: obj.field or mod.func()
            while self._match(TokenKind.DOT):
                member = str(self._expect(TokenKind.IDENT).value)
                if self._match(TokenKind.LPAREN):
                    args = []
                    if not self._check(TokenKind.RPAREN):
                        args.append(self._parse_expr())
                        while self._match(TokenKind.COMMA):
                            args.append(self._parse_expr())
                    self._expect(TokenKind.RPAREN)
                    if isinstance(expr, Name) and "." not in expr.name and "::" not in expr.name:
                        expr = Call(loc=tok.loc, name=f"{expr.name}.{member}", args=args)
                    else:
                        raise ParseError("method calls not supported", tok.loc)
                else:
                    expr = FieldAccess(loc=tok.loc, obj=expr, field=member)
            return expr
        if self._match(TokenKind.LPAREN):
            e = self._parse_expr()
            self._expect(TokenKind.RPAREN)
            return e
        raise ParseError(f"unexpected {tok.kind.name}", tok.loc)
