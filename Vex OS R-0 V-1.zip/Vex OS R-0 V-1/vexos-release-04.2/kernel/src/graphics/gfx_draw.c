/*
 * Vex OS - kernel/src/graphics/gfx_draw.c
 *
 * Raster drawing primitives: clear, filled rect, outline, lines,
 * filled circle.  All clipped to framebuffer bounds.
 * No SSE/MMX.  No heap.  No static state.
 */

#include "gfx/draw.h"

void gfx_clear(const GfxFb *fb, GfxColor c)
{
    if (!fb || !fb->ok || !fb->pixels) return;
    uint32_t word = gfx_encode(fb, c);
    uint32_t h = fb->height;
    uint32_t w = fb->width;
    uint32_t p = fb->pitch_px;
    volatile uint32_t *row = fb->pixels;
    for (uint32_t y = 0; y < h; y++, row += p) {
        for (uint32_t x = 0; x < w; x++) {
            row[x] = word;
        }
    }
}

/* SECURITY-02 Graphics audit: all rectangle geometry is computed in
 * 64-bit. The previous version computed `x + w` and `y + h` in int32_t,
 * which is undefined behaviour on overflow in C - the compiler is
 * entitled to assume it cannot happen and may legally delete the
 * `x0 >= x1` guard that was the only thing standing between an
 * attacker-chosen (x, w) near INT32_MAX and a fill loop. int64 sums of
 * two int32 values cannot overflow, so the clip below is exact for every
 * input, including INT32_MIN/INT32_MAX in any combination. */
static void fill_rect64(const GfxFb *fb,
                        int64_t x, int64_t y, int64_t w, int64_t h,
                        GfxColor c)
{
    if (!fb || !fb->ok || !fb->pixels || w <= 0 || h <= 0) return;

    int64_t x0 = x < 0 ? 0 : x;
    int64_t y0 = y < 0 ? 0 : y;
    int64_t x1 = x + w; if (x1 > (int64_t)fb->width)  x1 = (int64_t)fb->width;
    int64_t y1 = y + h; if (y1 > (int64_t)fb->height) y1 = (int64_t)fb->height;
    if (x0 >= x1 || y0 >= y1) return;

    uint32_t word = gfx_encode(fb, c);
    uint32_t p    = fb->pitch_px;
    for (int64_t row = y0; row < y1; row++) {
        volatile uint32_t *line = fb->pixels + (uint32_t)row * p;
        for (int64_t col = x0; col < x1; col++) {
            line[col] = word;
        }
    }
}

void gfx_fill_rect(const GfxFb *fb,
                   int32_t x, int32_t y, int32_t w, int32_t h,
                   GfxColor c)
{
    fill_rect64(fb, x, y, w, h, c);
}

void gfx_hline(const GfxFb *fb,
               int32_t x, int32_t y, int32_t len, GfxColor c)
{
    gfx_fill_rect(fb, x, y, len, 1, c);
}

void gfx_vline(const GfxFb *fb,
               int32_t x, int32_t y, int32_t len, GfxColor c)
{
    gfx_fill_rect(fb, x, y, 1, len, c);
}

void gfx_rect_outline(const GfxFb *fb,
                      int32_t x, int32_t y, int32_t w, int32_t h,
                      GfxColor c)
{
    if (w <= 0 || h <= 0) return;
    /* 64-bit for the same reason as fill_rect64: y + h - 1 and
     * x + w - 1 overflowed int32_t for large inputs. */
    int64_t xr = (int64_t)x + w - 1;
    int64_t yb = (int64_t)y + h - 1;
    fill_rect64(fb, x,  y,  w, 1, c);
    fill_rect64(fb, x,  yb, w, 1, c);
    fill_rect64(fb, x,  y,  1, h, c);
    fill_rect64(fb, xr, y,  1, h, c);
}

void gfx_circle(const GfxFb *fb,
                int32_t cx, int32_t cy, int32_t r, GfxColor c)
{
    /* A radius beyond the largest framebuffer gfx_fb_init() accepts
     * (65536) is wider than any screen and would only feed the
     * incremental error terms below numbers large enough to overflow
     * int32_t. Refusing is correct: nothing visible is lost that a
     * clipped smaller circle would not already show. */
    if (r <= 0 || r > 65536) return;
    int32_t dx = r, dy = 0;
    int32_t err = 1 - r;
    while (dx >= dy) {
        fill_rect64(fb, (int64_t)cx - dx, (int64_t)cy + dy, 2 * (int64_t)dx + 1, 1, c);
        fill_rect64(fb, (int64_t)cx - dx, (int64_t)cy - dy, 2 * (int64_t)dx + 1, 1, c);
        fill_rect64(fb, (int64_t)cx - dy, (int64_t)cy + dx, 2 * (int64_t)dy + 1, 1, c);
        fill_rect64(fb, (int64_t)cx - dy, (int64_t)cy - dx, 2 * (int64_t)dy + 1, 1, c);
        dy++;
        if (err < 0) {
            err += 2 * dy + 1;
        } else {
            dx--;
            err += 2 * (dy - dx) + 1;
        }
    }
}
