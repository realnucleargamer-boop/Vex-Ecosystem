#!/bin/bash
# Multi-threaded TCG boot matrix (BOOT-03).
#
# Runs the BOOT-03 acceptance checks under "-accel tcg,thread=multi", where
# QEMU executes guest vCPUs in genuinely parallel host threads instead of
# serialising them. This is stronger concurrency evidence than the default
# single-threaded TCG used by scripts/smp-matrix.sh -- but it is NOT proof of
# race freedom, and docs/BOOT-03.md section 7 states exactly why: the host has
# only 2 vCPUs, MTTCG does not model real x86 memory ordering, and nothing in
# BOOT-03 contends the PMM/VMM locks in the first place (APs park before they
# allocate). Read that section before quoting these results.
#
# Each run is ended by its own timeout, because the kernel parks forever in
# "sti; hlt" after printing its summary. That is expected, not a failure.
#
# Usage: scripts/mttcg-matrix.sh      (no arguments; edit the loops to change)
cd /home/user/workspace/vexos/vexos
pass=0; total=0
for n in 2 4 8 16 32; do
  for r in 1 2 3; do
    total=$((total+1))
    V=$(mktemp); cp /usr/share/OVMF/OVMF_VARS_4M.fd "$V"
    L=build/mttcg-logs/mt-$n-$r.log
    timeout 100 qemu-system-x86_64 -machine q35 -accel tcg,thread=multi -cpu qemu64 \
      -smp $n -m 512M -no-reboot -display none \
      -drive if=pflash,format=raw,unit=0,readonly=on,file=/usr/share/OVMF/OVMF_CODE_4M.fd \
      -drive if=pflash,format=raw,unit=1,file="$V" \
      -drive format=raw,file=build/vexos.img -serial file:$L > build/mttcg-logs/mt-$n-$r.err 2>&1
    C=$(tr -d '\000' < $L | sed 's/\x1b\[[0-9;=]*[a-zA-Z]//g')
    ok=1
    echo "$C" | grep -q "BOOT SAGA COMPLETE" || ok=0
    echo "$C" | grep -q "SMP: ${n}/${n} CPUs online" || ok=0
    echo "$C" | grep -qE "^\[test\] .*: FAIL" && ok=0
    echo "$C" | grep -q "===== 105/105 checks passed =====" || ok=0
    if [ $ok -eq 1 ]; then echo "MTTCG PASS -smp $n run $r"; pass=$((pass+1));
    else echo "MTTCG FAIL -smp $n run $r"; fi
    rm -f "$V"
  done
done
echo "MTTCG RESULT: $pass/$total passed"
