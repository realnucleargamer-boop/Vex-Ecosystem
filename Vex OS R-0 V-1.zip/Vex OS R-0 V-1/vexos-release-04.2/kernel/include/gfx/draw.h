/*
 * Vex OS - kernel/include/gfx/draw.h
 *
 * Raster drawing primitives for BOOT-03's native graphics layer.
 * Every function operates on an already-initialised GfxFb and
 * produces no side effects beyond writing pixels and consuming stack.
 * No heap, no static state, no SSE.
 */

#ifndef VEXOS_GFX_DRAW_H
#define VEXOS_GFX_DRAW_H

#include <stdint.h>
#include "gfx/fb.h"

/* Fill the entire framebuffer with one colour. */
void gfx_clear(const GfxFb *fb, GfxColor c);

/* Filled axis-aligned rectangle, clipped to screen bounds. */
void gfx_fill_rect(const GfxFb *fb,
                   int32_t x, int32_t y, int32_t w, int32_t h,
                   GfxColor c);

/* One-pixel-wide rectangle outline, clipped. */
void gfx_rect_outline(const GfxFb *fb,
                      int32_t x, int32_t y, int32_t w, int32_t h,
                      GfxColor c);

/* Horizontal and vertical lines, clipped. */
void gfx_hline(const GfxFb *fb, int32_t x, int32_t y, int32_t len, GfxColor c);
void gfx_vline(const GfxFb *fb, int32_t x, int32_t y, int32_t len, GfxColor c);

/* Filled circle (midpoint algorithm), clipped. */
void gfx_circle(const GfxFb *fb, int32_t cx, int32_t cy, int32_t r, GfxColor c);

#endif /* VEXOS_GFX_DRAW_H */
