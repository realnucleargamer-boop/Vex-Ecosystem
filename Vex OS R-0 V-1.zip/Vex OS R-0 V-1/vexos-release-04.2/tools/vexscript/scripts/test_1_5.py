#!/usr/bin/env python3
"""VEX-Script 1.5 tests"""
import sys, io
from pathlib import Path
from contextlib import redirect_stdout

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vexscript.interpreter import Interpreter
from vexscript.errors import VexError

P = F = 0

def check(name, cond, detail=""):
    global P, F
    if cond:
        P += 1
        print(f"  PASS  {name}")
    else:
        F += 1
        print(f"  FAIL  {name}  {detail}")

def run(src, fn="<t>"):
    i = Interpreter()
    b = io.StringIO()
    with redirect_stdout(b):
        i.load(src, fn)
        c = i.run_main()
    return c, b.getvalue()

def ok(src, out, name):
    try:
        c, o = run(src)
        check(name, c == 0 and o == out, f"rc={c} out={o!r}")
    except VexError as e:
        check(name, False, str(e))

def fail(src, name, frag=None):
    try:
        run(src)
        check(name, False, "should reject")
    except VexError as e:
        m = str(e)
        check(name, frag is None or frag.lower() in m.lower(), m)

print("VEX-Script 1.5 Test Suite")

print("\n=== Casts ===")
ok("""
fn main() -> i32 {
    let x: i64 = 100;
    let y: i32 = x as i32;
    if (y == 100) { println(1); }
    return 0;
}
""", "1\n", "i64 to i32 cast")
ok("""
fn main() -> i32 {
    let x: i32 = 5;
    let y: i64 = x as i64;
    println(y);
    return 0;
}
""", "5\n", "i32 to i64 cast")
fail("""
fn main() -> i32 {
    let x: bool = true;
    let y: i64 = x as i64;
    return 0;
}
""", "forbid bool to i64 cast", "invalid cast")
fail("""
fn main() -> i32 {
    let x: i64 = 3000000000;
    let y: i32 = x as i32;
    return 0;
}
""", "i32 range check", "out of range")

print("\n=== Control flow typing ===")
fail("""
fn main() -> i32 {
    if (42) { return 0; }
    return 0;
}
""", "reject int if condition", "bool")
fail("""
fn main() -> i32 {
    while (1) { break; }
    return 0;
}
""", "reject int while condition", "bool")
ok("""
fn main() -> i32 {
    if (true) { println(1); }
    return 0;
}
""", "1\n", "bool if ok")

print("\n=== Return paths ===")
fail("""
fn main() -> i32 {
    let x: i64 = 1;
}
""", "missing return", "return")
ok("""
fn main() -> i32 {
    if (true) { return 0; } else { return 1; }
}
""", "", "if else both return")

print("\n=== Types ===")
fail("fn main() -> i32 { let x: i64 = true; return 0; }", "let mismatch", "type mismatch")
fail("fn main() -> i32 { let x: bool = 42; return 0; }", "bool from int", "type mismatch")

print("\n=== Function values foundation ===")
ok("""
fn add(a: i64, b: i64) -> i64 { return a + b; }
fn main() -> i32 {
    let f = add;
    println(f(3, 4));
    return 0;
}
""", "7\n", "function value call")

print("\n=== Stdlib ===")
ok("""
fn main() -> i32 {
    println(str_len("abc"));
    println(abs(0 - 9));
    return 0;
}
""", "3\n9\n", "str_len and abs")

print("\n=== Modules still isolated ===")
try:
    c, o = run(Path(ROOT/"examples/use_math.vex").read_text(), str(ROOT/"examples/use_math.vex"))
    check("qualified module path", c == 0 and "25" in o and "30" in o, o)
except VexError as e:
    check("qualified module path", False, str(e))
except VexError as e:
    check("qualified module path", False, str(e))

print(f"\n=== 1.5 Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
