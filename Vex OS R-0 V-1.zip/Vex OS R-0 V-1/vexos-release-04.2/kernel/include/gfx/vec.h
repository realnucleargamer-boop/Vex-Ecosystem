/*
 * gfx/vec.h - GFX-VEC-01: anti-aliased vector graphics with sub-pixel coordinates.
 *
 * COORDINATES. All coordinates are vfx = Q24.8 fixed point (1/256 pixel resolution, range +-2^22 px). This is the
 * "fractional coordinate" system. It is deliberately NOT hardware floating point: the kernel is built with -mno-sse and
 * does not save/restore FPU/SSE state across interrupts, so using the FPU in kernel code would silently corrupt
 * user/kernel state. Fixed point is also what FreeType/AGG use internally, and it is deterministic.
 *
 * ANTI-ALIASING. Fills use exact-area coverage (signed-area accumulation per pixel row), not supersampling: a pixel's
 * alpha is the true fraction of the pixel the shape covers (to ~1/256), computed analytically for straight edges.
 * Curves (quadratic/cubic Bezier) are flattened to within ~0.1 px first.
 *
 * FILL RULES. Non-zero (default) and even-odd. Overlapping same-direction pieces are clamped to full coverage, which
 * is what makes the stroker's union-of-pieces correct.
 *
 * LIMITS (all enforced; violations return -1 and draw nothing, never overflow):
 *   - at most VEC_MAX_PTS points and VEC_MAX_SUBPATHS subpaths per path (curves count their flattened points);
 *   - a shape wider than VEC_MAX_W pixels is rejected (callers fall back to the aliased primitives);
 *   - rows are clipped to the clip rectangle / framebuffer before any work, so cost is bounded by the visible height.
 *
 * STROKE ACCURACY DOMAIN (measured in tests/vec_host_test.py): single lines, polylines with turns <= 120 degrees whose segments are
 * at least 1.2 stroke-widths long, and closed outlines whose interior is wider than the stroke are within ~5/255 of the exact offset
 * geometry (rounded-rectangle and circle outlines: <= 14/255). Outside that domain (hairpin turns, strokes wider than the shape
 * is thick) the outline overlaps itself and a few pixels can be wrong by up to ~40%, or a too-thin shape can show a hole. Joins are
 * round (round=1) or bevel (round=0); there are no miter limits/dashes.
 *
 * NOT REENTRANT: the convenience functions share one static scratch path. Do not call from interrupt context.
 * No heap, no libc, no floating point.
 */
#ifndef VEXOS_GFX_VEC_H
#define VEXOS_GFX_VEC_H

#include <stdint.h>
#include "gfx/fb.h"

typedef int32_t vfx;                                   /* Q24.8 */
#define VFX_ONE        256
#define VFX_INT(n)     ((vfx)((int32_t)(n) * 256))
#define VFX_FRAC(n, d) ((vfx)(((int64_t)(n) * 256) / (d)))     /* VFX_FRAC(5, 2) == 2.5 px */

#define VEC_MAX_PTS       1024
#define VEC_MAX_SUBPATHS  128
#define VEC_MAX_W         2560

typedef struct {
    vfx      x[VEC_MAX_PTS], y[VEC_MAX_PTS];
    uint16_t sub_start[VEC_MAX_SUBPATHS];
    uint8_t  sub_closed[VEC_MAX_SUBPATHS];
    uint16_t npts, nsub;
    vfx      cx, cy;           /* current point */
    int      need_move;        /* after close: next line_to starts a new subpath at (cx,cy) */
    int      err;              /* sticky: a capacity limit was hit; fills of this path are refused */
} VecPath;

typedef struct { int32_t x0, y0, x1, y1; } VecClip;    /* pixel rectangle [x0,x1) x [y0,y1) */

typedef struct {
    GfxColor c0, c1;           /* c0 everywhere, or c0 -> c1 from gy0 to gy1 when vgrad is set */
    uint8_t  alpha;            /* 0..255 global opacity */
    int      vgrad;
    vfx      gy0, gy1;
} VecPaint;

static inline VecPaint vec_solid(GfxColor c, uint8_t alpha)
{
    VecPaint p; p.c0 = c; p.c1 = c; p.alpha = alpha; p.vgrad = 0; p.gy0 = 0; p.gy1 = 0; return p;
}
static inline VecPaint vec_vgradient(GfxColor top, GfxColor bottom, vfx y_top, vfx y_bottom, uint8_t alpha)
{
    VecPaint p; p.c0 = top; p.c1 = bottom; p.alpha = alpha; p.vgrad = 1; p.gy0 = y_top; p.gy1 = y_bottom; return p;
}

/* Master switch for every UI/text call site that has both an anti-aliased and an aliased implementation (default ON).
 * The vector API itself is unaffected; this lets the UI be compared A/B and gives an instant fallback. */
void vec_set_aa(int on);
int  vec_aa(void);

/* ---- path construction (curves are flattened as they are added) ---- */
void vec_path_begin(VecPath *p);
void vec_move_to(VecPath *p, vfx x, vfx y);
void vec_line_to(VecPath *p, vfx x, vfx y);
void vec_quad_to(VecPath *p, vfx cx, vfx cy, vfx x, vfx y);
void vec_cubic_to(VecPath *p, vfx c1x, vfx c1y, vfx c2x, vfx c2y, vfx x, vfx y);
void vec_close(VecPath *p);
void vec_add_ellipse(VecPath *p, vfx cx, vfx cy, vfx rx, vfx ry);
void vec_add_rrect(VecPath *p, vfx x, vfx y, vfx w, vfx h, vfx rx, vfx ry);

/* ---- rasterisation ---- */
/* Fill `p` into the framebuffer. clip may be NULL (whole framebuffer). 0 = drawn, -1 = refused (see LIMITS). */
int vec_fill(const GfxFb *fb, const VecPath *p, int evenodd, const VecPaint *paint, const VecClip *clip);
/* Rasterise into an 8-bit coverage mask of w*h bytes (origin = path origin). Used for glyph caches and tests. */
int vec_mask(const VecPath *p, int evenodd, int w, int h, uint8_t *out);
/* Outline `in` into `out` as filled geometry of the given stroke width: round joins/caps when round != 0, otherwise
 * butt caps and bevel (no) joins. Fill `out` with the NON-ZERO rule. 0 = ok, -1 = capacity exceeded. */
int vec_stroke_path(const VecPath *in, vfx width, int round, VecPath *out);
int vec_stroke(const GfxFb *fb, const VecPath *p, vfx width, int round, const VecPaint *paint, const VecClip *clip);

/* ---- convenience (use the shared static scratch path) ---- */
VecPath *vec_scratch(void);
int vec_fill_rrect(const GfxFb *fb, vfx x, vfx y, vfx w, vfx h, vfx r, const VecPaint *paint, const VecClip *clip);
int vec_stroke_rrect(const GfxFb *fb, vfx x, vfx y, vfx w, vfx h, vfx r, vfx width, const VecPaint *paint, const VecClip *clip);
int vec_fill_ellipse(const GfxFb *fb, vfx cx, vfx cy, vfx rx, vfx ry, const VecPaint *paint, const VecClip *clip);
int vec_line(const GfxFb *fb, vfx x0, vfx y0, vfx x1, vfx y1, vfx width, int round, const VecPaint *paint, const VecClip *clip);

#endif /* VEXOS_GFX_VEC_H */
