/* Vex OS - kernel/include/keymap.h : US-layout translation of INPUT-02 key codes (HID usage) to 7-bit ASCII.
 * Scope: US QWERTY, ASCII only, Shift honoured, Caps Lock NOT tracked, no Unicode, no dead keys. */
#ifndef VEXOS_KEYMAP_H
#define VEXOS_KEYMAP_H
#include <stdint.h>
int vex_key_ascii(uint16_t key, uint16_t modifiers);   /* 32..126, or 0 if the key has no printable value */
#endif
