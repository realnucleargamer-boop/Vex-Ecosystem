#!/usr/bin/env python3
"""VexScript 3.0-C — neural linear / ReLU / forward"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vexscript import __version__, __ir_version__
from vexscript.interpreter import Interpreter
from vexscript.compile_ir import run_via_ir
from vexscript.tensor_rt import (
    tensor_create, tensor_fill, tensor_set, neural_relu, neural_linear, neural_forward_2layer, tensor_get,
)

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

print("VexScript 3.0-C")
check("version 3.0-c", __version__.startswith("3.0.0"), __version__)
check("ir 1.4", __ir_version__ == "1.4", __ir_version__)

# pure python neural
t = tensor_fill(tensor_create("f32", 4), -1.0)
t.data[1] = 2.0
t.data[3] = 0.5
r = neural_relu(t)
check("relu", r.data == [0.0, 2.0, 0.0, 0.5], r.data)

x = tensor_fill(tensor_create("f32", 1, 2), 1.0)
w = tensor_fill(tensor_create("f32", 2, 2), 1.0)
y = neural_linear(x, w, None)
check("linear", y.shape == (1, 2) and y.data[0] == 2.0, (y.shape, y.data))

# 2-layer: identity-ish
x = tensor_fill(tensor_create("f32", 2), 1.0)
w1 = tensor_create("f32", 2, 2)
tensor_set(w1, 1.0, 0, 0); tensor_set(w1, 0.0, 0, 1)
tensor_set(w1, 0.0, 1, 0); tensor_set(w1, 1.0, 1, 1)
b1 = tensor_fill(tensor_create("f32", 2), 0.0)
w2 = tensor_fill(tensor_create("f32", 2, 1), 1.0)
b2 = tensor_fill(tensor_create("f32", 1), 0.0)
out = neural_forward_2layer(x, w1, b1, w2, b2)
check("forward_2", abs(out.data[0] - 2.0) < 1e-6, out.data)

src = '''
fn main() -> i32 {
    let x = tensor_create_2(1, 2);
    tensor_fill(x, 1);
    let w = tensor_create_2(2, 2);
    tensor_fill(w, 1);
    let y = neural_linear(x, w);
    println(tensor_get_2(y, 0, 0));
    let z = neural_relu(y);
    println(tensor_get_2(z, 0, 0));
    return 0;
}
'''
i = Interpreter()
i.load(src, "t")
code = i.run_main()
check("ast neural", code == 0 and i.output[0] in ("2", "2.0") and i.output[1] in ("2", "2.0"), i.output)

code, out = run_via_ir(src)
check("ir neural", code == 0 and "2" in out, out)

# 2.0+++ compat
src2 = 'fn main() -> i32 { println(1 + 2); return 0; }\n'
code, out = run_via_ir(src2)
check("compat arith", code == 0 and "3" in out, out)

print(f"\n=== 3.0-C Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
