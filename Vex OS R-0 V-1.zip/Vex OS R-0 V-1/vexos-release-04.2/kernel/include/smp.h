/*
 * Vex OS - kernel/include/smp.h
 *
 * BOOT-02C: real secondary CPU (AP) startup.
 *
 * Takes the CPU list ACPI/MADT discovered in BOOT-02B and actually
 * brings those CPUs up, moving Vex OS from "1/N CPUs online" to
 * "N/N CPUs online".
 *
 * SCOPE, and what is deliberately NOT here:
 *   * No scheduler, no per-CPU task state, no cross-CPU IPI messaging.
 *   * No interrupts on APs. APs never execute `sti`. They share the
 *     BSP's IDT so that a fault produces a diagnostic instead of a
 *     triple fault, but no interrupt source is unmasked for them.
 *   * No new paging architecture. APs adopt the BSP's CR3.
 *   * APs are parked in a halt loop once they have reported in. Giving
 *     them work is a later milestone.
 */

#ifndef VEXOS_SMP_H
#define VEXOS_SMP_H

#include <stdint.h>
#include "acpi.h"
#include "bootinfo.h"
#include "efi_memmap.h"

/* ------------------------------------------------------------------ *
 * Trampoline data-block layout.
 *
 * These offsets are a HARD CONTRACT with the D_* defines in
 * kernel/src/arch/x86_64/smp/ap_trampoline.asm. That file is assembled
 * separately as a flat binary, so the linker cannot catch a mismatch -
 * if these two lists ever drift, the AP will load garbage into RSP and
 * fail in a way that is genuinely painful to debug. Change both, or
 * neither.
 * ------------------------------------------------------------------ */
#define VEX_TRAMPOLINE_SIZE       4096

#define VEX_TRAMPOLINE_DATA_OFF   0xF00
#define VEX_TRAMPOLINE_OFF_CR3    (VEX_TRAMPOLINE_DATA_OFF + 0x00)
#define VEX_TRAMPOLINE_OFF_ENTRY  (VEX_TRAMPOLINE_DATA_OFF + 0x08)
#define VEX_TRAMPOLINE_OFF_RSP    (VEX_TRAMPOLINE_DATA_OFF + 0x10)
#define VEX_TRAMPOLINE_OFF_ARG    (VEX_TRAMPOLINE_DATA_OFF + 0x18)
#define VEX_TRAMPOLINE_OFF_ACK    (VEX_TRAMPOLINE_DATA_OFF + 0x20)
#define VEX_TRAMPOLINE_OFF_BASE   (VEX_TRAMPOLINE_DATA_OFF + 0x24)

/* Written by an AP, in AP C code, as proof that the AP really executed
 * kernel C code rather than merely having a SIPI accepted. Checked by
 * the BSP before any CPU is reported ONLINE. */
#define VEX_AP_ALIVE_MAGIC 0x5645583041504cULL   /* "VEX0APL" */

/* Per-CPU state. One entry per MADT processor entry, indexed by the
 * same index, so diagnostics can always name the CPU that failed. */
typedef enum {
    CPU_STATE_UNKNOWN = 0,
    CPU_STATE_BSP,             /* this is the bootstrap processor */
    CPU_STATE_SKIPPED,         /* MADT says the CPU is not enabled */
    CPU_STATE_STARTING,        /* INIT-SIPI-SIPI sent, not yet reported */
    CPU_STATE_ONLINE,          /* reached AP C code and identified itself */
    CPU_STATE_FAILED_TIMEOUT,  /* never reported in before the deadline */
    CPU_STATE_FAILED_IDENTITY  /* reported in, but its APIC ID was wrong */
} CpuState;

typedef struct {
    volatile uint64_t alive_magic;   /* AP writes VEX_AP_ALIVE_MAGIC */
    volatile uint32_t reported_apic_id; /* APIC ID the AP read itself */
    volatile uint32_t reached_c_code;   /* AP writes 1 */
    uint32_t expected_apic_id;       /* what the MADT claimed */
    uint32_t processor_id;
    uint64_t stack_top;
    CpuState state;

    /* BOOT-03 additions, all written by the AP itself and read by the
     * BSP after the alive_magic handshake.
     *
     * reported_cr3 is the load-bearing one: it is the ONLY way to know
     * that an AP is executing under the kernel's page tables rather than
     * whatever the trampoline left in CR3. "SMP still works after we
     * enabled paging" is otherwise an assumption, since an AP running on
     * the firmware tables would look identical in every other respect
     * until the moment it touched something only the kernel tables map. */
    volatile uint64_t reported_cr3;
    volatile uint32_t percpu_ok;     /* AP verified its own %gs:0 block */
    volatile uint32_t percpu_index;  /* index the AP believes it is */

    /* KERNEL-01 Phase 1 additions, same pattern: written by the AP
     * itself, read by the BSP after the handshake.
     *
     * The BSP can read the per-CPU TSS array directly - it built it - so
     * it does not need the AP's help to know what IST1 was CONFIGURED
     * to be. What it cannot see from the outside is whether a given AP
     * actually executed `ltr` and is now holding a task register. That
     * is a per-logical-processor register; only the AP can read it.
     *
     * reported_tr is therefore the load-bearing field: it is the AP's
     * own `str` result, and it is the difference between "we wrote code
     * that calls tss_load" and "this CPU is holding this TSS".
     *
     * reported_ist1 is the IST1 value the AP read back out of the TSS
     * the hardware is pointing at, which is what closes the loop between
     * "CPU n's TSS has a distinct stack" and "CPU n is using CPU n's
     * TSS". A zero here means no usable double-fault stack. */
    volatile uint32_t reported_tr;   /* AP's own `str` result (0 = none) */
    volatile uint64_t reported_ist1; /* IST1 in the TSS this CPU loaded */

    /* KERNEL-01 Phase 2 additions, same pattern again.
     *
     * reported_svr is the AP's own read-back of its Spurious Interrupt
     * Vector Register after calling lapic_enable_on_this_cpu(). Bit 8 set
     * means that CPU's LAPIC is software enabled and can therefore
     * receive fixed-delivery interrupts. This is the field that separates
     * "we called the enable function" from "this CPU's LAPIC is enabled":
     * SVR is per-logical-processor, so the BSP cannot read it for an AP.
     *
     * reported_rflags is the AP's own `pushfq` result taken AFTER `sti`.
     * Bit 9 (IF) set is the only direct evidence that a given AP is
     * actually interruptible, as opposed to sitting in `hlt` with
     * interrupts masked - which looks identical from the outside and is
     * exactly the state in which a TLB shootdown would never be
     * acknowledged.
     *
     * ORDERING REQUIREMENT: both must be published BEFORE the AP sets
     * alive_magic / reached_c_code, because the BSP treats that handshake
     * as the point at which this CPU's fields are readable. Publishing
     * after would be a race in which the BSP could read zeros from a CPU
     * that is in fact fine. */
    volatile uint32_t reported_svr;    /* AP's own SVR read-back */
    volatile uint64_t reported_rflags; /* AP's own RFLAGS after sti */
    volatile uint32_t tss_ok;        /* AP's gdt_load_on_this_cpu() result */
} CpuInfo;

typedef struct {
    uint32_t cpu_count;              /* MADT entries considered */
    uint32_t online_count;           /* CPUs actually online, incl. BSP */
    uint32_t failed_count;
    uint32_t bsp_apic_id;
    uint64_t trampoline_phys;        /* low page the trampoline was put in */
    int      started;                /* 1 if startup was attempted at all */
    CpuInfo  cpus[ACPI_MAX_CPUS];
} SmpInfo;

/* Brings up every enabled AP the MADT lists, one at a time, and fills
 * `out` with the per-CPU outcome. Prints its own progress and
 * diagnostics to serial.
 *
 * Returns 1 if every enabled AP came online, 0 otherwise. A return of 0
 * is NOT fatal and never hangs: failed CPUs are reported individually
 * as FAILED with a reason, and the BSP continues.
 *
 * `info` supplies the EFI memory map, which is needed to find a
 * conventional page below 1 MiB for the trampoline (the PMM cannot
 * supply one - it deliberately ignores memory below 1 MiB). */
int smp_start_aps(BootInfo *info, const AcpiInfo *acpi, uint32_t bsp_apic_id,
                  SmpInfo *out);

/* Human-readable name for a CpuState, for diagnostics. */
const char *smp_state_name(CpuState s);

#endif /* VEXOS_SMP_H */
