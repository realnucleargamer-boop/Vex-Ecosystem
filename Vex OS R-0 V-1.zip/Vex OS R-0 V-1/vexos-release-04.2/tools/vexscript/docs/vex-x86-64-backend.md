# Vex x86-64 Backend

## Strategy
- Stack slots for SSA values and `L_*` locals (`load_local`/`store_local`)
- No optimizing register allocator (correctness first)
- Branches: `jmp` / `cmp`+`jne`
- Calls: System V, callee name with `::` → `_`

## Dependencies
GNU `as` / `gcc` on the host. Explicit error if link fails (E0505).
