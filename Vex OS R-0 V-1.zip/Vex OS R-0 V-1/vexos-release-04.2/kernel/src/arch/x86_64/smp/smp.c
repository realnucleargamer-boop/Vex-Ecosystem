/*
 * Vex OS - kernel/src/arch/x86_64/smp/smp.c
 *
 * BOOT-02C: brings the secondary CPUs (APs) online.
 *
 * See kernel/include/smp.h for scope, and docs/BOOT-02C.md for the
 * design rationale and the measured QEMU results.
 */

#include "smp.h"
#include "acpi.h"
#include "bootinfo.h"
#include "efi_memmap.h"
#include "gdt.h"
#include "idt.h"
#include "lapic.h"
#include "pit_delay.h"
#include "pmm.h"
#include "ap_stack.h"
#include "percpu.h"
#include "serial.h"

extern const uint8_t ap_trampoline_blob_start[];
extern const uint8_t ap_trampoline_blob_end[];

/* ------------------------------------------------------------------ *
 * Shared state between the BSP and a starting AP.
 *
 * Only ONE AP is ever in flight at a time (see the comment on the
 * startup loop), so a single "currently starting" slot is sufficient
 * and there is no need for per-CPU trampoline data blocks.
 * ------------------------------------------------------------------ */
static SmpInfo *g_smp;                       /* set before any AP starts */
static volatile uint32_t g_online_counter;   /* incremented by APs */
static uint64_t g_lapic_base;

/* ------------------------------------------------------------------ *
 * Small atomic helpers.
 *
 * Written with GCC/Clang builtins rather than hand-rolled `lock`
 * assembly so both supported toolchains generate the same thing, and so
 * the memory ordering is stated explicitly instead of being implied by
 * x86's relatively strong model. The orderings below are chosen to be
 * correct on a weaker model too, which costs nothing on x86 and avoids
 * baking in an assumption that would silently break if this code were
 * ever reused.
 * ------------------------------------------------------------------ */
static inline uint32_t atomic_load_u32(const volatile uint32_t *p)
{
    return __atomic_load_n(p, __ATOMIC_ACQUIRE);
}

static inline void atomic_store_u32(volatile uint32_t *p, uint32_t v)
{
    __atomic_store_n(p, v, __ATOMIC_RELEASE);
}

static inline uint64_t atomic_load_u64(const volatile uint64_t *p)
{
    return __atomic_load_n(p, __ATOMIC_ACQUIRE);
}

static inline void atomic_store_u64(volatile uint64_t *p, uint64_t v)
{
    __atomic_store_n(p, v, __ATOMIC_RELEASE);
}

static inline uint32_t atomic_inc_u32(volatile uint32_t *p)
{
    return __atomic_add_fetch(p, 1, __ATOMIC_ACQ_REL);
}

static inline uint64_t read_cr3(void)
{
    uint64_t v;
    __asm__ volatile ("mov %%cr3, %0" : "=r"(v));
    return v;
}

const char *smp_state_name(CpuState s)
{
    switch (s) {
    case CPU_STATE_BSP:              return "ONLINE (BSP)";
    case CPU_STATE_SKIPPED:          return "SKIPPED (not enabled in MADT)";
    case CPU_STATE_STARTING:         return "STARTING";
    case CPU_STATE_ONLINE:           return "ONLINE";
    case CPU_STATE_FAILED_TIMEOUT:   return "FAILED (timeout - never reported in)";
    case CPU_STATE_FAILED_IDENTITY:  return "FAILED (APIC ID mismatch)";
    default:                         return "UNKNOWN";
    }
}

/* ------------------------------------------------------------------ *
 * Low-memory trampoline page.
 *
 * The PMM cannot be used for this. It deliberately ignores everything
 * below 1 MiB (see pmm.c) and hands out pages from a single arena high
 * in memory - but a SIPI vector is only 8 bits, so the trampoline MUST
 * live at a 4 KiB-aligned physical address below 1 MiB. Rather than
 * teaching the bump allocator about low memory (which would change
 * BOOT-02A behaviour that currently works), this walks the EFI memory
 * map directly and picks one conventional page.
 *
 * The page is never returned; one 4 KiB page held for the lifetime of
 * the kernel is an acceptable cost, and freeing it would mean the
 * trampoline's own GDT could vanish from under an AP that is still
 * mid-transition.
 * ------------------------------------------------------------------ */
static uint64_t find_low_trampoline_page(BootInfo *info)
{
    /* Avoid the very first page (0x0000-0x0FFF). Real-mode structures
     * such as the IVT and BDA live there, and while nothing in Vex OS
     * uses them today, firmware and SMM code may. It is one page. */
    const uint64_t min_addr = 0x1000ULL;
    const uint64_t max_addr = 0x100000ULL;   /* SIPI vector limit */

    uint8_t *desc = (uint8_t *)(uintptr_t)info->memory_map;
    uint8_t *end  = desc + info->memory_map_size;

    /* The descriptor stride comes from the firmware, NOT from
     * sizeof(EfiMemoryDescriptor) - the spec allows it to be larger
     * than the structure this kernel knows about. */
    uint64_t stride = info->memory_map_desc_size;
    if (stride == 0) {
        return 0;
    }

    uint64_t best = 0;

    while (desc + stride <= end) {
        EfiMemoryDescriptor *d = (EfiMemoryDescriptor *)desc;

        if (d->Type == EFI_MEM_TYPE_CONVENTIONAL && d->NumberOfPages > 0) {
            uint64_t start = d->PhysicalStart;
            uint64_t stop  = start + d->NumberOfPages * 4096ULL;

            /* Clip the region to the usable low window. */
            if (start < min_addr) {
                start = min_addr;
            }
            if (stop > max_addr) {
                stop = max_addr;
            }

            /* Align up to a page boundary. */
            start = (start + 0xFFFULL) & ~0xFFFULL;

            if (start + 4096ULL <= stop) {
                /* Prefer the HIGHEST qualifying page. Very low memory is
                 * more likely to be quietly used by firmware or legacy
                 * emulation, so staying near the top of the window is
                 * the safer of two arbitrary choices. */
                uint64_t candidate = (stop - 4096ULL) & ~0xFFFULL;
                if (candidate >= start && candidate > best) {
                    best = candidate;
                }
            }
        }
        desc += stride;
    }

    return best;
}

/* ------------------------------------------------------------------ *
 * AP C entry point.
 *
 * Reached from the trampoline with a valid 64-bit stack and the BSP's
 * CR3 already loaded. `cpu_index` is the index into g_smp->cpus that
 * the BSP put in the trampoline's argument slot.
 *
 * Deliberately does NOT print anything. The BSP prints on the AP's
 * behalf after it observes the handshake. serial.c has no locking, and
 * adding a serial spinlock purely so APs can each emit one line would
 * add a synchronization primitive - and a new deadlock risk on the one
 * output path used to debug everything else - for no diagnostic gain.
 * Every value the BSP prints about an AP is a value the AP itself
 * wrote, so the evidence is equally strong either way.
 * ------------------------------------------------------------------ */
__attribute__((noreturn))
void ap_entry(uint64_t cpu_index)
{
    /* Adopt the BSP's descriptor tables. Until this point the AP is
     * running on the trampoline's throwaway GDT, which lives in a low
     * page and describes no TSS and no exception handling.
     *
     * KERNEL-01 Phase 1: this CPU now loads ITS OWN TSS here, so it has
     * a valid task register and a private double-fault stack. The call
     * range-checks cpu_index itself and returns 0 rather than loading a
     * selector that describes nothing, so it is safe to make before the
     * bounds check below.
     *
     * Captured into locals because `me` is not yet known to be valid;
     * they are published to shared state further down, after the bounds
     * check, alongside the other AP-reported evidence. */
    int tss_loaded = gdt_load_on_this_cpu((uint32_t)cpu_index);
    idt_load_on_this_cpu();

    /* Read the task register back from THIS CPU. Only this CPU can: TR
     * is per-logical-processor, so no amount of BSP-side inspection can
     * substitute for it. This is the AP's own testimony that `ltr` took
     * effect on the hardware it ran on. */
    uint16_t my_tr = gdt_read_tr();

    /* Interrupts are not enabled YET. Phase 1 gave this CPU a valid IST
     * so that enabling them is survivable; Phase 2 enables them, but
     * only further down, after this CPU's descriptor tables, LAPIC and
     * CPU-local storage are all established. Enabling them here would
     * mean taking an interrupt before %gs is valid. */

    if (cpu_index >= ACPI_MAX_CPUS || g_smp == 0) {
        /* Nothing safe to report through - park rather than touch
         * memory that may not be what this CPU thinks it is. */
        for (;;) {
            __asm__ volatile ("cli; hlt");
        }
    }

    CpuInfo *me = &g_smp->cpus[cpu_index];

    /* Identity check performed by the AP itself: read this CPU's own
     * LAPIC ID from its own LAPIC. This is the value the BSP will
     * compare against the MADT entry. */
    uint32_t my_apic_id = lapic_read_own_id(g_lapic_base);

    atomic_store_u32(&me->reported_apic_id, my_apic_id);

    /* BOOT-03: report which page tables this CPU is actually running
     * on. The AP inherited CR3 from the trampoline data block, which the
     * BSP populated with its own CR3 - so after BOOT-03 this must equal
     * the kernel PML4. Reporting it lets the BSP CHECK that rather than
     * assume it, and it is the specific evidence that paging and SMP
     * coexist. */
    atomic_store_u64(&me->reported_cr3, read_cr3());

    /* KERNEL-01 Phase 1 evidence. reported_tr is the value this CPU read
     * out of its own task register; reported_ist1 is the double-fault
     * stack top in the TSS that selector designates. Together with the
     * BSP-side check that descriptor n encodes the address of TSS n,
     * they establish that this CPU is using its own TSS and its own #DF
     * stack, rather than that some code path intended it to. */
    atomic_store_u32(&me->reported_tr, (uint32_t)my_tr);
    atomic_store_u64(&me->reported_ist1, gdt_ist1_for((uint32_t)cpu_index));
    atomic_store_u32(&me->tss_ok, tss_loaded ? 1u : 0u);

    /* BOOT-03: establish CPU-local storage on this AP. This must happen
     * on the AP itself - writing another CPU's GS base is impossible,
     * since IA32_GS_BASE is per-logical-processor.
     *
     * The AP is still running on the low physical stack the trampoline
     * gave it, not on a guarded kernel stack; migrating AP stacks is
     * deliberately out of scope (see kernel/include/kstack.h), so
     * kernel_stack_top is reported as the stack it is really using rather
     * than a stack it is not. */
    {
        uint64_t my_rsp;
        __asm__ volatile ("mov %%rsp, %0" : "=r"(my_rsp));
        int ok = percpu_init_for_this_cpu((uint32_t)cpu_index, my_apic_id,
                                          me->stack_top ? me->stack_top
                                                        : my_rsp,
                                          0 /* not the BSP */);
        if (ok) {
            ok = percpu_verify_this_cpu((uint32_t)cpu_index);
        }
        atomic_store_u32(&me->percpu_index, (uint32_t)cpu_index);
        atomic_store_u32(&me->percpu_ok, ok ? 1u : 0u);
    }

    /* ---------------------------------------------------------------- *
     * KERNEL-01 Phase 2: make this AP interruptible.
     *
     * Deliberately the LAST thing before the handshake, and in this
     * order, because each step depends on the previous one having taken
     * effect on THIS CPU:
     *
     *   1. its own IDT is loaded          (done above)
     *   2. its own TSS/IST is loaded      (done above, Phase 1)
     *   3. its CPU-local storage is up    (done above)
     *   4. its LAPIC is software enabled  (here)
     *   5. interrupts are enabled         (here)
     *
     * Step 4 is not redundant with lapic_init(): that ran on the BSP and
     * SVR is per-logical-processor, so this AP's LAPIC is still software
     * disabled and would silently drop every fixed-delivery IPI. See
     * lapic_enable_on_this_cpu() in lapic.h.
     * ---------------------------------------------------------------- */
    uint32_t my_svr = lapic_enable_on_this_cpu(g_lapic_base);
    atomic_store_u32(&me->reported_svr, my_svr);

    /* The `sti`. From this instruction on, this CPU can take an
     * interrupt at any point, and every vector it can receive is
     * dispatched through the handler table in idt.c.
     *
     * What can actually arrive here is narrow, and that is intentional:
     * the LAPIC timer LVT is masked on this CPU (its reset value has the
     * mask bit set, and only the BSP's timer_init() ever unmasks a
     * timer), the legacy PIC is fully masked by idt_init(), and no I/O
     * APIC redirection entry is programmed. So the only interrupts this
     * AP can see are IPIs sent to it deliberately - which is exactly the
     * capability Phases 3 and 4 require - plus the LAPIC spurious
     * vector, which the dispatcher handles without an EOI. */
    __asm__ volatile ("sti" ::: "memory");

    /* This CPU's own RFLAGS, read after `sti`. Bit 9 (IF) is the only
     * direct evidence that this AP is genuinely interruptible; an AP
     * halted with interrupts masked is externally indistinguishable from
     * one halted with them enabled, right up until a shootdown IPI goes
     * unacknowledged. Read here rather than inside the idle loop so the
     * value is published before the handshake. */
    uint64_t my_rflags;
    __asm__ volatile ("pushfq; pop %0" : "=r"(my_rflags) :: "memory");
    atomic_store_u64(&me->reported_rflags, my_rflags);

    /* Publish the "reached C code" evidence and the magic LAST, after
     * the APIC ID store and after the Phase 2 interrupt evidence, so the
     * BSP can never observe the proof-of-life flag while the data it
     * describes is still stale. */
    atomic_store_u32(&me->reached_c_code, 1);
    atomic_store_u64(&me->alive_magic, VEX_AP_ALIVE_MAGIC);

    atomic_inc_u32(&g_online_counter);

    /* Park, INTERRUPTIBLE.
     *
     * History of this loop, because the change is the point of Phase 2:
     * BOOT-03 parked here as `cli; hlt`, because an AP had no TSS and
     * therefore no IST, so any exception taken with interrupts enabled
     * had no guaranteed-valid stack to switch to. Phase 1 removed that
     * objection by giving every CPU its own TSS and #DF stack, but kept
     * the `cli` because dispatch was still a hardcoded single-vector `if`
     * with no handler table. Phase 2 removes the remaining objection, so
     * the `cli` is now gone.
     *
     * `hlt` with interrupts ENABLED is what makes this CPU reachable: it
     * stops the core until an interrupt arrives, then resumes after the
     * handler returns, and loops back into `hlt`. That is precisely the
     * behaviour a TLB shootdown needs from an idle CPU - it must be able
     * to receive the IPI, invalidate, acknowledge, and go back to sleep.
     *
     * There is deliberately no `cli` anywhere in this loop. A `cli; hlt`
     * pair here would be a CPU that can never be woken, and a CPU that
     * can never be woken is a CPU that can never acknowledge a
     * shootdown - which the initiator would experience as a timeout that
     * looks like a hardware fault rather than a logic error. */
    for (;;) {
        __asm__ volatile ("hlt");
    }
}

/* ------------------------------------------------------------------ *
 * BSP-side startup.
 * ------------------------------------------------------------------ */

static void put_u32(uint32_t v)
{
    serial_put_dec64((uint64_t)v);
}

static int start_one_ap(uint64_t tramp_phys, uint32_t index, CpuInfo *cpu)
{
    volatile uint8_t *tramp = (volatile uint8_t *)(uintptr_t)tramp_phys;

    volatile uint64_t *d_rsp =
        (volatile uint64_t *)(tramp + VEX_TRAMPOLINE_OFF_RSP);
    volatile uint64_t *d_arg =
        (volatile uint64_t *)(tramp + VEX_TRAMPOLINE_OFF_ARG);
    volatile uint32_t *d_ack =
        (volatile uint32_t *)(tramp + VEX_TRAMPOLINE_OFF_ACK);

    /* Per-AP data is published BEFORE the SIPI, and the ack is cleared
     * first so a stale ack from the previous AP cannot be mistaken for
     * this one's. */
    atomic_store_u32(d_ack, 0);
    atomic_store_u64(d_rsp, cpu->stack_top);
    atomic_store_u64(d_arg, (uint64_t)index);

    uint8_t vector = (uint8_t)(tramp_phys >> 12);

    cpu->state = CPU_STATE_STARTING;

    /* --- INIT --- */
    lapic_send_init(g_lapic_base, cpu->expected_apic_id);

    /* The documented sequence requires roughly 10 ms after INIT before
     * the first SIPI. This is a real timed wait, not a spin of
     * arbitrary length - see pit_delay.h for why that distinction
     * matters. */
    pit_delay_us(10000);

    /* --- first SIPI --- */
    lapic_send_sipi(g_lapic_base, cpu->expected_apic_id, vector);
    if (!lapic_wait_ipi_idle(g_lapic_base)) {
        serial_puts("  [smp] WARNING: ICR delivery status stuck after"
                    " first SIPI\n");
    }
    pit_delay_us(200);

    /* --- second SIPI, only if needed --- *
     *
     * The startup algorithm specifies sending two SIPIs, because on
     * some processors the first may be lost. Sending the second one to
     * a CPU that already started is harmless in principle, but it is
     * skipped when the AP has already acknowledged - re-running the
     * trampoline on a CPU that has moved on to C code would point a
     * second execution at the same stack. Checking the ack first
     * removes that risk entirely. */
    if (atomic_load_u32(d_ack) == 0) {
        lapic_send_sipi(g_lapic_base, cpu->expected_apic_id, vector);
        if (!lapic_wait_ipi_idle(g_lapic_base)) {
            serial_puts("  [smp] WARNING: ICR delivery status stuck after"
                        " second SIPI\n");
        }
        pit_delay_us(200);
    }

    /* --- wait for the AP to report in, with a real deadline --- *
     *
     * A dead or missing AP must not hang the BSP. The wait is bounded
     * at roughly 100 ms, in 1 ms polls. If the AP has not published its
     * proof-of-life by then it is declared FAILED and the BSP moves on;
     * it is never reported as ONLINE. */
    const uint32_t max_polls = 100;
    int reported = 0;

    for (uint32_t i = 0; i < max_polls; i++) {
        if (atomic_load_u64(&cpu->alive_magic) == VEX_AP_ALIVE_MAGIC &&
            atomic_load_u32(&cpu->reached_c_code) == 1) {
            reported = 1;
            break;
        }
        pit_delay_us(1000);
    }

    if (!reported) {
        cpu->state = CPU_STATE_FAILED_TIMEOUT;
        return 0;
    }

    /* The AP reported in. Verify it is the CPU the MADT said it was
     * before calling it online. */
    uint32_t got = atomic_load_u32(&cpu->reported_apic_id);
    if (got != cpu->expected_apic_id) {
        cpu->state = CPU_STATE_FAILED_IDENTITY;
        serial_puts("  [smp] CPU ");
        put_u32(index);
        serial_puts(": identity mismatch - MADT said APIC ID ");
        put_u32(cpu->expected_apic_id);
        serial_puts(", CPU reported ");
        put_u32(got);
        serial_puts("\n");
        return 0;
    }

    cpu->state = CPU_STATE_ONLINE;
    return 1;
}

int smp_start_aps(BootInfo *info, const AcpiInfo *acpi, uint32_t bsp_apic_id,
                  SmpInfo *out)
{
    /* Zero the whole structure: every CpuInfo field the AP handshake
     * relies on must start from a known state. */
    for (uint32_t i = 0; i < ACPI_MAX_CPUS; i++) {
        out->cpus[i].alive_magic = 0;
        out->cpus[i].reported_apic_id = 0;
        out->cpus[i].reached_c_code = 0;
        out->cpus[i].expected_apic_id = 0;
        out->cpus[i].processor_id = 0;
        out->cpus[i].stack_top = 0;
        out->cpus[i].state = CPU_STATE_UNKNOWN;

        /* KERNEL-01 Phase 1 fields. Zeroed here for the same reason as
         * everything above: SmpInfo is not guaranteed to arrive zeroed,
         * and a stale non-zero reported_tr would let a CPU that never
         * executed `ltr` look as though it had. */
        out->cpus[i].reported_tr = 0;
        out->cpus[i].reported_ist1 = 0;
        out->cpus[i].tss_ok = 0;
    }
    out->cpu_count = acpi->cpu_count;
    out->online_count = 0;
    out->failed_count = 0;
    out->bsp_apic_id = bsp_apic_id;
    out->trampoline_phys = 0;
    out->started = 0;

    g_smp = out;
    g_online_counter = 0;

    /* The LAPIC MMIO base is taken from IA32_APIC_BASE via lapic_init,
     * which kernel_entry already ran; re-read it here rather than
     * trusting the MADT's copy, since the MSR is what the hardware
     * actually decodes. */
    LapicInfo li;
    if (!lapic_init(&li)) {
        serial_puts("[kernel] SMP: LAPIC unavailable - cannot start APs\n");
        return 0;
    }
    g_lapic_base = li.physical_base;

    /* Record the MADT view first, so the report is complete even if
     * startup is refused below. */
    uint32_t bsp_index = 0;
    int bsp_found = 0;
    for (uint32_t i = 0; i < acpi->cpu_count && i < ACPI_MAX_CPUS; i++) {
        out->cpus[i].expected_apic_id = acpi->cpus[i].apic_id;
        out->cpus[i].processor_id = acpi->cpus[i].processor_id;

        if (acpi->cpus[i].apic_id == bsp_apic_id) {
            out->cpus[i].state = CPU_STATE_BSP;
            bsp_index = i;
            bsp_found = 1;
        } else if (!acpi->cpus[i].enabled) {
            out->cpus[i].state = CPU_STATE_SKIPPED;
        }
    }
    if (!bsp_found) {
        /* Refusing to proceed: if the BSP cannot find itself in the
         * MADT, the CPU list is not trustworthy, and sending INIT to an
         * APIC ID that might be our own would reset the machine. */
        serial_puts("[kernel] SMP: BSP APIC ID ");
        put_u32(bsp_apic_id);
        serial_puts(" not present in MADT - refusing to start APs\n");
        return 0;
    }

    /* --- BSP must be MADT index 0 --- *
     *
     * KERNEL-01 Phase 1 makes this explicit, because the consequence of
     * violating it changed from subtle to immediate.
     *
     * The kernel identifies the BSP as CPU index 0 in two places that
     * predate this milestone: kernel_entry calls
     * percpu_init_for_this_cpu(0, ...) for the BSP unconditionally, and
     * APs use their MADT index. If the BSP were NOT MADT index 0, the AP
     * at MADT index 0 would be handed the same index the BSP already
     * claimed. Before this phase that produced two CPUs sharing one
     * per-CPU block - bad, but quiet. Now it would additionally have
     * that AP execute `ltr` on the TSS the BSP is already holding, which
     * the architecture answers with #GP on the busy bit.
     *
     * Refused rather than worked around, in keeping with the duplicate-
     * APIC-ID and high-CR3 refusals below and above. Working around it
     * would mean introducing an index-remapping layer, and a remapping
     * layer whose only exercise is a configuration no test produces is
     * worse than a loud refusal. Every firmware this kernel has been run
     * on lists the BSP first; if one does not, that is worth stopping
     * for and handling deliberately.
     *
     * Note this cannot regress BOOT-03 on any configuration BOOT-03
     * actually passed on: had bsp_index been non-zero, BOOT-03's own
     * per-CPU checks would already have been testing two CPUs sharing
     * one block. */
    if (bsp_index != 0) {
        serial_puts("[kernel] SMP: BSP is MADT index ");
        put_u32(bsp_index);
        serial_puts(", not 0 - the kernel assigns the BSP CPU index 0"
                    " (percpu and TSS), so this would collide with the"
                    " AP at index 0. Refusing to start APs.\n");
        return 0;
    }

    out->online_count = 1;   /* the BSP is, by definition, online */

    /* --- duplicate APIC ID check --- *
     *
     * Two MADT entries claiming the same APIC ID would make per-CPU
     * bookkeeping meaningless and could send two SIPIs to one CPU.
     * Detected and refused rather than worked around. */
    for (uint32_t i = 0; i < acpi->cpu_count && i < ACPI_MAX_CPUS; i++) {
        for (uint32_t j = i + 1; j < acpi->cpu_count && j < ACPI_MAX_CPUS; j++) {
            if (acpi->cpus[i].apic_id == acpi->cpus[j].apic_id) {
                serial_puts("[kernel] SMP: duplicate APIC ID ");
                put_u32(acpi->cpus[i].apic_id);
                serial_puts(" in MADT - refusing to start APs\n");
                return 0;
            }
        }
    }

    /* --- CR3 constraint --- *
     *
     * APs adopt the BSP's CR3, and the trampoline loads it while still
     * in 32-bit protected mode, where only 32 bits can be written. A
     * CR3 at or above 4 GiB cannot be delivered this way. Checked and
     * refused explicitly instead of being silently truncated into a
     * jump to a garbage page table. */
    uint64_t cr3 = read_cr3();
    if (cr3 >= 0x100000000ULL) {
        serial_puts("[kernel] SMP: BSP CR3 is above 4 GiB (");
        serial_put_hex64(cr3);
        serial_puts(") - the 32-bit trampoline cannot load it,"
                    " refusing to start APs\n");
        return 0;
    }

    /* --- trampoline page --- */
    uint64_t tramp_phys = find_low_trampoline_page(info);
    if (tramp_phys == 0) {
        serial_puts("[kernel] SMP: no conventional page below 1 MiB"
                    " available for the AP trampoline\n");
        return 0;
    }
    out->trampoline_phys = tramp_phys;

    uint64_t blob_size =
        (uint64_t)(ap_trampoline_blob_end - ap_trampoline_blob_start);
    if (blob_size != VEX_TRAMPOLINE_SIZE) {
        serial_puts("[kernel] SMP: embedded trampoline blob is ");
        serial_put_dec64(blob_size);
        serial_puts(" bytes, expected 4096 - refusing to start APs\n");
        return 0;
    }

    serial_puts("[kernel] SMP: trampoline page @ ");
    serial_put_hex64(tramp_phys);
    serial_puts(" (SIPI vector ");
    serial_put_hex64((uint64_t)(tramp_phys >> 12));
    serial_puts("), CR3 = ");
    serial_put_hex64(cr3);
    serial_puts("\n");

    /* Copy the blob into the low page. */
    volatile uint8_t *dst = (volatile uint8_t *)(uintptr_t)tramp_phys;
    for (uint64_t i = 0; i < blob_size; i++) {
        dst[i] = ap_trampoline_blob_start[i];
    }

    /* Verify the copy landed. Cheap, and it catches a low page that is
     * actually read-only or not backed at all - which would otherwise
     * show up as every AP mysteriously timing out. */
    for (uint64_t i = 0; i < blob_size; i++) {
        if (dst[i] != ap_trampoline_blob_start[i]) {
            serial_puts("[kernel] SMP: trampoline copy verification failed"
                        " at offset ");
            serial_put_dec64(i);
            serial_puts(" - refusing to start APs\n");
            return 0;
        }
    }

    /* Patch the fields that are the same for every AP. */
    volatile uint64_t *d_cr3 =
        (volatile uint64_t *)(dst + VEX_TRAMPOLINE_OFF_CR3);
    volatile uint64_t *d_entry =
        (volatile uint64_t *)(dst + VEX_TRAMPOLINE_OFF_ENTRY);

    atomic_store_u64(d_cr3, cr3);
    atomic_store_u64(d_entry, (uint64_t)(uintptr_t)&ap_entry);

    /* Make sure the PIT probe (and its diagnostic output, if it fails)
     * happens here rather than in the middle of the INIT-SIPI sequence
     * where the timing matters. */
    if (!pit_delay_probe()) {
        serial_puts("[kernel] SMP: WARNING - no usable PIT; AP startup"
                    " delays are uncalibrated\n");
    }

    out->started = 1;

    /* --- start the APs, ONE AT A TIME --- *
     *
     * Serialized deliberately. The trampoline has a single data block,
     * so exactly one AP may be consuming its RSP/arg fields at any
     * moment; the BSP does not rewrite them until that AP has
     * acknowledged. Starting APs in parallel would need one trampoline
     * page (or one data block) per AP and a genuinely concurrent
     * handshake, which is more machinery than this milestone needs. The
     * cost is startup latency, which nothing depends on yet.
     *
     * The BSP prints nothing while polling, so the serial port has a
     * single writer throughout. */
    for (uint32_t i = 0; i < acpi->cpu_count && i < ACPI_MAX_CPUS; i++) {
        CpuInfo *cpu = &out->cpus[i];

        if (cpu->state == CPU_STATE_BSP || cpu->state == CPU_STATE_SKIPPED) {
            continue;
        }

        /* Every AP gets its OWN stack from the PMM. Stacks are never
         * shared or reused, even for an AP that failed to start: a CPU
         * that timed out may still be alive and may still start
         * executing on that stack later, so handing it to a different
         * CPU would be a genuine corruption risk. */
        cpu->stack_top = ap_stack_alloc_top();

        if (start_one_ap(tramp_phys, i, cpu)) {
            out->online_count++;
        } else {
            out->failed_count++;
        }
    }

    /* Cross-check the BSP's per-CPU bookkeeping against the counter the
     * APs incremented independently. Disagreement would mean the
     * handshake is not doing what it claims, so it is reported loudly
     * rather than smoothed over. */
    uint32_t counted = atomic_load_u32(&g_online_counter) + 1; /* +BSP */
    if (counted != out->online_count) {
        serial_puts("[kernel] SMP: WARNING - AP-incremented counter says ");
        put_u32(counted);
        serial_puts(" online, BSP bookkeeping says ");
        put_u32(out->online_count);
        serial_puts("\n");
    }

    return out->failed_count == 0;
}
