#!/usr/bin/env python3
"""Host test for kernel/src/drivers/storage/vstore.c (ASan/UBSan). Run: python3 tests/vstore_host_test.py"""
import os, subprocess, sys, tempfile
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); k = os.path.join(root, "kernel")
exe = os.path.join(tempfile.mkdtemp(), "t")
c = subprocess.run(["gcc", "-std=gnu11", "-g", "-O1", "-fsanitize=address,undefined", "-fno-sanitize-recover=all", "-Wall", "-Wextra", "-I", os.path.join(k, "include"),
                    os.path.join(root, "tests/host/vstore_harness.c"), os.path.join(k, "src/drivers/storage/vstore.c"), "-o", exe], capture_output=True, text=True)
if c.returncode: print(c.stderr); sys.exit(1)
sys.exit(subprocess.run([exe], env=dict(os.environ, ASAN_OPTIONS="detect_leaks=0")).returncode)   # harness callocs are intentionally not freed; vstore.c itself allocates nothing
