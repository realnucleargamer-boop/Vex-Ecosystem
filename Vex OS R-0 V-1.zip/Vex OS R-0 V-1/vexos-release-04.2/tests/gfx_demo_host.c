/* Host-only demo/test renderer for GFX-VEC-01: writes a PPM so the output quality can be inspected. NOT part of the kernel. */
#include <stdio.h>
#include <stdlib.h>
#include "gfx/vec.h"
#include "gfx/vecfont.h"
#define W 640
#define H 420
static uint32_t buf[W * H];
int main(int argc, char **argv)
{
    GfxFb fb; fb.pixels = buf; fb.width = W; fb.height = H; fb.pitch_px = W; fb.r_shift = 16; fb.g_shift = 8; fb.b_shift = 0; fb.ok = 1;
    for (int i = 0; i < W * H; i++) buf[i] = 0x0b1020;
    VecPaint win = vec_solid(gfx_rgb(24, 32, 56), 255), edge = vec_solid(gfx_rgb(70, 90, 160), 255);
    vec_fill_rrect(&fb, VFX_INT(14), VFX_INT(12), VFX_INT(300), VFX_INT(190), VFX_INT(10), &win, 0);
    vec_stroke_rrect(&fb, VFX_INT(14) + 128, VFX_INT(12) + 128, VFX_INT(300) - 256, VFX_INT(190) - 256, VFX_INT(10), VFX_FRAC(3, 2), &edge, 0);
    VecPaint grad = vec_vgradient(gfx_rgb(90, 120, 255), gfx_rgb(40, 50, 140), VFX_INT(24), VFX_INT(52), 255);
    vec_fill_rrect(&fb, VFX_INT(26), VFX_INT(24), VFX_INT(276), VFX_INT(28), VFX_INT(14), &grad, 0);
    VecPaint white = vec_solid(gfx_rgb(235, 240, 255), 255), dim = vec_solid(gfx_rgb(170, 185, 230), 255);
    vf_draw_text(&fb, VFX_INT(44), VFX_INT(43), VFX_INT(15), "Vector title - sub-pixel text", &white, 0);
    /* circles at fractional centres: the fractional part moves the edge smoothly */
    for (int i = 0; i < 6; i++) { VecPaint c = vec_solid(gfx_rgb(255, (uint8_t)(120 + i * 20), 90), 255); vec_fill_ellipse(&fb, VFX_INT(40 + i * 40) + i * 43, VFX_INT(84), VFX_INT(15), VFX_INT(15), &c, 0); }
    for (int i = 0; i < 5; i++) { vec_line(&fb, VFX_INT(30), VFX_INT(118) + i * 71, VFX_INT(300), VFX_INT(118) + i * 71 + (i * 26), VFX_FRAC(3, 2) + i * 40, 1, &dim, 0); }
    /* the 8x16 cell font (what the terminal uses) */
    GfxColor fg = gfx_rgb(220, 230, 255), bg = gfx_rgb(5, 8, 16);
    const char *lines[] = { "The quick brown fox jumps over the lazy dog", "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz", "0123456789 +-*/=<>{}[]()#%&@!?;:.,'\"~^_| $", "v. ai what is 12 plus 30  ->  12 plus 30 = 42", "> v. proc test   PASS  57/57   rm -rf /  main() { return 0; }" };
    for (int l = 0; l < 5; l++) for (int c = 0; lines[l][c]; c++) vf_draw_cell(&fb, 330 + c * 0 + 0, 0, 0, fg, bg), vf_draw_cell(&fb, 10 + c * 8, 216 + l * 16, lines[l][c], fg, bg);
    /* text at several sizes, fractional positions */
    int sizes[] = { 11, 13, 16, 20, 26 }; int y = 312;
    for (int i = 0; i < 5; i++) { char s[64]; snprintf(s, sizeof s, "Sphinx of black quartz %d px", sizes[i]); vf_draw_text(&fb, VFX_INT(14) + i * 85, VFX_INT(y) + (i * 77) % 256, VFX_INT(sizes[i]), s, &white, 0); y += sizes[i] + 8 - (i == 0 ? 0 : 0); }
    /* icons built from paths: a folder, a gear-like star, a check mark */
    VecPath *p = vec_scratch(); vec_path_begin(p); vec_move_to(p, VFX_INT(340), VFX_INT(60)); vec_line_to(p, VFX_INT(362), VFX_INT(60)); vec_quad_to(p, VFX_INT(368), VFX_INT(60), VFX_INT(372), VFX_INT(66)); vec_line_to(p, VFX_INT(404), VFX_INT(66));
    vec_quad_to(p, VFX_INT(410), VFX_INT(66), VFX_INT(410), VFX_INT(72)); vec_line_to(p, VFX_INT(410), VFX_INT(100)); vec_quad_to(p, VFX_INT(410), VFX_INT(106), VFX_INT(404), VFX_INT(106)); vec_line_to(p, VFX_INT(346), VFX_INT(106)); vec_quad_to(p, VFX_INT(340), VFX_INT(106), VFX_INT(340), VFX_INT(100)); vec_close(p);
    VecPaint folder = vec_vgradient(gfx_rgb(255, 210, 110), gfx_rgb(225, 160, 60), VFX_INT(60), VFX_INT(106), 255); vec_fill(&fb, p, 0, &folder, 0);
    vec_path_begin(p); for (int i = 0; i < 10; i++) { int64_t r = (i & 1) ? 14 : 28; int a = i * 36; static const int c36[10] = { 256, 207, 79, -79, -207, -256, -207, -79, 79, 207 }, s36[10] = { 0, 150, 243, 243, 150, 0, -150, -243, -243, -150 }; (void)a; int ii = i; vec_line_to(p, VFX_INT(470) + (vfx)(r * c36[ii]), VFX_INT(84) + (vfx)(r * s36[ii])); }
    vec_close(p); VecPaint star = vec_solid(gfx_rgb(120, 220, 160), 255); vec_fill(&fb, p, 0, &star, 0);
    vec_path_begin(p); vec_move_to(p, VFX_INT(530), VFX_INT(86)); vec_line_to(p, VFX_INT(544), VFX_INT(100)); vec_line_to(p, VFX_INT(570), VFX_INT(66)); VecPaint chk = vec_solid(gfx_rgb(120, 255, 150), 255); vec_stroke(&fb, p, VFX_INT(5), 1, &chk, 0);
    /* translucent overlay */
    VecPaint glass = vec_solid(gfx_rgb(255, 255, 255), 60); vec_fill_rrect(&fb, VFX_INT(340), VFX_INT(130), VFX_INT(280), VFX_INT(60), VFX_INT(12), &glass, 0);
    vf_draw_text(&fb, VFX_INT(356), VFX_INT(168), VFX_INT(22), "Translucent glass", &white, 0);
    FILE *f = fopen(argc > 1 ? argv[1] : "demo.ppm", "wb"); fprintf(f, "P6\n%d %d\n255\n", W, H);
    for (int i = 0; i < W * H; i++) { uint8_t px[3] = { (uint8_t)(buf[i] >> 16), (uint8_t)(buf[i] >> 8), (uint8_t)buf[i] }; fwrite(px, 1, 3, f); }
    fclose(f); return 0;
}
