/*
 * Vex OS - kernel/src/core/serial.c
 *
 * Minimal 16550 UART driver, COM1 @ 0x3F8. Raw port I/O via inline
 * asm - no libc, no external dependencies. This is intentionally the
 * simplest possible early-debug channel; it is not the final
 * driver-model serial driver (that lives under drivers/ once the
 * driver interface is frozen).
 */

#include "serial.h"

#define COM1 0x3F8

static inline void outb(uint16_t port, uint8_t val)
{
    __asm__ volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint8_t inb(uint16_t port)
{
    uint8_t ret;
    __asm__ volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

void serial_init(void)
{
    outb(COM1 + 1, 0x00); /* disable interrupts */
    outb(COM1 + 3, 0x80); /* enable DLAB (set baud rate divisor) */
    outb(COM1 + 0, 0x03); /* divisor low byte: 38400 baud */
    outb(COM1 + 1, 0x00); /* divisor high byte */
    outb(COM1 + 3, 0x03); /* 8 bits, no parity, one stop bit */
    outb(COM1 + 2, 0xC7); /* enable FIFO, clear, 14-byte threshold */
    outb(COM1 + 4, 0x0B); /* IRQs disabled, RTS/DSR set */
}

static int transmit_empty(void)
{
    return inb(COM1 + 5) & 0x20;
}

void serial_putc(char c)
{
    if (c == '\n') serial_putc('\r');
    while (!transmit_empty()) { }
    outb(COM1, (uint8_t)c);
}

void serial_puts(const char *s)
{
    while (*s) {
        serial_putc(*s++);
    }
}

void serial_put_hex64(uint64_t v)
{
    static const char digits[] = "0123456789ABCDEF";
    serial_puts("0x");
    for (int shift = 60; shift >= 0; shift -= 4) {
        serial_putc(digits[(v >> shift) & 0xF]);
    }
}

void serial_put_dec64(uint64_t v)
{
    char buf[21];
    int i = 20;
    buf[i--] = 0;
    if (v == 0) buf[i--] = '0';
    while (v > 0 && i >= 0) {
        buf[i--] = (char)('0' + (v % 10));
        v /= 10;
    }
    serial_puts(&buf[i + 1]);
}
