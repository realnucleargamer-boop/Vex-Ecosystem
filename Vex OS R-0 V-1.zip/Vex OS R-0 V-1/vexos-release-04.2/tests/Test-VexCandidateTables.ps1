# Vex OS - candidate-directory table tests.
#
# The real Windows paths cannot be exercised on Linux, but the table CONTENTS
# can be asserted - and a missing or misspelled entry here is the single most
# likely way for tool discovery to fail on a real machine.
#
# NOTE on roots: Windows-style roots ("C:\Program Files") cannot be used here,
# because PowerShell's Join-Path resolves the drive qualifier through the
# provider and drive C: does not exist on this host. Linux-valid roots are
# substituted instead, so the hand-written SUFFIX literals - the part that can
# actually be wrong - are still asserted.

$ErrorActionPreference = "Stop"
Set-StrictMode -Off

. (Join-Path (Split-Path -Parent $PSScriptRoot) "scripts/VexToolchain.ps1")

$script:pass = 0
$script:fail = 0
function Check($name, $condition, $detail) {
    if ($condition) { Write-Host "  PASS  $name" -ForegroundColor Green; $script:pass++ }
    else { Write-Host "  FAIL  $name" -ForegroundColor Red; if ($detail) { Write-Host "        $detail" -ForegroundColor DarkYellow }; $script:fail++ }
}

Write-Host "`n[11] Candidate-directory tables" -ForegroundColor Cyan

$env:ProgramFiles        = '/pf'
${env:ProgramFiles(x86)} = '/pf86'
$env:LOCALAPPDATA        = '/lad'
$env:ProgramData         = '/pd'
$env:USERPROFILE         = '/up'

# Path-separator note: Join-Path emits '/' on Linux and '\' on Windows, so
# every assertion below matches [\/] rather than a hardcoded separator.
$nasm = @(Get-VexNasmCandidateDirs)
$nj = $nasm -join ' ; '
Check "NASM: admin install location (ProgramFiles\NASM)"            ($nj -match '/pf/NASM')                  $nj
Check "NASM: 32-bit ProgramFiles variant"                           ($nj -match '/pf86/NASM')                $nj
Check "NASM: per-user LOCALAPPDATA\bin\NASM (winget-cli #2453)"     ($nj -match '/lad[\\/]bin[\\/]NASM')            $nj
Check "NASM: winget Links shim dir"                                 ($nj -match 'WinGet[\\/]Links')             $nj
Check "NASM: winget package dir wildcard"                           ($nj -match 'NASM\.NASM_\*')             $nj
Check "NASM: chocolatey"                                            ($nj -match 'chocolatey')                $nj
Check "NASM: scoop"                                                 ($nj -match 'scoop')                     $nj
Check "NASM: bare C:\NASM fallback"                                 ($nj -match 'C:\\NASM')                  $nj
Check "NASM: no empty entries"                                      (($nasm | Where-Object { [string]::IsNullOrWhiteSpace($_) }).Count -eq 0) ""
Check "NASM: no duplicate entries"                                  ($nasm.Count -eq (@($nasm | Select-Object -Unique)).Count) $nj

$llvm = @(Get-VexLlvmCandidateDirs)
$lj = $llvm -join ' ; '
Check "LLVM: default installer location (ProgramFiles\LLVM\bin)"    ($lj -match '/pf[\\/]LLVM[\\/]bin')             $lj
Check "LLVM: 32-bit ProgramFiles variant"                           ($lj -match '/pf86[\\/]LLVM[\\/]bin')           $lj
Check "LLVM: per-user Programs\LLVM\bin"                            ($lj -match 'Programs[\\/]LLVM[\\/]bin')       $lj
Check "LLVM: winget Links shim dir"                                 ($lj -match 'WinGet[\\/]Links')             $lj
Check "LLVM: winget package dir wildcard"                           ($lj -match 'LLVM\.LLVM_\*')             $lj
Check "LLVM: Visual Studio bundled LLVM"                            ($lj -match 'VC[\\/]Tools[\\/]Llvm[\\/]x64[\\/]bin') $lj
Check "LLVM: chocolatey"                                            ($lj -match 'chocolatey')                $lj
Check "LLVM: scoop"                                                 ($lj -match 'scoop')                     $lj
Check "LLVM: msys2"                                                 ($lj -match 'msys64')                    $lj
Check "LLVM: no empty entries"                                      (($llvm | Where-Object { [string]::IsNullOrWhiteSpace($_) }).Count -eq 0) ""
Check "LLVM: no duplicate entries"                                  ($llvm.Count -eq (@($llvm | Select-Object -Unique)).Count) $lj

$qemu = @(Get-VexQemuCandidateDirs)
$qj = $qemu -join ' ; '
Check "QEMU: ProgramFiles\qemu"                                     ($qj -match '/pf/qemu')                  $qj
Check "QEMU: winget package id wildcard"                            ($qj -match 'SoftwareFreedomConservancy\.QEMU_\*') $qj
Check "QEMU: chocolatey"                                            ($qj -match 'chocolatey')                $qj
Check "QEMU: no empty entries"                                      (($qemu | Where-Object { [string]::IsNullOrWhiteSpace($_) }).Count -eq 0) ""

# Every tool the build actually needs must appear in the spec table.
$specKeys = @((Get-VexToolSpecs) | ForEach-Object { $_.Key })
foreach ($needed in @("clang","lld-link","ld.lld","llvm-objcopy","nasm","qemu")) {
    Check "spec table contains '$needed'" ($specKeys -contains $needed) "have: $($specKeys -join ',')"
}
$specExes = @((Get-VexToolSpecs) | ForEach-Object { $_.Exe })
Check "all spec executables end in .exe" ((@($specExes | Where-Object { $_ -notlike "*.exe" })).Count -eq 0) "$($specExes -join ',')"
$groups = @((Get-VexToolSpecs) | ForEach-Object { $_.Group } | Select-Object -Unique)
Check "spec groups contain llvm, nasm and qemu" (($groups -contains 'llvm') -and ($groups -contains 'nasm') -and ($groups -contains 'qemu')) "$($groups -join ',')"

# Missing environment variables must not produce malformed entries.
Remove-Item Env:ProgramFiles -ErrorAction SilentlyContinue
Remove-Item 'Env:ProgramFiles(x86)' -ErrorAction SilentlyContinue
Remove-Item Env:LOCALAPPDATA -ErrorAction SilentlyContinue
Remove-Item Env:ProgramData -ErrorAction SilentlyContinue
Remove-Item Env:USERPROFILE -ErrorAction SilentlyContinue

$threw = $false; $d = @()
try { $d = @(Get-VexNasmCandidateDirs) } catch { $threw = $true }
Check "tables tolerate a stripped environment"        (-not $threw) ""
Check "no empty entries with env vars absent"         (($d | Where-Object { [string]::IsNullOrWhiteSpace($_) }).Count -eq 0) "got: $($d -join ' ; ')"
Check "hardcoded fallbacks survive a stripped env"    (($d -join ' ; ') -match 'C:\\NASM') "got: $($d -join ' ; ')"

$threw = $false
try { Get-VexLlvmCandidateDirs | Out-Null; Get-VexQemuCandidateDirs | Out-Null } catch { $threw = $true }
Check "LLVM/QEMU tables tolerate a stripped environment" (-not $threw) ""

Write-Host ("`n{0} passed, {1} failed" -f $script:pass, $script:fail) -ForegroundColor $(if ($script:fail -eq 0) { "Green" } else { "Red" })
if ($script:fail -gt 0) { exit 1 }
