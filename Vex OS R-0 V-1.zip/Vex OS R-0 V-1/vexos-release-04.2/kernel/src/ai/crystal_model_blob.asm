; Vex OS - kernel/src/ai/crystal_model_blob.asm
;
; CRYSTAL-NATIVE-01: embeds the exported VEX AI 1.5-Crystal weights (assets/crystal/crystal15.vxcr, format VXCR v1,
; written by tools/crystal_export.py) into the kernel image as read-only data, exactly like ap_trampoline_blob.asm.
; The core never trusts the blob: vxc_model_open() validates header, dimensions, exact length and CRC-32 before use.
; The path is relative to the repository root (assembled with `-i <repo root>`, same as the trampoline blob).

BITS 64

section .rodata
align 16

global crystal_model_blob_start
global crystal_model_blob_end

crystal_model_blob_start:
    incbin "assets/crystal/crystal15.vxcr"
crystal_model_blob_end:

section .note.GNU-stack noalloc noexec nowrite progbits
