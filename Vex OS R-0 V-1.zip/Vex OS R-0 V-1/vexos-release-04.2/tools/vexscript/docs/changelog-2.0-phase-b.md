# VexScript 2.0 Phase B — Vex IR 0.1

## Implemented
- Vex IR 0.1 data model (functions, basic blocks, SSA values)
- AST → IR emitter (literals, arith, cmp, lets, assign, if, while, for/loop/break/continue, calls, returns)
- `load_local` / `store_local` for mutable variables across blocks
- IR validator (terminators, SSA, branches, unknown ops)
- Deterministic textual IR
- IR reference interpreter (testing only)
- `compile_ir.compile_to_ir` / `emit_ir_text` / `run_via_ir`
- Module functions emitted into IR; qualified calls rewritten

## Not in Phase B
- x86-64 backend, ELF, syscalls, OS APIs, GUI
