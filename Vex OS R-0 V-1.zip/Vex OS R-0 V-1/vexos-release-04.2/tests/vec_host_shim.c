/* Host-only shim for kernel/src/graphics/vec.c (ctypes). NOT part of the kernel build. */
#include "gfx/vec.h"
int shim_poly_mask(const int32_t *xs, const int32_t *ys, int n, int w, int h, int evenodd, uint8_t *out)
{ static VecPath p; vec_path_begin(&p); for (int i = 0; i < n; i++) { if (i == 0) vec_move_to(&p, xs[i], ys[i]); else vec_line_to(&p, xs[i], ys[i]); } vec_close(&p); return vec_mask(&p, evenodd, w, h, out); }
int shim_multi_mask(const int32_t *xs, const int32_t *ys, const int *counts, int nsub, int w, int h, int evenodd, uint8_t *out)
{ static VecPath p; vec_path_begin(&p); int k = 0; for (int s = 0; s < nsub; s++) { for (int i = 0; i < counts[s]; i++, k++) { if (i == 0) vec_move_to(&p, xs[k], ys[k]); else vec_line_to(&p, xs[k], ys[k]); } vec_close(&p); } return vec_mask(&p, evenodd, w, h, out); }
int shim_ellipse_mask(int32_t cx, int32_t cy, int32_t rx, int32_t ry, int w, int h, uint8_t *out)
{ static VecPath p; vec_path_begin(&p); vec_add_ellipse(&p, cx, cy, rx, ry); return vec_mask(&p, 0, w, h, out); }
int shim_rrect_mask(int32_t x, int32_t y, int32_t rw, int32_t rh, int32_t r, int w, int h, uint8_t *out)
{ static VecPath p; vec_path_begin(&p); vec_add_rrect(&p, x, y, rw, rh, r, r); return vec_mask(&p, 0, w, h, out); }
int shim_line_mask(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t width, int round, int w, int h, uint8_t *out)
{ static VecPath p, s; vec_path_begin(&p); vec_move_to(&p, x0, y0); vec_line_to(&p, x1, y1); if (vec_stroke_path(&p, width, round, &s) != 0) return -1; return vec_mask(&s, 0, w, h, out); }
int shim_cubic_mask(const int32_t *c, int w, int h, uint8_t *out)   /* c[8]: p0..p3, closed by a straight edge */
{ static VecPath p; vec_path_begin(&p); vec_move_to(&p, c[0], c[1]); vec_cubic_to(&p, c[2], c[3], c[4], c[5], c[6], c[7]); vec_close(&p); return vec_mask(&p, 0, w, h, out); }
/* framebuffer fill with clip; pixels has (fw+2*margin)*(fh+2*margin) words so out-of-bounds writes are detectable */
int shim_fill_fb(uint32_t *buf, int fw, int fh, int margin, const int32_t *xs, const int32_t *ys, int n, int has_clip, const int32_t *clip, int r, int g, int b, int alpha)
{
    GfxFb fb; int pitch = fw + 2 * margin;
    fb.pixels = buf + (size_t)margin * pitch + margin; fb.width = (uint32_t)fw; fb.height = (uint32_t)fh; fb.pitch_px = (uint32_t)pitch; fb.r_shift = 16; fb.g_shift = 8; fb.b_shift = 0; fb.ok = 1;
    static VecPath p; vec_path_begin(&p); for (int i = 0; i < n; i++) { if (i == 0) vec_move_to(&p, xs[i], ys[i]); else vec_line_to(&p, xs[i], ys[i]); } vec_close(&p);
    VecPaint pt = vec_solid(gfx_rgb((uint8_t)r, (uint8_t)g, (uint8_t)b), (uint8_t)alpha); VecClip c; if (has_clip) { c.x0 = clip[0]; c.y0 = clip[1]; c.x1 = clip[2]; c.y1 = clip[3]; }
    return vec_fill(&fb, &p, 0, &pt, has_clip ? &c : 0);
}
int shim_many_points(int n, int w, int h, uint8_t *out)   /* path capacity attack: n vertices on a circle */
{ static VecPath p; vec_path_begin(&p); for (int i = 0; i < n; i++) { int32_t x = 64 * 256 + (int32_t)((i * 37) % 4000), y = 64 * 256 + (int32_t)((i * 91) % 4000); if (i == 0) vec_move_to(&p, x, y); else vec_line_to(&p, x, y); } vec_close(&p); return vec_mask(&p, 0, w, h, out); }
int shim_many_subpaths(int n, int w, int h, uint8_t *out)
{ static VecPath p; vec_path_begin(&p); for (int i = 0; i < n; i++) { vec_move_to(&p, 256 * (i % 50), 256 * (i / 50)); vec_line_to(&p, 256 * (i % 50) + 300, 256 * (i / 50)); vec_line_to(&p, 256 * (i % 50), 256 * (i / 50) + 300); vec_close(&p); } return vec_mask(&p, 0, w, h, out); }
int shim_stroke_poly(const int32_t *xs, const int32_t *ys, int n, int closed, int32_t width, int round, int w, int h, uint8_t *out)
{ static VecPath p, s; vec_path_begin(&p); for (int i = 0; i < n; i++) { if (i == 0) vec_move_to(&p, xs[i], ys[i]); else vec_line_to(&p, xs[i], ys[i]); } if (closed) vec_close(&p);
  if (vec_stroke_path(&p, width, round, &s) != 0) return -1; return vec_mask(&s, 0, w, h, out); }
int shim_rrect_stroke_mask(int32_t x, int32_t y, int32_t rw, int32_t rh, int32_t r, int32_t width, int w, int h, uint8_t *out)
{ static VecPath p, s; vec_path_begin(&p); vec_add_rrect(&p, x, y, rw, rh, r, r); if (vec_stroke_path(&p, width, 0, &s) != 0) return -1; return vec_mask(&s, 0, w, h, out); }
int shim_ellipse_stroke_mask(int32_t cx, int32_t cy, int32_t rx, int32_t ry, int32_t width, int w, int h, uint8_t *out)
{ static VecPath p, s; vec_path_begin(&p); vec_add_ellipse(&p, cx, cy, rx, ry); if (vec_stroke_path(&p, width, 1, &s) != 0) return -1; return vec_mask(&s, 0, w, h, out); }
