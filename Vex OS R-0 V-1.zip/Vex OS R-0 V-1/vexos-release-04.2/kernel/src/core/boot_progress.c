/*
 * Vex OS - kernel/src/core/boot_progress.c
 *
 * See kernel/include/boot_progress.h for the design rationale. This
 * file has exactly one job: hold state and call a registered callback.
 * No gfx calls, no serial, no hardware access - freestanding in the
 * strictest sense, so it can never be the reason a future Security 2
 * or VEX AI integration has to touch graphics internals.
 */

#include "boot_progress.h"

static BootProgress        g_state;
static BootProgressRenderFn g_renderer;

static void bp_strcpy_bounded(char *dst, const char *src, int cap)
{
    int i = 0;
    if (!src) { dst[0] = '\0'; return; }
    while (src[i] != '\0' && i < cap - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

void boot_progress_init(void)
{
    g_state.stage = BOOT_STAGE_START;
    g_state.percent = 0;
    g_state.message[0] = '\0';
    g_state.update_count = 0;
    g_renderer = 0;
}

void boot_progress_attach_renderer(BootProgressRenderFn render_fn)
{
    g_renderer = render_fn;
}

void boot_progress_set(BootStage stage, int percent, const char *message)
{
    if (percent < 0) percent = 0;
    if (percent > 100) percent = 100;

    g_state.stage = stage;
    g_state.percent = percent;
    bp_strcpy_bounded(g_state.message, message, BOOT_PROGRESS_MSG_MAX);
    g_state.update_count++;

    if (g_renderer) {
        g_renderer(&g_state);
    }
}

const BootProgress *boot_progress_get(void)
{
    return &g_state;
}
