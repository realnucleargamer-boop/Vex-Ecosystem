/*
 * Vex OS - kernel/include/panic.h
 *
 * Frozen panic format (from architecture spec):
 *
 *   VEX KERNEL PANIC
 *
 *   Reason: <exception>
 *   RIP: <hex>
 *   CR2: <hex>
 *   CPU: <id>
 *   Thread: <name>
 *
 *   [Stack trace]
 *
 *   Press ENTER to reboot.
 *
 * BOOT-01 implements the serial-output half of this (framebuffer
 * panic rendering, real stack unwinding, and multi-CPU/thread
 * identification arrive with the interrupt/process milestones).
 * panic() never returns.
 */

#ifndef VEXOS_PANIC_H
#define VEXOS_PANIC_H

#include <stdint.h>

/* rip/cr2 are 0 when not applicable (e.g. a software-detected
 * invariant violation rather than a CPU exception). */
void panic(const char *reason, uint64_t rip, uint64_t cr2) __attribute__((noreturn));

#endif /* VEXOS_PANIC_H */
