"""
VEX AI 1.0 language-wave regression tests.

Covers the three bugs fixed for VEX AI 1.0:
  Bug 1 - indexed array mutation (a[i] = x)
  Bug 2 - same-module function resolution
  Bug 3 - genome/stream/fitness/migration/diversity/elite builtins
          reaching the Vex IR execution path (vexc run)

Run with:  PYTHONPATH=src python3 scripts/test_language_wave_1_0.py
"""
import os
import sys
import tempfile
import subprocess

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from vexscript.interpreter import Interpreter  # noqa: E402
from vexscript.errors import VexError  # noqa: E402

PASS = 0
FAIL = 0
FAILURES = []


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS  {name}")
    else:
        FAIL += 1
        FAILURES.append(name)
        print(f"  FAIL  {name}  {detail}")


def run_hosted(src, filename="main.vex", module_paths=None):
    interp = Interpreter(module_paths=module_paths or [])
    interp.load(src, filename)
    code = interp.run_main()
    return code, interp.output


def make_project(tmpdir, files, entry="src/main.vex"):
    srcdir = os.path.join(tmpdir, "src")
    os.makedirs(srcdir, exist_ok=True)
    for fname, content in files.items():
        with open(os.path.join(srcdir, fname), "w") as f:
            f.write(content)
    with open(os.path.join(tmpdir, "vex.toml"), "w") as f:
        f.write(f'[package]\nname = "t"\nversion = "0.1.0"\n[build]\nentry = "{entry}"\n')
    return tmpdir


def run_full_pipeline(project_dir):
    env = dict(os.environ)
    env["PYTHONPATH"] = os.path.join(os.path.dirname(__file__), "..", "src")
    p = subprocess.run(
        [sys.executable, "-m", "vexscript.cli", "run", project_dir],
        capture_output=True, text=True, env=env, timeout=180,
    )
    return p.returncode, p.stdout, p.stderr


# --------------------------------------------------------------------
# Bug 1: indexed array mutation
# --------------------------------------------------------------------

def test_bug1_array_index_assign():
    print("\n=== Bug 1: a[i] = x ===")
    src = """
    fn main() -> i32 {
        let mut a: i64[] = [1, 2, 3];
        a[1] = 99;
        println(a[0]);
        println(a[1]);
        println(a[2]);
        return 0;
    }
    """
    code, out = run_hosted(src)
    check("hosted: array element mutated in place", out == ["1", "99", "3"], out)

    with tempfile.TemporaryDirectory() as td:
        proj = make_project(td, {"main.vex": src})
        rc, stdout, stderr = run_full_pipeline(proj)
        check("compiled (vexc run): array element mutated in place",
              rc == 0 and stdout.strip().splitlines() == ["1", "99", "3"], (rc, stdout, stderr))

    # Regression: reading still works, and OOB index is still rejected.
    oob_src = """
    fn main() -> i32 {
        let mut a: i64[] = [1, 2, 3];
        a[5] = 1;
        return 0;
    }
    """
    threw = False
    try:
        run_hosted(oob_src)
    except (VexError, Exception):
        threw = True
    check("out-of-bounds a[i]=x is rejected, not silently ignored", threw)

    # Immutable arrays still reject mutation.
    immut_src = """
    fn main() -> i32 {
        let a: i64[] = [1, 2, 3];
        a[0] = 5;
        return 0;
    }
    """
    threw = False
    try:
        run_hosted(immut_src)
    except (VexError, Exception):
        threw = True
    check("a[i]=x on an immutable ('let', not 'let mut') array is rejected", threw)


# --------------------------------------------------------------------
# Bug 2: same-module function resolution
# --------------------------------------------------------------------

def test_bug2_same_module_call():
    print("\n=== Bug 2: same-module function resolution ===")
    lib_src = "pub fn a() -> i64 { return b(); }\npub fn b() -> i64 { return 7; }\n"
    priv_lib_src = "pub fn a() -> i64 { return helper(); }\nfn helper() -> i64 { return 13; }\n"
    main_src = "use lib;\nfn main() -> i32 { println(lib::a()); return 0; }\n"

    with tempfile.TemporaryDirectory() as td:
        proj = make_project(td, {"main.vex": main_src, "lib.vex": lib_src})
        interp = Interpreter(module_paths=[os.path.join(proj, "src")])
        interp.load(main_src, os.path.join(proj, "src", "main.vex"))
        interp.run_main()
        check("hosted: pub fn a() calling unqualified b() in same module", interp.output == ["7"], interp.output)

        rc, stdout, stderr = run_full_pipeline(proj)
        check("compiled (vexc run): same-module unqualified call", rc == 0 and stdout.strip() == "7", (rc, stdout, stderr))

    # Private (non-pub) helper called from a pub function in the same module
    # -- exercises the CLI fix that previously excluded non-exported
    # functions from IR emission entirely.
    with tempfile.TemporaryDirectory() as td:
        proj = make_project(td, {"main.vex": main_src.replace("lib.vex", "priv_lib.vex"), "lib.vex": priv_lib_src})
        rc, stdout, stderr = run_full_pipeline(proj)
        check("compiled: pub fn calling a PRIVATE same-module helper",
              rc == 0 and stdout.strip() == "13", (rc, stdout, stderr))

    # Qualified cross-module calls must be unaffected.
    main_src2 = "use lib;\nfn main() -> i32 { println(lib::b()); return 0; }\n"
    with tempfile.TemporaryDirectory() as td:
        proj = make_project(td, {"main.vex": main_src2, "lib.vex": lib_src})
        rc, stdout, stderr = run_full_pipeline(proj)
        check("compiled: qualified module::fn() call still works", rc == 0 and stdout.strip() == "7", (rc, stdout, stderr))

    # Two different modules may each have a private helper with the same
    # bare name without colliding (regression for the fn_rets aliasing bug
    # removed alongside the Bug 2 fix).
    lib_a_src = "pub fn a() -> i64 { return helper(); }\nfn helper() -> i64 { return 1; }\n"
    lib_b_src = "pub fn b() -> i64 { return helper(); }\nfn helper() -> i64 { return 2; }\n"
    main_src3 = "use lib_a;\nuse lib_b;\nfn main() -> i32 { println(lib_a::a()); println(lib_b::b()); return 0; }\n"
    with tempfile.TemporaryDirectory() as td:
        proj = make_project(td, {"main.vex": main_src3, "lib_a.vex": lib_a_src, "lib_b.vex": lib_b_src})
        rc, stdout, stderr = run_full_pipeline(proj)
        check("compiled: two modules' same-named private helpers don't collide",
              rc == 0 and stdout.strip().splitlines() == ["1", "2"], (rc, stdout, stderr))


# --------------------------------------------------------------------
# Bug 3: genome/stream/fitness builtins reach the IR execution path
# --------------------------------------------------------------------

def test_bug3_genome_stream_builtins_compiled():
    print("\n=== Bug 3: genome/stream/fitness/migrate/diversity builtins via vexc run ===")
    src = """
    fn main() -> i32 {
        rng_seed(42);
        let g: i64 = genome_from_string("Hello");
        println(genome_match(g, "Hello sir"));
        genome_set_char(g, 0, "Y");
        println(genome_to_string(g));
        let sid: i64 = stream_create(4, 1, 1);
        fitness_set(sid, 0, 5);
        fitness_set(sid, 1, 9);
        println(fitness_best_index(sid));
        println(fitness_average(sid));
        println(elite_preserve_count(sid));
        return 0;
    }
    """
    with tempfile.TemporaryDirectory() as td:
        proj = make_project(td, {"main.vex": src})
        rc, stdout, stderr = run_full_pipeline(proj)
        lines = stdout.strip().splitlines() if rc == 0 else []
        check("compiled (vexc run): genome_/stream_/fitness_/elite_ builtins all execute",
              rc == 0 and lines == ["5", "Yello", "1", "3", "1"], (rc, stdout, stderr))


if __name__ == "__main__":
    test_bug1_array_index_assign()
    test_bug2_same_module_call()
    test_bug3_genome_stream_builtins_compiled()

    print(f"\n=== Results: {PASS} passed, {FAIL} failed ===")
    if FAILURES:
        print("Failed:", FAILURES)
    sys.exit(1 if FAIL else 0)
