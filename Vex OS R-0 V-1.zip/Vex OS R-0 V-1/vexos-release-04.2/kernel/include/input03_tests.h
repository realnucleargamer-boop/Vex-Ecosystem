/*
 * Vex OS - kernel/include/input03_tests.h
 * INPUT-03 / LOCK-01 in-kernel logic tests: mouse packet decoding and queue,
 * power-table parsers (incl. hostile inputs), RTC validation, cursor clamp,
 * and the lock-screen state machine (single-fire activation, key
 * auto-repeat, drag-off cancel, popup focus, disabled power items).
 *
 * These are LOGIC tests: no hardware is touched and no framebuffer is
 * needed.  They prove the decision logic; the end-to-end behaviour (real
 * PS/2 injection, rendering) is verified separately by
 * scripts/lockscreen_e2e.py against the booted image.
 * Counters are COUNTED, never hard-coded.
 */
#ifndef VEXOS_INPUT03_TESTS_H
#define VEXOS_INPUT03_TESTS_H
#include <stdint.h>
typedef struct { uint32_t checks_run, checks_failed; } Input03Results;
void input03_run_tests(Input03Results *out);
void input03_print_summary(const Input03Results *r);
int  input03_all_passed(const Input03Results *r);
#endif
