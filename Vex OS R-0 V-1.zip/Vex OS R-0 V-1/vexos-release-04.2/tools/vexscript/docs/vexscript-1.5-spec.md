# VEX-Script 1.5 Specification

Builds on 1.4. Reference interpreter.

## Explicit casts
```vex
value as i64
value as i32
```
Allowed: i32↔i64, integer_literal→i32/i64.  
Forbidden: bool→integer (and other undeclared conversions).  
`i64 as i32` performs a **runtime range check** (−2³¹ … 2³¹−1); out of range is an error.

## Control-flow typing
`if` / `while` / `for` conditions must be `bool`. Integer conditions are rejected.

## Return paths
Functions with a non-void return type must return on all paths (conservative analysis).

## Function values (foundation)
```vex
let f = add;
f(10, 20);
```
Minimal callable binding by function name. Not full closures.

## Modules
Unchanged isolation: `use m;` then `m::fn(...)`.

## Stdlib
`abs`, `min`, `max`, `str_contains`, `len_string`, `str_len` (alias).
