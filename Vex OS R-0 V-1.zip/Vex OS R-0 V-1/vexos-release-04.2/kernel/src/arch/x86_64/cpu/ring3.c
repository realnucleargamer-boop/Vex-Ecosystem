/*
 * Vex OS - kernel/src/arch/x86_64/cpu/ring3.c
 *
 * SECURITY-02 Ring 3 foundation. See kernel/include/ring3.h and
 * docs/SECURITY-02.md.
 *
 * DESIGN CHOICE, STATED PLAINLY: the user region lives in the kmap window
 * of the ONE shared address space, gated page-by-page by the U/S bit. It
 * is not a separate CR3 per task. Reasons: the low virtual range is
 * already occupied by the supervisor-only identity map (a user mapping
 * there would collide with it), and a per-task address space is a
 * process-manager feature this milestone explicitly does not build.
 * What this still genuinely provides is the property that matters for a
 * first boundary: Ring 3 can reach exactly the pages vmm_map_user_page()
 * marked U/S=user, and every other page - the kernel image, kernel
 * stacks, page tables, the direct map, the framebuffer - is
 * supervisor-only and faults. A per-task CR3 is the natural next step
 * and is listed under "remaining risks" in the SECURITY-02 report.
 */

#include "ring3.h"
#include "vmm.h"
#include "pmm.h"
#include "gdt.h"
#include "idt.h"
#include "irq.h"
#include "serial.h"

/* ---- asm side (ring3_transition.asm / ring3_programs.asm) ------------ */
extern int  ring3_checkpoint_save(Ring3Checkpoint *cp) __attribute__((returns_twice));
extern void ring3_checkpoint_restore(Ring3Checkpoint *cp, int retval)
    __attribute__((noreturn));
extern void ring3_enter(uint64_t entry_rip, uint64_t user_rsp,
                        uint64_t arg0, uint64_t arg1);
extern const uint8_t  ring3_prog_base[];
extern const uint64_t ring3_prog_size;

/* ring3_transition.asm hardcodes the selectors; fail the BUILD, not a
 * boot, if gdt.h ever moves them. */
_Static_assert(GDT_SEL_USER_CODE == 0x1B, "ring3_transition.asm hardcodes 0x1B");
_Static_assert(GDT_SEL_USER_DATA == 0x23, "ring3_transition.asm hardcodes 0x23");

#define IA32_KERNEL_GS_BASE 0xC0000102U

#define R3_PAGES        4          /* code, guard, stack, guard */
#define R3_KSTACK_SIZE  16384

static uint64_t g_region_base;
static uint64_t g_code_phys, g_stack_phys;
static int      g_init;

static uint8_t  g_kstack[R3_KSTACK_SIZE] __attribute__((aligned(16)));

static Ring3ExtSyscall g_ext_syscall;   /* PROC-01: when set, owns every syscall of the active run */
static Ring3Checkpoint g_cp;
static volatile int    g_active;
static Ring3Result     g_res;
static uint64_t        g_runs, g_faults_isolated;

static const char g_msg[] = "hello from ring3";

/* ---- geometry ---------------------------------------------------------- */
uint64_t ring3_region_base(void)   { return g_region_base; }
uint64_t ring3_region_bytes(void)  { return (uint64_t)R3_PAGES * VMM_PAGE_SIZE; }
uint64_t ring3_code_va(void)       { return g_region_base; }
uint64_t ring3_guard_lo_va(void)   { return g_region_base + 1 * VMM_PAGE_SIZE; }
uint64_t ring3_stack_va(void)      { return g_region_base + 2 * VMM_PAGE_SIZE; }
uint64_t ring3_guard_hi_va(void)   { return g_region_base + 3 * VMM_PAGE_SIZE; }
uint64_t ring3_msg_va(void)        { return ring3_stack_va(); }
uint64_t ring3_msg_len(void)       { return (uint64_t)sizeof(g_msg) - 1; }
uint64_t ring3_kernel_stack_top(void) { return (uint64_t)(uintptr_t)(g_kstack + R3_KSTACK_SIZE); }
int      ring3_initialised(void)   { return g_init; }
uint64_t ring3_runs_total(void)    { return g_runs; }
uint64_t ring3_faults_isolated(void) { return g_faults_isolated; }

/* ---- user pointer validation ------------------------------------------ */
static int canonical(uint64_t a)
{
    uint64_t top = a >> 47;
    return top == 0 || top == 0x1FFFF;
}

UserValidate user_range_check(uint64_t ptr, uint64_t len, int need_write)
{
    if (!g_init) return UV_ERR_NOT_INITIALISED;
    if (ptr == 0) return UV_ERR_NULL;

    /* Overflow FIRST, in a form that cannot itself wrap: len > MAX - ptr
     * is exactly "ptr + len > 2^64 - 1". Computing ptr + len and
     * comparing afterwards is the classic mistake, because the sum has
     * already wrapped by the time it is compared. */
    if (len > UINT64_MAX - ptr) return UV_ERR_OVERFLOW;

    /* A zero-length range still names one byte's address; check the page
     * it sits on so a wild pointer cannot hide behind len == 0. After the
     * check above, ptr + span - 1 <= UINT64_MAX - 1: no wrap. */
    uint64_t span = len ? len : 1;
    uint64_t last = ptr + span - 1;

    if (!canonical(ptr) || !canonical(last)) return UV_ERR_NONCANONICAL;

    /* EVERY page the range touches, not just the first. */
    uint64_t first_page = ptr  & ~(VMM_PAGE_SIZE - 1);
    uint64_t last_page  = last & ~(VMM_PAGE_SIZE - 1);
    for (uint64_t page = first_page; ; page += VMM_PAGE_SIZE) {
        uint64_t entry = 0, size = 0;
        if (vmm_query(page, &entry, &size) != VMM_OK || !(entry & VMM_PRESENT))
            return UV_ERR_NOT_MAPPED;
        if (!(entry & VMM_USER))
            return UV_ERR_NOT_USER;
        if (size != VMM_PAGE_SIZE)
            return UV_ERR_LARGE_PAGE;
        if (need_write && !(entry & VMM_WRITE))
            return UV_ERR_NOT_WRITABLE;
        if (page == last_page) break;
    }

    /* Belt and braces: the page walk above is what actually decides, but
     * the user region is explicit, so also require containment in it. A
     * user-accessible page outside the region would mean something other
     * than ring3_init() created one - worth refusing, and worth the
     * SECURITY-02 audit noticing. */
    if (ptr < g_region_base || last >= g_region_base + ring3_region_bytes())
        return UV_ERR_OUTSIDE_REGION;

    return UV_OK;
}

/* ---- syscall entry ------------------------------------------------------ */
static void log_write(const uint8_t *p, uint64_t n)
{
    serial_puts("[ring3] SYS_WRITE: ");
    for (uint64_t i = 0; i < n; i++) {
        uint8_t c = p[i];
        serial_putc((c >= 0x20 && c < 0x7F) ? (char)c : '.');
    }
    serial_puts("\n");
}

static void ring3_syscall_handler(InterruptFrame *f)
{
    /* The gate is DPL3, so Ring 0 could also reach here via `int 0x80`.
     * Nothing in the kernel does, and this path trusts a Ring 3 frame:
     * refuse anything else, and anything with no run in flight. */
    if (!g_active || (f->cs & 3) != 3) {
        f->rax = (uint64_t)RING3_SYS_REJECTED;
        return;
    }

    g_res.syscalls_seen++;
    if (g_ext_syscall) { f->rax = (uint64_t)g_ext_syscall(f); return; }
    uint64_t nr = f->rax;

    if (nr == RING3_SYS_EXIT) {
        g_res.outcome   = RING3_OUT_EXITED;
        g_res.exit_code = f->rdi;
        g_active = 0;
        /* Abandon this interrupt frame: SYS_EXIT means "do not resume
         * Ring 3", and there is no task to switch to. Nothing on this
         * stack owns a resource that needs releasing. */
        ring3_checkpoint_restore(&g_cp, RING3_OUT_EXITED);
    }

    if (nr == RING3_SYS_WRITE) {
        uint64_t ptr = f->rdi, len = f->rsi;
        /* Validate FIRST, so an overflowing or kernel-pointing request is
         * refused for its real reason; only a range that is otherwise
         * entirely valid is then held to the length cap. Either way the
         * kernel reads no byte of user memory before this returns OK. */
        UserValidate v = user_range_check(ptr, len, 0);
        if (v == UV_OK && len > RING3_WRITE_MAX) v = UV_ERR_TOO_LARGE;
        if (v != UV_OK) {
            g_res.syscalls_rejected++;
            g_res.last_reject_reason = (int)v;
            g_res.last_write_ret = RING3_SYS_REJECTED;
            f->rax = (uint64_t)RING3_SYS_REJECTED;
            serial_puts("[ring3] SYSCALL REJECTED: SYS_WRITE pointer failed validation\n");
            return;
        }
        log_write((const uint8_t *)(uintptr_t)ptr, len);
        g_res.bytes_written += len;
        g_res.last_write_ret = (int64_t)len;
        f->rax = len;
        return;
    }

    /* Unknown syscall number: reject, never guess. */
    g_res.syscalls_rejected++;
    g_res.last_write_ret = RING3_SYS_REJECTED;
    f->rax = (uint64_t)RING3_SYS_REJECTED;
    serial_puts("[ring3] SYSCALL REJECTED: unknown syscall number\n");
}

/* ---- fault isolation ----------------------------------------------------- */
int ring3_handle_user_fault(InterruptFrame *frame)
{
    if (!g_active || (frame->cs & 3) != 3) return 0;

    /* Aborts are not recoverable faults: a #DF or #MC means the CPU state
     * itself is suspect, and "terminate the task and carry on" would be
     * pretending otherwise. Leave those to the kernel's normal fatal
     * path. */
    if (frame->vector == 8 || frame->vector == 18) return 0;

    uint64_t cr2 = 0;
    if (frame->vector == 14) __asm__ volatile ("mov %%cr2, %0" : "=r"(cr2));

    g_res.outcome          = RING3_OUT_FAULTED;
    g_res.fault_vector     = frame->vector;
    g_res.fault_error_code = frame->error_code;
    g_res.fault_rip        = frame->rip;
    g_res.fault_cr2        = cr2;
    g_faults_isolated++;
    g_active = 0;

    serial_puts("[ring3] USER FAULT isolated: vector=");
    serial_put_dec64(frame->vector);
    serial_puts(" err=");
    serial_put_hex64(frame->error_code);
    serial_puts(" rip=");
    serial_put_hex64(frame->rip);
    if (frame->vector == 14) {
        serial_puts(" cr2=");
        serial_put_hex64(cr2);
    }
    serial_puts(" - user task terminated, kernel continues\n");

    ring3_checkpoint_restore(&g_cp, RING3_OUT_FAULTED);
}

/* ---- running a program ---------------------------------------------------- */
static void run_common(uint64_t entry, uint64_t stack_top, uint64_t arg0, uint64_t arg1, Ring3Result *out);

void ring3_run(uint64_t slot, uint64_t arg0, uint64_t arg1, Ring3Result *out)
{
    uint8_t *p = (uint8_t *)&g_res;
    for (uint64_t i = 0; i < sizeof(g_res); i++) p[i] = 0;

    if (!g_init || slot >= ring3_prog_size) {
        if (out) *out = g_res;
        return;
    }
    run_common(ring3_code_va() + slot, ring3_stack_va() + VMM_PAGE_SIZE - 16, arg0, arg1, out);
}

void ring3_run_ext(uint64_t entry, uint64_t stack_top, uint64_t arg0, uint64_t arg1, Ring3Result *out)
{
    uint8_t *p = (uint8_t *)&g_res;
    for (uint64_t i = 0; i < sizeof(g_res); i++) p[i] = 0;
    if (!g_init || g_active) { if (out) *out = g_res; return; }
    run_common(entry, stack_top, arg0, arg1, out);
}

void ring3_set_ext_syscall(Ring3ExtSyscall fn) { g_ext_syscall = fn; }
int  ring3_active(void) { return g_active; }
void ring3_finish(Ring3Outcome outcome, uint64_t exit_code)
{
    g_res.outcome = outcome;
    g_res.exit_code = exit_code;
    if (outcome == RING3_OUT_FAULTED) g_faults_isolated++;
    g_active = 0;
    ring3_checkpoint_restore(&g_cp, (int)outcome);
}

static void run_common(uint64_t entry, uint64_t stack_top, uint64_t arg0, uint64_t arg1, Ring3Result *out)
{
    uint64_t saved_flags;
    __asm__ volatile ("pushfq; pop %0" : "=r"(saved_flags));

    g_runs++;
    g_active = 1;

    /* GS base discipline - see isr_common. KERNEL_GS_BASE must be 0 so
     * that ring3_enter's swapgs leaves Ring 3 a zero GS base and parks
     * the kernel's per-CPU pointer where the interrupt entry path finds
     * it. */
    __asm__ volatile ("wrmsr" : : "c"(IA32_KERNEL_GS_BASE), "a"(0), "d"(0));

    int rc = ring3_checkpoint_save(&g_cp);
    if (rc == 0) {
        ring3_enter(entry, stack_top, arg0, arg1);
        /* ring3_enter does not return. */
    }

    /* Resumed from a SYS_EXIT or a fault. Re-establish kernel state the
     * interrupt-gate entry cleared: IF was cleared by the gate, and the
     * longjmp does not restore RFLAGS. */
    g_active = 0;
    if (saved_flags & 0x200) __asm__ volatile ("sti");
    else                     __asm__ volatile ("cli");

    if (out) *out = g_res;
}

/* ---- setup ---------------------------------------------------------------- */
static void zero_page_via_direct_map(uint64_t phys)
{
    volatile uint8_t *p = (volatile uint8_t *)(uintptr_t)(VEX_PHYS_MAP_BASE + phys);
    for (uint64_t i = 0; i < VMM_PAGE_SIZE; i++) p[i] = 0;
}

int ring3_init(void)
{
    if (g_init) return 1;

    if (ring3_prog_size == 0 || ring3_prog_size > VMM_PAGE_SIZE) {
        serial_puts("[ring3] init: test program does not fit one page\n");
        return 0;
    }

    g_region_base = vmm_kmap_reserve_virtual(R3_PAGES);
    if (!g_region_base) { serial_puts("[ring3] init: no virtual space\n"); return 0; }

    g_code_phys  = pmm_alloc_page();
    g_stack_phys = pmm_alloc_page();
    if (!g_code_phys || !g_stack_phys) {
        serial_puts("[ring3] init: out of frames\n");
        return 0;
    }

    /* Fill BEFORE mapping user-accessible, through the supervisor-only
     * direct map, and zero the whole frame first: a recycled frame may
     * hold another subsystem's old contents, and a user-readable page
     * must never start with them. */
    zero_page_via_direct_map(g_code_phys);
    zero_page_via_direct_map(g_stack_phys);
    volatile uint8_t *cp = (volatile uint8_t *)(uintptr_t)(VEX_PHYS_MAP_BASE + g_code_phys);
    for (uint64_t i = 0; i < ring3_prog_size; i++) cp[i] = ring3_prog_base[i];
    volatile uint8_t *sp = (volatile uint8_t *)(uintptr_t)(VEX_PHYS_MAP_BASE + g_stack_phys);
    for (uint64_t i = 0; i < sizeof(g_msg) - 1; i++) sp[i] = (uint8_t)g_msg[i];

    /* Code: user, read-only, EXECUTABLE (no VMM_NX). Stack: user,
     * writable, NX - code cannot be injected into it and run. Neither
     * page is both writable and executable. */
    if (vmm_map_user_page(ring3_code_va(), g_code_phys, VMM_USER) != VMM_OK ||
        vmm_map_user_page(ring3_stack_va(), g_stack_phys,
                          VMM_USER | VMM_WRITE | VMM_NX) != VMM_OK) {
        serial_puts("[ring3] init: vmm_map_user_page failed\n");
        return 0;
    }
    /* The two guard pages stay unmapped: that is the guard. */

    if (!gdt_set_rsp0(0, ring3_kernel_stack_top())) {
        serial_puts("[ring3] init: gdt_set_rsp0 refused\n");
        return 0;
    }
    if (!idt_allow_user_syscall_vector(RING3_SYSCALL_VECTOR)) {
        serial_puts("[ring3] init: idt gate refused\n");
        return 0;
    }
    IrqResult r = irq_register(RING3_SYSCALL_VECTOR, ring3_syscall_handler, "ring3-syscall");
    if (r != IRQ_OK) {
        serial_puts("[ring3] init: irq_register failed\n");
        return 0;
    }

    g_init = 1;
    serial_puts("[ring3] user region at ");
    serial_put_hex64(g_region_base);
    serial_puts(" (code RX, guard, stack RW+NX, guard)\n");
    return 1;
}
