#ifndef VEXOS_RUNTIME_UI_H
#define VEXOS_RUNTIME_UI_H
#include "gfx/fb.h"
void runtime_ui_init(GfxFb *fb, int graphics_ok, int input_ok, int user_ok);
void runtime_ui_update(void);
#endif
