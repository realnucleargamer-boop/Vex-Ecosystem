/*
 * Vex OS - kernel/include/tlb.h
 *
 * KERNEL-01 Phase 4: cross-CPU TLB shootdown.
 *
 *
 * THE PROBLEM
 *
 * `invlpg` invalidates the translation for one linear address on the CPU
 * that executes it, and only on that CPU. Every mapping change in
 * vmm.c ends with a local `invlpg`, which was correct while exactly one
 * CPU was running. It is not correct now. If CPU 0 unmaps a page that
 * CPU 3 has cached in its TLB, CPU 3 keeps translating that address
 * through a page-table entry that no longer exists - reading or writing
 * a frame the kernel believes is free, silently, with no fault. If the
 * frame has since been handed to something else, that is memory
 * corruption whose cause is arbitrarily far from its effect.
 *
 * There is no hardware TLB coherence on x86-64. The only way to
 * invalidate another CPU's TLB is to interrupt it and have it invalidate
 * its own. That interruption, and the protocol that makes it observable,
 * is what this file is.
 *
 *
 * THE PROTOCOL
 *
 * Each CPU owns one request slot. A slot holds a monotonically
 * increasing REQUEST generation written only by initiators, an
 * ACKNOWLEDGED generation written only by the owning CPU, and the address
 * range to invalidate.
 *
 *   1. The initiator has already changed the mapping and invalidated its
 *      OWN TLB. It does that first so that if anything below fails, the
 *      initiator is at least self-consistent.
 *
 *   2. It determines which CPUs need telling: every ONLINE CPU except
 *      itself. Offline CPUs are excluded - a CPU that never came up has
 *      no TLB to invalidate, and waiting for it to acknowledge would be
 *      waiting forever.
 *
 *   3. For each such CPU it writes the range into that CPU's slot, then
 *      publishes a new request generation with a RELEASE store. The
 *      release is what makes the range visible before the generation
 *      that advertises it; without it a receiver could see a new
 *      generation pointing at a stale address and invalidate the wrong
 *      page while reporting success.
 *
 *   4. It sends the shootdown vector - one broadcast-excluding-self when
 *      there is more than one target, a targeted IPI when there is
 *      exactly one. Broadcast is not merely an optimization at high CPU
 *      counts: it is one ICR write instead of thirty-one, each of which
 *      would have its own delivery-status wait.
 *
 *   5. Each receiver, in interrupt context, loads its request generation
 *      with an ACQUIRE load, invalidates the range, and stores that same
 *      generation into its acknowledged field with a RELEASE store. It
 *      takes no lock at all - see below.
 *
 *   6. The initiator waits until every target's acknowledged generation
 *      has reached the generation it published, with a finite bound. It
 *      then reports how many acknowledged.
 *
 *
 * WHY THE RECEIVER TAKES NO LOCK
 *
 * Not for speed. Because taking one would deadlock. vmm_lock() disables
 * interrupts before acquiring the VMM spinlock, so a CPU waiting for that
 * lock cannot service interrupts. If the shootdown handler also needed
 * the VMM lock, then a CPU spinning for it would be unable to answer the
 * shootdown, and an initiator holding it would wait forever for an
 * acknowledgement that could not arrive. The same argument applies to the
 * PMM lock.
 *
 * The receiver is therefore lock-free by construction: a slot's
 * acknowledged field has exactly one writer, the CPU that owns it, so
 * there is nothing to exclude. It calls no allocator, touches no page
 * table, and does nothing that can block.
 *
 *
 * WHY THE INITIATOR MUST HAVE INTERRUPTS ENABLED
 *
 * Two CPUs can shoot down at the same time. If each waited for the other
 * with interrupts disabled, neither could answer the other and both would
 * spin until their timeouts expired - a livelock that would look like
 * mysterious slowness plus two "timeout" counters, on a system where
 * nothing was actually broken.
 *
 * tlb_shootdown_range() therefore REFUSES to run a remote shootdown with
 * interrupts disabled, returning TLB_ERR_UNSAFE_CONTEXT rather than
 * attempting it. In particular this makes it an error to call it while
 * holding the VMM lock, since vmm_lock() clears IF. The correct sequence
 * for a caller is: take the VMM lock, change the mapping, release the
 * lock, then shoot down. Phase 5's reclamation does exactly this, and
 * it is why reclamation cannot be folded into vmm_unmap_page().
 *
 * A local-only shootdown - one CPU online, or no IPI layer - is always
 * permitted regardless of interrupt state, because it is just `invlpg`
 * and cannot wait for anybody. This is what allows the single-threaded
 * boot path to keep calling mapping primitives before the first `sti`.
 *
 *
 * STALE ACKNOWLEDGEMENTS
 *
 * A receiver that was slow, or that took a shootdown IPI whose request it
 * had already serviced, must not be able to satisfy a LATER wait.
 * Generations are monotonic per slot and an initiator waits for
 * acknowledged >= the generation it published, so an acknowledgement from
 * an older request is numerically incapable of satisfying a newer wait.
 * The receiver additionally ignores an interrupt whose generation it has
 * already acknowledged, and counts it, so a spurious or duplicated
 * shootdown IPI is visible rather than silently absorbed.
 *
 *
 * WHAT IS DELIBERATELY ABSENT
 *
 * No batching or deferred flush queues, no per-address-space tracking
 * (there is one address space), no PCID or INVPCID use, no
 * "shootdown-lite" that skips CPUs believed to be idle. Every one of
 * those is an optimization that trades correctness margin for speed on a
 * kernel that has no measured performance problem yet.
 */

#ifndef VEXOS_TLB_H
#define VEXOS_TLB_H

#include <stdint.h>
#include "smp.h"

/* Vector used for shootdown IPIs. Above the timer at 0x20 and below the
 * Phase 3 test vector at 0x41, so the three never collide. */
#define TLB_SHOOTDOWN_VECTOR 0x40

/* Upper bound on pages named by a single request. A request larger than
 * this is served as a full flush instead, because past a few dozen pages
 * reloading CR3 is both cheaper and less error-prone than a long invlpg
 * loop run inside an interrupt handler. */
#define TLB_MAX_RANGE_PAGES 64

typedef enum {
    TLB_OK = 0,
    TLB_OK_LOCAL_ONLY,          /* no remote CPU needed telling */
    TLB_ERR_NOT_READY,          /* tlb_init() has not run */
    TLB_ERR_BAD_RANGE,          /* zero pages, or not page-aligned */
    TLB_ERR_UNSAFE_CONTEXT,     /* remote shootdown with IF clear */
    TLB_ERR_IPI_FAILED,         /* the IPI layer refused to send */
    TLB_ERR_ACK_TIMEOUT         /* a target never acknowledged */
} TlbResult;

/* Registers the shootdown handler on TLB_SHOOTDOWN_VECTOR and records the
 * CPU inventory. Must run on the BSP after SMP startup and after the IPI
 * layer is armed. Returns TLB_OK on success.
 *
 * Until this succeeds, every shootdown degrades to a local invlpg and
 * reports TLB_OK_LOCAL_ONLY - which is exactly right for the
 * single-threaded part of boot, and is why the early mapping calls in
 * kernel_entry need no special-casing. */
TlbResult tlb_init(const SmpInfo *smp);

/* Invalidates `pages` pages starting at `virt` on this CPU and on every
 * other online CPU, and waits for them to confirm.
 *
 * `virt` must be page-aligned and `pages` must be non-zero. Requests
 * larger than TLB_MAX_RANGE_PAGES are promoted to a full flush on the
 * receivers, which is conservative and always correct.
 *
 * MUST NOT be called with the VMM or PMM lock held, and must not be
 * called with interrupts disabled when other CPUs are online - both are
 * refused rather than risked. See the header comment. */
TlbResult tlb_shootdown_range(uint64_t virt, uint32_t pages);

/* Convenience for the single-page case, which is what page-table
 * reclamation needs. */
TlbResult tlb_shootdown_page(uint64_t virt);

/* Invalidates everything, everywhere, by having each CPU reload CR3.
 * Used when a range is too large to enumerate, and available to callers
 * that changed something structural. */
TlbResult tlb_shootdown_all(void);

/* Counters, all monotonic.
 *
 * `stale_ignored` counts shootdown interrupts whose request the receiving
 * CPU had already acknowledged. It is expected to be small but not
 * necessarily zero: a broadcast reaches a CPU that a previous targeted
 * send already served. `timeouts` counts targets that failed to
 * acknowledge inside the bound, and SHOULD be zero on a healthy machine -
 * a non-zero value means a CPU is not answering interrupts. */
uint64_t tlb_shootdowns_initiated(void);
uint64_t tlb_remote_requests(void);      /* target-CPUs asked, cumulative */
uint64_t tlb_acks_received(void);
uint64_t tlb_timeouts(void);
uint64_t tlb_stale_ignored(void);
uint64_t tlb_full_flushes(void);
uint64_t tlb_anonymous_receipts(void);   /* handler ran with no percpu */

/* Shootdowns that FULLY completed: every target acknowledged, or there was
 * no other CPU to tell. This is the counter page-table reclamation checks
 * against, because "the call I made returned OK" is a weaker claim than
 * "a shootdown demonstrably completed between my mapping change and my
 * free" - and it is the weaker claim that a removed or bypassed shootdown
 * could still satisfy. */
uint64_t tlb_completed_count(void);

/* Number of shootdown requests CPU `index` has serviced. Reads another
 * CPU's slot, which is safe because the field has a single writer and is
 * only ever read for reporting. Returns 0 for an out-of-range index. */
uint64_t tlb_serviced_by_cpu(uint32_t index);

/* Pages invalidated by CPU `index`, cumulative. */
uint64_t tlb_pages_invalidated_by_cpu(uint32_t index);

const char *tlb_result_name(TlbResult r);

#endif /* VEXOS_TLB_H */
