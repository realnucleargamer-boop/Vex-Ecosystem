; Vex OS - kernel/src/arch/x86_64/smp/ap_trampoline.asm
;
; BOOT-02C: the AP (application processor) startup trampoline.
;
; This file is assembled SEPARATELY as a flat binary (`nasm -f bin`,
; `org 0`) and then embedded into the kernel image as opaque bytes by
; ap_trampoline_blob.asm. It is deliberately NOT linked with the
; kernel.
;
; WHY A SEPARATE FLAT BINARY:
;   A Startup IPI (SIPI) carries an 8-bit vector V and starts the AP in
;   REAL MODE at CS = V << 8, IP = 0 - i.e. at physical address
;   V * 4096. The AP therefore begins executing at a physical address
;   below 1 MiB that has nothing to do with where the kernel was
;   linked (0x100000). If this code were part of the kernel link, every
;   symbol reference would carry a link-time address that is simply
;   wrong once the bytes have been copied down to a low page. Rather
;   than fight the linker with relocation tricks, the trampoline is a
;   position-independent flat blob: it is copied verbatim to a low page
;   and it computes its own load address at runtime.
;
; RELOCATION STRATEGY (no linker relocation is relied upon anywhere):
;   * In real mode the AP derives its own physical base from CS
;     (base = CS << 4). NASM's `org 0` means every label in this file
;     is a small offset from that base.
;   * The base is carried forward in ESI/RSI across both mode switches,
;     so 32-bit and 64-bit code address the data block as [esi + off]
;     rather than via an absolute address the assembler cannot know.
;   * Both far jumps go through an in-memory far pointer whose offset
;     field is computed and stored at runtime. There is not a single
;     hardcoded absolute address in the mode-switch path.
;
; MODE SEQUENCE:
;   16-bit real mode -> 32-bit protected mode -> 64-bit long mode
;   -> indirect jump to the kernel's C AP entry point.
;
; PAGING: this trampoline does NOT build page tables. It loads the CR3
; value the BSP captured from itself, so APs run on exactly the same
; address space the BSP is already using (which on Vex OS today is
; still the firmware-provided mapping). This is the smallest safe
; mechanism that gets an AP into long mode and is a deliberate choice
; not to introduce a new paging architecture in BOOT-02C. Consequence:
; CR3 must be < 4 GiB, because 32-bit `mov cr3, eax` can only load 32
; bits. The BSP validates this before starting any AP and refuses to
; proceed otherwise rather than silently truncating.
;
; INTERRUPTS: interrupts are disabled on entry (the AP starts with them
; masked) and this code never enables them. No `sti` appears here or in
; the AP C entry path.

BITS 16
org 0

; ---------------------------------------------------------------------
; Data block offsets.
;
; These MUST match the VEX_TRAMPOLINE_* offsets in kernel/include/smp.h.
; The block is placed at a fixed offset near the end of the page so the
; BSP can patch it without needing any symbol information from this
; separately-assembled file. A build-time assertion at the bottom of
; this file checks the block really landed where the header claims.
; ---------------------------------------------------------------------
%define DATA_OFF    0xF00

%define D_CR3       (DATA_OFF + 0x00)   ; u64: CR3 the AP should load
%define D_ENTRY     (DATA_OFF + 0x08)   ; u64: 64-bit C entry address
%define D_RSP       (DATA_OFF + 0x10)   ; u64: stack TOP for this AP
%define D_ARG       (DATA_OFF + 0x18)   ; u64: arg passed in RDI
%define D_ACK       (DATA_OFF + 0x20)   ; u32: AP sets 1 once it has
                                        ;      consumed the fields above
%define D_BASE      (DATA_OFF + 0x24)   ; u32: base, stored for debugging

; Selectors within this trampoline's own temporary GDT.
%define SEL_CODE32  0x08
%define SEL_DATA    0x10
%define SEL_CODE64  0x18

; =====================================================================
; 16-bit real mode entry - this is where the SIPI lands (offset 0).
; =====================================================================
real_entry:
    cli
    cld

    ; DS = CS so the small in-page offsets below address this page.
    mov     ax, cs
    mov     ds, ax

    ; base = CS << 4. This is the physical address this page was
    ; copied to, discovered at runtime rather than assumed.
    movzx   eax, ax
    shl     eax, 4
    mov     [d_base_off], eax           ; kept for post-mortem debugging
    mov     esi, eax                    ; ESI carries base from here on

    ; Patch the GDT pseudo-descriptor's base field: linear address of
    ; our temporary GDT = base + gdt32.
    mov     ebx, eax
    add     ebx, gdt32
    mov     [gdtr_base], ebx

    ; Patch the 32-bit far pointer's offset field.
    mov     ebx, eax
    add     ebx, pm_entry
    mov     [pm_far_off], ebx

    ; Patch the 64-bit far pointer's offset field.
    mov     ebx, eax
    add     ebx, lm_entry
    mov     [lm_far_off], ebx

    lgdt    [gdtr]

    ; Enter protected mode (CR0.PE). Paging is still off at this point;
    ; it gets enabled together with long mode in pm_entry.
    mov     eax, cr0
    or      eax, 1
    mov     cr0, eax

    ; Indirect far jump - the offset was computed above, so nothing
    ; here depends on a link-time address.
    jmp     dword far [pm_far]

; =====================================================================
; 32-bit protected mode.
; ESI = trampoline physical base (survived the far jump).
; =====================================================================
BITS 32
pm_entry:
    mov     ax, SEL_DATA
    mov     ds, ax
    mov     es, ax
    mov     ss, ax
    mov     fs, ax
    mov     gs, ax

    ; A temporary stack is NOT set up here. Nothing between this point
    ; and the 64-bit entry pushes anything, so giving the AP a stack it
    ; would immediately abandon would only add a failure mode.

    ; CR4.PAE must be set before long mode can be enabled.
    mov     eax, cr4
    or      eax, 1 << 5                 ; PAE
    mov     cr4, eax

    ; Adopt the BSP's page tables. The BSP guarantees this value is
    ; below 4 GiB before starting any AP.
    mov     eax, [esi + D_CR3]
    mov     cr3, eax

    ; EFER.LME - request long mode.
    mov     ecx, 0xC0000080             ; IA32_EFER
    rdmsr
    or      eax, 1 << 8                 ; LME
    wrmsr

    ; CR0.PG - enabling paging with LME set activates long mode. The
    ; CPU is in 32-bit compatibility mode immediately after this, and
    ; only the far jump below makes it genuinely 64-bit.
    mov     eax, cr0
    or      eax, 1 << 31                ; PG
    mov     cr0, eax

    jmp     far [esi + lm_far]

; =====================================================================
; 64-bit long mode.
; RSI = trampoline physical base (zero-extended from ESI).
; =====================================================================
BITS 64
lm_entry:
    mov     ax, SEL_DATA
    mov     ds, ax
    mov     es, ax
    mov     ss, ax
    mov     fs, ax
    mov     gs, ax

    ; Consume every per-AP field into registers BEFORE acknowledging.
    ;
    ; This ordering is the whole reason the shared data block is safe:
    ; the BSP starts APs one at a time and does not rewrite these
    ; fields until it has seen D_ACK. If the ack were published before
    ; the values were read, the BSP could legally overwrite D_RSP for
    ; the next AP while this AP was still reading it - two CPUs would
    ; then end up on the same stack.
    mov     rsp, [rsi + D_RSP]
    mov     rax, [rsi + D_ENTRY]
    mov     rdi, [rsi + D_ARG]

    ; Publish the acknowledgement. On x86-64 ordinary stores are not
    ; reordered with earlier loads in a way that matters here, but an
    ; explicit barrier makes the intent unambiguous and costs nothing
    ; on a path that executes once per AP.
    mfence
    mov     dword [rsi + D_ACK], 1

    ; Enter the kernel's C AP entry. Deliberately a jump, not a call:
    ; there is nothing sensible to return to, and the AP entry never
    ; returns.
    jmp     rax

; =====================================================================
; Temporary GDT.
;
; Only what the mode switches need: a 32-bit code segment, a data
; segment, and a 64-bit code segment. The AP replaces this with the
; kernel's real GDT as soon as it is executing C code.
; =====================================================================
align 16
gdt32:
    dq 0x0000000000000000               ; 0x00 null

    ; 0x08: 32-bit code, base 0, limit 4 GiB, granularity 4 KiB, D/B set
    dw 0xFFFF, 0x0000
    db 0x00, 0x9A, 0xCF, 0x00

    ; 0x10: data, base 0, limit 4 GiB
    dw 0xFFFF, 0x0000
    db 0x00, 0x92, 0xCF, 0x00

    ; 0x18: 64-bit code. L=1 (bit 21 of the granularity byte) marks it
    ; as 64-bit; D must be 0 when L is 1.
    dw 0x0000, 0x0000
    db 0x00, 0x9A, 0x20, 0x00
gdt32_end:

align 4
gdtr:
    dw gdt32_end - gdt32 - 1            ; limit
gdtr_base:
    dd 0                                ; patched at runtime

; Far pointer used to reach 32-bit protected mode (m16:32).
align 4
pm_far:
pm_far_off:
    dd 0                                ; patched at runtime
    dw SEL_CODE32

; Far pointer used to reach 64-bit long mode (m16:32).
align 4
lm_far:
lm_far_off:
    dd 0                                ; patched at runtime
    dw SEL_CODE64

; Fail the build rather than silently produce a trampoline whose code
; would run into its own data block.
%if ($ - $$) > DATA_OFF
  %error "AP trampoline code+GDT overflowed into the data block"
%endif

; ---------------------------------------------------------------------
; Data block, padded to its fixed offset.
; ---------------------------------------------------------------------
times DATA_OFF - ($ - $$) db 0

data_block:
    dq 0                                ; D_CR3
    dq 0                                ; D_ENTRY
    dq 0                                ; D_RSP
    dq 0                                ; D_ARG
    dd 0                                ; D_ACK
d_base_off:
    dd 0                                ; D_BASE

; Pad the blob to a full 4 KiB page so the copy length is unambiguous.
times 4096 - ($ - $$) db 0

%if ($ - $$) != 4096
  %error "AP trampoline blob is not exactly 4096 bytes"
%endif
