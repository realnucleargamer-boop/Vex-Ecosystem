# Vex OS - run-qemu.ps1
#
# Launches the integrated BOOT-03/KERNEL-01 baseline in QEMU + OVMF on Windows.
# Direct logical port of scripts/run-qemu.sh - same flags, same safety
# properties.
#
# QEMU is located automatically via scripts\VexToolchain.ps1, for the same
# reason build.ps1 does it: the QEMU-for-Windows installer does not reliably
# put qemu-system-x86_64.exe on PATH, and a PATH edit made in one terminal
# never reaches an already-open one.
#
# Per Development Rule 6: this is the ONLY sanctioned way to test boot
# code until VM bring-up is stable. This script's -drive arguments are
# verified below to reference ONLY project-local files under build\ -
# never a physical disk (\\.\PhysicalDriveN) or the host's real EFI
# System Partition.

#Requires -Version 5.1

[CmdletBinding()]
param(
    # Ignore build\toolchain.local.json and re-discover QEMU.
    [switch]$RefreshTools
)

$ErrorActionPreference = "Stop"

$RepoRoot = Split-Path -Parent $PSCommandPath
$BuildDir = Join-Path $RepoRoot "build"
$ImgPath  = Join-Path $BuildDir "vexos.img"

function Write-Fail($msg) { Write-Host "ERROR: $msg" -ForegroundColor Red; exit 1 }

if (-not (Test-Path $ImgPath)) {
    Write-Fail "$ImgPath not found - run build.ps1 first."
}

. (Join-Path $RepoRoot "scripts\VexToolchain.ps1")

try {
    $tc = Resolve-VexToolchain -RepoRoot $RepoRoot -Require @("qemu") -Refresh:$RefreshTools -Quiet
} catch {
    Write-Fail $_.Exception.Message
}
$QemuPath = $tc["qemu"]

# OVMF firmware location. Override with $env:OVMF_DIR if yours differs.
# Common locations: alongside the QEMU install, or wherever you
# downloaded standalone EDK2/OVMF release artifacts to.
$OvmfDir = $env:OVMF_DIR
if (-not $OvmfDir) {
    $qemuDir = Split-Path -Parent $QemuPath
    $candidates = @(
        (Join-Path $qemuDir "share"),
        $qemuDir,
        "C:\Program Files\qemu\share",
        (Join-Path $BuildDir "ovmf")
    )
    $OvmfDir = $candidates | Where-Object { $_ -and (Test-Path (Join-Path $_ "OVMF_CODE.fd")) } | Select-Object -First 1
}

$OvmfCode = $env:OVMF_CODE
$OvmfVarsSrc = $env:OVMF_VARS
if (-not $OvmfCode -and $OvmfDir) { $OvmfCode = Join-Path $OvmfDir "OVMF_CODE.fd" }
if (-not $OvmfVarsSrc -and $OvmfDir) { $OvmfVarsSrc = Join-Path $OvmfDir "OVMF_VARS.fd" }
if (-not $OvmfCode -or -not $OvmfVarsSrc) {
    Write-Fail "OVMF firmware directory could not be determined.`n  Set `$env:OVMF_DIR to the folder containing OVMF_CODE.fd / OVMF_VARS.fd,`n  or `$env:OVMF_CODE / `$env:OVMF_VARS to exact file paths."
}

if (-not (Test-Path $OvmfCode) -or -not (Test-Path $OvmfVarsSrc)) {
    Write-Fail "OVMF firmware not found (looked for OVMF_CODE.fd / OVMF_VARS.fd).`n  Set `$env:OVMF_DIR to the folder containing them, or `$env:OVMF_CODE / `$env:OVMF_VARS to exact file paths.`n  Some QEMU-for-Windows distributions bundle these under their install's share\ folder; otherwise download standalone EDK2/OVMF release artifacts."
}

# Local writable copy of OVMF_VARS - the installed/shared copy is
# never opened for writing, mirroring run-qemu.sh's behavior.
$OvmfVarsLocal = Join-Path $BuildDir "OVMF_VARS.local.fd"
if (-not (Test-Path $OvmfVarsLocal)) {
    Copy-Item $OvmfVarsSrc $OvmfVarsLocal
}

# Default to 4 virtual CPUs so ACPI/MADT detection (BOOT-02B) has more
# than one CPU to actually find. Override with $env:VEXOS_SMP if
# needed - BOOT-02B only detects CPUs, it doesn't start them yet, so
# any count here is safe.
if (-not $env:VEXOS_SMP) { $env:VEXOS_SMP = "4" }

# --- Host-safety check, enforced structurally, not just by convention ---
# Both drive paths below MUST resolve under $BuildDir. Anything else
# (a bare drive letter, a \\.\PhysicalDriveN path, a path outside the
# repo) aborts before QEMU is ever invoked.
foreach ($p in @($ImgPath, $OvmfVarsLocal)) {
    $resolved = (Resolve-Path $p).Path
    if (-not $resolved.StartsWith((Resolve-Path $BuildDir).Path)) {
        Write-Fail "Refusing to launch QEMU: '$resolved' is outside $BuildDir. This should never happen - stopping rather than risk touching host disks."
    }
}

Write-Host "Launching Vex OS (BOOT-03 baseline) in QEMU..." -ForegroundColor Cyan
Write-Host "  QEMU:       $QemuPath" -ForegroundColor DarkGray
Write-Host "  Disk image: $ImgPath" -ForegroundColor DarkGray
Write-Host "  OVMF code:  $OvmfCode (read-only)" -ForegroundColor DarkGray
Write-Host "  OVMF vars:  $OvmfVarsLocal (local, writable)" -ForegroundColor DarkGray
Write-Host ""

& $QemuPath `
    -machine q35,accel=tcg `
    -cpu qemu64 `
    -smp $env:VEXOS_SMP `
    -m 512M `
    -drive if=pflash,format=raw,readonly=on,file="$OvmfCode" `
    -drive if=pflash,format=raw,file="$OvmfVarsLocal" `
    -drive format=vpc,file="$ImgPath" `
    -serial stdio `
    -no-reboot `
    -no-shutdown
