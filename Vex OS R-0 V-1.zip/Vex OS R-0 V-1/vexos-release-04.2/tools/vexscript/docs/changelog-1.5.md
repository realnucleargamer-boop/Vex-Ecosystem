# Changelog — VEX-Script 1.5.0

## Added
- Explicit casts: `expr as i32` / `expr as i64` with range check on narrow
- Strict bool conditions for if/while/for
- Return-path analysis in typechecker
- Function-value foundation (`let f = add; f(...)`)
- `str_len` stdlib alias

## Strengthened
- Static type coverage for lets, returns, calls, structs, fields, casts

## Breaking
- Integer used as `if`/`while` condition is now a type error (must be bool)

## Compatibility
- 1.0–1.4 programs that already used comparison conditions remain valid
