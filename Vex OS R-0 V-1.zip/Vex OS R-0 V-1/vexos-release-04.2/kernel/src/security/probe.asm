; Vex OS - kernel/src/security/probe.asm
;
; SECURITY-01: faulting access probes.
;
; A probe performs ONE real memory access that is expected to fault, and
; returns whether it completed. The fault is a genuine CPU exception: it
; is delivered through the IDT, recorded by idt.c, and then control is
; redirected here to a fixup label. Nothing is repaired - the access is
; supposed to remain denied, and repairing it would delete the evidence
; the test exists to collect.
;
; HOW THE FIXUP WORKS
;
;   Before the access, the probe publishes two things: a nonzero
;   `sec_probe_active` flag, and the address to resume at. The #PF/#GP/#UD
;   handler checks that flag; if set, it overwrites the return RIP in the
;   interrupt frame with the fixup address and iretq's there instead of
;   panicking. This is the same mechanism a real kernel's user-copy
;   exception table uses, reduced to one slot.
;
;   RSP is saved and restored explicitly. It has to be: sec_probe_exec
;   faults during an indirect CALL, which has already pushed a return
;   address, and the #PF is taken with RSP below where the probe started.
;   Resuming at a fixup without restoring RSP would leak stack on every
;   probe and, worse, would make the amount leaked depend on which
;   exception occurred.
;
;   Single-slot and BSP-only by design. Concurrency here would be a
;   second implementation of exception handling, which is not something
;   this milestone is entitled to build.

BITS 64

section .data
align 8
global sec_probe_active
global sec_probe_fixup_rip
global sec_probe_saved_rsp
sec_probe_active:    dq 0
sec_probe_fixup_rip: dq 0
sec_probe_saved_rsp: dq 0

section .text

; int sec_probe_read8(uint64_t addr /*rdi*/, uint8_t *out /*rsi*/)
global sec_probe_read8
sec_probe_read8:
    mov     [rel sec_probe_saved_rsp], rsp
    lea     rax, [rel .fault]
    mov     [rel sec_probe_fixup_rip], rax
    mov     qword [rel sec_probe_active], 1

    xor     eax, eax
    mov     al, [rdi]              ; <-- the access under test

    mov     qword [rel sec_probe_active], 0
    test    rsi, rsi
    jz      .ok
    mov     [rsi], al
.ok:
    mov     eax, 1                 ; completed
    ret
.fault:
    mov     rsp, [rel sec_probe_saved_rsp]
    mov     qword [rel sec_probe_active], 0
    xor     eax, eax               ; faulted
    ret

; int sec_probe_write8(uint64_t addr /*rdi*/, uint8_t value /*sil*/)
global sec_probe_write8
sec_probe_write8:
    mov     [rel sec_probe_saved_rsp], rsp
    lea     rax, [rel .fault]
    mov     [rel sec_probe_fixup_rip], rax
    mov     qword [rel sec_probe_active], 1

    mov     [rdi], sil             ; <-- the access under test

    mov     qword [rel sec_probe_active], 0
    mov     eax, 1
    ret
.fault:
    mov     rsp, [rel sec_probe_saved_rsp]
    mov     qword [rel sec_probe_active], 0
    xor     eax, eax
    ret

; int sec_probe_exec(uint64_t addr /*rdi*/)
;
; Attempts to EXECUTE at `addr`. Used to show that an NX mapping really
; is non-executable rather than merely flagged.
;
; The target is called, not jumped to, so that a page which unexpectedly
; IS executable returns here instead of running off into whatever
; follows. A page containing arbitrary data that happens to be
; executable will almost certainly fault on a later instruction - which
; is still reported as "faulted", and is why the test that uses this
; asserts on the recorded exception rather than on the return value
; alone.
global sec_probe_exec
sec_probe_exec:
    mov     [rel sec_probe_saved_rsp], rsp
    lea     rax, [rel .fault]
    mov     [rel sec_probe_fixup_rip], rax
    mov     qword [rel sec_probe_active], 1

    call    rdi                    ; <-- the fetch under test

    mov     qword [rel sec_probe_active], 0
    mov     eax, 1
    ret
.fault:
    mov     rsp, [rel sec_probe_saved_rsp]
    mov     qword [rel sec_probe_active], 0
    xor     eax, eax
    ret
