/*
 * vec.c - GFX-VEC-01 vector rasteriser (see kernel/include/gfx/vec.h for the guarantees and limits).
 * Pure integer: Q24.8 coordinates, Q16 coverage accumulation, int64 intermediates. No libc, no heap, no FPU.
 * Algorithm: per pixel row, every edge adds its exact signed area/cover into a 1-D accumulation row
 * (the "signed-area" method used by font-rs/stb_truetype v2); a running sum across the row is the pixel coverage.
 */
#include "gfx/vec.h"

#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC optimize ("O2", "no-tree-loop-distribute-patterns")   /* kernel is -O0; this file is the pixel hot path. The 2nd flag stops GCC turning our
                                                                       zero/copy loops into memset/memcpy calls (the kernel links no libc). */
#endif

#define COORD_LIMIT (1 << 28)   /* inputs are clamped to +-1M px so that every product below fits int64 */

static const int32_t g_cos64[64] = {
    65536, 65220, 64277, 62714, 60547, 57798, 54491, 50660,
    46341, 41576, 36410, 30893, 25080, 19024, 12785, 6424,
    0, -6424, -12785, -19024, -25080, -30893, -36410, -41576,
    -46341, -50660, -54491, -57798, -60547, -62714, -64277, -65220,
    -65536, -65220, -64277, -62714, -60547, -57798, -54491, -50660,
    -46341, -41576, -36410, -30893, -25080, -19024, -12785, -6424,
    0, 6424, 12785, 19024, 25080, 30893, 36410, 41576,
    46341, 50660, 54491, 57798, 60547, 62714, 64277, 65220 };
static const int32_t g_sin64[64] = {
    0, 6424, 12785, 19024, 25080, 30893, 36410, 41576,
    46341, 50660, 54491, 57798, 60547, 62714, 64277, 65220,
    65536, 65220, 64277, 62714, 60547, 57798, 54491, 50660,
    46341, 41576, 36410, 30893, 25080, 19024, 12785, 6424,
    0, -6424, -12785, -19024, -25080, -30893, -36410, -41576,
    -46341, -50660, -54491, -57798, -60547, -62714, -64277, -65220,
    -65536, -65220, -64277, -62714, -60547, -57798, -54491, -50660,
    -46341, -41576, -36410, -30893, -25080, -19024, -12785, -6424 };

static vfx clampc(int64_t v) { return (vfx)(v > COORD_LIMIT ? COORD_LIMIT : v < -COORD_LIMIT ? -COORD_LIMIT : v); }
static int64_t iabs64(int64_t v) { return v < 0 ? -v : v; }
static uint32_t isqrt64(uint64_t n)
{
    uint64_t res = 0, bit = (uint64_t)1 << 62;
    while (bit > n) bit >>= 2;
    while (bit) { if (n >= res + bit) { n -= res + bit; res = (res >> 1) + bit; } else res >>= 1; bit >>= 2; }
    return (uint32_t)res;
}

/* ------------------------------------------------------------------------------------------------ path building */
void vec_path_begin(VecPath *p) { p->npts = 0; p->nsub = 0; p->cx = 0; p->cy = 0; p->need_move = 0; p->err = 0; }

static void add_pt(VecPath *p, vfx x, vfx y)
{
    if (p->npts >= VEC_MAX_PTS) { p->err = 1; return; }
    p->x[p->npts] = clampc(x); p->y[p->npts] = clampc(y); p->npts++;
    p->cx = clampc(x); p->cy = clampc(y);
}

void vec_move_to(VecPath *p, vfx x, vfx y)
{
    if (p->nsub >= VEC_MAX_SUBPATHS) { p->err = 1; return; }
    p->sub_start[p->nsub] = p->npts; p->sub_closed[p->nsub] = 0; p->nsub++;
    p->need_move = 0;
    add_pt(p, x, y);
}

static void ensure_sub(VecPath *p) { if (p->nsub == 0 || p->need_move) vec_move_to(p, p->cx, p->cy); }

void vec_line_to(VecPath *p, vfx x, vfx y) { ensure_sub(p); add_pt(p, x, y); }

void vec_close(VecPath *p)
{
    if (p->nsub == 0) return;
    p->sub_closed[p->nsub - 1] = 1;
    p->cx = p->x[p->sub_start[p->nsub - 1]]; p->cy = p->y[p->sub_start[p->nsub - 1]];
    p->need_move = 1;
}

/* segments for a curve: from the control-polygon deviation (in px), aiming at ~0.1 px flatness */
static int seg_count(int64_t dev_q8, int cubic)
{
    int64_t dev_px_x16 = dev_q8 / 16;                       /* px * 16 */
    uint32_t n = isqrt64((uint64_t)(dev_px_x16 * (cubic ? 12 : 10)) / 4) + 1;   /* ~ sqrt(dev_px * k) */
    if (n < 2) n = 2;
    return (int)(n > (cubic ? 40u : 28u) ? (cubic ? 40u : 28u) : n);
}

void vec_quad_to(VecPath *p, vfx qx, vfx qy, vfx x, vfx y)
{
    ensure_sub(p);
    int64_t x0 = p->cx, y0 = p->cy, x1 = qx, y1 = qy, x2 = x, y2 = y;
    int64_t dev = iabs64(x0 - 2 * x1 + x2) + iabs64(y0 - 2 * y1 + y2);
    int n = seg_count(dev, 0);
    for (int i = 1; i <= n; i++) {
        int64_t a = n - i, b = i, nn = (int64_t)n * n;
        int64_t px = (a * a * x0 + 2 * a * b * x1 + b * b * x2 + nn / 2) / nn, py = (a * a * y0 + 2 * a * b * y1 + b * b * y2 + nn / 2) / nn;
        if (px < 0) px = (a * a * x0 + 2 * a * b * x1 + b * b * x2 - nn / 2) / nn;
        if (py < 0) py = (a * a * y0 + 2 * a * b * y1 + b * b * y2 - nn / 2) / nn;
        add_pt(p, (vfx)px, (vfx)py);
    }
}

void vec_cubic_to(VecPath *p, vfx ax, vfx ay, vfx bx, vfx by, vfx x, vfx y)
{
    ensure_sub(p);
    int64_t x0 = p->cx, y0 = p->cy, x1 = ax, y1 = ay, x2 = bx, y2 = by, x3 = x, y3 = y;
    int64_t d1 = iabs64(x0 - 2 * x1 + x2) + iabs64(y0 - 2 * y1 + y2), d2 = iabs64(x1 - 2 * x2 + x3) + iabs64(y1 - 2 * y2 + y3);
    int n = seg_count(d1 > d2 ? d1 : d2, 1);
    for (int i = 1; i <= n; i++) {
        int64_t a = n - i, b = i, nnn = (int64_t)n * n * n;
        int64_t c0 = a * a * a, c1 = 3 * a * a * b, c2 = 3 * a * b * b, c3 = b * b * b;
        int64_t sx = c0 * x0 + c1 * x1 + c2 * x2 + c3 * x3, sy = c0 * y0 + c1 * y1 + c2 * y2 + c3 * y3;
        sx = sx >= 0 ? (sx + nnn / 2) / nnn : (sx - nnn / 2) / nnn; sy = sy >= 0 ? (sy + nnn / 2) / nnn : (sy - nnn / 2) / nnn;
        add_pt(p, (vfx)sx, (vfx)sy);
    }
}

#define KAPPA_Q16 36195     /* 0.552284749831 * 65536: cubic approximation of a quarter circle */

void vec_add_ellipse(VecPath *p, vfx cx, vfx cy, vfx rx, vfx ry)
{
    if (rx <= 0 || ry <= 0) return;
    int64_t kx = ((int64_t)rx * KAPPA_Q16) >> 16, ky = ((int64_t)ry * KAPPA_Q16) >> 16;
    vec_move_to(p, cx + rx, cy);
    vec_cubic_to(p, cx + rx, cy + (vfx)ky, cx + (vfx)kx, cy + ry, cx, cy + ry);
    vec_cubic_to(p, cx - (vfx)kx, cy + ry, cx - rx, cy + (vfx)ky, cx - rx, cy);
    vec_cubic_to(p, cx - rx, cy - (vfx)ky, cx - (vfx)kx, cy - ry, cx, cy - ry);
    vec_cubic_to(p, cx + (vfx)kx, cy - ry, cx + rx, cy - (vfx)ky, cx + rx, cy);
    vec_close(p);
}

void vec_add_rrect(VecPath *p, vfx x, vfx y, vfx w, vfx h, vfx rx, vfx ry)
{
    if (w <= 0 || h <= 0) return;
    if (rx < 0) rx = 0;
    if (ry < 0) ry = 0;
    if (rx > w / 2) rx = w / 2;
    if (ry > h / 2) ry = h / 2;
    int64_t kx = ((int64_t)rx * KAPPA_Q16) >> 16, ky = ((int64_t)ry * KAPPA_Q16) >> 16;
    vec_move_to(p, x + rx, y);
    vec_line_to(p, x + w - rx, y);
    if (rx && ry) vec_cubic_to(p, x + w - rx + (vfx)kx, y, x + w, y + ry - (vfx)ky, x + w, y + ry);
    vec_line_to(p, x + w, y + h - ry);
    if (rx && ry) vec_cubic_to(p, x + w, y + h - ry + (vfx)ky, x + w - rx + (vfx)kx, y + h, x + w - rx, y + h);
    vec_line_to(p, x + rx, y + h);
    if (rx && ry) vec_cubic_to(p, x + rx - (vfx)kx, y + h, x, y + h - ry + (vfx)ky, x, y + h - ry);
    vec_line_to(p, x, y + ry);
    if (rx && ry) vec_cubic_to(p, x, y + ry - (vfx)ky, x + rx - (vfx)kx, y, x + rx, y);
    vec_close(p);
}

/* ------------------------------------------------------------------------------------------------ rasteriser */
typedef void (*RowFn)(void *ctx, int y, int x0, const uint8_t *cov, int n);

static int32_t g_acc[VEC_MAX_W + 4];
static uint8_t g_cov[VEC_MAX_W + 4];

/* Add one clipped edge piece (x in Q8 relative to the row origin, d = signed cover in Q16) to the accumulation row. */
static void acc_edge(int32_t *a, int32_t xa, int32_t xb, int32_t d, int *tmin, int *tmax)
{
    int32_t xl = xa < xb ? xa : xb, xr = xa < xb ? xb : xa;
    int xi0 = xl >> 8, xi1 = (xr + 255) >> 8;
    if (xi0 < *tmin) *tmin = xi0;
    if (xi1 + 1 > *tmax) *tmax = xi1 + 1;
    if (xi1 <= xi0 + 1) {
        int32_t xmf = ((xa + xb) >> 1) - (xi0 << 8);
        int32_t part = (int32_t)(((int64_t)d * xmf) >> 8);
        a[xi0] += d - part; a[xi0 + 1] += part;
    } else {
        int64_t s = ((int64_t)256 * 65536) / (int64_t)(xr - xl);                 /* 1/dx in Q16 */
        int32_t x0f = xl - (xi0 << 8), x1f = xr - (xi1 << 8) + 256;
        int64_t a0 = (s * (256 - x0f) * (256 - x0f)) >> 17, am = (s * x1f * x1f) >> 17;
        a[xi0] += (int32_t)(((int64_t)d * a0) >> 16);
        if (xi1 == xi0 + 2) {
            a[xi0 + 1] += (int32_t)(((int64_t)d * (65536 - a0 - am)) >> 16);
        } else {
            int64_t a1 = (s * (384 - x0f)) >> 8;
            a[xi0 + 1] += (int32_t)(((int64_t)d * (a1 - a0)) >> 16);
            int32_t ds = (int32_t)(((int64_t)d * s) >> 16);
            for (int xi = xi0 + 2; xi < xi1 - 1; xi++) a[xi] += ds;
            int64_t a2 = a1 + (int64_t)(xi1 - xi0 - 3) * s;
            a[xi1 - 1] += (int32_t)(((int64_t)d * (65536 - a2 - am)) >> 16);
        }
        a[xi1] += (int32_t)(((int64_t)d * am) >> 16);
    }
}

static int raster(const VecPath *p, int evenodd, int cx0, int cy0, int cx1, int cy1, RowFn fn, void *ctx)
{
    if (!p || p->err) return -1;
    if (p->npts < 2 || cx1 <= cx0 || cy1 <= cy0) return 0;
    int32_t minx = p->x[0], maxx = p->x[0], miny = p->y[0], maxy = p->y[0];
    for (int i = 1; i < p->npts; i++) {
        if (p->x[i] < minx) minx = p->x[i];
        if (p->x[i] > maxx) maxx = p->x[i];
        if (p->y[i] < miny) miny = p->y[i];
        if (p->y[i] > maxy) maxy = p->y[i];
    }
    int bx0 = minx >> 8, bx1 = (maxx + 255) >> 8, by0 = miny >> 8, by1 = (maxy + 255) >> 8;
    if ((int64_t)bx1 - bx0 + 4 > VEC_MAX_W) return -1;
    int ya = by0 > cy0 ? by0 : cy0, yb = by1 < cy1 ? by1 : cy1;
    int xa = bx0 > cx0 ? bx0 : cx0, xb = bx1 < cx1 ? bx1 : cx1;
    if (ya >= yb || xa >= xb) return 0;
    int bw = bx1 - bx0 + 3;

    for (int y = ya; y < yb; y++) {
        int tmin = bw, tmax = -1;
        int32_t ys = (int32_t)y * 256, ye = ys + 256;
        for (int s = 0; s < p->nsub; s++) {
            int st = p->sub_start[s], en = (s + 1 < p->nsub) ? p->sub_start[s + 1] : p->npts;
            if (en - st < 2) continue;
            for (int i = st; i < en; i++) {
                int j = (i + 1 < en) ? i + 1 : st;                       /* the closing edge is implicit: fills are always closed */
                int64_t ex0 = p->x[i], ey0 = p->y[i], ex1 = p->x[j], ey1 = p->y[j]; int dir = 1;
                if (ey0 == ey1) continue;
                if (ey0 > ey1) { int64_t t = ex0; ex0 = ex1; ex1 = t; t = ey0; ey0 = ey1; ey1 = t; dir = -1; }
                if (ey1 <= ys || ey0 >= ye) continue;
                int64_t ca = ey0 > ys ? ey0 : ys, cb = ey1 < ye ? ey1 : ye, dy = ey1 - ey0, dx = ex1 - ex0;
                int64_t pxa = ex0 + dx * (ca - ey0) / dy - (int64_t)bx0 * 256, pxb = ex0 + dx * (cb - ey0) / dy - (int64_t)bx0 * 256;
                if (pxa < 0) pxa = 0;
                if (pxb < 0) pxb = 0;
                acc_edge(g_acc, (int32_t)pxa, (int32_t)pxb, dir * (int32_t)((cb - ca) * 256), &tmin, &tmax);
            }
        }
        if (tmax >= 0) {
            if (tmax > bw) tmax = bw;
            int32_t run = 0; int first = -1, last = -1;
            for (int c = 0; c <= tmax; c++) {
                run += g_acc[c]; g_acc[c] = 0;
                int64_t v = run < 0 ? -(int64_t)run : run;
                if (evenodd) { v &= 131071; if (v > 65536) v = 131072 - v; } else if (v > 65536) v = 65536;
                int cv = (int)((v * 255 + 32768) >> 16);
                g_cov[c] = (uint8_t)cv;
                int px = bx0 + c;
                if (cv && px >= xa && px < xb) { if (first < 0) first = c; last = c; }
            }
            if (first >= 0) fn(ctx, y, bx0 + first, g_cov + first, last - first + 1);
        }
    }
    return 0;
}

/* ---- framebuffer sink ---- */
typedef struct { const GfxFb *fb; const VecPaint *paint; int xa, xb; } FbCtx;
static inline int div255(int v) { v += 128; return (v + (v >> 8)) >> 8; }

static void fb_row(void *vc, int y, int x0, const uint8_t *cov, int n)
{
    FbCtx *c = vc; const GfxFb *fb = c->fb; const VecPaint *pt = c->paint;
    GfxColor col = pt->c0;
    if (pt->vgrad) {
        int64_t span = (int64_t)pt->gy1 - pt->gy0, t = span > 0 ? (((int64_t)y * 256 + 128 - pt->gy0) * 256) / span : 0;
        if (t < 0) t = 0;
        if (t > 256) t = 256;
        col.r = (uint8_t)(pt->c0.r + (((int)pt->c1.r - pt->c0.r) * (int)t) / 256);
        col.g = (uint8_t)(pt->c0.g + (((int)pt->c1.g - pt->c0.g) * (int)t) / 256);
        col.b = (uint8_t)(pt->c0.b + (((int)pt->c1.b - pt->c0.b) * (int)t) / 256);
    }
    volatile uint32_t *row = fb->pixels + (size_t)y * fb->pitch_px;
    uint32_t solid = gfx_encode(fb, col);
    for (int i = 0; i < n; i++) {
        int x = x0 + i; if (x < c->xa || x >= c->xb) continue;
        int a = cov[i]; if (!a) continue;
        a = pt->alpha == 255 ? a : div255(a * pt->alpha);
        if (a >= 255) { row[x] = solid; continue; }
        if (!a) continue;
        uint32_t d = row[x];
        int dr = (d >> fb->r_shift) & 255, dg = (d >> fb->g_shift) & 255, db = (d >> fb->b_shift) & 255;
        dr = div255(col.r * a + dr * (255 - a)); dg = div255(col.g * a + dg * (255 - a)); db = div255(col.b * a + db * (255 - a));
        row[x] = ((uint32_t)dr << fb->r_shift) | ((uint32_t)dg << fb->g_shift) | ((uint32_t)db << fb->b_shift);
    }
}

int vec_fill(const GfxFb *fb, const VecPath *p, int evenodd, const VecPaint *paint, const VecClip *clip)
{
    if (!fb || !fb->ok || !fb->pixels || !p || !paint) return -1;
    int cx0 = 0, cy0 = 0, cx1 = (int)fb->width, cy1 = (int)fb->height;
    if (clip) {
        if (clip->x0 > cx0) cx0 = clip->x0;
        if (clip->y0 > cy0) cy0 = clip->y0;
        if (clip->x1 < cx1) cx1 = clip->x1;
        if (clip->y1 < cy1) cy1 = clip->y1;
    }
    FbCtx c = { fb, paint, cx0, cx1 };
    return raster(p, evenodd, cx0, cy0, cx1, cy1, fb_row, &c);
}

/* ---- mask sink ---- */
typedef struct { uint8_t *m; int w; } MaskCtx;
static void mask_row(void *vc, int y, int x0, const uint8_t *cov, int n)
{
    MaskCtx *c = vc;
    for (int i = 0; i < n; i++) { int x = x0 + i; if (x >= 0 && x < c->w) c->m[(size_t)y * c->w + x] = cov[i]; }
}
int vec_mask(const VecPath *p, int evenodd, int w, int h, uint8_t *out)
{
    if (!out || w <= 0 || h <= 0 || (int64_t)w * h > (1 << 24)) return -1;
    for (int64_t i = 0; i < (int64_t)w * h; i++) out[i] = 0;
    MaskCtx c = { out, w };
    return raster(p, evenodd, 0, 0, w, h, mask_row, &c);
}

/* ------------------------------------------------------------------------------------------------ stroking
 * A stroke is built as ONE non-overlapping outline per subpath (left offset chain, round/bevel joins on the outer side,
 * end cap, then the reversed chain), not as a union of overlapping pieces: the signed-area rasteriser SUMS coverage, so
 * two shapes whose anti-aliased edges coincide would double-count (measured: ~40% error at tangent points). */
static int64_t area2(const VecPath *o, int st, int en)
{
    int64_t s = 0;
    /* only the sign and relative size matter (outer vs inner contour), so scale each product down: 1024 terms of up to 2^56 would overflow int64 */
    for (int i = st; i < en; i++) { int j = (i + 1 < en) ? i + 1 : st; s += (((int64_t)o->x[i] * o->y[j]) >> 12) - (((int64_t)o->x[j] * o->y[i]) >> 12); }
    return s;
}
static void reverse_sub(VecPath *o, int st, int en)
{
    for (int i = 0, j = en - st - 1; i < j; i++, j--) {
        vfx tx = o->x[st + i], ty = o->y[st + i]; o->x[st + i] = o->x[st + j]; o->y[st + i] = o->y[st + j]; o->x[st + j] = tx; o->y[st + j] = ty;
    }
}
static void out_pt(VecPath *o, int64_t x, int64_t y)
{
    if (o->npts >= VEC_MAX_PTS) { o->err = 1; return; }
    o->x[o->npts] = clampc(x); o->y[o->npts] = clampc(y); o->npts++;
}
static int out_begin(VecPath *o)
{
    if (o->nsub >= VEC_MAX_SUBPATHS) { o->err = 1; return -1; }
    o->sub_start[o->nsub] = o->npts; o->sub_closed[o->nsub] = 1; o->nsub++; return o->npts;
}

typedef struct { VecPath *o; int64_t hw; int round; int stride; } Stk;

static int tab_index(int64_t vx, int64_t vy)          /* table direction closest to (vx, vy) */
{
    int best = 0; int64_t bd = INT64_MIN;
    for (int j = 0; j < 64; j++) { int64_t d = vx * g_cos64[j] + vy * g_sin64[j]; if (d > bd) { bd = d; best = j; } }
    return best;
}
/* arc points strictly between the start and end directions, rotating by dir (+1/-1 table steps) */
static void arc(Stk *s, int64_t cx, int64_t cy, int64_t ax, int64_t ay, int64_t bx, int64_t by, int dir)
{
    int i0 = tab_index(ax, ay), i1 = tab_index(bx, by);
    int count = dir > 0 ? ((i1 - i0) & 63) : ((i0 - i1) & 63);
    for (int t = s->stride; t < count; t += s->stride) { int j = (i0 + dir * t) & 63; out_pt(s->o, cx + ((s->hw * g_cos64[j]) >> 16), cy + ((s->hw * g_sin64[j]) >> 16)); }
}
static void semicircle(Stk *s, int64_t cx, int64_t cy, int64_t lx, int64_t ly)     /* from +L to -L through the travel direction */
{
    int i0 = tab_index(lx, ly);
    for (int t = s->stride; t < 32; t += s->stride) { int j = (i0 - t) & 63; out_pt(s->o, cx + ((s->hw * g_cos64[j]) >> 16), cy + ((s->hw * g_sin64[j]) >> 16)); }
}

/* Join at vertex (ax,ay) between the previous segment (direction pd, left normal pL, length plen) and the current one.
 * Outer side: both offset points (+ an arc when round). Inner side: the exact intersection of the two offset lines when
 * both segments are long enough to contain it (a clean, non-overlapping boundary), else the safe route via the vertex. */
static void joint(Stk *s, int64_t ax, int64_t ay, int64_t pdx, int64_t pdy, int64_t pLx, int64_t pLy, uint64_t plen,
                  int64_t dx, int64_t dy, int64_t Lx, int64_t Ly, uint64_t len)
{
    int64_t cross = pdx * dy - pdy * dx, dot = pdx * dx + pdy * dy;
    if (cross < 0 || (cross == 0 && dot < 0)) {                         /* left is the OUTER side */
        out_pt(s->o, ax + pLx, ay + pLy);
        if (s->round) arc(s, ax, ay, pLx, pLy, Lx, Ly, -1);
        out_pt(s->o, ax + Lx, ay + Ly);
    } else if (cross > 0) {                                             /* inner side */
        int64_t hw2 = s->hw * s->hw, den = hw2 + (pLx * Lx + pLy * Ly), crossL = pLx * Ly - pLy * Lx;
        if (den > 0 && s->hw <= (1 << 18)) {
            int64_t dist = s->hw * (crossL < 0 ? -crossL : crossL) / den;       /* distance of the intersection from the vertex along each segment */
            uint64_t lim = plen < len ? plen : len;
            if (dist >= 0 && (uint64_t)dist <= lim) { out_pt(s->o, ax + (pLx + Lx) * hw2 / den, ay + (pLy + Ly) * hw2 / den); return; }
        }
        out_pt(s->o, ax + pLx, ay + pLy); out_pt(s->o, ax, ay); out_pt(s->o, ax + Lx, ay + Ly);
    } else {
        out_pt(s->o, ax + Lx, ay + Ly);                                 /* straight on */
    }
}

/* Emit the left-offset chain of q[0..m-1] (q = keep[] forward or reversed). Each segment contributes its joint at its
 * START vertex; the end offset point of a segment is emitted by the next joint (open chains emit the last one). */
static void emit_chain(Stk *s, const VecPath *in, const uint16_t *keep, int m, int rev, int closed)
{
#define Q(k) (keep[rev ? (m - 1 - (k)) : (k)])
    int nseg = closed ? m : m - 1;
    int64_t pdx = 0, pdy = 0, pLx = 0, pLy = 0; uint64_t plen = 0; int have_prev = 0;
    if (closed) {                                          /* the join at the wrap vertex needs the LAST segment's direction */
        int a = Q(m - 1), b = Q(0);
        int64_t dx = (int64_t)in->x[b] - in->x[a], dy = (int64_t)in->y[b] - in->y[a]; plen = isqrt64((uint64_t)(dx * dx + dy * dy));
        pdx = dx; pdy = dy; pLx = -dy * s->hw / (int64_t)plen; pLy = dx * s->hw / (int64_t)plen; have_prev = 1;
    }
    for (int i = 0; i < nseg; i++) {
        int a = Q(i), b = Q((i + 1) % m);
        int64_t dx = (int64_t)in->x[b] - in->x[a], dy = (int64_t)in->y[b] - in->y[a]; uint64_t len = isqrt64((uint64_t)(dx * dx + dy * dy));
        int64_t Lx = -dy * s->hw / (int64_t)len, Ly = dx * s->hw / (int64_t)len;
        if (have_prev) joint(s, in->x[a], in->y[a], pdx, pdy, pLx, pLy, plen, dx, dy, Lx, Ly, len);
        else out_pt(s->o, (int64_t)in->x[a] + Lx, (int64_t)in->y[a] + Ly);
        pdx = dx; pdy = dy; pLx = Lx; pLy = Ly; plen = len; have_prev = 1;
    }
    if (!closed) {
        int e = Q(m - 1);
        out_pt(s->o, (int64_t)in->x[e] + pLx, (int64_t)in->y[e] + pLy);
        if (s->round) semicircle(s, in->x[e], in->y[e], pLx, pLy);
    }
#undef Q
}

static uint16_t g_keep[VEC_MAX_PTS];

int vec_stroke_path(const VecPath *in, vfx width, int round, VecPath *out)
{
    vec_path_begin(out);
    if (!in) return -1;
    if (in->err) return -1;
    if (width <= 0) return 0;
    Stk s; s.o = out; s.hw = width / 2; if (s.hw < 1) s.hw = 1; s.round = round;
    s.stride = s.hw < 256 ? 4 : s.hw < 768 ? 2 : 1;                         /* table stride: 16/32/64 points per full circle (radius < 1 px / < 3 px / larger) */
    for (int sp = 0; sp < in->nsub; sp++) {
        int st = in->sub_start[sp], en = (sp + 1 < in->nsub) ? in->sub_start[sp + 1] : in->npts, m = 0;
        for (int i = st; i < en; i++) {                                     /* drop consecutive duplicates (zero-length segments) */
            if (m && in->x[g_keep[m - 1]] == in->x[i] && in->y[g_keep[m - 1]] == in->y[i]) continue;
            g_keep[m++] = (uint16_t)i;
        }
        int closed = in->sub_closed[sp];
        if (closed && m > 1 && in->x[g_keep[m - 1]] == in->x[g_keep[0]] && in->y[g_keep[m - 1]] == in->y[g_keep[0]]) m--;
        if (m < 1) continue;
        if (m == 1) {                                                       /* a dot */
            if (round) { int k = 64 / s.stride, st2 = out_begin(out); if (st2 < 0) continue; for (int j = 0; j < k; j++) { int idx = j * s.stride; out_pt(out, in->x[g_keep[0]] + ((s.hw * g_cos64[idx]) >> 16), in->y[g_keep[0]] + ((s.hw * g_sin64[idx]) >> 16)); } }
            continue;
        }
        if (closed && m >= 3) {
            int a0 = out_begin(out); if (a0 < 0) continue; emit_chain(&s, in, g_keep, m, 0, 1); int a1 = out->npts;
            int b0 = out_begin(out); if (b0 < 0) continue; emit_chain(&s, in, g_keep, m, 1, 1); int b1 = out->npts;
            int64_t aa = area2(out, a0, a1), ab = area2(out, b0, b1);
            int a_outer = (aa < 0 ? -aa : aa) >= (ab < 0 ? -ab : ab);          /* outer contour positive, inner negative: a ring under non-zero */
            if ((aa > 0) != a_outer) reverse_sub(out, a0, a1);
            if ((ab > 0) != !a_outer) reverse_sub(out, b0, b1);
        } else {
            int c0 = out_begin(out); if (c0 < 0) continue;
            emit_chain(&s, in, g_keep, m, 0, 0); emit_chain(&s, in, g_keep, m, 1, 0);
            if (area2(out, c0, out->npts) < 0) reverse_sub(out, c0, out->npts);
        }
    }
    return out->err ? -1 : 0;
}

static int g_aa = 1;
void vec_set_aa(int on) { g_aa = on ? 1 : 0; }
int  vec_aa(void) { return g_aa; }

static VecPath g_scratch, g_stroke;
VecPath *vec_scratch(void) { return &g_scratch; }

int vec_stroke(const GfxFb *fb, const VecPath *p, vfx width, int round, const VecPaint *paint, const VecClip *clip)
{
    if (vec_stroke_path(p, width, round, &g_stroke) != 0) return -1;
    return vec_fill(fb, &g_stroke, 0, paint, clip);
}

/* ------------------------------------------------------------------------------------------------ convenience */
int vec_fill_rrect(const GfxFb *fb, vfx x, vfx y, vfx w, vfx h, vfx r, const VecPaint *paint, const VecClip *clip)
{
    vec_path_begin(&g_scratch); vec_add_rrect(&g_scratch, x, y, w, h, r, r);
    return vec_fill(fb, &g_scratch, 0, paint, clip);
}
int vec_stroke_rrect(const GfxFb *fb, vfx x, vfx y, vfx w, vfx h, vfx r, vfx width, const VecPaint *paint, const VecClip *clip)
{
    vec_path_begin(&g_scratch); vec_add_rrect(&g_scratch, x, y, w, h, r, r);
    return vec_stroke(fb, &g_scratch, width, 0, paint, clip);
}
int vec_fill_ellipse(const GfxFb *fb, vfx cx, vfx cy, vfx rx, vfx ry, const VecPaint *paint, const VecClip *clip)
{
    vec_path_begin(&g_scratch); vec_add_ellipse(&g_scratch, cx, cy, rx, ry);
    return vec_fill(fb, &g_scratch, 0, paint, clip);
}
int vec_line(const GfxFb *fb, vfx x0, vfx y0, vfx x1, vfx y1, vfx width, int round, const VecPaint *paint, const VecClip *clip)
{
    vec_path_begin(&g_scratch); vec_move_to(&g_scratch, x0, y0); vec_line_to(&g_scratch, x1, y1);
    return vec_stroke(fb, &g_scratch, width, round, paint, clip);
}
