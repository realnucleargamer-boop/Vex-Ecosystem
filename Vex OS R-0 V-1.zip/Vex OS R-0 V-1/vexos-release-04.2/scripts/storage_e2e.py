#!/usr/bin/env python3
"""Vex OS - scripts/storage_e2e.py : STORAGE-01 (PCI + AHCI + data-disk settings store) and wallpaper PERSISTENCE across a real reboot, in QEMU.
Needs the seeded image built with -DVEX_DEV_SEED_ACCOUNTS=1 -DVEX_TERM_MIRROR=1 (same as wallpaper_e2e.py).  Usage: storage_e2e.py <seeded.img>
Everything is verified from outside the guest as well: the raw bytes of the data disk file and a SHA-256 of the boot image are checked on the host."""
import hashlib, os, struct, sys, time, zlib
sys.path.insert(0, os.path.dirname(__file__))
from e2e_common import *
IMG = sys.argv[1]; Ctx.out = "build/storage"; os.makedirs(Ctx.out, exist_ok=True)
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def mkdisk(name, fill=b"\0"):
    p = f"{Ctx.out}/{name}"; open(p, "wb").write((fill * (8 * 1048576 // len(fill)))[:8 * 1048576]); return p
def vstore_slots(p):
    """Independent re-implementation of the on-disk format: returns (header_ok, [(seq, wallpaper) for valid slots])."""
    d = open(p, "rb").read(3 * 512); hdr = d[:512]
    hok = hdr[:8] == b"VEXSTOR1" and struct.unpack_from("<I", hdr, 8)[0] == 1 and zlib.crc32(hdr[:508]) & 0xFFFFFFFF == struct.unpack_from("<I", hdr, 508)[0]
    sl = []
    for k in (1, 2):
        r = d[k * 512:(k + 1) * 512]
        if struct.unpack_from("<I", r, 0)[0] == 0x54455356 and zlib.crc32(r[:508]) & 0xFFFFFFFF == struct.unpack_from("<I", r, 508)[0]: sl.append(struct.unpack_from("<II", r, 4))
    return hok, sl
def boot(disks, tag, allow_reboot=False):
    extra = []
    for d in disks: extra += ["-drive", f"format=raw,file={d}"]
    vm = Vm(IMG, Ctx.out, tag=tag, extra=extra, allow_reboot=allow_reboot); vm.wait_serial(r"\[ui\] lock screen shown", 200); time.sleep(1.2); return vm
boot_sha = sha(IMG); blank = mkdisk("blank.img")

# ================================================= A. blank data disk: detection, refusal to save, format, save
vm = boot([blank], "A", allow_reboot=True); s = vm.serial()
check("[pci] 6 device(s)" in s and "SATA controller" in s, "PCI enumeration lists the devices (incl. the SATA/AHCI controller)")
check("[ahci] disk 0 port 0" in s and "[ahci] disk 1 port 1" in s, "AHCI driver identified both disks (boot disk + data disk)")
check("[storage] disk 0: not a Vex data disk (left untouched)" in s, "the BOOT disk is classified FOREIGN and is never used for settings")
check("[storage] data store: blank (not formatted)" in s, "the blank second disk is detected as BLANK (not formatted yet)")
D = signin(vm); S, tiles, AP, RS = open_wallpaper_page(vm, D)
click(vm, tiles[2]); click(vm, AP); time.sleep(1.5); im = shot(vm, "A1_unsaved")
check(cnt(vm, r"\[wallpaper\] applied Deep Arcs") == 1 and cnt(vm, r"wallpaper choice NOT saved") == 1, "apply on a BLANK disk still changes the desktop but is NOT saved")
shot(vm, "A2_msg")
click(vm, rects(vm, "settings view shown")["tmin"]); time.sleep(0.5); click(vm, D["term"]); time.sleep(0.6)
o = term_cmd(vm, "v. storage"); check(any("Data store: blank" in l for l in o) and any("QEMU HARDDISK" in l for l in o), "v. storage reports the real disks and the blank store", str(o))
o = term_cmd(vm, "v. drivers"); check(any("PCI devices: 6" in l for l in o) and any("SATA controller" in l for l in o), "v. drivers lists the real PCI devices", str(o))
check(open(blank, "rb").read(8) == b"\0" * 8, "host check: the blank disk file is still all-zero before format")
o = term_cmd(vm, "v. storage format", 2.5); check(any("Data disk formatted" in l for l in o), "admin: v. storage format succeeds on the verified-blank disk", str(o))
hok, sl = vstore_slots(blank); check(hok and len(sl) >= 1, f"host check: data disk now has a valid VEXSTOR1 header and slot(s) {sl}")
o = term_cmd(vm, "v. storage format"); check(any("already formatted" in l for l in o), "formatting twice is refused", str(o))
check(sha(IMG) == boot_sha, "host check: the boot image file was not modified by the guest")
# save from Settings
D = rects(vm, "desktop shown"); click(vm, D["sett"]); time.sleep(0.5); S, tiles, AP, RS = open_wallpaper_page(vm, D)
click(vm, tiles[3]); click(vm, AP); time.sleep(2.0)
check(cnt(vm, r"saved wallpaper choice") == 1, "after format, Apply (Blue Flow) is saved by the kernel")
hok, sl = vstore_slots(blank); check(any(w == 3 for _, w in sl), f"host check: Blue Flow (index 3) is on the data disk: slots {sl}")
n_lock = cnt(vm, r"\[ui\] lock screen shown"); vm.hmp("system_reset"); check(wait_lock(vm, n_lock), "rebooted (system_reset)")
D = signin(vm); desk = shot(vm, "A3_after_reboot")
check(cnt(vm, r"\[wallpaper\] restored saved wallpaper: Blue Flow") == 1, "after reboot the kernel restores the saved wallpaper (log)")
e = strip_err(desk, 3); check(e < 10, f"after reboot the REAL desktop shows Blue Flow without touching Settings (error {e:.1f})", f"{e:.1f}")
check(strip_err(desk, 4) > 40, "negative control: not any other wallpaper")
# change choice, reboot again
S, tiles, AP, RS = open_wallpaper_page(vm, D); click(vm, tiles[2]); click(vm, AP); time.sleep(2.0)
hok, sl = vstore_slots(blank); check(sorted(w for _, w in sl) == [2, 3] or sorted(w for _, w in sl)[-1:] == [3] and any(w == 2 for _, w in sl), f"host check: A/B slots hold the new (2) and previous (3) choices: {sl}")
n_lock = cnt(vm, r"\[ui\] lock screen shown"); vm.hmp("system_reset"); wait_lock(vm, n_lock); D = signin(vm); desk = shot(vm, "A4_after_reboot2")
check(strip_err(desk, 2) < 10 and cnt(vm, r"restored saved wallpaper: Deep Arcs") == 1, "second reboot restores the newest choice (Deep Arcs)")
# reset to default persists too
S, tiles, AP, RS = open_wallpaper_page(vm, D); click(vm, RS); time.sleep(1.5)
n_lock = cnt(vm, r"\[ui\] lock screen shown"); vm.hmp("system_reset"); wait_lock(vm, n_lock); D = signin(vm); desk = shot(vm, "A5_after_reset_reboot")
check(all(desk.getpixel(p) == NAVY for p in [(20, 400), (640, 300), (1250, 700)]), "Reset to default is persisted: next boot is the exact default navy")
check(cnt(vm, r"restored saved wallpaper") == 2, "no wallpaper was restored after the reset (still only the 2 earlier restores)")
# standard user cannot format / does not break
typ(vm, ""); D = rects(vm, "desktop shown"); click(vm, D["term"]); time.sleep(0.6)
typ(vm, "v. change users\n"); time.sleep(1.5); L = rects(vm, "lock screen shown"); click(vm, L["users"]); Uu = rects(vm, "users panel opened"); bob = False
for k in sorted(Uu):
    if not k.startswith("item"): continue
    click(vm, Uu[k]); time.sleep(0.5); typ(vm, "bobpass1\n"); time.sleep(1.8)
    if re.search(r"(?i)signed in as bob", vm.serial()): bob = True; break
    L = rects(vm, "lock screen shown"); click(vm, L["users"]); Uu = rects(vm, "users panel opened")
check(bob, "signed in as the standard user Bob")
D = rects(vm, "desktop shown"); click(vm, D["term"]); time.sleep(0.8)
o = term_cmd(vm, "v. storage format"); check(any("Only an administrator" in l for l in o), "standard user: v. storage format is refused", str(o))
check(vm.alive() and "PANIC" not in vm.serial() and "UNHANDLED CPU EXCEPTION" not in vm.serial(), "no panic across the whole persistence run")
vm.stop(); check(sha(IMG) == boot_sha, "host check: boot image still byte-identical")

# ================================================= B. a disk that holds someone else's data must never be written
junk = mkdisk("foreign.img", b"PRECIOUS-USER-DATA\n"); junk_sha = sha(junk)
vm = boot([junk], "B"); check("[storage] disk 1: not a Vex data disk (left untouched)" in vm.serial(), "a non-blank, non-Vex disk is classified FOREIGN")
D = signin(vm); click(vm, D["term"]); time.sleep(0.6)
o = term_cmd(vm, "v. storage"); check(any("not a Vex data disk" in l for l in o), "v. storage says the disk is not a Vex data disk", str(o))
o = term_cmd(vm, "v. storage format"); check(any("Refused" in l for l in o), "admin: format of a foreign disk is REFUSED", str(o))
S, tiles, AP, RS = open_wallpaper_page(vm, D); click(vm, tiles[1]); click(vm, AP); time.sleep(1.5)
check(cnt(vm, r"\[wallpaper\] applied Midnight Horizon") == 1, "wallpaper still works (RAM only) when the disk is foreign")
vm.stop(); check(sha(junk) == junk_sha, "host check: the foreign disk is byte-for-byte unchanged (SHA-256)")

# ================================================= C. no data disk at all
vm = boot([], "C"); check("[storage] data store: no data disk" in vm.serial(), "single-disk boot: store state is 'no data disk'")
D = signin(vm); S, tiles, AP, RS = open_wallpaper_page(vm, D); click(vm, tiles[4]); click(vm, AP); time.sleep(1.5)
check(cnt(vm, r"\[wallpaper\] applied Morning Haze") == 1 and strip_err(shot(vm, "C1"), 4) < 10, "no data disk: wallpaper applies in RAM")
click(vm, rects(vm, "settings view shown")["tmin"]); time.sleep(0.5); click(vm, D["term"]); time.sleep(0.6)
o = term_cmd(vm, "v. storage"); check(any("No data disk" in l for l in o), "v. storage honestly reports there is no data disk", str(o))
vm.stop(); check(sha(IMG) == boot_sha, "host check: boot image unchanged in the single-disk run")
print(f"\n{sum(Ctx.res)}/{len(Ctx.res)} STORAGE-01 end-to-end checks passed"); sys.exit(0 if all(Ctx.res) else 1)
