"""Mutable genome buffers for VexScript (VEX AI readiness).

Hosted runtime representation: list of single-character strings (Unicode code
units as length-1 strings). Not a GC'd string type — fixed capacity optional.

Ownership: handles are integer IDs; reset_genome_state() clears all buffers.
Invalid index operations return empty string / -1 / no-op as documented.
"""
from __future__ import annotations
from dataclasses import dataclass, field

# VEX AI–oriented allowed charset (application may use subset)
GENOME_CHARSET = (
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "abcdefghijklmnopqrstuvwxyz"
    "0123456789"
    ".,/'\\;[]-=+{}><?"
)


@dataclass
class Genome:
    data: list[str] = field(default_factory=list)
    capacity: int = 0  # 0 = unbounded growth

    def length(self) -> int:
        return len(self.data)


_GENOMES: dict[int, Genome] = {}
_NEXT_GID = 1


def reset_genome_state() -> None:
    global _GENOMES, _NEXT_GID
    _GENOMES = {}
    _NEXT_GID = 1


def _get(gid: int) -> Genome:
    g = _GENOMES.get(int(gid))
    if g is None:
        raise ValueError(f"invalid genome handle {gid}")
    return g


def genome_create(capacity: int = 0) -> int:
    """Create empty genome. capacity>0 reserves and caps length."""
    global _NEXT_GID
    cap = max(0, int(capacity))
    gid = _NEXT_GID
    _NEXT_GID += 1
    _GENOMES[gid] = Genome(data=[], capacity=cap)
    return gid


def genome_from_string(s: str, capacity: int = 0) -> int:
    global _NEXT_GID
    text = str(s)
    cap = max(0, int(capacity))
    if cap and len(text) > cap:
        text = text[:cap]
    gid = _NEXT_GID
    _NEXT_GID += 1
    _GENOMES[gid] = Genome(data=list(text), capacity=cap)
    return gid


def genome_length(gid: int) -> int:
    return _get(gid).length()


def genome_char_at(gid: int, index: int) -> str:
    g = _get(gid)
    i = int(index)
    if i < 0 or i >= len(g.data):
        return ""  # safe empty on OOB
    return g.data[i]


def genome_set_char(gid: int, index: int, ch: str) -> int:
    """Set character at index. Returns 0 ok, -1 on OOB / empty ch."""
    g = _get(gid)
    i = int(index)
    if i < 0 or i >= len(g.data):
        return -1
    c = str(ch)
    if len(c) == 0:
        return -1
    g.data[i] = c[0]
    return 0


def genome_slice(gid: int, start: int, end: int) -> int:
    """New genome with [start, end). Clamps to bounds. Empty if invalid."""
    g = _get(gid)
    n = len(g.data)
    a = max(0, min(int(start), n))
    b = max(a, min(int(end), n))
    return genome_from_string("".join(g.data[a:b]), g.capacity)


def genome_copy(gid: int) -> int:
    g = _get(gid)
    return genome_from_string("".join(g.data), g.capacity)


def genome_compare(a: int, b: int) -> int:
    """0 equal, <0 if a<b lexicographically, >0 if a>b."""
    da = "".join(_get(a).data)
    db = "".join(_get(b).data)
    if da < db:
        return -1
    if da > db:
        return 1
    return 0


def genome_append_char(gid: int, ch: str) -> int:
    g = _get(gid)
    c = str(ch)
    if len(c) == 0:
        return -1
    if g.capacity and len(g.data) >= g.capacity:
        return -1
    g.data.append(c[0])
    return 0


def genome_to_string(gid: int) -> str:
    return "".join(_get(gid).data)


def genome_mutate_pos(gid: int, index: int, ch: str) -> int:
    """Alias for set_char (in-place mutation)."""
    return genome_set_char(gid, index, ch)


def genome_fill(gid: int, ch: str, length: int) -> int:
    """Replace contents with `length` copies of ch[0]. Respects capacity."""
    g = _get(gid)
    c = str(ch)
    if len(c) == 0:
        return -1
    n = max(0, int(length))
    if g.capacity:
        n = min(n, g.capacity)
    g.data = [c[0]] * n
    return 0


def genome_char_code_at(gid: int, index: int) -> int:
    ch = genome_char_at(gid, index)
    return ord(ch[0]) if ch else -1


def genome_set_char_code(gid: int, index: int, code: int) -> int:
    if code < 0:
        return -1
    return genome_set_char(gid, index, chr(int(code) & 0xFF))


def genome_fill_code(gid: int, code: int, length: int) -> int:
    if code < 0:
        return -1
    return genome_fill(gid, chr(int(code) & 0xFF), length)


def genome_match(gid: int, target: str) -> int:
    """Count matching character positions against target (general text fitness)."""
    g = _get(gid)
    tgt = str(target)
    hits = 0
    n = min(len(g.data), len(tgt))
    for i in range(n):
        if g.data[i] == tgt[i]:
            hits += 1
    return hits
