# VexScript 3.0 — Design Specification

**Status:** Design freeze candidate (implementation staged)  
**Base:** VexScript 2.0+++ (v2.2.1) + Vex IR 1.2  
**Companion IR:** **Vex IR 2.0** (not an extension of 1.2 feature-cram)

## 1. Philosophy

VexScript 3.0 remains:

- Statically typed, deterministic, compiled
- No hidden JavaScript runtime, no GC requirement in core
- Vex IR is the canonical contract
- Suitable for VEX AI *and* ordinary systems/application code

Neural / evolutionary features are **library-shaped language + runtime primitives**, not magical “neuron” syntax. Programmers work with **tensors, layers, models, populations**; the runtime owns storage and numeric kernels.

## 2. Architecture

```text
                VexScript 3.0
                     │
        ┌────────────┼────────────┐
        ▼            ▼            ▼
   Normal code   Math Engine   AI / Evolution
        │            │            │
        └────────────┼────────────┘
                     ▼
                 Vex IR 2.0
                     │
             ┌───────┴────────┐
             ▼                ▼
        CPU Backend       VEX AI Runtime
        (x86-64)          (hosted numeric)
```

IR 1.2 remains valid for 2.0+++ programs. 3.0 programs that use tensors/evolve require **IR 2.0**.

## 3. Core additions (language surface)

### 3.1 Tensor types

```vex
let a: tensor<f32, [128]>;
let w: tensor<f32, [128, 64]>;
```

- Contiguous numeric storage (not `T[]` object arrays)
- Rank and shape are part of the static type
- Element types initially: `f32`, `f64`, later `i32`/`i64` where useful

### 3.2 Layers (desugar, not magic)

```vex
layer Dense(128, 64)
layer Activation("relu")
```

Lower to ordinary calls / IR ops (`neural.linear`, `neural.relu`, …), not special VM opcodes that hide allocation.

### 3.3 Weights

```vex
weights W: tensor<f32, [128, 64]>;
```

Semantic: named, runtime-managed parameter tensor (trainable / evolvable storage).

### 3.4 Evolution primitives

Conceptual API (exact syntax frozen in Phase B+):

| Primitive | Role |
|-----------|------|
| `population` | Set of candidates |
| `fitness` | Score candidate |
| `mutate` | Stochastic variation (seeded RNG) |
| `crossover` | Combine parents |
| `select` | Keep elites / tournament |
| `generation` | Advance EA step |

Pipeline:

```text
population → evaluate fitness → select → mutate/crossover → next generation
```

### 3.5 Deterministic RNG

```vex
rng_seed(12345);
```

Same seed ⇒ same evolutionary trajectory (bitwise where platform allows).

### 3.6 Early stop

Ordinary control flow — no special “AI stop”:

```vex
if (error == 0) {
    break;  // or return
}
```

### 3.7 Checkpoint (planned)

Save/load model or population blobs via hosted APIs — **not** kernel syscalls until Vex OS ABI exists.

## 4. What is NOT VexScript 3.0

- Calling external OpenAI/Claude/Gemini APIs as language features
- Automatic GPU magic without explicit backend
- GC-based tensor graphs
- Dynamic shapes in v1 of tensors (fixed shapes first)
- Replacing VexScript 2.0+++ for non-AI code

## 5. Compatibility

| 2.0+++ feature | 3.0 |
|----------------|-----|
| strings, arrays, structs, modules | Preserved |
| Vex IR 1.2 programs | Still accepted |
| Hosted `vex::*` stubs | Preserved |

Breaking changes must be listed in migration notes.

## 6. Implementation phases

| Phase | Scope |
|-------|--------|
| **3.0-A** | Spec + tensor type syntax + RNG seed builtin + IR 2.0 doc stubs |
| **3.0-B** | Tensor create/load/store/add/mul in hosted runtime + IR ops |
| **3.0-C** | matmul, dense forward, activation helpers |
| **3.0-D** | Population / fitness / mutate / crossover / select |
| **3.0-E** | Checkpoint, multi-candidate eval, optimization |

No phase may claim “neural training works” without executable tests.

## 7. VEX AI relationship

VEX AI services should be written in VexScript using these primitives over time. Until 3.0-B/C land, VEX AI continues on **2.0+++** (strings, structs, classify logic).
