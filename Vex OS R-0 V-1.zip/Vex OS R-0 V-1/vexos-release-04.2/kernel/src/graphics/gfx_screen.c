/*
 * Vex OS - kernel/src/graphics/gfx_screen.c
 *
 * BOOT-03 native boot screen.  Layout, status panel, terminal area.
 *
 * Every PASS/FAIL/ONLINE value shown here comes from a runtime flag or
 * Boot03Results field that kernel_entry.c sets only after the real
 * subsystem has executed.  Nothing here is fabricated or assumed.
 */

#include "gfx/screen.h"
#include "gfx/draw.h"
#include "serial.h"
#include "kernel01_tests.h"
#include "security01_tests.h"

/* ------------------------------------------------------------------ */
/* Layout constants — derived from the actual framebuffer geometry     */
/* ------------------------------------------------------------------ */

#define HEADER_H      30
#define PAD           14
#define PANEL_W       300
#define SEPARATOR_H   1

/* ------------------------------------------------------------------ */
/* Small string helpers (no libc, no static buffers shared)           */
/* ------------------------------------------------------------------ */

static int gfx_strlen(const char *s)
{
    int n = 0; while (*s++) n++; return n;
}

static void gfx_u64_to_str(uint64_t v, char *buf, int cap)
{
    int i = cap - 1;
    buf[i] = '\0';
    if (v == 0) { if (i > 0) buf[--i] = '0'; }
    else { while (v > 0 && i > 0) { buf[--i] = (char)('0' + v % 10); v /= 10; } }
    /* Shift to front if buf didn't start at [0]. */
    if (i > 0) {
        int j = 0;
        while (buf[i]) buf[j++] = buf[i++];
        buf[j] = '\0';
    }
}

/* ------------------------------------------------------------------ */
/* Header bar                                                          */
/* ------------------------------------------------------------------ */

static void draw_header(const GfxFb *fb, int32_t w)
{
    gfx_fill_rect(fb, 0, 0, w, HEADER_H, GFX_HEADER_BG);
    gfx_hline(fb, 0, HEADER_H - 1, w, GFX_ACCENT);

    int32_t ty = (HEADER_H - GFX_FONT_H) / 2;
    int32_t x  = gfx_draw_str(fb, PAD, ty, "VEX OS", GFX_WHITE, GFX_HEADER_BG);
    x = gfx_draw_str(fb, x + 8, ty, "BOOT-03", GFX_ACCENT, GFX_HEADER_BG);
    (void)x;

    /* Right side: GRAPHICS ONLINE indicator. */
    const char *label = "GRAPHICS ONLINE";
    int32_t label_w   = gfx_strlen(label) * GFX_FONT_W;
    int32_t lx        = w - PAD - label_w - 14;
    gfx_draw_str(fb, lx, ty, label, GFX_GREEN, GFX_HEADER_BG);
    /* Small green dot */
    gfx_circle(fb, w - PAD - 5, HEADER_H / 2, 4, GFX_GREEN);
}

/* ------------------------------------------------------------------ */
/* Status panel row helper                                            */
/* ------------------------------------------------------------------ */

static void panel_row(const GfxFb *fb,
                      int32_t x, int32_t y,
                      const char *label, const char *value, GfxColor vc)
{
    int32_t lw = gfx_strlen(label) * GFX_FONT_W;
    gfx_draw_str(fb, x, y, label, GFX_DIM, GFX_PANEL_BG);
    gfx_draw_str(fb, x + lw + GFX_FONT_W, y, value, vc, GFX_PANEL_BG);
}

static void panel_section(const GfxFb *fb, int32_t x, int32_t *y,
                          int32_t pw, const char *title)
{
    gfx_draw_str(fb, x, *y, title, GFX_ACCENT, GFX_PANEL_BG);
    *y += GFX_FONT_H + 3;
    gfx_hline(fb, x, *y, pw - 2 * PAD, GFX_BORDER);
    *y += 6;
}

static GfxColor result_col(int ok) { return ok ? GFX_GREEN : GFX_RED; }
static const char *result_str(int ok) { return ok ? "PASS" : "FAIL"; }

/* ------------------------------------------------------------------ */
/* Status panel                                                        */
/* ------------------------------------------------------------------ */

static void draw_status_panel(const GfxFb *fb, int32_t body_y,
                              int32_t body_h, const GfxBootStatus *st)
{
    int32_t x = PAD;
    int32_t y = body_y + PAD;
    int32_t pw = PANEL_W;

    gfx_fill_rect(fb, x, body_y, pw, body_h, GFX_PANEL_BG);
    gfx_rect_outline(fb, x, body_y, pw, body_h, GFX_BORDER);

    /* ---- CPU / SMP ---- */
    panel_section(fb, x + PAD, &y, pw, "CPU / SMP");

    char cpubuf[12];
    gfx_u64_to_str((uint64_t)st->cpu_count, cpubuf, sizeof(cpubuf));
    if (st->lapic_ok) {
        panel_row(fb, x + PAD, y, "BSP", "ONLINE", GFX_GREEN);
        y += GFX_FONT_H + 4;
        if (st->smp_ok && st->cpu_count > 1) {
            panel_row(fb, x + PAD, y, "APs", cpubuf, GFX_GREEN);
        } else {
            panel_row(fb, x + PAD, y, "APs", "NOT STARTED", GFX_YELLOW);
        }
    } else {
        panel_row(fb, x + PAD, y, "LAPIC", "FAIL", GFX_RED);
        y += GFX_FONT_H + 4;
        panel_row(fb, x + PAD, y, "APs", "UNKNOWN", GFX_YELLOW);
    }
    y += GFX_FONT_H + 10;

    /* ---- Memory ---- */
    panel_section(fb, x + PAD, &y, pw, "MEMORY");

    char membuf[20];
    gfx_u64_to_str(st->usable_mib, membuf, sizeof(membuf));
    panel_row(fb, x + PAD, y, "PMM", st->b03 && st->b03->memory ? "PASS" : "FAIL",
              result_col(st->b03 && st->b03->memory));
    y += GFX_FONT_H + 4;
    panel_row(fb, x + PAD, y, "VMM/PAGING",
              result_str(st->paging_ok), result_col(st->paging_ok));
    y += GFX_FONT_H + 4;
    panel_row(fb, x + PAD, y, "USABLE", membuf, GFX_TEXT);
    y += GFX_FONT_H + 10;

    /* ---- Hardware ---- */
    panel_section(fb, x + PAD, &y, pw, "HARDWARE");

    panel_row(fb, x + PAD, y, "ACPI", result_str(st->acpi_ok),
              result_col(st->acpi_ok));
    y += GFX_FONT_H + 4;
    panel_row(fb, x + PAD, y, "LAPIC/APIC", result_str(st->lapic_ok),
              result_col(st->lapic_ok));
    y += GFX_FONT_H + 4;
    panel_row(fb, x + PAD, y, "TIMER",
              result_str(st->timer_ok), result_col(st->timer_ok));
    y += GFX_FONT_H + 10;

    /* ---- BOOT-03 tests ---- */
    panel_section(fb, x + PAD, &y, pw, "BOOT-03 TESTS");

    if (st->b03) {
        char tbuf[24];
        char passed_str[12], total_str[12];
        uint32_t passed = st->b03->checks_run - st->b03->checks_failed;
        gfx_u64_to_str((uint64_t)passed,          passed_str, sizeof(passed_str));
        gfx_u64_to_str((uint64_t)st->b03->checks_run, total_str, sizeof(total_str));
        /* Build "NNN/TTT" into tbuf. */
        int pi = 0;
        for (int i = 0; passed_str[i]; i++) tbuf[pi++] = passed_str[i];
        tbuf[pi++] = '/';
        for (int i = 0; total_str[i]; i++) tbuf[pi++] = total_str[i];
        tbuf[pi] = '\0';

        int all_ok = (st->b03->checks_failed == 0);
        panel_row(fb, x + PAD, y, "CHECKS", tbuf,
                  all_ok ? GFX_GREEN : GFX_RED);
        y += GFX_FONT_H + 4;
        panel_row(fb, x + PAD, y, "INTERRUPTS",
                  result_str(st->b03->interrupts),
                  result_col(st->b03->interrupts));
        y += GFX_FONT_H + 4;
        panel_row(fb, x + PAD, y, "SMP TEST",
                  result_str(st->b03->smp), result_col(st->b03->smp));
    } else {
        panel_row(fb, x + PAD, y, "CHECKS", "NOT RUN", GFX_YELLOW);
    }
    y += GFX_FONT_H + 10;

    /* ---- KERNEL-01 ---- */
    if (st->k01) {
        panel_section(fb, x + PAD, &y, pw, "KERNEL-01");
        panel_row(fb, x + PAD, y, "TSS/IST",
                  result_str(st->k01->tss_ist), result_col(st->k01->tss_ist));
        y += GFX_FONT_H + 4;
        panel_row(fb, x + PAD, y, "IPI",
                  result_str(st->k01->ipi), result_col(st->k01->ipi));
        y += GFX_FONT_H + 4;
        panel_row(fb, x + PAD, y, "TLB",
                  result_str(st->k01->tlb), result_col(st->k01->tlb));
        y += GFX_FONT_H + 4;
        panel_row(fb, x + PAD, y, "RECLAIM",
                  result_str(st->k01->reclaim), result_col(st->k01->reclaim));
        y += GFX_FONT_H + 10;
    }

    /* ---- SECURITY-01 ---- */
    if (st->s01) {
        panel_section(fb, x + PAD, &y, pw, "SECURITY-01");
        panel_row(fb, x + PAD, y, "SEC-PTR",
                  result_str(st->s01->ptr), result_col(st->s01->ptr));
        y += GFX_FONT_H + 4;
        panel_row(fb, x + PAD, y, "SEC-PERM",
                  result_str(st->s01->perm), result_col(st->s01->perm));
        y += GFX_FONT_H + 4;
        panel_row(fb, x + PAD, y, "SEC-FAULT",
                  result_str(st->s01->fault), result_col(st->s01->fault));
        y += GFX_FONT_H + 10;
    }

    /* ---- Graphics ---- */
    panel_section(fb, x + PAD, &y, pw, "GRAPHICS");

    char wbuf[12], hbuf[12];
    gfx_u64_to_str((uint64_t)st->fb_width,  wbuf, sizeof(wbuf));
    gfx_u64_to_str((uint64_t)st->fb_height, hbuf, sizeof(hbuf));

    panel_row(fb, x + PAD, y, "GOP/FB", "ONLINE", GFX_GREEN);
    y += GFX_FONT_H + 4;
    panel_row(fb, x + PAD, y, "RENDERER",
              result_str(st->renderer_ok), result_col(st->renderer_ok));
    y += GFX_FONT_H + 4;

    /* "1280x800" */
    char resbuf[24];
    int ri = 0;
    for (int i = 0; wbuf[i]; i++) resbuf[ri++] = wbuf[i];
    resbuf[ri++] = 'x';
    for (int i = 0; hbuf[i]; i++) resbuf[ri++] = hbuf[i];
    resbuf[ri] = '\0';
    panel_row(fb, x + PAD, y, "RESOLUTION", resbuf, GFX_TEXT);
    y += GFX_FONT_H + 4;
    panel_row(fb, x + PAD, y, "BUFFER", "DIRECT (no heap)", GFX_DIM);
}

/* ------------------------------------------------------------------ */
/* Terminal area frame                                                 */
/* ------------------------------------------------------------------ */

static void draw_terminal_frame(const GfxFb *fb,
                                int32_t tx, int32_t ty,
                                int32_t tw, int32_t th)
{
    gfx_fill_rect(fb, tx, ty, tw, th, GFX_TERM_BG);
    gfx_rect_outline(fb, tx, ty, tw, th, GFX_BORDER);

    /* Column header label */
    int32_t lx = tx + PAD;
    int32_t ly = ty + PAD / 2;
    gfx_draw_str(fb, lx, ly, "VEX OS  boot log", GFX_DIM, GFX_TERM_BG);
    gfx_hline(fb, tx, ly + GFX_FONT_H + 2, tw, GFX_BORDER);
}

/* ------------------------------------------------------------------ */
/* Public entry point                                                  */
/* ------------------------------------------------------------------ */

int gfx_boot_screen_draw(GfxFb *fb, GfxConsole *con, GfxBootStatus *st)
{
    if (!fb->ok) return 0;

    /* --- Populate display-only fields from fb --- */
    st->fb_width  = fb->width;
    st->fb_height = fb->height;
    st->fb_bpp    = 32;

    /* --- Renderer selftest (real hardware round-trip) --- */
    st->renderer_ok = gfx_fb_selftest(fb);

    int32_t W = (int32_t)fb->width;
    int32_t H = (int32_t)fb->height;

    /* --- Background --- */
    gfx_clear(fb, GFX_DARK_BG);

    /* --- Header --- */
    draw_header(fb, W);

    /* --- Layout --- */
    int32_t body_y = HEADER_H + PAD;
    int32_t body_h = H - body_y - PAD;
    if (body_h < 0) body_h = 0;

    int32_t panel_w = PANEL_W;
    if (panel_w > W / 2) panel_w = W / 2;

    draw_status_panel(fb, body_y, body_h, st);

    /* --- Terminal area --- */
    int32_t term_x = PAD + panel_w + PAD;
    int32_t term_w = W - term_x - PAD;
    int32_t term_y = body_y;
    int32_t term_h = body_h;

    if (term_w > 0) {
        draw_terminal_frame(fb, term_x, term_y, term_w, term_h);

        /* Text area inside the frame. */
        int32_t inner_y  = term_y + GFX_FONT_H + PAD + 4;
        int32_t inner_h  = term_h - (inner_y - term_y) - PAD;
        int32_t inner_x  = term_x + PAD;
        int32_t inner_w  = term_w - 2 * PAD;

        if (inner_h > GFX_FONT_H && inner_w > GFX_FONT_W) {
            gfx_console_init(con, fb,
                             inner_x, inner_y, inner_w, inner_h,
                             GFX_TEXT, GFX_TERM_BG);
        } else {
            con->ok = 0;
        }
    } else {
        con->ok = 0;
    }

    serial_puts("[gfx] boot screen drawn");
    if (con->ok) {
        serial_puts(", console ");
        serial_put_dec64(con->cols);
        serial_puts("x");
        serial_put_dec64(con->rows);
    }
    serial_puts("\n");

    return st->renderer_ok;
}

void gfx_boot_screen_write_status(GfxConsole *con, const GfxBootStatus *st)
{
    if (!con->ok) return;

    gfx_console_puts_col(con, "VEX OS  BOOT-03\n", GFX_ACCENT);
    gfx_console_puts(con, "\n");

    /* One line per subsystem — matches what the panel shows. */
    gfx_console_puts_col(con, "ACPI     ", GFX_DIM);
    gfx_console_puts_col(con,
        st->acpi_ok  ? "OK\n" : "FAILED\n",
        result_col(st->acpi_ok));

    gfx_console_puts_col(con, "LAPIC    ", GFX_DIM);
    gfx_console_puts_col(con,
        st->lapic_ok ? "OK\n" : "FAILED\n",
        result_col(st->lapic_ok));

    gfx_console_puts_col(con, "PAGING   ", GFX_DIM);
    gfx_console_puts_col(con,
        st->paging_ok ? "OK\n" : "FAILED\n",
        result_col(st->paging_ok));

    gfx_console_puts_col(con, "TIMER    ", GFX_DIM);
    gfx_console_puts_col(con,
        st->timer_ok  ? "OK\n" : "FAILED\n",
        result_col(st->timer_ok));

    gfx_console_puts_col(con, "SMP      ", GFX_DIM);
    if (st->smp_ok) {
        gfx_console_puts_col(con, "OK  CPUs=", GFX_GREEN);
        gfx_console_put_u64(con, (uint64_t)st->cpu_count);
        gfx_console_putc(con, '\n');
    } else {
        gfx_console_puts_col(con, "NOT STARTED\n", GFX_YELLOW);
    }

    if (st->b03) {
        uint32_t passed = st->b03->checks_run - st->b03->checks_failed;
        gfx_console_puts_col(con, "TESTS    ", GFX_DIM);
        gfx_console_put_u64(con, (uint64_t)passed);
        gfx_console_putc(con, '/');
        gfx_console_put_u64(con, (uint64_t)st->b03->checks_run);
        gfx_console_puts_col(con,
            st->b03->checks_failed == 0 ? "  PASS\n" : "  FAIL\n",
            result_col(st->b03->checks_failed == 0));
    }

    gfx_console_puts(con, "\n");
    gfx_console_puts_col(con, "MEMORY   ", GFX_DIM);
    gfx_console_put_u64(con, st->usable_mib);
    gfx_console_puts(con, " MiB usable\n");

    if (st->k01) {
        gfx_console_puts_col(con, "KERNEL-01  ", GFX_DIM);
        gfx_console_puts_col(con,
            kernel01_all_passed(st->k01) ? "PASS\n" : "FAIL\n",
            result_col(kernel01_all_passed(st->k01)));
    }
    if (st->s01) {
        gfx_console_puts_col(con, "SECURITY-01 ", GFX_DIM);
        gfx_console_puts_col(con,
            security01_all_passed(st->s01) ? "PARTIAL PASS\n" : "FAIL\n",
            result_col(security01_all_passed(st->s01)));
    }

    {
        int all_green = (st->b03 && st->b03->checks_failed == 0 && st->paging_ok)
                        && (st->k01 == 0 || kernel01_all_passed(st->k01))
                        && (st->s01 == 0 || security01_all_passed(st->s01));
        gfx_console_puts(con, "\n");
        gfx_console_puts_col(con,
            all_green ? "VEX OS ONLINE\n" : "VEX OS DEGRADED\n",
            all_green ? GFX_GREEN : GFX_RED);
    }

    gfx_console_puts_col(con, "[vex] > ", GFX_ACCENT);
}
