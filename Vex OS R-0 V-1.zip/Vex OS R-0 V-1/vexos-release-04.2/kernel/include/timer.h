/*
 * Vex OS - kernel/include/timer.h
 *
 * BOOT-03 timer foundation: the Local APIC timer in periodic mode.
 *
 * SCOPE: reliable periodic interrupts, acknowledgement, and a tick
 * counter. There is NO scheduler, no timer wheel, no sleep/timeout API
 * and no one-shot deadline support. Those belong to whatever comes
 * after the boot saga.
 *
 * WHY THE LAPIC TIMER AND NOT THE PIT
 *
 *   The PIT is a single shared device: with more than one CPU there is
 *   exactly one PIT interrupt to go around, and routing it needs the
 *   IOAPIC, which Vex OS does not program (BOOT-02C parses only MADT
 *   type 0 and never touches type 1 IOAPIC entries). The LAPIC timer is
 *   per-CPU by construction, which is what a per-CPU scheduler will
 *   need, and it requires no interrupt routing at all. The PIT is still
 *   used - as the calibration reference, via pit_delay_us(), because
 *   the LAPIC timer's input frequency is not architecturally specified
 *   and must be measured against a known-rate source.
 *
 * WHICH CPUS RUN IT IN BOOT-03
 *
 *   The BSP only. APs still never execute `sti`, because they have no
 *   TSS loaded (BOOT-02C omits `ltr` deliberately) and therefore no
 *   IST - an exception on an AP would use a stack it has no guaranteed
 *   valid entry for. Enabling interrupts on APs is explicitly deferred,
 *   and stated as a limitation rather than quietly implied to work.
 */

#ifndef VEXOS_TIMER_H
#define VEXOS_TIMER_H

#include <stdint.h>

/* The IDT vector the LAPIC timer is wired to. 0x20 (32) is the first
 * vector above the architecturally-defined exception range, and the
 * legacy PIC that would otherwise own it is masked (pic_mask_all()). */
#define TIMER_VECTOR 0x20

/* Target tick rate. 100 Hz is a deliberately unambitious rate: it is
 * fast enough that a test can observe many ticks in a fraction of a
 * second, and slow enough that a mis-calibration by a large factor is
 * still survivable rather than an interrupt storm. */
#define TIMER_TARGET_HZ 100

typedef struct {
    int      initialized;
    int      calibrated;          /* 1 if measured, 0 if a fallback was used */
    uint64_t lapic_base;
    uint64_t counts_per_second;   /* measured LAPIC timer input rate */
    uint32_t initial_count;       /* value programmed for TIMER_TARGET_HZ */
    uint32_t divide;              /* divide-configuration selector used */
    uint64_t measured_hz;         /* counts_per_second / divide-adjusted */
} TimerInfo;

/* Calibrates the LAPIC timer against the PIT and programs it in
 * periodic mode on the CALLING CPU, unmasked, on TIMER_VECTOR. Does NOT
 * execute `sti` - enabling interrupts stays an explicit, separate,
 * visible act at the call site. Returns 1 on success. */
int timer_init(uint64_t lapic_base);

/* Masks the LAPIC timer LVT entry on the calling CPU, so a test can
 * stop ticks without disabling interrupts globally. */
void timer_stop(void);

/* Global tick count, summed across CPUs that run the timer (BOOT-03:
 * the BSP alone). Incremented by the interrupt handler. */
uint64_t timer_ticks(void);

/* PROC-01: optional per-tick hook, called from the LAPIC timer interrupt AFTER timer_on_interrupt() (so after the EOI)
 * with the interrupted frame. Used only by the Ring 3 CPU-time watchdog. The hook runs in interrupt context with
 * interrupts off; it may abandon the frame (ring3_finish) only when the frame's CS has RPL 3. Pass NULL to clear. */
void timer_set_tick_hook(void (*fn)(void *frame));

/* Called by the interrupt dispatcher for TIMER_VECTOR. Increments the
 * global and per-CPU counters and issues EOI. */
void timer_on_interrupt(void);

/* Diagnostics. */
const TimerInfo *timer_info(void);

/* Busy-waits until the tick counter has advanced by `n`, or until a
 * bounded spin expires. Returns 1 if the ticks arrived. Used by the
 * BOOT-03 test to prove interrupts are actually being delivered
 * repeatedly rather than once. */
int timer_wait_ticks(uint64_t n);

#endif /* VEXOS_TIMER_H */
