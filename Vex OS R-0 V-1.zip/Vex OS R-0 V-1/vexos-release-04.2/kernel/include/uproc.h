/*
 * uproc.h - PROC-01: Ring 3 image loader and syscall boundary.
 *
 * WHAT THIS IS: a validated executable-image loader plus a real syscall table on top of the existing Ring 3 machinery
 * (ring3.c: DPL3 `int 0x80` gate, TSS rsp0, checkpoint/restore around the user run, fault isolation).
 *
 * WHAT THIS IS NOT (stated plainly - see docs/PROC-01.md):
 *   - ONE process at a time. There is no scheduler and no concurrency; a run starts, ends, and is fully torn down.
 *   - NO per-process page tables. All runs share the kernel's address space; user pages live in a fixed 40-page
 *     window inside the kmap area, mapped fresh (zeroed frames) per run and unmapped + freed afterwards. Isolation
 *     between runs is therefore temporal (no frame or mapping survives a run), not spatial.
 *   - SMEP/SMAP are NOT enabled by this kernel (reported by SECURITY-02); the kernel could be induced to fetch from a
 *     user page by some other bug. The loader relies on U/S, R/W and NX bits and on its own range checks.
 *   - Executable format is the minimal VXE1 below, not ELF.
 *
 * ---- VXE1 image (little-endian, 48-byte header) -------------------------------------------------------------------
 *   0  u8[4] "VXE1"      4  u16 version = 1     6  u16 header_size = 48     8  u32 flags = 0
 *   12 u32 entry (byte offset INTO the text segment)       16 u32 text_off     20 u32 text_size
 *   24 u32 data_off (0 iff data_size == 0)                 28 u32 data_size    32 u32 bss_size
 *   36 u32 stack_pages (1..4)      40 u32 reserved = 0     44 u32 reserved = 0
 *   text  -> user, read-only, EXECUTABLE pages.   data+bss (zero-filled) and stack -> user, writable, NX pages.
 *   Text and data are always on different pages, so no page is ever writable and executable.
 *
 * ---- Process window (40 pages; every guard page is left unmapped) -------------------------------------------------
 *   page 0 guard | 1..16 text | 17 guard | 18..33 data+bss | 34 guard | 35..38 stack (top `stack_pages` mapped) | 39 guard
 *   At entry: RDI = data base VA, RSI = text base VA, RSP = stack top - 16. Everything else is zero.
 *
 * ---- Syscall ABI: `int 0x80`; RAX = number, RDI RSI RDX R10 = args; return value in RAX (negative = error) ---------
 *   0 EXIT(code)                    does not return
 *   1 WRITE(ptr, len)               len <= 256; copies from user, logs to serial; returns len
 *   2 GETPID()                      returns the process id (monotonic, starts at 1)
 *   3 AI_ASK(in, in_len, out, cap)  in_len <= 256 printable ASCII, 1 <= cap <= 4096; Crystal reply is copied to `out`
 *                                   NUL-terminated and truncated to cap-1; returns the FULL reply length (snprintf-style)
 *   anything else                   -38 (ENOSYS); the number is compared as a full 64-bit value
 * Every user pointer is checked for arithmetic overflow, containment in ONE mapped segment of the current process
 * (read: text/data/stack; write: data/stack only) and, per page, present+user(+writable). Nothing in the kernel
 * dereferences a user pointer before it passes. Failures return -14 (EFAULT) / -22 (EINVAL) and never fault the kernel.
 * CPU budget: a run is terminated when it has been running UPROC_MAX_TICKS timer ticks (10 ms each), checked at every
 * syscall entry and every timer tick that interrupts user code.
 */
#ifndef VEX_UPROC_H
#define VEX_UPROC_H

#include <stdint.h>
#include <stddef.h>
#include "ring3.h"

#define UPROC_HDR_SIZE          48u
#define UPROC_MAX_IMAGE         65536u
#define UPROC_PAGE              4096u
#define UPROC_MAX_TEXT_PAGES    16u
#define UPROC_MAX_DATA_PAGES    16u
#define UPROC_MAX_STACK_PAGES   4u
#define UPROC_WINDOW_PAGES      40u
#define UPROC_PG_TEXT0          1u
#define UPROC_PG_DATA0          18u
#define UPROC_PG_STACK_TOP      39u     /* first page AFTER the stack = the high guard */
#define UPROC_MAX_TICKS         50u     /* 500 ms of wall time at 100 Hz */
#define UPROC_MAX_WRITE         256u
#define UPROC_MAX_OUTPUT        2048u   /* total bytes a process may log */

#define UPROC_SYS_EXIT   0
#define UPROC_SYS_WRITE  1
#define UPROC_SYS_GETPID 2
#define UPROC_SYS_AI_ASK 3

#define UPROC_E_IO      (-5)
#define UPROC_E_BUSY    (-16)
#define UPROC_E_FAULT   (-14)
#define UPROC_E_INVAL   (-22)
#define UPROC_E_NOSYS   (-38)
#define UPROC_E_QUOTA   (-122)

typedef enum {
    UPROC_OK = 0,
    UPROC_E_NULL, UPROC_E_TOO_SMALL, UPROC_E_TOO_BIG, UPROC_E_MAGIC, UPROC_E_VERSION, UPROC_E_HDRSIZE,
    UPROC_E_FLAGS, UPROC_E_RESERVED, UPROC_E_TEXT_SIZE, UPROC_E_TEXT_RANGE, UPROC_E_DATA_RANGE,
    UPROC_E_DATA_PAGES, UPROC_E_OVERLAP, UPROC_E_ENTRY, UPROC_E_STACK,
    UPROC_E_NOT_INIT, UPROC_E_BUSY_RUN, UPROC_E_NO_MEMORY, UPROC_E_MAP
} UprocStatus;

typedef struct {
    uint32_t entry, text_off, text_size, data_off, data_size, bss_size, stack_pages;
    uint32_t text_pages, data_pages;     /* derived */
} UprocLayout;

/* Pure validation (no kernel dependencies - host-fuzzed). Fills *L only on UPROC_OK. */
UprocStatus uproc_image_validate(const uint8_t *img, size_t len, UprocLayout *L);
const char *uproc_status_name(UprocStatus s);

typedef struct {
    UprocStatus status;           /* load/start status; the fields below are valid only when UPROC_OK */
    Ring3Outcome outcome;         /* RING3_OUT_EXITED / FAULTED / TIMEOUT */
    uint64_t exit_code;
    uint64_t pid;
    uint64_t fault_vector, fault_error_code, fault_rip, fault_cr2;
    uint64_t syscalls, syscalls_rejected, ticks;
    uint64_t bytes_written;
    char     last_write[UPROC_MAX_WRITE + 1];
    uint64_t last_write_len;
    uint64_t text_va, data_va, stack_lo_va, stack_top_va;   /* window addresses of this run (for tests) */
} UprocResult;

int  uproc_init(void);                                        /* 1 on success; needs ring3_init() done */
UprocStatus uproc_run(const uint8_t *img, size_t len, UprocResult *out);
uint64_t uproc_runs_total(void);

#endif
