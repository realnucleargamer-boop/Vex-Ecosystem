/* Vex OS - kernel/src/drivers/storage/ahci.c : STORAGE-01 minimal polled AHCI driver. See include/ahci.h. */
#include "ahci.h"
#include "pci.h"
#include "pmm.h"
#include "vmm.h"
#include "serial.h"
#include "pit_delay.h"

#define HBA_GHC 0x04
#define HBA_PI  0x0C
#define PORT(p) (0x100u + (uint32_t)(p) * 0x80u)
#define P_CLB 0x00
#define P_CLBU 0x04
#define P_FB 0x08
#define P_FBU 0x0C
#define P_IS 0x10
#define P_CMD 0x18
#define P_TFD 0x20
#define P_SIG 0x24
#define P_SSTS 0x28
#define P_SERR 0x30
#define P_CI 0x38
#define CMD_ST (1u << 0)
#define CMD_FRE (1u << 4)
#define CMD_FR (1u << 14)
#define CMD_CR (1u << 15)
#define BOUNCE_SECTORS 8u

typedef struct { uint64_t page; volatile uint8_t *cl, *ct; uint8_t *data; uint64_t data_phys; int ok; } PortCtx;
static volatile uint8_t *abar; static AhciDisk disks[AHCI_MAX_DISKS]; static PortCtx pc[AHCI_MAX_DISKS]; static int ndisks; static int inited;

static inline uint32_t r32(uint32_t off) { return *(volatile uint32_t *)(abar + off); }
static inline void w32(uint32_t off, uint32_t v) { *(volatile uint32_t *)(abar + off) = v; }
static int wait_clear(uint32_t off, uint32_t mask, int ms) { for (int i = 0; i < ms * 10; i++) { if (!(r32(off) & mask)) return 1; pit_delay_us(100); } return 0; }

static int port_stop(int p)
{
    uint32_t c = r32(PORT(p) + P_CMD); w32(PORT(p) + P_CMD, c & ~(CMD_ST | CMD_FRE));
    return wait_clear(PORT(p) + P_CMD, CMD_CR | CMD_FR, 500);
}
static void zero(volatile void *v, uint32_t n) { volatile uint8_t *b = v; while (n--) *b++ = 0; }

/* Builds and issues one command in slot 0 and waits for completion. */
static int issue(int d, uint8_t cmd, uint64_t lba, uint32_t count, int write, uint32_t bytes)
{
    PortCtx *c = &pc[d]; int p = disks[d].port; volatile uint32_t *h = (volatile uint32_t *)c->cl; volatile uint8_t *t = c->ct;
    zero(t, 0x90);
    t[0] = 0x27; t[1] = 0x80; t[2] = cmd; t[7] = (uint8_t)(1u << 6);
    t[4] = (uint8_t)lba; t[5] = (uint8_t)(lba >> 8); t[6] = (uint8_t)(lba >> 16); t[8] = (uint8_t)(lba >> 24); t[9] = (uint8_t)(lba >> 32); t[10] = (uint8_t)(lba >> 40);
    t[12] = (uint8_t)count; t[13] = (uint8_t)(count >> 8);
    uint32_t prdtl = bytes ? 1u : 0u;
    if (bytes) { volatile uint32_t *e = (volatile uint32_t *)(t + 0x80); e[0] = (uint32_t)c->data_phys; e[1] = (uint32_t)(c->data_phys >> 32); e[2] = 0; e[3] = bytes - 1; }
    h[0] = 5u | (write ? (1u << 6) : 0u) | (prdtl << 16); h[1] = 0;
    uint64_t ctp = c->page + 0x500; h[2] = (uint32_t)ctp; h[3] = (uint32_t)(ctp >> 32);
    w32(PORT(p) + P_IS, 0xFFFFFFFFu); w32(PORT(p) + P_SERR, 0xFFFFFFFFu);
    if (!wait_clear(PORT(p) + P_TFD, 0x88u, 500)) return -3;            /* BSY | DRQ */
    __sync_synchronize(); w32(PORT(p) + P_CI, 1u);
    for (int i = 0; i < 30000; i++) {                                    /* ~3 s */
        if (!(r32(PORT(p) + P_CI) & 1u)) break;
        if (r32(PORT(p) + P_IS) & (1u << 30)) return -2;                 /* task file error */
        pit_delay_us(100);
        if (i == 29999) return -3;
    }
    if (r32(PORT(p) + P_TFD) & 0x01u) return -2;                         /* ERR */
    return 0;
}

static int setup_port(int p, int slot)
{
    PortCtx *c = &pc[slot];
    if (!port_stop(p)) return 0;
    uint64_t page = pmm_alloc_page_below(0x100000000ull), data = pmm_alloc_page_below(0x100000000ull);
    if (!page || !data) { if (page) pmm_free_pages(page, 1); if (data) pmm_free_pages(data, 1); return 0; }
    c->page = page; c->cl = (volatile uint8_t *)(uintptr_t)page; c->ct = (volatile uint8_t *)(uintptr_t)(page + 0x500); c->data = (uint8_t *)(uintptr_t)data; c->data_phys = data;
    zero((volatile void *)(uintptr_t)page, 4096); zero((volatile void *)(uintptr_t)data, 4096);
    w32(PORT(p) + P_CLB, (uint32_t)page); w32(PORT(p) + P_CLBU, (uint32_t)(page >> 32));
    w32(PORT(p) + P_FB, (uint32_t)(page + 0x400)); w32(PORT(p) + P_FBU, (uint32_t)((page + 0x400) >> 32));
    w32(PORT(p) + P_SERR, 0xFFFFFFFFu); w32(PORT(p) + P_IS, 0xFFFFFFFFu);
    w32(PORT(p) + P_CMD, r32(PORT(p) + P_CMD) | CMD_FRE); w32(PORT(p) + P_CMD, r32(PORT(p) + P_CMD) | CMD_ST);
    c->ok = 1; return 1;
}

int ahci_init(void)
{
    if (inited) return ndisks;
    inited = 1;
    const PciDev *d = pci_find_class(0x01, 0x06, 0x01);
    if (!d) { serial_puts("[ahci] no AHCI controller on PCI\n"); return 0; }
    uint64_t phys = pci_bar_mem(d, 5);
    if (!phys || (phys & 0xFFF)) { serial_puts("[ahci] ABAR (BAR5) missing or not page aligned\n"); return 0; }
    uint64_t va = vmm_kmap_reserve_virtual(2);
    if (!va || vmm_map_page(va, phys, VMM_KERNEL_MMIO) != VMM_OK || vmm_map_page(va + 0x1000, phys + 0x1000, VMM_KERNEL_MMIO) != VMM_OK) { serial_puts("[ahci] cannot map ABAR\n"); return 0; }
    pci_enable_mem_dma(d); abar = (volatile uint8_t *)(uintptr_t)va;
    w32(HBA_GHC, r32(HBA_GHC) | (1u << 31));                             /* AHCI enable */
    uint32_t pi = r32(HBA_PI);
    serial_puts("[ahci] controller "); serial_put_hex64(d->vendor); serial_puts(":"); serial_put_hex64(d->device); serial_puts(" ports-implemented="); serial_put_hex64(pi); serial_puts("\n");
    for (int p = 0; p < 32 && ndisks < AHCI_MAX_DISKS; p++) {
        if (!(pi & (1u << p))) continue;
        uint32_t ss = r32(PORT(p) + P_SSTS);
        if ((ss & 0xF) != 3 || ((ss >> 8) & 0xF) != 1) continue;         /* no device / no active link */
        if (r32(PORT(p) + P_SIG) != 0x00000101u) { serial_puts("[ahci] port "); serial_put_dec64((uint64_t)p); serial_puts(": non-ATA device ignored\n"); continue; }
        if (!setup_port(p, ndisks)) { serial_puts("[ahci] port setup failed\n"); continue; }
        disks[ndisks].port = p; disks[ndisks].sectors = 0;
        if (issue(ndisks, 0xEC, 0, 0, 0, 512) != 0) { serial_puts("[ahci] IDENTIFY failed on port "); serial_put_dec64((uint64_t)p); serial_puts("\n"); pc[ndisks].ok = 0; continue; }
        const uint16_t *id = (const uint16_t *)pc[ndisks].data;
        if (!(id[83] & (1u << 10))) { serial_puts("[ahci] disk without LBA48 ignored\n"); pc[ndisks].ok = 0; continue; }
        disks[ndisks].sectors = (uint64_t)id[100] | ((uint64_t)id[101] << 16) | ((uint64_t)id[102] << 32) | ((uint64_t)id[103] << 48);
        for (int i = 0; i < 20; i++) { disks[ndisks].model[2 * i] = (char)(id[27 + i] >> 8); disks[ndisks].model[2 * i + 1] = (char)id[27 + i]; }
        disks[ndisks].model[40] = 0; for (int i = 39; i >= 0 && (disks[ndisks].model[i] == ' ' || disks[ndisks].model[i] == 0); i--) disks[ndisks].model[i] = 0;
        serial_puts("[ahci] disk "); serial_put_dec64((uint64_t)ndisks); serial_puts(" port "); serial_put_dec64((uint64_t)p); serial_puts(": "); serial_puts(disks[ndisks].model);
        serial_puts(", "); serial_put_dec64(disks[ndisks].sectors); serial_puts(" sectors\n");
        ndisks++;
    }
    if (!ndisks) serial_puts("[ahci] no usable ATA disk\n");
    return ndisks;
}
int ahci_disk_count(void) { return ndisks; }
const AhciDisk *ahci_disk(int i) { return (i >= 0 && i < ndisks) ? &disks[i] : 0; }

int ahci_read(int d, uint64_t lba, uint32_t count, void *buf)
{
    if (d < 0 || d >= ndisks || !pc[d].ok || !buf || count == 0 || lba >= disks[d].sectors || count > disks[d].sectors - lba) return -1;
    uint8_t *o = buf;
    while (count) {
        uint32_t n = count > BOUNCE_SECTORS ? BOUNCE_SECTORS : count;
        int r = issue(d, 0x25, lba, n, 0, n * 512); if (r) return r;
        for (uint32_t i = 0; i < n * 512; i++) o[i] = pc[d].data[i];
        o += n * 512; lba += n; count -= n;
    }
    return 0;
}
int ahci_write(int d, uint64_t lba, uint32_t count, const void *buf)
{
    if (d < 0 || d >= ndisks || !pc[d].ok || !buf || count == 0 || lba >= disks[d].sectors || count > disks[d].sectors - lba) return -1;
    const uint8_t *s = buf;
    while (count) {
        uint32_t n = count > BOUNCE_SECTORS ? BOUNCE_SECTORS : count;
        for (uint32_t i = 0; i < n * 512; i++) pc[d].data[i] = s[i];
        int r = issue(d, 0x35, lba, n, 1, n * 512); if (r) return r;
        s += n * 512; lba += n; count -= n;
    }
    return issue(d, 0xEA, 0, 0, 0, 0);                                   /* FLUSH CACHE EXT */
}
