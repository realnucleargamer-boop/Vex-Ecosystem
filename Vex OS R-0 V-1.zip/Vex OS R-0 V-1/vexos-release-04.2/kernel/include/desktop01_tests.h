/* DESKTOP-01 in-kernel logic tests: accounts, IST, key map, app tracker, the REAL compiled VexScript
 * terminal (through the host), and the setup/lock/users/desktop/V-menu/search/terminal UI flows.
 * Logic only; end-to-end behaviour is verified by scripts/desktop_e2e.py. Counters are counted. */
#ifndef VEXOS_DESKTOP01_TESTS_H
#define VEXOS_DESKTOP01_TESTS_H
#include <stdint.h>
typedef struct { uint32_t checks_run, checks_failed; } Desktop01Results;
void desktop01_run_tests(Desktop01Results *out);
void desktop01_print_summary(const Desktop01Results *r);
int  desktop01_all_passed(const Desktop01Results *r);
#endif
