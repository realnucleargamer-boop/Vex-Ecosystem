/* Vex OS - kernel/include/cpuacct.h : real CPU accounting for the boot processor (BSP).
 * MEANING OF THE PERCENTAGE: the fraction of TSC time, since the previous sample, that the BSP spent NOT halted in the
 * main loop's `hlt` (i.e. running the kernel/UI). 100% = the BSP was never idle. It measures the BSP only; the other
 * CPUs are parked (cli; hlt) and run no work, so there is nothing to account for them. No frequency is assumed (ratio only). */
#ifndef VEXOS_CPUACCT_H
#define VEXOS_CPUACCT_H
#include <stdint.h>
void cpuacct_init(void);
void cpuacct_idle_begin(void);                 /* call immediately before hlt */
void cpuacct_idle_end(void);                   /* call immediately after hlt returns */
int  cpuacct_sample(uint32_t *busy_permille);  /* busy fraction x1000 since last sample; 0 = no valid window yet */
/* Pure helper, unit-tested: busy permille from elapsed/idle TSC deltas (clamped to 0..1000). */
uint32_t cpuacct_permille(uint64_t elapsed, uint64_t idle);
#endif
