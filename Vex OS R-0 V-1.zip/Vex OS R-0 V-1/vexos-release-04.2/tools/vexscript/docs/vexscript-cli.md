# vexc CLI

```bash
PYTHONPATH=src python3 -m vexscript.cli check [path]
PYTHONPATH=src python3 -m vexscript.cli build [path]
PYTHONPATH=src python3 -m vexscript.cli run [path]
PYTHONPATH=src python3 -m vexscript.cli emit-ir [path]
PYTHONPATH=src python3 -m vexscript.cli --version
```

Or `scripts/vexc` with PYTHONPATH set.
