# Vex OS - build.ps1
#
# Windows-native build of the current milestone (BOOT-02B) using clang/lld
# + NASM.
#
# Tools are located automatically - see scripts\VexToolchain.ps1. You do NOT
# need to add NASM or LLVM to PATH, in this terminal or any other. Resolved
# directories are prepended to this process's PATH only; your persistent
# environment is never modified.
#
# Pipeline (mirrors the Linux Makefiles, verified equivalent by
# actually boot-testing a clang/lld-built image before this script
# was written - see docs/WINDOWS-BUILD.md):
#
#   bootloader/src/main_win.c  --clang(x86_64-unknown-windows)-->  .obj
#                               --lld-link(/subsystem:efi_application)--> build\BOOTX64.EFI
#
#   kernel/src/**/*.c          --clang(x86_64-unknown-elf)-->       .o
#   kernel/src/**/*.asm        --nasm(-f elf64)-->                  .o
#                               --ld.lld(-T kernel\linker.ld)-->     kernel.elf
#                               --llvm-objcopy(-O binary)-->         build\KERNEL.ELF
#
#   build\BOOTX64.EFI + build\KERNEL.ELF --diskpart/format--> build\vexos.img (VHD)
#
# Does NOT touch bootloader/src/main.c (the Linux/gnu-efi build) or
# the existing Makefiles - Linux/WSL build path is untouched.
#
# Requires an ELEVATED (Administrator) PowerShell session, because
# diskpart's vdisk create/attach and drive-letter assignment require
# admin rights. The script checks and fails clearly if not elevated.

#Requires -Version 5.1

[CmdletBinding()]
param(
    # Ignore build\toolchain.local.json and re-discover every tool. Use after
    # installing, upgrading, or moving LLVM/NASM.
    [switch]$RefreshTools
)

$ErrorActionPreference = "Stop"

$RepoRoot   = Split-Path -Parent $PSCommandPath
$BuildDir   = Join-Path $RepoRoot "build"
$KernelObjDir = Join-Path $BuildDir "kernel-obj"
$VhdPath    = Join-Path $BuildDir "vexos.vhd"   # diskpart requires a .vhd/.vhdx extension
$ImgPath    = Join-Path $BuildDir "vexos.img"   # final artifact name, per the agreed pipeline
$ImgSizeMB = 256

function Write-Step($msg) { Write-Host "==> $msg" -ForegroundColor Cyan }
function Write-Fail($msg) { Write-Host "ERROR: $msg" -ForegroundColor Red; exit 1 }

# ------------------------------------------------------------------
# Elevation check
# ------------------------------------------------------------------
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal(
    [Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Fail "This script must run in an elevated (Administrator) PowerShell session.`n  diskpart's VHD create/attach and drive-letter assignment require it.`n  Right-click PowerShell -> 'Run as Administrator', then re-run build.ps1."
}

# ------------------------------------------------------------------
# Tool discovery
#
# Replaces the previous "Get-Command or die" approach, which failed on a
# perfectly good NASM install purely because NASM's installer does not put
# itself on PATH (upstream bug 3392224). Discovery now covers env overrides,
# a validated per-machine cache, PATH, standard install directories,
# registry uninstall entries, and finally a bounded filesystem probe.
# ------------------------------------------------------------------
. (Join-Path $RepoRoot "scripts\VexToolchain.ps1")
. (Join-Path $RepoRoot "scripts\VexDisk.ps1")

New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null
New-Item -ItemType Directory -Force -Path $KernelObjDir | Out-Null

Write-Step "Locating build tools"
try {
    # QEMU is deliberately NOT required here - building an image should not
    # depend on having a way to run it. run-qemu.ps1 resolves QEMU itself.
    $tc = Resolve-VexToolchain -RepoRoot $RepoRoot -Require @("llvm","nasm") -Refresh:$RefreshTools
} catch {
    Write-Fail $_.Exception.Message
}

$Clang   = $tc["clang"]
$LldLink = $tc["lld-link"]
$LldElf  = $tc["ld.lld"]
$ObjCopy = $tc["llvm-objcopy"]
$Nasm    = $tc["nasm"]

# ------------------------------------------------------------------
# Bootloader (clang -> x86_64-unknown-windows -> lld-link EFI subsystem)
# ------------------------------------------------------------------
Write-Step "Building bootloader (build\BOOTX64.EFI)"

$BootloaderSrc = Join-Path $RepoRoot "bootloader\src\main_win.c"
$BootloaderInc = Join-Path $RepoRoot "bootloader\include"
$CommonInc     = Join-Path $RepoRoot "common\include"
$BootObj       = Join-Path $BuildDir "main_win.obj"
$BootEfi       = Join-Path $BuildDir "BOOTX64.EFI"

& $Clang --target=x86_64-unknown-windows -ffreestanding -fshort-wchar `
    -fno-stack-protector -mno-red-zone -Wall -Wextra `
    -I "$BootloaderInc" -I "$CommonInc" `
    -c "$BootloaderSrc" -o "$BootObj"
if ($LASTEXITCODE -ne 0) { Write-Fail "Bootloader compile failed." }

& $LldLink "$BootObj" /entry:efi_main /subsystem:efi_application /machine:x64 `
    /nodefaultlib /out:"$BootEfi"
if ($LASTEXITCODE -ne 0) { Write-Fail "Bootloader link failed." }

Write-Host "  Built $BootEfi"

# ------------------------------------------------------------------
# Kernel (clang -> x86_64-unknown-elf, nasm, ld.lld, llvm-objcopy)
# ------------------------------------------------------------------
Write-Step "Building kernel (build\KERNEL.ELF)"

$KernelInc  = Join-Path $RepoRoot "kernel\include"
$LinkerScript = Join-Path $RepoRoot "kernel\linker.ld"
$KernelElfOut = Join-Path $BuildDir "kernel.elf"
$KernelFlatOut = Join-Path $BuildDir "KERNEL.ELF"

# NOTE: object files are named by basename only (not full relative
# path), unlike kernel/Makefile which preserves directory structure.
# This works as long as every source file has a unique basename
# across the whole kernel tree - true today, but if a future file
# collides (e.g. two different idt.c), this will silently overwrite
# one .o with another. Flag for fixing if/when that happens rather
# than pre-solving it now.
$CSources = @(
    "kernel\src\core\kernel_entry.c",
    "kernel\src\core\serial.c",
    "kernel\src\core\panic.c",
    "kernel\src\arch\x86_64\gdt\gdt.c",
    "kernel\src\arch\x86_64\idt\idt.c",
    "kernel\src\memory\physical\pmm.c",
    "kernel\src\arch\x86_64\cpu\ap_stack.c",
    "kernel\src\arch\x86_64\acpi\acpi.c",
    "kernel\src\arch\x86_64\apic\lapic.c",
    "kernel\src\arch\x86_64\apic\ipi.c",
    "kernel\src\arch\x86_64\time\pit_delay.c",
    "kernel\src\arch\x86_64\smp\smp.c",
    "kernel\src\memory\virtual\vmm.c",
    "kernel\src\memory\virtual\tlb.c",
    "kernel\src\memory\virtual\kstack.c",
    "kernel\src\arch\x86_64\cpu\percpu.c",
    "kernel\src\arch\x86_64\cpu\context.c",
    "kernel\src\arch\x86_64\time\timer.c",
    "kernel\src\core\boot03_tests.c",
    "kernel\src\core\kernel01_tests.c",
    "kernel\src\security\secure.c",
    "kernel\src\core\security01_tests.c",
    "kernel\src\graphics\gfx_fb.c",
    "kernel\src\graphics\gfx_draw.c",
    "kernel\src\graphics\gfx_font8x16.c",
    "kernel\src\graphics\gfx_text.c",
    "kernel\src\graphics\gfx_screen.c"
)
$AsmSources = @(
    "kernel\src\arch\x86_64\boot\start.asm",
    "kernel\src\arch\x86_64\gdt\gdt_flush.asm",
    "kernel\src\arch\x86_64\idt\isr_stubs.asm",
    "kernel\src\arch\x86_64\smp\ap_trampoline_blob.asm",
    "kernel\src\arch\x86_64\cpu\context_switch.asm",
    "kernel\src\security\probe.asm"
)

$objs = @()

foreach ($rel in $CSources) {
    $src = Join-Path $RepoRoot $rel
    $obj = Join-Path $KernelObjDir ((Split-Path $rel -Leaf) -replace '\.c$', '.o')
    & $Clang --target=x86_64-unknown-elf -ffreestanding -fno-stack-protector `
        -fno-stack-check -fno-pic -fno-pie -mno-red-zone -mcmodel=kernel `
        -mno-mmx -mno-sse -mno-sse2 -Wall -Wextra -std=gnu11 `
        -I "$KernelInc" -I "$CommonInc" `
        -c "$src" -o "$obj"
    if ($LASTEXITCODE -ne 0) { Write-Fail "Kernel compile failed: $rel" }
    $objs += $obj
}

# BOOT-02C: the AP trampoline is assembled as a STANDALONE FLAT BINARY
# (nasm -f bin, org 0) and then embedded into the kernel by
# ap_trampoline_blob.asm via `incbin`. It is deliberately not part of
# the kernel link - see kernel/src/arch/x86_64/smp/ap_trampoline.asm for
# why (it executes from a low physical page in real mode, so link-time
# addresses would be meaningless).
#
# This MUST be built before ap_trampoline_blob.asm is assembled, and the
# `incbin "build/ap_trampoline.bin"` path inside that file is resolved
# relative to the repository root, so nasm is given the repo root on its
# include path (-i) to match kernel/Makefile's behaviour.
Write-Step "Assembling AP trampoline flat binary (build\ap_trampoline.bin)"

$TrampolineSrc = Join-Path $RepoRoot "kernel\src\arch\x86_64\smp\ap_trampoline.asm"
$TrampolineBin = Join-Path $BuildDir "ap_trampoline.bin"

& $Nasm -f bin "$TrampolineSrc" -o "$TrampolineBin"
if ($LASTEXITCODE -ne 0) { Write-Fail "AP trampoline assembly failed." }

if (-not (Test-Path $TrampolineBin)) {
    Write-Fail "AP trampoline binary was not produced: $TrampolineBin"
}

# The trampoline must be exactly one 4 KiB page. The .asm file asserts
# this at assembly time too; checking here as well means a stale or
# truncated file on the Windows path is caught before it is embedded.
$trampSize = (Get-Item $TrampolineBin).Length
if ($trampSize -ne 4096) {
    Write-Fail "AP trampoline binary is $trampSize bytes, expected 4096."
}

foreach ($rel in $AsmSources) {
    $src = Join-Path $RepoRoot $rel
    $obj = Join-Path $KernelObjDir ((Split-Path $rel -Leaf) -replace '\.asm$', '.o')
    # -i <repo root> so `incbin "build/ap_trampoline.bin"` resolves the
    # same way it does under kernel/Makefile.
    & $Nasm -f elf64 -i "$RepoRoot" "$src" -o "$obj"
    if ($LASTEXITCODE -ne 0) { Write-Fail "NASM assembly failed: $rel" }
    $objs += $obj
}

& $LldElf -nostdlib -no-pie -T "$LinkerScript" $objs -o "$KernelElfOut"
if ($LASTEXITCODE -ne 0) { Write-Fail "Kernel link failed." }

& $ObjCopy -O binary "$KernelElfOut" "$KernelFlatOut"
if ($LASTEXITCODE -ne 0) { Write-Fail "Kernel objcopy to flat binary failed." }

Write-Host "  Built $KernelFlatOut"

# ------------------------------------------------------------------
# Disk image: VHD via diskpart (Windows-native, no custom FAT writer)
#
# Creates a fixed VHD, attaches it, partitions it GPT with a proper
# EFI System Partition, formats FAT32, copies the two boot files on,
# then detaches. All via diskpart, built into Windows - no third-party
# tool required.
#
# The mechanics live in scripts\VexDisk.ps1, which adds the robustness this
# block previously lacked: stale attached VHDs from a crashed run are
# detached before anything else, the drive letter is chosen dynamically
# (with retries) instead of hardcoding V:, diskpart output is actually
# checked for errors, the mount is polled until writable rather than tested
# once, and the detach below is in a finally block so no failure can leave
# the VHD attached and poison the next build.
# ------------------------------------------------------------------
Write-Step "Building disk image (build\vexos.img)"

# Both leftover artifacts may be attached, not merely present: a previous
# run could have died before or after the .vhd -> .img rename.
try {
    Dismount-VexVhd -Path $VhdPath -WorkDir $BuildDir | Out-Null
    Dismount-VexVhd -Path $ImgPath -WorkDir $BuildDir -Quiet | Out-Null
    Remove-VexFileWithRetry -Path $VhdPath
    Remove-VexFileWithRetry -Path $ImgPath
} catch {
    Write-Fail $_.Exception.Message
}

$MountLetter = $null
$DiskError   = $null
try {
    $MountLetter = New-VexEfiVhd -VhdPath $VhdPath -BuildDir $BuildDir -SizeMB $ImgSizeMB -EspSizeMB 64 -Label "VEXOS"

    Write-Step "Copying boot files onto the image (${MountLetter}:)"
    $espBootDir = "${MountLetter}:\EFI\BOOT"
    New-Item -ItemType Directory -Force -Path $espBootDir | Out-Null
    Copy-Item "$BootEfi" (Join-Path $espBootDir "BOOTX64.EFI") -Force
    Copy-Item "$KernelFlatOut" "${MountLetter}:\KERNEL.ELF" -Force

    # Verify the files are actually on the ESP before declaring success.
    # A silent copy failure here produces a VHD that boots to the UEFI shell,
    # which is a confusing symptom to debug later.
    foreach ($expected in @((Join-Path $espBootDir "BOOTX64.EFI"), "${MountLetter}:\KERNEL.ELF")) {
        if (-not (Test-Path -LiteralPath $expected)) {
            throw "Expected file '$expected' is missing from the image after copy."
        }
    }
}
catch {
    # Record and rethrow after the finally block has detached. Calling
    # Write-Fail (which exits) from here would skip cleanup.
    $DiskError = $_
}
finally {
    # Detach unconditionally: on success so QEMU can open the file
    # exclusively, and on failure so the next build starts clean.
    if ($MountLetter) {
        Write-Host "  Detaching image (was mounted at ${MountLetter}:)" -ForegroundColor DarkGray
    }
    Dismount-VexVhd -Path $VhdPath -WorkDir $BuildDir -Quiet | Out-Null
}

if ($DiskError) {
    Write-Fail ("Disk image creation failed - the VHD has been detached, so the next run starts clean.`n  " +
                $DiskError.Exception.Message)
}

# Rename to the agreed final artifact name. The bytes are still a VHD
# (footer-based) container - run-qemu.ps1 passes format=vpc explicitly
# so QEMU reads it correctly regardless of the .img extension.
Move-Item -LiteralPath "$VhdPath" -Destination "$ImgPath" -Force

Write-Host ""
Write-Host "Build complete: $ImgPath" -ForegroundColor Green
Write-Host "(Note: this file is VHD-formatted; run-qemu.ps1 passes format=vpc explicitly.)" -ForegroundColor DarkGray
Write-Host "Run 'run-qemu.ps1' to boot it." -ForegroundColor Green


