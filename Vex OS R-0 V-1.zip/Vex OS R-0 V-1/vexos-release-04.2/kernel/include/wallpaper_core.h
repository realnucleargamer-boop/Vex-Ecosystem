/*
 * Vex OS - kernel/include/wallpaper_core.h
 *
 * WALLPAPER-01 pure core: the "VWP1" wallpaper container, its validator, and a bounds-checked
 * cover-fit bilinear scaler.  No kernel dependencies (no allocator, no serial, no framebuffer) so the
 * identical code is compiled natively by tests/wallpaper_host_test.py and fuzzed on the host.
 *
 * VEX OS has no PNG/JPEG decoder and no writable storage (see docs/WALLPAPER-01.md), so wallpapers
 * are converted at BUILD time (tools/make_wallpapers.py) into this trivially-parsed raw format.
 * Nothing in this file allocates; every function that reads a blob bounds-checks against its length.
 */
#ifndef VEXOS_WALLPAPER_CORE_H
#define VEXOS_WALLPAPER_CORE_H

#include <stdint.h>
#include <stddef.h>

#define WP_HEADER_BYTES 20u
#define WP_MIN_DIM      16u
#define WP_MAX_DIM      512u          /* stored size; bounds every pixel-count multiplication below */
#define WP_FMT_RGB565   1u

typedef struct { const char *id; const char *name; const uint8_t *data; uint32_t size; } WpAsset;
extern const WpAsset wp_assets[];     /* wallpaper_data.c (generated) */
extern const int wp_asset_count;

typedef enum {
    WP_OK = 0,
    WP_E_NULL,        /* null blob / null output */
    WP_E_TRUNCATED,   /* blob shorter than header or than header + pixels */
    WP_E_MAGIC,       /* not a VWP1 container */
    WP_E_FORMAT,      /* unsupported pixel format or non-zero reserved fields */
    WP_E_DIMS,        /* width/height outside [WP_MIN_DIM, WP_MAX_DIM] */
    WP_E_SIZE,        /* pixel_bytes != w*h*2, or trailing bytes */
    WP_E_CRC,         /* pixel data does not match the stored checksum (corrupt) */
    WP_E_MISSING,     /* no such wallpaper / empty asset */
    WP_E_NOMEM,       /* could not allocate the scaled-image cache */
    WP_E_SCREEN,      /* screen size unsupported (too large / zero / not a 32-bit framebuffer) */
    WP_E_RANGE        /* bad geometry argument */
} WpStatus;

typedef struct { uint16_t w, h; const uint8_t *px; } WpImage;   /* px points INTO the validated blob */

/* Cover-fit geometry of a src_w x src_h image shown on a vw x vh surface:
 * scaled to (sw x sh) with sw>=vw && sh>=vh, then centre-cropped by (cx, cy). */
typedef struct { uint32_t vw, vh, sw, sh, cx, cy; } WpCover;

const char *wp_status_text(WpStatus s);                 /* short, user-presentable reason */
uint32_t    wp_crc32(const uint8_t *p, uint32_t n);     /* zlib/IEEE polynomial */

/* Structure only: header, dimensions, exact length.  Does NOT read the pixels. */
WpStatus wp_parse(const uint8_t *blob, uint32_t len, WpImage *out);
/* wp_parse + checksum over the pixel bytes. Use this before trusting an image. */
WpStatus wp_verify(const uint8_t *blob, uint32_t len, WpImage *out);

WpStatus wp_cover(uint32_t src_w, uint32_t src_h, uint32_t vw, uint32_t vh, WpCover *out);

/* Render n pixels of row y (starting at column x0) of the virtual vw x vh cover image into out[],
 * packed with the framebuffer channel shifts.  Fails (and writes nothing) if x0+n or y is out of range. */
WpStatus wp_render_row(const WpImage *img, const WpCover *cv, uint32_t y, uint32_t x0, uint32_t n,
                       uint32_t *out, uint8_t rs, uint8_t gs, uint8_t bs);

/* Mean luma (0..255) of a w x h block of packed pixels (sampled every 2nd pixel); 0 if empty. */
uint32_t wp_mean_luma(const uint32_t *px, uint32_t pitch_px, uint32_t w, uint32_t h,
                      uint8_t rs, uint8_t gs, uint8_t bs);

#endif /* VEXOS_WALLPAPER_CORE_H */
