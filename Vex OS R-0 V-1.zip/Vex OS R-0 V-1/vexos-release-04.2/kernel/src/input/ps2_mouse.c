/*
 * Vex OS - kernel/src/input/ps2_mouse.c
 * INPUT-03 polled PS/2 mouse. See include/ps2_mouse.h for the design notes.
 */
#include "ps2_mouse.h"
#include "input.h"
#include "serial.h"

#define I8042_DATA   0x60
#define I8042_CMD    0x64   /* write: command, read: status */
#define ST_OBF       (1u << 0)
#define ST_IBF       (1u << 1)
#define ST_AUX       (1u << 5)

/* A half-assembled packet older than this many 100 Hz ticks is abandoned.
 * Real hardware streams a packet in ~3 ms, so 10 ticks (100 ms) is far
 * beyond any legitimate gap. */
#define STALE_TICKS  10u

static inline void outb(uint16_t p, uint8_t v) { __asm__ volatile("outb %0,%1" :: "a"(v), "Nd"(p)); }
static inline uint8_t inb(uint16_t p) { uint8_t v; __asm__ volatile("inb %1,%0" : "=a"(v) : "Nd"(p)); return v; }

/* ---- pure decode ---------------------------------------------------- */
int ps2_mouse_decode(uint8_t b0, uint8_t b1, uint8_t b2, Ps2MousePacket *out)
{
    if (!out || !(b0 & 0x08u)) return 0;
    /* The sign bits live in b0; the 9-bit two's-complement value is
     * (sign ? b - 256 : b).  Expressed without any signed shift of a
     * negative value. */
    int32_t dx = (int32_t)b1 - ((b0 & 0x10u) ? 256 : 0);
    int32_t dy = (int32_t)b2 - ((b0 & 0x20u) ? 256 : 0);
    out->overflow = (b0 & 0xC0u) != 0;
    if (out->overflow) { dx = 0; dy = 0; }   /* a clipped delta is not a real delta */
    out->dx = dx;
    out->dy = -dy;                            /* device +y is up; screen +y is down */
    out->buttons = (uint8_t)(b0 & 0x07u);
    return 1;
}

/* ---- stream assembler ---------------------------------------------- */
static uint8_t  pkt[3];
static uint32_t pidx;
static uint64_t last_tick;
static uint8_t  last_buttons;
static uint64_t npackets, nresyncs;
static int      present;

void ps2_mouse_reset_decoder(void) { pidx = 0; last_buttons = 0; last_tick = 0; }
uint64_t ps2_mouse_packets(void)  { return npackets; }
uint64_t ps2_mouse_resyncs(void)  { return nresyncs; }
int ps2_mouse_present(void)       { return present; }

void ps2_mouse_feed(uint8_t b, uint64_t now)
{
    if (pidx != 0 && now != 0 && now - last_tick > STALE_TICKS) { pidx = 0; nresyncs++; }
    last_tick = now;
    if (pidx == 0 && !(b & 0x08u)) { nresyncs++; return; }   /* not a valid first byte: slide forward */
    pkt[pidx++] = b;
    if (pidx < 3) return;
    pidx = 0;

    Ps2MousePacket p;
    if (!ps2_mouse_decode(pkt[0], pkt[1], pkt[2], &p)) { nresyncs++; return; }
    npackets++;
    if (p.dx == 0 && p.dy == 0 && p.buttons == last_buttons) return;  /* nothing changed */
    last_buttons = p.buttons;
    (void)input_publish_mouse(p.dx, p.dy, p.buttons);
}

/* ---- controller / device bring-up ----------------------------------- */
/* Bounded spin counts.  Each inb of the status port is >= ~0.5us on real
 * hardware, so these are generous; they exist so an absent or wedged
 * controller can never hang boot. */
#define SPIN_SHORT  200000u
#define SPIN_LONG  2000000u

static int wait_ibf_clear(void) { for (uint32_t i = 0; i < SPIN_SHORT; i++) if (!(inb(I8042_CMD) & ST_IBF)) return 1; return 0; }
static int wait_obf_set(uint32_t n) { for (uint32_t i = 0; i < n; i++) if (inb(I8042_CMD) & ST_OBF) return 1; return 0; }

static void flush_output(void)
{
    for (uint32_t i = 0; i < 64u && (inb(I8042_CMD) & ST_OBF); i++) (void)inb(I8042_DATA);
}

/* Read one byte that came from the AUX device; a keyboard byte seen while
 * waiting is discarded (boot-time only; nothing is typing yet). */
static int read_aux(uint8_t *out, uint32_t spins)
{
    for (int tries = 0; tries < 8; tries++) {
        if (!wait_obf_set(spins)) return 0;
        uint8_t st = inb(I8042_CMD);
        uint8_t b  = inb(I8042_DATA);
        if (st & ST_AUX) { *out = b; return 1; }
    }
    return 0;
}

static int ctrl_cmd(uint8_t c) { if (!wait_ibf_clear()) return 0; outb(I8042_CMD, c); return 1; }
static int ctrl_write_data(uint8_t d) { if (!wait_ibf_clear()) return 0; outb(I8042_DATA, d); return 1; }

/* Send one byte to the mouse (0xD4 prefix) and require ACK (0xFA);
 * retry on 0xFE (resend). */
static int mouse_cmd(uint8_t c)
{
    for (int attempt = 0; attempt < 3; attempt++) {
        if (!ctrl_cmd(0xD4) || !ctrl_write_data(c)) return 0;
        uint8_t r;
        if (!read_aux(&r, SPIN_LONG)) return 0;
        if (r == 0xFA) return 1;
        if (r != 0xFE) return 0;
    }
    return 0;
}

int ps2_mouse_init(void)
{
    present = 0;
    ps2_mouse_reset_decoder();
    npackets = nresyncs = 0;

    /* A missing controller reads back 0xFF on every port. */
    if (inb(I8042_CMD) == 0xFF) { serial_puts("[mouse] no i8042 controller (status 0xFF)\n"); return 0; }

    flush_output();
    if (!ctrl_cmd(0xA8)) { serial_puts("[mouse] enable-aux command timed out\n"); return 0; }

    /* Controller configuration byte: bit5 = aux clock DISABLED, bit1 = aux IRQ
     * enable.  Un-gate the clock; clear the IRQ enable because nothing is
     * routed to receive IRQ12 and we poll.  Bit 0 (keyboard IRQ) and the
     * translation bit are left exactly as firmware set them. */
    if (!ctrl_cmd(0x20) || !wait_obf_set(SPIN_SHORT)) { serial_puts("[mouse] cannot read controller config\n"); return 0; }
    uint8_t cfg = inb(I8042_DATA);
    cfg = (uint8_t)(cfg & ~((1u << 5) | (1u << 1)));
    if (!ctrl_cmd(0x60) || !ctrl_write_data(cfg)) { serial_puts("[mouse] cannot write controller config\n"); return 0; }

    /* Reset: ACK, then (best-effort) self-test 0xAA and device id 0x00. */
    if (!mouse_cmd(0xFF)) {
        serial_puts("[mouse] no PS/2 mouse answered reset - keyboard-only\n");
        (void)ctrl_cmd(0xA7);   /* leave the aux port disabled */
        return 0;
    }
    uint8_t r = 0, id = 0xFF;
    int selftest = read_aux(&r, SPIN_LONG) && r == 0xAA;
    if (selftest) (void)read_aux(&id, SPIN_SHORT);
    serial_puts("[mouse] reset: self-test ");
    serial_puts(selftest ? "0xAA" : "no-response");
    serial_puts(", device id ");
    serial_put_hex64(id);
    serial_puts("\n");

    if (!mouse_cmd(0xF6)) { serial_puts("[mouse] set-defaults not acknowledged\n"); (void)ctrl_cmd(0xA7); return 0; }
    if (!mouse_cmd(0xF4)) { serial_puts("[mouse] enable-reporting not acknowledged\n"); (void)ctrl_cmd(0xA7); return 0; }

    flush_output();
    ps2_mouse_reset_decoder();
    present = 1;
    serial_puts("[mouse] PS/2 mouse streaming (3-byte packets, polled)\n");
    return 1;
}
