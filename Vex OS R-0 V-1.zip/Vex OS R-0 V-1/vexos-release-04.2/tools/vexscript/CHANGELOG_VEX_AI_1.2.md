# CHANGELOG — VEX AI 1.2 toolchain pass

Builds on the 1.1 toolchain pass (three language fixes + accel builtin IR
dispatch, already present in this package). Adds:

## New runtime module: `src/vexscript/gpu_rt.py`

A fully vectorized, batched population/genome runtime, additive to (not a
replacement for) `genome_rt.py`/`evolve_rt.py`. See VEX AI 1.2's
`docs/ARCHITECTURE_MAP_1.2.md` for the full rationale and honest GPU
status (no real GPU/CUDA execution occurred in this development pass; see
that document's §2 for the `pip install torch` failure transcript).

Device dispatch: imports `torch` if available and checks
`torch.cuda.is_available()`; uses real `torch` CUDA tensors when true,
real `torch` CPU tensors when torch exists but CUDA doesn't, and NumPy
arrays when torch isn't importable (the actual, exercised path in this
sandbox). All three paths implement the same fully-vectorized algorithms
(population creation, batched target/structural fitness, batched
Generation<->Logic reasoning bonus, batched elitism+crossover+mutation) --
no per-individual or per-character Python loop in any hot-path function on
any backend.

## New VexScript builtins (hosted interpreter AND Vex IR interpreter)

`gpop_create`, `gpop_size`, `gpop_gene_len`, `gpop_generation`,
`gpop_fitness_target`, `gpop_fitness_structural`, `gpop_reasoning_bonus`,
`gpop_upper_count_at`, `gpop_advance`, `gpop_best_index`,
`gpop_best_fitness`, `gpop_avg_fitness_milli`, `gpop_best_string`,
`gpop_backend_code`.

- `src/vexscript/interpreter.py`: builtin dict entries + handler methods,
  delegating to `gpu_rt.py`.
- `src/vexscript/ir/interpreter.py`: a `gpop_*`-prefixed dispatch block
  (same pattern as the existing `genome_*`/`stream_*`/accel dispatch),
  delegating to the same `gpu_rt.py` functions, so `vexc run` (the
  compiled pipeline) can execute VEX AI 1.2 code, not just the hosted
  interpreter. Verified byte-identical output between the two paths on
  `vex_ai_1_2.vex`'s full Input-Only driver.

No existing builtin's signature or behavior changed. No version numbers
bumped (additive runtime + builtins, not a contract change).

## Regression status after this pass

- Pre-existing 27-test suite (`scripts/run_tests.py`): 27/27, unchanged.
- Pre-existing 10-test accel suite (`scripts/test_accel.py`): 10/10,
  unchanged.
- 10-test language-wave suite (`scripts/test_language_wave_1_0.py`):
  10/10, unchanged.
- VEX AI 1.0's own 36-test suite: 36/36, re-run unmodified against this
  toolchain as part of VEX AI 1.2's own test suite.
- VEX AI 1.1's own 17-test suite (which itself re-runs 1.0's suite):
  17/17, re-run unmodified.
- VEX AI 1.2's own 16-test suite: 16/16.
