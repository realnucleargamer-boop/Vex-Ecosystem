#!/usr/bin/env bash
# Vex OS - scripts/smp-test.sh
#
# Non-interactive QEMU/OVMF boot harness for SMP testing.
#
# Boots build/vexos.img headless with N virtual CPUs, captures serial
# output to a log file, and terminates after a timeout. Used to produce
# the reproducible evidence in docs/BOOT-02C.md.
#
#   ./scripts/smp-test.sh <ncpus> [timeout_seconds] [logfile] [run_label]
#
# Exit status is the QEMU exit status, EXCEPT that a timeout kill is
# reported as 124 (from `timeout`) and is NOT treated as failure by the
# caller - the kernel deliberately ends in an infinite hlt loop, so a
# timeout is the normal end of a successful run. Judge success by the
# LOG CONTENTS, never by the exit code.

set -uo pipefail

NCPU="${1:-4}"
TIMEOUT="${2:-40}"
LOG="${3:-build/smp-$NCPU.log}"
LABEL="${4:-}"

IMG="build/vexos.img"
OVMF_DIR="${OVMF_DIR:-/usr/share/OVMF}"
OVMF_CODE="${OVMF_CODE:-$OVMF_DIR/OVMF_CODE_4M.fd}"
OVMF_VARS_SRC="${OVMF_VARS:-$OVMF_DIR/OVMF_VARS_4M.fd}"

if [ ! -f "$IMG" ]; then
    echo "error: $IMG not found - run 'make image' first" >&2
    exit 2
fi
if [ ! -f "$OVMF_CODE" ] || [ ! -f "$OVMF_VARS_SRC" ]; then
    echo "error: OVMF firmware not found under $OVMF_DIR" >&2
    exit 2
fi

mkdir -p "$(dirname "$LOG")"

# Each run gets its own NVRAM copy. A shared VARS file lets one run's
# NVRAM writes change the next run's boot behavior, which would make
# "repeat the same configuration" a meaningless test.
VARS_LOCAL="$(mktemp "build/OVMF_VARS.smp$NCPU.XXXXXX.fd")"
cp "$OVMF_VARS_SRC" "$VARS_LOCAL"

# QEMU is run in the BACKGROUND and the log is polled for a completion
# sentinel, rather than simply waiting out the whole timeout. The kernel
# deliberately ends in an infinite hlt loop and never exits, so a plain
# `timeout` always burns the full duration - which made a repeated
# matrix run take far longer than the boots themselves. Polling turns
# the timeout back into what it should be: an upper bound for a hang,
# not the cost of every successful run.
: > "$LOG"

qemu-system-x86_64 \
    -machine q35,accel=tcg \
    -cpu qemu64 \
    -smp "$NCPU" \
    -m 512M \
    -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" \
    -drive if=pflash,format=raw,file="$VARS_LOCAL" \
    -drive format=raw,file="$IMG" \
    -serial "file:$LOG" \
    -display none \
    -no-reboot \
    > /dev/null 2>&1 &
qemu_pid=$!

rc=0
deadline=$(( $(date +%s) + TIMEOUT ))
while :; do
    if ! kill -0 "$qemu_pid" 2>/dev/null; then
        wait "$qemu_pid"; rc=$?
        break
    fi
    # SYSTEM READY is the kernel's last line before it parks forever.
    if grep -q "SYSTEM READY" "$LOG" 2>/dev/null; then
        # Give the port a moment to flush anything already queued.
        sleep 0.3
        kill "$qemu_pid" 2>/dev/null
        wait "$qemu_pid" 2>/dev/null
        rc=0
        break
    fi
    if [ "$(date +%s)" -ge "$deadline" ]; then
        kill -9 "$qemu_pid" 2>/dev/null
        wait "$qemu_pid" 2>/dev/null
        rc=124            # timed out - treat as a hang, i.e. a failure
        break
    fi
    sleep 0.25
done

rm -f "$VARS_LOCAL"

if [ -n "$LABEL" ]; then
    echo "--- $LABEL (-smp $NCPU, qemu rc=$rc) ---"
fi
exit $rc
