/*
 * Vex OS - kernel/include/vfs_cmds.h
 *
 * Verminal `v. testpath` and `v. content`: read-only inspection of the RAM filesystem on behalf of the signed-in user.
 * Pure logic over vfs.h (no UI, no allocation); output goes through a caller-supplied line sink so the same code is
 * compiled natively by tests/vfs_cmds_host_test.py.  Permission policy = vfs_can_read(): a non-administrator learns
 * NOTHING about another user's home (existing or not look identical).
 */
#ifndef VEXOS_VFS_CMDS_H
#define VEXOS_VFS_CMDS_H
#include <stdint.h>

#define VFSC_MAX_LINES 120      /* hard cap on lines one command may emit (the terminal scrollback is 200) */
#define VFSC_MAX_FILES 32       /* files expanded by one `v. content <folder>` */

typedef void (*VfscOut)(const char *line);

/* Returns 1 if the path exists AND the user may read it (prints "TRUE: ..."), else 0 (prints "FALSE: ..."). */
int vfs_cmd_testpath(const char *arg, uint32_t uid, int admin, const char *home_id, VfscOut out);
/* Prints a file's text, or the text of every readable FILE directly inside a folder (not recursive). Returns lines printed, or -1 on error. */
int vfs_cmd_content(const char *arg, uint32_t uid, int admin, const char *home_id, VfscOut out);

#endif
