#!/usr/bin/env python3
"""VexScript 2.0 Phase D — hosted vex::* API stubs"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vexscript.interpreter import Interpreter
from vexscript.errors import VexError
from vexscript.hosted import reset_hosted_state, HOSTED_BUILTINS
from vexscript.compile_ir import compile_to_ir, run_via_ir

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

def run(src):
    reset_hosted_state()
    i = Interpreter()
    i.load(src, "<t>")
    code = i.run_main()
    return code, i.output

print("VexScript 2.0 Phase D Tests")

print("\n=== info ===")
c, o = run("""
import vex::info;
fn main() -> i32 {
    println(vex::info::os_name());
    println(vex::info::version());
    println(vex::info::api_version());
    return 0;
}
""")
check("info values", c == 0 and o == ["Vex OS", "hosted", "0.1"], o)

print("\n=== time / proc / thread / input ===")
c, o = run("""
import vex::time;
import vex::proc;
import vex::thread;
import vex::input;
fn main() -> i32 {
    let t: i64 = vex::time::now();
    println(t);
    println(vex::proc::get_id());
    println(vex::thread::current());
    println(vex::input::poll());
    return 0;
}
""")
check("time/proc/thread/input", c == 0 and len(o) == 4 and o[1] == "1" and o[3] == "0", o)

print("\n=== fs sandbox ===")
c, o = run("""
import vex::fs;
fn main() -> i32 {
    let h: i64 = vex::fs::open("note.txt", "w");
    vex::fs::write(h, "hi");
    vex::fs::close(h);
    let r: i64 = vex::fs::open("note.txt", "r");
    println(vex::fs::read(r));
    vex::fs::close(r);
    return 0;
}
""")
check("vfs read/write", c == 0 and o == ["hi"], o)

print("\n=== missing API ===")
try:
    run("import vex::nope;\nfn main() -> i32 { return 0; }\n")
    check("missing namespace", False)
except VexError as e:
    check("missing namespace", "E0001" in str(e), str(e))

try:
    run("import vex::info;\nfn main() -> i32 { vex::info::missing(); return 0; }\n")
    check("missing symbol", False)
except VexError as e:
    check("missing symbol", True, str(e))

print("\n=== IR path (i64 APIs) ===")
try:
    code, out = run_via_ir("""
import vex::proc;
fn main() -> i32 {
    println(vex::proc::get_id());
    return 0;
}
""")
    check("IR hosted call", code == 0 and "1" in out, out)
except Exception as e:
    check("IR hosted call", False, str(e))

print("\n=== example file ===")
src = (ROOT / "examples/v2/hosted_api.vex").read_text()
c, o = run(src)
check("hosted_api.vex", c == 0 and "Vex OS" in o, o)

print(f"\n=== Phase D Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
