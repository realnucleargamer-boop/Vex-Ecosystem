#!/usr/bin/env python3
"""VexScript 3.0-E — checkpoint, best index, generation step"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vexscript import __version__, __ir_version__
from vexscript.interpreter import Interpreter
from vexscript.compile_ir import run_via_ir
from vexscript.evolve_rt import (
    reset_evolve_state, evolve_create, evolve_randomize, evolve_checkpoint_save,
    evolve_checkpoint_load, evolve_checkpoint_exists, evolve_get, evolve_size,
    evolve_best_index, evolve_generation,
)

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

print("VexScript 3.0-E")
check("version", __version__.startswith("3."), __version__)
check("ir", __ir_version__ == "1.5", __ir_version__)

state = [42]
def rng():
    state[0] = (state[0] + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
    z = state[0]
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9 & 0xFFFFFFFFFFFFFFFF
    z = (z ^ (z >> 27)) * 0x94D049BB133111EB & 0xFFFFFFFFFFFFFFFF
    return z ^ (z >> 31)

reset_evolve_state()
pid = evolve_create(3, 4)
evolve_randomize(pid, rng)
evolve_checkpoint_save(pid, "gen0")
check("ckpt exists", evolve_checkpoint_exists("gen0") == 1)
pid2 = evolve_checkpoint_load("gen0")
check("load size", evolve_size(pid2) == 3)
a, b = evolve_get(pid, 0), evolve_get(pid2, 0)
check("roundtrip data", a.data == b.data, (a.data, b.data))
check("best", evolve_best_index([1, 8, 3, 2]) == 1)
evolve_generation(pid, 1, rng, 200)
check("gen size", evolve_size(pid) == 3)

src = '''
fn main() -> i32 {
    rng_seed(7);
    let pop = evolve_create(4, 4);
    evolve_randomize(pop);
    evolve_checkpoint_save(pop, "snap");
    println(evolve_checkpoint_exists("snap"));
    let pop2 = evolve_checkpoint_load("snap");
    println(evolve_size(pop2));
    let elite = evolve_best_index(1, 9, 3, 2);
    println(elite);
    evolve_generation(pop, elite, 250);
    println(evolve_size(pop));
    return 0;
}
'''
i = Interpreter(); i.load(src, "t"); c = i.run_main(); o1 = list(i.output)
j = Interpreter(); j.load(src, "t"); j.run_main(); o2 = list(j.output)
check("ast e", c == 0 and str(o1[0]) in ("1", "1.0") and str(o1[1]) in ("4", "4.0"), o1)
check("ast det", o1 == o2, (o1, o2))
code, out = run_via_ir(src)
check("ir e", code == 0 and "1" in out and "4" in out, out)
code2, out2 = run_via_ir(src)
check("ir det", out == out2)

# D compat
src_d = '''
fn main() -> i32 {
    rng_seed(1);
    let p = evolve_create(2, 2);
    println(evolve_size(p));
    return 0;
}
'''
code, out = run_via_ir(src_d)
check("compat D", code == 0 and "2" in out, out)

print(f"\n=== 3.0-E Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
