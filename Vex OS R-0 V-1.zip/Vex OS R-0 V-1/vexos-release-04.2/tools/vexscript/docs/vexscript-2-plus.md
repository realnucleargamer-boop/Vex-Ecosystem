# VexScript 2+

Next generation after 2.0.0. **Not** VexScript 3.0.

## Phase A (implemented)
- `type Alias = T;` with resolution and cycle detection
- `enum Name { A, B, C }` — C-like, discriminant = index
- Variants: `Name::A` as typed values (type `Name`, runtime i64)
- IR lowering of enum variants to `const.i64`
- No implicit numeric conversions beyond existing integer_literal rules

## Not yet (later 2+ phases)
- match / pattern matching
- generic Result/Option
- borrow checker
- std:: modules as real packages

## Phase B (implemented)
- `match (expr) { Pattern => { ... } }`
- Patterns: `Enum::Variant`, integer literals, `_` wildcard
- Non-exhaustive enum matches are **errors** unless `_` is present
- Fat arrow `=>` (also accepts `->`)
- Parentheses required around scrutinee (`match (x) { ... }`) to avoid struct-literal ambiguity
- IR: match lowers to compare + branch chain
- **Non-generic Result foundation:** use `enum ResultCode { Ok, Err }` + `match` (no generics yet; existing `ok`/`err` builtins remain)

## Phase C (implemented)
- Pointer **type annotations**: `*T`, `*mut T` (provisional; integer 0 allowed as null/address placeholder)
- Automatic search of package `stdlib/` on the module path
- Portable modules:
  - `import math;` → `stdlib/math.vex` (`abs`, `min`, `max`, `clamp`)
  - `import std::math;` → `stdlib/std/math.vex`
  - `import result;` → `ResultCode` + `is_ok_code`
- Memory model documented in `docs/vexscript-memory-model.md`
- **Not** implemented: pointer dereference, address-of, allocator, GC, borrow checker

## Phase D (implemented)
- IR **constant folding** for arithmetic and comparisons on known constants
- **Unreachable block** elimination after CFG analysis
- Diagnostics: source line + caret under `VexError.format()` when source is available
- Optimize runs after IR validation on `compile_to_ir` / native path

## 2.1.1 — VEX-AI compiler foundation

### Fixed
- IR interpreter typed values: `i64` | `bool` | `string` | struct maps (no more `int(string)`)
- `const.string` with payload preserved
- `make_struct` / `extract` for mixed field types
- Call return types include `string` and struct names
- String `==` / `!=` in IR interpreter
- Builtins `concat`, `len_string` on IR path

### Not yet (later)
- Growable arrays / message history vectors
- Full native x86-64 string beyond existing cstr path
- Generic collections
