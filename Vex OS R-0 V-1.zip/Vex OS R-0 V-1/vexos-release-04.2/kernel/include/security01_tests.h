/*
 * Vex OS - kernel/include/security01_tests.h
 *
 * SECURITY-01 in-kernel self-tests.
 *
 * WHAT THESE TESTS ARE ENTITLED TO CLAIM
 *
 *   This milestone was specified against a USER-01 Ring 3 baseline that
 *   does not exist in this repository. There is no user mode, no syscall
 *   entry, no user process, and no user page tables. A very large part
 *   of the original brief - user pointer validation on syscall entry,
 *   SMEP/SMAP enforcement against user code, user W^X, fatal user faults
 *   killing a process - cannot be tested here, because there is nothing
 *   at CPL 3 to test it against.
 *
 *   The response to that is NOT to print PASS for those items. Every one
 *   of them is printed as an explicit
 *
 *       [test] SEC-NA: n/a  - <item> (NOT APPLICABLE - NO USERSPACE)
 *
 *   line, which is counted separately and never counts toward the
 *   passing tally. A reader of the log can therefore see exactly how
 *   much of the security surface is actually under test and how much is
 *   merely absent. That distinction is the single most important thing
 *   this file communicates.
 *
 *   What IS tested is tested for real:
 *
 *     SEC-PTR   the range validator, against hostile inputs - overflow,
 *               non-canonical, hole-straddling, out-of-window, and
 *               cross-page ranges whose second page is bad. Includes
 *               positive controls so that "rejects everything" cannot
 *               masquerade as correctness.
 *     SEC-PERM  the USER-bit invariant and W^X, asserted against the
 *               LIVE page tables by walking them, not against the
 *               intentions of the code that built them.
 *     SEC-CPU   real CPUID and CR4/EFER state for NX, SMEP, SMAP, UMIP,
 *               and WP. Reported as observed, with no feature enabled
 *               blindly.
 *     SEC-FAULT negative controls in which the CPU itself refuses an
 *               access: a read of an unmapped page, a write to a
 *               read-only page, an execute of an NX page, and a touch of
 *               a non-canonical address. Each asserts on the vector and
 *               error code the hardware reported. Nothing is repaired -
 *               a denied access stays denied.
 *     SEC-ISO   descriptor-table privilege state: kernel selectors at
 *               DPL 0, TSS descriptors at DPL 0, and rsp0 left zero
 *               because no ring transition exists to use it.
 *
 * ORDERING. As with KERNEL-01, this runs and prints before
 * boot03_print_summary(), because scripts/smp-test.sh terminates QEMU
 * shortly after "SYSTEM READY" and evidence printed after that line can
 * be truncated away.
 *
 * This suite deliberately does NOT print "SECURITY-01 COMPLETE", and the
 * kernel must not print it either. The milestone as specified is not
 * complete; a subset of it is implemented and tested.
 */

#ifndef VEXOS_SECURITY01_TESTS_H
#define VEXOS_SECURITY01_TESTS_H

#include <stdint.h>

typedef struct {
    int ptr;        /* SEC-PTR   range validation */
    int perm;       /* SEC-PERM  USER bit and W^X in the live tables */
    int cpu;        /* SEC-CPU   CPU security feature state */
    int fault;      /* SEC-FAULT CPU-generated denial of bad accesses */
    int iso;        /* SEC-ISO   descriptor privilege state */

    uint32_t checks_run;
    uint32_t checks_failed;
    uint32_t not_applicable;   /* Ring-3 items with no userspace to test */
} Security01Results;

void security01_run_tests(Security01Results *out);
void security01_print_summary(const Security01Results *r);
int  security01_all_passed(const Security01Results *r);

#endif /* VEXOS_SECURITY01_TESTS_H */
