#ifndef VEXOS_PS2_KEYBOARD_H
#define VEXOS_PS2_KEYBOARD_H
#include <stdint.h>
/* Polled PS/2 set-1 keyboard frontend for QEMU.  It publishes INPUT-02 events. */
int ps2_keyboard_init(void);
void ps2_keyboard_poll(void);
uint64_t ps2_keyboard_events(void);
#endif
