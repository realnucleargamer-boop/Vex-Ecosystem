; Vex OS - kernel/src/arch/x86_64/cpu/context_switch.asm
;
; BOOT-03 cooperative kernel context switch.
;
;   void context_switch(KernelContext *from, KernelContext *to);
;
; System V AMD64 ABI: from = RDI, to = RSI.
;
; KernelContext.rsp is at offset 0. A _Static_assert in
; kernel/include/context.h enforces that, because nothing else can: the
; assembler has no view of the C struct, so this is a hand-maintained
; contract of exactly the kind that broke silently elsewhere in this
; project (see the trampoline offset contract in kernel/include/smp.h).
;
; PUSH ORDER IS PART OF THE CONTRACT. context_create in context.c builds
; a synthetic stack image that this code pops from. The two must agree:
;
;   low  address -> RFLAGS, R15, R14, R13, R12, RBX, RBP, ret-target ...
;   high address
;
; If you add a register here, add it there.

bits 64

global context_switch
global context_trampoline

extern context_entry_returned

section .text

context_switch:
    ; Save the callee-saved set plus RFLAGS on the OUTGOING stack.
    ; Caller-saved registers are intentionally not saved - the ABI
    ; already permits any call to clobber them.
    push    rbp
    push    rbx
    push    r12
    push    r13
    push    r14
    push    r15
    pushfq

    ; Publish the outgoing stack pointer, then adopt the incoming one.
    ; Between these two instructions this CPU is momentarily running on
    ; a stack that two contexts both believe they own; nothing may
    ; interrupt and touch the stack in that window. Timer interrupts do
    ; not touch either context's saved state, so the window is safe as
    ; written - but it is the reason the switch is not made
    ; interrupt-reentrant.
    mov     [rdi], rsp
    mov     rsp, [rsi]

    ; Restore in exact reverse order.
    popfq
    pop     r15
    pop     r14
    pop     r13
    pop     r12
    pop     rbx
    pop     rbp

    ; For a context that has run before, this returns into its previous
    ; call to context_switch. For a freshly created context, this jumps
    ; to context_trampoline, because context_create placed that address
    ; exactly where a return address would be.
    ret

; ------------------------------------------------------------------ ;
; context_trampoline
;
; First-time entry point for a new context.
;
; WHY A TRAMPOLINE IS NEEDED: the entry function's argument belongs in
; RDI, but RDI is caller-saved and therefore is NOT part of the register
; set context_switch restores. A freshly created context cannot simply
; `ret` straight into entry(arg) and expect RDI to hold anything.
;
; So context_create smuggles the argument and the entry address through
; two registers that ARE restored - R12 (arg) and R13 (entry) - and this
; trampoline moves them into place. Using the callee-saved set as the
; carrier is what makes the handoff work with no extra state in the
; struct.
; ------------------------------------------------------------------ ;
context_trampoline:
    ; Entry here happens via `ret`, so RSP is congruent to 8 mod 16 -
    ; the same state a function sees immediately after a `call`. This
    ; push both establishes a frame and restores 16-byte alignment for
    ; the call below, which the System V AMD64 ABI requires at the call
    ; site. Getting this wrong shows up only when the callee uses an
    ; aligned SSE spill, i.e. rarely and confusingly.
    push    rbp
    mov     rbp, rsp

    mov     rdi, r12            ; arg
    call    r13                 ; entry(arg)

    ; A context entry function has no caller to return to. If it returns
    ; anyway, say so loudly rather than executing whatever quadword sits
    ; above the stack.
    call    context_entry_returned

.hang:
    cli
    hlt
    jmp     .hang
