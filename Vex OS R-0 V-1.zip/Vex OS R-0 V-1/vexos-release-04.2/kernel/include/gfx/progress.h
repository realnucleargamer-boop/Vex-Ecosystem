/*
 * Vex OS - kernel/include/gfx/progress.h
 *
 * Graphics 2: the graphical boot splash + loading bar.
 *
 * This is the renderer half of the "Boot subsystem -> BootProgress state
 * -> Graphics 2 renderer" pipeline (see boot_progress.h). It depends on
 * gfx/fb.h, gfx/draw.h, gfx/text.h, and BootProgress - nothing else. It
 * has no knowledge of ACPI, paging, SMP, or any other boot internal; it
 * only ever sees the (stage, percent, message) triple it is handed.
 *
 * Two entry points, matching the "draw once, update cheaply" rule in
 * the brief (no full-screen redraw per update):
 *
 *   gfx_boot_splash_init()   - draws the static chrome exactly once
 *                               (title, subtitle, bar outline/background).
 *   gfx_boot_splash_render() - called on every boot_progress_set(); only
 *                               repaints the message line and the bar's
 *                               fill region, never the whole screen.
 *
 * gfx_boot_splash_render() matches BootProgressRenderFn's signature
 * exactly, so kernel_entry.c can pass it straight to
 * boot_progress_attach_renderer() with no wrapper.
 */

#ifndef VEXOS_GFX_PROGRESS_H
#define VEXOS_GFX_PROGRESS_H

#include "gfx/fb.h"
#include "boot_progress.h"

/* Draws the static splash chrome (title, subtitle, bar outline) into
 * *fb. Call once, after gfx_fb_init() succeeds and before the first
 * boot_progress_set(). Safe to call with fb->ok == 0 (no-op). */
void gfx_boot_splash_init(const GfxFb *fb);

/* Repaints only the message line and the bar's fill region to match
 * *state. Matches BootProgressRenderFn. Safe to call with a NULL *fb
 * internally bound (it no-ops) - see gfx_progress.c; callers normally
 * reach this only via boot_progress_attach_renderer(), never directly. */
void gfx_boot_splash_render(const BootProgress *state);

/* Binds the GfxFb this renderer draws into. Must be called before
 * attaching gfx_boot_splash_render as the active renderer. Exists
 * because BootProgressRenderFn's signature (by design) carries no
 * gfx/fb.h type - see boot_progress.h's decoupling rationale. */
void gfx_boot_splash_bind(const GfxFb *fb);

#endif /* VEXOS_GFX_PROGRESS_H */
