# VexScript 2.0 Phase E — Native x86-64 Backend

## Pipeline
```
VexScript → IR → validate → x86-64 AT&T asm → gcc/as + vex_rt.c → host executable
```

## ABI (temporary hosted)
System V AMD64: args in rdi,rsi,rdx,rcx,r8,r9; return in rax; 16-byte stack alignment.

**Not** the Vex OS syscall ABI.

## Runtime
`src/runtime/vex_rt.c`: `vex_rt_print_i64`, `vex_rt_println_i64` only.

## CLI
- `vexc emit-asm` — print assembly
- `vexc run-native` — compile and run host binary
- `vexc build --target x86_64` — write IR + native binary under `build/`
- `vexc run` still uses **IR interpreter** (unchanged)

## Unsupported in native
- `vex::*` hosted APIs (E0502)
- Full string printing beyond integer println
