#!/usr/bin/env python3
"""Vex OS - scripts/release_e2e.py : end-to-end checks of the release features through REAL PS/2 input in QEMU:
password first-run, password sign-in (wrong/right), two independent accounts, admin-only Add user, permission
enforcement, File Explorer file creation, Task Manager, volatility on reboot, and the release image size.
  python3 scripts/release_e2e.py build/vexos.img build/vexos-seed.img"""
import os, re, sys, time
sys.path.insert(0, os.path.dirname(__file__))
from qemu_drive import Vm, load_ppm, ppm_to_png
IMG = sys.argv[1] if len(sys.argv) > 1 else "build/vexos.img"; SEED = sys.argv[2] if len(sys.argv) > 2 else "build/vexos-seed.img"
OUT = os.environ.get("E2E_OUT", "build/release-e2e"); os.makedirs(OUT, exist_ok=True); res = []
def check(ok, what, d=""): res.append(bool(ok)); print(("PASS  " if ok else "FAIL  ") + what + (f"  [{d}]" if d and not ok else ""), flush=True); return ok
def cnt(vm, p): return len(re.findall(p, vm.serial()))
def rects(vm, tag):
    ls = [l for l in vm.serial().splitlines() if tag in l]
    return {m.group(1): tuple(map(int, m.groups()[1:])) for m in re.finditer(r"(\w+)=\((\d+),(\d+),(\d+),(\d+)\)", ls[-1])} if ls else {}
def mr(vm, dx, dy):
    while dx or dy:
        sx = max(-100, min(100, dx)); sy = max(-100, min(100, dy)); vm.mouse_move(sx, sy); dx -= sx; dy -= sy; time.sleep(0.03)
    time.sleep(0.35)
def click(vm, r): mr(vm, -1500, -1000); mr(vm, r[0] + r[2] // 2, r[1] + r[3] // 2); vm.mouse_button(1); time.sleep(0.25); vm.mouse_button(0); time.sleep(0.7)
K = {"/": "slash", " ": "spc", ".": "dot", "-": "minus", "\n": "ret", "\t": "tab"}
def typ(vm, s, g=0.11):
    for c in s: vm.sendkey(K.get(c) or ("shift-" + c.lower() if c.isupper() else c)); time.sleep(g)
    time.sleep(0.4)
def shot(vm, n):
    p = f"{OUT}/{n}.ppm"; vm.screendump(p); ppm_to_png(p, f"{OUT}/{n}.png")
def boot(img, tag, pat, **kw):
    vm = Vm(img, OUT, tag=tag, **kw); ok = vm.wait_serial(pat, 150); time.sleep(1.0); return vm, ok

print("=== A. First-run with password, sign-in, Task Manager, File Explorer ===")
size = os.path.getsize(IMG); check(size < 15 * 1048576, f"release image is {size} bytes ({size/1048576:.2f} MiB) < 15 MiB (15728640)")
vm, ok = boot(IMG, "A", r"\[ui\] setup screen shown"); L = vm.serial()
check(ok and "SYSTEM READY" in L and "108/108 SECURITY-02" in L and "VEX KERNEL PANIC" not in L, "boots to first-run; SYSTEM READY; SECURITY-02 108/108")
check(re.search(r"(\d+)/\1 DESKTOP-01", L) and re.search(r"(\d+)/\1 INPUT-03", L), "DESKTOP-01 and INPUT-03 logic suites all passed at boot")
R = rects(vm, "setup screen shown"); shot(vm, "01_setup")
click(vm, R["name"]); typ(vm, "Vex\n"); time.sleep(0.5)
check(cnt(vm, r"rejected: Password must be at least 6") == 1, "no password -> rejected (a password is mandatory)")
vm.sendkey("tab"); typ(vm, "vexpass1"); vm.sendkey("tab"); typ(vm, "different1\n"); time.sleep(0.5)
check(cnt(vm, r"rejected: passwords do not match") == 1, "mismatched confirmation rejected")
for _ in range(10): vm.sendkey("backspace")
typ(vm, "vexpass1\n"); time.sleep(1.5)
check(cnt(vm, r"account created: Vex \(administrator\)") == 1 and "[ui] lock screen shown" in vm.serial(), "valid name + matching password -> administrator account created, lock screen shown")
check("vexpass1" not in vm.serial(), "the password never appears in the serial/diagnostic log")
R = rects(vm, "lock screen shown"); check("pass" in R, "lock screen shows a password field"); shot(vm, "02_lock_password")
typ(vm, "wrongpass\n"); time.sleep(0.6)
check(cnt(vm, r"sign-in REJECTED for Vex") == 1 and "signed in as" not in vm.serial(), "incorrect password REJECTED: stays on the lock screen"); shot(vm, "03_lock_rejected")
typ(vm, "vexpass1\n"); time.sleep(1.2)
check(cnt(vm, r"signed in as Vex \(via ENTER\)") == 1, "correct password signs in"); D = rects(vm, "desktop shown"); shot(vm, "04_desktop")
check({"vbtn", "search", "term", "expl", "task"} <= set(D), "desktop shows V, search, Terminal, File Explorer and Task Manager entries")
click(vm, D["task"]); time.sleep(3.2); shot(vm, "05_taskmgr")
check(cnt(vm, r"Task Manager launched") == 1, "Task Manager opens from the desktop")
vm.sendkey("esc"); time.sleep(0.6); check("Task Manager closed" in vm.serial(), "Task Manager closes")
click(vm, D["expl"]); time.sleep(0.6); check("File Explorer launched" in vm.serial(), "File Explorer opens (home folder)")
vm.sendkey("n"); time.sleep(0.4); typ(vm, "hello.txt\n"); time.sleep(0.6); shot(vm, "06_explorer_created")
check(cnt(vm, r"explorer: created file /home/vex/hello\.txt") == 1, "New File creates /home/vex/hello.txt through the filesystem")
vm.sendkey("n"); time.sleep(0.4); typ(vm, "hello.txt\n"); time.sleep(0.5)
check(cnt(vm, r"create rejected: A file or folder with that name already exists") == 1, "creating the same name again is refused (no overwrite)")
for _ in range(9): vm.sendkey("backspace")
typ(vm, "bad/name\n"); time.sleep(0.4); check(cnt(vm, r"create rejected: Invalid file name") == 1, "invalid file name rejected"); vm.sendkey("esc")
vm.sendkey("backspace"); time.sleep(0.5); vm.sendkey("h"); time.sleep(0.5); shot(vm, "07_explorer_back_home")
check(cnt(vm, r"explorer: /home\r?\n") >= 1 and cnt(vm, r"explorer: /home/vex\r?\n") >= 1, "navigate Up to /home and Home back to /home/vex (file still listed - see screenshot)")
vm.stop()

print("\n=== B. Two accounts, independent passwords, permissions, admin-only Add user ===")
vm, ok = boot(SEED, "B", r"\[ui\] lock screen shown"); L = rects(vm, "lock screen shown")
check(ok and "VEX_DEV_SEED_ACCOUNTS" in vm.serial(), "seeded build (3 TEST accounts: Vex admin, Nexus, Bob) reaches the lock screen")
typ(vm, "nexuspw1\n"); time.sleep(0.8); check(cnt(vm, r"sign-in REJECTED for Vex") == 1, "Nexus's password does not sign in as Vex")
click(vm, L["users"]); U = rects(vm, "users panel opened"); shot(vm, "08_users"); click(vm, U["item1"])
check("selected account Nexus" in vm.serial(), "Users panel switches the selected account to Nexus (not authenticated yet)")
typ(vm, "vexpass1\n"); time.sleep(0.8); check(cnt(vm, r"sign-in REJECTED for Nexus") == 1, "Vex's password does not sign in as Nexus")
typ(vm, "nexuspw1\n"); time.sleep(1.2); check(cnt(vm, r"signed in as Nexus") == 1, "Nexus signs in with Nexus's own password")
D = rects(vm, "desktop shown"); click(vm, D["vbtn"]); V = rects(vm, "V menu opened")
check("item7" in V and "item8" not in V, "standard user's V menu has no Add user entry"); vm.sendkey("esc"); time.sleep(0.5)
click(vm, D["expl"]); time.sleep(0.5); vm.sendkey("backspace"); time.sleep(0.5); vm.sendkey("n"); time.sleep(0.4); typ(vm, "x.txt\n"); time.sleep(0.5)
check(cnt(vm, r"create rejected: Permission denied") == 1, "Nexus (standard) cannot create a file in /home: permission enforced"); shot(vm, "09_permission_denied")
vm.sendkey("esc"); vm.sendkey("esc"); time.sleep(0.5)
click(vm, D["vbtn"]); V = rects(vm, "V menu opened"); click(vm, V["item5"]); time.sleep(0.8)
check("session locked (via V menu)" in vm.serial(), "Lock returns to the lock screen")
L = rects(vm, "lock screen shown"); click(vm, L["users"]); U = rects(vm, "users panel opened"); click(vm, U["item0"])
typ(vm, "vexpass1\n"); time.sleep(1.2); check(cnt(vm, r"signed in as Vex") == 1, "switching back: Vex signs in with Vex's password")
D = rects(vm, "desktop shown"); click(vm, D["vbtn"]); V = rects(vm, "V menu opened"); check("item8" in V, "administrator's V menu offers Add user")
click(vm, V["item8"]); time.sleep(0.6); shot(vm, "10_add_user")
typ(vm, "Carol\n"); typ(vm, ""); vm.sendkey("tab"); typ(vm, "carol789"); vm.sendkey("tab"); typ(vm, "carol789\n"); time.sleep(1.0)
check(cnt(vm, r"account created: Carol \(standard user\)") == 1, "admin creates a third account (Carol, standard user) with her own password")
click(vm, D["vbtn"]); V = rects(vm, "V menu opened"); click(vm, V["item5"]); time.sleep(0.8)
L = rects(vm, "lock screen shown"); click(vm, L["users"]); U = rects(vm, "users panel opened")
check("item3" in U and "item4" in U and "item5" not in U, "Users panel now lists 4 real accounts + Close"); shot(vm, "11_users_4")
check("vexpass1" not in vm.serial() and "nexuspw1" not in vm.serial() and "carol789" not in vm.serial(), "no password appears in the diagnostic log")
check(vm.alive() and "VEX KERNEL PANIC" not in vm.serial() and "UNHANDLED CPU EXCEPTION" not in vm.serial(), "no panic after the whole session")
vm.stop()

print("\n=== C. Volatility (honest persistence check) ===")
vm, ok = boot(IMG, "C", r"\[ui\] setup screen shown", allow_reboot=True); R = rects(vm, "setup screen shown")
click(vm, R["name"]); typ(vm, "Vex\n"); vm.sendkey("tab"); typ(vm, "vexpass1"); vm.sendkey("tab"); typ(vm, "vexpass1\n"); time.sleep(1.5)
L = rects(vm, "lock screen shown"); click(vm, L["power"]); P = rects(vm, "power menu opened"); click(vm, P["item1"]); t0 = time.time(); ok2 = False
while time.time() - t0 < 120:
    if cnt(vm, r"\[ui\] setup screen shown") >= 2: ok2 = True; break
    time.sleep(0.5)
check(ok2, "after a real reboot the account is gone and first-run returns: accounts/files are NOT persistent (documented)")
vm.stop()
print(f"\n{sum(res)}/{len(res)} release end-to-end checks passed"); sys.exit(0 if all(res) else 1)
