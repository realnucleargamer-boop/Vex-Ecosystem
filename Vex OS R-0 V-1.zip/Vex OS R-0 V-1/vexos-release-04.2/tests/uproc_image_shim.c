/* Host-only shim for kernel/src/proc/uproc_image.c (ctypes). NOT part of the kernel build. */
#include "uproc.h"
int shim_validate(const uint8_t *img, size_t len, uint32_t *o)   /* o[9]: entry,text_off,text_size,data_off,data_size,bss,stack,text_pages,data_pages */
{
    UprocLayout L; UprocStatus s = uproc_image_validate(img, len, &L);
    if (s == UPROC_OK) { o[0]=L.entry; o[1]=L.text_off; o[2]=L.text_size; o[3]=L.data_off; o[4]=L.data_size; o[5]=L.bss_size; o[6]=L.stack_pages; o[7]=L.text_pages; o[8]=L.data_pages; }
    return (int)s;
}
