#include "vexterm_host.h"
#include "apps.h"
#include "timer.h"

/* entry points compiled from VexScript (apps/vex_terminal/src/main.vex) */
extern int64_t vt_init(void);
extern int64_t vt_on_key(int64_t code, int64_t ch);
extern int64_t vt_on_tick(void);

static char lines[VTH_LINES][VTH_COLS + 1];
static int cur, curcol, nlines;                 /* cur = ring index of the line being written */
static int64_t state[16];
static char bufs[2][VTH_BUF_MAX + 1]; static int blen[2];
static int open_, dirty, pdirty;
static int t_active; static uint32_t t_period_ticks; static uint64_t t_due; static uint32_t starts, stops, fires;

static void out_clear(void) { for (int i = 0; i < VTH_LINES; i++) lines[i][0] = 0; cur = 0; curcol = 0; nlines = 1; dirty = 1; }
static void newline(void) { cur = (cur + 1) % VTH_LINES; lines[cur][0] = 0; curcol = 0; if (nlines < VTH_LINES) nlines++; }
static void put(char c)
{
    if (c == '\n') { newline(); return; }
    if (c < 32 || c > 126) return;                       /* drop control / non-ASCII bytes */
    if (curcol >= VTH_COLS) newline();                   /* hard wrap */
    lines[cur][curcol++] = c; lines[cur][curcol] = 0; dirty = 1;
}
static void puts_(const char *s) { if (!s) return; for (int i = 0; s[i] && i < 4096; i++) put(s[i]); dirty = 1; }

/* ---- services the VexScript runtime calls (symbol names fixed by the native backend) ---- */
void vex_rt_print_cstr(const char *s)   { puts_(s); }
void vex_rt_println_cstr(const char *s) { puts_(s); put('\n'); }
void vex_rt_print_i64(int64_t v)
{
    char t[22]; int n = 0; uint64_t u = v < 0 ? (uint64_t)0 - (uint64_t)v : (uint64_t)v;
    do { t[n++] = (char)('0' + u % 10); u /= 10; } while (u && n < 21);
    if (v < 0) put('-');
    while (n) put(t[--n]);
}
void vex_rt_println_i64(int64_t v) { vex_rt_print_i64(v); put('\n'); }
int64_t vex_os_state_get(int64_t k) { return (k >= 0 && k < 16) ? state[k] : 0; }
int64_t vex_os_state_set(int64_t k, int64_t v) { if (k < 0 || k >= 16) return 0; state[k] = v; pdirty = 1; return 1; }
int64_t vex_os_buf_push(int64_t b, int64_t c)
{
    if (b < 0 || b > 1 || c < 32 || c > 126 || blen[b] >= VTH_BUF_MAX) return 0;
    bufs[b][blen[b]++] = (char)c; bufs[b][blen[b]] = 0; pdirty = 1; return 1;
}
int64_t vex_os_buf_pop(int64_t b) { if (b < 0 || b > 1 || !blen[b]) return 0; bufs[b][--blen[b]] = 0; pdirty = 1; return 1; }
int64_t vex_os_buf_clear(int64_t b) { if (b < 0 || b > 1) return 0; for (int i = 0; i <= VTH_BUF_MAX; i++) bufs[b][i] = 0; blen[b] = 0; pdirty = 1; return 1; }   /* full wipe: a typed password must not linger */
int64_t vex_os_buf_len(int64_t b) { return (b >= 0 && b <= 1) ? blen[b] : 0; }
const char *vex_os_buf_text(int64_t b) { return (b >= 0 && b <= 1) ? bufs[b] : ""; }
int64_t vex_os_out_clear(void) { out_clear(); return 1; }
int64_t vex_os_app_count(void) { return apps_tracked_count(); }
int64_t vex_os_app_id(int64_t i) { const AppInst *a = apps_tracked_get((int)i); return a ? (int64_t)a->inst_id : 0; }
const char *vex_os_app_name(int64_t i) { const AppInst *a = apps_tracked_get((int)i); return a ? a->name : ""; }
const char *vex_os_app_kind(int64_t i) { const AppInst *a = apps_tracked_get((int)i); return a ? a->kind : ""; }
int64_t vex_os_app_started_ms(int64_t i) { const AppInst *a = apps_tracked_get((int)i); return a ? (int64_t)a->started_ms : 0; }
int64_t vex_os_now_ms(void) { return (int64_t)apps_now_ms(); }
int64_t vex_os_timer_start(int64_t ms)
{
    if (t_active) return 0;                                            /* never a second timer */
    if (ms < VTH_TIMER_MIN_MS || ms > VTH_TIMER_MAX_MS) return 0;
    t_period_ticks = (uint32_t)((ms * TIMER_TARGET_HZ + 999) / 1000);
    t_due = timer_ticks() + t_period_ticks; t_active = 1; starts++; return 1;
}
int64_t vex_os_timer_stop(void) { int was = t_active; t_active = 0; if (was) stops++; return was; }
int64_t vex_os_timer_active(void) { return t_active; }

/* One pending command request from the app (a single slot: the app cannot queue more than one per key). */
static int req_kind; static char req_arg[VTH_ARG_MAX + 1];
int64_t vex_os_cmd(int64_t kind, const char *arg)
{
    if (kind < 1 || kind > 13 || req_kind) return 0;
    int i = 0; if (arg) for (; arg[i] && i < VTH_ARG_MAX; i++) req_arg[i] = arg[i];
    req_arg[i] = 0; req_kind = (int)kind; return 1;
}
int vth_take_request(int *kind, char *arg, int cap)
{
    if (!req_kind || !kind || !arg || cap < 1) return 0;
    int i = 0; for (; req_arg[i] && i < cap - 1; i++) arg[i] = req_arg[i]; arg[i] = 0;
    *kind = req_kind; req_kind = 0; req_arg[0] = 0; return 1;
}
void vth_print(const char *s) { puts_(s); put('\n'); }
/* ---- host API ---- */
void vth_open(void) { open_ = 1; for (int i = 0; i < 16; i++) state[i] = 0; blen[0] = blen[1] = 0; bufs[0][0] = bufs[1][0] = 0; t_active = 0; (void)vt_init(); dirty = 1; pdirty = 1; }
void vth_close(void) { req_kind = 0; req_arg[0] = 0; if (t_active) { t_active = 0; stops++; } open_ = 0; for (int i = 0; i < 16; i++) state[i] = 0; blen[0] = blen[1] = 0; bufs[0][0] = bufs[1][0] = 0; }
int vth_is_open(void) { return open_; }
int vth_key(uint16_t code, int ascii) { if (!open_) return 0; int64_t r = vt_on_key(code, ascii); return r == 2 ? 2 : (r ? 1 : 0); }
void vth_poll(void)
{
    if (!open_ || !t_active) return;
    uint64_t now = timer_ticks();
    if (now < t_due) return;
    t_due = now + t_period_ticks;            /* resync: a late poll never causes a burst of catch-up fires */
    fires++; (void)vt_on_tick();
}
int vth_take_dirty(void) { int d = dirty; dirty = 0; return d; }              /* OUTPUT area changed */
int vth_take_prompt_dirty(void) { int d = pdirty; pdirty = 0; return d; }     /* only the prompt row changed */
int vth_visible(int rows, const char **out)
{
    int n = nlines < rows ? nlines : rows;
    for (int i = 0; i < n; i++) out[i] = lines[(cur - (n - 1 - i) + VTH_LINES * 2) % VTH_LINES];
    return n;
}
int vth_view(void) { return (int)state[0]; }
const char *vth_prompt_label(void) { return state[0] == 0 ? "> " : state[0] == 2 ? "input> " : ""; }
const char *vth_prompt_text(void) { return state[0] == 0 ? bufs[0] : state[0] == 2 ? bufs[1] : ""; }
int vth_timer_active(void) { return t_active; }
uint32_t vth_timer_starts(void) { return starts; }
uint32_t vth_timer_stops(void) { return stops; }
uint32_t vth_timer_fires(void) { return fires; }
