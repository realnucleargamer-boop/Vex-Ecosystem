# VexScript 2+ Roadmap
| Phase | Scope | Status |
|-------|--------|--------|
| A | Type aliases + enums | **done** |
| B | Result/error + match | **done** |
| C | Memory + std foundation | **done** |
| D | Opts + diagnostics | **done** |
| E | Tooling | next |
