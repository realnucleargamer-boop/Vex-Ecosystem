/*
 * Vex OS - kernel/include/lapic.h
 *
 * BOOT-02B: detects and initializes the BSP's Local APIC only.
 * Reading/writing other cores' LAPICs, sending IPIs, and the whole
 * INIT-SIPI-SIPI startup sequence are BOOT-02C (SMP) work - not
 * here.
 *
 * ARCHITECTURAL ASSUMPTION (flagged): LAPIC registers are accessed
 * via MMIO at the physical address IA32_APIC_BASE reports. Like
 * acpi.c, this relies on UEFI/OVMF's post-ExitBootServices identity
 * mapping still covering that physical address, since Vex OS has no
 * page tables of its own yet.
 */

#ifndef VEXOS_LAPIC_H
#define VEXOS_LAPIC_H

#include <stdint.h>

typedef struct {
    int      supported;       /* CPUID.1:EDX.APIC (bit 9) */
    int      globally_enabled;/* IA32_APIC_BASE.EN (bit 11) */
    uint64_t physical_base;   /* from IA32_APIC_BASE, bits 12-35 */
    uint32_t id;               /* this core's LAPIC ID (register 0x20, bits 24-31) */
} LapicInfo;

/* Detects CPUID APIC support, reads IA32_APIC_BASE, verifies the
 * global enable bit, reads back this core's LAPIC ID, and sets the
 * Spurious Interrupt Vector Register's software-enable bit (with a
 * dedicated, otherwise-unused spurious vector) so the LAPIC is ready
 * for BOOT-02C's IPI use. Does NOT call `sti` and does NOT unmask
 * any interrupt source - fills `out` and returns 1 on success, 0 if
 * the CPU/firmware doesn't support what's needed. */
int lapic_init(LapicInfo *out);

/* ---------------------------------------------------------------- *
 * BOOT-02C: IPI support, needed for the INIT-SIPI-SIPI AP startup
 * sequence. These operate on the LAPIC of the CALLING CPU (the
 * Interrupt Command Register is per-CPU), so in practice they are only
 * ever called from the BSP.
 * ---------------------------------------------------------------- */

/* Reads the calling CPU's own LAPIC ID. Used by APs to verify their
 * identity against what the MADT claimed. */
uint32_t lapic_read_own_id(uint64_t physical_base);

/* Sends INIT (assert then deassert) to the target APIC ID. */
void lapic_send_init(uint64_t physical_base, uint32_t apic_id);

/* Sends a Startup IPI carrying `vector`. The AP begins execution in
 * real mode at physical address vector * 4096. */
void lapic_send_sipi(uint64_t physical_base, uint32_t apic_id,
                     uint8_t vector);

/* Waits for the last IPI to be accepted (ICR Delivery Status clear).
 * Returns 1 if it cleared, 0 if it timed out - a stuck delivery status
 * must not hang the BSP. */
int lapic_wait_ipi_idle(uint64_t physical_base);

/* ---------------------------------------------------------------- *
 * BOOT-03: raw register access and end-of-interrupt.
 *
 * The LAPIC timer lives in kernel/src/arch/x86_64/apic/lapic_timer.c.
 * Rather than duplicate the MMIO accessors there (two copies of the
 * same volatile cast is how one of them ends up non-volatile), lapic.c
 * exposes them. They are deliberately raw: no register-name validation,
 * because the timer code needs registers this file does not know about.
 *
 * All LAPIC MMIO is 32-bit aligned accesses only; a 64-bit access to a
 * LAPIC register is undefined.
 * ---------------------------------------------------------------- */
uint32_t lapic_reg_read(uint64_t physical_base, uint32_t reg);
void     lapic_reg_write(uint64_t physical_base, uint32_t reg, uint32_t value);

/* ---------------------------------------------------------------- *
 * KERNEL-01 Phase 2: per-CPU software-enable, and a base address the
 * interrupt dispatcher can reach without being handed one.
 * ---------------------------------------------------------------- */

/* The dedicated spurious vector this kernel programs into every LAPIC's
 * Spurious Interrupt Vector Register. Exposed as a function rather than
 * a macro so that the dispatcher's "this vector is not registerable"
 * rule and lapic.c's SVR programming are guaranteed to be talking about
 * the same number - the consequence of them disagreeing is an EOI issued
 * for an interrupt that is not in service. */
uint32_t lapic_spurious_vector(void);

/* Software-enables the LAPIC of the CALLING CPU and programs the
 * spurious vector, then sets the Task Priority Register to 0 so no
 * interrupt is blocked by priority.
 *
 * WHY APs NEED THIS AT ALL. lapic_init() runs on the BSP and sets the
 * SVR software-enable bit on the BSP's LAPIC only; SVR and TPR are
 * per-logical-processor registers, so an AP coming out of INIT has its
 * LAPIC software-DISABLED (SVR reset value 0x000000FF, enable bit
 * clear). A software-disabled LAPIC still accepts INIT, SIPI and NMI -
 * which is why AP startup works without this - but it will not deliver
 * fixed-delivery interrupts. Without this call an AP can execute `sti`
 * and still never see an IPI, which would present as "the shootdown was
 * sent and never acknowledged".
 *
 * Does NOT execute `sti` and does not unmask the LAPIC timer. Returns
 * the SVR value read back, so the caller can publish it as evidence
 * rather than assuming the write took. */
uint32_t lapic_enable_on_this_cpu(uint64_t physical_base);

/* The LAPIC base recorded by lapic_init(), or 0 if it never succeeded.
 *
 * This exists for one caller: the interrupt dispatcher, which has to EOI
 * an unclaimed vector and has no argument to get a base from. The LAPIC
 * MMIO base is the same physical address on every CPU (each CPU's
 * accesses are routed to its own LAPIC), so one global value is correct
 * here rather than a per-CPU shortcut. Returns 0 rather than guessing if
 * there is no LAPIC; callers must check, because writing EOI through a
 * null base would be a store to physical address 0xB0. */
uint64_t lapic_dispatch_base(void);

/* Signals end-of-interrupt to the CALLING CPU's LAPIC. Must be called
 * from the handler of every LAPIC-delivered interrupt; omitting it
 * leaves the in-service bit set and no further interrupt at or below
 * that priority is ever delivered - which presents as "the timer fired
 * exactly once". */
void lapic_send_eoi(uint64_t physical_base);

#endif /* VEXOS_LAPIC_H */
