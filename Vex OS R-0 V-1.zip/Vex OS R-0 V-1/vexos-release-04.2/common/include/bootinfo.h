/*
 * Vex OS - common/include/bootinfo.h
 *
 * BootInfo v1 - the ONE authoritative bootloader <-> kernel contract.
 *
 * FROZEN per architecture review (Vex OS 1.0 Phase 0). Do not add,
 * remove, reorder, or resize fields without an architecture review.
 * If you need a new field, bump `version` and use `reserved[]` /
 * extend past `header_size` - never break existing field offsets.
 *
 * This header is included by BOTH the UEFI bootloader (built against
 * gnu-efi types) and the freestanding kernel. It must not depend on
 * libc, gnu-efi headers, or anything not available in both contexts.
 * Only <stdint.h> (freestanding, compiler-provided) is used.
 */

#ifndef VEXOS_BOOTINFO_H
#define VEXOS_BOOTINFO_H

#include <stdint.h>

/* Validates the structure actually came from a Vex bootloader before
 * the kernel trusts it. Arbitrary fixed 8-byte constant, frozen. */
#define VEXOS_BOOTINFO_MAGIC   0x3158304F5845565AULL

#define VEXOS_BOOTINFO_VERSION 1

/* Pixel formats we can encounter from the UEFI GOP. Kernel graphics
 * code must switch on this rather than assuming BGRA8888. */
typedef enum {
    VEX_PIXEL_FORMAT_RGBX8 = 0,
    VEX_PIXEL_FORMAT_BGRX8 = 1,
    VEX_PIXEL_FORMAT_BITMASK = 2,
    VEX_PIXEL_FORMAT_UNKNOWN = 3
} VexPixelFormat;

/* boot_flags bits (extend, never repurpose a bit) */
#define VEX_BOOTFLAG_SERIAL_PRESENT   (1ULL << 0)
#define VEX_BOOTFLAG_DEBUG_BUILD      (1ULL << 1)

typedef struct {
    /* --- Header: validate these three fields before touching
     *     anything else in this structure. --- */
    uint64_t magic;                    /* == VEXOS_BOOTINFO_MAGIC */
    uint32_t version;                  /* == VEXOS_BOOTINFO_VERSION (1) */
    uint32_t header_size;              /* == sizeof(BootInfo) at build time */

    /* --- EFI memory map (raw UEFI descriptor array, NOT parsed) --- */
    uint64_t memory_map;               /* physical addr of EFI_MEMORY_DESCRIPTOR[] */
    uint64_t memory_map_size;          /* total size in bytes */
    uint64_t memory_map_desc_size;     /* size of one EFI_MEMORY_DESCRIPTOR (ABI may pad) */
    uint32_t memory_map_desc_version;  /* EFI descriptor version, for future-proofing */
    uint32_t _pad0;                    /* explicit padding, keeps struct layout stable */

    /* --- Framebuffer (from UEFI GOP) --- */
    uint64_t framebuffer_addr;         /* physical address of linear framebuffer */
    uint64_t framebuffer_size;         /* total size in bytes */
    uint32_t framebuffer_width;        /* pixels */
    uint32_t framebuffer_height;       /* pixels */
    uint32_t framebuffer_pitch;        /* bytes per scanline */
    uint32_t framebuffer_bpp;          /* bits per pixel */
    uint32_t framebuffer_pixel_format; /* VexPixelFormat */
    uint32_t _pad1;

    /* --- ACPI --- */
    uint64_t rsdp_address;             /* physical address of ACPI RSDP, 0 if not found */

    /* --- Kernel image location --- */
    uint64_t kernel_physical_base;     /* where the bootloader placed the kernel image */
    uint64_t kernel_physical_size;     /* size in bytes of the loaded kernel image */
    uint64_t kernel_virtual_base;      /* == 0xFFFFFFFF80000000, informational/redundant */

    /* --- Boot metadata --- */
    uint64_t command_line;             /* physical addr of NUL-terminated ASCII string, 0 if none */
    uint64_t bootloader_version;       /* Vex bootloader's own build/version identifier */

    /* --- Future compatibility --- */
    uint64_t boot_flags;               /* VEX_BOOTFLAG_* bitfield */
    uint64_t reserved[4];              /* zero-filled, do not read; extension space */
} __attribute__((packed)) BootInfo;

/*
 * Layout is `packed` deliberately: every field above is already
 * naturally aligned by construction (uint64_t fields on 8-byte
 * boundaries, uint32_t pairs grouped), so packing changes nothing
 * for a correctly-ordered struct but removes any compiler-specific
 * padding ambiguity between the bootloader's toolchain and the
 * kernel's toolchain. If you reorder fields, re-verify alignment.
 */

#endif /* VEXOS_BOOTINFO_H */
