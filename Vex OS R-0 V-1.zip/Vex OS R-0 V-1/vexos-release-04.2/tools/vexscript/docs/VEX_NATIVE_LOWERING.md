# VexScript Native Lowering Wave

**Status:** PARTIALLY NATIVE  
**VexScript:** 3.2.1 · **IR:** 1.5 · **VEX-C:** 5.1.1 (IR tag aligned)

## Architecture

```text
VexScript source
    ↓ AST / typecheck
Vex IR 1.5  (call @genome_* / @stream_* / …)
    ↓ x86-64 AT&T
gcc + vex_rt.c + vex_evo_rt.c
    ↓
native x86-64 executable
```

Hosted path (`genome_rt.py` / `evolve_rt.py`) remains for interpreter/`vexc run` compatibility.

## IR 1.5

Additive vs 1.4: version tag + documented **external native runtime ABI** (`vex_rt_*`).  
High-level ops still lower as `call` to C symbols (not one IR opcode per API).

## Native coverage

| Primitive | Status |
|-----------|--------|
| `rng_seed` / `rng_u64` | **NATIVE** |
| `genome_create` / `length` / `char_code_at` / `set_char_code` / `fill_code` / `copy` / `compare` / `slice` | **NATIVE** |
| `genome_from_string` / `genome_char_at` (string-returning) | **HOSTED** (string ABI incomplete on native) |
| `stream_*` / `fitness_*` / `migrate_*` / `diversity_hamming_avg` / `elite_preserve_count` | **NATIVE** |
| tensor / neural_* | **HOSTED** (unchanged) |
| `evolve_*` older helpers | **HOSTED** preferred; streams cover generation path natively |

## Memory model (native C)

- Fixed tables: max genomes 256, len 4096, pops 64, pop size 512, dim 256, streams 64
- Handles are `int64` indices; no GC
- `vex_rt_evo_reset` available; process start is clean tables

## Benchmarks (dev machine)

Stream advance 32×16 × 20 gens:

| Path | Time |
|------|------|
| Hosted interpreter | ~0.014 s (execute only) |
| Native | ~0.09 s **including compile+link** |

Steady-state native execution of the runtime is C; compile cost dominates micro-benches.

## Remaining blockers for production VEX AI 1.0

1. String-oriented genome APIs on native path  
2. Larger table limits / dynamic allocation policy for 75k-scale  
3. Tensor/neural native kernels  
4. Cross-backend RNG identity not guaranteed vs hosted (same algorithm, separate state machines)  
5. VEX AI application policy (12 streams, etc.) still not implemented (by design)

## Final status

**PARTIALLY NATIVE** — core integer genome/stream/fitness/migration/RNG path executes without Python for those operations; full language surface still uses hosted interpreter for many features.
