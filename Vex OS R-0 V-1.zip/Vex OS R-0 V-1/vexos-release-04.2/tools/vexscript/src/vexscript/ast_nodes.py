from __future__ import annotations
from dataclasses import dataclass, field
from .errors import SourceLocation
from .lexer import TokenKind


@dataclass
class Node:
    loc: SourceLocation


@dataclass
class TypeNode(Node):
    name: str


@dataclass
class Expr(Node):
    pass


@dataclass
class IntLit(Expr):
    value: int


@dataclass
class BoolLit(Expr):
    value: bool


@dataclass
class StringLit(Expr):
    value: str


@dataclass
class ArrayLit(Expr):
    elements: list  # list[Expr]


@dataclass
class Index(Expr):
    obj: Expr
    index: Expr


@dataclass
class Name(Expr):
    name: str


@dataclass
class Binary(Expr):
    op: TokenKind
    left: Expr
    right: Expr


@dataclass
class Unary(Expr):
    op: TokenKind
    operand: Expr


@dataclass
class Call(Expr):
    name: str
    args: list[Expr]


@dataclass
class Assign(Expr):
    name: str
    value: Expr


@dataclass
class FieldAccess(Expr):
    obj: Expr
    field: str


@dataclass
class FieldAssign(Expr):
    obj: Expr
    field: str
    value: Expr


@dataclass
class IndexAssign(Expr):
    """a[i] = value  (VEX AI 1.0 language wave: mutable indexed assignment)."""
    obj: Expr
    index: Expr
    value: Expr


@dataclass
class Cast(Expr):
    expr: Expr
    target: TypeNode


@dataclass
class StructLit(Expr):
    name: str
    fields: list[tuple[str, Expr]]  # (field_name, value_expr)


@dataclass
class Stmt(Node):
    pass


@dataclass
class ExprStmt(Stmt):
    expr: Expr


@dataclass
class Let(Stmt):
    name: str
    mutable: bool
    type: TypeNode | None
    init: Expr | None


@dataclass
class Return(Stmt):
    value: Expr | None


@dataclass
class If(Stmt):
    cond: Expr
    then_body: list[Stmt]
    else_body: list[Stmt] | None


@dataclass
class While(Stmt):
    cond: Expr
    body: list[Stmt]


@dataclass
class For(Stmt):
    init: Stmt | None
    cond: Expr | None
    step: Expr | None
    body: list[Stmt]


@dataclass
class Loop(Stmt):
    body: list[Stmt]


@dataclass
class Break(Stmt):
    pass


@dataclass
class Continue(Stmt):
    pass


@dataclass
class Block(Stmt):
    body: list[Stmt]


@dataclass
class MatchArm(Node):
    """pattern: '_' for wildcard, or 'Enum::Variant' / integer literal string."""
    pattern: str  # "_", "Enum::Variant", or "123"
    body: list[Stmt]


@dataclass
class Match(Stmt):
    expr: Expr
    arms: list[MatchArm]


@dataclass
class Param(Node):
    name: str
    type: TypeNode | None


@dataclass
class Function(Node):
    name: str
    params: list[Param]
    return_type: TypeNode | None
    body: list[Stmt]
    exported: bool = False  # pub fn


@dataclass
class StructField(Node):
    name: str
    type: TypeNode | None


@dataclass
class StructDef(Node):
    name: str
    fields: list[StructField]


@dataclass
class TypeAlias(Node):
    name: str
    target: TypeNode


@dataclass
class EnumDef(Node):
    name: str
    variants: list[str]  # simple C-like; discriminant = index


@dataclass
class Use(Node):
    """Import of a module. `items` None = import whole module for qualified access.
    `items` list = selective import of those public names (also available qualified).
    """
    module: str
    items: list[str] | None = None  # selective: import math::{ add, sub }


@dataclass
class Program(Node):
    uses: list[Use]
    structs: list[StructDef]
    functions: list[Function]
    type_aliases: list = field(default_factory=list)
    enums: list = field(default_factory=list)
