/*
 * Vex OS - kernel/src/drivers/pci/netstatus.c
 * Read-only PCI scan for a network controller. See include/netstatus.h.
 */
#include "netstatus.h"
#include "serial.h"

static NetStatus ns;

static inline void outl(uint16_t p, uint32_t v) { __asm__ volatile("outl %0,%1" :: "a"(v), "Nd"(p)); }
static inline uint32_t inl(uint16_t p) { uint32_t v; __asm__ volatile("inl %1,%0" : "=a"(v) : "Nd"(p)); return v; }

static uint32_t cfg_read32(uint8_t bus, uint8_t slot, uint8_t func, uint8_t off)
{
    outl(0xCF8, 0x80000000u | ((uint32_t)bus << 16) | ((uint32_t)slot << 11) | ((uint32_t)func << 8) | (off & 0xFCu));
    return inl(0xCFC);
}

int netstatus_is_network_class(uint8_t c) { return c == 0x02; }

const char *netstatus_known_name(uint16_t v, uint16_t d)
{
    if (v == 0x8086 && d == 0x10D3) return "Intel 82574L (e1000e)";
    if (v == 0x8086 && d == 0x100E) return "Intel 82540EM (e1000)";
    if (v == 0x1AF4 && d == 0x1000) return "virtio-net";
    if (v == 0x10EC && d == 0x8139) return "Realtek RTL8139";
    return 0;
}

int netstatus_probe(void)
{
    ns = (NetStatus){0};
    /* If the root complex does not answer at all, config space reads float to
     * all-ones; detect that so we do not report a bus we could not read. */
    uint32_t host = cfg_read32(0, 0, 0, 0);
    if (host == 0xFFFFFFFFu || (host & 0xFFFFu) == 0xFFFFu) {
        serial_puts("[net] PCI config space not reachable (no host bridge answered)\n");
        return 0;
    }
    for (uint32_t bus = 0; bus < 256 && !ns.adapter_found; bus++) {
        for (uint32_t slot = 0; slot < 32 && !ns.adapter_found; slot++) {
            uint32_t id0 = cfg_read32((uint8_t)bus, (uint8_t)slot, 0, 0);
            if ((id0 & 0xFFFFu) == 0xFFFFu) continue;
            uint32_t hdr = cfg_read32((uint8_t)bus, (uint8_t)slot, 0, 0x0C);
            uint32_t nfunc = (hdr & 0x00800000u) ? 8u : 1u;        /* multifunction bit */
            for (uint32_t fn = 0; fn < nfunc; fn++) {
                uint32_t id = cfg_read32((uint8_t)bus, (uint8_t)slot, (uint8_t)fn, 0);
                if ((id & 0xFFFFu) == 0xFFFFu) continue;
                ns.devices_scanned++;
                uint32_t cls = cfg_read32((uint8_t)bus, (uint8_t)slot, (uint8_t)fn, 0x08);
                if (netstatus_is_network_class((uint8_t)(cls >> 24))) {
                    ns.adapter_found = 1;
                    ns.vendor = (uint16_t)(id & 0xFFFFu); ns.device = (uint16_t)(id >> 16);
                    ns.bus = (uint8_t)bus; ns.slot = (uint8_t)slot; ns.func = (uint8_t)fn;
                    ns.adapter_name = netstatus_known_name(ns.vendor, ns.device);
                    break;
                }
            }
        }
    }
    ns.state = ns.adapter_found ? NET_NO_DRIVER_ADAPTER_PRESENT : NET_NO_DRIVER_NO_ADAPTER;
    serial_puts("[net] PCI scan: ");
    serial_put_dec64(ns.devices_scanned);
    serial_puts(" function(s) seen before stop; ");
    if (ns.adapter_found) {
        serial_puts("network controller ");
        serial_put_hex64(ns.vendor); serial_puts(":"); serial_put_hex64(ns.device);
        serial_puts(" at bus "); serial_put_dec64(ns.bus);
        serial_puts(" - NO DRIVER, unusable\n");
    } else {
        serial_puts("no network controller found - NO DRIVER\n");
    }
    return 1;
}

const NetStatus *netstatus_get(void) { return &ns; }
const char *netstatus_label(void)
{
    return ns.state == NET_NO_DRIVER_ADAPTER_PRESENT ? "Network: unavailable (no driver)"
                                                    : "Network: unavailable";
}
