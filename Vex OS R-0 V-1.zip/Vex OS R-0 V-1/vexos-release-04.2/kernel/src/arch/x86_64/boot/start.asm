; Vex OS - kernel/src/arch/x86_64/boot/start.asm
;
; This is the FIRST code executed in the kernel image. The bootloader
; loads the kernel as a flat binary at the fixed BOOT-01 physical
; address (see common/include/boot_layout.h) and calls it as a C
; function: `entry(info)`, System V AMD64 ABI, so on entry here:
;
;   RDI = BootInfo* info
;   [rsp] = return address pushed by the bootloader's CALL (never used -
;           this kernel does not return to the bootloader)
;
; Responsibilities of this stub, and only these:
;   1. Zero .bss. This is NOT optional and was missing until BOOT-03:
;      .bss is NOBITS, so it is absent from the flat binary the
;      bootloader loads, which means every zero-initialised C global in
;      the kernel started life holding whatever was in that DRAM. It
;      appeared to work only because QEMU/OVMF happens to leave that
;      memory zeroed; on real hardware, or after a warm reset, it does
;      not. Done first, and without using the stack, because the boot
;      stack itself lives in .bss.
;   2. Switch off the UEFI-provided stack onto our own dedicated
;      kernel stack (we don't want to depend on bootloader stack
;      size/lifetime assumptions).
;   3. Preserve RDI (the BootInfo pointer) across the switch.
;   4. Call kernel_entry(info) - a normal C function from here on.
;
; No GDT/IDT/paging setup here - UEFI already left us in 64-bit long
; mode with paging enabled (identity-ish mapping covering loaded
; regions) when boot services were exited. Building Vex OS's own
; GDT/IDT/paging is the explicit next milestone, done from C/asm
; called by kernel_entry, not from this stub.

BITS 64

section .bss
align 16
stack_bottom:
    resb 16384          ; 16 KiB kernel boot stack - BOOT-01 only,
                         ; sized generously since nothing recursive
                         ; runs yet. Revisit once the process/thread
                         ; milestone introduces per-thread stacks.
stack_top:

section .text.start
global _start
extern kernel_entry
extern __bss_start
extern __bss_end

_start:
    ; Preserve the BootInfo pointer (RDI) across the stack switch -
    ; do this before touching RSP.
    mov     rax, rdi

    ; --- Zero .bss ---
    ; Uses no stack and no call, so it is safe to run while RSP still
    ; points at the bootloader's stack and while the region being
    ; cleared includes our own not-yet-active kernel stack. RAX holds
    ; the BootInfo pointer and must not be touched; BootInfo itself
    ; lives in bootloader-allocated memory, never in .bss.
    lea     rdi, [rel __bss_start]
    lea     rcx, [rel __bss_end]
    sub     rcx, rdi            ; byte count
    shr     rcx, 3              ; -> qwords (.bss end is 8-byte aligned)
    xor     rdx, rdx
.zero_bss:
    test    rcx, rcx
    jz      .bss_done
    mov     [rdi], rdx
    add     rdi, 8
    dec     rcx
    jmp     .zero_bss
.bss_done:

    ; Point RSP at our own stack. System V requires 16-byte alignment
    ; at the point of a CALL (i.e. RSP % 16 == 0 immediately before
    ; the call instruction pushes the return address).
    lea     rsp, [rel stack_top]
    and     rsp, -16

    mov     rdi, rax            ; restore BootInfo* as arg1

    ; kernel_entry() is documented noreturn in practice for BOOT-01
    ; (infinite hlt loop at the end); call it as a normal function
    ; regardless so the ABI stays honest if that ever changes.
    call    kernel_entry

    ; Should never return. If it somehow does, halt rather than fall
    ; into undefined memory.
.hang:
    cli
    hlt
    jmp     .hang

; Explicitly mark this object's stack as non-executable so the
; linker doesn't have to guess (and warn) about it. Purely a
; toolchain hygiene marker - has no effect on the actual kernel
; stack set up above.
section .note.GNU-stack noalloc noexec nowrite progbits
