/*
 * Vex OS - kernel/src/core/boot03_tests.c
 *
 * BOOT-03 in-kernel subsystem self-tests. See boot03_tests.h.
 */

#include "boot03_tests.h"
#include "boot03_inject.h"
#include "pmm.h"
#include "vmm.h"
#include "kstack.h"
#include "context.h"
#include "percpu.h"
#include "timer.h"
#include "idt.h"
#include "serial.h"

/* ------------------------------------------------------------------ *
 * Reporting
 * ------------------------------------------------------------------ */

static uint32_t g_checks;
static uint32_t g_failed;

static int check(const char *sub, const char *what, int ok)
{
    g_checks++;
    if (!ok) g_failed++;

    serial_puts("[test] ");
    serial_puts(sub);
    serial_puts(ok ? ": ok   - " : ": FAIL - ");
    serial_puts(what);
    serial_puts("\n");
    return ok;
}

/* Same, but also prints an observed 64-bit value, because "FAIL" without
 * the number that failed sends the next person back to the debugger for
 * information the test already had. */
static int check_v(const char *sub, const char *what, int ok, uint64_t value)
{
    g_checks++;
    if (!ok) g_failed++;

    serial_puts("[test] ");
    serial_puts(sub);
    serial_puts(ok ? ": ok   - " : ": FAIL - ");
    serial_puts(what);
    serial_puts(" [");
    serial_put_hex64(value);
    serial_puts("]\n");
    return ok;
}

/* ------------------------------------------------------------------ *
 * MEMORY - physical page allocator
 * ------------------------------------------------------------------ */

/* Pressure test buffer. 1024 pages is 4 MiB of allocation, enough to
 * exercise the bitmap across many words and the rotating search hint,
 * and small enough to fit comfortably in the 419 MiB the test VM has.
 * Static, because a 8 KiB array on the boot stack (16 KiB total) would
 * be its own bug. */
#define PRESSURE_PAGES 1024
static uint64_t g_pressure[PRESSURE_PAGES];

static int test_memory(BootInfo *info)
{
    const char *S = "MEMORY";
    int ok = 1;

    uint64_t total = pmm_total_frames();
    uint64_t usable = pmm_usable_frames();
    uint64_t free_before = pmm_free_frames();

    serial_puts("[test] MEMORY: total frames ");
    serial_put_dec64(total);
    serial_puts(", usable ");
    serial_put_dec64(usable);
    serial_puts(", free ");
    serial_put_dec64(free_before);
    serial_puts(", allocated ");
    serial_put_dec64(pmm_allocated_frames());
    serial_puts("\n");

    ok &= check(S, "allocator reports a non-zero frame count", total > 0);
    ok &= check(S, "usable frames do not exceed total frames", usable <= total);
    ok &= check(S, "free frames do not exceed usable frames",
                free_before <= usable);
    ok &= check(S, "some usable memory exists", usable > 0);

    /* Frame 0 must never be allocatable. */
    ok &= check(S, "physical page 0 is reserved", pmm_is_reserved(0));

    /* The kernel image must be reserved - allocating over the running
     * kernel is the single most destructive thing this allocator could
     * do. */
    ok &= check(S, "kernel image base is reserved",
                pmm_is_reserved(info->kernel_physical_base));
    if (info->kernel_physical_size > 0) {
        ok &= check(S, "kernel image last byte is reserved",
                    pmm_is_reserved(info->kernel_physical_base +
                                    info->kernel_physical_size - 1));
    }

    if (info->framebuffer_addr != 0) {
        ok &= check(S, "framebuffer is reserved",
                    pmm_is_reserved(info->framebuffer_addr));
    }
    if (info->rsdp_address != 0) {
        ok &= check(S, "ACPI RSDP page is reserved",
                    pmm_is_reserved(info->rsdp_address));
    }

    /* --- single page round trip --- */
    uint64_t p = pmm_alloc_page();
    ok &= check_v(S, "single page allocation succeeds", p != 0, p);
    if (p != 0) {
        ok &= check(S, "allocated page is 4 KiB aligned",
                    (p & (PMM_PAGE_SIZE - 1)) == 0);
        ok &= check(S, "allocated page is marked allocated", pmm_is_allocated(p));
        ok &= check(S, "allocated page is not reserved", !pmm_is_reserved(p));
        ok &= check(S, "free count dropped by exactly one",
                    pmm_free_frames() == free_before - 1);

        /* The page must be writable memory, not a hole. */
        volatile uint64_t *probe = (volatile uint64_t *)(uintptr_t)p;
        *probe = 0x0123456789ABCDEFULL;
        ok &= check(S, "allocated page holds a written value",
                    *probe == 0x0123456789ABCDEFULL);

        ok &= check(S, "freeing an allocated page succeeds",
                    pmm_free_page(p) == PMM_OK);
        ok &= check(S, "free count restored after free",
                    pmm_free_frames() == free_before);
        ok &= check(S, "freed page is no longer marked allocated",
                    !pmm_is_allocated(p));

        /* --- double free must be refused --- */
        ok &= check(S, "double free is refused with NOT_ALLOCATED",
                    pmm_free_page(p) == PMM_ERR_NOT_ALLOCATED);
        ok &= check(S, "free count unchanged by the refused double free",
                    pmm_free_frames() == free_before);
    }

    /* --- invalid requests --- */
    ok &= check(S, "zero-page allocation is refused",
                pmm_try_alloc_pages(0) == 0);
    ok &= check(S, "unaligned free is refused",
                pmm_free_page(0x1234) == PMM_ERR_NOT_ALIGNED);
    ok &= check(S, "out-of-range free is refused",
                pmm_free_page(pmm_highest_address()) == PMM_ERR_OUT_OF_RANGE);

    /* An allocation larger than all of memory must fail cleanly, not
     * panic and not wrap around. */
    ok &= check(S, "absurdly large allocation fails cleanly",
                pmm_try_alloc_pages(total + 1) == 0);

    /* --- reserved memory protection ---
     * This is the check that fault injection 3 breaks. */
    ok &= check(S, "freeing reserved memory is refused (kernel image)",
                pmm_free_page(info->kernel_physical_base &
                              ~(PMM_PAGE_SIZE - 1)) == PMM_ERR_RESERVED);
    ok &= check(S, "freeing physical page 0 is refused",
                pmm_free_page(0) == PMM_ERR_RESERVED);
    ok &= check(S, "reserved-memory refusal did not change the free count",
                pmm_free_frames() == free_before);

    /* --- allocation below a limit --- */
    uint64_t low = pmm_alloc_page_below(0x100000000ULL);
    ok &= check_v(S, "bounded allocation returns a frame below 4 GiB",
                  low != 0 && low < 0x100000000ULL, low);
    if (low) pmm_free_page(low);

    /* --- contiguous allocation --- */
    uint64_t run = pmm_try_alloc_pages(16);
    ok &= check_v(S, "16-page contiguous allocation succeeds", run != 0, run);
    if (run != 0) {
        int contig = 1;
        for (uint64_t i = 0; i < 16; i++) {
            if (!pmm_is_allocated(run + i * PMM_PAGE_SIZE)) contig = 0;
            if (pmm_is_reserved(run + i * PMM_PAGE_SIZE)) contig = 0;
        }
        ok &= check(S, "all 16 pages of the run are allocated and unreserved",
                    contig);
        ok &= check(S, "freeing the 16-page run succeeds",
                    pmm_free_pages(run, 16) == PMM_OK);
        ok &= check(S, "free count restored after freeing the run",
                    pmm_free_frames() == free_before);
    }

    /* --- memory pressure ---
     * Allocate a lot of pages one at a time, verify every one is
     * distinct, then give them all back and require the free count to
     * return to EXACTLY its starting value. An allocator that leaks or
     * double-hands-out shows up here and essentially nowhere else. */
    uint64_t got = 0;
    for (uint64_t i = 0; i < PRESSURE_PAGES; i++) {
        g_pressure[i] = pmm_alloc_page();
        if (g_pressure[i] == 0) break;
        got++;
    }
    ok &= check_v(S, "memory pressure test obtained all requested pages",
                  got == PRESSURE_PAGES, got);

    /* Distinctness. O(n^2) at n=1024 is about half a million comparisons
     * of already-cached memory - negligible at boot, and it needs no
     * auxiliary data structure that could itself be wrong. */
    int distinct = 1;
    for (uint64_t i = 0; i < got && distinct; i++) {
        if (g_pressure[i] == 0 ||
            (g_pressure[i] & (PMM_PAGE_SIZE - 1)) != 0) {
            distinct = 0;
            break;
        }
        for (uint64_t j = i + 1; j < got; j++) {
            if (g_pressure[i] == g_pressure[j]) { distinct = 0; break; }
        }
    }
    ok &= check(S, "every page from the pressure test is distinct and aligned",
                distinct);

    ok &= check(S, "pressure test consumed exactly the pages it allocated",
                pmm_free_frames() == free_before - got);

    int freed_all = 1;
    for (uint64_t i = 0; i < got; i++) {
        if (pmm_free_page(g_pressure[i]) != PMM_OK) freed_all = 0;
    }
    ok &= check(S, "all pressure-test pages freed successfully", freed_all);
    ok &= check_v(S, "free count restored exactly after the pressure test",
                  pmm_free_frames() == free_before, pmm_free_frames());

    return ok;
}

/* ------------------------------------------------------------------ *
 * PAGING
 * ------------------------------------------------------------------ */

static int test_paging(BootInfo *info, uint64_t lapic_base)
{
    const char *S = "PAGING";
    int ok = 1;

    const VmmInfo *vi = vmm_info();

    ok &= check(S, "VMM reports the kernel page tables are active", vi->active);
    ok &= check_v(S, "CR3 holds the kernel PML4",
                  vmm_read_cr3() == vi->pml4_phys, vmm_read_cr3());
    ok &= check_v(S, "kernel PML4 is below 4 GiB (AP trampoline requirement)",
                  vi->pml4_phys != 0 && vi->pml4_phys < 0x100000000ULL,
                  vi->pml4_phys);
    ok &= check(S, "page-table frames are reserved in the PMM",
                pmm_is_reserved(vi->pml4_phys));

    ok &= check(S, "CR0.WP is set, so read-only pages are enforced in ring 0",
                vmm_write_protect_enabled());

    if (vi->nx_supported) {
        ok &= check(S, "EFER.NXE is enabled where the CPU supports NX",
                    vi->nx_enabled);
    } else {
        serial_puts("[test] PAGING: note - CPU reports no NX support;"
                    " NX checks skipped\n");
    }

    /* --- identity translation of things the kernel depends on --- */
    uint64_t phys = 0;
    ok &= check(S, "kernel image translates identity",
                vmm_translate(info->kernel_physical_base, &phys) == VMM_OK &&
                phys == info->kernel_physical_base);

    if (info->framebuffer_addr) {
        ok &= check(S, "framebuffer translates identity",
                    vmm_translate(info->framebuffer_addr, &phys) == VMM_OK &&
                    phys == info->framebuffer_addr);
    }
    if (info->rsdp_address) {
        ok &= check(S, "ACPI RSDP translates identity",
                    vmm_translate(info->rsdp_address, &phys) == VMM_OK &&
                    phys == info->rsdp_address);
    }
    if (lapic_base) {
        ok &= check(S, "LAPIC MMIO translates identity",
                    vmm_translate(lapic_base, &phys) == VMM_OK &&
                    phys == lapic_base);

        uint64_t entry = 0, size = 0;
        int uc = (vmm_query(lapic_base, &entry, &size) == VMM_OK) &&
                 ((entry & (VMM_PCD | VMM_PWT)) == (VMM_PCD | VMM_PWT));
        ok &= check_v(S, "LAPIC MMIO is mapped uncacheable", uc, entry);
    }

    /* --- direct physical map --- */
    ok &= check(S, "direct physical map resolves to the right frame",
                vmm_translate(VEX_PHYS_MAP_BASE + info->kernel_physical_base,
                              &phys) == VMM_OK &&
                phys == info->kernel_physical_base);

    /* Read the same memory through both windows and require agreement.
     * This is the check that would catch a direct map built with the
     * wrong offset - the translation check above uses the same arithmetic
     * the mapping code used, so on its own it is partly circular. */
    {
        volatile uint64_t *via_ident =
            (volatile uint64_t *)(uintptr_t)info->kernel_physical_base;
        volatile uint64_t *via_direct =
            (volatile uint64_t *)(uintptr_t)(VEX_PHYS_MAP_BASE +
                                             info->kernel_physical_base);
        ok &= check_v(S, "identity and direct map read the same bytes",
                      *via_ident == *via_direct, *via_ident);
    }

    /* --- map / write / read-back / unmap --- */
    uint64_t frame = pmm_alloc_page();
    uint64_t va = vmm_kmap_reserve_virtual(1);
    ok &= check_v(S, "test frame allocated", frame != 0, frame);
    ok &= check_v(S, "kmap virtual page reserved", va != 0, va);

    if (frame && va) {
        ok &= check(S, "mapping a page succeeds",
                    vmm_map_page(va, frame, VMM_KERNEL_RW_NX) == VMM_OK);
        ok &= check(S, "the new mapping translates to the right frame",
                    vmm_translate(va, &phys) == VMM_OK && phys == frame);

        /* Write through the virtual mapping, read through the physical
         * (identity) address. If these disagree the mapping points
         * somewhere else and the translate check was lying. */
        volatile uint64_t *v = (volatile uint64_t *)(uintptr_t)va;
        volatile uint64_t *pp = (volatile uint64_t *)(uintptr_t)frame;
        *v = 0xFEEDFACECAFEBEEFULL;
        ok &= check_v(S, "write via virtual address is visible via physical",
                      *pp == 0xFEEDFACECAFEBEEFULL, *pp);

        /* Reject a second mapping of the same virtual address. */
        ok &= check(S, "re-mapping a live page is refused",
                    vmm_map_page(va, frame, VMM_KERNEL_RW) ==
                    VMM_ERR_ALREADY_MAPPED);

        /* Unaligned requests. */
        ok &= check(S, "unaligned map is refused",
                    vmm_map_page(va + 1, frame, VMM_KERNEL_RW) ==
                    VMM_ERR_NOT_ALIGNED);
        ok &= check(S, "unaligned unmap is refused",
                    vmm_unmap_page(va + 1) == VMM_ERR_NOT_ALIGNED);

        /* --- unmap --- this is what fault injection 1 breaks. */
        ok &= check(S, "unmapping the page succeeds",
                    vmm_unmap_page(va) == VMM_OK);
        ok &= check(S, "the unmapped page no longer translates",
                    vmm_translate(va, &phys) == VMM_ERR_NOT_MAPPED);
        ok &= check(S, "unmapping an already-unmapped page is refused",
                    vmm_unmap_page(va) == VMM_ERR_NOT_MAPPED);

        /* --- recoverable page fault: demand map ---
         * Arm the handler, then touch the address. If #PF is not being
         * delivered, or CR2 is wrong, or iretq does not resume the
         * faulting instruction, this does not come back. */
        idt_expect_page_fault(va, frame, IDT_PF_ACTION_MAP);
        *v = 0x1111222233334444ULL;   /* faults, is repaired, re-executes */

        uint64_t cr2 = 0, err = 0;
        int observed = idt_page_fault_observed(&cr2, &err);
        ok &= check(S, "an expected page fault was delivered and handled",
                    observed);
        ok &= check_v(S, "CR2 reported the faulting page", cr2 == va, cr2);
        /* Error code bit 0 = present, bit 1 = write. A not-present write
         * fault is P=0, W=1. */
        ok &= check_v(S, "error code shows a not-present write fault",
                      (err & 0x1) == 0 && (err & 0x2) != 0, err);
        ok &= check_v(S, "the faulting store completed after resumption",
                      *v == 0x1111222233334444ULL, *v);

        /* --- write protection is actually enforced --- */
        ok &= check(S, "downgrading the page to read-only succeeds",
                    vmm_protect_page(va, VMM_KERNEL_RO_NX) == VMM_OK);

        idt_expect_page_fault(va, 0, IDT_PF_ACTION_MAKE_WRITABLE);
        *v = 0x5555666677778888ULL;   /* must fault: page is read-only */

        observed = idt_page_fault_observed(&cr2, &err);
        ok &= check(S, "writing a read-only page raised a page fault",
                    observed);
        ok &= check_v(S, "read-only violation reported a present write fault",
                      (err & 0x1) != 0 && (err & 0x2) != 0, err);
        ok &= check_v(S, "the store completed once the page was made writable",
                      *v == 0x5555666677778888ULL, *v);

        idt_clear_page_fault_expectation();

        /* Clean up. KERNEL-01 Phase 6 added vmm_kmap_free_virtual(), but
         * this test deliberately still does not call it: BOOT-03's
         * behaviour is left exactly as it was so that this test keeps
         * describing the code it was written against. The KERNEL-01
         * K01-KMAP tests cover the free path. */
        vmm_unmap_page(va);
        pmm_free_page(frame);
    }

    return ok;
}

/* ------------------------------------------------------------------ *
 * INTERRUPTS
 * ------------------------------------------------------------------ */

static int test_interrupts(void)
{
    const char *S = "INTERRUPTS";
    int ok = 1;

    /* Re-run the int3 round trip now that the kernel is on its own page
     * tables. BOOT-02C proved the IDT dispatched under firmware tables;
     * that says nothing about whether the IDT, the ISR stubs and the
     * stack are all still reachable after CR3 changed. */
    ok &= check(S, "software interrupt round trip works under kernel paging",
                idt_self_test());

    /* The paging test provoked real hardware exceptions and returned from
     * them. Requiring the count here ties the two subsystems together:
     * "interrupts work" includes exception delivery, not only int3. */
    ok &= check_v(S, "hardware page faults were delivered and resumed",
                  idt_page_faults_handled() >= 2,
                  idt_page_faults_handled());

    return ok;
}

/* ------------------------------------------------------------------ *
 * TIMER
 * ------------------------------------------------------------------ */

static int test_timer(void)
{
    const char *S = "TIMER";
    int ok = 1;

    const TimerInfo *ti = timer_info();

    ok &= check(S, "timer reports itself initialized", ti->initialized);
    ok &= check(S, "timer was calibrated, not assumed", ti->calibrated);
    ok &= check_v(S, "calibrated count rate is non-zero",
                  ti->counts_per_second > 0, ti->counts_per_second);
    ok &= check_v(S, "programmed initial count is non-zero",
                  ti->initial_count > 0, ti->initial_count);

    /* Interrupts must be enabled by now for any of this to mean
     * anything. Check the flag rather than trusting the call order. */
    uint64_t rflags;
    __asm__ volatile ("pushfq; pop %0" : "=r"(rflags));
    ok &= check_v(S, "interrupts are enabled on the BSP (IF set)",
                  (rflags & (1ULL << 9)) != 0, rflags);

    uint64_t t0 = timer_ticks();

    /* Wait for several ticks, not one. One tick proves delivery; several
     * prove the periodic mode and the EOI are both right. This is what
     * fault injection 2 breaks - without EOI the first tick arrives and
     * no other ever does. */
    int got = timer_wait_ticks(5);
    ok &= check_v(S, "at least 5 timer interrupts were delivered", got,
                  timer_ticks());

    uint64_t t1 = timer_ticks();
    ok &= check_v(S, "tick counter advanced", t1 > t0, t1 - t0);

    /* Advance again, to show it keeps going rather than having run once. */
    int got2 = timer_wait_ticks(5);
    ok &= check_v(S, "the timer keeps firing after the first burst", got2,
                  timer_ticks());

    /* The per-CPU tick counter is incremented from inside the interrupt
     * handler via %gs:0 - so a non-zero value here is evidence that
     * CPU-local storage works in interrupt context, which is where it
     * will actually be used. */
    PerCpu *me = percpu_this_or_null();
    ok &= check(S, "per-CPU block is reachable from the timer handler",
                me != 0);
    if (me) {
        ok &= check_v(S, "per-CPU tick counter was incremented by the handler",
                      me->ticks > 0, me->ticks);
    }

    serial_puts("[test] TIMER: measured ");
    serial_put_dec64(ti->measured_hz);
    serial_puts(" Hz (target ");
    serial_put_dec64(TIMER_TARGET_HZ);
    serial_puts(" Hz), global ticks ");
    serial_put_dec64(timer_ticks());
    serial_puts("\n");
    serial_puts("[test] TIMER: NOTE - rate measured against the PIT inside"
                " QEMU TCG; this is not a wall-clock accuracy claim\n");

    return ok;
}

/* ------------------------------------------------------------------ *
 * SMP
 * ------------------------------------------------------------------ */

static int test_smp(const SmpInfo *smp)
{
    const char *S = "SMP";
    int ok = 1;

    if (smp == 0 || !smp->started) {
        check(S, "SMP startup was attempted", 0);
        return 0;
    }

    ok &= check_v(S, "every MADT-listed CPU is online",
                  smp->online_count == smp->cpu_count, smp->online_count);
    ok &= check_v(S, "no CPU failed to start", smp->failed_count == 0,
                  smp->failed_count);

    uint64_t kernel_cr3 = vmm_info()->pml4_phys;

    /* Every online CPU must be running on the kernel's page tables. This
     * is the specific evidence that paging and SMP coexist, as opposed to
     * the APs happening to survive on firmware tables. */
    int cr3_ok = 1, percpu_ok = 1, id_ok = 1;
    for (uint32_t i = 0; i < smp->cpu_count; i++) {
        const CpuInfo *c = &smp->cpus[i];
        if (c->state != CPU_STATE_ONLINE) continue;

        if (i == 0) continue;   /* the BSP is checked separately below */

        if (c->reported_cr3 != kernel_cr3) {
            serial_puts("[test] SMP: CPU ");
            serial_put_dec64(i);
            serial_puts(" reported CR3 ");
            serial_put_hex64(c->reported_cr3);
            serial_puts(", expected ");
            serial_put_hex64(kernel_cr3);
            serial_puts("\n");
            cr3_ok = 0;
        }
        if (!c->percpu_ok) percpu_ok = 0;
        if (c->percpu_index != i) id_ok = 0;
        if (c->reported_apic_id != c->expected_apic_id) id_ok = 0;
    }

    ok &= check_v(S, "every AP runs on the kernel page tables", cr3_ok,
                  kernel_cr3);
    ok &= check(S, "every AP established and verified its CPU-local storage",
                percpu_ok);
    ok &= check(S, "every AP identifies itself consistently", id_ok);

    /* No duplicate APIC IDs among online CPUs. smp.c checks identity per
     * CPU against the MADT; this checks the set, which catches a
     * different bug - two CPUs both believing they are the same one. */
    int dup = 0;
    for (uint32_t i = 0; i < smp->cpu_count; i++) {
        if (smp->cpus[i].state != CPU_STATE_ONLINE) continue;
        for (uint32_t j = i + 1; j < smp->cpu_count; j++) {
            if (smp->cpus[j].state != CPU_STATE_ONLINE) continue;
            if (smp->cpus[i].reported_apic_id ==
                smp->cpus[j].reported_apic_id) dup = 1;
        }
    }
    ok &= check(S, "no two online CPUs report the same APIC ID", !dup);

    ok &= check_v(S, "per-CPU blocks initialized matches CPUs online",
                  percpu_initialized_count() == smp->online_count,
                  percpu_initialized_count());

    serial_puts("[test] SMP: NOTE - all evidence below is QEMU TCG."
                " TCG serialises guest execution, so this is NOT evidence"
                " of race-condition freedom on real hardware or under KVM\n");

    return ok;
}

/* ------------------------------------------------------------------ *
 * KERNEL FOUNDATION - per-CPU state, guarded stacks, context switching
 * ------------------------------------------------------------------ */

static KernelContext g_main_ctx;
static KernelContext g_test_ctx;
static volatile uint64_t g_ctx_ran;
static volatile uint64_t g_ctx_arg_seen;
static volatile uint64_t g_ctx_rsp_seen;

static void context_test_entry(uint64_t arg)
{
    g_ctx_arg_seen = arg;

    uint64_t rsp;
    __asm__ volatile ("mov %%rsp, %0" : "=r"(rsp));
    g_ctx_rsp_seen = rsp;

    g_ctx_ran = 1;
    g_test_ctx.started = 1;

    /* Hand control back. This is the interesting half: returning from a
     * context is not a `ret`, it is a switch back to whoever switched in.
     * If this does not work the kernel hangs here, which is why the test
     * prints its progress before attempting it. */
    context_switch(&g_test_ctx, &g_main_ctx);

    /* If control ever comes back here, the context was resumed a second
     * time. Nothing in BOOT-03 does that, so park visibly rather than
     * falling off the end. */
    for (;;) {
        __asm__ volatile ("cli; hlt");
    }
}

static int test_kernel_foundation(const SmpInfo *smp)
{
    const char *S = "KERNEL FOUNDATION";
    int ok = 1;

    (void)smp;

    /* --- per-CPU state on the BSP --- */
    ok &= check(S, "BSP CPU-local storage verifies against its own index",
                percpu_verify_this_cpu(0));

    PerCpu *me = percpu_this_or_null();
    ok &= check(S, "BSP per-CPU block is reachable via %gs:0", me != 0);
    if (me) {
        ok &= check(S, "BSP per-CPU block self-pointer is consistent",
                    me->self == me);
        ok &= check(S, "BSP per-CPU block is marked as the BSP", me->is_bsp);
        ok &= check_v(S, "BSP per-CPU block records the kernel CR3",
                      me->cr3 == vmm_info()->pml4_phys, me->cr3);
    }

    /* --- guarded kernel stack --- */
    KernelStack stack;
    int alloced = kstack_alloc(&stack);
    ok &= check(S, "a guarded kernel stack can be allocated", alloced);
    if (alloced) {
        ok &= check_v(S, "kernel stack is sound and its guard page is unmapped",
                      kstack_verify(&stack), stack.guard);
        ok &= check(S, "kernel stack top is 16-byte aligned (ABI)",
                    (stack.top & 0xF) == 0);
        ok &= check(S, "the guard page sits directly below the stack",
                    stack.guard + VMM_PAGE_SIZE == stack.base);

        uint64_t dummy = 0;
        ok &= check(S, "the guard page does not translate",
                    vmm_translate(stack.guard, &dummy) == VMM_ERR_NOT_MAPPED);
    }

    /* --- context switch --- */
    context_adopt_current(&g_main_ctx, "boot-bsp");

    int created = context_create(&g_test_ctx, "boot03-ctx-test",
                                 context_test_entry, 0xABCDEF0123456789ULL);
    ok &= check(S, "a kernel execution context can be created", created);

    if (created) {
        ok &= check(S, "the new context has its own stack, not the BSP's",
                    g_test_ctx.stack.base != 0 &&
                    g_test_ctx.stack.base != g_main_ctx.stack.base);

        serial_puts("[test] KERNEL FOUNDATION: switching to context '");
        serial_puts(g_test_ctx.name);
        serial_puts("' at RSP ");
        serial_put_hex64(g_test_ctx.rsp);
        serial_puts("\n");

        g_ctx_ran = 0;
        g_test_ctx.switches_in++;
        context_switch(&g_main_ctx, &g_test_ctx);
        /* Control returns here when the other context switches back. */

        ok &= check(S, "the second context ran", g_ctx_ran == 1);
        ok &= check_v(S, "the context received its argument intact",
                      g_ctx_arg_seen == 0xABCDEF0123456789ULL, g_ctx_arg_seen);
        ok &= check_v(S, "the context ran on its own stack",
                      g_ctx_rsp_seen > g_test_ctx.stack.base &&
                      g_ctx_rsp_seen <= g_test_ctx.stack.top,
                      g_ctx_rsp_seen);
        ok &= check(S, "control returned to the original context",
                    g_main_ctx.magic == CONTEXT_MAGIC);
        ok &= check_v(S, "kernel stacks allocated so far", kstack_count() >= 2,
                      kstack_count());
    }

    serial_puts("[test] KERNEL FOUNDATION: NOTE - context switching is"
                " cooperative and single-CPU; BOOT-03 adds no scheduler\n");

    return ok;
}

/* ------------------------------------------------------------------ *
 * Driver
 * ------------------------------------------------------------------ */

void boot03_run_tests(BootInfo *info, const SmpInfo *smp,
                      uint64_t lapic_base, Boot03Results *out)
{
    g_checks = 0;
    g_failed = 0;

    serial_puts("\n[test] ===== BOOT-03 subsystem self-tests =====\n");

    out->memory            = test_memory(info);
    out->paging            = test_paging(info, lapic_base);
    out->interrupts        = test_interrupts();
    out->timer             = test_timer();
    out->smp               = test_smp(smp);
    out->kernel_foundation = test_kernel_foundation(smp);

    out->checks_run = g_checks;
    out->checks_failed = g_failed;

    serial_puts("[test] ===== ");
    serial_put_dec64(g_checks - g_failed);
    serial_puts("/");
    serial_put_dec64(g_checks);
    serial_puts(" checks passed =====\n\n");
}

/* Conditions outside BOOT-03 that must also hold before this boot may
 * call itself ready. Starts permissive so that BOOT-03's own behaviour is
 * bit-for-bit what it was before KERNEL-01 existed if nothing folds
 * anything in. See boot03_gate_and() in boot03_tests.h for why the gate
 * is shared rather than each milestone printing its own readiness line. */
static int g_extra_gate = 1;

void boot03_gate_and(int ok)
{
    if (!ok) g_extra_gate = 0;
}

int boot03_all_passed(const Boot03Results *r)
{
    return r->memory && r->paging && r->interrupts && r->timer &&
           r->smp && r->kernel_foundation && r->checks_failed == 0 &&
           g_extra_gate;
}

void boot03_print_summary(const Boot03Results *r)
{
#if VEX_INJECTED(5)
    /* NEGATIVE CONTROL, part 1 of 2: fabricate a subsystem failure.
     *
     * Injection 5 on its own would be worthless: with every subsystem
     * genuinely passing, an unconditional summary and a gated summary
     * produce byte-identical output, so observing the success block would
     * prove nothing at all. The point of this injection is to create the
     * one situation the gate exists to prevent - a FAILING subsystem
     * alongside a printed BOOT SAGA COMPLETE - and then check that the
     * external harness rejects that run anyway, i.e. that scripts/ do not
     * simply trust the kernel's own verdict. */
    ((Boot03Results *)r)->memory = 0;
#endif

    serial_puts("VEX OS BOOT-03\n");
    serial_puts("MEMORY: ");           serial_puts(r->memory ? "PASS\n" : "FAIL\n");
    serial_puts("PAGING: ");           serial_puts(r->paging ? "PASS\n" : "FAIL\n");
    serial_puts("INTERRUPTS: ");       serial_puts(r->interrupts ? "PASS\n" : "FAIL\n");
    serial_puts("TIMER: ");            serial_puts(r->timer ? "PASS\n" : "FAIL\n");
    serial_puts("SMP: ");              serial_puts(r->smp ? "PASS\n" : "FAIL\n");
    serial_puts("KERNEL FOUNDATION: ");
    serial_puts(r->kernel_foundation ? "PASS\n" : "FAIL\n");

#if VEX_INJECTED(5)
    /* NEGATIVE CONTROL, part 2 of 2: print the success block
     * unconditionally, despite the fabricated failure above. This build
     * must NEVER be shipped. */
    serial_puts("SYSTEM READY\n");
    serial_puts("BOOT SAGA COMPLETE\n");
    serial_puts("[kernel] WARNING: fault injection 5 active - summary is"
                " unconditional and MEANINGLESS\n");
    return;
#endif

    if (boot03_all_passed(r)) {
        serial_puts("SYSTEM READY\n");
        serial_puts("BOOT SAGA COMPLETE\n");
    } else {
        /* Deliberately does NOT print SYSTEM READY. The external harness
         * keys on that string, so a failed boot must not produce it -
         * otherwise a broken kernel would be indistinguishable from a
         * working one to every script in scripts/. */
        serial_puts("BOOT-03: FAILED - ");
        serial_put_dec64(r->checks_failed);
        serial_puts(" of ");
        serial_put_dec64(r->checks_run);
        serial_puts(" checks failed. Not declaring the boot saga complete.\n");
    }
}
