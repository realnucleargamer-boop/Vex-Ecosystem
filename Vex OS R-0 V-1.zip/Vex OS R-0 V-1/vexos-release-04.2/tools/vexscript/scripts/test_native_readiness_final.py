#!/usr/bin/env python3
"""Final native readiness wave tests — string genomes, 75k, multi-stream."""
from __future__ import annotations
import sys
import time
import resource
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vexscript import __version__, __ir_version__
from vexscript.native import run_native, compile_native
from vexscript.interpreter import Interpreter

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

print(f"Final native readiness  VS={__version__} IR={__ir_version__}")

# --- 1 String genome native e2e ---
src = r'''
fn main() -> i32 {
    let g = genome_from_string("Hello");
    println(genome_length(g));
    println(genome_char_at(g, 0));
    genome_set_char(g, 0, "J");
    println(genome_to_string(g));
    let hits = genome_match(g, "Jello");
    println(hits);
    let h = genome_slice(g, 0, 2);
    println(genome_to_string(h));
    return 0;
}
'''
try:
    code, out = run_native(src, "str_genome.vex")
    lines = [ln for ln in out.strip().splitlines()]
    check("native string genome e2e",
          code == 0 and lines[0] == "5" and lines[1] == "H" and "Jello" in out and "5" in lines,
          out)
except Exception as e:
    check("native string genome e2e", False, str(e))

# hosted parity
i = Interpreter(); i.load(src, "t"); i.run_main()
check("hosted string genome", i.output[0] == "5" and i.output[2] == "Jello", i.output)

# --- 2 Text fitness ---
src = r'''
fn main() -> i32 {
    let g = genome_from_string("ABCDEF");
    println(genome_match(g, "ABCDEF"));
    println(genome_match(g, "ABCXXX"));
    println(genome_match(g, "ZZZZZZ"));
    return 0;
}
'''
code, out = run_native(src, "fit_text.vex")
check("native text fitness", code == 0 and out.strip().splitlines() == ["6", "3", "0"], out)

# --- 3 75k capacity (single large genome) ---
# Use fill_code for speed of source generation
src = '''
fn main() -> i32 {
    let g = genome_create(75000);
    genome_fill_code(g, 65, 75000);
    println(genome_length(g));
    println(genome_char_code_at(g, 0));
    println(genome_char_code_at(g, 74999));
    genome_set_char_code(g, 100, 66);
    println(genome_char_code_at(g, 100));
    let c = genome_copy(g);
    println(genome_compare(g, c));
    return 0;
}
'''
t0 = time.perf_counter()
try:
    code, out = run_native(src, "g75k.vex")
    elapsed = time.perf_counter() - t0
    lines = out.strip().splitlines()
    check("75k genome native", code == 0 and lines == ["75000", "65", "65", "66", "0"], out)
    print(f"  TIME 75k ops (incl compile)={elapsed:.3f}s")
except Exception as e:
    check("75k genome native", False, str(e))

# capacity overflow boundary
src = '''
fn main() -> i32 {
    let g = genome_create(0);
    let r = genome_fill_code(g, 65, 100000);
    println(genome_length(g));
    println(r);
    return 0;
}
'''
code, out = run_native(src, "overflow.vex")
# should clamp to VEX_MAX_GENOME_LEN 81920
length = int(out.strip().splitlines()[0]) if code == 0 else -1
check("capacity clamp", code == 0 and length == 81920, out)

# --- 4 Multi-stream native stress (12 streams, not hardcoded in runtime) ---
src = '''
fn main() -> i32 {
    rng_seed(12345);
    let s0 = stream_create(16, 16, 2);
    let s1 = stream_create(16, 16, 2);
    let s2 = stream_create(16, 16, 2);
    let s3 = stream_create(16, 16, 2);
    let s4 = stream_create(16, 16, 2);
    let s5 = stream_create(16, 16, 2);
    let s6 = stream_create(16, 16, 2);
    let s7 = stream_create(16, 16, 2);
    let s8 = stream_create(16, 16, 2);
    let s9 = stream_create(16, 16, 2);
    let s10 = stream_create(16, 16, 2);
    let s11 = stream_create(16, 16, 2);
    let mut i: i64 = 0;
    while (i < 16) {
        fitness_set(s0, i, i);
        fitness_set(s1, i, 16 - i);
        i = i + 1;
    }
    let mut g: i64 = 0;
    while (g < 25) {
        stream_advance(s0, 150);
        stream_advance(s1, 150);
        stream_advance(s6, 100);
        g = g + 1;
    }
    migrate_best(s0, s1, 0);
    println(stream_generation(s0));
    println(stream_generation(s1));
    println(stream_generation(s11));
    println(stream_size(s0));
    println(elite_preserve_count(s0));
    return 0;
}
'''
t0 = time.perf_counter()
code, out = run_native(src, "12stream.vex")
elapsed = time.perf_counter() - t0
lines = out.strip().splitlines() if code == 0 else []
check("12-stream native stress", code == 0 and lines[0] == "25" and lines[2] == "0" and lines[3] == "16", out)
print(f"  TIME 12-stream 25gens (incl compile)={elapsed:.3f}s")

# determinism
code2, out2 = run_native(src, "12stream_b.vex")
check("12-stream deterministic", out == out2, (out, out2))

# --- 5 Safety: invalid handles ---
src = '''
fn main() -> i32 {
    println(genome_length(0));
    println(genome_char_code_at(999, 0));
    println(fitness_get(0, 0));
    return 0;
}
'''
code, out = run_native(src, "safe.vex")
check("invalid handles safe", code == 0, out)

# --- 6 Hosted readiness still green smoke ---
i = Interpreter()
i.load('''
fn main() -> i32 {
    let g = genome_from_string("Ab");
    println(genome_match(g, "Ab"));
    return 0;
}
''', "t")
i.run_main()
check("hosted match", i.output == ["2"], i.output)

print(f"\n=== Final native readiness: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
