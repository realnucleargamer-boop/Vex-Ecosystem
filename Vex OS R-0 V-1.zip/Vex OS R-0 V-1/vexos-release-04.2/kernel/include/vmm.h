/*
 * Vex OS - kernel/include/vmm.h
 *
 * BOOT-03 kernel virtual memory foundation.
 *
 * Vex OS now builds and OWNS its own x86-64 page tables instead of
 * running on whatever mapping UEFI happened to leave behind. This is
 * the kernel foundation only - there is no userspace address space, no
 * per-process page tables, no demand paging policy, no swapping.
 *
 * ADDRESS SPACE (BOOT-03)
 *
 *   0x0000000000000000 .. top of memory map     identity map
 *       Physical memory mapped 1:1. Retained deliberately: acpi.c,
 *       lapic.c, smp.c, the framebuffer code and the AP trampoline all
 *       address physical memory directly, and the kernel image itself
 *       is linked to run at 0x100000. Removing the identity map would
 *       be a rewrite of working BOOT-01/02C code with no BOOT-03
 *       requirement behind it. Built with 2 MiB pages.
 *
 *   0xFFFF800000000000 .. + top of memory map   direct physical map
 *       The same physical memory, mapped again in the higher half at a
 *       fixed offset. This is the "known kernel address space" the
 *       kernel will use to reach arbitrary physical memory once it
 *       stops relying on identity. Built with 2 MiB pages.
 *
 *   0xFFFFC00000000000 .. +512 GiB              kernel map window
 *       4 KiB-granular window for explicit mappings: the map/unmap
 *       primitives, guarded kernel stacks, and the paging self-tests
 *       all operate here. Nothing is mapped in it at boot.
 *
 *   The kernel IMAGE is not relocated to 0xFFFFFFFF80000000 in BOOT-03.
 *   See docs/BOOT-03.md for why, and for what moving it would require.
 *
 * CACHE ATTRIBUTES
 *
 *   A 2 MiB page in the identity and direct maps is write-back only if
 *   the entire 2 MiB range is reported as RAM by the EFI memory map;
 *   otherwise it is mapped uncacheable (PCD|PWT). This is not a
 *   performance tweak - mapping the LAPIC or the framebuffer write-back
 *   would be a correctness bug. Write-combining via PAT is out of scope.
 *
 * OWNERSHIP
 *
 *   Every page table is allocated from the BOOT-03 PMM and immediately
 *   reserved with PMM_RSV_PAGE_TABLE, so a page table can never be
 *   handed out as ordinary memory. The PML4 is allocated below 4 GiB
 *   because the BOOT-02C AP trampoline loads CR3 in 32-bit protected
 *   mode.
 */

#ifndef VEXOS_VMM_H
#define VEXOS_VMM_H

#include <stdint.h>
#include "bootinfo.h"

#define VMM_PAGE_SIZE        4096ULL
#define VMM_LARGE_PAGE_SIZE  0x200000ULL          /* 2 MiB */

/* Higher-half windows. Both are PML4-entry aligned (512 GiB each), so
 * each occupies exactly one PML4 slot per 512 GiB covered. */
#define VEX_PHYS_MAP_BASE    0xFFFF800000000000ULL
#define VEX_KMAP_BASE        0xFFFFC00000000000ULL
#define VEX_KMAP_SIZE        0x8000000000ULL       /* 512 GiB of window */

/* Page-table entry flags (Intel SDM Vol.3, "Paging"). */
#define VMM_PRESENT   (1ULL << 0)
#define VMM_WRITE     (1ULL << 1)
#define VMM_USER      (1ULL << 2)
#define VMM_PWT       (1ULL << 3)
#define VMM_PCD       (1ULL << 4)
#define VMM_ACCESSED  (1ULL << 5)
#define VMM_DIRTY     (1ULL << 6)
#define VMM_LARGE     (1ULL << 7)   /* PS: this entry maps a 2 MiB page */
#define VMM_GLOBAL    (1ULL << 8)
#define VMM_NX        (1ULL << 63)  /* requires EFER.NXE */

/* Convenience combinations used by the kernel. */
#define VMM_KERNEL_RW      (VMM_PRESENT | VMM_WRITE)
#define VMM_KERNEL_RO      (VMM_PRESENT)
#define VMM_KERNEL_RW_NX   (VMM_PRESENT | VMM_WRITE | VMM_NX)
#define VMM_KERNEL_RO_NX   (VMM_PRESENT | VMM_NX)
#define VMM_KERNEL_MMIO    (VMM_PRESENT | VMM_WRITE | VMM_PCD | VMM_PWT | VMM_NX)

typedef enum {
    VMM_OK = 0,
    VMM_ERR_NO_MEMORY,       /* could not allocate a page table */
    VMM_ERR_NOT_ALIGNED,
    VMM_ERR_ALREADY_MAPPED,
    VMM_ERR_NOT_MAPPED,
    VMM_ERR_LARGE_PAGE,      /* address is covered by a 2 MiB mapping */
    VMM_ERR_NOT_INITIALIZED,
    VMM_ERR_BAD_REQUEST,

    /* KERNEL-01 Phase 6, for kmap virtual-range frees. Appended, never
     * inserted, so every existing value keeps its number. */
    VMM_ERR_NO_SUCH_RANGE,   /* not a range base that was handed out */
    VMM_ERR_ALREADY_FREE     /* the range is already free (double free) */
} VmmResult;

typedef struct {
    uint64_t pml4_phys;          /* the kernel's CR3 value */
    uint64_t identity_top;       /* bytes of physical space identity mapped */
    uint64_t table_pages;        /* page-table frames allocated */
    uint64_t large_pages_wb;     /* 2 MiB write-back mappings created */
    uint64_t large_pages_uc;     /* 2 MiB uncacheable mappings created */
    int      nx_supported;       /* CPUID.80000001:EDX.NX */
    int      nx_enabled;         /* EFER.NXE actually set */
    int      active;             /* 1 once CR3 has been switched */
} VmmInfo;

/* Builds the kernel page tables described above. Does NOT switch CR3.
 * Returns 1 on success, 0 on failure (and prints why). Splitting build
 * from activation is deliberate: it makes the "controlled manner"
 * requirement real, and it means a failed build leaves the machine
 * running on the firmware tables rather than on half-built ones. */
int vmm_build_kernel_tables(BootInfo *info, VmmInfo *out);

/* Verifies that a set of addresses the kernel is currently depending on
 * really are mapped in the new tables, BEFORE loading CR3. Returns 1 if
 * all present, 0 otherwise (naming each failure on serial).
 *
 * This exists because a missing mapping discovered by loading CR3 is an
 * instant triple fault with no diagnostic; discovered here it is a
 * printed error and a normal boot on firmware tables. */
int vmm_verify_before_activation(BootInfo *info, uint64_t lapic_base);

/* Loads the kernel PML4 into CR3, enabling EFER.NXE first if the CPU
 * supports it. After this returns, the kernel is running on its own
 * page tables. */
void vmm_activate(void);

/* 1 if CR0.WP is set, so that supervisor writes to read-only pages
 * fault. Checked by the BOOT-03 tests rather than assumed, because
 * without it every read-only kernel mapping is decorative. */
int vmm_write_protect_enabled(void);

/* Reads back CR3. Used to prove activation, and by APs to report which
 * tables they are actually running on. */
uint64_t vmm_read_cr3(void);

/* Maps `virt` -> `phys` with `flags`, allocating page tables as needed.
 * 4 KiB granularity. Both addresses must be page aligned. Refuses to
 * silently replace an existing mapping. */
VmmResult vmm_map_page(uint64_t virt, uint64_t phys, uint64_t flags);

/* SECURITY-02: the ONLY way to create a Ring-3-accessible mapping.
 * `flags` MUST include VMM_USER (VMM_ERR_BAD_REQUEST otherwise) - this
 * is not a general-purpose relaxation of vmm_map_page(), it is a
 * separate, narrow door that also promotes the VMM_USER bit up every
 * ancestor page-table entry on the walk to `virt`, which is the step
 * standard x86-64 paging requires before a leaf's own VMM_USER bit has
 * any effect (the CPU ANDs the user bit across the whole walk). See
 * vmm.c for the full safety argument. Everything else about this
 * function - alignment, already-mapped refusal, large-page collisions -
 * behaves identically to vmm_map_page(). */
VmmResult vmm_map_user_page(uint64_t virt, uint64_t phys, uint64_t flags);

/* Removes the mapping for `virt` and invalidates the TLB entry. Does
 * NOT free the underlying physical frame - the caller owns that, and
 * unmapping is not the same operation as deallocating. */
VmmResult vmm_unmap_page(uint64_t virt);

/* KERNEL-01 Phase 5: unmaps `virt` AND reclaims every intermediate page
 * table the removal emptied, returning those frames to the allocator.
 *
 * Restricted to the kmap window. Outside it, the intermediate tables are
 * shared with the identity map, the direct map, the kernel image and the
 * framebuffer; an address outside the window is rejected with
 * VMM_ERR_BAD_REQUEST before any entry is touched, which makes "never free
 * a shared or static table" structural rather than a promise. The PML4
 * itself is never freed - only entries within it.
 *
 * Distinct from vmm_unmap_page() rather than replacing it, because it
 * cannot be done under the VMM lock: the lock disables interrupts and a
 * remote TLB shootdown with interrupts disabled is refused by design (see
 * tlb.h). The sequence must release the lock in the middle:
 *
 *   entry edits under the lock -> unlock -> shootdown -> confirm -> free
 *
 * All entries along the walk, including emptied parents, are cleared
 * BEFORE the shootdown. Intel SDM Vol.3 specifies that INVLPG invalidates
 * paging-structure caches for the named linear address, so once the
 * shootdown completes no CPU holds a cached reference to any orphaned
 * table and none can acquire one, because the entries that would let it
 * walk there are gone.
 *
 * FAILS SAFE. If the shootdown does not demonstrably complete, the frames
 * are LEAKED and counted, and VMM_ERR_BAD_REQUEST is returned. The address
 * space is still correct - the entries are gone either way. A counted leak
 * is a bounded cost; a premature free is silent corruption.
 *
 * vmm_unmap_page() is UNCHANGED, including its documented leak, so every
 * BOOT-03 test and fault injection 1 still describe the code they were
 * written against. */
VmmResult vmm_unmap_page_reclaim(uint64_t virt);

/* Reclamation statistics. Separate accessors rather than new VmmInfo
 * fields, so the struct the BOOT-03 tests read is untouched.
 *
 * `violations` counts frames that were freed WITHOUT a completed
 * shootdown. It must always be zero: the gate refuses to free in that
 * case. It is counted separately from the refusal so that a build which
 * bypasses the gate is still observable - the injection removes the
 * refusal, not the observation. */
uint64_t vmm_reclaim_attempts(void);
uint64_t vmm_tables_reclaimed(void);
uint64_t vmm_reclaim_leaks(void);
uint64_t vmm_reclaim_violations(void);

/* Changes the flags on an existing 4 KiB mapping, keeping the frame. */
VmmResult vmm_protect_page(uint64_t virt, uint64_t flags);

/* Translates `virt` to a physical address. Handles both 4 KiB and
 * 2 MiB mappings, including the offset within a large page. Returns
 * VMM_OK and writes *out_phys, or VMM_ERR_NOT_MAPPED. */
VmmResult vmm_translate(uint64_t virt, uint64_t *out_phys);

/* Reads the raw leaf entry for `virt`, for diagnostics and tests.
 * Returns VMM_OK and writes *out_entry plus the page size that leaf
 * describes. */
VmmResult vmm_query(uint64_t virt, uint64_t *out_entry, uint64_t *out_size);

/* Reserves a `pages`-long, page-aligned virtual range in the kmap window
 * and returns its base, or 0 if the window is exhausted or the range table
 * is full. Reserves ADDRESS SPACE ONLY - nothing is mapped.
 *
 * KERNEL-01 Phase 6 replaced the BOOT-03 bump-only allocator: ranges can now
 * be returned with vmm_kmap_free_virtual() and are reused. The signature and
 * the contract for existing callers are unchanged - a fresh reservation still
 * comes off a cursor that NEVER moves backward, which is the BOOT-03 sec.9
 * invariant. Reuse comes from a record table, not from rewinding the cursor,
 * so a freed-then-reissued range has the same base because the record
 * remembered it.
 *
 * Every returned base is page-aligned, whether it came from the cursor or
 * from reuse: records store the base that was originally issued, so
 * alignment is preserved by construction rather than recomputed.
 *
 * Reuse requires an exact page-count match. Free ranges are neither split nor
 * coalesced - deliberately, because the consumers are one stack range per CPU
 * plus the self-tests, and a merge path nothing exercises is a liability. See
 * vmm.c for the cost of that choice and where it would have to change. */
uint64_t vmm_kmap_reserve_virtual(uint64_t pages);

/* Returns a range previously obtained from vmm_kmap_reserve_virtual(), making
 * it available for reuse. `base` and `pages` must match the reservation
 * exactly.
 *
 * THE RANGE MUST BE FULLY UNMAPPED FIRST. If any page inside it still has a
 * mapping the call is refused with VMM_ERR_ALREADY_MAPPED, because reissuing
 * a range with live mappings would hand the next consumer frames belonging to
 * someone else.
 *
 * Refusals, each of which is a caller bug rather than a condition to retry:
 *   VMM_ERR_NOT_ALIGNED     - base is not page aligned
 *   VMM_ERR_BAD_REQUEST     - zero pages, outside the kmap window, or a page
 *                             count that does not match the reservation
 *   VMM_ERR_NO_SUCH_RANGE   - never reserved, or an address in the middle of
 *                             a range instead of its base
 *   VMM_ERR_ALREADY_FREE    - double free
 *   VMM_ERR_ALREADY_MAPPED  - pages in the range are still mapped */
VmmResult vmm_kmap_free_virtual(uint64_t base, uint64_t pages);

/* kmap allocator statistics, for diagnostics and tests. `reuses` counts
 * reservations satisfied from the free list without moving the cursor, which
 * is the direct evidence that reuse actually happens rather than every
 * request quietly bumping. */
typedef struct {
    uint64_t cursor;         /* next fresh address; never decreases */
    uint64_t window_base;
    uint64_t window_size;
    uint64_t live_ranges;
    uint64_t free_ranges;
    uint64_t reuses;
    uint64_t max_ranges;     /* capacity of the record table */
} VmmKmapStats;

void vmm_kmap_stats(VmmKmapStats *out);

/* Human-readable VmmResult. */
const char *vmm_result_name(VmmResult r);

/* The VmmInfo filled by vmm_build_kernel_tables, for diagnostics. */
const VmmInfo *vmm_info(void);

#endif /* VEXOS_VMM_H */
