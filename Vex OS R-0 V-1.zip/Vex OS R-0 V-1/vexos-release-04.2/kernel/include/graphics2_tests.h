/*
 * Vex OS - kernel/include/graphics2_tests.h
 *
 * Graphics 2 subsystem self-tests, following the BOOT-03 convention:
 * these run on real (virtual) hardware, in-kernel, after graphics has
 * initialised, and check things only in-kernel code can check (that a
 * clipped pixel write really didn't land, that a bar fill width really
 * tracks percent, that boot_progress_set()'s clamp really clamps).
 *
 * DESIGN RULE (inherited from BOOT-03): a check that cannot fail is not
 * a check. Every predicate here is one a plausible Graphics 2 bug would
 * break - see the comment above each check in graphics2_tests.c for
 * which specific bug it catches.
 */

#ifndef VEXOS_GRAPHICS2_TESTS_H
#define VEXOS_GRAPHICS2_TESTS_H

#include <stdint.h>
#include "gfx/fb.h"

typedef struct {
    int fb_pixel_roundtrip;   /* gfx_put/gfx_get round-trip at a real pixel */
    int fb_bounds_clipping;   /* out-of-range gfx_put() does not corrupt memory */
    int rect_fill_bounds;     /* gfx_fill_rect clips to screen, doesn't overrun */
    int progress_clamp_low;   /* boot_progress_set(-50) clamps to 0 */
    int progress_clamp_high;  /* boot_progress_set(500) clamps to 100 */
    int progress_monotonic;   /* the real recorded boot sequence never regresses */
    int bar_fill_scales;      /* rendered bar fill width increases with percent */

    uint32_t checks_run;
    uint32_t checks_failed;
} Graphics2Results;

/* Runs every Graphics 2 test. *fb must already be initialised
 * (fb->ok == 1); if it is not, every fb-dependent check is recorded as
 * failed rather than skipped, matching BOOT-03's SMP-may-be-NULL rule:
 * a milestone that requires working graphics cannot pass by not
 * testing it. */
void graphics2_run_tests(GfxFb *fb, Graphics2Results *out);

/* Prints the Graphics 2 summary block over serial, matching BOOT-03's
 * PASS/FAIL formatting. */
void graphics2_print_summary(const Graphics2Results *r);

int graphics2_all_passed(const Graphics2Results *r);

#endif /* VEXOS_GRAPHICS2_TESTS_H */
