# VexScript 2.0 Phase C

## Delivered
- `vex.toml` with `[package]` and `[build].entry`
- Project root discovery
- Multi-file modules from `src/` via existing Phase A resolver
- `vexc check | build | run | emit-ir`
- `build/project.ir` (validated text IR — **not** a native executable)
- Privacy checked at load/check time (E0004)

## Error codes
| Code | Meaning |
|------|---------|
| E0401 | missing vex.toml |
| E0402 | malformed manifest |
| E0403 | invalid entry path |
| E0405 | CLI usage |

## What build does NOT do
No x86-64, ELF, Vex OS syscalls, or fake kernel.
