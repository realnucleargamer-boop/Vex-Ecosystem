/*
 * Vex OS - kernel/src/arch/x86_64/cpu/context.c
 *
 * BOOT-03 kernel execution contexts. See kernel/include/context.h.
 */

#include "context.h"
#include "kstack.h"
#include "panic.h"
#include "serial.h"

/* Defined in context_switch.asm. */
extern void context_trampoline(void);

/* Initial RFLAGS for a new context.
 *
 * Bit 1 is reserved and architecturally always 1; a popfq of a value
 * with it clear is a wrong-looking flags register for no reason. IF is
 * deliberately CLEAR: a new kernel context starts with interrupts
 * disabled and enables them itself if it wants them. Starting a
 * brand-new stack with interrupts already on means the first thing that
 * can happen on it is an interrupt, before the context has established
 * any of its own invariants. */
#define CONTEXT_INITIAL_RFLAGS 0x0000000000000002ULL

void context_entry_returned(void)
{
    panic("context entry function returned - kernel contexts must not return",
          0, 0);
}

void context_adopt_current(KernelContext *ctx, const char *name)
{
    if (ctx == 0) return;

    /* rsp is left at 0: it is only ever written by context_switch when
     * this context is switched AWAY from, and reading it before that
     * would be meaningless. The stack fields are zero because this
     * context did not allocate its stack - it inherited the boot stack
     * from start.asm, which is in .bss inside the kernel image and has
     * no guard page. That is stated rather than papered over: the BSP's
     * original stack is the one kernel stack in the system without
     * overflow protection. */
    ctx->rsp = 0;
    ctx->magic = CONTEXT_MAGIC;
    ctx->stack.base = 0;
    ctx->stack.top = 0;
    ctx->stack.guard = 0;
    ctx->stack.pages = 0;
    ctx->entry = 0;
    ctx->arg = 0;
    ctx->name = name;
    ctx->started = 1;
    ctx->switches_in = 0;
}

int context_create(KernelContext *ctx, const char *name,
                   ContextEntry entry, uint64_t arg)
{
    if (ctx == 0 || entry == 0) return 0;

    KernelStack stack;
    if (!kstack_alloc(&stack)) return 0;

    if (!kstack_verify(&stack)) {
        serial_puts("[kernel] CONTEXT: refusing to create context on an "
                    "unsound stack\n");
        return 0;
    }

    /* Build the synthetic stack image that context_switch will pop.
     *
     * THIS LAYOUT IS A CONTRACT WITH context_switch.asm. The order below
     * is the reverse of that file's push sequence, and the two must be
     * changed together - see the comment block in the .asm.
     *
     * Written as explicit indices from the top rather than a loop or a
     * struct overlay, because the whole point is that a human can read
     * it next to the assembly and check it. */
    uint64_t *sp = (uint64_t *)(uintptr_t)stack.top;

    sp[-1] = (uint64_t)(uintptr_t)context_entry_returned; /* poison / unused */
    sp[-2] = (uint64_t)(uintptr_t)context_trampoline;     /* `ret` target */
    sp[-3] = 0;                                           /* rbp */
    sp[-4] = 0;                                           /* rbx */
    sp[-5] = arg;                                         /* r12 -> rdi */
    sp[-6] = (uint64_t)(uintptr_t)entry;                  /* r13 -> called */
    sp[-7] = 0;                                           /* r14 */
    sp[-8] = 0;                                           /* r15 */
    sp[-9] = CONTEXT_INITIAL_RFLAGS;                      /* popfq */

    ctx->rsp = stack.top - (9 * 8);
    ctx->magic = CONTEXT_MAGIC;
    ctx->stack = stack;
    ctx->entry = entry;
    ctx->arg = arg;
    ctx->name = name;
    ctx->started = 0;
    ctx->switches_in = 0;

    return 1;
}
