/*
 * Vex OS - kernel/src/ui/cursor.c
 * Save-under software cursor. See include/cursor.h.
 */
#include "cursor.h"
#include "gfx/draw.h"

/* 'X' = outline, 'W' = fill, '.' = transparent.  Hot spot is the top-left pixel. */
static const char *const sprite[CURSOR_H] = {
    "X...........",
    "XX..........",
    "XWX.........",
    "XWWX........",
    "XWWWX.......",
    "XWWWWX......",
    "XWWWWWX.....",
    "XWWWWWWX....",
    "XWWWWWWWX...",
    "XWWWWWWWWX..",
    "XWWWWWWWWWX.",
    "XWWWWWXXXXXX",
    "XWWXWWX.....",
    "XWX.XWWX....",
    "XX..XWWX....",
    "X....XWWX...",
    ".....XWWX...",
    "......XX....",
};

static const GfxFb *fbp;
static int32_t cx, cy;
static int visible;
static int32_t saved_x, saved_y;       /* where the saved pixels came from */
static GfxColor saved[CURSOR_W * CURSOR_H];

int32_t cursor_clamp(int32_t v, int32_t lo, int32_t hi) { return v < lo ? lo : v > hi ? hi : v; }

int cursor_sprite_wellformed(void)
{
    for (int r = 0; r < CURSOR_H; r++) {
        int n = 0;
        for (; sprite[r][n]; n++) {
            char c = sprite[r][n];
            if (c != 'X' && c != 'W' && c != '.') return 0;
        }
        if (n != CURSOR_W) return 0;
    }
    return 1;
}

void cursor_init(const GfxFb *fb)
{
    fbp = fb; visible = 0;
    cx = fb && fb->ok ? (int32_t)(fb->width / 2) : 0;
    cy = fb && fb->ok ? (int32_t)(fb->height / 2) : 0;
}

void cursor_move_to(int32_t x, int32_t y)
{
    if (!fbp || !fbp->ok) return;
    cx = cursor_clamp(x, 0, (int32_t)fbp->width  - 1);
    cy = cursor_clamp(y, 0, (int32_t)fbp->height - 1);
}
int32_t cursor_x(void) { return cx; }
int32_t cursor_y(void) { return cy; }
int cursor_visible(void) { return visible; }

void cursor_hide(void)
{
    if (!visible || !fbp) return;
    for (int r = 0; r < CURSOR_H; r++)
        for (int c = 0; c < CURSOR_W; c++)
            if (sprite[r][c] != '.')                     /* only pixels the sprite covered */
                gfx_put(fbp, saved_x + c, saved_y + r, saved[r * CURSOR_W + c]);
    visible = 0;
}

void cursor_show(void)
{
    if (!fbp || !fbp->ok) return;
    if (visible) cursor_hide();
    saved_x = cx; saved_y = cy;
    const GfxColor outline = gfx_rgb(0x05, 0x07, 0x0C), fill = gfx_rgb(0xF4, 0xF7, 0xFF);
    for (int r = 0; r < CURSOR_H; r++)
        for (int c = 0; c < CURSOR_W; c++) {
            char s = sprite[r][c];
            if (s == '.') continue;
            saved[r * CURSOR_W + c] = gfx_get(fbp, cx + c, cy + r);
            gfx_put(fbp, cx + c, cy + r, s == 'X' ? outline : fill);
        }
    visible = 1;
}
