# Vex IR 0.1 — Canonical Specification

Textual, deterministic, explicitly typed, basic-block + SSA values.

## Grammar (text)

```
module ::= function*

function ::= 'func' '@' NAME '(' (param (',' param)*)? ')' '->' type '{' block+ '}'
param ::= type '%' NAME
block ::= 'block' NAME ':' instruction* terminator
instruction ::= '%' NAME '=' op
terminator ::= 'ret' type value
             | 'br' NAME
             | 'br_cond' value ',' NAME ',' NAME

op ::= 'const.' type literal
     | 'copy' type value
     | 'add'|'sub'|'mul'|'div'|'mod' type value ',' value
     | 'eq'|'ne'|'lt'|'le'|'gt'|'ge' type value ',' value
     | 'and'|'or' type value ',' value
     | 'not' type value
     | 'call' type '@' NAME '(' (value (',' value)*)? ')'
     | 'extract' type value ',' INT     # struct field index
     | 'insert' type value ',' INT ',' value

value ::= '%' NAME | literal
type ::= 'i8'|'i16'|'i32'|'i64'|'u8'|'u16'|'u32'|'u64'|'bool'|'void'
```

SSA names are `%v0`, `%v1`, … assigned in emission order (deterministic).
Block names: `entry`, `then0`, `else0`, `join0`, `loop0`, `body0`, `end0`, …

## Semantics (summary)
- Integer ops are two's complement; div/mod by zero is undefined (trap in IR interpreter).
- Comparisons produce `bool`.
- `call` matches callee arity and types.
- Every block ends with exactly one terminator.
- No GC; no host pointers in the IR model.
