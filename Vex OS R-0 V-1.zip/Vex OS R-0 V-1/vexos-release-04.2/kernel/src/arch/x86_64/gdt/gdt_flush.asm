; Vex OS - kernel/src/arch/x86_64/gdt/gdt_flush.asm
;
; gdt_flush(GdtPtr *ptr): loads the GDTR, reloads all data segment
; registers to the kernel data selector, and reloads CS to the kernel
; code selector. CS cannot be reloaded with a plain `mov` - the only
; way is a far jump/call/return that specifies a new selector; this
; uses the standard far-return trick (push target selector:offset,
; then retfq).
;
; tss_load(selector): loads the Task Register via `ltr`. A single
; instruction, but kept in asm for consistency with gdt_flush and
; because `ltr` operates on a 16-bit selector value in a way that's
; easiest to express directly here.
;
; tss_read(): returns the Task Register selector via `str`. KERNEL-01
; Phase 1 added this so the self-tests can ask the CPU which TSS it is
; actually holding, instead of trusting that the code which was supposed
; to call tss_load did call it. "ltr was issued" and "TR contains this
; selector" are different claims and only the second one is evidence.

BITS 64

section .text

global gdt_flush
gdt_flush:
    lgdt [rdi]

    mov ax, 0x10        ; GDT_SEL_KERNEL_DATA
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax

    ; Reload CS via far return: push the target selector, then the
    ; target offset (address of .reload_cs), then retfq pops both
    ; and jumps, updating CS as a side effect.
    push qword 0x08      ; GDT_SEL_KERNEL_CODE
    lea rax, [rel .reload_cs]
    push rax
    retfq
.reload_cs:
    ret

global tss_load
tss_load:
    ; rdi = selector (uint16_t, passed in the low 16 bits of rdi per
    ; System V AMD64 - upper bits are unspecified, so mask them)
    and rdi, 0xFFFF
    ltr di
    ret

global tss_read
tss_read:
    ; `str` writes the 16-bit TR selector to its operand. Zero the whole
    ; of rax first so the uint16_t return value has no stale high bits;
    ; str only touches ax.
    xor rax, rax
    str ax
    ret

section .note.GNU-stack noalloc noexec nowrite progbits
