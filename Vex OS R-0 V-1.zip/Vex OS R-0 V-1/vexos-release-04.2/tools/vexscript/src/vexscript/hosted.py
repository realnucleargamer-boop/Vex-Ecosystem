"""Hosted vex::* API stubs (Phase D).

These are NOT Vex OS kernel/syscalls. They exist for API design validation
and hosted testing only. Real backends will map the same names later.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable

# Opaque handle: non-zero u64-style integers in hosted mode
_next_handle = 1


def _alloc_handle() -> int:
    global _next_handle
    h = _next_handle
    _next_handle += 1
    return h


@dataclass
class HostedFS:
    """In-memory virtual filesystem only — no real host paths."""
    files: dict[str, bytes] = field(default_factory=dict)
    open_files: dict[int, dict] = field(default_factory=dict)

    def open(self, path: str, mode: str = "r") -> int:
        path = str(path)
        if mode.startswith("w") and path not in self.files:
            self.files[path] = b""
        if path not in self.files:
            return 0  # invalid handle
        h = _alloc_handle()
        self.open_files[h] = {"path": path, "pos": 0, "mode": mode}
        return h

    def close(self, handle: int) -> int:
        self.open_files.pop(int(handle), None)
        return 0

    def read(self, handle: int, max_len: int = 256) -> str:
        meta = self.open_files.get(int(handle))
        if not meta:
            return ""
        data = self.files.get(meta["path"], b"")
        pos = meta["pos"]
        chunk = data[pos : pos + int(max_len)]
        meta["pos"] = pos + len(chunk)
        return chunk.decode("utf-8", errors="replace")

    def write(self, handle: int, text: str) -> int:
        meta = self.open_files.get(int(handle))
        if not meta:
            return -1
        path = meta["path"]
        data = self.files.get(path, b"")
        encoded = str(text).encode("utf-8")
        # append
        self.files[path] = data + encoded
        meta["pos"] = len(self.files[path])
        return len(encoded)


@dataclass
class HostedState:
    fs: HostedFS = field(default_factory=HostedFS)
    current_pid: int = 1
    processes: dict[int, str] = field(default_factory=lambda: {1: "main"})
    current_tid: int = 1


_STATE = HostedState()


def reset_hosted_state() -> None:
    global _STATE, _next_handle
    _STATE = HostedState()
    _next_handle = 1


# ── API implementations ──────────────────────────────

def info_os_name() -> str:
    return "Vex OS"


def info_version() -> str:
    return "hosted"


def info_api_version() -> str:
    return "0.1"


def time_now() -> int:
    """Deterministic-ish hosted monotonic counter (milliseconds scale)."""
    import time as _t
    return int(_t.monotonic() * 1000) & 0x7FFFFFFFFFFFFFFF


def time_sleep(ms: int) -> int:
    """Hosted sleep capped at 100ms for tests; not a kernel sleep."""
    import time as _t
    ms = max(0, min(int(ms), 100))
    if ms:
        _t.sleep(ms / 1000.0)
    return 0


def fs_open(path: str, mode: str = "r") -> int:
    return _STATE.fs.open(str(path), str(mode) if mode else "r")


def fs_close(handle: int) -> int:
    return _STATE.fs.close(int(handle))


def fs_read(handle: int) -> str:
    return _STATE.fs.read(int(handle))


def fs_write(handle: int, text: str) -> int:
    return _STATE.fs.write(int(handle), str(text))


def proc_get_id() -> int:
    return _STATE.current_pid


def proc_spawn(name: str) -> int:
    """Synthetic process handle only — does not spawn host processes."""
    h = _alloc_handle()
    _STATE.processes[h] = str(name)
    return h


def proc_exit(code: int) -> int:
    """Stub: records intent only; does not terminate host process."""
    return int(code)


def thread_current() -> int:
    return _STATE.current_tid


def thread_spawn() -> int:
    """Synthetic thread handle — no host thread created."""
    return _alloc_handle()


def thread_yield() -> int:
    return 0


def input_poll() -> int:
    """0 = no_event (deterministic hosted stub)."""
    return 0


def input_wait() -> int:
    """Same as poll in Phase D — no real input device."""
    return 0


# Fully qualified name → callable
HOSTED_BUILTINS: dict[str, Callable] = {
    "vex::info::os_name": info_os_name,
    "vex::info::version": info_version,
    "vex::info::api_version": info_api_version,
    "vex::time::now": time_now,
    "vex::time::sleep": time_sleep,
    "vex::fs::open": fs_open,
    "vex::fs::close": fs_close,
    "vex::fs::read": fs_read,
    "vex::fs::write": fs_write,
    "vex::proc::get_id": proc_get_id,
    "vex::proc::spawn": proc_spawn,
    "vex::proc::exit": proc_exit,
    "vex::thread::current": thread_current,
    "vex::thread::spawn": thread_spawn,
    "vex::thread::yield": thread_yield,
    "vex::input::poll": input_poll,
    "vex::input::wait": input_wait,
}

# For typechecker: name → (param types, return type)
HOSTED_SIGNATURES: dict[str, tuple[list[str], str]] = {
    "vex::info::os_name": ([], "string"),
    "vex::info::version": ([], "string"),
    "vex::info::api_version": ([], "string"),
    "vex::time::now": ([], "i64"),
    "vex::time::sleep": (["i64"], "i64"),
    "vex::fs::open": (["string", "string"], "i64"),  # returns Handle as i64
    "vex::fs::close": (["i64"], "i64"),
    "vex::fs::read": (["i64"], "string"),
    "vex::fs::write": (["i64", "string"], "i64"),
    "vex::proc::get_id": ([], "i64"),
    "vex::proc::spawn": (["string"], "i64"),
    "vex::proc::exit": (["i64"], "i64"),
    "vex::thread::current": ([], "i64"),
    "vex::thread::spawn": ([], "i64"),
    "vex::thread::yield": ([], "i64"),
    "vex::input::poll": ([], "i64"),
    "vex::input::wait": ([], "i64"),
}

# Namespace → list of public function short names
HOSTED_NAMESPACES: dict[str, list[str]] = {
    "vex::info": ["os_name", "version", "api_version"],
    "vex::time": ["now", "sleep"],
    "vex::fs": ["open", "close", "read", "write"],
    "vex::proc": ["get_id", "spawn", "exit"],
    "vex::thread": ["current", "spawn", "yield"],
    "vex::input": ["poll", "wait"],
}
