/*
 * Vex OS - kernel/src/graphics/gfx_progress.c
 *
 * See kernel/include/gfx/progress.h for the design rationale.
 *
 * Deliberately does not full-screen clear on every update: the static
 * chrome (title, subtitle label, bar outline) is drawn exactly once by
 * gfx_boot_splash_init(); gfx_boot_splash_render() only repaints the
 * message line and the bar's fill region, which is the per-frame work
 * the Graphics 2 brief asks to avoid doing unnecessarily.
 */

#include "gfx/progress.h"
#include "gfx/draw.h"
#include "gfx/text.h"

static const GfxFb *g_fb;      /* bound framebuffer, may be 0 */
static int32_t g_bar_x, g_bar_y, g_bar_w, g_bar_h;
static int32_t g_msg_x, g_msg_y, g_msg_w;
static int32_t g_pct_x, g_pct_y;
static int     g_last_percent = -1;

/* No snprintf in this freestanding kernel (consistent with every other
 * gfx_*.c file in the tree) - a tiny local formatter is cheaper and
 * clearer than pulling one in for three digits and a '%'. */
static void fmt_percent(char *out, int percent)
{
    int i = 0;
    if (percent < 0) percent = 0;
    if (percent > 100) percent = 100;
    if (percent >= 100) {
        out[i++] = '1'; out[i++] = '0'; out[i++] = '0';
    } else if (percent >= 10) {
        out[i++] = (char)('0' + percent / 10);
        out[i++] = (char)('0' + percent % 10);
    } else {
        out[i++] = (char)('0' + percent);
    }
    out[i++] = '%';
    out[i] = '\0';
}

void gfx_boot_splash_bind(const GfxFb *fb)
{
    g_fb = fb;
}

void gfx_boot_splash_init(const GfxFb *fb)
{
    if (!fb || !fb->ok) return;
    g_fb = fb;
    g_last_percent = -1;

    gfx_clear(fb, GFX_DARK_BG);

    /* Title, centred-ish. No scaled font exists, so a 1px "bold" smear
     * (draw it twice, offset by one pixel) keeps it readable as a
     * title without pulling in a second font. Small, static, cheap -
     * drawn exactly once here, never again. */
    int32_t title_x = (int32_t)fb->width / 2 - (6 * GFX_FONT_W) / 2;
    int32_t title_y = (int32_t)fb->height * 30 / 100;
    gfx_draw_str(fb, title_x,     title_y, "VEX OS", GFX_WHITE, GFX_DARK_BG);
    gfx_draw_str(fb, title_x + 1, title_y, "VEX OS", GFX_WHITE, GFX_DARK_BG);

    const char *subtitle = "Graphics 2 boot";
    int32_t sub_x = (int32_t)fb->width / 2 - (15 * GFX_FONT_W) / 2;
    int32_t sub_y = title_y + GFX_FONT_H + 6;
    gfx_draw_str(fb, sub_x, sub_y, subtitle, GFX_DIM, GFX_DARK_BG);

    /* Bar geometry, resolution-independent. */
    g_bar_w = (int32_t)fb->width * 50 / 100;
    g_bar_h = 22;
    g_bar_x = (int32_t)fb->width / 2 - g_bar_w / 2;
    g_bar_y = (int32_t)fb->height * 58 / 100;

    gfx_rect_outline(fb, g_bar_x - 2, g_bar_y - 2, g_bar_w + 4, g_bar_h + 4, GFX_BORDER);
    gfx_fill_rect(fb, g_bar_x, g_bar_y, g_bar_w, g_bar_h, GFX_PANEL_BG);

    g_pct_x = g_bar_x + g_bar_w + 12;
    g_pct_y = g_bar_y + (g_bar_h - GFX_FONT_H) / 2;

    /* Message line sits below the bar; clearing g_msg_w wide (not
     * strlen-dependent) means a shorter message never leaves stale
     * glyphs from a longer previous one. */
    g_msg_x = g_bar_x;
    g_msg_y = g_bar_y + g_bar_h + 14;
    g_msg_w = g_bar_w + 80;
}

void gfx_boot_splash_render(const BootProgress *state)
{
    const GfxFb *fb = g_fb;
    if (!fb || !fb->ok || !state) return;

    int percent = state->percent;
    if (percent < 0) percent = 0;
    if (percent > 100) percent = 100;

    if (percent != g_last_percent) {
        int32_t fill_w = g_bar_w * percent / 100;
        /* Repaint the bar interior only (background + proportional
         * fill), never the surrounding outline/title/subtitle. */
        gfx_fill_rect(fb, g_bar_x, g_bar_y, g_bar_w, g_bar_h, GFX_PANEL_BG);
        if (fill_w > 0) {
            gfx_fill_rect(fb, g_bar_x, g_bar_y, fill_w, g_bar_h, GFX_ACCENT);
        }
        char pct_buf[6];
        fmt_percent(pct_buf, percent);
        gfx_draw_str(fb, g_pct_x, g_pct_y, pct_buf, GFX_TEXT, GFX_DARK_BG);
        g_last_percent = percent;
    }

    /* Message line: clear the fixed-width region, then draw. */
    gfx_fill_rect(fb, g_msg_x, g_msg_y, g_msg_w, GFX_FONT_H, GFX_DARK_BG);
    gfx_draw_str(fb, g_msg_x, g_msg_y, state->message, GFX_DIM, GFX_DARK_BG);
}
