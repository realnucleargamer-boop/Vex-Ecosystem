; Vex OS - kernel/src/arch/x86_64/cpu/ring3_transition.asm
;
; SECURITY-02: the actual Ring 0 -> Ring 3 transition, and the
; checkpoint save/restore pair that lets the kernel get back to a known
; safe point after a Ring 3 program exits OR faults - the fault case is
; why a plain C function call cannot be used here: a fault is detected
; deep inside the interrupt handler's own call stack, with no normal
; return path back to whoever started the Ring 3 program. This is the
; same "last known good point" idea GDT_DF_STACK_SIZE/IST1 exists for
; at the CPU level, implemented here at the C-call level with a
; hand-written, classic setjmp/longjmp pair - consistent with this
; kernel having no libc and therefore no <setjmp.h>.

BITS 64
section .text

; ---------------------------------------------------------------- *
; int ring3_checkpoint_save(Ring3Checkpoint *cp);   [rdi = cp]
;
; Saves every callee-saved register, the caller's RSP, and the
; caller's own return address into *cp, then returns 0 - exactly like
; setjmp(). A later ring3_checkpoint_restore(cp, n) makes this same
; call appear to return `n` instead, from a completely different
; point in the program (possibly interrupt context). Layout (8 qwords,
; see ring3.h's Ring3Checkpoint, which this must stay in lockstep
; with): rbx, rbp, r12, r13, r14, r15, rsp, rip.
; ---------------------------------------------------------------- *
global ring3_checkpoint_save
ring3_checkpoint_save:
    mov [rdi + 0],  rbx
    mov [rdi + 8],  rbp
    mov [rdi + 16], r12
    mov [rdi + 24], r13
    mov [rdi + 32], r14
    mov [rdi + 40], r15
    lea rax, [rsp + 8]        ; caller's RSP (above our own return addr)
    mov [rdi + 48], rax
    mov rax, [rsp]             ; our return address = where the caller resumes
    mov [rdi + 56], rax
    xor eax, eax                ; "save" path always returns 0
    ret

; ---------------------------------------------------------------- *
; void ring3_checkpoint_restore(Ring3Checkpoint *cp, int retval);
;   [rdi = cp, rsi = retval]
;
; Never returns to its caller. Restores the registers/RSP saved by
; ring3_checkpoint_save() and jumps to the saved return address, with
; `retval` in RAX - i.e. makes the ORIGINAL ring3_checkpoint_save()
; call site resume as if it had just returned `retval`. Safe to call
; from deep inside interrupt-handler C code (idt_common_handler's own
; call stack is simply abandoned, not unwound - there is nothing on it
; that owns a resource needing release; see ring3.c).
; ---------------------------------------------------------------- *
global ring3_checkpoint_restore
ring3_checkpoint_restore:
    mov rbx, [rdi + 0]
    mov rbp, [rdi + 8]
    mov r12, [rdi + 16]
    mov r13, [rdi + 24]
    mov r14, [rdi + 32]
    mov r15, [rdi + 40]
    mov rax, rsi                ; return value
    mov rcx, [rdi + 56]          ; saved RIP
    mov rsp, [rdi + 48]           ; saved RSP (restored LAST, after reading
                                    ; everything else out of *cp via rdi/rcx,
                                    ; which do not depend on the new stack)
    jmp rcx

; ---------------------------------------------------------------- *
; void ring3_enter(uint64_t entry_rip, uint64_t user_rsp,
;                   uint64_t arg0, uint64_t arg1);
;   [rdi = entry_rip, rsi = user_rsp, rdx = arg0, rcx = arg1]
;
; The actual Ring 0 -> Ring 3 transition. Builds the 5-qword hardware
; IRETQ frame by hand (SS, RSP, RFLAGS, CS, RIP - pushed in that
; reverse order so IRETQ pops them in the order the architecture
; requires). Selector values (0x1B = user code, 0x23 = user data) are
; GDT_SEL_USER_CODE/GDT_SEL_USER_DATA from kernel/include/gdt.h,
; hardcoded here the same way isr_stubs.asm hardcodes
; GDT_SEL_KERNEL_CODE - this file cannot #include a C header, so the
; numeric values are the source of truth on this side, and a
; _Static_assert in ring3.c checks they still match gdt.h's macros.
;
; Does not return in the normal sense: execution continues in Ring 3
; at `entry_rip`. The caller gets control back only via a syscall
; (SYS_EXIT) or a fault, both of which resume execution at the
; checkpoint saved by ring3_checkpoint_save() just before calling this
; - never by this function's own `ret`.
; ---------------------------------------------------------------- *
global ring3_enter
ring3_enter:
    mov rax, rdi          ; entry_rip
    mov rbx, rsi            ; user_rsp
    mov r8,  rdx              ; arg0 -> user RDI
    mov r9,  rcx               ; arg1 -> user RSI

    ; No DS/ES/FS/GS loads here, deliberately. In 64-bit mode they do
    ; not participate in addressing, IRETQ to Ring 3 nulls any of them
    ; that still hold a DPL0 selector, and - the reason this matters -
    ; a `mov gs, reg` reloads the hidden GS base from the descriptor,
    ; which would destroy IA32_GS_BASE, the kernel's per-CPU pointer
    ; (percpu.c reads %gs:0). The GS base hand-off is done with swapgs
    ; below instead; ring3.c has already zeroed IA32_KERNEL_GS_BASE so
    ; that swapgs leaves GS base = 0 for Ring 3 and parks the per-CPU
    ; pointer in KERNEL_GS_BASE, where isr_common's entry swapgs finds it.
    push qword 0x23                ; SS
    push rbx                        ; RSP
    pushfq
    pop r11
    or r11, 0x200                    ; IF set, conventional
    push r11                          ; RFLAGS
    push qword 0x1B                    ; CS = GDT_SEL_USER_CODE
    push rax                            ; RIP = entry_rip

    mov rdi, r8                          ; user arg0
    mov rsi, r9                           ; user arg1
    ; Scrub every other general-purpose register so Ring 3 does not
    ; start with kernel values (pointers, flags, saved args) left in
    ; them - an information leak that would otherwise hand Ring 3 kernel
    ; addresses. The callee-saved ones are not lost: ring3_checkpoint_save
    ; already captured them, and a restore reloads them.
    xor eax, eax
    xor ebx, ebx
    xor ecx, ecx
    xor edx, edx
    xor ebp, ebp
    xor r8d,  r8d
    xor r9d,  r9d
    xor r10d, r10d
    xor r11d, r11d
    xor r12d, r12d
    xor r13d, r13d
    xor r14d, r14d
    xor r15d, r15d
    swapgs                                 ; GS base := user (0); per-CPU -> KERNEL_GS_BASE
    iretq

section .note.GNU-stack noalloc noexec nowrite progbits
