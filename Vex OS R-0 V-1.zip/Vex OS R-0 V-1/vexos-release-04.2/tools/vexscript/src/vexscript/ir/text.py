"""Deterministic textual form of Vex IR 1.4."""
from __future__ import annotations
from .nodes import ModuleIR, Instruction, Value, IR_VERSION


def _val(v: Value) -> str:
    return v.text


def _inst(inst: Instruction) -> str:
    if inst.op == "const":
        lit = inst.extra
        if inst.ty == "bool":
            lit = "true" if lit else "false"
        elif inst.ty == "string":
            lit = repr(str(lit))
        return f"{inst.dest} = const.{inst.ty} {lit}"
    if inst.op == "ret":
        if not inst.args:
            return "ret void"
        return f"ret {inst.ty} {_val(inst.args[0])}"
    if inst.op == "br":
        return f"br {inst.extra}"
    if inst.op == "br_cond":
        t, f = inst.extra
        return f"br_cond {_val(inst.args[0])}, {t}, {f}"
    if inst.op == "call":
        args = ", ".join(_val(a) for a in inst.args)
        dest = f"{inst.dest} = " if inst.dest else ""
        return f"{dest}call {inst.ty} @{inst.extra}({args})"
    if inst.op in ("add", "sub", "mul", "div", "mod", "eq", "ne", "lt", "le", "gt", "ge", "and", "or"):
        return f"{inst.dest} = {inst.op}.{inst.ty} {_val(inst.args[0])}, {_val(inst.args[1])}"
    if inst.op in ("not", "copy"):
        return f"{inst.dest} = {inst.op}.{inst.ty} {_val(inst.args[0])}"
    if inst.op == "load_local":
        return f"{inst.dest} = load_local.{inst.ty} {inst.extra}"
    if inst.op == "store_local":
        return f"store_local.{inst.ty} {inst.extra}, {_val(inst.args[0])}"
    if inst.op == "make_struct":
        args = ", ".join(_val(a) for a in inst.args)
        return f"{inst.dest} = make_struct.{inst.ty} [{inst.extra}] ({args})"
    if inst.op == "make_array":
        args = ", ".join(_val(a) for a in inst.args)
        return f"{inst.dest} = make_array.{inst.ty} n={inst.extra} ({args})"
    if inst.op == "index":
        return f"{inst.dest} = index.{inst.ty} {_val(inst.args[0])}, {_val(inst.args[1])}"
    if inst.op == "extract":
        return f"{inst.dest} = extract.{inst.ty} {_val(inst.args[0])}, {inst.extra}"
    if inst.op == "insert":
        return f"{inst.dest} = insert.{inst.ty} {_val(inst.args[0])}, {inst.extra}, {_val(inst.args[1])}"
    args = ", ".join(_val(a) for a in inst.args)
    dest = f"{inst.dest} = " if inst.dest else ""
    return f"{dest}{inst.op}.{inst.ty} {args}".rstrip()


def module_to_text(mod: ModuleIR) -> str:
    lines: list[str] = []
    ver = getattr(mod, "ir_version", IR_VERSION) or IR_VERSION
    lines.append(f"; Vex IR {ver}")
    lines.append(f"ir_version {ver}")
    cc = getattr(mod, "calling_conv", None)
    if cc:
        lines.append(f"calling_conv {cc}")
    lines.append("")

    structs = getattr(mod, "structs", None) or {}
    for name in sorted(structs.keys()):
        fields = structs[name]
        rendered = ", ".join(f"{fn}: {ft}" for fn, ft in fields)
        lines.append(f"struct {name} {{ {rendered} }}")
        lines.append("")

    for fn in sorted(mod.functions, key=lambda f: f.name):
        params = ", ".join(f"{n}: {t}" for n, t in fn.params)
        lines.append(f"func @{fn.name}({params}) -> {fn.return_type} {{")
        for b in fn.blocks:
            lines.append(f"block {b.name}:")
            for inst in b.instructions:
                lines.append(f"  {_inst(inst)}")
            if b.terminator:
                lines.append(f"  {_inst(b.terminator)}")
        lines.append("}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"
