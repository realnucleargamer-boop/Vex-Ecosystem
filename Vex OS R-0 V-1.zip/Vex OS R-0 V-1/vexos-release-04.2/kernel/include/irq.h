/*
 * Vex OS - kernel/include/irq.h
 *
 * KERNEL-01 Phase 2: generic interrupt-handler registration.
 *
 * WHAT THIS REPLACES
 *
 *   Until this phase, idt_common_handler() recognized exactly one
 *   interrupt vector, with a hardcoded `if (frame->vector ==
 *   TIMER_VECTOR)`. That was honest for BOOT-03, which had exactly one
 *   interrupt source. It does not survive KERNEL-01: TLB shootdown needs
 *   its own vector, the IPI self-tests need a scratch vector, and each
 *   new source added as another `if` makes the dispatcher a place where
 *   unrelated subsystems collide.
 *
 *   This is a table, not a framework. 256 slots, one function pointer
 *   each, a name for diagnostics, and a per-vector delivery counter.
 *   There is no interrupt threading, no deferred/bottom-half mechanism,
 *   no priority manipulation, no IRQ sharing and no per-CPU handler
 *   override. Those are not needed by anything in this milestone, and a
 *   mechanism with no consumer cannot be tested.
 *
 * CONCURRENCY RULE (load-bearing)
 *
 *   The table is written only during single-threaded initialization, on
 *   the BSP, before the vector in question can be delivered. After that
 *   it is read-only. That is what makes the dispatch path lock-free:
 *   the interrupt handler performs a plain read of one slot and never
 *   takes a lock, which it must not do, because the shootdown receiver
 *   runs from this path and is required to acquire no VMM or PMM lock.
 *
 *   irq_register() enforces the first half of that rule by refusing to
 *   overwrite an occupied slot with a different handler. It cannot
 *   enforce "before delivery is possible" - that is a call-ordering
 *   obligation on the caller, stated here and checked by the Phase 2
 *   self-tests inasmuch as they verify the expected vectors are
 *   registered before interrupts are enabled anywhere.
 *
 * EOI IS THE HANDLER'S JOB
 *
 *   A registered handler must issue lapic_send_eoi() itself. The
 *   dispatcher deliberately does not do it on the handler's behalf,
 *   because "every interrupt gets an EOI" is false: the LAPIC spurious
 *   vector must NOT be acknowledged (no in-service bit is set for it),
 *   and acknowledging it would dismiss an unrelated interrupt that is
 *   genuinely in service. Making EOI implicit would hide that
 *   distinction inside the one function where getting it wrong presents
 *   as "the timer fired exactly once".
 *
 * VECTOR RANGE
 *
 *   Vectors 0-31 are the architecturally-defined exception range and are
 *   NOT registerable: they are handled by the exception path in idt.c,
 *   which panics with a decoded name and, for #PF, runs the BOOT-03
 *   recovery hook. Allowing a driver to capture vector 14 would silently
 *   disable page-fault reporting. Vector 0xFF is the LAPIC spurious
 *   vector and is also refused, for the EOI reason above.
 */

#ifndef VEXOS_IRQ_H
#define VEXOS_IRQ_H

#include <stdint.h>
#include "idt.h"

/* Lowest registerable vector: the first one above the exception range. */
#define IRQ_FIRST_VECTOR 32

typedef void (*IrqHandler)(InterruptFrame *frame);

typedef enum {
    IRQ_OK = 0,
    IRQ_ERR_BAD_VECTOR,      /* in the exception range, or the spurious vector */
    IRQ_ERR_NULL_HANDLER,
    IRQ_ERR_TAKEN,           /* occupied by a DIFFERENT handler */
    IRQ_ERR_NOT_REGISTERED
} IrqResult;

/* Installs `fn` for `vector`. `name` is retained by pointer for
 * diagnostics and must have static lifetime.
 *
 * Registering the handler that is already installed for that vector
 * returns IRQ_OK and changes nothing. That idempotence is deliberate:
 * timer_init() may run on more than one CPU, and the second call is not
 * an error - whereas a DIFFERENT handler arriving for an occupied vector
 * is a genuine collision between two subsystems and is refused. */
IrqResult irq_register(uint32_t vector, IrqHandler fn, const char *name);

/* Removes the handler for `vector`. Present so that the registration
 * mechanism can be shown to be reversible, and so a self-test can use a
 * scratch vector without leaving it permanently occupied. Must not be
 * called while the vector can still be delivered. */
IrqResult irq_unregister(uint32_t vector);

/* The installed handler, or 0. Lets a test assert that a vector really
 * is wired to the function it expects, rather than that a registration
 * call was issued somewhere. */
IrqHandler irq_handler_for(uint32_t vector);

/* The registered name, or "(unregistered)". Never returns 0. */
const char *irq_name_for(uint32_t vector);

/* How many times the dispatcher has invoked the handler for `vector`.
 * Counted by the dispatcher, not the handler, so it measures dispatch
 * rather than what the handler chose to record. */
uint64_t irq_dispatch_count(uint32_t vector);

/* Interrupts delivered at or above IRQ_FIRST_VECTOR with no registered
 * handler. Should be 0 on a healthy boot; a non-zero value means
 * something is firing that nothing claims. */
uint64_t irq_unhandled_count(void);

/* LAPIC spurious-vector deliveries. Counted separately from unhandled
 * because a spurious interrupt is an expected hardware event, not a
 * missing handler, and is the one vector that must not be EOI'd. */
uint64_t irq_spurious_count(void);

/* Occupied slots. */
uint32_t irq_registered_count(void);

/* Human-readable IrqResult. */
const char *irq_result_name(IrqResult r);

#endif /* VEXOS_IRQ_H */
