/*
 * Vex OS - kernel/linker.ld
 *
 * BOOT-01 linker script. Links the kernel to run at the fixed
 * physical address VEX_KERNEL_LOAD_PHYS (see
 * common/include/boot_layout.h - 0x100000 / 1 MiB). This is a
 * temporary, pre-paging arrangement: once the paging milestone lands,
 * the kernel moves to the frozen higher-half virtual layout
 * (kernel_virtual_base = 0xFFFFFFFF80000000) and this script is
 * revised under architecture review, not silently.
 *
 * ENTRY(_start) points at the NASM stub in
 * arch/x86_64/boot/start.asm, which is deliberately the very first
 * code in the image, since the bootloader jumps to byte 0 of the
 * loaded flat binary.
 */

ENTRY(_start)

/* Keep in sync with common/include/boot_layout.h VEX_KERNEL_LOAD_PHYS */
KERNEL_LOAD_ADDR = 0x100000;

SECTIONS
{
    . = KERNEL_LOAD_ADDR;

    /* The kernel's true runtime footprint.
     *
     * These exist because BootInfo.kernel_physical_size is the size of
     * the LOADED FLAT BINARY, and .bss is NOBITS - it is not in that
     * binary. The loaded size therefore understates how much memory the
     * kernel actually occupies at run time, by the whole of .bss (which
     * includes the boot stack). Anything that reserves or places memory
     * based on the loaded size alone will happily hand out the kernel's
     * own stack. Use __kernel_end, not the BootInfo size, for that. */
    __kernel_start = .;

    .text : ALIGN(4096)
    {
        __text_start = .;
        *(.text.start)   /* start.asm's _start must land first in the image */
        *(.text*)
        __text_end = .;
    }

    .rodata : ALIGN(4096)
    {
        __rodata_start = .;
        *(.rodata*)
        __rodata_end = .;
    }

    .data : ALIGN(4096)
    {
        __data_start = .;
        *(.data*)
        __data_end = .;
    }

    .bss : ALIGN(4096)
    {
        __bss_start = .;
        *(COMMON)
        *(.bss*)
        . = ALIGN(8);        /* start.asm zeroes .bss 8 bytes at a time */
        __bss_end = .;
    }

    /* One past the last byte the kernel occupies at run time. */
    __kernel_end = ALIGN(4096);

    /DISCARD/ :
    {
        *(.comment)
        *(.eh_frame)
        *(.note*)
    }
}
