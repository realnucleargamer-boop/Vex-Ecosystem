/*
 * Vex OS - kernel/include/vfs.h : minimal in-memory virtual filesystem.
 *
 * HONESTY: this is VOLATILE. It lives in RAM and is empty again after every boot; vfs_persistent() is 0. VEX OS has
 * no block driver, so no file survives a reboot, and nothing here pretends otherwise. Files carry NO content
 * (size 0): this release implements directories and file *creation*, not reading/writing data.
 * Layout at init: "/" , "/home" (admin-owned), "/tmp" (world-writable). Each account gets "/home/<id>" owned by it.
 * Permission model (the one that exists): admin may create anywhere; a standard user may create only in
 * directories they own or that are world-writable. Names: 1..31 of A-Z a-z 0-9 space . _ - ; never "." / ".."; no '/'.
 * Paths are resolved component by component and ".." is REJECTED, so a path cannot escape upward by traversal.
 */
#ifndef VEXOS_VFS_H
#define VEXOS_VFS_H
#include <stdint.h>
#define VFS_MAX_NODES 96
#define VFS_NAME_MAX 31
#define VFS_DATA_MAX 2048              /* bytes of content per file (static pool: 96 x 2 KiB) */
typedef enum { VFS_OK = 0, VFS_ERR_NAME = -1, VFS_ERR_EXISTS = -2, VFS_ERR_NOTFOUND = -3, VFS_ERR_NOTDIR = -4,
               VFS_ERR_DENIED = -5, VFS_ERR_FULL = -6, VFS_ERR_PATH = -7, VFS_ERR_NOTEMPTY = -8, VFS_ERR_TOOBIG = -9 } VfsResult;
typedef struct { char name[VFS_NAME_MAX + 1]; uint8_t used, is_dir, world_writable; int16_t parent; uint32_t owner_uid; uint16_t size; uint64_t mtime_ms; } VfsNode;   /* mtime = uptime ms (volatile FS: same boot only) */
void vfs_init(void);
int  vfs_persistent(void);
int  vfs_root(void);
int  vfs_resolve(const char *path);                         /* node index or negative VfsResult */
VfsResult vfs_validate_name(const char *name);
int  vfs_create(int dir, const char *name, int is_dir, uint32_t uid, int admin);   /* new node index or negative VfsResult */
int  vfs_ensure_home(uint32_t uid, const char *id);          /* creates /home/<id> owned by uid if missing */
int  vfs_list(int dir, int *out, int max);                   /* children, directories first, then by creation order */
const VfsNode *vfs_node(int i);
int  vfs_parent(int i);                                      /* parent index, root's parent is root */
int  vfs_path(int i, char *buf, int cap);                    /* absolute path; returns length or -1 */
int  vfs_count(void);
/* File content (this release): bounded, volatile. All mutations validate FIRST and then commit, so a failure leaves the file as it was. */
int  vfs_write(int node, const char *data, int len, uint32_t uid, int admin);    /* 0 or negative VfsResult; replaces content */
int  vfs_read(int node, char *out, int cap);                                      /* bytes copied (NUL-terminated if room), or negative */
int  vfs_rename(int node, const char *newname, uint32_t uid, int admin);          /* 0 or negative VfsResult; never overwrites */
int  vfs_delete(int node, uint32_t uid, int admin);                               /* files and EMPTY folders; "/", /home, /tmp are protected */
int  vfs_can_read(int node, uint32_t uid, int admin);                             /* non-admins cannot read inside another user's home */
int  vfs_search(const char *query, uint32_t uid, int admin, int *out, int max);   /* case-insensitive name substring over READABLE nodes */
const char *vfs_errmsg(int code);
#endif
