#!/usr/bin/env python3
"""VexScript 2.0 Phase A — import / pub / privacy"""
import sys, io
from pathlib import Path
from contextlib import redirect_stdout

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vexscript.interpreter import Interpreter
from vexscript.errors import VexError

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

def run(src, path="<t>"):
    i = Interpreter()
    b = io.StringIO()
    with redirect_stdout(b):
        i.load(src, path)
        c = i.run_main()
    return c, b.getvalue()

def ok(src, exp, name, path=None):
    try:
        p = path or str(ROOT / "examples" / "_tmp_main.vex")
        if path is None:
            # write next to modules
            pass
        c, o = run(src, path or "<t>")
        check(name, c == 0 and (exp is None or o == exp or exp in o), f"rc={c} out={o!r}")
    except VexError as e:
        check(name, False, str(e))

def fail(src, name, code=None, path="<t>"):
    try:
        run(src, path)
        check(name, False, "should fail")
    except VexError as e:
        msg = str(e)
        okc = code is None or f"error[{code}]" in msg or code in msg
        check(name, okc, msg)

print("VexScript 2.0 Phase A Tests")

ex = ROOT / "examples"

# ensure pub math module
(ex / "math_mod.vex").write_text("""
pub fn add(a: i64, b: i64) -> i64 { return a + b; }
pub fn square(x: i64) -> i64 { return x * x; }
fn secret() -> i64 { return 42; }
""")

print("\n=== import ===")
ok("""
import math_mod;
fn main() -> i32 {
    println(math_mod::add(2, 3));
    return 0;
}
""", "5\n", "simple import", str(ex / "pa_import.vex"))

ok("""
import math_mod::{ add };
fn main() -> i32 {
    println(add(10, 1));
    return 0;
}
""", "11\n", "selective import", str(ex / "pa_sel.vex"))

ok("""
use math_mod;
fn main() -> i32 {
    println(math_mod::square(4));
    return 0;
}
""", "16\n", "deprecated use still works", str(ex / "pa_use.vex"))

print("\n=== privacy ===")
fail("""
import math_mod;
fn main() -> i32 {
    math_mod::secret();
    return 0;
}
""", "private symbol rejected", "E0004", str(ex / "pa_priv.vex"))

ok("""
import math_mod;
fn main() -> i32 {
    println(math_mod::add(1, 1));
    return 0;
}
""", "2\n", "public symbol ok", str(ex / "pa_pub.vex"))

print("\n=== errors ===")
fail("import nope;\nfn main() -> i32 { return 0; }\n", "missing module", "E0001", str(ex / "pa_miss.vex"))

fail("""
import math_mod;
import math_mod;
fn main() -> i32 { return 0; }
""", "duplicate import", "E0005", str(ex / "pa_dup.vex"))

fail("""
import math_mod::{ nope };
fn main() -> i32 { return 0; }
""", "missing symbol selective", "E0003", str(ex / "pa_nosym.vex"))

# cycle: a imports b, b imports a
(ex / "cyc_a.vex").write_text("import cyc_b;\npub fn a() -> i64 { return 1; }\n")
(ex / "cyc_b.vex").write_text("import cyc_a;\npub fn b() -> i64 { return 2; }\n")
fail("""
import cyc_a;
fn main() -> i32 { return 0; }
""", "import cycle", "E0002", str(ex / "pa_cyc.vex"))

print("\n=== diagnostics format ===")
try:
    run("import missing_xyz;\nfn main() -> i32 { return 0; }\n", str(ex / "diag.vex"))
    check("diag location", False)
except VexError as e:
    m = str(e)
    check("diag has file", "diag.vex" in m, m)
    check("diag has E code", "E0001" in m, m)
    check("diag has line", ":1:" in m or ":2:" in m, m)

print(f"\n=== Phase A Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
