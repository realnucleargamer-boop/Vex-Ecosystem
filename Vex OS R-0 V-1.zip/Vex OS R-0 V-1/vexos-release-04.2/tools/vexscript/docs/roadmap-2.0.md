# VEX-Script Roadmap — 2.0 and beyond

## VEX-Script 1.1 (current)
- Reference interpreter
- 1.0 surface preserved
- Modules (minimal), control-flow completion, Option/Result helpers, string basics, diagnostics

## VEX-Script 2.0 — Planned
- Real module system with visibility
- Generics (restricted)
- Proper struct operations and methods
- Ownership / simplified borrow rules (or explicit lifetimes)
- Intermediate Representation (Vex IR)
- First compiler backend (x86-64 or C)
- Expanded standard library
- Stable interop surface for Vex AI and Vex OS (handles + documented APIs only)

## VEX-Script 2.0+++ / future stable
- Self-hosting
- Package manager
- Async / structured concurrency (if still desired)
- Macros
- Advanced FFI
- Full performance toolchain
- Official language standard document

## Long-term vision
VEX-Script becomes the high-level language of the Vex ecosystem:
- Userspace applications
- System services
- Scripting and automation
- Controlled interface for Vex AI (stable APIs, never raw kernel access)

It stays modular with respect to Vex OS and Vex AI.
