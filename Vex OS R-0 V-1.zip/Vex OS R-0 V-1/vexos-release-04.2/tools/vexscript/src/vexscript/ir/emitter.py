"""AST → Vex IR 0.1 emitter."""
from __future__ import annotations
from .nodes import ModuleIR, FunctionIR, Block as IRBlock, Instruction, Value
from ..ast_nodes import (
    Program, Function, Stmt, Expr, Let, Return, ExprStmt, If, While, For, Loop,
    Break, Continue, Block, Match, IntLit, BoolLit, Name, Binary, Unary, Call, Cast,
    Assign, StructLit, FieldAccess, StringLit, ArrayLit, Index, TypeNode,
    IndexAssign, FieldAssign,
)
from ..errors import VexError


def _map_type(t) -> str:
    if t is None:
        return "i64"
    n = getattr(t, "name", None) or str(t)
    if n in ("i8", "i16", "i32", "i64", "u8", "u16", "u32", "u64", "bool", "string", "void"):
        return n
    # struct names and pointer types pass through
    return n


class Emitter:
    def __init__(
        self,
        enum_values: dict | None = None,
        structs: dict | None = None,
        fn_rets: dict | None = None,
        module_name: str | None = None,
    ):
        self.module_name = module_name
        self.enum_values = enum_values or {}
        self.structs: dict[str, list[tuple[str, str]]] = structs or {}
        self.fn_rets: dict[str, str] = {
            "println": "i64",
            "print": "i64",
            "print_i64": "i64",
            "concat": "string",
            "len_string": "i64",
            "str_len": "i64",
            "str_contains": "bool",
            "abs": "i64",
            "min": "i64",
            "max": "i64",
            "str_equals": "bool", "str_starts_with": "bool", "str_ends_with": "bool",
            "str_length": "i64", "str_char_at": "i64",
            "os_state_get": "i64", "os_state_set": "i64", "os_buf_push": "i64", "os_buf_pop": "i64",
            "os_buf_clear": "i64", "os_buf_len": "i64", "os_buf_text": "string", "os_out_clear": "i64",
            "os_app_count": "i64", "os_app_id": "i64", "os_app_name": "string", "os_app_kind": "string",
            "os_app_started_ms": "i64", "os_now_ms": "i64", "os_timer_start": "i64",
            "os_timer_stop": "i64", "os_timer_active": "i64", "str_skip": "string", "os_cmd": "i64",
            "genome_char_at": "string",
            "genome_to_string": "string",
            "genome_from_string": "i64",
            "genome_match": "i64",
        }
        if fn_rets:
            self.fn_rets.update(fn_rets)
        self.v = 0
        self.blocks: list[IRBlock] = []
        self.cur: IRBlock | None = None
        self.locals: dict[str, str] = {}
        self.local_ty: dict[str, str] = {}
        self.fn_ret = "i64"
        self.loop_stack: list[tuple[str, str]] = []
        self.blk_id = 0

    def _new_v(self) -> str:
        n = f"%v{self.v}"
        self.v += 1
        return n

    def _new_block(self, prefix: str) -> IRBlock:
        b = IRBlock(name=f"{prefix}{self.blk_id}")
        self.blk_id += 1
        self.blocks.append(b)
        return b

    def _emit(self, inst: Instruction):
        self.cur.instructions.append(inst)

    def _term(self, inst: Instruction):
        self.cur.terminator = inst

    def emit_function(self, fn: Function) -> FunctionIR:
        self.v = 0
        self.blocks = []
        self.locals = {}
        self.local_ty = {}
        self.blk_id = 0
        self.fn_ret = _map_type(fn.return_type) if fn.return_type else "i32"
        params = []
        entry = self._new_block("entry")
        entry.name = "entry"
        self.cur = entry
        for p in fn.params:
            ssa = self._new_v()
            ty = _map_type(p.type)
            params.append((ssa, ty))
            self.locals[p.name] = ssa
            self.local_ty[p.name] = ty
            self._emit(Instruction(None, "store_local", ty, [Value("ssa", ssa, ty)], extra=p.name))
        for stmt in fn.body:
            if self.cur.terminator is not None:
                # unreachable; start a dead block
                self.cur = self._new_block("dead")
            self._stmt(stmt)
        if self.cur and self.cur.terminator is None:
            z = self._new_v()
            self._emit(Instruction(z, "const", self.fn_ret, [], extra=0))
            self._term(Instruction(None, "ret", self.fn_ret, [Value("ssa", z, self.fn_ret)]))
        return FunctionIR(name=fn.name, params=params, return_type=self.fn_ret, blocks=self.blocks)

    def _stmt(self, stmt: Stmt):
        if isinstance(stmt, Let):
            ty = _map_type(stmt.type)
            if stmt.init is None:
                ssa = self._new_v()
                self._emit(Instruction(ssa, "const", ty, [], extra=0))
            else:
                ssa, ty = self._expr(stmt.init)
            self.locals[stmt.name] = ssa
            self.local_ty[stmt.name] = ty
            self._emit(Instruction(None, "store_local", ty, [Value("ssa", ssa, ty)], extra=stmt.name))
        elif isinstance(stmt, Return):
            if stmt.value is None:
                self._term(Instruction(None, "ret", "void", []))
            else:
                ssa, ty = self._expr(stmt.value)
                self._term(Instruction(None, "ret", ty, [Value("ssa", ssa, ty)]))
        elif isinstance(stmt, ExprStmt):
            e = stmt.expr
            if isinstance(e, Assign):
                ssa, ty = self._expr(e.value)
                self.locals[e.name] = ssa
                self.local_ty[e.name] = ty
                self._emit(Instruction(None, "store_local", ty, [Value("ssa", ssa, ty)], extra=e.name))
            else:
                self._expr(e)
        elif isinstance(stmt, If):
            cond, _ = self._expr(stmt.cond)
            then_b = self._new_block("then")
            else_b = self._new_block("else")
            join_b = self._new_block("join")
            self._term(Instruction(
                None, "br_cond", "bool",
                [Value("ssa", cond, "bool")],
                extra=(then_b.name, else_b.name),
            ))
            self.cur = then_b
            for s in stmt.then_body:
                self._stmt(s)
            if self.cur.terminator is None:
                self._term(Instruction(None, "br", "void", [], extra=join_b.name))
            self.cur = else_b
            for s in (stmt.else_body or []):
                self._stmt(s)
            if self.cur.terminator is None:
                self._term(Instruction(None, "br", "void", [], extra=join_b.name))
            self.cur = join_b
        elif isinstance(stmt, Match):
            scrut, _ = self._expr(stmt.expr)
            end_b = self._new_block("matchend")
            for i, arm in enumerate(stmt.arms):
                body_b = self._new_block(f"arm{i}")
                next_b = self._new_block(f"armn{i}")
                # compare scrut to pattern value
                if arm.pattern == "_":
                    self._term(Instruction(None, "br", "void", [], extra=body_b.name))
                else:
                    if arm.pattern in self.enum_values:
                        disc = self.enum_values[arm.pattern]
                    elif arm.pattern.isdigit() or (arm.pattern.startswith("-") and arm.pattern[1:].isdigit()):
                        disc = int(arm.pattern)
                    else:
                        disc = 0
                    c = self._new_v()
                    self._emit(Instruction(c, "const", "i64", [], extra=disc))
                    cmp = self._new_v()
                    self._emit(Instruction(
                        cmp, "eq", "bool",
                        [Value("ssa", scrut, "i64"), Value("ssa", c, "i64")],
                    ))
                    self._term(Instruction(
                        None, "br_cond", "bool",
                        [Value("ssa", cmp, "bool")],
                        extra=(body_b.name, next_b.name),
                    ))
                self.cur = body_b
                for s in arm.body:
                    self._stmt(s)
                if self.cur.terminator is None:
                    self._term(Instruction(None, "br", "void", [], extra=end_b.name))
                self.cur = next_b
            # fallthrough next after last -> end
            if self.cur.terminator is None:
                self._term(Instruction(None, "br", "void", [], extra=end_b.name))
            self.cur = end_b

        elif isinstance(stmt, While):
            header = self._new_block("loop")
            body_b = self._new_block("body")
            end_b = self._new_block("end")
            self._term(Instruction(None, "br", "void", [], extra=header.name))
            self.cur = header
            cond, _ = self._expr(stmt.cond)
            self._term(Instruction(
                None, "br_cond", "bool",
                [Value("ssa", cond, "bool")],
                extra=(body_b.name, end_b.name),
            ))
            self.cur = body_b
            self.loop_stack.append((header.name, end_b.name))
            for s in stmt.body:
                self._stmt(s)
            self.loop_stack.pop()
            if self.cur.terminator is None:
                self._term(Instruction(None, "br", "void", [], extra=header.name))
            self.cur = end_b
        elif isinstance(stmt, For):
            # for (init; cond; step) body → while-like
            if stmt.init:
                self._stmt(stmt.init) if isinstance(stmt.init, Stmt) else None
            # For may have different shape - lower simply via while if attrs exist
            header = self._new_block("forh")
            body_b = self._new_block("forb")
            end_b = self._new_block("fore")
            self._term(Instruction(None, "br", "void", [], extra=header.name))
            self.cur = header
            if stmt.cond:
                cond, _ = self._expr(stmt.cond)
            else:
                c = self._new_v()
                self._emit(Instruction(c, "const", "bool", [], extra=1))
                cond = c
            self._term(Instruction(
                None, "br_cond", "bool",
                [Value("ssa", cond, "bool")],
                extra=(body_b.name, end_b.name),
            ))
            self.cur = body_b
            self.loop_stack.append((header.name, end_b.name))
            for s in stmt.body:
                self._stmt(s)
            if stmt.step:
                self._expr(stmt.step) if not isinstance(stmt.step, Stmt) else self._stmt(stmt.step)
            self.loop_stack.pop()
            if self.cur.terminator is None:
                self._term(Instruction(None, "br", "void", [], extra=header.name))
            self.cur = end_b
        elif isinstance(stmt, Loop):
            body_b = self._new_block("loopb")
            end_b = self._new_block("loope")
            self._term(Instruction(None, "br", "void", [], extra=body_b.name))
            self.cur = body_b
            self.loop_stack.append((body_b.name, end_b.name))
            for s in stmt.body:
                self._stmt(s)
            self.loop_stack.pop()
            if self.cur.terminator is None:
                self._term(Instruction(None, "br", "void", [], extra=body_b.name))
            self.cur = end_b
        elif isinstance(stmt, Break):
            if self.loop_stack:
                self._term(Instruction(None, "br", "void", [], extra=self.loop_stack[-1][1]))
        elif isinstance(stmt, Continue):
            if self.loop_stack:
                self._term(Instruction(None, "br", "void", [], extra=self.loop_stack[-1][0]))
        elif isinstance(stmt, Block):
            for s in stmt.body:
                self._stmt(s)

    def _expr(self, expr: Expr) -> tuple[str, str]:
        if isinstance(expr, IntLit):
            ssa = self._new_v()
            self._emit(Instruction(ssa, "const", "i64", [], extra=int(expr.value)))
            return ssa, "i64"
        if isinstance(expr, BoolLit):
            ssa = self._new_v()
            self._emit(Instruction(ssa, "const", "bool", [], extra=1 if expr.value else 0))
            return ssa, "bool"
        if isinstance(expr, Name):
            if expr.name in self.enum_values:
                ssa = self._new_v()
                self._emit(Instruction(ssa, "const", "i64", [], extra=int(self.enum_values[expr.name])))
                return ssa, "i64"
            if expr.name not in self.local_ty and expr.name not in self.locals:
                raise VexError(f"IR: undefined variable '{expr.name}'", expr.loc, "E0201")
            ty = self.local_ty.get(expr.name, "i64")
            dest = self._new_v()
            self._emit(Instruction(dest, "load_local", ty, [], extra=expr.name))
            return dest, ty
        if isinstance(expr, Binary):
            from ..lexer import TokenKind
            op_map = {
                TokenKind.PLUS: "add", TokenKind.MINUS: "sub", TokenKind.STAR: "mul",
                TokenKind.SLASH: "div", TokenKind.PERCENT: "mod",
                TokenKind.EQ: "eq", TokenKind.NE: "ne", TokenKind.LT: "lt",
                TokenKind.LE: "le", TokenKind.GT: "gt", TokenKind.GE: "ge",
                TokenKind.ANDAND: "and", TokenKind.OROR: "or",
            }
            left, lty = self._expr(expr.left)
            right, rty = self._expr(expr.right)
            ir_op = op_map.get(expr.op)
            if ir_op is None:
                raise VexError(f"IR: unsupported op", expr.loc, "E0202")
            # string concatenation via concat builtin
            if expr.op == TokenKind.PLUS and (lty == "string" or rty == "string"):
                dest = self._new_v()
                self._emit(Instruction(
                    dest, "call", "string",
                    [Value("ssa", left, "string"), Value("ssa", right, "string")],
                    extra="concat",
                ))
                return dest, "string"
            ty = lty if lty != "bool" else "i64"
            if rty == "i64":
                ty = "i64"
            dest = self._new_v()
            out_ty = "bool" if ir_op in ("eq", "ne", "lt", "le", "gt", "ge", "and", "or") else ty
            self._emit(Instruction(
                dest, ir_op, out_ty,
                [Value("ssa", left, lty), Value("ssa", right, rty)],
            ))
            return dest, out_ty
        if isinstance(expr, Unary):
            from ..lexer import TokenKind
            o, ty = self._expr(expr.operand)
            dest = self._new_v()
            if expr.op == TokenKind.MINUS:
                z = self._new_v()
                self._emit(Instruction(z, "const", ty, [], extra=0))
                self._emit(Instruction(dest, "sub", ty, [Value("ssa", z, ty), Value("ssa", o, ty)]))
                return dest, ty
            if expr.op == TokenKind.BANG:
                self._emit(Instruction(dest, "not", "bool", [Value("ssa", o, ty)]))
                return dest, "bool"
            raise VexError("IR: unsupported unary", expr.loc, "E0202")
        if isinstance(expr, Call):
            args = []
            for a in expr.args:
                s, ty_a = self._expr(a)
                args.append(Value("ssa", s, ty_a))
            dest = self._new_v()
            call_name = expr.name
            # VEX AI 1.0 language wave (Bug 2 fix, IR level): qualify a bare
            # same-module sibling call before emission.
            if "::" not in call_name and self.module_name:
                qualified = f"{self.module_name}::{call_name}"
                if qualified in self.fn_rets and call_name not in self.fn_rets:
                    call_name = qualified
            ret_ty = self.fn_rets.get(call_name, "i64")
            if "::" in call_name:
                ret_ty = self.fn_rets.get(call_name, self.fn_rets.get(call_name.replace("::", "_"), ret_ty))
            self._emit(Instruction(dest, "call", ret_ty, args, extra=call_name))
            return dest, ret_ty
        if isinstance(expr, Cast):
            s, _ = self._expr(expr.expr)
            ty = _map_type(expr.target)
            dest = self._new_v()
            self._emit(Instruction(dest, "copy", ty, [Value("ssa", s, ty)]))
            return dest, ty
        if isinstance(expr, Assign):
            ssa, ty = self._expr(expr.value)
            self.locals[expr.name] = ssa
            self.local_ty[expr.name] = ty
            return ssa, ty
        if isinstance(expr, IndexAssign):
            arr_s, arr_ty = self._expr(expr.obj)
            idx_s, idx_ty = self._expr(expr.index)
            val_s, val_ty = self._expr(expr.value)
            self._emit(Instruction(None, "index_set", val_ty, [
                Value("ssa", arr_s, arr_ty),
                Value("ssa", idx_s, idx_ty),
                Value("ssa", val_s, val_ty),
            ]))
            return val_s, val_ty
        if isinstance(expr, StructLit):
            field_map = {fname: fexpr for fname, fexpr in expr.fields}
            order = self.structs.get(expr.name)
            if order:
                names = [fn for fn, _ in order]
            else:
                names = [fn for fn, _ in expr.fields]
            args = []
            for fn in names:
                fe = field_map.get(fn)
                if fe is None:
                    raise VexError(f"IR: struct '{expr.name}' missing field '{fn}'", expr.loc, "E0203")
                ssa, ty = self._expr(fe)
                args.append(Value("ssa", ssa, ty))
            d = self._new_v()
            self._emit(Instruction(
                d, "make_struct", expr.name, args, extra=",".join(names)
            ))
            return d, expr.name
        if isinstance(expr, FieldAccess):
            o, oty = self._expr(expr.obj)
            fty = "i64"
            if oty in self.structs:
                for fn, ft in self.structs[oty]:
                    if fn == expr.field:
                        fty = ft
                        break
            d = self._new_v()
            self._emit(Instruction(
                d, "extract", fty, [Value("ssa", o, oty)], extra=expr.field
            ))
            return d, fty
        if isinstance(expr, ArrayLit):
            args = []
            ety = "i64"
            for e in expr.elements:
                s, ty = self._expr(e)
                ety = ty
                args.append(Value("ssa", s, ty))
            d = self._new_v()
            aty = f"{ety}[]"
            self._emit(Instruction(d, "make_array", aty, args, extra=len(expr.elements)))
            return d, aty
        if isinstance(expr, Index):
            o, oty = self._expr(expr.obj)
            i, ity = self._expr(expr.index)
            elem = oty[:-2] if oty.endswith("[]") else "i64"
            d = self._new_v()
            self._emit(Instruction(
                d, "index", elem,
                [Value("ssa", o, oty), Value("ssa", i, ity)],
            ))
            return d, elem
        if isinstance(expr, StringLit):
            d = self._new_v()
            self._emit(Instruction(d, "const", "string", [], extra=str(expr.value)))
            return d, "string"
        raise VexError(f"IR: unsupported expression {type(expr).__name__}", getattr(expr, "loc", None), "E0202")


def emit_program(
    program: Program,
    extra_functions: dict | None = None,
    enum_values: dict | None = None,
    structs: dict | None = None,
) -> ModuleIR:
    mod = ModuleIR()
    mod.ir_version = "1.5"
    mod.calling_conv = "vex_hosted"
    enums = enum_values or {}
    # Build struct layout from program if not provided
    st_map: dict[str, list[tuple[str, str]]] = dict(structs or {})
    for st in getattr(program, "structs", []) or []:
        st_map[st.name] = [
            (f.name, (f.type.name if f.type else "i64")) for f in st.fields
        ]
    fn_rets: dict[str, str] = {}
    for fn in program.functions:
        fn_rets[fn.name] = _map_type(fn.return_type) if fn.return_type else "i32"
    if extra_functions:
        for key, fn in extra_functions.items():
            if hasattr(fn, "return_type"):
                fn_rets[key] = _map_type(fn.return_type) if fn.return_type else "i64"
                # Deliberately not also aliasing the bare fn.name (see Bug 2
                # fix notes) -- that used to let same-module unqualified
                # calls bypass qualification and let two modules' same-
                # named private helpers collide.
                fn_rets[key.replace("::", "_")] = fn_rets[key]
    for fn in program.functions:
        mod.functions.append(Emitter(enums, st_map, fn_rets).emit_function(fn))
    if extra_functions:
        for key, fn in extra_functions.items():
            if not hasattr(fn, "body"):
                continue
            ir_name = key.replace("::", "_")
            if any(f.name == ir_name for f in mod.functions):
                continue
            if any(f.name == fn.name for f in mod.functions):
                continue
            mod_name = key.split("::")[0] if "::" in key else None
            fir = Emitter(enums, st_map, fn_rets, module_name=mod_name).emit_function(fn)
            fir.name = ir_name if "::" in key else fn.name
            mod.functions.append(fir)
    mod.structs = dict(st_map)
    return mod
