/*
 * uproc_tests.c - PROC-01 in-kernel verification and the `v. proc` terminal command.
 *
 * Each program in uproc_programs.asm attacks one boundary; this file asserts the EXACT expected outcome (and fault
 * details), then checks the cross-cutting invariants after every run: physical frames unchanged, the whole process
 * window unmapped again, no run left armed, and the interrupt flag restored. Loader attacks mutate a valid image's
 * header. A PASS here means the booted kernel behaved correctly for that case - nothing more.
 */
#include "uproc.h"
#include "proc_term.h"
#include "ring3.h"
#include "vmm.h"
#include "pmm.h"
#include "serial.h"

#define PROG_LIST \
    X(hello) X(bssdata) X(kread) X(kwrite) X(textwrite) X(nxdata) X(nxstack) X(guardlo) X(guardhi) X(texthole) X(stackover) \
    X(priv_cli) X(priv_hlt) X(priv_cr3) X(priv_in) X(priv_wrmsr) X(ud2) X(div0) X(intk) X(usyscall) \
    X(badptr) X(nosys) X(getpid) X(exit_neg) X(flood) X(spin) X(spinsys) X(ask) X(leaka) X(leakb)
#define X(n) extern const uint8_t uprog_##n[]; extern const uint8_t uprog_##n##_end[];
PROG_LIST
#undef X

typedef struct { const char *name; const uint8_t *img, *end; } Prog;
static const Prog progs[] = {
#define X(n) { #n, uprog_##n, uprog_##n##_end },
PROG_LIST
#undef X
};
#define NPROGS ((int)(sizeof progs / sizeof progs[0]))
static const Prog *find(const char *n) { for (int i = 0; i < NPROGS; i++) { const char *a = progs[i].name, *b = n; while (*a && *a == *b) { a++; b++; } if (*a == 0 && *b == 0) return &progs[i]; } return 0; }

/* ---- tiny line builder / helpers ---- */
typedef struct { char b[160]; unsigned n; } Ln;
static void lc(Ln *l, char c) { if (l->n + 1 < sizeof l->b) { l->b[l->n++] = c; l->b[l->n] = 0; } }
static void ls(Ln *l, const char *s) { while (*s) lc(l, *s++); }
static void ld(Ln *l, int64_t v) { char t[24]; int k = 0; uint64_t u = v < 0 ? (uint64_t)0 - (uint64_t)v : (uint64_t)v; if (v < 0) lc(l, '-'); do { t[k++] = (char)('0' + (int)(u % 10u)); u /= 10u; } while (u && k < 23); while (k) lc(l, t[--k]); }
static void lh(Ln *l, uint64_t v) { static const char H[] = "0123456789abcdef"; ls(l, "0x"); int started = 0; for (int s = 60; s >= 0; s -= 4) { int d = (int)((v >> s) & 15u); if (d || started || s == 0) { lc(l, H[d]); started = 1; } } }
static int seq(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return *a == *b; }
static void minit(Ln *l) { l->n = 0; l->b[0] = 0; }
static uint64_t read_if(void) { uint64_t f; __asm__ volatile ("pushfq; pop %0" : "=r"(f)); return f & 0x200; }
static uint64_t rdmsr_(uint32_t m) { uint32_t lo, hi; __asm__ volatile ("rdmsr" : "=a"(lo), "=d"(hi) : "c"(m)); return ((uint64_t)hi << 32) | lo; }

/* ---- expectations ---- */
enum { CR2_NONE = 0, CR2_ABS_KERNEL, CR2_TEXT, CR2_DATA, CR2_DATA_M1, CR2_STACK_TOP, CR2_TEXT_P1, CR2_IN_STACK, CR2_BELOW_STACK };
enum { RIP_NONE = 0, RIP_TEXT, RIP_DATA, RIP_STACK };
typedef struct {
    const char *prog; Ring3Outcome oc; int chk_exit; uint64_t exit; int vec; uint64_t err_set, err_clr; int cr2k, ripk;
    const char *write; int64_t syscalls; const char *what;
} Exp;
static const Exp exps[] = {
    { "hello",     RING3_OUT_EXITED,  1, 15, -1, 0, 0, 0, 0, "hello from vxe1", 2, "hello: WRITE + EXIT, exit code = bytes written, text logged" },
    { "bssdata",   RING3_OUT_EXITED,  1, 0,  -1, 0, 0, 0, 0, 0, -1, "initialised data readable; bss zero over 3 pages; data+bss writable" },
    { "kread",     RING3_OUT_FAULTED, 0, 0,  14, 0x5, 0, CR2_ABS_KERNEL, RIP_TEXT, 0, -1, "read of kernel memory -> #PF (present, user, supervisor-only page)" },
    { "kwrite",    RING3_OUT_FAULTED, 0, 0,  14, 0x7, 0, CR2_ABS_KERNEL, RIP_TEXT, 0, -1, "write to kernel memory -> #PF" },
    { "textwrite", RING3_OUT_FAULTED, 0, 0,  14, 0x7, 0, CR2_TEXT, RIP_TEXT, 0, -1, "write to own code page -> #PF (code is read-only)" },
    { "nxdata",    RING3_OUT_FAULTED, 0, 0,  14, 0x15, 0, CR2_DATA, RIP_DATA, 0, -1, "execute the data page -> #PF instruction fetch (NX enforced)" },
    { "nxstack",   RING3_OUT_FAULTED, 0, 0,  14, 0x15, 0, CR2_IN_STACK, RIP_STACK, 0, -1, "execute the stack -> #PF instruction fetch (NX enforced)" },
    { "guardlo",   RING3_OUT_FAULTED, 0, 0,  14, 0x6, 0x1, CR2_DATA_M1, RIP_TEXT, 0, -1, "write into the guard page below data -> #PF (not present)" },
    { "guardhi",   RING3_OUT_FAULTED, 0, 0,  14, 0x6, 0x1, CR2_STACK_TOP, RIP_TEXT, 0, -1, "write into the guard page above the stack -> #PF (not present)" },
    { "texthole",  RING3_OUT_FAULTED, 0, 0,  14, 0x4, 0x1, CR2_TEXT_P1, RIP_TEXT, 0, -1, "read one page past the end of text -> #PF (not present)" },
    { "stackover", RING3_OUT_FAULTED, 0, 0,  14, 0x6, 0x1, CR2_BELOW_STACK, RIP_TEXT, 0, -1, "stack overflow runs into the unmapped guard -> #PF" },
    { "priv_cli",  RING3_OUT_FAULTED, 0, 0,  13, 0, 0, 0, RIP_TEXT, 0, -1, "cli from Ring 3 -> #GP" },
    { "priv_hlt",  RING3_OUT_FAULTED, 0, 0,  13, 0, 0, 0, RIP_TEXT, 0, -1, "hlt from Ring 3 -> #GP" },
    { "priv_cr3",  RING3_OUT_FAULTED, 0, 0,  13, 0, 0, 0, RIP_TEXT, 0, -1, "mov rax,cr3 from Ring 3 -> #GP" },
    { "priv_in",   RING3_OUT_FAULTED, 0, 0,  13, 0, 0, 0, RIP_TEXT, 0, -1, "port I/O (in al,0x60) from Ring 3 -> #GP" },
    { "priv_wrmsr",RING3_OUT_FAULTED, 0, 0,  13, 0, 0, 0, RIP_TEXT, 0, -1, "wrmsr from Ring 3 -> #GP" },
    { "ud2",       RING3_OUT_FAULTED, 0, 0,  6,  0, 0, 0, RIP_TEXT, 0, -1, "ud2 -> #UD isolated" },
    { "div0",      RING3_OUT_FAULTED, 0, 0,  0,  0, 0, 0, RIP_TEXT, 0, -1, "divide by zero -> #DE isolated" },
    { "intk",      RING3_OUT_FAULTED, 0, 0,  13, 0, 0, 0, RIP_TEXT, 0, -1, "software int 0x20 (kernel timer vector) -> #GP, handler not run" },
    { "usyscall",  RING3_OUT_FAULTED, 0, 0,  6,  0, 0, 0, RIP_TEXT, 0, -1, "SYSCALL instruction -> #UD (SCE clear)" },
    { "badptr",    RING3_OUT_EXITED,  1, 0,  -1, 0, 0, 0, 0, 0, 24, "23 hostile/valid syscall pointer cases: every refusal and every acceptance as specified" },
    { "nosys",     RING3_OUT_EXITED,  1, 0,  -1, 0, 0, 0, 0, 0, 14, "13 unknown syscall numbers (incl. 32-bit aliases of EXIT/WRITE/AI_ASK) -> -38 each" },
    { "getpid",    RING3_OUT_EXITED,  0, 0,  -1, 0, 0, 0, 0, 0, 2, "GETPID returns this run's pid" },
    { "exit_neg",  RING3_OUT_EXITED,  1, ~0ull, -1, 0, 0, 0, 0, 0, 1, "full 64-bit exit code preserved" },
    { "flood",     RING3_OUT_EXITED,  1, 0,  -1, 0, 0, 0, 0, 0, 3001, "3000 syscalls finish inside the CPU budget" },
    { "spin",      RING3_OUT_TIMEOUT, 0, 0,  -1, 0, 0, 0, 0, 0, -1, "infinite user loop is ended by the watchdog; kernel keeps running" },
    { "spinsys",   RING3_OUT_TIMEOUT, 0, 0,  -1, 0, 0, 0, 0, 0, -1, "infinite syscall loop is ended by the watchdog" },
    { "ask",       RING3_OUT_EXITED,  1, 15, -1, 0, 0, 0, 0, "12 plus 30 = 42", 3, "AI_ASK: Ring 3 asks Crystal across the syscall boundary and gets 12 plus 30 = 42" },
    { "leaka",     RING3_OUT_EXITED,  1, 0,  -1, 0, 0, 0, 0, 0, -1, "leak setup: scribble magic over data, bss and stack" },
    { "leakb",     RING3_OUT_EXITED,  1, 0,  -1, 0, 0, 0, 0, 0, -1, "no leakage: same VAs, recycled frames, bss and stack read as zero" },
};
#define NEXPS ((int)(sizeof exps / sizeof exps[0]))

static int g_pass, g_total;
static void report(proc_emit_fn emit, int ok, const char *what, const char *detail)
{
    Ln l; minit(&l); ls(&l, ok ? "PASS  " : "FAIL  "); ls(&l, what); if (!ok && detail) { ls(&l, "  ["); ls(&l, detail); ls(&l, "]"); }
    g_total++; g_pass += ok; emit(l.b);
}

static int window_clean(const UprocResult *r)
{
    uint64_t e, sz;
    uint64_t vas[4] = { r->text_va, r->data_va, r->stack_lo_va, r->stack_top_va - 4096 };
    for (int i = 0; i < 4; i++) { if (vmm_query(vas[i], &e, &sz) == VMM_OK && (e & VMM_PRESENT)) return 0; }
    return 1;
}

static int run_exp(const Exp *x, proc_emit_fn emit, uint64_t *last_pid)
{
    const Prog *p = find(x->prog); UprocResult r; Ln d; minit(&d);
    uint64_t f0 = pmm_free_frames(), if0 = read_if();
    UprocStatus st = uproc_run(p->img, (size_t)(p->end - p->img), &r);
    uint64_t f1 = pmm_free_frames(), if1 = read_if();
    int ok = 1;
    if (st != UPROC_OK) { ok = 0; ls(&d, "load: "); ls(&d, uproc_status_name(st)); }
    else {
        if (r.outcome != x->oc) { ok = 0; ls(&d, "outcome "); ld(&d, r.outcome); ls(&d, " want "); ld(&d, x->oc); ls(&d, "; "); }
        if (x->chk_exit && r.exit_code != x->exit) { ok = 0; ls(&d, "exit "); lh(&d, r.exit_code); ls(&d, "; "); }
        if (!x->chk_exit && seq(x->prog, "getpid") && r.exit_code != r.pid) { ok = 0; ls(&d, "pid mismatch; "); }
        if (x->vec >= 0) {
            if ((int)r.fault_vector != x->vec) { ok = 0; ls(&d, "vec "); ld(&d, (int64_t)r.fault_vector); ls(&d, " want "); ld(&d, x->vec); ls(&d, "; "); }
            if ((r.fault_error_code & x->err_set) != x->err_set) { ok = 0; ls(&d, "err "); lh(&d, r.fault_error_code); ls(&d, " lacks "); lh(&d, x->err_set); ls(&d, "; "); }
            if (r.fault_error_code & x->err_clr) { ok = 0; ls(&d, "err "); lh(&d, r.fault_error_code); ls(&d, " has forbidden "); lh(&d, x->err_clr); ls(&d, "; "); }
            uint64_t c = r.fault_cr2; int cok = 1;
            switch (x->cr2k) {
            case CR2_ABS_KERNEL: cok = c == 0x100000; break;
            case CR2_TEXT: cok = c == r.text_va; break;
            case CR2_DATA: cok = c == r.data_va; break;
            case CR2_DATA_M1: cok = c == r.data_va - 1; break;
            case CR2_STACK_TOP: cok = c == r.stack_top_va; break;
            case CR2_TEXT_P1: cok = c == r.text_va + 4096; break;
            case CR2_IN_STACK: cok = c >= r.stack_lo_va && c < r.stack_top_va; break;
            case CR2_BELOW_STACK: cok = c < r.stack_lo_va && c >= r.stack_lo_va - 4096; break;
            default: break;
            }
            if (!cok) { ok = 0; ls(&d, "cr2 "); lh(&d, c); ls(&d, "; "); }
            uint64_t ip = r.fault_rip; int iok = 1;
            if (x->ripk == RIP_TEXT) iok = ip >= r.text_va && ip < r.text_va + 4096 * 16;
            else if (x->ripk == RIP_DATA) iok = ip == r.data_va;
            else if (x->ripk == RIP_STACK) iok = ip >= r.stack_lo_va && ip < r.stack_top_va;
            if (!iok) { ok = 0; ls(&d, "rip "); lh(&d, ip); ls(&d, "; "); }
        }
        if (x->write && !seq(r.last_write, x->write)) { ok = 0; ls(&d, "write '"); ls(&d, r.last_write); ls(&d, "'; "); }
        if (x->syscalls >= 0 && (int64_t)r.syscalls != x->syscalls) { ok = 0; ls(&d, "syscalls "); ld(&d, (int64_t)r.syscalls); ls(&d, " want "); ld(&d, x->syscalls); ls(&d, "; "); }
        if (!window_clean(&r)) { ok = 0; ls(&d, "window still mapped; "); }
        if (last_pid) { if (r.pid <= *last_pid) { ok = 0; ls(&d, "pid not increasing; "); } *last_pid = r.pid; }
    }
    if (f0 != f1) { ok = 0; ls(&d, "frames "); ld(&d, (int64_t)f0); ls(&d, "->"); ld(&d, (int64_t)f1); ls(&d, "; "); }
    if (if0 != if1) { ok = 0; ls(&d, "IF not restored; "); }
    if (ring3_active()) { ok = 0; ls(&d, "run still armed; "); }
    report(emit, ok, x->what, d.b);
    return ok;
}

/* ---- loader attacks: mutate a valid image header ---- */
typedef struct { const char *what; unsigned off, w; uint64_t val; UprocStatus want; } Mut;
static const Mut muts[] = {
    { "bad magic", 0, 1, 'X', UPROC_E_MAGIC }, { "version 2", 4, 2, 2, UPROC_E_VERSION }, { "header_size 47", 6, 2, 47, UPROC_E_HDRSIZE },
    { "flags != 0", 8, 4, 1, UPROC_E_FLAGS }, { "reserved0 != 0", 40, 4, 1, UPROC_E_RESERVED }, { "reserved1 != 0", 44, 4, 0x80000000u, UPROC_E_RESERVED },
    { "text_size 0", 20, 4, 0, UPROC_E_TEXT_SIZE }, { "text_size 65537", 20, 4, 65537, UPROC_E_TEXT_SIZE }, { "text_size 0xFFFFFFF0", 20, 4, 0xFFFFFFF0u, UPROC_E_TEXT_SIZE },
    { "text_off inside header", 16, 4, 47, UPROC_E_TEXT_RANGE }, { "text_off 0xFFFFFFFF (32-bit wrap bait)", 16, 4, 0xFFFFFFFFu, UPROC_E_TEXT_RANGE },
    { "text runs past the image", 20, 4, 4096, UPROC_E_TEXT_RANGE },
    { "data_size 0 but data_off set", 28, 4, 0, UPROC_E_DATA_RANGE }, { "data_off 0xFFFFFFFF", 24, 4, 0xFFFFFFFFu, UPROC_E_DATA_RANGE }, { "data_size runs past the image", 28, 4, 4096, UPROC_E_DATA_RANGE },
    { "bss 0xFFFFFFFF", 32, 4, 0xFFFFFFFFu, UPROC_E_DATA_PAGES }, { "data+bss one byte over 16 pages", 32, 4, 65536 - 15 + 1, UPROC_E_DATA_PAGES },
    { "data_off inside the header", 24, 4, 0, UPROC_E_DATA_RANGE },
    { "data segment overlaps the text segment", 24, 4, 48, UPROC_E_OVERLAP },
    { "entry far beyond text", 12, 4, 0xFFFFFFFFu, UPROC_E_ENTRY }, { "stack_pages 0", 36, 4, 0, UPROC_E_STACK }, { "stack_pages 5", 36, 4, 5, UPROC_E_STACK },
};
#define NMUTS ((int)(sizeof muts / sizeof muts[0]))
static uint8_t g_mut[512];

static void loader_attacks(proc_emit_fn emit)
{
    const Prog *h = find("hello"); size_t n = (size_t)(h->end - h->img);
    for (int i = 0; i < NMUTS; i++) {
        for (size_t k = 0; k < n; k++) g_mut[k] = h->img[k];
        for (unsigned b = 0; b < muts[i].w; b++) g_mut[muts[i].off + b] = (uint8_t)(muts[i].val >> (8 * b));
        uint64_t f0 = pmm_free_frames(), runs = uproc_runs_total(); UprocResult r;
        UprocStatus st = uproc_run(g_mut, n, &r);
        Ln d; minit(&d); int ok = st == muts[i].want && f0 == pmm_free_frames() && runs == uproc_runs_total() && !ring3_active();
        if (!ok) { ls(&d, "got "); ls(&d, uproc_status_name(st)); ls(&d, " want "); ls(&d, uproc_status_name(muts[i].want)); }
        Ln w; minit(&w); ls(&w, "loader refuses: "); ls(&w, muts[i].what); report(emit, ok, w.b, d.b);
    }
    for (size_t k = 0; k < n; k++) g_mut[k] = h->img[k];
    { UprocResult r; Ln d; minit(&d); int ok = uproc_run(g_mut, 47, &r) == UPROC_E_TOO_SMALL && uproc_run(g_mut, 0, &r) == UPROC_E_TOO_SMALL && uproc_run(0, 100, &r) == UPROC_E_NULL
                    && uproc_run(g_mut, 65537, &r) == UPROC_E_TOO_BIG && uproc_run(g_mut, 4294967296ull, &r) == UPROC_E_TOO_BIG;
      report(emit, ok, "loader refuses: NULL image, 47/0-byte image, 65537-byte and 2^32-byte lengths (no read past the buffer)", ""); (void)d; }
    {   /* boundary ACCEPTED: data+bss exactly 16 pages must load and run */
        for (size_t k = 0; k < n; k++) g_mut[k] = h->img[k];
        uint32_t bss = 65536 - 15; for (unsigned b = 0; b < 4; b++) g_mut[32 + b] = (uint8_t)(bss >> (8 * b));
        UprocResult r; uint64_t f0 = pmm_free_frames(); UprocStatus st = uproc_run(g_mut, n, &r);
        int ok = st == UPROC_OK && r.outcome == RING3_OUT_EXITED && r.exit_code == 15 && f0 == pmm_free_frames();
        report(emit, ok, "loader accepts the exact maximum (data+bss = 16 pages), runs it, and frees all 16+ frames", "");
    }
}

void proc_selftest(proc_emit_fn emit)
{
    g_pass = g_total = 0; Ln l;
    emit("Process selftest (PROC-01): hostile Ring 3 programs, loader attacks, leak and invariant checks.");
    if (!uproc_init()) { emit("FAIL  uproc_init (Ring 3 not ready)"); return; }
    { UprocResult w; const Prog *h = find("hello"); (void)uproc_run(h->img, (size_t)(h->end - h->img), &w); }   /* warm-up: first run may allocate page-table frames once */
    uint64_t efer = rdmsr_(0xC0000080u);
    { Ln e; minit(&e); ls(&e, "INFO  EFER=" ); lh(&e, efer); ls(&e, (efer & (1u << 11)) ? " NXE on" : " NXE OFF"); ls(&e, (efer & 1u) ? "; SCE ON" : "; SCE off"); emit(e.b); }
    report(emit, (efer & (1u << 11)) != 0, "EFER.NXE is enabled (NX is enforceable)", "");
    uint64_t last_pid = 0; int sce = (efer & 1u) != 0;
    for (int i = 0; i < NEXPS; i++) {
        if (seq(exps[i].prog, "usyscall") && sce) { emit("FAIL  EFER.SCE is set: user `syscall` test SKIPPED (instruction would be live) - finding, not a pass"); g_total++; continue; }
        run_exp(&exps[i], emit, &last_pid);
    }
    loader_attacks(emit);
    {   /* repeated create/destroy: no frame leak across 60 runs, and the kernel stays healthy */
        const Prog *h = find("hello"); uint64_t f0 = pmm_free_frames(); int ok = 1; UprocResult r;
        for (int i = 0; i < 60; i++) { if (uproc_run(h->img, (size_t)(h->end - h->img), &r) != UPROC_OK || r.exit_code != 15) ok = 0; }
        Ln d; minit(&d); if (f0 != pmm_free_frames()) { ok = 0; ls(&d, "frames "); ld(&d, (int64_t)f0); ls(&d, "->"); ld(&d, (int64_t)pmm_free_frames()); }
        report(emit, ok, "60 consecutive runs: physical frame count identical before and after (no leak)", d.b);
    }
    { UprocResult r; const Prog *k = find("kread"); uint64_t fi = ring3_faults_isolated(); (void)uproc_run(k->img, (size_t)(k->end - k->img), &r);
      report(emit, ring3_faults_isolated() == fi + 1, "fault counter increments exactly once per isolated fault", ""); }
    minit(&l); ls(&l, "Process selftest: "); ld(&l, g_pass); lc(&l, '/'); ld(&l, g_total); ls(&l, g_pass == g_total ? " PASS" : " FAIL"); emit(l.b);
    serial_puts("[uproc] selftest: "); serial_put_dec64((uint64_t)g_pass); serial_puts("/"); serial_put_dec64((uint64_t)g_total); serial_puts(g_pass == g_total ? " PASS\n" : " FAIL\n");
}

/* ---- terminal entry: `v. proc ...` ---- */
void proc_term(const char *arg, proc_emit_fn emit)
{
    while (*arg == ' ') arg++;
    if (*arg == 0) {
        emit("Ring 3 process loader (PROC-01). v. proc test | v. proc list | v. proc run <hello|ask|getpid> | v. proc status");
        emit("One process at a time, no per-process page tables, no SMEP/SMAP: see docs/PROC-01.md for the exact guarantees and limits.");
        return;
    }
    if (seq(arg, "test")) { proc_selftest(emit); return; }
    if (seq(arg, "list")) { Ln l; minit(&l); ls(&l, "Embedded VXE1 programs:"); for (int i = 0; i < NPROGS; i++) { ls(&l, " "); ls(&l, progs[i].name); if (l.n > 120) { emit(l.b); minit(&l); ls(&l, "  "); } } emit(l.b); return; }
    if (seq(arg, "status")) { Ln l; minit(&l); ls(&l, "Loader "); ls(&l, uproc_init() ? "ready" : "NOT ready"); ls(&l, "; runs: "); ld(&l, (int64_t)uproc_runs_total()); ls(&l, "; user faults isolated: "); ld(&l, (int64_t)ring3_faults_isolated()); ls(&l, "; CPU budget "); ld(&l, UPROC_MAX_TICKS * 10); ls(&l, " ms"); emit(l.b); return; }
    if (arg[0] == 'r' && arg[1] == 'u' && arg[2] == 'n' && arg[3] == ' ') {
        const char *nm = arg + 4; while (*nm == ' ') nm++;
        if (!(seq(nm, "hello") || seq(nm, "ask") || seq(nm, "getpid"))) { emit("Only hello, ask and getpid can be run by name (the others are attack programs; use v. proc test)."); return; }
        if (!uproc_init()) { emit("Loader not ready."); return; }
        const Prog *p = find(nm); UprocResult r; UprocStatus st = uproc_run(p->img, (size_t)(p->end - p->img), &r); Ln l; minit(&l);
        if (st != UPROC_OK) { ls(&l, "load failed: "); ls(&l, uproc_status_name(st)); emit(l.b); return; }
        ls(&l, "pid "); ld(&l, (int64_t)r.pid); ls(&l, r.outcome == RING3_OUT_EXITED ? " exited, code " : r.outcome == RING3_OUT_FAULTED ? " FAULTED (isolated), vector " : " TIMED OUT ");
        ld(&l, (int64_t)(r.outcome == RING3_OUT_FAULTED ? r.fault_vector : r.exit_code)); ls(&l, "; syscalls "); ld(&l, (int64_t)r.syscalls); ls(&l, "; ran "); ld(&l, (int64_t)r.ticks * 10); ls(&l, " ms");
        emit(l.b);
        if (r.last_write_len) { Ln w; minit(&w); ls(&w, "program wrote: "); ls(&w, r.last_write); emit(w.b); }
        return;
    }
    emit("Unknown v. proc subcommand. Try: v. proc test | list | run <name> | status");
}
