#!/usr/bin/env python3
"""VexScript 2+ Phase D — IR optimize + diagnostics"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vexscript.compile_ir import compile_to_ir, run_via_ir
from vexscript.ir.text import module_to_text
from vexscript.interpreter import Interpreter
from vexscript.errors import VexError

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

print("VexScript 2+ Phase D")

src = "fn main() -> i32 { println(2 + 3 * 4); return 0; }\n"
mod = compile_to_ir(src)
text = module_to_text(mod)
check("const fold mul", "const.i64 12" in text, text)
check("const fold add", "const.i64 14" in text, text)

code, out = run_via_ir(src)
check("folded result", code == 0 and "14" in out, out)

# unreachable: always branch to one side after fold might leave dead blocks
# simple: match creates multiple blocks, all reachable - skip

try:
    Interpreter().load(
        "fn main() -> i32 {\n    let x: i64 = true;\n    return 0;\n}\n",
        "demo.vex",
    )
    check("diag snippet", False)
except VexError as e:
    fmt = e.format()
    check("diag has line", "demo.vex:2:5" in fmt, fmt)
    check("diag has caret", "^" in fmt, fmt)
    check("diag has source line", "let x: i64 = true" in fmt, fmt)

print(f"\n=== 2+ Phase D Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
