/*
 * Vex OS - kernel/include/boot03_inject.h
 *
 * BOOT-03 fault injection, for NEGATIVE CONTROLS.
 *
 * A test suite that has never failed is not evidence that the system
 * works - it is equally consistent with the tests not checking anything.
 * BOOT-02C established the habit of proving the harness can fail; this
 * header is the BOOT-03 mechanism for the same thing at the subsystem
 * level.
 *
 * Each injection deliberately breaks ONE invariant in the real
 * implementation - not in the test - so that building with it and
 * observing the corresponding subsystem report FAIL demonstrates the
 * test actually exercises that invariant.
 *
 * USAGE:  make VEX_FAULT_INJECT=2 clean image
 *         (or -DVEX_FAULT_INJECT=2 on the compiler command line)
 *
 * The default is 0, and with 0 every macro below compiles to nothing, so
 * a normal build contains no injection code at all - this is not a
 * runtime flag that could be left on by accident.
 *
 * Injection points, and the test each one must break:
 *
 *   1  vmm_unmap_page leaves the PTE present.
 *      -> PAGING must FAIL (unmap-then-translate check).
 *
 *   2  timer_on_interrupt omits the EOI write.
 *      -> TIMER must FAIL (the timer fires once, then never again).
 *
 *   3  pmm_free_page accepts a reserved frame.
 *      -> MEMORY must FAIL (reserved-memory protection check).
 *
 *   4  percpu_init_for_this_cpu stores the wrong cpu_index.
 *      -> SMP / per-CPU must FAIL (self-identification check).
 *
 *   5  boot03 summary is printed unconditionally as PASS.
 *      -> proves the summary gate itself is doing work: with this on,
 *         a FAILING subsystem would still print BOOT SAGA COMPLETE, which
 *         is exactly the dishonesty the gate exists to prevent. Used to
 *         demonstrate the gate, never shipped.
 *
 * KERNEL-01 additions. Same rule: each one breaks the implementation, not
 * the test. KERNEL-01 failures reach SYSTEM READY through the gate
 * kernel_entry.c installs with boot03_gate_and(), so a broken KERNEL-01
 * subsystem cannot produce the string the rest of scripts/ keys on.
 *
 *   6  vmm_unmap_page_reclaim() skips the required TLB shootdown.
 *      -> RECLAIM must FAIL. The reclamation gate must then refuse to free
 *         the orphaned tables, so the reclaim reports an error, no table is
 *         reclaimed, and the frames are counted as leaked. This proves the
 *         gate is what permits the free, rather than the free happening
 *         regardless and the shootdown being decoration.
 *
 *   7  page tables are freed even though the gate refused, the shootdown
 *      having been skipped as in 6.
 *      -> RECLAIM must FAIL. Distinct from 6 in what catches it: 6 is
 *         caught by the absence of a reclaim, 7 by the violation counter,
 *         which the injection deliberately leaves intact. The injection
 *         removes the refusal, not the observation - a build that frees
 *         page tables without a completed shootdown must be detectable and
 *         not merely refused.
 *
 *   8  the shootdown handler invalidates but never publishes its
 *      acknowledgement.
 *      -> TLB must FAIL, by TIMEOUT rather than by hanging: the
 *         acknowledgement wait is bounded, so the kernel must survive to
 *         report the failure. Proves the acknowledgement protocol is
 *         load-bearing - without it a shootdown that never reached a CPU
 *         would look identical to one that succeeded. Needs a remote CPU,
 *         so this injection is meaningful only with -smp 2 or more.
 *
 *   9  vmm_kmap_free_virtual() accepts a double free of a virtual range.
 *      -> KMAP must FAIL. A range already on the free list would be handed
 *         to two consumers at once, each believing it owns those addresses.
 *
 * SECURITY-01 injections, 10 upward.
 *
 *   The SECURITY-01 brief specified injections numbered 11-20, every one
 *   of which targets USER-01 code - syscall entry, user boundary checks,
 *   process termination, CR3 switching. None of that code exists in this
 *   repository. Injections cannot be written against absent code, and
 *   writing ones that only LOOK like the requested ones would be worse
 *   than admitting the gap. These are numbered from 10, continuing this
 *   file's existing sequence, and each breaks real code that is really
 *   present. The mapping to the brief is recorded in docs/SECURITY-01.md.
 *
 *  10  sec_check_range() uses base+len without checking for overflow.
 *      -> SEC-PTR must FAIL. The wrapped end makes every later bound look
 *         satisfied, so a range of length UINT64_MAX is approved.
 *
 *  11  sec_check_range() bounds-checks only the FIRST byte against the
 *      window.
 *      -> SEC-PTR must FAIL. A range that starts inside and runs off the
 *         far end is approved - the "validated ptr, dereferenced ptr+len"
 *         bug the whole checker exists to prevent.
 *
 *  12  sec_is_canonical() declares every address canonical.
 *      -> SEC-PTR must FAIL. Addresses the CPU rejects with #GP are
 *         approved, and the hole-straddling check collapses with it.
 *
 *  13  sec_check_range() stops after the first page of the mapping walk.
 *      -> SEC-PTR must FAIL. A cross-page range whose SECOND page is
 *         unmapped is approved.
 *
 *  14  vmm_map_page()/vmm_protect_page() no longer refuse VMM_USER.
 *      -> SEC-PERM must FAIL. A kernel mapping can then be marked
 *         USER-accessible. Caught twice over: the guard stops refusing,
 *         and the independent page-table audit sees the USER bit in the
 *         live tables - which is the point of auditing the tables rather
 *         than trusting the mapper.
 *
 *  15  the probe fixup reports the faulting access as having SUCCEEDED.
 *      -> SEC-FAULT must FAIL. This one attacks the TEST INSTRUMENT on
 *         purpose: negative controls are only evidence if the instrument
 *         that reports "the CPU denied this" can itself be shown to fail
 *         when it lies.
 *
 *  16  the direct map is built without NX.
 *      -> SEC-PERM must FAIL on the W^X check, and SEC-FAULT must FAIL on
 *         the direct-map execute probe, because the fetch now succeeds.
 *         Two independent subsystems catch it: one reading the tables,
 *         one asking the CPU.
 */

#ifndef VEXOS_BOOT03_INJECT_H
#define VEXOS_BOOT03_INJECT_H

#ifndef VEX_FAULT_INJECT
#define VEX_FAULT_INJECT 0
#endif

#define VEX_INJECTED(n) (VEX_FAULT_INJECT == (n))

#endif /* VEXOS_BOOT03_INJECT_H */
