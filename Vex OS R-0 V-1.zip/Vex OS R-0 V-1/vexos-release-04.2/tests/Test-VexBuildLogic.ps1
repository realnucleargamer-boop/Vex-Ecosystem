# Vex OS - test harness for the build-environment changes.
#
# SCOPE / HONESTY NOTE: this runs on Linux PowerShell 7. It exercises the
# platform-independent logic of VexToolchain.ps1 and VexDisk.ps1 -
# resolution order, override handling, cache validation, error-message
# content, diskpart output parsing, and the host-safety guards. It CANNOT
# exercise: real diskpart, real VHD attach/detach, drive-letter assignment,
# the registry probe, Windows path candidates, or clang/nasm invocation.
# Those require a Windows host.

$ErrorActionPreference = "Stop"
Set-StrictMode -Off

$RepoRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $RepoRoot "scripts/VexToolchain.ps1")
. (Join-Path $RepoRoot "scripts/VexDisk.ps1")

$script:pass = 0
$script:fail = 0

function Check($name, $condition, $detail) {
    if ($condition) {
        Write-Host "  PASS  $name" -ForegroundColor Green
        $script:pass++
    } else {
        Write-Host "  FAIL  $name" -ForegroundColor Red
        if ($detail) { Write-Host "        $detail" -ForegroundColor DarkYellow }
        $script:fail++
    }
}

$sandbox = "/tmp/vextest"
if (Test-Path $sandbox) { Remove-Item $sandbox -Recurse -Force }
New-Item -ItemType Directory -Force -Path $sandbox | Out-Null

# ==================================================================
Write-Host "`n[1] Expand-VexDirCandidate" -ForegroundColor Cyan
# ==================================================================
New-Item -ItemType Directory -Force -Path "$sandbox/wg/LLVM.LLVM_abc/bin" | Out-Null
New-Item -ItemType Directory -Force -Path "$sandbox/wg/LLVM.LLVM_xyz/bin" | Out-Null

$r = Expand-VexDirCandidate "$sandbox/wg/LLVM.LLVM_*/bin"
Check "wildcard candidate expands to both matches" ($r.Count -eq 2) "got $($r.Count): $($r -join ',')"
Check "wildcard results are real directories" (($r | Where-Object { Test-Path $_ }).Count -eq 2) ""

$r = Expand-VexDirCandidate "$sandbox/does/not/exist"
Check "non-existent literal candidate yields nothing" ($r.Count -eq 0) "got $($r -join ',')"

$r = Expand-VexDirCandidate "$sandbox/nope-*/bin"
Check "non-matching wildcard yields nothing (no throw)" ($r.Count -eq 0) "got $($r -join ',')"

$r = Expand-VexDirCandidate $null
Check "null candidate yields nothing (no throw)" ($r.Count -eq 0) ""

# ==================================================================
Write-Host "`n[2] Resolve-VexTool - override handling" -ForegroundColor Cyan
# ==================================================================
New-Item -ItemType Directory -Force -Path "$sandbox/nasmdir" | Out-Null
Set-Content -Path "$sandbox/nasmdir/nasm.exe" -Value "fake"
New-Item -ItemType Directory -Force -Path "$sandbox/llvmroot/bin" | Out-Null
Set-Content -Path "$sandbox/llvmroot/bin/clang.exe" -Value "fake"

$p = Resolve-VexTool -Exe "nasm.exe" -OverrideValue "$sandbox/nasmdir"
Check "override as directory resolves" ($p -eq "$sandbox/nasmdir/nasm.exe") "got '$p'"

$p = Resolve-VexTool -Exe "nasm.exe" -OverrideValue "$sandbox/nasmdir/nasm.exe"
Check "override as exact file resolves" ($p -eq "$sandbox/nasmdir/nasm.exe") "got '$p'"

$p = Resolve-VexTool -Exe "clang.exe" -OverrideValue "$sandbox/llvmroot"
Check "override falls back to <dir>/bin" ($p -eq "$sandbox/llvmroot/bin/clang.exe") "got '$p'"

$quotedOverride = '  "' + "$sandbox/nasmdir" + '"  '
$p = Resolve-VexTool -Exe "nasm.exe" -OverrideValue $quotedOverride
Check "override tolerates surrounding quotes/whitespace" ($p -eq "$sandbox/nasmdir/nasm.exe") "got '$p'"

$threw = $false; $msg = ""
try { Resolve-VexTool -Exe "nasm.exe" -OverrideValue "$sandbox/bogus" | Out-Null }
catch { $threw = $true; $msg = $_.Exception.Message }
Check "bad override throws instead of silently falling through" $threw ""
Check "bad-override message names the exe and the bin fallback" ($msg -match "nasm\.exe" -and $msg -match "bin") "got '$msg'"

# ==================================================================
Write-Host "`n[3] Resolve-VexTool - candidate directory search" -ForegroundColor Cyan
# ==================================================================
$p = Resolve-VexTool -Exe "nasm.exe" -CandidateDirs @("$sandbox/none1","$sandbox/nasmdir","$sandbox/none2")
Check "finds exe in a later candidate dir" ($p -eq "$sandbox/nasmdir/nasm.exe") "got '$p'"

$p = Resolve-VexTool -Exe "clang.exe" -CandidateDirs @("$sandbox/llvmroot")
Check "candidate dir search also tries <dir>/bin" ($p -eq "$sandbox/llvmroot/bin/clang.exe") "got '$p'"

$p = Resolve-VexTool -Exe "clang.exe" -CandidateDirs @("$sandbox/wg/LLVM.LLVM_*/bin")
Check "wildcard candidate dir with no exe returns null" ($null -eq $p) "got '$p'"

Set-Content -Path "$sandbox/wg/LLVM.LLVM_xyz/bin/clang.exe" -Value "fake"
$p = Resolve-VexTool -Exe "clang.exe" -CandidateDirs @("$sandbox/wg/LLVM.LLVM_*/bin")
Check "wildcard candidate dir finds exe once present" ($p -eq "$sandbox/wg/LLVM.LLVM_xyz/bin/clang.exe") "got '$p'"

$p = Resolve-VexTool -Exe "totally-absent-tool.exe" -CandidateDirs @("$sandbox/none")
Check "genuinely missing tool returns null (caller decides)" ($null -eq $p) "got '$p'"

$threw = $false
try { $p = Resolve-VexTool -Exe "nasm.exe" -CandidateDirs @("$sandbox/nope") -RegistryDisplayNameLike "NASM*" }
catch { $threw = $true }
Check "registry probe on a non-Windows host does not throw" (-not $threw) ""

# ==================================================================
Write-Host "`n[4] Toolchain cache: write, read, stale invalidation" -ForegroundColor Cyan
# ==================================================================
$fakeRepo = "$sandbox/repo"
New-Item -ItemType Directory -Force -Path "$fakeRepo/build" | Out-Null

Write-VexToolchainCache $fakeRepo @{ nasm = "$sandbox/nasmdir/nasm.exe"; clang = "$sandbox/llvmroot/bin/clang.exe" }
$cachePath = Get-VexToolchainCachePath $fakeRepo
Check "cache file is written to build/toolchain.local.json" (Test-Path $cachePath) "expected $cachePath"

$c = Read-VexToolchainCache $fakeRepo
Check "cache round-trips both entries" ($c.Count -eq 2 -and $c["nasm"] -eq "$sandbox/nasmdir/nasm.exe") "got $($c.Count)"

# Simulate the user uninstalling / moving NASM.
Remove-Item "$sandbox/nasmdir/nasm.exe" -Force
$c = Read-VexToolchainCache $fakeRepo
Check "stale cache entry is dropped, not returned" (-not $c.ContainsKey("nasm")) "got keys: $($c.Keys -join ',')"
Check "still-valid cache entry survives" ($c.ContainsKey("clang")) "got keys: $($c.Keys -join ',')"
Set-Content -Path "$sandbox/nasmdir/nasm.exe" -Value "fake"

Set-Content -Path $cachePath -Value "{ this is not json"
$threw = $false
try { $c = Read-VexToolchainCache $fakeRepo } catch { $threw = $true }
Check "corrupt cache is discarded, not fatal" ((-not $threw) -and $c.Count -eq 0) "threw=$threw count=$($c.Count)"

Set-Content -Path $cachePath -Value ""
$c = Read-VexToolchainCache $fakeRepo
Check "empty cache file is handled" ($c.Count -eq 0) ""

$c = Read-VexToolchainCache "$sandbox/no-such-repo"
Check "absent cache file is handled" ($c.Count -eq 0) ""

# Cache-write failure must not be fatal (read-only build dir).
$roRepo = "$sandbox/roRepo"
New-Item -ItemType Directory -Force -Path "$roRepo/build" | Out-Null
chmod 500 "$roRepo/build"
$threw = $false
try { Write-VexToolchainCache $roRepo @{ nasm = "$sandbox/nasmdir/nasm.exe" } } catch { $threw = $true }
Check "unwritable cache location is non-fatal" (-not $threw) ""
chmod 700 "$roRepo/build"

# ==================================================================
Write-Host "`n[5] Resolve-VexToolchain - missing-tool error quality" -ForegroundColor Cyan
# ==================================================================
# No LLVM/NASM on this host and no overrides, so this must fail - the point
# is that it fails with an actionable message rather than a bare exception.
Remove-Item Env:VEXOS_NASM -ErrorAction SilentlyContinue
Remove-Item Env:VEXOS_LLVM_BIN -ErrorAction SilentlyContinue
$msg = ""
try { Resolve-VexToolchain -RepoRoot "$sandbox/repo2" -Require @("nasm") -Quiet | Out-Null }
catch { $msg = $_.Exception.Message }
Check "missing tool produces an error" ($msg -ne "") ""
Check "error names the missing executable" ($msg -match "nasm\.exe") "got: $msg"
Check "error gives an install command" ($msg -match "winget install NASM") "got: $msg"
Check "error names the env override to use" ($msg -match "VEXOS_NASM") "got: $msg"
Check "error explains the NASM-not-on-PATH root cause" ($msg -match "does not add itself to PATH") "got: $msg"
Check "error lists what was searched" ($msg -match "Searched, in order") "got: $msg"

# ==================================================================
Write-Host "`n[6] Resolve-VexToolchain - env override end-to-end + PATH injection" -ForegroundColor Cyan
# ==================================================================
$env:VEXOS_NASM = "$sandbox/nasmdir"
$pathBefore = $env:PATH
$tc = Resolve-VexToolchain -RepoRoot "$sandbox/repo3" -Require @("nasm") -Quiet
Check "override drives full resolution" ($tc["nasm"] -eq "$sandbox/nasmdir/nasm.exe") "got $($tc['nasm'])"
Check "resolved dir is injected into process PATH" ($env:PATH -like "*$sandbox/nasmdir*") ""
Check "process PATH is only prepended to, not replaced" ($env:PATH.EndsWith($pathBefore)) ""

# Second call must not duplicate the entry.
$tc = Resolve-VexToolchain -RepoRoot "$sandbox/repo3" -Require @("nasm") -Quiet
$occurrences = ([regex]::Matches($env:PATH, [regex]::Escape("$sandbox/nasmdir"))).Count
Check "repeated runs do not duplicate PATH entries" ($occurrences -eq 1) "occurrences=$occurrences"

# An override pointing at a real install must win over a stale cache entry.
Write-VexToolchainCache "$sandbox/repo3" @{ nasm = "$sandbox/llvmroot/bin/clang.exe" }
$tc = Resolve-VexToolchain -RepoRoot "$sandbox/repo3" -Require @("nasm") -Quiet
Check "env override takes precedence over cache" ($tc["nasm"] -eq "$sandbox/nasmdir/nasm.exe") "got $($tc['nasm'])"
# Case-insensitive dedup: a differently-cased PATH entry must not produce a
# duplicate on every run (Windows paths are case-insensitive).
$env:PATH = ($sandbox.ToUpper() + "/NASMDIR") + [IO.Path]::PathSeparator + $pathBefore
$pathWithUpper = $env:PATH
$tc = Resolve-VexToolchain -RepoRoot "$sandbox/repo3" -Require @("nasm") -Quiet
Check "case-differing PATH entry is treated as already present" ($env:PATH -eq $pathWithUpper) "PATH grew unexpectedly"

# Trailing-separator dedup.
$env:PATH = "$sandbox/nasmdir/" + [IO.Path]::PathSeparator + $pathBefore
$pathWithSlash = $env:PATH
$tc = Resolve-VexToolchain -RepoRoot "$sandbox/repo3" -Require @("nasm") -Quiet
Check "trailing-separator PATH entry is treated as already present" ($env:PATH -eq $pathWithSlash) "PATH grew unexpectedly"

$env:PATH = $pathBefore
Remove-Item Env:VEXOS_NASM

# Cache hit path (no override): seed cache, confirm it is used.
Write-VexToolchainCache "$sandbox/repo4" @{ nasm = "$sandbox/nasmdir/nasm.exe" }
$tc = Resolve-VexToolchain -RepoRoot "$sandbox/repo4" -Require @("nasm") -Quiet
Check "valid cache entry is reused without rediscovery" ($tc["nasm"] -eq "$sandbox/nasmdir/nasm.exe") "got $($tc['nasm'])"
$env:PATH = $pathBefore

# -Refresh must bypass the cache (and therefore fail here, since NASM is
# genuinely absent from this host).
$msg = ""
try { Resolve-VexToolchain -RepoRoot "$sandbox/repo4" -Require @("nasm") -Refresh -Quiet | Out-Null }
catch { $msg = $_.Exception.Message }
Check "-Refresh bypasses the cache" ($msg -match "nasm\.exe") "got: $msg"

# ==================================================================
Write-Host "`n[7] Invoke-VexDiskpart - output/exit-code error detection" -ForegroundColor Cyan
# ==================================================================
# Mock diskpart. The real one is Windows-only; what is testable here is
# whether the wrapper correctly classifies success vs failure.
$mockDir = "$sandbox/mockbin"
New-Item -ItemType Directory -Force -Path $mockDir | Out-Null

function Set-MockDiskpart([string]$body) {
    Set-Content -Path "$mockDir/diskpart" -Value $body
    chmod 755 "$mockDir/diskpart"
}
$env:PATH = "$mockDir" + [IO.Path]::PathSeparator + $pathBefore

Set-MockDiskpart @'
#!/bin/sh
echo "DiskPart successfully created the virtual disk file."
exit 0
'@
$res = Invoke-VexDiskpart -Lines @("create vdisk file=`"x.vhd`" maximum=64 type=fixed") -WorkDir $sandbox -Label "mock"
Check "clean run is classified as success" (-not $res.Failed) "output: $($res.Output)"

Set-MockDiskpart @'
#!/bin/sh
echo "DiskPart has encountered an error: The parameter is incorrect."
exit 0
'@
$threw = $false; $msg = ""
try { Invoke-VexDiskpart -Lines @("assign letter=V") -WorkDir $sandbox -Label "mock create" | Out-Null }
catch { $threw = $true; $msg = $_.Exception.Message }
Check "error string in output is detected despite exit code 0" $threw "diskpart exit code alone is unreliable"
Check "thrown message includes the diskpart script" ($msg -match "assign letter=V") "got: $msg"
Check "thrown message includes the diskpart output" ($msg -match "encountered an error") "got: $msg"

$res = Invoke-VexDiskpart -Lines @("detach vdisk") -WorkDir $sandbox -Label "mock" -Tolerant
Check "-Tolerant reports failure without throwing" ($res.Failed -and $res.Output -match "encountered an error") ""

Set-MockDiskpart @'
#!/bin/sh
echo "There is no virtual disk selected."
exit 0
'@
$res = Invoke-VexDiskpart -Lines @("detach vdisk") -WorkDir $sandbox -Label "mock" -Tolerant
Check "'no virtual disk selected' is treated as failure" ($res.Failed) ""

Set-MockDiskpart @'
#!/bin/sh
echo "boom" >&2
exit 3
'@
$res = Invoke-VexDiskpart -Lines @("x") -WorkDir $sandbox -Label "mock" -Tolerant
Check "non-zero exit code is treated as failure" ($res.Failed -and $res.ExitCode -eq 3) "code=$($res.ExitCode)"

$leftovers = Get-ChildItem $sandbox -Filter "diskpart_*.txt" -ErrorAction SilentlyContinue
Check "temp diskpart scripts are cleaned up" ($leftovers.Count -eq 0) "left: $($leftovers.Name -join ',')"

# diskpart entirely unlaunchable. This must be classified as failure even
# though $LASTEXITCODE from the previous command may still be 0.
$env:PATH = $pathBefore
$global:LASTEXITCODE = 0
$res = Invoke-VexDiskpart -Lines @("detach vdisk") -WorkDir $sandbox -Label "mock" -Tolerant
Check "unlaunchable diskpart is classified as failure, not success" ($res.Failed) "code=$($res.ExitCode) out=$($res.Output)"
Check "unlaunchable diskpart output explains the launch failure" ($res.Output -match "Could not launch diskpart") "got: $($res.Output)"

$env:PATH = $pathBefore

# ==================================================================
Write-Host "`n[8] Get-VexFreeDriveLetter - override validation" -ForegroundColor Cyan
# ==================================================================
$env:VEXOS_VHD_LETTER = "W"
$l = Get-VexFreeDriveLetter
Check "letter override is honoured verbatim" ($l.Count -eq 1 -and $l[0] -eq "W") "got $($l -join ',')"

$env:VEXOS_VHD_LETTER = "w:"
$l = Get-VexFreeDriveLetter
Check "override normalises case and trailing colon" ($l[0] -eq "W") "got $($l -join ',')"

$env:VEXOS_VHD_LETTER = "V:\"
$l = Get-VexFreeDriveLetter
Check "override normalises trailing backslash" ($l[0] -eq "V") "got $($l -join ',')"

foreach ($bad in @("C", "AB", "5", "")) {
    $env:VEXOS_VHD_LETTER = $bad
    $threw = $false
    try { Get-VexFreeDriveLetter | Out-Null } catch { $threw = $true }
    if ($bad -eq "") {
        Check "empty override is ignored (falls back to auto-select)" (-not $threw) ""
    } else {
        Check "invalid override '$bad' is rejected" $threw ""
    }
}
Remove-Item Env:VEXOS_VHD_LETTER -ErrorAction SilentlyContinue

$threw = $false
try { Get-VexUsedDriveLetters | Out-Null } catch { $threw = $true }
Check "used-letter enumeration survives a non-Windows host" (-not $threw) ""

# ==================================================================
Write-Host "`n[9] New-VexEfiVhd - host-safety and argument guards" -ForegroundColor Cyan
# ==================================================================
# These are the checks that must fire BEFORE diskpart is ever invoked. A bug
# that let a path outside build/ through to diskpart could format a host disk.
$bd = "$sandbox/repo/build"
New-Item -ItemType Directory -Force -Path $bd | Out-Null
New-Item -ItemType Directory -Force -Path "$sandbox/outside" | Out-Null

$threw = $false; $msg = ""
try { New-VexEfiVhd -VhdPath "$sandbox/outside/evil.vhd" -BuildDir $bd -SizeMB 64 | Out-Null }
catch { $threw = $true; $msg = $_.Exception.Message }
Check "VHD path outside the build dir is refused" $threw ""
Check "refusal message explains why" ($msg -match "outside the build directory") "got: $msg"

$threw = $false; $msg = ""
try { New-VexEfiVhd -VhdPath "$bd/vexos.img" -BuildDir $bd -SizeMB 64 | Out-Null }
catch { $threw = $true; $msg = $_.Exception.Message }
Check "non-.vhd extension is refused (diskpart requires .vhd)" $threw ""
Check "extension refusal explains diskpart's requirement" ($msg -match "diskpart requires") "got: $msg"

$threw = $false; $msg = ""
try { New-VexEfiVhd -VhdPath "$bd/vexos.vhd" -BuildDir $bd -SizeMB 32 -EspSizeMB 32 | Out-Null }
catch { $threw = $true; $msg = $_.Exception.Message }
Check "ESP larger than the disk is refused" $threw ""
Check "ESP-size refusal is specific" ($msg -match "must be smaller") "got: $msg"

# A path that merely shares a prefix with the build dir must not pass the
# guard - "build2" is not inside "build".
New-Item -ItemType Directory -Force -Path "$sandbox/repo/build2" | Out-Null
$threw = $false
try { New-VexEfiVhd -VhdPath "$sandbox/repo/build2/x.vhd" -BuildDir $bd -SizeMB 64 | Out-Null }
catch { $threw = $true }
Check "prefix-collision path (build2 vs build) is refused" $threw ""

# ==================================================================
Write-Host "`n[10] Remove-VexFileWithRetry / Dismount-VexVhd edge cases" -ForegroundColor Cyan
# ==================================================================
$threw = $false
try { Remove-VexFileWithRetry -Path "$sandbox/definitely-not-here.vhd" } catch { $threw = $true }
Check "deleting an absent file is a no-op" (-not $threw) ""

Set-Content -Path "$sandbox/deleteme.vhd" -Value "x"
Remove-VexFileWithRetry -Path "$sandbox/deleteme.vhd"
Check "deleting an existing file works" (-not (Test-Path "$sandbox/deleteme.vhd")) ""

$r = Dismount-VexVhd -Path "$sandbox/absent.vhd" -WorkDir $sandbox -Quiet
Check "detaching an absent VHD returns false without invoking diskpart" ($r -eq $false) "got $r"

# ==================================================================
Write-Host ("`n{0} passed, {1} failed" -f $script:pass, $script:fail) -ForegroundColor $(if ($script:fail -eq 0) { "Green" } else { "Red" })
if ($script:fail -gt 0) { exit 1 }
