# VexScript 2.0 Phase D — Hosted `vex::*` stubs

## Implemented namespaces
- `vex::info` — os_name, version, api_version (stub strings)
- `vex::time` — now, sleep (hosted; sleep capped 100ms)
- `vex::fs` — open/close/read/write on **in-memory VFS only**
- `vex::proc` — get_id, spawn (synthetic handles), exit (stub)
- `vex::thread` — current, spawn (synthetic), yield
- `vex::input` — poll/wait return 0 (no_event)

## Architecture
```
VexScript → vex::* → Hosted Backend → stubs/sandbox
```
Not kernel. Not syscalls. Not real host process/FS access outside the VFS sandbox.

## Notes
- Multi-segment `import vex::info` and `vex::info::os_name()` supported
- IR keeps `vex::` call names for hosted builtins
