#!/usr/bin/env python3
"""VexScript 3.0-B — tensor numeric core + IR 1.4 compatibility"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vexscript import __version__, __ir_version__
from vexscript.interpreter import Interpreter
from vexscript.compile_ir import run_via_ir, emit_ir_text
from vexscript.tensor_rt import tensor_create, tensor_fill, tensor_add, tensor_matmul, tensor_get

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

print("VexScript 3.0-B")
check("version", __version__.startswith("3."), __version__)
check("ir 1.4", __ir_version__ == "1.4", __ir_version__)

# pure runtime
a = tensor_fill(tensor_create("f32", 2, 2), 2.0)
b = tensor_fill(tensor_create("f32", 2, 2), 3.0)
c = tensor_add(a, b)
check("tensor_add", c.data == [5.0]*4, c.data)
m = tensor_matmul(
    tensor_fill(tensor_create("f32", 2, 3), 1.0),
    tensor_fill(tensor_create("f32", 3, 2), 2.0),
)
check("matmul shape", m.shape == (2, 2), m.shape)
check("matmul val", m.data[0] == 6.0, m.data)  # 1*2+1*2+1*2

src = '''
fn main() -> i32 {
    let a = tensor_create_2(2, 2);
    tensor_fill(a, 2);
    let b = tensor_create_2(2, 2);
    tensor_fill(b, 3);
    let c = tensor_add(a, b);
    println(tensor_get_2(c, 0, 0));
    println(tensor_length(c));
    return 0;
}
'''
i = Interpreter()
i.load(src, "t")
code = i.run_main()
check("ast tensor path", code == 0 and "5" in "".join(str(x) for x in i.output) and "4" in "".join(str(x) for x in i.output), i.output)

# IR path
code, out = run_via_ir(src)
check("ir tensor path", code == 0 and "5" in out and "4" in out, out)
text = emit_ir_text(src)
check("emit ir 1.4", "ir_version 1.4" in text, text[:80])

# 2.0+++ still works
src2 = 'fn main() -> i32 { println("Vex" + "AI"); return 0; }\n'
code, out = run_via_ir(src2)
check("compat string+", code == 0 and "VexAI" in out, out)

print(f"\n=== 3.0-B Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
