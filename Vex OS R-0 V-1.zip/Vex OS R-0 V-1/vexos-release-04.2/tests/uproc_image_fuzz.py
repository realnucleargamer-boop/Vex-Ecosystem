#!/usr/bin/env python3
"""PROC-01: differential fuzz of kernel/src/proc/uproc_image.c against an INDEPENDENT Python model of the VXE1 rules
(written from kernel/include/uproc.h, not from the C). Run: tests/uproc_image_fuzz.py [O2|asan]  (asan needs LD_PRELOAD=libasan.so)."""
import ctypes as C, os, random, struct, subprocess, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
kind = sys.argv[1] if len(sys.argv) > 1 else "O2"; out = os.path.join(ROOT, "build", "uproc-host"); os.makedirs(out, exist_ok=True)
flags = ["-O2"] if kind == "O2" else ["-O1", "-g", "-fsanitize=address,undefined", "-fno-sanitize-recover=undefined"]
so = os.path.join(out, f"libuimg_{kind}.so")
subprocess.check_call(["gcc", *flags, "-shared", "-fPIC", "-Wall", "-Wextra", "-std=gnu11", "-I" + os.path.join(ROOT, "kernel/include"),
                       os.path.join(ROOT, "kernel/src/proc/uproc_image.c"), os.path.join(ROOT, "tests/uproc_image_shim.c"), "-o", so])
L = C.CDLL(so); L.shim_validate.argtypes = [C.c_char_p, C.c_size_t, C.POINTER(C.c_uint32)]
ST = ["ok", "null", "too-small", "too-big", "bad-magic", "bad-version", "bad-header-size", "bad-flags", "bad-reserved", "bad-text-size", "text-out-of-image",
      "data-out-of-image", "data-too-large", "segments-overlap", "entry-outside-text", "bad-stack-pages"]
PAGE = 4096
def ref(b):
    n = len(b)
    if n < 48: return "too-small", None
    if n > 65536: return "too-big", None
    if b[:4] != b"VXE1": return "bad-magic", None
    ver, hs, fl = struct.unpack_from("<HHI", b, 4)
    if ver != 1: return "bad-version", None
    if hs != 48: return "bad-header-size", None
    if fl != 0: return "bad-flags", None
    entry, toff, tsz, doff, dsz, bss, stk, r0, r1 = struct.unpack_from("<9I", b, 12)
    if r0 or r1: return "bad-reserved", None
    if tsz == 0 or tsz > 16 * PAGE: return "bad-text-size", None
    if toff < 48 or toff + tsz > n: return "text-out-of-image", None
    if dsz == 0:
        if doff != 0: return "data-out-of-image", None
    elif doff < 48 or doff + dsz > n: return "data-out-of-image", None
    if dsz + bss > 16 * PAGE: return "data-too-large", None
    if dsz and not (toff + tsz <= doff or doff + dsz <= toff): return "segments-overlap", None
    if entry >= tsz: return "entry-outside-text", None
    if stk < 1 or stk > 4: return "bad-stack-pages", None
    return "ok", (entry, toff, tsz, doff, dsz, bss, stk, (tsz + PAGE - 1) // PAGE, (dsz + bss + PAGE - 1) // PAGE)
def build(text=b"\x90" * 64, data=b"hello", bss=0, stk=1, entry=0):
    h = 48; toff = h; doff = toff + len(text) if data else 0
    img = b"VXE1" + struct.pack("<HHIIIIIIIIII", 1, 48, 0, entry, toff, len(text), doff, len(data), bss, stk, 0, 0) + text + data
    return bytearray(img)
def check(img):
    o = (C.c_uint32 * 9)(); s = L.shim_validate(bytes(img), len(img), o)
    want, lay = ref(bytes(img)); got = ST[s]
    return got == want and (lay is None or tuple(o) == lay), got, want
rnd = random.Random(2026); bad = []; seen = {}; N = 0
INTERESTING = [0, 1, 2, 47, 48, 49, 4095, 4096, 4097, 65535, 65536, 65537, 0x7FFFFFFF, 0x80000000, 0xFFFFFFFE, 0xFFFFFFFF, 16 * 4096, 16 * 4096 + 1, 15 * 4096]
ok, g, w = check(build()); assert ok and g == "ok", (g, w)
for it in range(220000):
    img = build(text=bytes(rnd.randrange(256) for _ in range(rnd.choice([1, 16, 64, 5000]))), data=bytes(rnd.choice([0, 3, 100, 4100])) , bss=rnd.choice([0, 1, 4096, 70000]), stk=rnd.randint(1, 4))
    k = rnd.random()
    if k < .6:
        for _ in range(rnd.randint(1, 3)):
            off = rnd.choice([0, 4, 6, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44]) if rnd.random() < .9 else rnd.randrange(48)
            w = rnd.choice([1, 2, 4]); v = rnd.choice(INTERESTING) if rnd.random() < .7 else rnd.getrandbits(8 * w)
            img[off:off + w] = (v & ((1 << 8 * w) - 1)).to_bytes(w, "little")
    elif k < .8: img[rnd.randrange(len(img))] ^= 1 << rnd.randrange(8)
    elif k < .9: img = img[:rnd.randrange(0, len(img) + 1)]
    elif k < .95: img += bytes(rnd.randrange(65536 - len(img) + 3)) if len(img) < 65536 else b""
    ok, g, w = check(img); N += 1; seen[w] = seen.get(w, 0) + 1
    if not ok: bad.append((g, w, bytes(img[:48]).hex()))
for extra in (65536 - 4, 65536 - 4 + 1, 65536 - 4 + 100, 1 << 20):       # exactly 64 KiB (not too-big) and over it (too-big): deterministic boundary
    ok, g, w = check(bytearray(b"VXE1" + bytes(extra))); N += 1; seen[w] = seen.get(w, 0) + 1
    if not ok: bad.append((g, w, "boundary", extra))
assert seen.get("too-big", 0) >= 3
print(f"{N} mutated images: {N - len(bad)} agree with the independent model, {len(bad)} disagree [{kind}]")
print("outcome coverage:", {k: seen.get(k, 0) for k in ST[2:] + ["ok"]})
missing = [k for k in ST[2:] + ["ok"] if not seen.get(k)]; print("rules never exercised:", missing or "none")
for b in bad[:5]: print("DISAGREE", b)
sys.exit(0 if not bad and not missing else 1)
