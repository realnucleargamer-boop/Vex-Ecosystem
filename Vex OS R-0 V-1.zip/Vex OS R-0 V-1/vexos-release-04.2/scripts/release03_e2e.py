#!/usr/bin/env python3
"""Vex OS - scripts/release03_e2e.py : Release-03 features through REAL PS/2 input in QEMU (seeded image).
Settings, Valbook (Ctrl+S), window controls, Verminal commands incl. add user + sign-in as the new user."""
import os, re, sys, time
sys.path.insert(0, os.path.dirname(__file__))
from qemu_drive import Vm, ppm_to_png
SEED = sys.argv[1] if len(sys.argv) > 1 else "build/vexos-seed.img"; OUT = "build/release03"; os.makedirs(OUT, exist_ok=True); res = []
def check(ok, w, d=""): res.append(bool(ok)); print(("PASS  " if ok else "FAIL  ") + w + (f"  [{d}]" if d and not ok else ""), flush=True)
def cnt(vm, p): return len(re.findall(p, vm.serial()))
def rects(vm, tag):
    ls = [l for l in vm.serial().splitlines() if tag in l]
    return {m.group(1): tuple(map(int, m.groups()[1:])) for m in re.finditer(r"(\w+)=\((\d+),(\d+),(\d+),(\d+)\)", ls[-1])} if ls else {}
def mr(vm, dx, dy):
    while dx or dy:
        sx = max(-100, min(100, dx)); sy = max(-100, min(100, dy)); vm.mouse_move(sx, sy); dx -= sx; dy -= sy; time.sleep(0.03)
    time.sleep(0.35)
def clk(vm, x, y): mr(vm, -1500, -1000); mr(vm, x, y); vm.mouse_button(1); time.sleep(0.25); vm.mouse_button(0); time.sleep(0.7)
def click(vm, r): clk(vm, r[0] + r[2] // 2, r[1] + r[3] // 2)
K = {" ": "spc", ".": "dot", "-": "minus", "\n": "ret", '"': "shift-apostrophe"}
def typ(vm, s):
    for c in s: vm.sendkey(K.get(c) or ("shift-" + c.lower() if c.isupper() else c)); time.sleep(0.11)
    time.sleep(0.5)
def shot(vm, n): p = f"{OUT}/{n}.ppm"; vm.screendump(p); ppm_to_png(p, f"{OUT}/{n}.png")
vm = Vm(SEED, OUT, tag="E"); vm.wait_serial(r"\[ui\] lock screen shown", 150); time.sleep(1.2)
check(os.path.getsize(SEED) < 15 * 1048576, f"image {os.path.getsize(SEED)} bytes < 15 MiB")
typ(vm, "vexpass1\n"); time.sleep(1.2); D = rects(vm, "desktop shown")
check({"valb", "sett", "expl", "task", "term", "vbtn"} <= set(D), "desktop taskbar lists Verminal, Explorer, Task Manager, Valbook, Settings and the V menu")
click(vm, D["sett"]); time.sleep(0.5); S = rects(vm, "settings view shown"); tc = S["tclose"]; cx, cy = tc[0] + 40 - 1000, tc[1] - 6
check(cnt(vm, r"Settings launched") == 1, "Settings opens from the taskbar"); shot(vm, "01_settings_system")
clk(vm, cx + 121, cy + 52 + 2 * 36 + 16); time.sleep(0.4); clk(vm, cx + 260 + 46 + 17, cy + 150 + 17); check(cnt(vm, r"settings: accent color changed") == 1, "Personalization: choosing an accent colour changes the live UI accent"); shot(vm, "02_settings_personalization")
clk(vm, cx + 121, cy + 52 + 3 * 36 + 16); time.sleep(0.4); clk(vm, cx + 260 + 95, cy + 150 + 17); check(cnt(vm, r"PC speaker test started") == 1, "Sound: the speaker test really programs the PC speaker (and the page says audibility depends on the host)"); shot(vm, "03_settings_sound")
clk(vm, cx + 121, cy + 52 + 4 * 36 + 16); time.sleep(0.4); shot(vm, "04_settings_users")
click(vm, S["tmin"]); time.sleep(0.5); check("window minimized" in vm.serial(), "minimize button hides Settings (it keeps running)")
click(vm, D["valb"]); time.sleep(0.5); typ(vm, "hello valbook"); vm.sendkey("ctrl-s"); time.sleep(0.6); typ(vm, "n.txt\n"); time.sleep(0.7)
check(cnt(vm, r"valbook: saved /home/vex/n\.txt") == 1, "Valbook: Ctrl+S on an untitled document asks for a name and saves it through the filesystem"); shot(vm, "05_valbook")
V = rects(vm, "valbook view shown"); click(vm, V["term"]); time.sleep(0.6)
typ(vm, "v. open Settings\n"); time.sleep(0.8); check(cnt(vm, r"application brought to the foreground|\[ui\] settings view shown") >= 1, "v. open Settings restores the minimized app")
Sx = rects(vm, "settings view shown"); click(vm, Sx["term"]); time.sleep(0.5)
typ(vm, "v. audio test\n"); time.sleep(0.6); check(cnt(vm, r"v\. audio test: PC speaker tone started") == 1, "v. audio test drives the speaker and reports honestly")
typ(vm, "v. add user carol carol789\n"); time.sleep(1.0); check(cnt(vm, r"v\. add user: created carol") == 1, "v. add user: administrator creates 'carol'")
typ(vm, "v. search n.txt\n"); time.sleep(0.5); shot(vm, "06_terminal_commands")
typ(vm, "v. add user carol carol789\n"); time.sleep(0.6); check(cnt(vm, r"v\. add user rejected: That account name is already in use"), "v. add user: duplicate rejected")
check("carol789" not in vm.serial(), "the password never appears in the serial log")
typ(vm, "v. change users\n"); time.sleep(1.2); check(cnt(vm, r"session locked \(via v\. change users\)") == 1, "v. change users locks the session")
L = rects(vm, "lock screen shown"); click(vm, L["users"]); U = rects(vm, "users panel opened"); click(vm, U["item3"])
typ(vm, "carol789\n"); time.sleep(1.3); check(cnt(vm, r"signed in as carol") == 1, "the newly added user signs in with their own password")
D = rects(vm, "desktop shown"); click(vm, D["term"]); time.sleep(0.5); typ(vm, "v. add user eve eve12345\n"); time.sleep(0.8)
check(cnt(vm, r"v\. add user rejected: Only an administrator can create accounts") == 1, "v. add user by a standard user is REFUSED by the account store")
check(vm.alive() and "VEX KERNEL PANIC" not in vm.serial() and "UNHANDLED CPU EXCEPTION" not in vm.serial(), "no panic after the whole session")
vm.stop(); print(f"\n{sum(res)}/{len(res)} Release-03 end-to-end checks passed"); sys.exit(0 if all(res) else 1)
