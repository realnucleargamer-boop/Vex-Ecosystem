#!/usr/bin/env python3
"""Acceleration layer tests: device, workers (1-2), torch matmul, batch streams."""
import sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vexscript.interpreter import Interpreter
from vexscript.accel_rt import (
    gpu_available, device_set, workers_set, workers_get, MAX_CPU_WORKERS,
    accel_tensor_zeros, accel_tensor_fill, accel_matmul, parallel_map,
)
from vexscript.tensor_rt import tensor_create, tensor_fill, tensor_matmul

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

print("Accel layer")
check("max workers 2", MAX_CPU_WORKERS == 2)
check("workers clamp", workers_set(8) == 2 and workers_set(1) == 1)
workers_set(2)
check("workers get", workers_get() == 2)

# GPU: report honesty
ga = gpu_available()
check("gpu_available is 0 or 1", ga in (0, 1), ga)
r = device_set("cuda")
if ga:
    check("device_set cuda", r == 0)
else:
    check("device_set cuda falls back", r == -1)
    check("stays cpu", device_set("cpu") == 0)

# parallel_map order
out = parallel_map(lambda x: x * 2, [1, 2, 3, 4])
check("parallel_map", out == [2, 4, 6, 8], out)

# torch matmul speed vs pure for medium size
a = tensor_fill(tensor_create("f32", 64, 64), 1.0)
b = tensor_fill(tensor_create("f32", 64, 64), 1.0)
t0 = time.perf_counter()
for _ in range(20):
    r = tensor_matmul(a, b)
t1 = time.perf_counter() - t0
check("matmul result", abs(r.data[0] - 64.0) < 1e-3, r.data[0])
print(f"  BENCH matmul 64x64 x20 = {t1:.4f}s")

# accel tensor path
az = accel_tensor_zeros("f32", 32, 32)
accel_tensor_fill(az, 1.0)
bz = accel_tensor_zeros("f32", 32, 32)
accel_tensor_fill(bz, 2.0)
cz = accel_matmul(az, bz)
check("accel matmul shape", cz.shape == (32, 32), cz.shape)

# VexScript API
src = '''
fn main() -> i32 {
    workers_set(2);
    println(workers_get());
    println(gpu_available());
    device_set(0);
    println(device_get_code());
    rng_seed(1);
    let s0 = stream_create(8, 8, 1);
    let s1 = stream_create(8, 8, 1);
    fitness_set(s0, 0, 5);
    fitness_set(s1, 0, 9);
    stream_advance_batch2(s0, s1, 100);
    println(stream_generation(s0));
    return 0;
}
'''
i = Interpreter(); i.load(src, "t"); c = i.run_main()
check("vex accel api", c == 0 and i.output[0] == "2", i.output)

print(f"\n=== Accel: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
