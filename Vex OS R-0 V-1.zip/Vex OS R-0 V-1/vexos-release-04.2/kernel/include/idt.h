/*
 * Vex OS - kernel/include/idt.h
 *
 * BOOT-02A: 256-entry IDT covering all 32 CPU exception vectors with
 * real handlers, plus a catch-all for vectors 32-255 (defensive only
 * - nothing should reach them, since interrupts are never enabled
 * with `sti` in BOOT-02A; see kernel_entry.c and docs/BOOT-02A.md).
 *
 * InterruptFrame's field order is fixed by the exact push sequence
 * in isr_stubs.asm's isr_common - if you change one, you must change
 * the other. See the comment above isr_common for the full layout
 * derivation.
 */

#ifndef VEXOS_IDT_H
#define VEXOS_IDT_H

#include <stdint.h>

typedef struct __attribute__((packed)) {
    uint16_t offset_low;
    uint16_t selector;
    uint8_t  ist;         /* bits 0-2: IST index (0 = don't switch stacks) */
    uint8_t  type_attr;   /* present, DPL, gate type */
    uint16_t offset_mid;
    uint32_t offset_high;
    uint32_t zero;
} IdtEntry;

typedef struct __attribute__((packed)) {
    uint16_t limit;
    uint64_t base;
} IdtPtr;

/* Matches the exact stack layout isr_common in isr_stubs.asm
 * produces: general-purpose registers (pushed rax..r15, so laid out
 * r15..rax ascending from the stub's rsp), then vector, then
 * error_code, then the CPU's own hardware-pushed frame (always 5
 * qwords in 64-bit mode, even without a privilege change - Intel SDM
 * Vol.3 6.14.2: SS:RSP is unconditionally pushed in long mode). */
typedef struct __attribute__((packed)) {
    uint64_t r15, r14, r13, r12, r11, r10, r9, r8;
    uint64_t rbp, rdi, rsi, rdx, rcx, rbx, rax;
    uint64_t vector;
    uint64_t error_code;
    uint64_t rip;
    uint64_t cs;
    uint64_t rflags;
    uint64_t user_rsp;
    uint64_t ss;
} InterruptFrame;

void idt_init(void);

/* BOOT-02C: points the CALLING CPU's IDTR at the IDT the BSP built.
 *
 * The IDT is read-only once initialized, so sharing it across CPUs is
 * safe. This is done for APs specifically so that a fault on an AP
 * reaches the existing exception reporting path instead of escalating
 * to a triple fault and silently resetting the machine.
 *
 * This does NOT enable interrupts and does not unmask any interrupt
 * source. APs never execute `sti`.
 *
 * KERNEL-01 PHASE 1 UPDATE. The asymmetry documented here for BOOT-02C
 * is gone. The text was: "the shared IDT's exception gates use IST1 for
 * #DF, which resolves through the TSS - and APs have no TSS loaded. A
 * double fault on an AP is therefore NOT recoverable today." That is no
 * longer true: gdt_load_on_this_cpu() now issues `ltr` with a per-CPU
 * TSS whose IST1 points at a per-CPU double-fault stack, so the IST1
 * gate resolves on every online CPU and a #DF on an AP has a valid
 * stack to switch to.
 *
 * What has NOT changed: APs still do not execute `sti`, and the
 * dispatcher in idt.c still recognizes exactly one interrupt vector.
 * Phase 1 fixed the stack, not the dispatch. */
void idt_load_on_this_cpu(void);

/* SECURITY-02: makes exactly one vector (>=32) invocable by `int` from
 * Ring 3. Returns 1 on success, 0 if vector is out of the allowed range. */
int idt_allow_user_syscall_vector(uint32_t vector);

/* Triggers `int3` and returns normally if the IDT correctly routed
 * it to idt_common_handler and back via iretq - the concrete,
 * checkable proof (per BOOT-02A requirement #6) that the IDT is not
 * just installed but actually dispatching. Prints its own result to
 * serial; also returns 1 on success / 0 if something went visibly
 * wrong before returning (best-effort - most failure modes here are
 * a triple fault, which this obviously can't catch or report itself). */
int idt_self_test(void);

/* ---------------------------------------------------------------- *
 * BOOT-03: recoverable page-fault expectation.
 *
 * Lets a test say "I am about to touch address X and I expect a page
 * fault", so that #PF delivery, CR2 correctness, error-code decoding
 * and - crucially - RESUMPTION after the handler fixes the mapping can
 * all be proven. Without a hook like this, every page fault in Vex OS is
 * fatal, and "paging works" would rest on nothing having faulted yet,
 * which is not the same claim.
 *
 * This is a TEST FACILITY, not demand paging. There is no policy, no
 * backing store and no fault accounting. Exactly one expectation can be
 * outstanding at a time, and it applies to a single 4 KiB page.
 *
 * The physical frame is supplied by the CALLER, not allocated in the
 * handler. That is deliberate: the PMM lock disables interrupts and is
 * held across allocation, so calling the allocator from an interrupt
 * handler would invert the documented lock ordering. See
 * docs/BOOT-03-DESIGN-NOTE.md.
 * ---------------------------------------------------------------- */

typedef enum {
    /* Map `phys` at the faulting page with read/write, then resume. */
    IDT_PF_ACTION_MAP = 1,
    /* The page is already mapped read-only; make it writable, then
     * resume. Proves the write-protection bit is actually enforced. */
    IDT_PF_ACTION_MAKE_WRITABLE = 2
} IdtPageFaultAction;

/* Arms an expectation for the page containing `virt`. `phys` is used
 * only by IDT_PF_ACTION_MAP. Clears any previously recorded fault. */
void idt_expect_page_fault(uint64_t virt, uint64_t phys,
                           IdtPageFaultAction action);

/* Disarms without requiring a fault to have occurred. */
void idt_clear_page_fault_expectation(void);

/* Returns 1 if the armed fault actually happened and was handled.
 * Writes the observed CR2 and error code when non-NULL, so a test can
 * check that the CPU reported the address and the reason it expected
 * rather than merely that something faulted. */
int idt_page_fault_observed(uint64_t *out_cr2, uint64_t *out_error_code);

/* Total page faults handled through the expectation mechanism. */
uint64_t idt_page_faults_handled(void);

#endif /* VEXOS_IDT_H */
