/* Hardware-neutral INPUT-02 keyboard event interface. */
#ifndef VEXOS_INPUT_H
#define VEXOS_INPUT_H

#include <stdint.h>

#define VEX_INPUT_QUEUE_CAPACITY 64u

typedef enum {
    VEX_KEY_UNKNOWN = 0, VEX_KEY_A = 4, VEX_KEY_B = 5, VEX_KEY_C = 6,
    VEX_KEY_L = 15,
    VEX_KEY_ENTER = 40, VEX_KEY_ESCAPE = 41, VEX_KEY_BACKSPACE = 42,
    VEX_KEY_TAB = 43, VEX_KEY_SPACE = 44,
    VEX_KEY_LEFT = 80, VEX_KEY_RIGHT = 79, VEX_KEY_DOWN = 81, VEX_KEY_UP = 82,
    VEX_KEY_LCTRL = 224, VEX_KEY_LSHIFT = 225, VEX_KEY_LALT = 226,
    VEX_KEY_RCTRL = 228, VEX_KEY_RSHIFT = 229, VEX_KEY_RALT = 230
} VexKeyCode;

typedef enum { VEX_KEY_PRESS = 1, VEX_KEY_RELEASE = 2 } VexKeyAction;
enum { VEX_MOD_LSHIFT = 1u << 0, VEX_MOD_RSHIFT = 1u << 1,
       VEX_MOD_LCTRL = 1u << 2, VEX_MOD_RCTRL = 1u << 3,
       VEX_MOD_LALT = 1u << 4, VEX_MOD_RALT = 1u << 5 };

typedef struct { VexKeyCode key; VexKeyAction action; uint16_t modifiers; uint64_t sequence; } VexKeyEvent;

/* Safe before interrupt delivery. Drivers translate hardware scancodes then call publish. */
void input_init(void);
int input_publish_key(VexKeyCode key, VexKeyAction action);
int input_poll_key(VexKeyEvent *out); /* 1 event, 0 empty/invalid pointer */
uint16_t input_modifiers(void);
uint64_t input_dropped_events(void);
int input_self_test(void);

/* ------------------------------------------------------------------ *
 * INPUT-03: mouse events.
 *
 * Same module, same conventions as the key queue: a bounded ring, a
 * hardware-neutral event, drivers publish and the UI consumes.  There is
 * deliberately no second input subsystem.
 *
 * An event carries a RELATIVE movement (dx, dy; +y is DOWN on screen) and
 * the ABSOLUTE button mask after the packet.  Carrying the absolute mask
 * means a dropped event can never leave a consumer believing a button is
 * still down: the next event states the truth.
 *
 * Concurrency: producer (PS/2 poll) and consumer (UI loop) both run on the
 * BSP main loop, never from interrupt context, so there is no concurrent
 * access.  The fences below keep the ring correct if that ever changes to
 * one interrupt-context producer + one consumer; they do NOT make the
 * queue safe for several producers.
 * ------------------------------------------------------------------ */
#define VEX_MOUSE_QUEUE_CAPACITY 128u
enum { VEX_MOUSE_BTN_LEFT = 1u << 0, VEX_MOUSE_BTN_RIGHT = 1u << 1,
       VEX_MOUSE_BTN_MIDDLE = 1u << 2 };

typedef struct {
    int16_t  dx, dy;      /* relative movement, saturated to int16 */
    uint8_t  buttons;     /* absolute button mask after this event */
    uint64_t sequence;
} VexMouseEvent;

/* 1 = queued, 0 = dropped (queue full; counted) or buttons had undefined bits. */
int      input_publish_mouse(int32_t dx, int32_t dy, uint8_t buttons);
int      input_poll_mouse(VexMouseEvent *out);   /* 1 event, 0 empty/NULL */
uint8_t  input_mouse_buttons(void);              /* mask after last publish */
uint64_t input_mouse_dropped(void);
int      input_mouse_self_test(void);
#endif
