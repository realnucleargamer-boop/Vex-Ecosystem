# SECURITY-02: the script run-vexos.ps1 has always told you to run, now real.
# build.ps1 already syncs the runtime ESP automatically after a successful
# build; this exists for re-syncing/verifying without rebuilding.
[CmdletBinding()] param([switch]$VerifyOnly)
& (Join-Path $PSScriptRoot 'Sync-RuntimeEsp.ps1') -VerifyOnly:$VerifyOnly
