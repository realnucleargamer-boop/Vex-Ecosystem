#!/usr/bin/env python3
"""Compiles the REAL kernel/src/apps/vfs.c + vfs_cmds.c natively with AddressSanitizer/UBSan and runs tests/host/vfs_cmds_harness.c
against them: v. testpath / v. content semantics, permission isolation, traversal, truncation, bounds.
Does not prove kernel/terminal integration (see scripts/wallpaper_e2e.py for the real-QEMU run)."""
import os, subprocess, sys, tempfile
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
d = tempfile.mkdtemp(); exe = os.path.join(d, "t")
cc = ["gcc", "-std=gnu11", "-g", "-O1", "-fsanitize=address,undefined", "-fno-sanitize-recover=all", "-Wall", "-Wextra", "-I", os.path.join(root, "kernel/include"), "-I", os.path.join(root, "common/include"),
      "-DTIMER_TARGET_HZ=100", os.path.join(root, "tests/host/vfs_cmds_harness.c"), os.path.join(root, "kernel/src/apps/vfs.c"), os.path.join(root, "kernel/src/apps/vfs_cmds.c"), "-o", exe]
c = subprocess.run(cc, capture_output=True, text=True)
if c.returncode: print(c.stderr); sys.exit(1)
if c.stderr.strip(): print(c.stderr)
sys.exit(subprocess.run([exe]).returncode)
