#include "crypto.h"
static const uint32_t K[64] = {
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2 };
#define ROR(x,n) (((x) >> (n)) | ((x) << (32 - (n))))
static void block(Sha256 *c, const uint8_t *p)
{
    uint32_t w[64], a, b, cc, d, e, f, g, h;
    for (int i = 0; i < 16; i++) w[i] = ((uint32_t)p[4*i] << 24) | ((uint32_t)p[4*i+1] << 16) | ((uint32_t)p[4*i+2] << 8) | p[4*i+3];
    for (int i = 16; i < 64; i++) {
        uint32_t s0 = ROR(w[i-15], 7) ^ ROR(w[i-15], 18) ^ (w[i-15] >> 3), s1 = ROR(w[i-2], 17) ^ ROR(w[i-2], 19) ^ (w[i-2] >> 10);
        w[i] = w[i-16] + s0 + w[i-7] + s1;
    }
    a = c->h[0]; b = c->h[1]; cc = c->h[2]; d = c->h[3]; e = c->h[4]; f = c->h[5]; g = c->h[6]; h = c->h[7];
    for (int i = 0; i < 64; i++) {
        uint32_t t1 = h + (ROR(e, 6) ^ ROR(e, 11) ^ ROR(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i];
        uint32_t t2 = (ROR(a, 2) ^ ROR(a, 13) ^ ROR(a, 22)) + ((a & b) ^ (a & cc) ^ (b & cc));
        h = g; g = f; f = e; e = d + t1; d = cc; cc = b; b = a; a = t1 + t2;
    }
    c->h[0] += a; c->h[1] += b; c->h[2] += cc; c->h[3] += d; c->h[4] += e; c->h[5] += f; c->h[6] += g; c->h[7] += h;
}
void sha256_init(Sha256 *c)
{
    static const uint32_t iv[8] = { 0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19 };
    for (int i = 0; i < 8; i++) c->h[i] = iv[i];
    c->len = 0; c->fill = 0;
}
void sha256_update(Sha256 *c, const void *dv, size_t n)
{
    const uint8_t *d = dv; c->len += n;
    while (n--) { c->buf[c->fill++] = *d++; if (c->fill == 64) { block(c, c->buf); c->fill = 0; } }
}
void sha256_final(Sha256 *c, uint8_t out[32])
{
    uint64_t bits = c->len * 8; uint8_t pad = 0x80;
    sha256_update(c, &pad, 1); pad = 0;
    while (c->fill != 56) sha256_update(c, &pad, 1);
    uint8_t l[8]; for (int i = 0; i < 8; i++) l[i] = (uint8_t)(bits >> (56 - 8 * i));
    sha256_update(c, l, 8);
    for (int i = 0; i < 8; i++) { out[4*i] = (uint8_t)(c->h[i] >> 24); out[4*i+1] = (uint8_t)(c->h[i] >> 16); out[4*i+2] = (uint8_t)(c->h[i] >> 8); out[4*i+3] = (uint8_t)c->h[i]; }
}
void secure_zero(void *p, size_t n) { volatile uint8_t *v = p; while (n--) *v++ = 0; }
int ct_equal(const uint8_t *a, const uint8_t *b, size_t n) { uint8_t r = 0; for (size_t i = 0; i < n; i++) r |= (uint8_t)(a[i] ^ b[i]); return r == 0; }
void hmac_sha256(const uint8_t *key, size_t kl, const uint8_t *msg, size_t ml, uint8_t out[32])
{
    uint8_t k[64], pad[64], inner[32]; Sha256 c;
    for (int i = 0; i < 64; i++) k[i] = 0;
    if (kl > 64) { sha256_init(&c); sha256_update(&c, key, kl); sha256_final(&c, k); } else for (size_t i = 0; i < kl; i++) k[i] = key[i];
    for (int i = 0; i < 64; i++) pad[i] = k[i] ^ 0x36;
    sha256_init(&c); sha256_update(&c, pad, 64); sha256_update(&c, msg, ml); sha256_final(&c, inner);
    for (int i = 0; i < 64; i++) pad[i] = k[i] ^ 0x5c;
    sha256_init(&c); sha256_update(&c, pad, 64); sha256_update(&c, inner, 32); sha256_final(&c, out);
    secure_zero(k, 64); secure_zero(pad, 64);
}
/* single output block (dkLen = 32), RFC 8018 section 5.2 */
void pbkdf2_hmac_sha256(const uint8_t *pw, size_t pl, const uint8_t *salt, size_t sl, uint32_t iters, uint8_t out[32])
{
    uint8_t buf[64 + 4], u[32], t[32];                 /* salt <= 64 bytes in this OS */
    if (sl > 64) sl = 64;
    for (size_t i = 0; i < sl; i++) buf[i] = salt[i];
    buf[sl] = 0; buf[sl+1] = 0; buf[sl+2] = 0; buf[sl+3] = 1;
    hmac_sha256(pw, pl, buf, sl + 4, u);
    for (int i = 0; i < 32; i++) t[i] = u[i];
    for (uint32_t it = 1; it < iters; it++) { hmac_sha256(pw, pl, u, 32, u); for (int i = 0; i < 32; i++) t[i] ^= u[i]; }
    for (int i = 0; i < 32; i++) out[i] = t[i];
    secure_zero(u, 32); secure_zero(t, 32); secure_zero(buf, sizeof buf);
}
