#!/usr/bin/env python3
"""Vex OS - scripts/proc_e2e.py : PROC-01 acceptance (Ring 3 loader + syscall boundary) through REAL PS/2 typing in QEMU (dev-seeded image).

Path exercised: PS/2 key events -> Verminal (VexScript) -> os_cmd(12) -> kernel run_term_request -> proc_term / uproc_run
-> vxc_infer (integer network inside the kernel) -> term_out -> framebuffer + `[term]` serial mirror (which this script reads).
Every command waits for the kernel's own `[ui] v. ai: handled` marker, so a slow reply cannot pass or fail by timing luck.
  Build the seeded test image first:  make image EXTRA_CFLAGS="-DGRAPHICS2_VISUAL_DEMO=0 -DVEX_DEV_SEED_ACCOUNTS=1 -DVEX_TERM_MIRROR=1" && cp build/vexos.img build/vexos-seed.img
  python3 scripts/proc_e2e.py build/vexos-seed.img   (seed image needs -DGRAPHICS2_VISUAL_DEMO=0 -DVEX_DEV_SEED_ACCOUNTS=1 -DVEX_TERM_MIRROR=1)
"""
import os, re, sys, time
sys.path.insert(0, os.path.dirname(__file__))
from qemu_drive import Vm, ppm_to_png
SEED = sys.argv[1] if len(sys.argv) > 1 else "build/vexos-seed.img"; OUT = "build/proc_e2e"; os.makedirs(OUT, exist_ok=True); res = []
def check(ok, w, d=""): res.append(bool(ok)); print(("PASS  " if ok else "FAIL  ") + w + (f"  [{d}]" if d and not ok else ""), flush=True)
def cnt(vm, p): return len(re.findall(p, vm.serial()))
def rects(vm, tag):
    ls = [l for l in vm.serial().splitlines() if tag in l]
    return {m.group(1): tuple(map(int, m.groups()[1:])) for m in re.finditer(r"(\w+)=\((\d+),(\d+),(\d+),(\d+)\)", ls[-1])} if ls else {}
def mr(vm, dx, dy):
    while dx or dy:
        sx = max(-100, min(100, dx)); sy = max(-100, min(100, dy)); vm.mouse_move(sx, sy); dx -= sx; dy -= sy; time.sleep(0.03)
    time.sleep(0.35)
def clk(vm, x, y): mr(vm, -1500, -1000); mr(vm, x, y); vm.mouse_button(1); time.sleep(0.25); vm.mouse_button(0); time.sleep(0.7)
def click(vm, r): clk(vm, r[0] + r[2] // 2, r[1] + r[3] // 2)
K = {" ": "spc", ".": "dot", "-": "minus", "\n": "ret", "/": "slash", "+": "shift-equal", "*": "shift-8", "?": "shift-slash", "'": "apostrophe", '"': "shift-apostrophe", "=": "equal", "!": "shift-1"}
def typ(vm, s):
    for c in s: vm.sendkey(K.get(c) or ("shift-" + c.lower() if c.isupper() else c)); time.sleep(0.11)
    time.sleep(0.4)
def shot(vm, n): p = f"{OUT}/{n}.ppm"; vm.screendump(p); ppm_to_png(p, f"{OUT}/{n}.png")
def term_lines(vm): return [l[len("[term] "):].rstrip("\r") for l in vm.serial().splitlines() if l.startswith("[term] ")]
def ask(vm, cmd, timeout=170):
    """Type a terminal command; wait for the kernel's handled-marker; return (new [term] lines, new [ai] serial lines, seconds)."""
    n_h = cnt(vm, r"\[ui\] v\. proc: handled"); n_t = len(term_lines(vm)); a0 = [l for l in vm.serial().splitlines() if l.startswith("[ai]")]
    t0 = time.time(); typ(vm, cmd + "\n")
    while time.time() - t0 < timeout and cnt(vm, r"\[ui\] v\. proc: handled") <= n_h: time.sleep(0.5)
    time.sleep(0.8)
    ai = [l.rstrip("\r") for l in vm.serial().splitlines() if l.startswith("[ai]")][len(a0):]
    return term_lines(vm)[n_t:], ai, time.time() - t0
def show(tag, lines, ai, dt):
    print(f"--- {tag}  ({dt:.1f}s wall incl. typing)"); [print("   | " + l[:200]) for l in lines]; [print("   > " + l[:200]) for l in ai]


def ask(vm, cmd, timeout=280):
    n_h = cnt(vm, r"\[ui\] v\. proc: handled"); n_t = len(term_lines(vm)); t0 = time.time(); typ(vm, cmd + "\n")
    while time.time() - t0 < timeout and cnt(vm, r"\[ui\] v\. proc: handled") <= n_h: time.sleep(0.5)
    time.sleep(1.0); return term_lines(vm)[n_t:], time.time() - t0
vm = Vm(SEED, OUT, tag="P"); vm.wait_serial(r"\[ui\] lock screen shown", 200); time.sleep(1.2)
typ(vm, "vexpass1\n"); time.sleep(1.5); D = rects(vm, "desktop shown"); check("term" in D, "desktop is up and Verminal is on the taskbar")
click(vm, D["term"]); time.sleep(1.0)
L, dt = ask(vm, "v. proc"); check(any("PROC-01" in l for l in L) and any("One process at a time" in l for l in L), "`v. proc` prints usage and states the one-process / no-page-table / no-SMEP limits")
L, dt = ask(vm, "v. proc status"); print("status:", L); check(any("Loader ready" in l for l in L), "`v. proc status`: loader ready")
L, dt = ask(vm, "v. proc run hello"); print(L); t = " ".join(L); check("exited, code 15" in t and "program wrote: hello from vxe1" in t, "`v. proc run hello`: a VXE1 image loaded into Ring 3, WRITE served, exit code 15")
L, dt = ask(vm, "v. proc run ask"); print(L); t = " ".join(L); check("exited, code 15" in t and "program wrote: 12 plus 30 = 42" in t, "`v. proc run ask`: Ring 3 program asked Crystal through AI_ASK and got 12 plus 30 = 42")
L, dt = ask(vm, "v. proc run getpid"); print(L); m = re.search(r"pid (\d+) exited, code (\d+)", " ".join(L)); check(bool(m) and m.group(1) == m.group(2), "`v. proc run getpid`: GETPID returned the run's own pid")
L, dt = ask(vm, "v. proc run kread"); check(any("Only hello, ask and getpid" in l for l in L), "attack programs cannot be launched by name from the terminal")
shot(vm, "01_proc_run")
L, dt = ask(vm, "v. proc test", timeout=290); print("selftest wall:", round(dt), "s,", len(L), "lines"); [print("  |", l[:170]) for l in L if not l.startswith("PASS")]
m = re.search(r"Process selftest: (\d+)/(\d+) PASS", " ".join(L)); check(bool(m) and m.group(1) == m.group(2) and int(m.group(2)) >= 55, f"in-kernel `v. proc test`: {m.group(0) if m else 'no PASS summary'}")
check(not any(l.startswith("FAIL") for l in L), "no FAIL line in the in-kernel process selftest")
shot(vm, "02_proc_test")
s = vm.serial(); n_faults = len(re.findall(r"\[ring3\] USER FAULT isolated", s)); check(n_faults >= 15, f"serial: {n_faults} user faults isolated during the run, kernel continued (>= 15 expected)")
check(len(re.findall(r"TIMEOUT \(cpu budget\)", s)) >= 2, "serial: both runaway programs ended by the CPU watchdog")
check(re.search(r"\[uproc\] selftest: (\d+)/\1 PASS", s) is not None, "serial records the selftest summary")
check("frames not released" not in s, "serial: no frame-release warning from the loader")
n0 = cnt(vm, r"\[ui\] v\. proc: handled")
t0 = time.time(); typ(vm, "v. ai what is 12 plus 30\n"); time.sleep(8); check("12 plus 30 = 42" in " ".join(term_lines(vm)[-6:]), "after all attacks, Crystal still answers 12 plus 30 = 42")
check(not re.search(r"VEX KERNEL PANIC|UNHANDLED CPU EXCEPTION|\[kernel\] FATAL", s), "no kernel panic / unhandled CPU exception / FATAL during the whole session")
open(f"{OUT}/serial_full.log", "w").write(vm.serial()); vm.stop()
print(f"\n{sum(res)}/{len(res)} PROC-01 end-to-end checks passed"); sys.exit(0 if all(res) else 1)
