/*
 * crystal_kernel.h - kernel adapter for the native Crystal core (CRYSTAL-NATIVE-01).
 *
 * TEMPORARY ARCHITECTURE: Crystal runs INSIDE the kernel at Ring 0 with no process isolation. The only protections are
 * the core's own input validation and bounds checks (see docs/CRYSTAL-NATIVE-01.md s5.3/s6). This adapter is the only
 * kernel-specific code; kernel/src/ai/crystal_core.c is kernel-independent and is meant to move behind a Ring 3 service.
 */
#ifndef CRYSTAL_KERNEL_H
#define CRYSTAL_KERNEL_H

#include <stddef.h>
#include <stdint.h>

typedef void (*crystal_emit_fn)(const char *line);

/* Handle the argument text of `v. ai <arg>` (terminal request kind 11). `arg` is NUL-terminated and at most
 * VTH_ARG_MAX bytes. Empty -> usage; "/status" -> model facts; "/selftest" -> in-kernel known-answer + boundary tests;
 * anything else -> one real inference. Output is emitted line by line through `emit` (never more than ~12 lines). */
void crystal_kernel_term(const char *arg, crystal_emit_fn emit);

/* PROC-01: programmatic entry for the Ring 3 AI_ASK syscall. `text` is a KERNEL copy (len <= 256, printable ASCII).
 * Writes the NUL-terminated reply to `out` (kernel buffer, capacity cap >= 1). Returns the reply length (>= 0), or a
 * negative code: -1 bad argument, -2 too long, -3 bad character, -100 busy, -101 model unavailable. */
int crystal_kernel_ask(const char *text, size_t len, char *out, size_t cap);

#endif
