#!/usr/bin/env python3
"""VexScript readiness expansion tests (genome, streams, fitness, migration)."""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vexscript import __version__
from vexscript.interpreter import Interpreter
from vexscript.genome_rt import (
    genome_create, genome_from_string, genome_char_at, genome_set_char,
    genome_slice, genome_length, genome_compare, genome_copy, reset_genome_state,
)

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

def run(src):
    i = Interpreter(); i.load(src, "t"); c = i.run_main(); return c, list(i.output)

print("Readiness expansion")
check("version 3.2+", __version__.startswith("3."), __version__)

# --- Genome pure ---
reset_genome_state()
g = genome_from_string("Ab0.-=")
check("len", genome_length(g) == 6)
check("char_at", genome_char_at(g, 0) == "A" and genome_char_at(g, 5) == "=")
check("oob", genome_char_at(g, 99) == "")
check("set", genome_set_char(g, 1, "Z") == 0 and genome_char_at(g, 1) == "Z")
check("set_oob", genome_set_char(g, 99, "X") == -1)
s = genome_slice(g, 0, 3)
check("slice", genome_length(s) == 3)
c = genome_copy(g)
check("copy_eq", genome_compare(g, c) == 0)

# --- Genome via VexScript ---
src = '''
fn main() -> i32 {
    let g = genome_from_string("Hello");
    println(genome_length(g));
    println(genome_char_at(g, 1));
    genome_set_char(g, 0, "J");
    println(genome_to_string(g));
    let h = genome_slice(g, 0, 2);
    println(genome_length(h));
    let mut buf = genome_create(16);
    genome_append_char(buf, "A");
    genome_append_char(buf, "B");
    println(genome_to_string(buf));
    return 0;
}
'''
code, out = run(src)
check("vex genome", code == 0 and out[0] == "5" and out[1] == "e" and "Jello" in out, out)

# --- Streams + fitness + elite ---
src = '''
fn main() -> i32 {
    rng_seed(42);
    let s = stream_create(8, 16, 2);
    println(stream_size(s));
    println(elite_preserve_count(s));
    fitness_set(s, 0, 10);
    fitness_set(s, 1, 50);
    fitness_set(s, 2, 20);
    println(fitness_best_index(s));
    println(fitness_worst_index(s));
    println(fitness_average(s));
    let mut gen = stream_generation(s);
    gen = stream_advance(s, 200);
    println(gen);
    println(stream_generation(s));
    return 0;
}
'''
code, out = run(src)
check("stream fitness", code == 0 and out[0] == "8" and out[1] == "2" and out[2] == "1", out)

# --- Migration ---
src = '''
fn main() -> i32 {
    rng_seed(7);
    let a = stream_create(4, 8, 1);
    let b = stream_create(4, 8, 1);
    fitness_set(a, 0, 100);
    fitness_set(a, 1, 10);
    migrate_best(a, b, 3);
    println(fitness_get(b, 3));
    migrate_copy(a, 1, b, 0);
    println(0);
    return 0;
}
'''
code, out = run(src)
check("migrate", code == 0 and out[0] == "100", out)

# --- Diversity ---
src = '''
fn main() -> i32 {
    rng_seed(1);
    let s = stream_create(5, 16, 1);
    evolve_randomize(stream_pop(s));
    let d = diversity_hamming_avg(s);
    println(d);
    return 0;
}
'''
code, out = run(src)
check("diversity", code == 0 and len(out) == 1, out)

# --- Multi-stream independent ---
src = '''
fn main() -> i32 {
    rng_seed(99);
    let s0 = stream_create(10, 8, 1);
    let s1 = stream_create(10, 8, 1);
    fitness_set(s0, 0, 1);
    fitness_set(s1, 0, 9);
    println(fitness_get(s0, 0));
    println(fitness_get(s1, 0));
    stream_advance(s0, 100);
    println(stream_generation(s0));
    println(stream_generation(s1));
    return 0;
}
'''
code, out = run(src)
check("multi-stream", code == 0 and out[0] == "1" and out[1] == "9" and out[2] == "1" and out[3] == "0", out)

# --- RNG still deterministic ---
src = '''
fn main() -> i32 {
    rng_seed(42);
    println(rng_u64());
    return 0;
}
'''
c1, o1 = run(src); c2, o2 = run(src)
check("rng det", o1 == o2)

# --- Larger scale ---
src = '''
fn main() -> i32 {
    rng_seed(42);
    let s = stream_create(100, 32, 5);
    let mut i: i64 = 0;
    while (i < 100) {
        fitness_set(s, i, i);
        i = i + 1;
    }
    println(fitness_best_index(s));
    println(fitness_sum(s));
    let mut g: i64 = 0;
    while (g < 5) {
        stream_advance(s, 150);
        g = g + 1;
    }
    println(stream_generation(s));
    return 0;
}
'''
code, out = run(src)
check("scale 100x32 g5", code == 0 and out[0] == "99" and out[2] == "5", out)

# regression string
src = 'fn main() -> i32 { println(concat("Vex", "Script")); return 0; }\n'
code, out = run(src)
check("string compat", code == 0 and out == ["VexScript"], out)

print(f"\n=== Readiness expansion: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
