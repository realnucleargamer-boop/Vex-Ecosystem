/*
 * Vex OS - kernel/src/arch/x86_64/cpu/ap_stack.c
 */

#include "ap_stack.h"
#include "pmm.h"

uint64_t ap_stack_alloc_top(void)
{
    uint64_t base = pmm_alloc_pages(AP_STACK_SIZE_PAGES);
    return base + (uint64_t)AP_STACK_SIZE_PAGES * PMM_PAGE_SIZE;
}
