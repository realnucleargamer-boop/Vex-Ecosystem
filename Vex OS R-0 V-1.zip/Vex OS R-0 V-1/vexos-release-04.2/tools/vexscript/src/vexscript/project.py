"""VexScript project discovery and vex.toml loading (Phase C)."""
from __future__ import annotations
import tomllib
from dataclasses import dataclass
from pathlib import Path
from .errors import VexError, SourceLocation


@dataclass
class ProjectConfig:
    root: Path
    name: str
    version: str
    entry: Path  # absolute path to entry source


def find_project_root(start: Path | None = None) -> Path:
    """Walk upward from start (or cwd) looking for vex.toml."""
    cur = (start or Path.cwd()).resolve()
    if cur.is_file():
        cur = cur.parent
    for p in [cur, *cur.parents]:
        if (p / "vex.toml").is_file():
            return p
    raise VexError(
        "missing vex.toml (not inside a VexScript project)",
        error_code="E0401",
    )


def load_manifest(root: Path) -> ProjectConfig:
    path = root / "vex.toml"
    if not path.is_file():
        raise VexError(
            f"missing vex.toml in {root}",
            SourceLocation(str(path), 1, 1),
            error_code="E0401",
        )
    try:
        data = tomllib.loads(path.read_text())
    except tomllib.TOMLDecodeError as e:
        raise VexError(
            f"malformed vex.toml: {e}",
            SourceLocation(str(path), 1, 1),
            error_code="E0402",
        ) from e

    if not isinstance(data, dict):
        raise VexError("malformed vex.toml: expected table", error_code="E0402")

    pkg = data.get("package")
    if not isinstance(pkg, dict):
        raise VexError(
            "vex.toml missing [package]",
            SourceLocation(str(path), 1, 1),
            error_code="E0402",
        )
    name = pkg.get("name")
    version = pkg.get("version")
    if not name or not isinstance(name, str):
        raise VexError(
            "vex.toml [package] missing name",
            SourceLocation(str(path), 1, 1),
            error_code="E0402",
        )
    if not version or not isinstance(version, str):
        raise VexError(
            "vex.toml [package] missing version",
            SourceLocation(str(path), 1, 1),
            error_code="E0402",
        )

    build = data.get("build")
    if not isinstance(build, dict):
        raise VexError(
            "vex.toml missing [build]",
            SourceLocation(str(path), 1, 1),
            error_code="E0402",
        )
    entry_rel = build.get("entry")
    if not entry_rel or not isinstance(entry_rel, str):
        raise VexError(
            "vex.toml [build] missing entry",
            SourceLocation(str(path), 1, 1),
            error_code="E0402",
        )

    entry = (root / entry_rel).resolve()
    if not entry.is_file():
        raise VexError(
            f"invalid entry file: {entry_rel}",
            SourceLocation(str(path), 1, 1),
            error_code="E0403",
        )

    return ProjectConfig(root=root, name=name, version=version, entry=entry)


def load_project(start: Path | None = None) -> ProjectConfig:
    root = find_project_root(start)
    return load_manifest(root)
