/*
 * Vex OS - kernel/include/kernel01_tests.h
 *
 * KERNEL-01 in-kernel self-tests.
 *
 * WHY THIS IS A SEPARATE FILE FROM boot03_tests.c
 *
 * It would have been less code to append these checks to the BOOT-03
 * suite. That was rejected for two reasons, both about evidence rather
 * than tidiness.
 *
 * 1. The external harness keys on the BOOT-03 tally. scripts/
 *    mttcg-matrix.sh greps for the literal string
 *    "===== 105/105 checks passed =====". Adding checks to the BOOT-03
 *    counter would change that number, which means either the harness
 *    starts failing or the harness gets edited - and editing a
 *    regression harness in the same change that adds a feature destroys
 *    the harness's value as an independent witness. Keeping a separate
 *    counter means BOOT-03 still reports exactly 105/105 and every
 *    pre-existing assertion in scripts/ passes untouched. A regression
 *    in this milestone therefore cannot hide behind a moved goalpost.
 *
 * 2. BOOT-03 is finished and its results are frozen. KERNEL-01 checks
 *    that fail should say KERNEL-01, so that a failure is attributed to
 *    the milestone that introduced it.
 *
 * ORDERING. kernel01_run_tests() and its summary are printed BEFORE
 * boot03_print_summary(). This is deliberate and not cosmetic:
 * scripts/smp-test.sh polls for "SYSTEM READY" and terminates QEMU
 * shortly after seeing it, so anything printed after that line is
 * liable to be truncated out of the log. Evidence that can be cut off
 * is not evidence.
 *
 * SCOPE. Checks are grouped one subsystem per phase, and a subsystem is
 * only added once the code it describes exists. A test for absent code
 * would be a claim about code that has not been written.
 */

#ifndef VEXOS_KERNEL01_TESTS_H
#define VEXOS_KERNEL01_TESTS_H

#include <stdint.h>
#include "smp.h"

typedef struct {
    int tss_ist;                 /* Phase 1: per-CPU TSS + IST readiness */
    int irq;                     /* Phase 2: handler table + AP interrupts */
    int ipi;                     /* Phase 3: inter-processor interrupts */
    int tlb;                     /* Phase 4: cross-CPU TLB shootdown */
    int reclaim;                 /* Phase 5: page-table reclamation */
    int kmap;                    /* Phase 6: reclaimable kmap ranges */

    uint32_t checks_run;
    uint32_t checks_failed;
} Kernel01Results;

/* Runs the KERNEL-01 self-tests on the BSP. `smp` may be NULL if
 * SMP startup was never attempted, in which case the result is recorded
 * as a FAILURE rather than skipped: the entire point of per-CPU TSS work
 * is multi-CPU, so it cannot pass by not being exercised. */
void kernel01_run_tests(const SmpInfo *smp, Kernel01Results *out);

/* Prints the KERNEL-01 summary block. Uses its own PASS/FAIL lines and
 * its own tally, distinct from the BOOT-03 block, and deliberately does
 * NOT print SYSTEM READY or any other string the harness keys on - a
 * KERNEL-01 phase must not be able to declare the boot good. */
void kernel01_print_summary(const Kernel01Results *r);

/* 1 if every KERNEL-01 subsystem passed and no individual check failed. */
int kernel01_all_passed(const Kernel01Results *r);

#endif /* VEXOS_KERNEL01_TESTS_H */
