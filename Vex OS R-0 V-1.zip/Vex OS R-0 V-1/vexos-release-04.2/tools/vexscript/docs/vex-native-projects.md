# Native projects
```
app/vex.toml
app/src/main.vex
app/src/math.vex
```
Build: resolve modules → IR → asm → objects → link + `vex_rt.c`.
