/*
 * Vex OS - kernel/include/netstatus.h
 *
 * Truthful network capability reporting.
 *
 * VEX OS has NO network driver, NO network stack and NO interface-management
 * path.  The only thing it can genuinely determine is whether a network
 * controller exists on the PCI bus, by reading PCI configuration space
 * (read-only: no BAR is mapped, no command register is written).
 *
 * Therefore the only states this module can report are:
 *   NET_NO_DRIVER_ADAPTER_PRESENT  - a NIC is on the bus, nothing drives it
 *   NET_NO_DRIVER_NO_ADAPTER       - no NIC found on the bus, no driver
 * "connected", "disconnected" and "Wi-Fi" are NOT representable here, on
 * purpose: nothing in the kernel could ever establish them.
 */
#ifndef VEXOS_NETSTATUS_H
#define VEXOS_NETSTATUS_H
#include <stdint.h>

typedef enum { NET_NO_DRIVER_NO_ADAPTER = 0, NET_NO_DRIVER_ADAPTER_PRESENT = 1 } NetState;

typedef struct {
    NetState state;
    int      adapter_found;
    uint16_t vendor, device;
    uint8_t  bus, slot, func;
    const char *adapter_name;   /* known-ID name, or NULL (print the hex IDs) */
    uint32_t devices_scanned;
} NetStatus;

/* Scans PCI buses 0-255 via config mechanism #1 (ports 0xCF8/0xCFC) for
 * class 0x02 (network controller).  Returns 1 if the bus responded at all. */
int  netstatus_probe(void);
const NetStatus *netstatus_get(void);
const char *netstatus_label(void);   /* short button text */

/* Pure: classify by class code / known-ID table (unit-tested). */
int netstatus_is_network_class(uint8_t class_code);
const char *netstatus_known_name(uint16_t vendor, uint16_t device);
#endif
