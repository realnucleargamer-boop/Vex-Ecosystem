/*
 * Vex OS - kernel/include/ap_stack.h
 *
 * BOOT-02A: proves the PMM can back per-CPU stack allocation, which
 * BOOT-02B's real SMP bring-up will need. Does NOT start any CPUs,
 * does NOT know the real CPU count (that's ACPI/MADT, explicitly
 * out of scope here) - this only allocates and hands back stack
 * regions on request, verified via a small fixed-count self-test in
 * kernel_entry.c.
 */

#ifndef VEXOS_AP_STACK_H
#define VEXOS_AP_STACK_H

#include <stdint.h>

#define AP_STACK_SIZE_PAGES 4  /* 16 KiB, matches the BSP boot stack in start.asm */

/* Allocates one AP stack from the PMM and returns its TOP address
 * (stacks grow down, so callers should set RSP to exactly this
 * value). panic()s if the PMM arena is exhausted. */
uint64_t ap_stack_alloc_top(void);

#endif /* VEXOS_AP_STACK_H */
