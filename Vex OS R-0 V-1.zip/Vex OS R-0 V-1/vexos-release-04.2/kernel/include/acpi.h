/*
 * Vex OS - kernel/include/acpi.h
 *
 * BOOT-02B (scaled down from the original BOOT-02 brief - see
 * docs/BOOT-02B.md for why): ACPI table discovery and MADT parsing
 * only. This enumerates CPUs the MADT reports; it does NOT start any
 * of them. Real secondary-CPU startup (trampoline, INIT-SIPI-SIPI,
 * long-mode handoff) is BOOT-02C, built on top of this.
 *
 * ACPI table layouts below are fixed by the ACPI Specification (a
 * standardized binary ABI, not something Vex OS defines) - this
 * mirrors the spec, it doesn't invent it.
 *
 * ARCHITECTURAL ASSUMPTION (flagged, not silent): reading these
 * tables means dereferencing raw physical addresses BootInfo/ACPI
 * hand us (RSDP, XSDT, MADT). Vex OS has no page tables of its own
 * yet (paging is still a later milestone) - this relies on whatever
 * identity-ish mapping UEFI/OVMF left active in CR3 after
 * ExitBootServices still covering these physical addresses. This is
 * the same assumption LAPIC MMIO access makes (see lapic.h) and
 * should be revisited once Vex OS owns its own page tables.
 */

#ifndef VEXOS_ACPI_H
#define VEXOS_ACPI_H

#include <stdint.h>

#define ACPI_MAX_CPUS 32

typedef struct __attribute__((packed)) {
    char     Signature[8];      /* "RSD PTR " (note trailing space) */
    uint8_t  Checksum;
    char     OEMID[6];
    uint8_t  Revision;          /* 0 = ACPI 1.0, 2 = ACPI 2.0+ */
    uint32_t RsdtAddress;
    uint32_t Length;
    uint64_t XsdtAddress;
    uint8_t  ExtendedChecksum;
    uint8_t  Reserved[3];
} AcpiRsdp;

typedef struct __attribute__((packed)) {
    char     Signature[4];
    uint32_t Length;
    uint8_t  Revision;
    uint8_t  Checksum;
    char     OEMID[6];
    char     OEMTableID[8];
    uint32_t OEMRevision;
    uint32_t CreatorID;
    uint32_t CreatorRevision;
} AcpiSdtHeader;

typedef struct __attribute__((packed)) {
    uint8_t Type;
    uint8_t Length;
} AcpiMadtEntryHeader;

/* MADT entry Type 0: Processor Local APIC */
typedef struct __attribute__((packed)) {
    AcpiMadtEntryHeader header;
    uint8_t  ProcessorId;
    uint8_t  ApicId;
    uint32_t Flags; /* bit0 = Enabled, bit1 = Online Capable */
} AcpiMadtLocalApic;

#define ACPI_MADT_TYPE_LOCAL_APIC 0
#define ACPI_MADT_LAPIC_FLAG_ENABLED (1u << 0)

typedef struct {
    uint8_t  processor_id;
    uint8_t  apic_id;
    int      enabled;
} AcpiCpuEntry;

typedef struct {
    uint32_t local_apic_address; /* from the MADT header - the "default" LAPIC MMIO base */
    uint32_t cpu_count;
    AcpiCpuEntry cpus[ACPI_MAX_CPUS];
} AcpiInfo;

/* Parses RSDP -> XSDT (preferred) / RSDT (fallback) -> MADT,
 * validating signatures and checksums at each step, and fills `out`.
 * Returns 1 on success, 0 on failure (does NOT panic - ACPI
 * discovery failing is reported and handled by the caller, per the
 * "make failures visible, don't crash" requirement). */
int acpi_init(uint64_t rsdp_physical_address, AcpiInfo *out);

#endif /* VEXOS_ACPI_H */
