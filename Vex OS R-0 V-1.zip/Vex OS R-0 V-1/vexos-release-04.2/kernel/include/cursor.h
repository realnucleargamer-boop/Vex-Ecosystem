/*
 * Vex OS - kernel/include/cursor.h
 *
 * Software mouse-pointer overlay.
 *
 * METHOD: save-under.  cursor_show() copies the framebuffer pixels under the
 * sprite into a static buffer and draws the sprite; cursor_hide() writes the
 * saved pixels back.  There is no back buffer, no heap, and no full-screen
 * copy: the cost of a move is ~2 x (12x18) pixel accesses.
 *
 * CONTRACT FOR CALLERS: anything that draws to the screen while the cursor is
 * visible must call cursor_hide() first and cursor_show() afterwards, or the
 * saved-under pixels go stale.  vexui.c does this once per redraw batch.
 *
 * SAFETY: every pixel access goes through gfx_get()/gfx_put(), which clip to
 * the validated framebuffer (SECURITY-02), so a cursor at any screen edge -
 * or at coordinates that are somehow out of range - cannot touch memory
 * outside the framebuffer.  Position is clamped on every update.
 */
#ifndef VEXOS_CURSOR_H
#define VEXOS_CURSOR_H
#include <stdint.h>
#include "gfx/fb.h"

#define CURSOR_W 12
#define CURSOR_H 18

void cursor_init(const GfxFb *fb);          /* bind (fb may be NULL/!ok: all calls become no-ops) */
void cursor_move_to(int32_t x, int32_t y);  /* clamps to the screen; does NOT draw */
int32_t cursor_x(void);
int32_t cursor_y(void);
void cursor_hide(void);                     /* restore pixels under the sprite */
void cursor_show(void);                     /* save-under + draw at the current position */
int  cursor_visible(void);

/* Pure helper (unit-tested). */
int32_t cursor_clamp(int32_t v, int32_t lo, int32_t hi);
/* Sprite sanity: every row has exactly CURSOR_W characters (unit-tested). */
int  cursor_sprite_wellformed(void);
#endif
