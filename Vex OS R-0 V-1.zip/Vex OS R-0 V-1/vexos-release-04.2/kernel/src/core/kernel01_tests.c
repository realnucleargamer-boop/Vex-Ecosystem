/*
 * Vex OS - kernel/src/core/kernel01_tests.c
 *
 * KERNEL-01 Phase 1 in-kernel self-tests: per-CPU TSS and IST.
 * See kernel/include/kernel01_tests.h for why this is a separate suite
 * with its own counter.
 *
 * DESIGN RULE inherited from BOOT-03: a check that cannot fail is not a
 * check. Each predicate below is one that a plausible implementation
 * mistake would actually break, and the mistakes are named in the
 * comments so a reader can judge that claim instead of taking it.
 */

#include "kernel01_tests.h"
#include "gdt.h"
#include "acpi.h"
#include "serial.h"
#include "boot_layout.h"
#include "irq.h"
#include "idt.h"
#include "timer.h"
#include "lapic.h"
#include "ipi.h"
#include "tlb.h"
#include "percpu.h"
#include "vmm.h"
#include "pmm.h"

/* RFLAGS.IF - bit 9. Defined here rather than pulled from a header
 * because no existing header declares it and adding a new one for a
 * single bit used by one test would be more surface than the fact
 * deserves. Intel SDM Vol.1 3.4.3 "EFLAGS Register". */
#define RFLAGS_IF (1ULL << 9)

/* Spurious Interrupt Vector Register: offset and software-enable bit.
 * The register numbers themselves are private to lapic.c; these two are
 * repeated here because the test reads the BSP's SVR back through the
 * generic lapic_reg_read() accessor to confirm the bit is set in
 * hardware. If they ever disagreed with lapic.c, the SVR checks below
 * would fail loudly rather than silently pass - which is the right
 * failure direction for a duplicated constant. */
#define LAPIC_SVR_OFFSET 0x0F0
#define LAPIC_SVR_ENABLE (1u << 8)

/* Minimal string equality. Used to check that a registered interrupt
 * handler's NAME is what the registering subsystem passed, not merely
 * that some name exists - a name is the only human-readable link between
 * a live vector and the code that owns it, and this kernel has no libc.
 * Both arguments are always non-null here: irq_name_for() never returns
 * null by contract. */
static int str_eq(const char *a, const char *b)
{
    if (a == 0 || b == 0) return 0;
    while (*a != '\0' && *a == *b) { a++; b++; }
    return *a == *b;
}

/* Provided by kernel/linker.ld. Used to confirm the IST stacks really
 * live inside the kernel's own linked extent - i.e. inside the region
 * the bootloader reserved and the PMM refuses to hand out - rather than
 * in memory something else may allocate. */
extern uint8_t __kernel_start[];
extern uint8_t __kernel_end[];

/* ------------------------------------------------------------------ *
 * Reporting. Separate counters from boot03_tests.c on purpose: the
 * BOOT-03 tally must remain exactly what it was before this milestone.
 * ------------------------------------------------------------------ */

static uint32_t g_checks;
static uint32_t g_failed;

static int check(const char *sub, const char *what, int ok)
{
    g_checks++;
    if (!ok) g_failed++;

    serial_puts("[test] ");
    serial_puts(sub);
    serial_puts(ok ? ": ok   - " : ": FAIL - ");
    serial_puts(what);
    serial_puts("\n");
    return ok;
}

static int check_v(const char *sub, const char *what, int ok, uint64_t value)
{
    g_checks++;
    if (!ok) g_failed++;

    serial_puts("[test] ");
    serial_puts(sub);
    serial_puts(ok ? ": ok   - " : ": FAIL - ");
    serial_puts(what);
    serial_puts(" [");
    serial_put_hex64(value);
    serial_puts("]\n");
    return ok;
}

/* ------------------------------------------------------------------ *
 * TSS / IST
 *
 * The claim under test is narrow and worth stating exactly:
 *
 *   Every CPU that is online is holding a task register that designates
 *   ITS OWN TSS, and that TSS names a double-fault stack that no other
 *   CPU's TSS names.
 *
 * Three separate things have to line up for that, and each is checked
 * against a different source of truth rather than inferred from the
 * others:
 *
 *   (a) the descriptor - read back out of the GDT's own bytes, so a
 *       base-field shifting bug in tss_set_entry() is visible;
 *   (b) the task register - read with `str` BY THE CPU IN QUESTION,
 *       because TR is per-logical-processor and cannot be inspected
 *       from another CPU at all;
 *   (c) the TSS contents - IST1, checked for non-zero, alignment,
 *       containment in the kernel image, and pairwise distinctness.
 *
 * Aggregate-then-report is used deliberately: each predicate is
 * evaluated across all online CPUs and reported as ONE check naming the
 * first offending CPU. That keeps the KERNEL-01 check total almost
 * independent of -smp, so a changed total in the log means a changed
 * test suite rather than merely a changed CPU count. Per-CPU values are
 * still printed, as diagnostics, so a failure is debuggable without a
 * rebuild.
 *
 * "Almost": there is exactly one conditional check, the idle-descriptor
 * busy-bit control, which has nothing to inspect when all 32 CPU indices
 * are in use. It is skipped with a printed note in that case rather than
 * being made unfailable, so the total is 21 for runs below 32 CPUs and
 * 20 at exactly 32. Stated here because an unexplained total that moves
 * is indistinguishable from a test that vanished.
 * ------------------------------------------------------------------ */

static int test_tss_ist(const SmpInfo *smp)
{
    const char *S = "K01-TSS";
    int ok = 1;

    if (smp == 0 || !smp->started) {
        /* Not "skipped". Per-CPU TSS state is a multi-CPU property; a
         * run that never brought CPUs up has not demonstrated it. */
        ok &= check(S, "SMP startup was attempted (per-CPU TSS is"
                       " untestable without it)", 0);
        return ok;
    }

    /* ---- The BSP, checked live and directly ---- */

    /* The BSP is the one CPU whose task register this code can read at
     * the moment of asking, because this code is running on it. */
    uint16_t bsp_tr = gdt_read_tr();

    ok &= check_v(S, "BSP task register is loaded (non-zero)",
                  bsp_tr != 0, bsp_tr);

    /* BOOT-02A froze the BSP's TSS selector at 0x28. If per-CPU
     * numbering had shifted it, this milestone would have changed the
     * BSP's observable behaviour, which it is not allowed to do. */
    ok &= check_v(S, "BSP task register is still the frozen 0x28",
                  bsp_tr == GDT_SEL_TSS, bsp_tr);

    ok &= check_v(S, "CPU 0 selector formula agrees with GDT_SEL_TSS",
                  GDT_SEL_TSS_FOR(0) == GDT_SEL_TSS,
                  (uint64_t)GDT_SEL_TSS_FOR(0));

    /* The kernel assigns the BSP CPU index 0 for both percpu and TSS
     * purposes (kernel_entry passes a literal 0). If the MADT had listed
     * the BSP anywhere else, the AP at index 0 would try to `ltr` the
     * TSS the BSP is holding busy. smp_start_aps refuses to start APs in
     * that case; this check confirms the configuration we are actually
     * running is the one where index 0 really is the BSP, so that every
     * per-CPU predicate below is comparing the right pairs. */
    {
        int slot0_is_bsp = (smp->cpu_count > 0) &&
                           (smp->cpus[0].state == CPU_STATE_BSP);
        ok &= check_v(S, "CPU index 0 is the BSP (TSS 0x28 is the BSP's)",
                      slot0_is_bsp,
                      (uint64_t)(smp->cpu_count > 0
                                     ? smp->cpus[0].expected_apic_id : 0));
    }

    /* ---- Per-CPU sweep over everything that is online ---- */

    uint32_t online_seen = 0;

    /* "first offending CPU" trackers. UINT32_MAX-ish sentinel avoided in
     * favour of a separate flag, so a legitimate CPU index 0 failure is
     * not confused with "nothing failed". */
    int      bad_state = 0;   uint32_t bad_state_cpu = 0;
    int      bad_tr = 0;      uint32_t bad_tr_cpu = 0;
    int      bad_sel = 0;     uint32_t bad_sel_cpu = 0;
    int      bad_desc = 0;    uint32_t bad_desc_cpu = 0;
    int      bad_acc = 0;     uint32_t bad_acc_cpu = 0;
    int      bad_idle = 0;    uint32_t bad_idle_cpu = 0;
    int      idle_seen = 0;
    int      bad_ist0 = 0;    uint32_t bad_ist0_cpu = 0;
    int      bad_align = 0;   uint32_t bad_align_cpu = 0;
    int      bad_range = 0;   uint32_t bad_range_cpu = 0;
    int      bad_agree = 0;   uint32_t bad_agree_cpu = 0;
    int      bad_okflag = 0;  uint32_t bad_okflag_cpu = 0;
    int      bad_dup = 0;     uint32_t bad_dup_cpu = 0;

    uint64_t kstart = (uint64_t)(uintptr_t)__kernel_start;
    uint64_t kend   = (uint64_t)(uintptr_t)__kernel_end;

    for (uint32_t i = 0; i < ACPI_MAX_CPUS && i < smp->cpu_count; i++) {
        const CpuInfo *c = &smp->cpus[i];

        /* Both states count as online: smp.c records the BSP as
         * CPU_STATE_BSP (smp_state_name renders it "ONLINE (BSP)") and
         * successfully started APs as CPU_STATE_ONLINE. Checking only
         * CPU_STATE_ONLINE would silently exclude the BSP - the one CPU
         * whose TSS behaviour was already working before this phase, and
         * therefore the one whose regression matters most. */
        int is_bsp = (c->state == CPU_STATE_BSP);
        if (!is_bsp && c->state != CPU_STATE_ONLINE) continue;
        online_seen++;

        uint16_t want_sel = GDT_SEL_TSS_FOR(i);
        uint64_t ist1     = gdt_ist1_for(i);
        uint64_t dbase    = gdt_tss_descriptor_base(i);
        uint8_t  dacc     = gdt_tss_descriptor_access(i);
        const Tss *t      = gdt_tss_for(i);

        /* The TR value for CPU i. For the BSP this is the live `str`
         * result read above; for an AP it is the value the AP itself
         * wrote into shared state after its own `str`. Using the AP's
         * own reading, rather than assuming the AP did what the code
         * says, is the whole reason CpuInfo.reported_tr exists. */
        uint32_t got_tr = is_bsp ? (uint32_t)bsp_tr : c->reported_tr;

        /* --- diagnostics, one line per online CPU --- */
        serial_puts("[test] K01-TSS: cpu ");
        serial_put_dec64(i);
        serial_puts(is_bsp ? " (BSP) sel " : " (AP)  sel ");
        serial_put_hex64((uint64_t)want_sel);
        serial_puts(" tr ");
        serial_put_hex64((uint64_t)got_tr);
        serial_puts(" tss ");
        serial_put_hex64((uint64_t)(uintptr_t)t);
        serial_puts(" desc_base ");
        serial_put_hex64(dbase);
        serial_puts(" ist1 ");
        serial_put_hex64(ist1);
        serial_puts("\n");

        /* --- predicates --- */

        /* A TR of zero means this CPU never executed `ltr`, which is
         * exactly the BOOT-02C state this phase exists to remove. */
        if (got_tr == 0 && !bad_tr) { bad_tr = 1; bad_tr_cpu = i; }

        /* Loading SOME TSS is not enough - loading another CPU's would
         * reintroduce the shared-IST bug while looking healthy. */
        if (got_tr != (uint32_t)want_sel && !bad_sel) {
            bad_sel = 1; bad_sel_cpu = i;
        }

        /* Descriptor must encode the address of THIS CPU's TSS. Catches
         * an off-by-one in the slot arithmetic and any base-field shift
         * mistake, neither of which would fault. */
        if (t == 0 || dbase != (uint64_t)(uintptr_t)t) {
            if (!bad_desc) { bad_desc = 1; bad_desc_cpu = i; }
        }

        /* Descriptor type byte, for a CPU that HAS loaded its TSS.
         *
         * This check originally expected 0x89 - present, DPL0, type 0x9,
         * "available 64-bit TSS" - which is what tss_set_entry() writes.
         * It failed on the first run, on every CPU, reading 0x8B.
         *
         * The kernel was right and the test was wrong. `ltr` does not
         * merely load the task register: it writes back to the
         * descriptor, changing the type from 0x9 (available) to 0xB
         * (busy), and the busy bit is precisely the mechanism that makes
         * loading an already-loaded TSS on a second CPU fault. So 0x8B
         * is the CORRECT post-`ltr` value, and expecting 0x89 was
         * expecting the descriptor to look untouched.
         *
         * Keeping the check but fixing the expectation makes it stronger
         * than it was: the busy bit is set by the CPU, not by this
         * kernel, so observing 0x8B is independent hardware confirmation
         * that `ltr` really executed against this exact descriptor. It
         * is not something the code could fake by writing a value and
         * reading it back. */
        if (dacc != 0x8B && !bad_acc) { bad_acc = 1; bad_acc_cpu = i; }

        /* IST1 == 0 means the #DF gate has no stack to switch to, i.e.
         * a double fault becomes a triple fault. */
        if (ist1 == 0 && !bad_ist0) { bad_ist0 = 1; bad_ist0_cpu = i; }

        /* The SysV ABI and the CPU's own push sequence both want a
         * 16-byte-aligned stack top. */
        if ((ist1 & 0xF) != 0 && !bad_align) {
            bad_align = 1; bad_align_cpu = i;
        }

        /* The stack must sit inside the kernel's linked extent. If it did
         * not, it would be in memory the PMM is entitled to hand out,
         * and the double-fault stack would be silently reallocated
         * underneath the CPU. */
        if ((ist1 <= kstart || ist1 > kend) && !bad_range) {
            bad_range = 1; bad_range_cpu = i;
        }

        /* The AP's own reading of IST1 must match what the BSP has in the
         * array. A mismatch would mean the CPU is looking at a different
         * TSS than the one the BSP thinks it configured. The BSP reads
         * the array directly, so it is exempt. */
        if (!is_bsp) {
            if (c->reported_ist1 != ist1 && !bad_agree) {
                bad_agree = 1; bad_agree_cpu = i;
            }
            /* The AP's own verdict from gdt_load_on_this_cpu(), which
             * includes its own `str` readback at the point of load. */
            if (!c->tss_ok && !bad_okflag) {
                bad_okflag = 1; bad_okflag_cpu = i;
            }
        }

        /* Pairwise distinctness against every other online CPU. O(n^2)
         * over at most 32 entries is 496 comparisons - free, and much
         * harder to get wrong than a cleverer scheme. Overlap, not just
         * equality, is what matters: two stacks whose ranges intersect
         * corrupt each other even with different top addresses. */
        for (uint32_t j = 0; j < ACPI_MAX_CPUS && j < smp->cpu_count; j++) {
            if (j == i) continue;
            if (smp->cpus[j].state != CPU_STATE_ONLINE &&
                smp->cpus[j].state != CPU_STATE_BSP) continue;

            uint64_t other = gdt_ist1_for(j);
            if (other == 0 || ist1 == 0) continue;

            uint64_t a_lo = ist1  - GDT_DF_STACK_SIZE, a_hi = ist1;
            uint64_t b_lo = other - GDT_DF_STACK_SIZE, b_hi = other;

            if (a_lo < b_hi && b_lo < a_hi) {
                if (!bad_dup) { bad_dup = 1; bad_dup_cpu = i; }
            }
        }

        /* An AP marked ONLINE must have reported in coherently; this is
         * BOOT-03's invariant, re-checked here only because every
         * predicate above trusts it. The BSP never writes
         * reached_c_code - it is the AP handshake flag - so it is
         * excluded rather than expected to fail. */
        if (!is_bsp && c->reached_c_code == 0 && !bad_state) {
            bad_state = 1; bad_state_cpu = i;
        }
    }

    /* The negative half of the busy-bit observation. Descriptors for CPU
     * indices that never came online must STILL read 0x89 (available),
     * because nothing ever executed `ltr` against them.
     *
     * Without this, "every online CPU's descriptor reads 0x8B" would be
     * equally consistent with tss_set_entry() having simply written 0x8B
     * for everyone. With it, the two observations together show the busy
     * bit tracks actual loading: set exactly where a CPU loaded it, clear
     * everywhere else. Skipped, rather than failed, when all 32 indices
     * are in use - a -smp 32 run legitimately has no idle descriptor. */
    for (uint32_t i = 0; i < GDT_MAX_CPUS; i++) {
        int in_use = (i < ACPI_MAX_CPUS && i < smp->cpu_count) &&
                     (smp->cpus[i].state == CPU_STATE_ONLINE ||
                      smp->cpus[i].state == CPU_STATE_BSP);
        if (in_use) continue;

        idle_seen = 1;
        if (gdt_tss_descriptor_access(i) != 0x89 && !bad_idle) {
            bad_idle = 1; bad_idle_cpu = i;
        }
    }

    ok &= check_v(S, "at least one CPU is online", online_seen > 0,
                  online_seen);
    ok &= check_v(S, "online CPU count matches SmpInfo.online_count",
                  online_seen == smp->online_count, smp->online_count);

    ok &= check_v(S, "every online CPU reported reaching C code",
                  !bad_state, bad_state_cpu);
    ok &= check_v(S, "every online CPU has a non-zero task register",
                  !bad_tr, bad_tr_cpu);
    ok &= check_v(S, "every online CPU's TR is its OWN TSS selector",
                  !bad_sel, bad_sel_cpu);
    ok &= check_v(S, "every TSS descriptor encodes its own TSS address",
                  !bad_desc, bad_desc_cpu);
    /* 0x8B = present, DPL0, BUSY 64-bit TSS. The busy bit is written by
     * the CPU during `ltr`, so this is hardware-sourced confirmation that
     * the load happened against this descriptor. */
    ok &= check_v(S, "every online CPU's TSS descriptor is marked busy by"
                     " the CPU (0x8B)", !bad_acc, bad_acc_cpu);

    if (idle_seen) {
        ok &= check_v(S, "descriptors for CPUs that never came online are"
                         " still available, not busy (0x89)",
                      !bad_idle, bad_idle_cpu);
    } else {
        serial_puts("[test] K01-TSS: note - every TSS descriptor is in use"
                    " on this run, so there is no idle descriptor to"
                    " compare the busy bit against\n");
    }
    ok &= check_v(S, "every online CPU has a non-zero IST1",
                  !bad_ist0, bad_ist0_cpu);
    ok &= check_v(S, "every IST1 is 16-byte aligned",
                  !bad_align, bad_align_cpu);
    ok &= check_v(S, "every IST1 lies inside the kernel's linked extent",
                  !bad_range, bad_range_cpu);
    ok &= check_v(S, "every AP's own IST1 reading matches the BSP's",
                  !bad_agree, bad_agree_cpu);
    ok &= check_v(S, "every AP reported a successful TSS load",
                  !bad_okflag, bad_okflag_cpu);
    ok &= check_v(S, "no two online CPUs share or overlap a #DF stack",
                  !bad_dup, bad_dup_cpu);

    /* ---- .bss footprint, the cost side of this change ---- *
     *
     * The per-CPU stacks made the double-fault allocation 32x larger.
     * VEX_KERNEL_RESERVE_BYTES is what the bootloader reserves, and
     * boot_layout.h's own comment warns that overflowing it means .bss
     * lands in memory the EFI map still calls conventional. pmm.c
     * already panics if __kernel_end exceeds the reserve, so this check
     * is not the safety net - it is the check that says how much room is
     * left, in the log, on every boot, so the next person to add a
     * per-CPU array can see the headroom before they spend it. */
    uint64_t footprint = gdt_percpu_footprint_bytes();
    uint64_t used = kend - VEX_KERNEL_LOAD_PHYS;

    serial_puts("[test] K01-TSS: per-CPU TSS+IST .bss footprint ");
    serial_put_dec64(footprint);
    serial_puts(" bytes; kernel extent ");
    serial_put_dec64(used);
    serial_puts(" of ");
    serial_put_dec64(VEX_KERNEL_RESERVE_BYTES);
    serial_puts(" reserved bytes\n");

    ok &= check_v(S, "per-CPU TSS+IST footprint is the expected size",
                  footprint == (uint64_t)GDT_MAX_CPUS *
                               (uint64_t)GDT_DF_STACK_SIZE +
                               (uint64_t)GDT_MAX_CPUS * sizeof(Tss),
                  footprint);
    ok &= check_v(S, "kernel still fits inside VEX_KERNEL_RESERVE_BYTES",
                  used <= VEX_KERNEL_RESERVE_BYTES, used);

    /* Headroom, reported as a check rather than a comment so that
     * quietly eating the last of the reserve is loud. 256 KiB is an
     * arbitrary-but-stated floor: enough for another 32-CPU 4 KiB
     * per-CPU array plus slack. */
    ok &= check_v(S, "at least 256 KiB of reserve headroom remains",
                  (VEX_KERNEL_RESERVE_BYTES - used) >= (256u * 1024u),
                  VEX_KERNEL_RESERVE_BYTES - used);

    /* ---- Explicit non-claims ---- *
     *
     * Stated in the log, not just in a report, because the log is what
     * outlives the conversation. */
    serial_puts("[test] K01-TSS: NOT PROVEN HERE - #DF recovery on an AP"
                " (no fault is triggered), TSS behaviour under KVM or on"
                " real hardware, and IST stack overflow safety (these"
                " stacks have no guard page)\n");
    return ok;
}

/* ================================================================== *
 * PHASE 2 - interrupt-handler table, and APs running interruptible.
 *
 * The two halves of this test answer two different questions.
 *
 * The table half is straightforward mechanism testing: registration
 * succeeds where it should, is refused where it must be, is idempotent
 * for a repeat of the same handler, and is reversible. Those can be
 * checked directly by calling the API.
 *
 * The second half is the one that matters, and it is checked
 * indirectly, because it has to be. "Is this AP actually
 * interruptible?" cannot be answered from the BSP: IF lives in the
 * AP's own RFLAGS and the software-enable bit lives in the AP's own
 * SVR, and both are per-logical-processor. So the AP reads them itself
 * and publishes them before the alive handshake, and the BSP checks
 * what the AP reported. That is why the ordering requirement in smp.h
 * is load-bearing rather than stylistic - if the publish moved after
 * the handshake, these checks could read zeros from a healthy CPU.
 *
 * The single most informative check in this block is that the timer's
 * dispatch count is non-zero: it is the only assertion that proves
 * interrupts are flowing through the NEW table rather than through the
 * old hardcoded `if`, since that counter is incremented by the
 * dispatcher and by nothing else.
 * ================================================================== */

/* Scratch handlers used only for registration mechanics. Neither is ever
 * delivered: no code sends K01_SCRATCH_VECTOR, and the registration is
 * removed again before this function returns. They must be distinct
 * functions so the "different handler is refused" case is real - two
 * trivial bodies could otherwise be merged by the linker's
 * identical-code folding, which would make IRQ_ERR_TAKEN untestable. The
 * volatile counters prevent that folding and double as evidence that
 * neither was ever actually invoked. */
static volatile uint32_t g_scratch_a_calls;
static volatile uint32_t g_scratch_b_calls;

static void scratch_handler_a(InterruptFrame *frame)
{
    (void)frame;
    g_scratch_a_calls++;
}

static void scratch_handler_b(InterruptFrame *frame)
{
    (void)frame;
    g_scratch_b_calls++;
}

/* 0xFE: the highest vector that is not the LAPIC spurious vector, chosen
 * so it cannot collide with the timer (0x20) or with the IPI vectors
 * Phases 3 and 4 will allocate from the low end of the range. */
#define K01_SCRATCH_VECTOR 0xFE

static int test_irq(const SmpInfo *smp)
{
    const char *S = "K01-IRQ";
    int ok = 1;

    /* ---- the timer now arrives through the table ---- */

    ok &= check_v(S, "timer vector has a registered handler",
                  irq_handler_for(TIMER_VECTOR) != 0, TIMER_VECTOR);

    ok &= check(S, "timer vector's registered name is the timer's",
                str_eq(irq_name_for(TIMER_VECTOR), "lapic-timer"));

    /* THE load-bearing check of this phase. This counter is incremented
     * by idt_common_handler's table-dispatch path and by nothing else -
     * not by timer_on_interrupt, and not by the tests. A non-zero value
     * therefore cannot be produced by anything except a real interrupt
     * being routed through the new handler table. If Phase 2 had wired
     * the table up but left the old hardcoded branch in front of it, this
     * would read zero while every other check still passed. */
    uint64_t timer_dispatches = irq_dispatch_count(TIMER_VECTOR);
    ok &= check_v(S, "timer interrupts are dispatched THROUGH the handler"
                  " table (dispatch count > 0)",
                  timer_dispatches > 0, timer_dispatches);

    /* The tick counter is incremented by the handler the table
     * dispatched to. It can legitimately exceed the dispatch count,
     * because BOOT-03's timer tests call timer_on_interrupt() directly;
     * it must never be LESS, because that would mean the dispatcher
     * counted deliveries whose handler did not run. */
    uint64_t ticks = timer_ticks();
    ok &= check_v(S, "tick count is at least the dispatch count (handler"
                  " really ran for each dispatch)",
                  ticks >= timer_dispatches, ticks);

    /* Interrupts are still being delivered NOW, with every AP
     * interrupt-enabled. Phase 2's change to the AP idle loop is the kind
     * of change that can wedge a system some time after boot, so this
     * re-checks liveness at test time rather than trusting a count that
     * accumulated earlier. timer_wait_ticks has its own PIT-based
     * timeout, so a dead timer fails here instead of hanging. */
    ok &= check(S, "timer is still delivering interrupts at test time"
                " (with all APs interrupt-enabled)",
                timer_wait_ticks(2) != 0);

    uint64_t dispatches_after = irq_dispatch_count(TIMER_VECTOR);
    ok &= check_v(S, "dispatch count advanced during that wait",
                  dispatches_after > timer_dispatches, dispatches_after);

    /* ---- nothing is firing that nobody claims ---- */

    /* Zero, not "small". An interrupt arriving on an unregistered vector
     * means something is enabled that this kernel does not know about,
     * and the shootdown phases cannot be trusted on a machine where
     * unexplained interrupts arrive. */
    uint64_t unhandled = irq_unhandled_count();
    ok &= check_v(S, "no interrupt arrived on an unregistered vector",
                  unhandled == 0, unhandled);

    /* Spurious interrupts are reported, NOT asserted about. A spurious
     * LAPIC interrupt is a legitimate hardware event that software does
     * not control; requiring zero here would be asserting something about
     * QEMU's timing rather than about this kernel. It is printed because
     * a large count would be worth investigating even though it is not a
     * failure. */
    serial_puts("[test] K01-IRQ: informational - LAPIC spurious vector"
                " deliveries so far: ");
    serial_put_dec64(irq_spurious_count());
    serial_puts("\n");

    /* ---- registration is refused where it must be ---- */

    /* The exception range. If a caller could capture vector 14, the #PF
     * path in idt.c - including BOOT-03's page-fault recovery hook -
     * would be silently bypassed. Vector 0 and vector 31 cover the ends
     * of the range so an off-by-one in the bound is caught. */
    ok &= check(S, "registering vector 0 (#DE) is refused",
                irq_register(0, scratch_handler_a, "bad")
                    == IRQ_ERR_BAD_VECTOR);
    ok &= check(S, "registering vector 14 (#PF) is refused",
                irq_register(14, scratch_handler_a, "bad")
                    == IRQ_ERR_BAD_VECTOR);
    ok &= check(S, "registering vector 31 (last exception vector) is"
                " refused",
                irq_register(31, scratch_handler_a, "bad")
                    == IRQ_ERR_BAD_VECTOR);

    /* The other side of the boundary: the first vector ABOVE the
     * exception range must be registerable, which is what makes the three
     * checks above a boundary test rather than a blanket refusal.
     *
     * That vector is 32 - and 32 is 0x20, which is TIMER_VECTOR. So the
     * proof that IRQ_FIRST_VECTOR is registerable is the timer's own
     * live registration, already checked at the top of this function;
     * there is no free vector at the boundary to demonstrate it with.
     *
     * An earlier version of this test registered a scratch handler on
     * vector 32 and then unregistered it. The implementation correctly
     * returned IRQ_ERR_TAKEN - but the unregister then SUCCEEDED and tore
     * down the live timer registration, cascading into six unrelated
     * failures. The lesson is recorded here because it is a real hazard
     * of a test that mutates a global table: a scratch vector must be one
     * nothing owns, and the boundary must be asserted rather than
     * exercised. */
    ok &= check_v(S, "the exception/interrupt boundary is where the timer"
                  " vector sits (IRQ_FIRST_VECTOR == TIMER_VECTOR), so the"
                  " boundary is registerable by the timer's own live"
                  " registration",
                  IRQ_FIRST_VECTOR == TIMER_VECTOR
                      && irq_handler_for(IRQ_FIRST_VECTOR) != 0,
                  IRQ_FIRST_VECTOR);

    /* The spurious vector. Refused because its correct handling is to
     * issue no EOI, and a registered handler would be expected to EOI. */
    ok &= check_v(S, "registering the LAPIC spurious vector is refused",
                  irq_register(lapic_spurious_vector(), scratch_handler_a,
                               "bad") == IRQ_ERR_BAD_VECTOR,
                  lapic_spurious_vector());

    ok &= check(S, "registering a null handler is refused",
                irq_register(K01_SCRATCH_VECTOR, 0, "bad")
                    == IRQ_ERR_NULL_HANDLER);

    /* ---- collision handling on an already-occupied vector ---- */

    IrqHandler timer_handler_before = irq_handler_for(TIMER_VECTOR);

    ok &= check(S, "re-registering the SAME handler on an occupied vector"
                " succeeds (idempotent)",
                irq_register(TIMER_VECTOR, timer_handler_before,
                             "lapic-timer") == IRQ_OK);

    ok &= check(S, "registering a DIFFERENT handler on an occupied vector"
                " is refused",
                irq_register(TIMER_VECTOR, scratch_handler_a, "intruder")
                    == IRQ_ERR_TAKEN);

    /* The refusal must not have damaged the existing registration. A
     * rejection that still overwrote the slot would leave the timer
     * pointing at the intruder while reporting an error. */
    ok &= check(S, "the refused registration left the timer's handler"
                " intact",
                irq_handler_for(TIMER_VECTOR) == timer_handler_before);
    ok &= check(S, "the refused registration left the timer's name intact",
                str_eq(irq_name_for(TIMER_VECTOR), "lapic-timer"));

    /* ---- the full register / query / unregister cycle ---- */

    uint32_t count_before = irq_registered_count();

    ok &= check(S, "a fresh vector reads back as unregistered",
                irq_handler_for(K01_SCRATCH_VECTOR) == 0);
    ok &= check(S, "an unregistered vector's name is \"(unregistered)\"",
                str_eq(irq_name_for(K01_SCRATCH_VECTOR), "(unregistered)"));

    ok &= check_v(S, "registering a fresh vector succeeds",
                  irq_register(K01_SCRATCH_VECTOR, scratch_handler_a,
                               "k01-scratch") == IRQ_OK,
                  K01_SCRATCH_VECTOR);
    ok &= check(S, "the registered handler reads back as the one supplied",
                irq_handler_for(K01_SCRATCH_VECTOR) == scratch_handler_a);
    ok &= check(S, "the registered name reads back as the one supplied",
                str_eq(irq_name_for(K01_SCRATCH_VECTOR), "k01-scratch"));
    ok &= check_v(S, "the registered-vector count rose by exactly one",
                  irq_registered_count() == count_before + 1,
                  irq_registered_count());

    /* A different handler is refused here too - confirming the collision
     * rule is a property of the table and not something special about the
     * timer's slot. */
    ok &= check(S, "a different handler is refused on the scratch vector"
                " as well",
                irq_register(K01_SCRATCH_VECTOR, scratch_handler_b,
                             "intruder") == IRQ_ERR_TAKEN);

    ok &= check(S, "unregistering the scratch vector succeeds",
                irq_unregister(K01_SCRATCH_VECTOR) == IRQ_OK);
    ok &= check(S, "it reads back as unregistered afterwards",
                irq_handler_for(K01_SCRATCH_VECTOR) == 0);
    ok &= check_v(S, "the registered-vector count returned to its original"
                  " value",
                  irq_registered_count() == count_before,
                  irq_registered_count());

    /* Double-unregister and out-of-range unregister. Both must report an
     * error rather than corrupt a slot - the same discipline Phase 6 will
     * need for double-free of a virtual range. */
    ok &= check(S, "unregistering it a second time is rejected",
                irq_unregister(K01_SCRATCH_VECTOR)
                    == IRQ_ERR_NOT_REGISTERED);
    ok &= check(S, "unregistering an exception vector is refused",
                irq_unregister(14) == IRQ_ERR_BAD_VECTOR);

    /* Neither scratch handler was ever delivered. If one had been, the
     * registration/unregistration above would have been interfering with
     * a live vector rather than testing mechanism in isolation. */
    ok &= check_v(S, "no scratch handler was ever actually invoked",
                  g_scratch_a_calls == 0 && g_scratch_b_calls == 0,
                  (uint64_t)g_scratch_a_calls + g_scratch_b_calls);

    /* The timer survived all of the above untouched. */
    ok &= check(S, "the timer's registration is unchanged after all"
                " registration tests",
                irq_handler_for(TIMER_VECTOR) == timer_handler_before);

    /* Re-check the unhandled counter now that the registration mechanics
     * have finished mutating the table.
     *
     * This is here specifically because of the vector-32 mistake
     * described above: when that test tore down the live timer
     * registration, timer interrupts began landing on the dispatcher's
     * unregistered path. The system survived - the EOI-on-unregistered
     * decision in idt.c is what kept the CPU from going deaf - but the
     * only direct signal was this counter, and it was checked too early
     * to see it. Checking again at the end turns "a test damaged the
     * table" from something inferred from six confusing failures into one
     * explicit assertion. */
    uint64_t unhandled_after = irq_unhandled_count();
    ok &= check_v(S, "still no interrupt on an unregistered vector after"
                  " the registration tests (the tests did not damage a"
                  " live vector)",
                  unhandled_after == 0, unhandled_after);

    /* ---- the BSP's own interrupt state ---- */

    uint64_t bsp_rflags;
    __asm__ volatile ("pushfq; pop %0" : "=r"(bsp_rflags));
    ok &= check_v(S, "BSP has interrupts enabled (RFLAGS.IF set)",
                  (bsp_rflags & RFLAGS_IF) != 0, bsp_rflags);

    uint64_t dbase = lapic_dispatch_base();
    ok &= check_v(S, "a LAPIC base is published for interrupt-context EOI",
                  dbase != 0, dbase);

    if (dbase != 0) {
        uint32_t bsp_svr = lapic_reg_read(dbase, LAPIC_SVR_OFFSET);
        ok &= check_v(S, "BSP LAPIC is software enabled (SVR bit 8)",
                      (bsp_svr & LAPIC_SVR_ENABLE) != 0, bsp_svr);
        ok &= check_v(S, "BSP SVR's vector field is the spurious vector",
                      (bsp_svr & 0xFFu) == lapic_spurious_vector(),
                      bsp_svr);
    }

    /* ---- every AP's own interrupt state, as reported by that AP ---- */

    if (smp == 0 || !smp->started) {
        /* Recorded as a failure, not a skip, for the same reason as
         * Phase 1: "APs run interrupt-enabled" cannot be established on a
         * machine with no APs. */
        ok &= check(S, "SMP startup was attempted (AP interrupt state is"
                    " meaningless without APs)", 0);
        return ok;
    }

    /* AP census.
     *
     * NOTE ON STATES: the BSP's CpuInfo.state is CPU_STATE_BSP, not
     * CPU_STATE_ONLINE - the enum distinguishes them. So "state ==
     * CPU_STATE_ONLINE" already means "an AP that came up", and there is
     * no need to filter the BSP out by APIC ID. An earlier version of
     * this test counted CPU_STATE_ONLINE as "every online CPU" and then
     * subtracted one for the BSP, which under -smp 4 expected 2 APs while
     * 3 had correctly reported. Both numbers are derived explicitly here
     * so that mistake cannot recur silently. */
    uint32_t aps = 0;              /* CPUs that ran ap_entry() and are up */
    uint32_t bsp_seen = 0;
    uint32_t svr_enabled = 0;
    uint32_t svr_vector_ok = 0;
    uint32_t if_set = 0;
    uint32_t rflags_published = 0;

    for (uint32_t i = 0; i < ACPI_MAX_CPUS; i++) {
        const CpuInfo *c = &smp->cpus[i];

        if (c->state == CPU_STATE_BSP) {
            /* The BSP does not go through ap_entry(), so it has no
             * self-reported SVR or RFLAGS; its interrupt state was
             * checked directly above by reading its own registers.
             * Counting it among the reporters would be counting evidence
             * that does not exist. */
            bsp_seen++;
            continue;
        }
        if (c->state != CPU_STATE_ONLINE) continue;

        aps++;

        if ((c->reported_svr & LAPIC_SVR_ENABLE) != 0) svr_enabled++;
        if ((c->reported_svr & 0xFFu) == lapic_spurious_vector()) {
            svr_vector_ok++;
        }
        if (c->reported_rflags != 0) rflags_published++;
        if ((c->reported_rflags & RFLAGS_IF) != 0) if_set++;
    }

    uint32_t online_seen = aps + bsp_seen;

    /* Cross-check the census against the count SMP startup recorded, so
     * that a wrong denominator cannot make the per-AP checks below pass
     * vacuously by expecting zero APs. */
    ok &= check_v(S, "AP census agrees with SmpInfo.online_count",
                  online_seen == smp->online_count, online_seen);
    ok &= check_v(S, "exactly one CPU is the BSP", bsp_seen == 1, bsp_seen);

    /* THE UNIPROCESSOR CASE.
     *
     * Every per-AP check below has the form `counter == aps`, which is
     * trivially true when aps is 0 - so on a single-CPU machine they
     * would all "pass" while establishing nothing. Reporting that as a
     * pass would be exactly the kind of vacuous evidence this suite is
     * supposed to refuse.
     *
     * So the AP block is SKIPPED, with a printed note, when and only when
     * the machine genuinely has one CPU. If aps is 0 while more than one
     * CPU is online, that is a real failure and is reported as one -
     * which is what distinguishes "there are no APs to check" from "the
     * APs are there and none of them reported".
     *
     * The skip changes the check total between -smp 1 and -smp N. That
     * is the same convention Phase 1 already uses for its idle-descriptor
     * check, and it is preferable to a count that stays constant by
     * counting assertions that assert nothing. */
    if (aps == 0) {
        ok &= check_v(S, "a single-CPU machine really is single-CPU (no AP"
                      " is missing)", online_seen == 1, online_seen);
        serial_puts("[test] K01-IRQ: SKIPPED - per-AP interrupt-state"
                    " checks: this run has no APs (-smp 1), so \"every AP"
                    " is interruptible\" has no subject. The BSP's own"
                    " interrupt state was checked above. Run with -smp 2"
                    " or more for AP coverage.\n");
        return ok;
    }

    ok &= check_v(S, "every online AP published its own RFLAGS",
                  rflags_published == aps, rflags_published);

    /* The two checks this phase exists to make. */
    ok &= check_v(S, "every online AP's LAPIC is software enabled (its own"
                  " SVR read-back)",
                  svr_enabled == aps, svr_enabled);
    ok &= check_v(S, "every online AP reports RFLAGS.IF set - APs are"
                  " genuinely interruptible",
                  if_set == aps, if_set);

    ok &= check_v(S, "every online AP's SVR names the spurious vector",
                  svr_vector_ok == aps, svr_vector_ok);

    serial_puts("[test] K01-IRQ: ");
    serial_put_dec64(aps);
    serial_puts(" AP(s) checked, ");
    serial_put_dec64(online_seen);
    serial_puts(" CPU(s) online\n");

    /* Honest statement of what this phase does NOT establish. Written to
     * the log rather than only to a report, because the log outlives the
     * conversation.
     *
     * In particular: no IPI has been SENT yet. Every check above shows
     * that an AP is in a state where it COULD receive one. Proving that a
     * targeted interrupt actually arrives at a chosen CPU requires the
     * IPI layer, which is Phase 3, and it is exactly the kind of claim
     * that must not be inferred from "IF is set". */
    serial_puts("[test] K01-IRQ: NOT PROVEN HERE - that an IPI actually"
                " reaches a chosen AP (nothing sends one yet; that is"
                " Phase 3), interrupt behaviour under KVM or on real"
                " hardware, and nesting/re-entrancy of the dispatch path"
                " under sustained load\n");
    serial_puts("[test] K01-IRQ: by design - the handler table is written"
                " only during single-threaded init, so the dispatch path"
                " takes no lock; APs park in `hlt` with interrupts"
                " enabled and no `cli`\n");

    return ok;
}

/* ================================================================== *
 * PHASE 3 - inter-processor interrupts.
 *
 * This is the first phase whose central claim cannot be checked by
 * inspecting state: "a targeted IPI reaches the CPU it was aimed at"
 * is a statement about something happening on ANOTHER CPU, at a time
 * this CPU does not control.
 *
 * The mechanism used to observe it is a per-CPU counter array written
 * only by the receiving CPU, at its own index, from the IPI handler.
 * One writer per slot means no lock is needed - which matters, because
 * the receiver runs in interrupt context and Phase 4 will require that
 * path to take no VMM or PMM lock. The initiator then polls for the
 * counter it expects, with a bounded wait, so a lost IPI fails the test
 * instead of hanging the boot.
 *
 * WHY THE COUNTER IS INDEXED PER CPU rather than being a single total:
 * a total would prove "somebody received it", which is exactly the
 * weaker claim that a broadcast could satisfy while targeting was
 * broken. Checking that CPU n's slot moved AND every other slot did
 * not is what makes it a test of targeting.
 * ================================================================== */

/* The vector Phase 3 uses for its own delivery tests. 0x41 is chosen to
 * sit just above the range Phase 4 will take for the shootdown vector, so
 * the two never collide, and well clear of the timer at 0x20. */
#define K01_IPI_TEST_VECTOR 0x41

/* Receipts, one slot per CPU index. `volatile` because the initiator
 * polls it while another CPU writes it; the write is a plain increment
 * because each slot has exactly one writer - the CPU whose index it is.
 *
 * PERCPU_MAX_CPUS is the same bound as ACPI_MAX_CPUS (percpu.c asserts
 * that), so a slot exists for every CPU that can exist. */
static volatile uint32_t g_ipi_receipts[PERCPU_MAX_CPUS];

/* Receipts recorded by a CPU that could not identify itself. Should stay
 * zero: an IPI handler running on a CPU with no CPU-local storage would
 * mean the AP handshake let a CPU through before percpu was up. */
static volatile uint32_t g_ipi_anonymous;

static void ipi_test_handler(InterruptFrame *frame)
{
    (void)frame;

    /* The checked accessor, not percpu_this(): if GS base were still zero
     * on this CPU, percpu_this() would read linear address 0 and this
     * handler would corrupt whatever lives there. Recording the anomaly
     * and moving on is strictly better than that. */
    PerCpu *p = percpu_this_or_null();
    if (p != 0 && p->cpu_index < PERCPU_MAX_CPUS) {
        g_ipi_receipts[p->cpu_index]++;
    } else {
        g_ipi_anonymous++;
    }

    /* EOI here, in the handler, because the dispatcher deliberately does
     * not do it - see irq.h. Omitting it would leave this CPU's
     * in-service bit set and it would never receive another IPI, which is
     * the failure Phase 4 would then experience as a CPU that
     * acknowledged exactly one shootdown and then went silent. */
    lapic_send_eoi(lapic_dispatch_base());
}

/* Polls for `slot` to reach `target`, up to a bounded number of
 * iterations. Returns 1 on success.
 *
 * A BOUND, NOT A TIMEOUT, and the difference is stated because it
 * matters: there is no time source usable here that is independent of
 * the LAPIC being tested, so this cannot be expressed in milliseconds.
 * What it guarantees is that a lost IPI ends the wait and fails a check,
 * rather than hanging the boot and being reported as a harness timeout -
 * which is the failure mode that makes a suite useless.
 *
 * `pause` keeps the spin cheap; the compiler barrier is unnecessary
 * because the slot is volatile, but the read is written explicitly to
 * make it obvious it is re-read each iteration. */
static int wait_for_receipt(volatile uint32_t *slot, uint32_t target)
{
    for (uint32_t i = 0; i < 20000000u; i++) {
        if (*slot >= target) return 1;
        __asm__ volatile ("pause");
    }
    return 0;
}

static int test_ipi(const SmpInfo *smp)
{
    const char *S = "K01-IPI";
    int ok = 1;

    /* ---- validation, before anything is sent ---- */

    /* The IPI layer refuses vectors nothing can handle. Checked BEFORE
     * the test vector is registered, so "unregistered vectors are
     * refused" is established against a vector that is genuinely
     * unregistered at that moment rather than one chosen to be obscure. */
    ok &= check_v(S, "sending an unregistered vector is refused",
                  ipi_send_self(K01_IPI_TEST_VECTOR) == IPI_ERR_BAD_VECTOR,
                  K01_IPI_TEST_VECTOR);

    ok &= check(S, "sending an exception-range vector is refused",
                ipi_send_self(14) == IPI_ERR_BAD_VECTOR);
    ok &= check(S, "sending vector 31 is refused",
                ipi_send_self(31) == IPI_ERR_BAD_VECTOR);
    ok &= check_v(S, "sending the LAPIC spurious vector is refused",
                  ipi_send_self(lapic_spurious_vector())
                      == IPI_ERR_BAD_VECTOR,
                  lapic_spurious_vector());

    /* Now register the handler, which is also the precondition for every
     * send below to be permitted at all. */
    ok &= check(S, "the IPI test vector can be registered",
                irq_register(K01_IPI_TEST_VECTOR, ipi_test_handler,
                             "k01-ipi-test") == IRQ_OK);

    /* An APIC ID that no CPU has. 0xFEEDFACE rather than something like
     * 255 because a plausible-looking ID might actually exist on a large
     * machine, and a validation test that accidentally names a real CPU
     * would send a live IPI while claiming to test refusal. */
    ok &= check(S, "sending to an APIC ID that is not online is refused",
                ipi_send(0xFEEDFACEu, K01_IPI_TEST_VECTOR)
                    == IPI_ERR_TARGET_OFFLINE);

    ok &= check(S, "an APIC ID that is not online reports as not online",
                ipi_target_is_online(0xFEEDFACEu) == 0);

    if (smp == 0 || !smp->started) {
        ok &= check(S, "SMP startup was attempted (IPI delivery is"
                    " meaningless without a CPU inventory)", 0);
        return ok;
    }

    ok &= check_v(S, "the BSP's own APIC ID reports as online",
                  ipi_target_is_online(smp->bsp_apic_id) != 0,
                  smp->bsp_apic_id);

    /* Targeting self through the targeted path is refused, so that a
     * shootdown initiator cannot end up waiting on its own
     * acknowledgement by passing its own ID in a loop. */
    ok &= check_v(S, "targeting the calling CPU via ipi_send() is refused",
                  ipi_send(smp->bsp_apic_id, K01_IPI_TEST_VECTOR)
                      == IPI_ERR_TARGET_IS_SELF,
                  smp->bsp_apic_id);

    /* EXACTLY six sends were refused above, not "at least" six: an exact
     * count is what catches a validation path that rejects something it
     * should have delivered, or double-counts. Enumerated so the number
     * is checkable by reading rather than by running - unregistered
     * vector, exception-range vector 14, vector 31, the spurious vector,
     * an offline APIC ID, and self via the targeted path. The
     * ipi_target_is_online() check between them is a query, not a send,
     * and correctly does not count.
     *
     * The second half is the stronger claim: not one of those refusals
     * reached the ICR. A layer that validated AFTER writing would pass
     * every individual refusal check above and still have sent six
     * unwanted interrupts. */
    uint64_t rejects_after_validation = ipi_reject_count();
    ok &= check_v(S, "all six refusals above were counted as rejects and"
                  " none of them touched the ICR",
                  rejects_after_validation == 6 && ipi_sent_count() == 0,
                  rejects_after_validation);

    /* ---- delivery to self ---- */

    /* Done first because it needs no AP, so a failure here localizes the
     * problem to the ICR write itself rather than to anything about
     * another CPU's state. The BSP's own slot is index 0. */
    uint32_t bsp_index = 0;
    {
        PerCpu *p = percpu_this_or_null();
        if (p != 0) bsp_index = p->cpu_index;
    }

    uint32_t before_self = g_ipi_receipts[bsp_index];
    IpiResult self_r = ipi_send_self(K01_IPI_TEST_VECTOR);
    ok &= check(S, "a self-directed IPI is accepted by the local APIC",
                self_r == IPI_OK);
    ok &= check_v(S, "the self-directed IPI actually ran the handler on"
                  " this CPU",
                  wait_for_receipt(&g_ipi_receipts[bsp_index],
                                   before_self + 1) != 0,
                  g_ipi_receipts[bsp_index]);

    /* ---- targeted delivery to each AP in turn ---- */

    /* Counted before anything is sent, so that the uniprocessor case can
     * be branched on honestly rather than passing vacuously: with no APs,
     * "every targeted IPI reached its target" is true because no targeted
     * IPI was sent, and a suite that reports that as a pass is claiming
     * evidence it does not have. */
    uint32_t aps = 0;
    for (uint32_t i = 0; i < ACPI_MAX_CPUS; i++) {
        if (smp->cpus[i].state == CPU_STATE_ONLINE) aps++;
    }

    if (aps == 0) {
        /* Uniprocessor. The self-IPI above already proved the ICR write,
         * the delivery-status handling, and the dispatch path; targeting
         * and broadcast-excluding-self are not testable with one CPU. */
        ok &= check_v(S, "with no APs online, exactly one CPU is present"
                      " (uniprocessor is a legitimate configuration, not a"
                      " failed startup)",
                      smp->online_count <= 1, smp->online_count);
        ok &= check_v(S, "no IPI send timed out or found the ICR busy",
                      ipi_timeout_count() == 0, ipi_timeout_count());
        ok &= check_v(S, "the only accepted send was the self-IPI",
                      ipi_sent_count() == 1, ipi_sent_count());
        ok &= check_v(S, "no IPI landed on an unregistered vector",
                      irq_unhandled_count() == 0, irq_unhandled_count());

        serial_puts("[test] K01-IPI: SKIPPED - targeted delivery to another"
                    " CPU and broadcast-excluding-self are not testable at"
                    " -smp 1; those checks are omitted rather than counted"
                    " as passes\n");
        serial_puts("[test] K01-IPI: NOT PROVEN HERE - everything the"
                    " multi-CPU run proves. This configuration establishes"
                    " only that the send path itself works.\n");
        return ok;
    }

    uint32_t targeted_delivered = 0;
    uint32_t targeted_accepted = 0;
    uint32_t misdelivered = 0;

    for (uint32_t i = 0; i < ACPI_MAX_CPUS; i++) {
        const CpuInfo *c = &smp->cpus[i];
        if (c->state != CPU_STATE_ONLINE) continue;   /* excludes the BSP */

        /* Snapshot every slot, so that "only the targeted CPU responded"
         * can be checked rather than assumed. This is the part that makes
         * this a targeting test: a broadcast bug would deliver to all of
         * them and be caught here. */
        uint32_t snapshot[PERCPU_MAX_CPUS];
        for (uint32_t k = 0; k < PERCPU_MAX_CPUS; k++) {
            snapshot[k] = g_ipi_receipts[k];
        }

        uint32_t target_index = c->percpu_index;
        if (target_index >= PERCPU_MAX_CPUS) continue;

        if (ipi_send(c->expected_apic_id, K01_IPI_TEST_VECTOR) != IPI_OK) {
            continue;
        }
        targeted_accepted++;

        if (!wait_for_receipt(&g_ipi_receipts[target_index],
                             snapshot[target_index] + 1)) {
            continue;
        }
        targeted_delivered++;

        /* Any OTHER slot that moved means the IPI went somewhere it was
         * not aimed. The BSP's slot is excluded from this comparison
         * because the BSP is running this loop with interrupts enabled and
         * its timer is live - but the timer does not touch these slots, so
         * in practice only a misdelivered IPI could move it. It is
         * excluded anyway rather than relied upon. */
        for (uint32_t k = 0; k < PERCPU_MAX_CPUS; k++) {
            if (k == target_index || k == bsp_index) continue;
            if (g_ipi_receipts[k] != snapshot[k]) misdelivered++;
        }
    }

    ok &= check_v(S, "every targeted IPI was accepted by the local APIC",
                  targeted_accepted == aps, targeted_accepted);

    /* THE central claim of this phase. */
    ok &= check_v(S, "every targeted IPI ran the handler on the CPU it was"
                  " aimed at",
                  targeted_delivered == aps, targeted_delivered);
    ok &= check_v(S, "no targeted IPI was delivered to a CPU it was not"
                  " aimed at",
                  misdelivered == 0, misdelivered);

    /* ---- broadcast to all but self ---- */

    uint32_t bcast_snapshot[PERCPU_MAX_CPUS];
    for (uint32_t k = 0; k < PERCPU_MAX_CPUS; k++) {
        bcast_snapshot[k] = g_ipi_receipts[k];
    }
    uint32_t bsp_before_bcast = g_ipi_receipts[bsp_index];

    ok &= check(S, "a broadcast-to-others IPI is accepted by the local"
                " APIC",
                ipi_broadcast_others(K01_IPI_TEST_VECTOR) == IPI_OK);

    uint32_t bcast_received = 0;
    for (uint32_t i = 0; i < ACPI_MAX_CPUS; i++) {
        const CpuInfo *c = &smp->cpus[i];
        if (c->state != CPU_STATE_ONLINE) continue;
        uint32_t idx = c->percpu_index;
        if (idx >= PERCPU_MAX_CPUS) continue;
        if (wait_for_receipt(&g_ipi_receipts[idx],
                             bcast_snapshot[idx] + 1)) {
            bcast_received++;
        }
    }

    ok &= check_v(S, "one broadcast reached every online AP",
                  bcast_received == aps, bcast_received);

    /* EXCLUDING SELF is the half of the shorthand that is easy to get
     * wrong, and getting it wrong is what would make a shootdown
     * initiator invalidate its own TLB twice and wait for an ack from
     * itself. Checked after the per-AP waits above, so the broadcast has
     * demonstrably completed by the time the sender's slot is read. */
    ok &= check_v(S, "the broadcast did NOT run on the sender",
                  g_ipi_receipts[bsp_index] == bsp_before_bcast,
                  g_ipi_receipts[bsp_index]);

    /* ---- health of the send path itself ---- */

    ok &= check_v(S, "no IPI send timed out or found the ICR busy",
                  ipi_timeout_count() == 0, ipi_timeout_count());
    ok &= check_v(S, "the accepted-send count matches the sends made"
                  " (1 self + per-AP targeted + 1 broadcast)",
                  ipi_sent_count() == (uint64_t)aps + 2, ipi_sent_count());
    ok &= check_v(S, "no IPI ran on a CPU that could not identify itself",
                  g_ipi_anonymous == 0, (uint64_t)g_ipi_anonymous);
    ok &= check_v(S, "no IPI landed on an unregistered vector",
                  irq_unhandled_count() == 0, irq_unhandled_count());
    ok &= check_v(S, "the dispatcher's count for the IPI vector matches the"
                  " receipts recorded by handlers",
                  irq_dispatch_count(K01_IPI_TEST_VECTOR)
                      == (uint64_t)aps * 2 + 1,
                  irq_dispatch_count(K01_IPI_TEST_VECTOR));

    /* Leave the test vector registered. Unregistering it would repeat the
     * Phase 2 mistake of tearing down a vector that has been delivered
     * during this boot: an IPI still in flight would then land on the
     * unregistered path. The slot costs one pointer and nothing sends
     * this vector after this function returns. */

    serial_puts("[test] K01-IPI: NOT PROVEN HERE - IPI behaviour under KVM"
                " or on real hardware, delivery while a target holds a"
                " lock or is in a long interrupt-disabled region, and"
                " recovery from a genuinely wedged target (no CPU is"
                " wedged in this test)\n");
    serial_puts("[test] K01-IPI: by design - delivery-status clear means"
                " the local APIC accepted the message, NOT that the"
                " receiver ran; every claim of receipt above comes from a"
                " counter the receiving CPU incremented itself\n");

    return ok;
}

/* ================================================================== *
 * PHASE 4 - cross-CPU TLB shootdown.
 *
 * WHAT CAN AND CANNOT BE PROVEN FROM INSIDE, STATED UP FRONT.
 *
 * The bug this phase prevents is: CPU 0 unmaps a page, CPU 3 still has
 * the translation cached, CPU 3 reads a frame the kernel considers free.
 * Directly OBSERVING that bug requires an AP that touches the address
 * after the unmap and reports what it saw. Every AP in this kernel sits
 * in `hlt` with no work queue, and giving them one would be inventing a
 * scheduler to test a TLB - a far larger change than the milestone asks
 * for, and one whose own bugs would be indistinguishable from the ones
 * being looked for.
 *
 * So what is proven here is one step short of that, and the gap is
 * printed at runtime rather than glossed: every online AP is shown to
 * have EXECUTED the invalidation for the exact request that was
 * published to it, and to have reported completion only afterwards. The
 * counters that establish this are written by the APs themselves, in
 * their own slots, from interrupt context. What is not proven is that an
 * AP which SKIPPED the invalidation would have observed stale data,
 * because no AP is made to look.
 *
 * The deliberate faults added in Phase 7 (injections 6 and 7) close part
 * of this gap from the other direction: they remove the shootdown and
 * require the suite to notice.
 * ================================================================== */

static int test_tlb(const SmpInfo *smp)
{
    const char *S = "K01-TLB";
    int ok = 1;

    /* ---- the layer is armed ---- */

    ok &= check_v(S, "the shootdown vector has a registered handler",
                  irq_handler_for(TLB_SHOOTDOWN_VECTOR) != 0,
                  TLB_SHOOTDOWN_VECTOR);
    ok &= check(S, "the shootdown vector is owned by the TLB subsystem",
                str_eq(irq_name_for(TLB_SHOOTDOWN_VECTOR), "tlb-shootdown"));

    /* The three KERNEL-01 vectors must be distinct from each other and
     * from the timer. Checked rather than assumed because a collision
     * would not fail loudly - it would deliver shootdowns to the timer
     * handler, which would EOI them and invalidate nothing. */
    ok &= check(S, "the shootdown vector collides with neither the timer"
                " nor the Phase 3 test vector",
                TLB_SHOOTDOWN_VECTOR != TIMER_VECTOR &&
                TLB_SHOOTDOWN_VECTOR != K01_IPI_TEST_VECTOR &&
                TLB_SHOOTDOWN_VECTOR != lapic_spurious_vector());

    /* ---- range validation, before anything is sent ---- */

    ok &= check(S, "a zero-page range is rejected",
                tlb_shootdown_range(VEX_KMAP_BASE, 0) == TLB_ERR_BAD_RANGE);
    ok &= check(S, "a misaligned range base is rejected",
                tlb_shootdown_range(VEX_KMAP_BASE + 1, 1)
                    == TLB_ERR_BAD_RANGE);

    if (smp == 0 || !smp->started) {
        ok &= check(S, "SMP startup was attempted (a cross-CPU shootdown is"
                    " meaningless without a CPU inventory)", 0);
        return ok;
    }

    /* Count APs before sending anything, so the uniprocessor case is
     * branched on rather than passing vacuously. */
    uint32_t aps = 0;
    for (uint32_t i = 0; i < ACPI_MAX_CPUS; i++) {
        if (smp->cpus[i].state == CPU_STATE_ONLINE) aps++;
    }

    /* A real mapping to invalidate. Using a genuinely mapped page rather
     * than an arbitrary address matters: `invlpg` on an unmapped address
     * is a no-op that cannot fail, so a shootdown "test" against one would
     * pass even if the invalidation were removed entirely. */
    uint64_t va = vmm_kmap_reserve_virtual(1);
    uint64_t frame = pmm_alloc_page();
    int have_page = 0;
    if (va != 0 && frame != 0) {
        have_page = (vmm_map_page(va, frame, VMM_PRESENT | VMM_WRITE)
                     == VMM_OK);
    }
    ok &= check_v(S, "a scratch page could be mapped to shoot down",
                  have_page != 0, va);
    if (have_page) {
        /* Touch it, so this CPU definitely has the translation cached and
         * the local invalidation below has something to remove. */
        *(volatile uint64_t *)va = 0x5445535431ull;
        ok &= check(S, "the scratch page is readable before the shootdown",
                    *(volatile uint64_t *)va == 0x5445535431ull);
    }

    uint64_t va_ok = have_page ? va : VEX_KMAP_BASE;

    if (aps == 0) {
        /* Uniprocessor. A local invalidation IS the entire shootdown, and
         * the layer must say so rather than reporting a remote success it
         * did not perform. */
        ok &= check(S, "with no APs online, a shootdown reports local-only"
                    " completion",
                    tlb_shootdown_page(va_ok) == TLB_OK_LOCAL_ONLY);
        ok &= check_v(S, "no remote request was issued",
                      tlb_remote_requests() == 0, tlb_remote_requests());
        ok &= check_v(S, "no acknowledgement was waited for and none timed"
                      " out",
                      tlb_acks_received() == 0 && tlb_timeouts() == 0,
                      tlb_timeouts());

        /* Permitted with interrupts disabled specifically because it
         * cannot wait for anybody - this is what lets the pre-`sti` boot
         * path keep calling mapping primitives. */
        __asm__ volatile ("cli");
        TlbResult cli_r = tlb_shootdown_page(va_ok);
        __asm__ volatile ("sti");
        ok &= check(S, "a local-only shootdown is permitted with interrupts"
                    " disabled", cli_r == TLB_OK_LOCAL_ONLY);

        serial_puts("[test] K01-TLB: SKIPPED - remote delivery, acknowledgement,"
                    " stale-request handling and the interrupts-disabled"
                    " refusal are not testable at -smp 1; those checks are"
                    " omitted rather than counted as passes\n");
        if (have_page) vmm_unmap_page(va_ok);
        return ok;
    }

    /* ---- the anti-deadlock guard ---- */

    /* THE most important negative check in this phase. vmm_lock() clears
     * IF, so a shootdown attempted while holding the VMM lock would be a
     * shootdown attempted with interrupts disabled - and a CPU spinning
     * for that same lock, also with IF clear, could never answer it. The
     * layer must refuse rather than spin out its budget.
     *
     * Tested by clearing IF directly rather than by taking the VMM lock,
     * because taking the VMM lock here and then failing an assertion
     * would leave it held and wedge the boot. The guard being tested reads
     * RFLAGS.IF and does not care how it came to be clear. */
    __asm__ volatile ("cli");
    TlbResult unsafe_r = tlb_shootdown_page(va_ok);
    __asm__ volatile ("sti");
    ok &= check(S, "a remote shootdown with interrupts disabled is REFUSED,"
                " not attempted (this is the deadlock guard)",
                unsafe_r == TLB_ERR_UNSAFE_CONTEXT);
    ok &= check_v(S, "the refused shootdown issued no remote request",
                  tlb_remote_requests() == 0, tlb_remote_requests());
    ok &= check_v(S, "the refused shootdown still invalidated the"
                  " initiator's own TLB (a refusal must leave the caller"
                  " self-consistent)",
                  tlb_shootdowns_initiated() >= 1,
                  tlb_shootdowns_initiated());

    /* ---- one real shootdown, checked per CPU ---- */

    uint64_t serviced_before[PERCPU_MAX_CPUS];
    uint64_t pages_before[PERCPU_MAX_CPUS];
    for (uint32_t k = 0; k < PERCPU_MAX_CPUS; k++) {
        serviced_before[k] = tlb_serviced_by_cpu(k);
        pages_before[k]    = tlb_pages_invalidated_by_cpu(k);
    }

    TlbResult r1 = tlb_shootdown_page(va_ok);
    ok &= check(S, "a single-page cross-CPU shootdown completes with every"
                " target acknowledging", r1 == TLB_OK);
    ok &= check_v(S, "exactly one remote request was issued per online AP",
                  tlb_remote_requests() == aps, tlb_remote_requests());
    ok &= check_v(S, "every acknowledgement was received",
                  tlb_acks_received() == aps, tlb_acks_received());
    ok &= check_v(S, "no target timed out", tlb_timeouts() == 0,
                  tlb_timeouts());

    /* Per-CPU, which is the part that makes this evidence rather than a
     * summary: each AP's slot is written only by that AP, from its own
     * interrupt handler. */
    uint32_t serviced_aps = 0;
    uint32_t paged_aps = 0;
    uint32_t bsp_index = 0;
    { PerCpu *p = percpu_this_or_null(); if (p) bsp_index = p->cpu_index; }

    for (uint32_t i = 0; i < ACPI_MAX_CPUS; i++) {
        const CpuInfo *c = &smp->cpus[i];
        if (c->state != CPU_STATE_ONLINE) continue;
        uint32_t idx = c->percpu_index;
        if (idx >= PERCPU_MAX_CPUS) continue;
        if (tlb_serviced_by_cpu(idx) > serviced_before[idx]) serviced_aps++;
        if (tlb_pages_invalidated_by_cpu(idx) > pages_before[idx]) paged_aps++;
    }

    ok &= check_v(S, "every online AP ran the shootdown handler itself",
                  serviced_aps == aps, serviced_aps);
    ok &= check_v(S, "every online AP actually invalidated at least one"
                  " page (it recorded the work, not just the interrupt)",
                  paged_aps == aps, paged_aps);

    /* The initiator must NOT appear as a remote target: it invalidated
     * directly, and asking it to acknowledge its own request would be
     * waiting for an interrupt it cannot take while it is here. */
    ok &= check_v(S, "the initiator did not service its own shootdown as a"
                  " remote request",
                  tlb_serviced_by_cpu(bsp_index) == serviced_before[bsp_index],
                  tlb_serviced_by_cpu(bsp_index));

    /* ---- the mapping change the shootdown was protecting ---- */

    if (have_page) {
        uint64_t phys = 0;
        ok &= check(S, "the scratch page still translates before it is"
                    " unmapped",
                    vmm_translate(va_ok, &phys) == VMM_OK);

        ok &= check(S, "the scratch page can be unmapped",
                    vmm_unmap_page(va_ok) == VMM_OK);

        /* THE ORDER THAT MATTERS: the mapping is already gone before this
         * runs, so no CPU can establish a NEW cached translation, and this
         * removes the ones that already exist. Doing it in the other order
         * would leave a window in which a CPU could re-cache the entry
         * after the invalidation and before the unmap. */
        TlbResult r2 = tlb_shootdown_page(va_ok);
        ok &= check(S, "the post-unmap shootdown completes with every target"
                    " acknowledging", r2 == TLB_OK);

        ok &= check(S, "the unmapped page no longer translates on this CPU",
                    vmm_translate(va_ok, &phys) != VMM_OK);
        ok &= check_v(S, "still no target has timed out",
                      tlb_timeouts() == 0, tlb_timeouts());
    }

    /* ---- full flush and range promotion ---- */

    uint64_t flushes_before = tlb_full_flushes();
    ok &= check(S, "a full-flush shootdown completes",
                tlb_shootdown_all() == TLB_OK);
    ok &= check_v(S, "the full flush was recorded as a flush, not a range",
                  tlb_full_flushes() == flushes_before + 1,
                  tlb_full_flushes());

    /* A range larger than the enumeration limit is promoted to a full
     * flush rather than rejected: a long invlpg loop inside an interrupt
     * handler on every CPU is worse for the system than one CR3 reload,
     * and it is always correct, only less precise. */
    flushes_before = tlb_full_flushes();
    ok &= check(S, "an over-long range is promoted to a full flush, not"
                " rejected",
                tlb_shootdown_range(VEX_KMAP_BASE, TLB_MAX_RANGE_PAGES + 1)
                    == TLB_OK);
    ok &= check_v(S, "the promoted range was recorded as a full flush",
                  tlb_full_flushes() == flushes_before + 1,
                  tlb_full_flushes());
    ok &= check(S, "a range at exactly the enumeration limit is NOT promoted",
                tlb_shootdown_range(VEX_KMAP_BASE, TLB_MAX_RANGE_PAGES)
                    == TLB_OK &&
                tlb_full_flushes() == flushes_before + 1);

    /* ---- stale request handling ---- */

    /* Deliberately last, because it perturbs the counters checked above.
     *
     * Sends the shootdown vector with NO request outstanding, by going
     * straight at the IPI layer. Every receiver must recognise that its
     * requested generation equals its acknowledged generation, invalidate
     * nothing, and count the event - because a receiver that instead
     * re-serviced whatever range was left in its slot could satisfy a
     * LATER initiator's wait with work done for an earlier request. That
     * is the stale-acknowledgement hazard, and this is the direct test of
     * it. */
    uint64_t stale_before = tlb_stale_ignored();
    uint64_t serviced_snapshot[PERCPU_MAX_CPUS];
    for (uint32_t k = 0; k < PERCPU_MAX_CPUS; k++) {
        serviced_snapshot[k] = tlb_serviced_by_cpu(k);
    }

    ok &= check(S, "a shootdown IPI can be sent with no request outstanding",
                ipi_broadcast_others(TLB_SHOOTDOWN_VECTOR) == IPI_OK);

    /* Bounded wait for the stale count to move, so a lost IPI fails a
     * check instead of making the next assertion flaky. */
    for (uint32_t spin = 0; spin < 20000000u; spin++) {
        if (tlb_stale_ignored() >= stale_before + aps) break;
        __asm__ volatile ("pause");
    }

    ok &= check_v(S, "every AP recognised the request as already"
                  " acknowledged and counted it",
                  tlb_stale_ignored() >= stale_before + aps,
                  tlb_stale_ignored() - stale_before);

    uint32_t wrongly_serviced = 0;
    for (uint32_t k = 0; k < PERCPU_MAX_CPUS; k++) {
        if (tlb_serviced_by_cpu(k) != serviced_snapshot[k]) wrongly_serviced++;
    }
    ok &= check_v(S, "no AP re-serviced a request it had already"
                  " acknowledged (stale-ack protection)",
                  wrongly_serviced == 0, wrongly_serviced);

    /* ---- health of the whole path ---- */

    ok &= check_v(S, "no shootdown handler ran on a CPU that could not"
                  " identify itself",
                  tlb_anonymous_receipts() == 0, tlb_anonymous_receipts());
    ok &= check_v(S, "no shootdown vector landed on an unregistered handler",
                  irq_unhandled_count() == 0, irq_unhandled_count());
    ok &= check_v(S, "no target ever timed out across the whole phase",
                  tlb_timeouts() == 0, tlb_timeouts());

    serial_puts("[test] K01-TLB: NOT PROVEN HERE - that an AP which SKIPPED"
                " the invalidation would observe stale data. Every AP is in"
                " `hlt` with no work queue, so nothing is made to read the"
                " unmapped address; giving APs work would mean inventing a"
                " scheduler to test a TLB. What IS proven is that every"
                " online AP executed the invalidation for the exact request"
                " published to it and reported completion only afterwards."
                " Injections 6 and 7 attack this from the other side.\n");
    serial_puts("[test] K01-TLB: NOT PROVEN HERE - behaviour under KVM or on"
                " real hardware, and recovery from a genuinely wedged CPU:"
                " the acknowledgement wait is BOUNDED so it cannot deadlock,"
                " but no CPU is wedged in this test, so the timeout path is"
                " exercised by construction only.\n");
    serial_puts("[test] K01-TLB: by design - the receiver takes NO lock, and"
                " not for speed: vmm_lock() clears IF, so a handler that"
                " needed the VMM lock could never run on a CPU spinning for"
                " it, and an initiator holding it would wait forever.\n");

    return ok;
}

/* ================================================================== *
 * PHASE 5 - page-table reclamation.
 *
 * ADDRESS CHOICE, AND WHY IT IS NOT ARBITRARY. These tests do not use
 * vmm_kmap_reserve_virtual(). That allocator hands out addresses from the
 * bottom of the kmap window, where every AP's kernel stack already lives,
 * so a page taken from it would share a page table with live stacks - the
 * table would never become empty and the reclamation path being tested
 * would never trigger. The addresses below sit 64 and 65 GiB into the
 * window instead: different PDPT entries from each other and from
 * anything the bump allocator has ever issued, so each one owns its PD and
 * PT outright and nothing else can be affected by freeing them.
 *
 * WHAT THE PML4 ENTRY PROVES. The kmap window is exactly one PML4 entry,
 * and the AP stacks keep the first PDPT entry populated, so the climb must
 * stop after the PD - the PDPT is never empty and the PML4 entry must
 * survive. That is asserted, because "never free a top-level structure"
 * is worth checking rather than assuming.
 *
 * THE IN-SUITE NEGATIVE CONTROL. Reclamation without a completed shootdown
 * is exercised for real, not simulated: the call is made with interrupts
 * disabled, which is a context in which a remote shootdown is refused by
 * design. The gate must then refuse to free, the frames must be counted as
 * leaked, and the violation counter must stay at zero. This needs a remote
 * CPU to exist - on -smp 1 there is nothing to shoot down and the local
 * path legitimately completes - so it takes an explicit SKIPPED branch
 * rather than passing vacuously. Injections 6 and 7 attack the same gate
 * from outside the suite.
 * ================================================================== */

/* 64 and 65 GiB into the kmap window. See the comment above. */
#define K01_RECLAIM_VA_A  (VEX_KMAP_BASE + 0x1000000000ULL)
#define K01_RECLAIM_VA_B  (VEX_KMAP_BASE + 0x1040000000ULL)

static int test_reclaim(const SmpInfo *smp)
{
    const char *S = "K01-RECLAIM";
    int ok = 1;

    /* Counted before anything is sent, so that -smp 1 takes a visible
     * SKIPPED branch instead of passing by accident. */
    int remote_cpus = 0;
    for (uint32_t i = 0; i < smp->cpu_count; i++) {
        if (smp->cpus[i].state == CPU_STATE_ONLINE) remote_cpus++;
    }

    const VmmInfo *vi = vmm_info();

    /* ---- argument validation, before any mapping exists ---- */

    ok &= check(S, "a misaligned reclaim request is refused",
                vmm_unmap_page_reclaim(K01_RECLAIM_VA_A + 8) ==
                VMM_ERR_NOT_ALIGNED);
    ok &= check(S, "reclaiming an address that is not mapped is refused",
                vmm_unmap_page_reclaim(K01_RECLAIM_VA_A) ==
                VMM_ERR_NOT_MAPPED);

    /* The window restriction is the structural guarantee that shared and
     * static tables are unreachable from this path, so each region that
     * must be out of reach is named explicitly rather than covered by one
     * representative address. The identity map, the direct map and the
     * kernel's own text all resolve through tables shared with every CPU
     * and every subsystem. */
    ok &= check(S, "reclaiming an identity-mapped address is refused",
                vmm_unmap_page_reclaim(0x200000ULL) == VMM_ERR_BAD_REQUEST);
    ok &= check(S, "reclaiming a direct-map address is refused",
                vmm_unmap_page_reclaim(VEX_PHYS_MAP_BASE + 0x200000ULL) ==
                VMM_ERR_BAD_REQUEST);
    ok &= check(S, "reclaiming an address just below the kmap window is"
                " refused",
                vmm_unmap_page_reclaim(VEX_KMAP_BASE - VMM_PAGE_SIZE) ==
                VMM_ERR_BAD_REQUEST);
    ok &= check(S, "reclaiming an address just past the kmap window is"
                " refused",
                vmm_unmap_page_reclaim(VEX_KMAP_BASE + VEX_KMAP_SIZE) ==
                VMM_ERR_BAD_REQUEST);
    ok &= check_v(S, "no refused request reclaimed anything",
                  vmm_tables_reclaimed() == 0, vmm_tables_reclaimed());

    /* ---- the narrow PMM door refuses everything it should ---- */

    /* pmm_release_reserved_page() is the only way a reserved frame can
     * ever return to the free pool. Each refusal is checked directly,
     * because the safety of the whole phase rests on them. */
    uint64_t scratch = pmm_alloc_page();
    ok &= check_v(S, "scratch frame allocated", scratch != 0, scratch);
    if (scratch) {
        ok &= check(S, "releasing a frame that is not reserved is refused",
                    pmm_release_reserved_page(scratch, PMM_RSV_PAGE_TABLE) ==
                    PMM_ERR_BAD_REQUEST);
        ok &= check(S, "releasing a misaligned address is refused",
                    pmm_release_reserved_page(scratch + 8,
                                              PMM_RSV_PAGE_TABLE) ==
                    PMM_ERR_NOT_ALIGNED);
        ok &= check(S, "releasing under any reason other than PAGE_TABLE is"
                    " refused",
                    pmm_release_reserved_page(scratch, PMM_RSV_KERNEL_IMAGE) ==
                    PMM_ERR_BAD_REQUEST &&
                    pmm_release_reserved_page(scratch, PMM_RSV_FIRMWARE) ==
                    PMM_ERR_BAD_REQUEST &&
                    pmm_release_reserved_page(scratch, PMM_RSV_KERNEL_STACK) ==
                    PMM_ERR_BAD_REQUEST);
        ok &= check(S, "the scratch frame survived every refused release",
                    pmm_is_allocated(scratch) && !pmm_is_reserved(scratch));
        pmm_free_page(scratch);
    }

    /* Reserved but never allocated - firmware, the kernel image, the
     * bitmaps. The allocation-bit requirement is what makes these
     * unreachable no matter what reason is claimed, so it is proven
     * against a frame that really is in that state: frame 0. */
    ok &= check(S, "frame 0 is reserved and not allocated",
                pmm_is_reserved(0) && !pmm_is_allocated(0));
    ok &= check(S, "releasing a reserved frame that was never allocated is"
                " refused",
                pmm_release_reserved_page(0, PMM_RSV_PAGE_TABLE) ==
                PMM_ERR_RESERVED);

    /* ---- map, access, reclaim ---- */

    uint64_t frame = pmm_alloc_page();
    ok &= check_v(S, "test frame allocated", frame != 0, frame);

    uint64_t tables_before = vi->table_pages;
    uint64_t free_before = pmm_free_frames();

    if (frame) {
        ok &= check(S, "mapping a page in a fresh kmap region succeeds",
                    vmm_map_page(K01_RECLAIM_VA_A, frame, VMM_KERNEL_RW_NX) ==
                    VMM_OK);
        ok &= check_v(S, "the mapping cost new intermediate page tables",
                      vi->table_pages > tables_before, vi->table_pages);

        /* Access, not just translation: a mapping that translates but does
         * not carry data is not a mapping. */
        volatile uint64_t *v = (volatile uint64_t *)(uintptr_t)K01_RECLAIM_VA_A;
        volatile uint64_t *pp = (volatile uint64_t *)(uintptr_t)frame;
        *v = 0xC0FFEE5EED5ULL;
        ok &= check_v(S, "a write through the new mapping lands in the frame",
                      *pp == 0xC0FFEE5EED5ULL, *pp);

        uint64_t phys = 0;
        ok &= check(S, "the mapping translates to the right frame",
                    vmm_translate(K01_RECLAIM_VA_A, &phys) == VMM_OK &&
                    phys == frame);

        /* Capture the tables about to be orphaned so their post-free state
         * can be inspected. Read out of the live entries rather than
         * guessed. */
        uint64_t entry = 0, size = 0;
        uint64_t pml4_entry_before = 0;
        (void)vmm_query(K01_RECLAIM_VA_A, &entry, &size);

        uint64_t cr3_before = vmm_read_cr3();
        uint64_t *pml4 = (uint64_t *)(uintptr_t)(cr3_before & ~0xFFFULL);
        uint64_t pml4_index = (K01_RECLAIM_VA_A >> 39) & 0x1FF;
        pml4_entry_before = pml4[pml4_index];

        uint64_t pdpt_phys = pml4_entry_before & 0x000FFFFFFFFFF000ULL;
        uint64_t *pdpt = (uint64_t *)(uintptr_t)pdpt_phys;
        uint64_t pd_phys = pdpt[(K01_RECLAIM_VA_A >> 30) & 0x1FF] &
                           0x000FFFFFFFFFF000ULL;
        uint64_t *pd = (uint64_t *)(uintptr_t)pd_phys;
        uint64_t pt_phys = pd[(K01_RECLAIM_VA_A >> 21) & 0x1FF] &
                           0x000FFFFFFFFFF000ULL;

        ok &= check(S, "the orphan-to-be tables are reserved as page tables"
                    " and allocated",
                    pmm_is_reserved(pt_phys) && pmm_is_allocated(pt_phys) &&
                    pmm_is_reserved(pd_phys) && pmm_is_allocated(pd_phys));

        /* The ordinary free path must keep refusing these, exactly as it
         * did before this phase existed. If reclamation had been built by
         * loosening pmm_free_page() instead of adding a narrow door, this
         * check would fail and BOOT-03's injection 3 would be meaningless. */
        ok &= check(S, "pmm_free_page() still refuses a live page-table"
                    " frame",
                    pmm_free_page(pt_phys) == PMM_ERR_RESERVED);

        uint64_t shootdowns_before = tlb_completed_count();
        uint64_t reclaimed_before = vmm_tables_reclaimed();

        ok &= check(S, "unmap-with-reclaim succeeds",
                    vmm_unmap_page_reclaim(K01_RECLAIM_VA_A) == VMM_OK);

        /* THE ORDERING REQUIREMENT. A shootdown must have completed during
         * the call - not merely been attempted. */
        ok &= check_v(S, "a TLB shootdown completed during the reclaim",
                      tlb_completed_count() > shootdowns_before,
                      tlb_completed_count() - shootdowns_before);

        ok &= check_v(S, "empty intermediate tables were reclaimed",
                      vmm_tables_reclaimed() > reclaimed_before,
                      vmm_tables_reclaimed() - reclaimed_before);
        ok &= check_v(S, "the live page-table count fell back to where it"
                      " started",
                      vi->table_pages == tables_before, vi->table_pages);
        ok &= check_v(S, "nothing was leaked", vmm_reclaim_leaks() == 0,
                      vmm_reclaim_leaks());

        /* The frames really went back to the allocator: un-reserved,
         * un-allocated, and countable in the free pool. */
        ok &= check(S, "the reclaimed tables are no longer reserved",
                    !pmm_is_reserved(pt_phys) && !pmm_is_reserved(pd_phys));
        ok &= check(S, "the reclaimed tables are no longer allocated",
                    !pmm_is_allocated(pt_phys) && !pmm_is_allocated(pd_phys));

        ok &= check(S, "the address no longer translates",
                    vmm_translate(K01_RECLAIM_VA_A, &phys) != VMM_OK);
        ok &= check(S, "the address no longer has a present entry",
                    vmm_query(K01_RECLAIM_VA_A, &entry, &size) != VMM_OK);

        /* Top-level structures are preserved. The PDPT still holds the AP
         * stacks, so the climb must have stopped below the PML4. */
        ok &= check_v(S, "the kmap PML4 entry survived the reclaim",
                      (pml4[pml4_index] & VMM_PRESENT) != 0 &&
                      pml4[pml4_index] == pml4_entry_before,
                      pml4[pml4_index]);
        ok &= check_v(S, "CR3 is unchanged", vmm_read_cr3() == cr3_before,
                      vmm_read_cr3());
        ok &= check(S, "the PML4 frame itself is still reserved",
                    pmm_is_reserved(cr3_before & ~0xFFFULL));

        /* An unrelated kmap mapping is untouched: the AP stacks live in the
         * first PDPT entry and must still translate. */
        (void)pd;

        /* ---- remap the same address ---- */

        ok &= check(S, "the reclaimed address can be mapped again",
                    vmm_map_page(K01_RECLAIM_VA_A, frame, VMM_KERNEL_RW_NX) ==
                    VMM_OK);
        *v = 0x5150515051505150ULL;
        ok &= check_v(S, "the remapped page carries data correctly",
                      *pp == 0x5150515051505150ULL, *pp);
        ok &= check(S, "the remapped address reclaims again",
                    vmm_unmap_page_reclaim(K01_RECLAIM_VA_A) == VMM_OK);

        /* ---- repeated cycles ---- */

        /* The failure this catches is a reclaim that returns OK while
         * quietly failing to give the frames back: the free count would
         * ratchet down every cycle. Sixteen cycles on two different
         * addresses, then the pool is compared with where it started. */
        int cycles_ok = 1;
        for (int i = 0; i < 16; i++) {
            uint64_t va = (i & 1) ? K01_RECLAIM_VA_B : K01_RECLAIM_VA_A;
            if (vmm_map_page(va, frame, VMM_KERNEL_RW_NX) != VMM_OK) {
                cycles_ok = 0; break;
            }
            *(volatile uint64_t *)(uintptr_t)va = (uint64_t)i + 1;
            if (*pp != (uint64_t)i + 1) { cycles_ok = 0; break; }
            if (vmm_unmap_page_reclaim(va) != VMM_OK) { cycles_ok = 0; break; }
        }
        ok &= check(S, "sixteen map/access/reclaim cycles all succeeded",
                    cycles_ok);
        ok &= check_v(S, "the page-table count returned to its starting"
                      " value after every cycle",
                      vi->table_pages == tables_before, vi->table_pages);
        ok &= check_v(S, "the free-frame pool is exactly where it started",
                      pmm_free_frames() == free_before, pmm_free_frames());
        ok &= check_v(S, "still nothing leaked", vmm_reclaim_leaks() == 0,
                      vmm_reclaim_leaks());

        /* ---- NEGATIVE CONTROL: reclamation without a completed
         * shootdown must be refused ---- */

        if (remote_cpus > 0) {
            ok &= check(S, "a page is mapped for the negative control",
                        vmm_map_page(K01_RECLAIM_VA_A, frame,
                                     VMM_KERNEL_RW_NX) == VMM_OK);

            uint64_t leaks_before = vmm_reclaim_leaks();
            uint64_t rec_before = vmm_tables_reclaimed();
            uint64_t comp_before = tlb_completed_count();

            /* Interrupts off. A remote shootdown in this context is
             * refused by design - the initiator could not answer the
             * shootdowns other CPUs send it, so waiting would livelock.
             * That makes this a genuine "the required shootdown did not
             * happen" condition rather than a simulated one. */
            uint64_t saved;
            __asm__ volatile ("pushfq; pop %0; cli" : "=r"(saved) : : "memory");
            VmmResult nr = vmm_unmap_page_reclaim(K01_RECLAIM_VA_A);
            if (saved & RFLAGS_IF) __asm__ volatile ("sti" ::: "memory");

            ok &= check(S, "reclamation without a completed shootdown is"
                        " refused", nr == VMM_ERR_BAD_REQUEST);
            ok &= check_v(S, "the refused reclaim confirmed no shootdown"
                          " completed",
                          tlb_completed_count() == comp_before,
                          tlb_completed_count() - comp_before);
            ok &= check_v(S, "the refused reclaim freed no page table",
                          vmm_tables_reclaimed() == rec_before,
                          vmm_tables_reclaimed() - rec_before);
            ok &= check_v(S, "the refused reclaim leaked the frames instead"
                          " and counted them",
                          vmm_reclaim_leaks() > leaks_before,
                          vmm_reclaim_leaks() - leaks_before);
            ok &= check(S, "the mapping is gone even though the frames were"
                        " not freed",
                        vmm_translate(K01_RECLAIM_VA_A, &phys) != VMM_OK);

            /* Leaking is the safe direction, but the address space must
             * still be usable afterwards. */
            ok &= check(S, "the address still works after a refused reclaim",
                        vmm_map_page(K01_RECLAIM_VA_A, frame,
                                     VMM_KERNEL_RW_NX) == VMM_OK);
            ok &= check(S, "and reclaims cleanly once interrupts are back on",
                        vmm_unmap_page_reclaim(K01_RECLAIM_VA_A) == VMM_OK);
        } else {
            serial_puts("[test] K01-RECLAIM: SKIPPED - the negative control"
                        " for reclamation without a completed shootdown"
                        " needs a remote CPU to shoot down. With -smp 1 the"
                        " local-only path legitimately completes even with"
                        " interrupts disabled, so there is no way to produce"
                        " an incomplete shootdown without weakening the"
                        " gate itself. Run the SMP matrix for this check.\n");
        }

        pmm_free_page(frame);
    }

    /* ---- the invariant that must hold in every build ---- */

    ok &= check_v(S, "no page table was ever freed without a completed"
                  " shootdown",
                  vmm_reclaim_violations() == 0, vmm_reclaim_violations());
    ok &= check_v(S, "every reclaim attempt was accounted for",
                  vmm_reclaim_attempts() > 0, vmm_reclaim_attempts());

    serial_puts("[test] K01-RECLAIM: NOT PROVEN HERE - that a CPU denied the"
                " shootdown would actually have walked into a freed table."
                " That needs an AP that walks an address on demand and"
                " reports what it found, which needs a scheduler. What IS"
                " proven is the ordering the safety argument rests on:"
                " every entry along the walk is cleared before the"
                " shootdown, a shootdown demonstrably completed before any"
                " frame was freed, and a reclaim whose shootdown did not"
                " complete leaks rather than frees.\n");
    serial_puts("[test] K01-RECLAIM: by design - vmm_unmap_page() is"
                " unchanged and still leaks its page tables. Reclamation"
                " cannot run under the VMM lock, which clears IF, so it is"
                " a separate entry point rather than a change to a"
                " primitive that every BOOT-03 test was written"
                " against.\n");

    return ok;
}

/* ================================================================== *
 * PHASE 6 - reclaimable kmap virtual ranges.
 *
 * WHAT THESE TESTS ARE ACTUALLY GUARDING. The dangerous failure is not
 * "reuse does not happen" - that only wastes a 512 GiB window. It is reuse
 * that hands a range to a second consumer while the first still holds it,
 * or a malformed free that marks a live range reusable. So the checks are
 * weighted accordingly: one check that reuse occurs at all, and the rest on
 * overlap and on every way a free can be wrong.
 *
 * WHY LIVE RANGES ARE INSPECTED AND NOT JUST COUNTED. Every range the test
 * holds is recorded locally and compared against every other, so an overlap
 * would be caught by observation rather than by trusting the allocator's own
 * bookkeeping - which is the thing under test.
 *
 * WHAT IS NOT TESTED, AND WHY. The record table becoming full is not driven
 * to exhaustion: with 96 records and up to 32 stack ranges already
 * outstanding, filling it would mean issuing dozens of ranges whose failure
 * mode is a clean 0 return, and the interesting refusals are all reachable
 * without it. The cursor-exhaustion path is likewise unreachable in a test -
 * it needs 512 GiB of reservations.
 * ================================================================== */

#define K01_KMAP_TRACK 8

static int test_kmap(const SmpInfo *smp)
{
    const char *S = "K01-KMAP";
    int ok = 1;
    (void)smp;

    VmmKmapStats st0, st1;
    vmm_kmap_stats(&st0);

    ok &= check_v(S, "the kmap window is where the layout says it is",
                  st0.window_base == VEX_KMAP_BASE &&
                  st0.window_size == VEX_KMAP_SIZE, st0.window_base);
    ok &= check_v(S, "the cursor is inside the window",
                  st0.cursor >= st0.window_base &&
                  st0.cursor <= st0.window_base + st0.window_size, st0.cursor);
    ok &= check_v(S, "the kernel stacks are already recorded as live ranges",
                  st0.live_ranges > 0, st0.live_ranges);

    /* ---- reserve: alignment, distinctness, no overlap ---- */

    uint64_t bases[K01_KMAP_TRACK];
    uint64_t sizes[K01_KMAP_TRACK];
    int held = 0;

    int all_ok = 1, aligned = 1;
    for (int i = 0; i < K01_KMAP_TRACK; i++) {
        /* Mixed sizes on purpose: an allocator that only ever sees one size
         * cannot demonstrate that reuse matches on size. */
        uint64_t pages = (uint64_t)(i % 3) + 1;
        uint64_t b = vmm_kmap_reserve_virtual(pages);
        if (b == 0) { all_ok = 0; break; }
        if (b & (VMM_PAGE_SIZE - 1)) aligned = 0;
        bases[held] = b; sizes[held] = pages; held++;
    }
    ok &= check_v(S, "eight reservations of mixed sizes all succeeded",
                  all_ok, (uint64_t)held);
    ok &= check(S, "every reserved base is page aligned", aligned);

    /* Compared pairwise against each other rather than against the
     * allocator's own view of itself. */
    int overlap = 0;
    for (int i = 0; i < held; i++) {
        for (int j = i + 1; j < held; j++) {
            uint64_t ai = bases[i], aj = bases[j];
            uint64_t ei = ai + sizes[i] * VMM_PAGE_SIZE;
            uint64_t ej = aj + sizes[j] * VMM_PAGE_SIZE;
            if (ai < ej && aj < ei) overlap = 1;
        }
    }
    ok &= check(S, "no two outstanding ranges overlap", !overlap);

    int in_window = 1;
    for (int i = 0; i < held; i++) {
        if (bases[i] < VEX_KMAP_BASE ||
            bases[i] + sizes[i] * VMM_PAGE_SIZE >
                VEX_KMAP_BASE + VEX_KMAP_SIZE) in_window = 0;
    }
    ok &= check(S, "every reserved range lies inside the kmap window",
                in_window);

    vmm_kmap_stats(&st1);
    ok &= check_v(S, "the cursor never moved backward",
                  st1.cursor >= st0.cursor, st1.cursor);
    ok &= check_v(S, "the live range count rose by exactly eight",
                  st1.live_ranges == st0.live_ranges + (uint64_t)held,
                  st1.live_ranges);

    /* ---- invalid frees, before anything real is freed ---- */

    if (held > 0) {
        ok &= check(S, "freeing zero pages is refused",
                    vmm_kmap_free_virtual(bases[0], 0) == VMM_ERR_BAD_REQUEST);
        ok &= check(S, "freeing a misaligned base is refused",
                    vmm_kmap_free_virtual(bases[0] + 8, sizes[0]) ==
                    VMM_ERR_NOT_ALIGNED);
        ok &= check(S, "freeing a range that was never reserved is refused",
                    vmm_kmap_free_virtual(VEX_KMAP_BASE + 0x2000000000ULL, 1)
                    == VMM_ERR_NO_SUCH_RANGE);
        ok &= check(S, "freeing an address outside the kmap window is"
                    " refused",
                    vmm_kmap_free_virtual(0x200000ULL, 1) ==
                    VMM_ERR_BAD_REQUEST &&
                    vmm_kmap_free_virtual(VEX_KMAP_BASE +
                                          VEX_KMAP_SIZE, 1) ==
                    VMM_ERR_BAD_REQUEST);
        ok &= check(S, "freeing the wrong page count is refused",
                    vmm_kmap_free_virtual(bases[0], sizes[0] + 1) ==
                    VMM_ERR_BAD_REQUEST);
    }

    /* An address inside a range but not its base. Accepting this would free
     * a range the caller did not name. Only meaningful for a range longer
     * than one page, so a 2-page range is found first. */
    int midtested = 0;
    for (int i = 0; i < held; i++) {
        if (sizes[i] >= 2) {
            ok &= check(S, "freeing an address in the middle of a range is"
                        " refused",
                        vmm_kmap_free_virtual(bases[i] + VMM_PAGE_SIZE,
                                              sizes[i] - 1) ==
                        VMM_ERR_NO_SUCH_RANGE);
            midtested = 1;
            break;
        }
    }
    ok &= check(S, "a multi-page range existed to test a mid-range free",
                midtested);

    /* Every refusal above must have left the bookkeeping untouched. */
    VmmKmapStats st2;
    vmm_kmap_stats(&st2);
    ok &= check_v(S, "no refused free changed the live range count",
                  st2.live_ranges == st1.live_ranges, st2.live_ranges);
    ok &= check_v(S, "no refused free changed the free range count",
                  st2.free_ranges == st1.free_ranges, st2.free_ranges);

    /* ---- a range that is still mapped cannot be returned ---- */

    uint64_t frame = pmm_alloc_page();
    ok &= check_v(S, "test frame allocated", frame != 0, frame);
    if (frame && held > 0) {
        ok &= check(S, "a page can be mapped inside a reserved range",
                    vmm_map_page(bases[0], frame, VMM_KERNEL_RW_NX) == VMM_OK);
        ok &= check(S, "returning a range with a live mapping inside it is"
                    " refused",
                    vmm_kmap_free_virtual(bases[0], sizes[0]) ==
                    VMM_ERR_ALREADY_MAPPED);
        uint64_t seen = 0;
        ok &= check_v(S, "the mapping survived the refused free",
                      vmm_translate(bases[0], &seen) == VMM_OK &&
                      seen == frame, seen);
        ok &= check(S, "unmapping it makes the range returnable",
                    vmm_unmap_page(bases[0]) == VMM_OK &&
                    vmm_kmap_free_virtual(bases[0], sizes[0]) == VMM_OK);
        pmm_free_page(frame);
    }

    /* ---- free, reuse, double free ---- */

    if (held > 0) {
        ok &= check(S, "freeing the same range twice is refused",
                    vmm_kmap_free_virtual(bases[0], sizes[0]) ==
                    VMM_ERR_ALREADY_FREE);

        uint64_t reuses_before;
        vmm_kmap_stats(&st2);
        reuses_before = st2.reuses;

        /* Same size as the range just freed, so it must come back rather
         * than move the cursor. Both facts are checked: the base matches AND
         * the cursor did not move. Either alone could be an accident. */
        uint64_t again = vmm_kmap_reserve_virtual(sizes[0]);
        VmmKmapStats st3;
        vmm_kmap_stats(&st3);

        ok &= check_v(S, "a freed range is handed back out again",
                      again == bases[0], again);
        ok &= check_v(S, "the reuse did not move the cursor",
                      st3.cursor == st2.cursor, st3.cursor);
        ok &= check_v(S, "the reuse was counted as a reuse",
                      st3.reuses == reuses_before + 1, st3.reuses);
        ok &= check(S, "the reissued range is still page aligned",
                    (again & (VMM_PAGE_SIZE - 1)) == 0);

        /* A request the free list cannot satisfy exactly must not be given
         * a free range of the wrong size - it must take fresh space. */
        uint64_t big = vmm_kmap_reserve_virtual(64);
        VmmKmapStats st4;
        vmm_kmap_stats(&st4);
        ok &= check_v(S, "a size the free list cannot match takes fresh"
                      " space instead", big != 0 && st4.cursor > st3.cursor,
                      big);
        int clash = 0;
        for (int i = 0; i < held; i++) {
            uint64_t ei = bases[i] + sizes[i] * VMM_PAGE_SIZE;
            if (big < ei && bases[i] < big + 64 * VMM_PAGE_SIZE) clash = 1;
        }
        ok &= check(S, "the fresh range overlaps nothing still held", !clash);
        if (big) ok &= check(S, "the fresh range can be returned",
                             vmm_kmap_free_virtual(big, 64) == VMM_OK);
    }

    /* ---- stress: reserve/free cycles must not consume the window ---- */

    /* The failure this catches is a free that reports success without
     * actually making the range reusable: the cursor would climb on every
     * iteration. After the first cycle warms the free list, the cursor must
     * be completely static. */
    uint64_t warm = vmm_kmap_reserve_virtual(4);
    ok &= check_v(S, "stress range reserved", warm != 0, warm);
    if (warm) {
        ok &= check(S, "stress range returned",
                    vmm_kmap_free_virtual(warm, 4) == VMM_OK);

        VmmKmapStats sa, sb;
        vmm_kmap_stats(&sa);
        int cycle_ok = 1, same_base = 1;
        for (int i = 0; i < 64; i++) {
            uint64_t b = vmm_kmap_reserve_virtual(4);
            if (b == 0) { cycle_ok = 0; break; }
            if (b != warm) same_base = 0;
            if (vmm_kmap_free_virtual(b, 4) != VMM_OK) { cycle_ok = 0; break; }
        }
        vmm_kmap_stats(&sb);

        ok &= check(S, "sixty-four reserve/free cycles all succeeded",
                    cycle_ok);
        ok &= check(S, "every cycle got the same range back", same_base);
        ok &= check_v(S, "the cursor did not move at all across the stress"
                      " loop", sb.cursor == sa.cursor, sb.cursor);
        ok &= check_v(S, "the range table did not grow across the stress"
                      " loop",
                      sb.live_ranges + sb.free_ranges ==
                      sa.live_ranges + sa.free_ranges,
                      sb.live_ranges + sb.free_ranges);
    }

    /* ---- give everything back ---- */

    int returned_ok = 1;
    for (int i = 0; i < held; i++) {
        VmmResult r = vmm_kmap_free_virtual(bases[i], sizes[i]);
        /* bases[0] was freed and reissued above, so it is live again and
         * must free cleanly; every other range is still live. */
        if (r != VMM_OK) returned_ok = 0;
    }
    ok &= check(S, "every range the test held was returned", returned_ok);

    VmmKmapStats stz;
    vmm_kmap_stats(&stz);
    ok &= check_v(S, "the live range count is back where it started",
                  stz.live_ranges == st0.live_ranges, stz.live_ranges);
    ok &= check_v(S, "the record table never overflowed",
                  stz.live_ranges + stz.free_ranges <= stz.max_ranges,
                  stz.live_ranges + stz.free_ranges);

    /* The AP stacks are the other consumer of this window and must be
     * entirely unaffected by everything above. */
    int stacks_ok = 1;
    for (uint32_t i = 0; i < smp->cpu_count; i++) {
        if (smp->cpus[i].state != CPU_STATE_ONLINE) continue;
        const PerCpu *pc = percpu_get(smp->cpus[i].percpu_index);
        if (pc == 0 || pc->kernel_stack_top == 0) { stacks_ok = 0; continue; }
        uint64_t phys = 0;
        if (vmm_translate(pc->kernel_stack_top - 8, &phys) != VMM_OK) {
            stacks_ok = 0;
        }
    }
    ok &= check(S, "every online AP's kernel stack still translates",
                stacks_ok);

    serial_puts("[test] K01-KMAP: by design - free ranges are neither split"
                " nor coalesced, so reuse needs an exact page-count match."
                " With one stack range per CPU and a 512 GiB window that"
                " cost is unreachable, and a merge path nothing exercises"
                " would be a liability rather than a feature.\n");
    serial_puts("[test] K01-KMAP: NOT PROVEN HERE - exhaustion of the record"
                " table or of the window itself. Both fail by returning 0,"
                " and reaching either would take dozens of held ranges or"
                " 512 GiB of reservations; every interesting refusal is"
                " reachable without them.\n");

    return ok;
}

/* ------------------------------------------------------------------ *
 * Driver
 * ------------------------------------------------------------------ */

void kernel01_run_tests(const SmpInfo *smp, Kernel01Results *out)
{
    g_checks = 0;
    g_failed = 0;

    serial_puts("[test] ===== KERNEL-01 self-tests (phase 1: per-CPU TSS"
                " + IST; phase 2: interrupt dispatch) =====\n");

    out->tss_ist = test_tss_ist(smp);
    out->irq     = test_irq(smp);
    out->ipi     = test_ipi(smp);
    out->tlb     = test_tlb(smp);
    out->reclaim = test_reclaim(smp);
    out->kmap    = test_kmap(smp);

    out->checks_run = g_checks;
    out->checks_failed = g_failed;

    serial_puts("[test] ===== ");
    serial_put_dec64(g_checks - g_failed);
    serial_puts("/");
    serial_put_dec64(g_checks);
    serial_puts(" KERNEL-01 checks passed =====\n\n");
}

void kernel01_print_summary(const Kernel01Results *r)
{
    serial_puts("VEX OS KERNEL-01\n");
    serial_puts("TSS/IST: ");
    serial_puts(r->tss_ist ? "PASS\n" : "FAIL\n");
    serial_puts("IRQ: ");
    serial_puts(r->irq ? "PASS\n" : "FAIL\n");
    serial_puts("IPI: ");
    serial_puts(r->ipi ? "PASS\n" : "FAIL\n");
    serial_puts("TLB: ");
    serial_puts(r->tlb ? "PASS\n" : "FAIL\n");
    serial_puts("RECLAIM: ");
    serial_puts(r->reclaim ? "PASS\n" : "FAIL\n");
    serial_puts("KMAP: ");
    serial_puts(r->kmap ? "PASS\n" : "FAIL\n");

    if (kernel01_all_passed(r)) {
        serial_puts("KERNEL-01 PHASE 7 COMPLETE\n");
    } else {
        serial_puts("KERNEL-01: FAILED - ");
        serial_put_dec64(r->checks_failed);
        serial_puts(" of ");
        serial_put_dec64(r->checks_run);
        serial_puts(" checks failed.\n");
    }
    serial_puts("\n");
}

int kernel01_all_passed(const Kernel01Results *r)
{
    return r->tss_ist && r->irq && r->ipi && r->tlb && r->reclaim && r->kmap &&
           r->checks_failed == 0;
}
