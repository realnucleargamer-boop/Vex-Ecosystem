/*
 * Vex OS - kernel/include/kstack.h
 *
 * BOOT-03 guarded kernel stacks.
 *
 * A kernel stack is allocated as N physical frames mapped into the kmap
 * window, with ONE UNMAPPED GUARD PAGE immediately below the lowest
 * mapped page. A stack overflow therefore hits a page fault at a known
 * address instead of silently overwriting whatever the allocator handed
 * out just below it.
 *
 * This matters more on this project than it might elsewhere: BOOT-02C's
 * AP stacks come straight from the physical allocator with nothing
 * between them, so an AP overrunning its 16 KiB would quietly corrupt
 * another CPU's stack and the symptom would appear on the wrong CPU.
 *
 * DELIBERATELY NOT APPLIED TO AP STARTUP STACKS IN BOOT-03.
 *   The AP trampoline loads RSP in 32-bit protected mode from the
 *   trampoline data block before paging is active on that AP, so an AP's
 *   initial stack must be a low physical address. Changing that is a
 *   change to the working BOOT-02C startup path with a real chance of
 *   breaking SMP, for a benefit BOOT-03 does not require. Guarded stacks
 *   are established, proven, and used by the kernel's own execution
 *   contexts; migrating AP startup stacks onto them is recorded as
 *   future work.
 */

#ifndef VEXOS_KSTACK_H
#define VEXOS_KSTACK_H

#include <stdint.h>

/* 16 KiB, matching the AP stack size BOOT-02C already uses, so there is
 * one kernel stack size in the project rather than two. */
#define KSTACK_PAGES 4
#define KSTACK_SIZE  (KSTACK_PAGES * 4096ULL)

typedef struct {
    uint64_t base;        /* lowest mapped virtual address */
    uint64_t top;         /* one past the highest mapped byte = initial RSP */
    uint64_t guard;       /* the unmapped guard page's virtual address */
    uint64_t pages;
} KernelStack;

/* Allocates KSTACK_PAGES frames, maps them into the kmap window above a
 * guard page, and fills `out`. Returns 1 on success. On failure it
 * releases whatever it had already taken - a partially built stack must
 * not leak frames or leave half a mapping behind.
 *
 * The returned `top` is 16-byte aligned, which the x86-64 System V ABI
 * requires at a function's entry boundary. */
int kstack_alloc(KernelStack *out);

/* Confirms the guard page really is unmapped and every stack page really
 * is mapped and writable. Returns 1 if the stack is sound. This is the
 * evidence that the guard exists, as distinct from the code having
 * intended to leave a gap. */
int kstack_verify(const KernelStack *s);

/* Number of kernel stacks allocated so far, for diagnostics. */
uint64_t kstack_count(void);

#endif /* VEXOS_KSTACK_H */
