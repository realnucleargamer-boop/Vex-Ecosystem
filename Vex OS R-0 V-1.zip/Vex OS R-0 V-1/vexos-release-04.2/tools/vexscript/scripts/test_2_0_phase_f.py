#!/usr/bin/env python3
"""VexScript 2.0 Phase F — multi-file native + strings"""
import sys, subprocess
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vexscript.native import run_native, compile_project, emit_asm
from vexscript.compile_ir import run_via_ir
from vexscript.project import load_project
from vexscript.errors import VexError

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

print("VexScript 2.0 Phase F Tests")

print("\n=== Strings native ===")
c, o = run_native('fn main() -> i32 { println("VEX OS ONLINE"); return 0; }\n')
check("string println", c == 0 and o == "VEX OS ONLINE\n", repr(o))

print("\n=== Differential ===")
src = 'fn main() -> i32 { println(20 + 22); return 0; }\n'
ir_c, ir_o = run_via_ir(src)
na_c, na_o = run_native(src)
check("diff arith", ir_c == na_c and ir_o == na_o, f"{ir_o!r} vs {na_o!r}")

print("\n=== Multi-file project native ===")
mf = ROOT / "examples/v2/native_multifile"
cfg = load_project(mf)
paths = [str(cfg.entry.parent), str(cfg.root / "src")]
c, o = run_native(cfg.entry.read_text(), str(cfg.entry), module_paths=paths)
check("multifile add", c == 0 and o == "42\n", repr(o))

print("\n=== Examples ===")
for name, expect in [
    ("native_hello", "VEX OS ONLINE\n"),
    ("native_multifile", "42\n"),
]:
    proj = ROOT / "examples/v2" / name
    cfg = load_project(proj)
    paths = [str(cfg.entry.parent), str(cfg.root / "src")]
    c, o = run_native(cfg.entry.read_text(), str(cfg.entry), module_paths=paths)
    check(name, c == 0 and o == expect, repr(o))

cfg = load_project(ROOT / "examples/v2/native_strings")
paths = [str(cfg.entry.parent), str(cfg.root / "src")]
c, o = run_native(cfg.entry.read_text(), str(cfg.entry), module_paths=paths)
check("native_strings", c == 0 and "VEX OS ONLINE" in o and "hello from module" in o, repr(o))

print("\n=== compile_project objects ===")
cfg = load_project(mf)
try:
    from vexscript.native import compile_native
    paths = [str(cfg.entry.parent), str(cfg.root / "src")]
    import tempfile
    td = Path(tempfile.mkdtemp())
    binp = compile_native(
        cfg.entry.read_text(), str(cfg.entry),
        out_path=td / "app", module_paths=paths, build_dir=td, multi_object=True,
    )
    r = subprocess.run([str(binp)], capture_output=True, text=True)
    check("project link+run", r.returncode == 0 and r.stdout == "42\n", r.stdout)
    has_o = any(td.glob("*.o")) or (td / "project.s").exists()
    check("build artifacts", has_o, list(td.iterdir()))
except Exception as e:
    check("project link+run", False, str(e))
    check("build artifacts", False, str(e))

print(f"\n=== Phase F Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
