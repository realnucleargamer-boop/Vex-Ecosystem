/*
 * Vex OS - kernel/include/accounts.h : local account store (DESKTOP-01).
 *
 * WHAT THIS IS: an identity list + a "selected account". Display name and unique id are separate: the
 * id is the lower-cased name and is what uniqueness is judged on ("Bob" and "bob" collide).
 * WHAT THIS IS NOT: authentication. There are no passwords, no PINs, no permissions and no per-account
 * isolation anywhere in the kernel; selecting an account grants nothing and protects nothing.
 *
 * STORAGE: VEX OS has no block driver and no filesystem, and this milestone must not invent one. The only
 * backend is therefore RAM and it is labelled TEMPORARY: accounts do NOT survive a reboot. The backend is
 * an interface (AcctBackend) so a persistent one can be added later without touching callers.
 *
 * LIMITS: ACCT_MAX accounts; names 3..32 chars after trimming; allowed A-Z a-z 0-9 space _ . - ; first
 * character alphanumeric; no leading/trailing/double spaces (rejected, not silently rewritten).
 */
#ifndef VEXOS_ACCOUNTS_H
#define VEXOS_ACCOUNTS_H
#include <stdint.h>
#define ACCT_MAX 16
#define ACCT_NAME_MIN 3
#define ACCT_NAME_MAX 32
#define ACCT_PW_MIN 6
#define ACCT_PW_MAX 64
#define ACCT_KDF_ITERS 4096u            /* PBKDF2-HMAC-SHA256 iterations (stored per account, so it can be raised later) */
enum { ACCT_ROLE_STANDARD = 0, ACCT_ROLE_ADMIN = 1 };
/* Passwords are NEVER stored: only a per-account random salt and the PBKDF2-HMAC-SHA256 derived key. */
typedef struct { char display[ACCT_NAME_MAX + 1]; char id[ACCT_NAME_MAX + 1]; uint32_t uid;
                 uint8_t role, has_pw; uint32_t iters; uint8_t salt[16]; uint8_t hash[32]; } Account;
typedef enum { ACCT_OK = 0, ACCT_ERR_EMPTY, ACCT_ERR_SHORT, ACCT_ERR_LONG, ACCT_ERR_CHAR, ACCT_ERR_SPACE, ACCT_ERR_DUP, ACCT_ERR_FULL, ACCT_ERR_STORE, ACCT_ERR_DENIED, ACCT_ERR_PWSHORT, ACCT_ERR_PWLONG, ACCT_ERR_PWCHAR } AcctResult;
typedef struct {
    const char *label;       /* shown to the user, e.g. "RAM (temporary)" */
    int persistent;          /* 1 only if a reboot-and-reload test has proven it */
    int (*store)(const Account *all, int n);   /* 0 = success */
} AcctBackend;

void        acct_init(void);                       /* empty store, RAM backend, nothing selected */
AcctResult  acct_validate(const char *name);       /* pure check, no mutation */
AcctResult  acct_create(const char *name);         /* validate + add + store + verify; selects nothing */
const char *acct_result_msg(AcctResult r);
/* Password-protected creation. caller = index of the authenticated account performing the action, or -1 ONLY
 * for first-run setup when no account exists yet (the first account becomes the administrator). Any later
 * creation by a non-administrator (or by -1) is refused with ACCT_ERR_DENIED: enforced here, not in the UI. */
AcctResult  acct_create_pw(const char *name, const char *password, int caller);
AcctResult  acct_validate_password(const char *pw);
int         acct_has_password(int i);
int         acct_role(int i);
int         acct_verify(int i, const char *pw);    /* 1 = accepted. Passwordless account accepts only "" */
int         acct_login(int i, const char *pw);     /* verify + set the active identity */
void        acct_logout(void);                      /* clears the active identity */
int         acct_active(void);                      /* authenticated account index or -1 */
void        acct_test_set_iters(uint32_t n);
#ifdef VEX_DEV_SEED_ACCOUNTS
AcctResult  acct_dev_create_pw(const char *name, const char *pw, int role);   /* DEV BUILD ONLY: bypasses the admin check */
#endif        /* tests only: cheaper KDF so boot-time tests stay fast */
int         acct_count(void);
const Account *acct_get(int i);
int         acct_find(const char *name);           /* index by id (case-insensitive) or -1 */
int         acct_selected(void);                   /* index or -1 */
int         acct_select(int i);                    /* 1 ok, 0 bad index */
const AcctBackend *acct_backend(void);
void        acct_test_fail_next_store(int fail);   /* failure-injection hook for tests only */
#endif
