/*
 * Vex OS - kernel/src/arch/x86_64/time/timer.c
 *
 * BOOT-03 LAPIC timer. See kernel/include/timer.h for scope and for why
 * this is the LAPIC timer rather than the PIT.
 *
 * Register numbers below are from the Intel SDM Volume 3A, Chapter 11
 * ("Advanced Programmable Interrupt Controller"), Table 11-1 "Local APIC
 * Register Address Map" and Figure 11-8 "Divide Configuration Register".
 */

#include "timer.h"
#include "irq.h"
#include "lapic.h"
#include "pit_delay.h"
#include "percpu.h"
#include "serial.h"
#include "boot03_inject.h"

/* LAPIC timer registers (offsets from the LAPIC MMIO base). */
#define LAPIC_LVT_TIMER      0x320
#define LAPIC_TIMER_INITIAL  0x380
#define LAPIC_TIMER_CURRENT  0x390
#define LAPIC_TIMER_DIVIDE   0x3E0

/* LVT Timer bits. */
#define LVT_MASKED           (1u << 16)
#define LVT_MODE_ONESHOT     (0u << 17)
#define LVT_MODE_PERIODIC    (1u << 17)

/* Divide Configuration Register encoding. Note the awkward layout: the
 * three significant bits are 0, 1 and 3 - bit 2 is reserved. 0b0011 is
 * divide-by-16. Getting this wrong yields a timer that is off by a
 * power of two and still "works", which is why the value is written as
 * a named constant with its meaning attached rather than a bare 3. */
#define DIVIDE_BY_16         0x3u

/* Calibration window. 10 ms against the PIT is long enough that the
 * PIT's own granularity (~0.84 us) is noise, and short enough not to
 * add meaningfully to boot time. */
#define CALIBRATION_US       10000ULL

static TimerInfo g_timer;
static volatile uint64_t g_ticks;

uint64_t timer_ticks(void)
{
    return __atomic_load_n(&g_ticks, __ATOMIC_ACQUIRE);
}

const TimerInfo *timer_info(void) { return &g_timer; }

void timer_on_interrupt(void)
{
    __atomic_add_fetch(&g_ticks, 1, __ATOMIC_ACQ_REL);

    /* Per-CPU tick count, if CPU-local storage is up on this CPU. The
     * checked accessor matters here: a timer interrupt arriving before
     * percpu_init on this CPU must not dereference a GS base of zero. */
    PerCpu *p = percpu_this_or_null();
    if (p != 0) {
        p->ticks++;   /* per-CPU, no other writer, so no atomic needed */
    }

    /* EOI last. Doing it first would allow a re-entrant timer interrupt
     * before the counters are consistent. */
#if VEX_INJECTED(2)
    /* NEGATIVE CONTROL: skip the EOI. The LAPIC keeps the in-service bit
     * set, no further timer interrupt is ever delivered, and the TIMER
     * test must catch it. See kernel/include/boot03_inject.h. */
    (void)0;
#else
    lapic_send_eoi(g_timer.lapic_base);
#endif
}

/* KERNEL-01 Phase 2: adapter between the generic handler signature and
 * timer_on_interrupt(), which takes no arguments because the tick path
 * has no use for the interrupt frame.
 *
 * Keeping timer_on_interrupt() frame-free is deliberate: it is called
 * directly by the BOOT-03 timer tests, and giving it a frame parameter
 * would force those tests to fabricate one. */
static void (*g_tick_hook)(void *frame);
void timer_set_tick_hook(void (*fn)(void *frame)) { g_tick_hook = fn; }

static void timer_irq_handler(InterruptFrame *frame)
{
    timer_on_interrupt();                       /* includes the EOI (last) */
    if (g_tick_hook) g_tick_hook(frame);        /* PROC-01 watchdog; after the EOI so the frame may be abandoned */
}

int timer_init(uint64_t lapic_base)
{
    g_timer.initialized = 0;
    g_timer.calibrated = 0;
    g_timer.lapic_base = lapic_base;
    g_timer.divide = DIVIDE_BY_16;
    g_timer.counts_per_second = 0;
    g_timer.initial_count = 0;
    g_timer.measured_hz = 0;

    if (lapic_base == 0) {
        serial_puts("[kernel] TIMER: FAILED - no LAPIC base\n");
        return 0;
    }

    lapic_reg_write(lapic_base, LAPIC_TIMER_DIVIDE, DIVIDE_BY_16);

    /* Calibrate with the timer MASKED and in one-shot mode: the count
     * still decrements, but no interrupt can be delivered while the IDT
     * entry's behaviour is being established. */
    lapic_reg_write(lapic_base, LAPIC_LVT_TIMER,
                    LVT_MASKED | LVT_MODE_ONESHOT | TIMER_VECTOR);

    /* Start from the maximum so the window cannot underflow to zero for
     * any plausible input frequency: at 0xFFFFFFFF counts and
     * divide-by-16, even a 1 GHz bus needs ~68 s to expire. */
    lapic_reg_write(lapic_base, LAPIC_TIMER_INITIAL, 0xFFFFFFFFu);

    pit_delay_us(CALIBRATION_US);

    uint32_t remaining = lapic_reg_read(lapic_base, LAPIC_TIMER_CURRENT);

    /* Stop the counter before doing arithmetic on the reading. */
    lapic_reg_write(lapic_base, LAPIC_TIMER_INITIAL, 0);

    if (remaining == 0 || remaining == 0xFFFFFFFFu) {
        /* remaining == 0xFFFFFFFF means the counter never moved (dead
         * timer, or a PIT delay that returned instantly);
         * remaining == 0 means it expired entirely, so the elapsed count
         * is a lower bound, not a measurement. Either way the number is
         * not a calibration and must not be dressed up as one. */
        serial_puts("[kernel] TIMER: FAILED - calibration reading implausible"
                    " (current count = ");
        serial_put_hex64(remaining);
        serial_puts(")\n");
        return 0;
    }

    uint64_t elapsed = 0xFFFFFFFFull - (uint64_t)remaining;

    /* elapsed counts happened in CALIBRATION_US microseconds. */
    uint64_t counts_per_second = (elapsed * 1000000ULL) / CALIBRATION_US;
    g_timer.counts_per_second = counts_per_second;

    uint32_t initial = (uint32_t)(counts_per_second / TIMER_TARGET_HZ);
    if (initial == 0) {
        serial_puts("[kernel] TIMER: FAILED - calibrated rate too low for "
                    "the target tick rate\n");
        return 0;
    }

    g_timer.initial_count = initial;
    g_timer.measured_hz = counts_per_second / initial;
    g_timer.calibrated = 1;

    /* KERNEL-01 Phase 2: claim the timer vector in the interrupt-handler
     * table BEFORE the LVT is unmasked below.
     *
     * This ordering is the whole reason the registration is here rather
     * than in kernel_entry: unmasking the LVT is what makes delivery
     * possible, and a vector that can be delivered before its handler is
     * installed would land on the dispatcher's unregistered path -
     * counted and EOI'd, but the tick would be lost, and the timer test
     * would fail intermittently for a reason that looks like a dead
     * LAPIC.
     *
     * A failure here is a hard init failure, not a warning: if the vector
     * is already owned by something else, unmasking the timer would
     * deliver timer interrupts to a foreign handler. */
    IrqResult ir = irq_register(TIMER_VECTOR, timer_irq_handler,
                                "lapic-timer");
    if (ir != IRQ_OK) {
        serial_puts("[kernel] TIMER: FAILED - cannot register vector ");
        serial_put_hex64(TIMER_VECTOR);
        serial_puts(" (");
        serial_puts(irq_result_name(ir));
        serial_puts(")\n");
        return 0;
    }

    /* Program periodic mode, unmasked. Order matters: the initial count
     * is written AFTER the LVT is configured, because writing the
     * initial count is what starts the countdown. */
    lapic_reg_write(lapic_base, LAPIC_LVT_TIMER,
                    LVT_MODE_PERIODIC | TIMER_VECTOR);
    lapic_reg_write(lapic_base, LAPIC_TIMER_INITIAL, initial);

    g_timer.initialized = 1;

    serial_puts("[kernel] TIMER: LAPIC timer calibrated - ");
    serial_put_dec64(counts_per_second);
    serial_puts(" counts/s (divide-by-16), initial count ");
    serial_put_dec64(initial);
    serial_puts(", target ");
    serial_put_dec64(TIMER_TARGET_HZ);
    serial_puts(" Hz, actual ");
    serial_put_dec64(g_timer.measured_hz);
    serial_puts(" Hz, vector ");
    serial_put_hex64(TIMER_VECTOR);
    serial_puts("\n");

    /* The calibration figure is measured against the PIT inside QEMU
     * TCG, where neither device runs at a physically meaningful rate.
     * It is reported so that a wildly wrong value is visible, not as a
     * claim about wall-clock accuracy. */
    return 1;
}

void timer_stop(void)
{
    if (g_timer.lapic_base == 0) return;
    lapic_reg_write(g_timer.lapic_base, LAPIC_LVT_TIMER,
                    LVT_MASKED | LVT_MODE_PERIODIC | TIMER_VECTOR);
    lapic_reg_write(g_timer.lapic_base, LAPIC_TIMER_INITIAL, 0);
}

int timer_wait_ticks(uint64_t n)
{
    uint64_t start = timer_ticks();
    uint64_t target = start + n;

    /* Bounded wait. An unbounded wait here would turn "the timer never
     * fired" - the exact failure this is testing for - into a silent hang,
     * which is the least useful possible way to fail.
     *
     * The bound is measured with the PIT, not with an iteration count.
     * The first version of this used a 2-billion-iteration `pause` loop,
     * which was effectively unbounded under QEMU TCG: fault injection 2
     * (timer_on_interrupt omits the EOI) hung the boot instead of
     * reporting TIMER: FAIL, and the negative control caught it. An
     * iteration count is not a time bound.
     *
     * The PIT is the right instrument here: it is polled, it is
     * independent of the LAPIC being tested, and it is already the
     * reference used to calibrate the LAPIC timer. Budget is 5x the
     * expected wait plus a fixed floor, so a merely slow timer is still
     * distinguishable from a dead one. */
    uint64_t budget_ms = (n * 1000u) / TIMER_TARGET_HZ * 5u + 200u;

    for (uint64_t ms = 0; ms < budget_ms; ms++) {
        if (timer_ticks() >= target) return 1;
        pit_delay_us(1000);
    }
    return 0;
}
