# Vex OS - build.ps1
#
# Windows-native build of the current milestone (BOOT-02B) using clang/lld
# + NASM.
#
# Tools are located automatically - see scripts\VexToolchain.ps1. You do NOT
# need to add NASM or LLVM to PATH, in this terminal or any other. Resolved
# directories are prepended to this process's PATH only; your persistent
# environment is never modified.
#
# Pipeline (mirrors the Linux Makefiles, verified equivalent by
# actually boot-testing a clang/lld-built image before this script
# was written - see docs/WINDOWS-BUILD.md):
#
#   bootloader/src/main_win.c  --clang(x86_64-unknown-windows)-->  .obj
#                               --lld-link(/subsystem:efi_application)--> build\BOOTX64.EFI
#
#   kernel/src/**/*.c          --clang(x86_64-unknown-elf)-->       .o
#   kernel/src/**/*.asm        --nasm(-f elf64)-->                  .o
#                               --ld.lld(-T kernel\linker.ld)-->     kernel.elf
#                               --llvm-objcopy(-O binary)-->         build\KERNEL.ELF
#
#   build\BOOTX64.EFI + build\KERNEL.ELF --diskpart/format--> build\vexos.img (VHD)
#
# Does NOT touch bootloader/src/main.c (the Linux/gnu-efi build) or
# the existing Makefiles - Linux/WSL build path is untouched.
#
# Requires an ELEVATED (Administrator) PowerShell session, because
# diskpart's vdisk create/attach and drive-letter assignment require
# admin rights. The script checks and fails clearly if not elevated.

#Requires -Version 5.1

[CmdletBinding()]
param(
    # Ignore build\toolchain.local.json and re-discover every tool. Use after
    # installing, upgrading, or moving LLVM/NASM.
    [switch]$RefreshTools,

    # DESKTOP-01 test aids (both OFF by default; the shipped configuration is a plain .\build.ps1):
    #   -FastBoot          compiles with GRAPHICS2_VISUAL_DEMO=0 (no 5 s pause after each boot stage)
    #   -DevSeedAccounts   pre-creates three TEST accounts (Vex, Nexus, Bob) so the multi-account Users
    #                      panel can be exercised. It is a development aid, never a product default.
    [switch]$FastBoot,
    [switch]$DevSeedAccounts
)

$ErrorActionPreference = "Stop"

$RepoRoot   = Split-Path -Parent $PSCommandPath
$BuildDir   = Join-Path $RepoRoot "build"
$KernelObjDir = Join-Path $BuildDir "kernel-obj"
$VhdPath    = Join-Path $BuildDir "vexos.vhd"   # diskpart requires a .vhd/.vhdx extension
$ImgPath    = Join-Path $BuildDir "vexos.img"   # final artifact name, per the agreed pipeline
$ImgSizeMB = 14   # RELEASE BUDGET: final artifact (VHD incl. 512 B footer) must be < 15 MiB = 15728640 bytes

function Write-Step($msg) { Write-Host "==> $msg" -ForegroundColor Cyan }
function Write-Fail($msg) { Write-Host "ERROR: $msg" -ForegroundColor Red; exit 1 }

# ------------------------------------------------------------------
# Elevation check
# ------------------------------------------------------------------
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal(
    [Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Fail "This script must run in an elevated (Administrator) PowerShell session.`n  diskpart's VHD create/attach and drive-letter assignment require it.`n  Right-click PowerShell -> 'Run as Administrator', then re-run build.ps1."
}

# ------------------------------------------------------------------
# Tool discovery
#
# Replaces the previous "Get-Command or die" approach, which failed on a
# perfectly good NASM install purely because NASM's installer does not put
# itself on PATH (upstream bug 3392224). Discovery now covers env overrides,
# a validated per-machine cache, PATH, standard install directories,
# registry uninstall entries, and finally a bounded filesystem probe.
# ------------------------------------------------------------------
. (Join-Path $RepoRoot "scripts\VexToolchain.ps1")
. (Join-Path $RepoRoot "scripts\VexDisk.ps1")

New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null
New-Item -ItemType Directory -Force -Path $KernelObjDir | Out-Null

Write-Step "Locating build tools"
try {
    # QEMU is deliberately NOT required here - building an image should not
    # depend on having a way to run it. run-qemu.ps1 resolves QEMU itself.
    $tc = Resolve-VexToolchain -RepoRoot $RepoRoot -Require @("llvm","nasm") -Refresh:$RefreshTools
} catch {
    Write-Fail $_.Exception.Message
}

$Clang   = $tc["clang"]
$LldLink = $tc["lld-link"]
$LldElf  = $tc["ld.lld"]
$ObjCopy = $tc["llvm-objcopy"]
$Nasm    = $tc["nasm"]

# ------------------------------------------------------------------
# Bootloader (clang -> x86_64-unknown-windows -> lld-link EFI subsystem)
# ------------------------------------------------------------------
Write-Step "Building bootloader (build\BOOTX64.EFI)"

$BootloaderSrc = Join-Path $RepoRoot "bootloader\src\main_win.c"
$BootloaderInc = Join-Path $RepoRoot "bootloader\include"
$CommonInc     = Join-Path $RepoRoot "common\include"
$BootObj       = Join-Path $BuildDir "main_win.obj"
$BootEfi       = Join-Path $BuildDir "BOOTX64.EFI"

& $Clang --target=x86_64-unknown-windows -ffreestanding -fshort-wchar `
    -fno-stack-protector -mno-red-zone -Wall -Wextra `
    -I "$BootloaderInc" -I "$CommonInc" `
    -c "$BootloaderSrc" -o "$BootObj"
if ($LASTEXITCODE -ne 0) { Write-Fail "Bootloader compile failed." }

& $LldLink "$BootObj" /entry:efi_main /subsystem:efi_application /machine:x64 `
    /nodefaultlib /out:"$BootEfi"
if ($LASTEXITCODE -ne 0) { Write-Fail "Bootloader link failed." }

Write-Host "  Built $BootEfi"

# ------------------------------------------------------------------
# Kernel (clang -> x86_64-unknown-elf, nasm, ld.lld, llvm-objcopy)
# ------------------------------------------------------------------
Write-Step "Building kernel (build\KERNEL.ELF)"

$KernelInc  = Join-Path $RepoRoot "kernel\include"
$LinkerScript = Join-Path $RepoRoot "kernel\linker.ld"
$KernelElfOut = Join-Path $BuildDir "kernel.elf"
$KernelFlatOut = Join-Path $BuildDir "KERNEL.ELF"

# NOTE: object files are named by basename only (not full relative
# path), unlike kernel/Makefile which preserves directory structure.
# This works as long as every source file has a unique basename
# across the whole kernel tree - true today, but if a future file
# collides (e.g. two different idt.c), this will silently overwrite
# one .o with another. Flag for fixing if/when that happens rather
# than pre-solving it now.
$CSources = @(
    "kernel\src\core\kernel_entry.c",
    "kernel\src\core\serial.c",
    "kernel\src\core\panic.c",
    "kernel\src\arch\x86_64\gdt\gdt.c",
    "kernel\src\arch\x86_64\idt\idt.c",
    "kernel\src\memory\physical\pmm.c",
    "kernel\src\memory\memset.c",
    "kernel\src\arch\x86_64\cpu\ap_stack.c",
    "kernel\src\arch\x86_64\acpi\acpi.c",
    "kernel\src\arch\x86_64\apic\lapic.c",
    "kernel\src\arch\x86_64\apic\ipi.c",
    "kernel\src\arch\x86_64\time\pit_delay.c",
    "kernel\src\arch\x86_64\smp\smp.c",
    "kernel\src\memory\virtual\vmm.c",
    "kernel\src\memory\virtual\tlb.c",
    "kernel\src\memory\virtual\kstack.c",
    "kernel\src\arch\x86_64\cpu\percpu.c",
    "kernel\src\arch\x86_64\cpu\context.c",
    "kernel\src\arch\x86_64\time\timer.c",
    "kernel\src\core\boot03_tests.c",
    "kernel\src\core\kernel01_tests.c",
    "kernel\src\security\secure.c",
    "kernel\src\core\security01_tests.c",
    "kernel\src\input\keyboard.c",
    "kernel\src\input\ps2_keyboard.c",
    "kernel\src\userspace\services.c",
    "kernel\src\graphics\gfx_fb.c",
    "kernel\src\graphics\gfx_draw.c",
    "kernel\src\graphics\gfx_font8x16.c",
    "kernel\src\graphics\gfx_text.c",
    "kernel\src\graphics\gfx_screen.c",
    "kernel\src\graphics\runtime_ui.c",
    "kernel\src\core\boot_progress.c",
    "kernel\src\core\graphics2_tests.c",
    "kernel\src\graphics\gfx_progress.c",
    "kernel\src\arch\x86_64\cpu\ring3.c",
    "kernel\src\core\security02_tests.c",
    "kernel\src\input\ps2_mouse.c",
    "kernel\src\arch\x86_64\acpi\power.c",
    "kernel\src\arch\x86_64\time\rtc.c",
    "kernel\src\drivers\pci\netstatus.c",
    "kernel\src\drivers\pci\pci.c",
    "kernel\src\drivers\storage\ahci.c",
    "kernel\src\drivers\storage\vstore.c",
    "kernel\src\drivers\storage\storage.c",
    "kernel\src\ui\cursor.c",
    "kernel\src\ui\vexui.c",
    "kernel\src\ui\wallpaper_core.c",
    "kernel\src\ui\wallpaper.c",
    "kernel\src\ui\wallpaper_data.c",
    "kernel\src\core\input03_tests.c",
    "kernel\src\input\keymap.c",
    "kernel\src\security\crypto.c",
    "kernel\src\apps\vfs.c",
    "kernel\src\apps\vfs_cmds.c",
    "kernel\src\arch\x86_64\time\cpuacct.c",
    "kernel\src\arch\x86_64\time\tz.c",
    "kernel\src\ui\accounts.c",
    "kernel\src\apps\apps.c",
    "kernel\src\apps\vexterm_host.c",
    "kernel\src\apps\vex_rt_str_glue.c",
    "kernel\src\core\desktop01_tests.c",
    "kernel\src\ai\crystal_core.c",
    "kernel\src\ai\crystal_kernel.c",
    "kernel\src\proc\uproc_image.c",
    "kernel\src\proc\uproc.c",
    "kernel\src\proc\uproc_tests.c",
    "kernel\src\graphics\vec.c",
    "kernel\src\graphics\vecfont.c"
)
$AsmSources = @(
    "kernel\src\arch\x86_64\boot\start.asm",
    "kernel\src\arch\x86_64\gdt\gdt_flush.asm",
    "kernel\src\arch\x86_64\idt\isr_stubs.asm",
    "kernel\src\arch\x86_64\smp\ap_trampoline_blob.asm",
    "kernel\src\arch\x86_64\cpu\context_switch.asm",
    "kernel\src\security\probe.asm",
    "kernel\src\arch\x86_64\cpu\ring3_transition.asm",
    "kernel\src\arch\x86_64\cpu\ring3_programs.asm",
    "kernel\src\ai\crystal_model_blob.asm",
    "kernel\src\proc\uproc_programs.asm"
)

$objs = @()
$ExtraDefs = @()
if ($FastBoot)        { $ExtraDefs += "-DGRAPHICS2_VISUAL_DEMO=0" }
if ($DevSeedAccounts) { $ExtraDefs += "-DVEX_DEV_SEED_ACCOUNTS=1"; Write-Host "  NOTE: -DevSeedAccounts build: three TEST accounts are pre-created." -ForegroundColor Yellow }

foreach ($rel in $CSources) {
    $src = Join-Path $RepoRoot $rel
    $obj = Join-Path $KernelObjDir ((Split-Path $rel -Leaf) -replace '\.c$', '.o')
    & $Clang --target=x86_64-unknown-elf -ffreestanding -fno-stack-protector `
        -fno-stack-check -fno-pic -fno-pie -mno-red-zone -mcmodel=kernel `
        -mno-mmx -mno-sse -mno-sse2 -Wall -Wextra -std=gnu11 `
        $ExtraDefs -I "$KernelInc" -I "$CommonInc" `
        -c "$src" -o "$obj"
    if ($LASTEXITCODE -ne 0) { Write-Fail "Kernel compile failed: $rel" }
    $objs += $obj
}

# BOOT-02C: the AP trampoline is assembled as a STANDALONE FLAT BINARY
# (nasm -f bin, org 0) and then embedded into the kernel by
# ap_trampoline_blob.asm via `incbin`. It is deliberately not part of
# the kernel link - see kernel/src/arch/x86_64/smp/ap_trampoline.asm for
# why (it executes from a low physical page in real mode, so link-time
# addresses would be meaningless).
#
# This MUST be built before ap_trampoline_blob.asm is assembled, and the
# `incbin "build/ap_trampoline.bin"` path inside that file is resolved
# relative to the repository root, so nasm is given the repo root on its
# include path (-i) to match kernel/Makefile's behaviour.
Write-Step "Assembling AP trampoline flat binary (build\ap_trampoline.bin)"

$TrampolineSrc = Join-Path $RepoRoot "kernel\src\arch\x86_64\smp\ap_trampoline.asm"
$TrampolineBin = Join-Path $BuildDir "ap_trampoline.bin"

& $Nasm -f bin "$TrampolineSrc" -o "$TrampolineBin"
if ($LASTEXITCODE -ne 0) { Write-Fail "AP trampoline assembly failed." }

if (-not (Test-Path $TrampolineBin)) {
    Write-Fail "AP trampoline binary was not produced: $TrampolineBin"
}

# The trampoline must be exactly one 4 KiB page. The .asm file asserts
# this at assembly time too; checking here as well means a stale or
# truncated file on the Windows path is caught before it is embedded.
$trampSize = (Get-Item $TrampolineBin).Length
if ($trampSize -ne 4096) {
    Write-Fail "AP trampoline binary is $trampSize bytes, expected 4096."
}

# DESKTOP-01: the Vex Terminal is a VexScript application. Source of truth: apps\vex_terminal\src\*.vex,
# compiled by tools\vexscript (VexScript -> Vex IR -> x86-64 assembly) into the COMMITTED file
# kernel\src\apps\generated\vex_terminal.s. With Python available it is regenerated here; without it the
# committed file is verified against the .vex sources by SHA-256 so a STALE compile can never be linked.
Write-Step "VexScript application (Vex Terminal)"
$VexAppS = Join-Path $RepoRoot "kernel\src\apps\generated\vex_terminal.s"
$py = $null
foreach ($cand in @("python","py")) { $c = Get-Command $cand -ErrorAction SilentlyContinue; if ($c -and $c.Source -notmatch "WindowsApps") { $py = $c.Source; break } }
if ($py) {
    & $py (Join-Path $RepoRoot "scripts\build_vexapp.py")
    if ($LASTEXITCODE -ne 0) { Write-Fail "VexScript compile failed (scripts\build_vexapp.py)." }
    & $py (Join-Path $RepoRoot "scripts\build_vexapp.py") --check
    if ($LASTEXITCODE -ne 0) { Write-Fail "Generated vex_terminal.s is stale after regeneration." }
} else {
    Write-Host "  Python not found: verifying the committed vex_terminal.s against the VexScript sources (SHA-256)." -ForegroundColor Yellow
    $files = @(Get-ChildItem -Path (Join-Path $RepoRoot "apps\vex_terminal\src") -Recurse -Filter *.vex | ForEach-Object { $_.FullName })
    $files += (Join-Path $RepoRoot "apps\vex_terminal\vex.toml")
    foreach ($t in @("typecheck.py","ir\emitter.py","ir\x86_64.py")) { $files += (Join-Path $RepoRoot ("tools\vexscript\src\vexscript\" + $t)) }
    $rootFull = (Resolve-Path $RepoRoot).Path.TrimEnd('\') + '\'
    $map = @{}
    foreach ($f in $files) { $map[($f.Substring($rootFull.Length) -replace '\\','/')] = $f }
    [string[]]$rels = @($map.Keys)
    [Array]::Sort($rels, [System.StringComparer]::Ordinal)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    foreach ($rel in $rels) {
        $nb = [Text.Encoding]::UTF8.GetBytes($rel); [void]$sha.TransformBlock($nb, 0, $nb.Length, $null, 0)
        $txt = [Text.Encoding]::GetEncoding(28591).GetString([IO.File]::ReadAllBytes($map[$rel])).Replace("`r`n", "`n")
        $cb = [Text.Encoding]::GetEncoding(28591).GetBytes($txt); [void]$sha.TransformBlock($cb, 0, $cb.Length, $null, 0)
    }
    [void]$sha.TransformFinalBlock(@(), 0, 0)
    $want = ($sha.Hash | ForEach-Object { $_.ToString("x2") }) -join ""
    $have = (Get-Content -LiteralPath $VexAppS -TotalCount 1)
    if ($have -ne "# VEXAPP-INPUT-SHA256: $want") {
        Write-Fail "vex_terminal.s does not match the VexScript sources (expected hash $want). Install Python 3 and re-run, or run: python scripts\build_vexapp.py"
    }
    Write-Host "  vex_terminal.s matches the sources ($($want.Substring(0,12)))."
}
$vexObj = Join-Path $KernelObjDir "vex_terminal.o"
& $Clang --target=x86_64-unknown-elf -c -x assembler "$VexAppS" -o "$vexObj"
if ($LASTEXITCODE -ne 0) { Write-Fail "Assembling the generated VexScript output failed." }
$objs += $vexObj

foreach ($rel in $AsmSources) {
    $src = Join-Path $RepoRoot $rel
    $obj = Join-Path $KernelObjDir ((Split-Path $rel -Leaf) -replace '\.asm$', '.o')
    # -i <repo root> so `incbin "build/ap_trampoline.bin"` resolves the
    # same way it does under kernel/Makefile.
    & $Nasm -f elf64 -i "$RepoRoot" "$src" -o "$obj"
    if ($LASTEXITCODE -ne 0) { Write-Fail "NASM assembly failed: $rel" }
    $objs += $obj
}

& $LldElf -nostdlib -no-pie -T "$LinkerScript" $objs -o "$KernelElfOut"
if ($LASTEXITCODE -ne 0) { Write-Fail "Kernel link failed." }

& $ObjCopy -O binary "$KernelElfOut" "$KernelFlatOut"
if ($LASTEXITCODE -ne 0) { Write-Fail "Kernel objcopy to flat binary failed." }

Write-Host "  Built $KernelFlatOut"

# SECURITY-02: synchronise the runtime ESP from the artifacts just built,
# BEFORE the (elevation-dependent) disk-image stage, so a diskpart failure
# cannot leave run-vexos.ps1 booting a stale kernel. Verifies by SHA-256 and
# throws on mismatch - a build that cannot prove the ESP is current fails.
Write-Step "Synchronising runtime ESP (build\runtime-esp)"
try { & (Join-Path $RepoRoot "scripts\Sync-RuntimeEsp.ps1") -BuildDir $BuildDir }
catch { Write-Fail ("Runtime ESP synchronisation failed: " + $_.Exception.Message) }

# ------------------------------------------------------------------
# Disk image: VHD via diskpart (Windows-native, no custom FAT writer)
#
# Creates a fixed VHD, attaches it, partitions it GPT with a proper
# EFI System Partition, formats FAT32, copies the two boot files on,
# then detaches. All via diskpart, built into Windows - no third-party
# tool required.
#
# The mechanics live in scripts\VexDisk.ps1, which adds the robustness this
# block previously lacked: stale attached VHDs from a crashed run are
# detached before anything else, the drive letter is chosen dynamically
# (with retries) instead of hardcoding V:, diskpart output is actually
# checked for errors, the mount is polled until writable rather than tested
# once, and the detach below is in a finally block so no failure can leave
# the VHD attached and poison the next build.
# ------------------------------------------------------------------
Write-Step "Building disk image (build\vexos.img)"

# Both leftover artifacts may be attached, not merely present: a previous
# run could have died before or after the .vhd -> .img rename.
try {
    Dismount-VexVhd -Path $VhdPath -WorkDir $BuildDir | Out-Null
    Dismount-VexVhd -Path $ImgPath -WorkDir $BuildDir -Quiet | Out-Null
    Remove-VexFileWithRetry -Path $VhdPath
    Remove-VexFileWithRetry -Path $ImgPath
} catch {
    Write-Fail $_.Exception.Message
}

$MountLetter = $null
$DiskError   = $null
try {
    $MountLetter = New-VexEfiVhd -VhdPath $VhdPath -BuildDir $BuildDir -SizeMB $ImgSizeMB -EspSizeMB 10 -Label "VEXOS"

    Write-Step "Copying boot files onto the image (${MountLetter}:)"
    $espBootDir = "${MountLetter}:\EFI\BOOT"
    New-Item -ItemType Directory -Force -Path $espBootDir | Out-Null
    Copy-Item "$BootEfi" (Join-Path $espBootDir "BOOTX64.EFI") -Force
    Copy-Item "$KernelFlatOut" "${MountLetter}:\KERNEL.ELF" -Force

    # Verify the files are actually on the ESP before declaring success.
    # A silent copy failure here produces a VHD that boots to the UEFI shell,
    # which is a confusing symptom to debug later.
    foreach ($expected in @((Join-Path $espBootDir "BOOTX64.EFI"), "${MountLetter}:\KERNEL.ELF")) {
        if (-not (Test-Path -LiteralPath $expected)) {
            throw "Expected file '$expected' is missing from the image after copy."
        }
    }
}
catch {
    # Record and rethrow after the finally block has detached. Calling
    # Write-Fail (which exits) from here would skip cleanup.
    $DiskError = $_
}
finally {
    # Detach unconditionally: on success so QEMU can open the file
    # exclusively, and on failure so the next build starts clean.
    if ($MountLetter) {
        Write-Host "  Detaching image (was mounted at ${MountLetter}:)" -ForegroundColor DarkGray
    }
    Dismount-VexVhd -Path $VhdPath -WorkDir $BuildDir -Quiet | Out-Null
}

if ($DiskError) {
    Write-Fail ("Disk image creation failed - the VHD has been detached, so the next run starts clean.`n  " +
                $DiskError.Exception.Message)
}

# Rename to the agreed final artifact name. The bytes are still a VHD
# (footer-based) container - run-qemu.ps1 passes format=vpc explicitly
# so QEMU reads it correctly regardless of the .img extension.
Move-Item -LiteralPath "$VhdPath" -Destination "$ImgPath" -Force

Write-Host ""
Write-Host "Build complete: $ImgPath" -ForegroundColor Green
# RELEASE SIZE GATE: measure the real artifact. Never an estimate, never the kernel size.
$ArtifactBytes = (Get-Item -LiteralPath $ImgPath).Length
Write-Host ("Release artifact: {0} = {1} bytes ({2:N2} MiB); limit 15728640 bytes" -f $ImgPath, $ArtifactBytes, ($ArtifactBytes / 1MB))
if ($ArtifactBytes -ge 15728640) { Write-Fail "Release artifact is $ArtifactBytes bytes, which is not smaller than 15 MiB (15728640)." }
Write-Host "(Note: this file is VHD-formatted; run-qemu.ps1 passes format=vpc explicitly.)" -ForegroundColor DarkGray
Write-Host "Run 'run-qemu.ps1' to boot it." -ForegroundColor Green




