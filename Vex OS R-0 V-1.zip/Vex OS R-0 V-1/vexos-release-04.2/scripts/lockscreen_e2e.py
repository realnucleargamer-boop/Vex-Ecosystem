#!/usr/bin/env python3
"""SUPERSEDED by scripts/desktop_e2e.py (DESKTOP-01 redesigned the lock screen and removed the LOCK-01 controls this script drives). Kept for history; do not expect it to pass.
Vex OS - scripts/lockscreen_e2e.py

End-to-end verification of the LOCK-01 / INPUT-03 milestone against the REAL
booted image in QEMU (q35, TCG, OVMF, 4 vCPU - same as scripts/run-qemu.sh).

Events are injected through QEMU's emulated i8042 (sendkey / mouse_move /
mouse_button / QMP input-send-event), so they traverse the real PS/2 path:
controller -> aux/keyboard routing -> packet decoder -> event queue -> UI.
Outcomes are checked from (a) the guest's serial log (counted, so a double
fire is detectable) and (b) exact framebuffer pixel colours from `screendump`.

Run from the repository root after `make image`:
    python3 scripts/lockscreen_e2e.py [build/vexos.img]

Nothing here is "tested because it compiled": every PASS below is an observed
guest behaviour.  What this CANNOT prove is physical-hardware behaviour.
"""
import os, re, sys, time
sys.path.insert(0, os.path.dirname(__file__))
from qemu_drive import Vm, load_ppm, find_cursor, ppm_to_png

IMG = sys.argv[1] if len(sys.argv) > 1 else "build/vexos.img"
OUT = os.environ.get("E2E_OUT", "build/lockscreen-e2e")
os.makedirs(OUT, exist_ok=True)

results = []
def check(ok, what, detail=""):
    results.append((bool(ok), what))
    print(("PASS  " if ok else "FAIL  ") + what + (f"   [{detail}]" if detail and not ok else ""), flush=True)
    return ok

def count(vm, pat): return len(re.findall(pat, vm.serial()))

def rect(vm, name, after=0):
    m = list(re.finditer(name + r"=\((\d+),(\d+),(\d+),(\d+)\)", vm.serial()))
    m = m[after:] if after else m
    return tuple(int(v) for v in m[-1].groups()) if m else None

def centre(r): return (r[0] + r[2] // 2, r[1] + r[3] // 2)

def shot(vm, name):
    p = os.path.join(OUT, name + ".ppm"); vm.screendump(p)
    ppm_to_png(p, os.path.join(OUT, name + ".png")); return load_ppm(p)

def px(img, x, y): return img.getpixel((x, y))

def settle(t=0.35): time.sleep(t)

def move_rel(vm, dx, dy):
    while dx or dy:
        sx = max(-100, min(100, dx)); sy = max(-100, min(100, dy))
        vm.mouse_move(sx, sy); dx -= sx; dy -= sy; time.sleep(0.03)
    settle()

def move_to(vm, x, y):
    move_rel(vm, -1500, -1000)                 # clamp into the top-left corner (guest clamps)
    move_rel(vm, x, y)

def click(vm, hold=0.25):
    vm.mouse_button(1); time.sleep(hold); vm.mouse_button(0); settle(0.5)

def boot(tag, **kw):
    vm = Vm(IMG, OUT, tag=tag, **kw)
    ok = vm.wait_serial(r"\[ui\] lock screen shown", 120)
    settle(1.0)
    return vm, ok

# colours produced by vexui.c (button_body)
PRIMARY_N, PRIMARY_H, PRIMARY_P = (0x2E, 0x7A, 0xF0), (0x5A, 0xA0, 0xFF), (0x1B, 0x55, 0xB8)
PRIMARY_BORDER, FOCUS_BORDER = (0x7E, 0xB6, 0xFF), (0xB4, 0xD2, 0xFF)
SEC_BORDER = (0x3A, 0x4B, 0x7A)

# ======================================================================
print("\n=== A. Boot, baseline suites, lock screen, mouse, keyboard ===")
vm, ok = boot("A")
log = vm.serial()
check(ok, "image boots to the lock screen")
check("SYSTEM READY" in log and "BOOT SAGA COMPLETE" in log, "SYSTEM READY and BOOT SAGA COMPLETE still reached")
for pat, nm in [(r"105/105 checks passed", "BOOT-03 105/105"), (r"210/210 KERNEL-01", "KERNEL-01 210/210"),
                (r"97/97 SECURITY-01", "SECURITY-01 97/97"), (r"7/7 checks passed", "Graphics 2 7/7"),
                (r"108/108 SECURITY-02", "SECURITY-02 108/108 (baseline preserved)"), (r"(\d+)/\1 INPUT-03", "INPUT-03 logic suite all passed")]:
    check(re.search(pat, log), nm)
mt = re.search(r"TOTAL: (\d+) bytes \((\d+) KiB\)", log)
check(mt and "target: PASS" in log, "boot-complete memory report < 5 MiB (measured)", mt.group(0) if mt else "")
print("   measured:", mt.group(0) if mt else "n/a")
check("[mouse] PS/2 mouse streaming" in log, "PS/2 mouse initialised (reset, defaults, enable reporting acknowledged)")
check("PM1a_CNT=0x0000000000000604" in log and "shutdown AVAILABLE" in log and "reboot AVAILABLE" in log, "power capabilities discovered from FADT/DSDT")
check("NO DRIVER" in log, "network probe reports 'no driver' (truthful)")
check("[ui] lock screen shown" in log, "UI logged the lock screen")
check("VEX KERNEL PANIC" not in log and "UNHANDLED CPU EXCEPTION" not in log, "no kernel panic / unhandled CPU exception in boot log")

ENTER, NET, POWER = rect(vm, "enter"), rect(vm, "net"), rect(vm, "power")
img = shot(vm, "01_lock")
check(find_cursor(img) == (640, 400), "cursor is visible at screen centre on boot", str(find_cursor(img)))
check(px(img, ENTER[0] + 8, centre(ENTER)[1]) == PRIMARY_N, "Enter button drawn in normal state")
check(px(img, ENTER[0] + 110, ENTER[1]) == FOCUS_BORDER or px(img, ENTER[0] + 110, ENTER[1]) == FOCUS_BORDER, "Enter button shows keyboard-focus ring by default", str(px(img, ENTER[0] + 110, ENTER[1])))

# ---- mouse movement ----
move_to(vm, 0, 0)
c = find_cursor(shot(vm, "02_corner"))
check(c == (0, 0), "cursor clamps exactly at the top-left corner", str(c))
move_to(vm, 300, 200)
c = find_cursor(shot(vm, "03_move"))
check(c == (300, 200), "relative mouse motion places the cursor exactly (300,200)", str(c))
move_rel(vm, 5000, 5000)
img = shot(vm, "04_br")
# only the sprite's outline hot-spot pixel fits on screen at (1279,799); the fill is clipped away
check(px(img, 1279, 799) == (0x05, 0x07, 0x0C) and find_cursor(img) is None and px(img, 0, 0) != (0x05, 0x07, 0x0C),
      "cursor clamps at the bottom-right corner: hot-spot pixel at (1279,799), sprite clipped, nothing wrapped to the other edge", str(px(img, 1279, 799)))
check(count(vm, r"session entered") == 0, "mouse motion alone never activates anything")

# ---- hover / pressed / click on Enter ----
ex, ey = centre(ENTER)
move_to(vm, ex + 60, ey)
img = shot(vm, "05_hover")
check(px(img, ENTER[0] + 8, ey) == PRIMARY_H, "hover state: Enter button lightens", str(px(img, ENTER[0] + 8, ey)))
vm.mouse_button(1); settle(0.5)
img = shot(vm, "06_pressed")
check(px(img, ENTER[0] + 8, ey) == PRIMARY_P, "pressed state: Enter button darkens while the button is held", str(px(img, ENTER[0] + 8, ey)))
check(count(vm, r"session entered") == 0, "press alone does not fire (fires on release)")
time.sleep(1.0)   # held for many polling ticks
check(count(vm, r"session entered") == 0, "holding the button for 1 s still does not fire")
vm.mouse_button(0); settle(0.6)
check(count(vm, r"session entered as Vex \(via mouse click\)") == 1, "release over Enter enters the session EXACTLY ONCE", str(count(vm, r"session entered")))
img = shot(vm, "07_session")
LOCKB = rect(vm, "lock")
check(LOCKB is not None, "session screen shown with a Lock button")
settle(1.2)
check(count(vm, r"session entered") == 1, "no repeated transition after the click")

# ---- return to lock: click Lock button, then L key ----
lx, ly = centre(LOCKB)
move_to(vm, lx, ly); click(vm)
check(count(vm, r"session locked \(via mouse click\)") == 1, "clicking Lock returns to the lock screen (once)")
img = shot(vm, "08_relocked")
check(px(img, ENTER[0] + 8, ey) in (PRIMARY_N, PRIMARY_H), "lock screen redrawn after returning")

# ---- keyboard: SPACE once ----
vm.sendkey("spc"); settle(0.7)
check(count(vm, r"session entered as Vex \(via SPACE\)") == 1, "SPACE enters the session")
vm.sendkey("l"); settle(0.6)
check(count(vm, r"session locked \(via key L\)") == 1, "L key locks the session")
# ---- typematic: key DOWN repeated with no UP ----
base = count(vm, r"session entered")
vm.key_event("spc", True); settle(0.5)
for _ in range(6): vm.key_event("spc", True); time.sleep(0.05)
settle(0.5)
check(count(vm, r"session entered") == base + 1, "held SPACE with 7 typematic make codes causes exactly one transition", f"{count(vm,'session entered')-base}")
vm.key_event("l", True); vm.key_event("l", False); settle(0.5)       # lock while SPACE is still held down
check(count(vm, r"session locked") == 3, "lock while SPACE still held")
for _ in range(4): vm.key_event("spc", True); time.sleep(0.05)       # more repeats of the same physical press
settle(0.5)
check(count(vm, r"session entered") == base + 1, "repeats of a SPACE held across a lock do NOT re-enter")
vm.key_event("spc", False); settle(0.4)
vm.sendkey("spc"); settle(0.6)
check(count(vm, r"session entered") == base + 2, "after release, a fresh SPACE press enters again")
vm.sendkey("l"); settle(0.6)

# ---- ENTER key + TAB / arrows focus ----
vm.sendkey("ret"); settle(0.6)
check(count(vm, r"session entered as Vex \(via ENTER\)") == 1, "ENTER activates the focused Enter button")
vm.sendkey("l"); settle(0.6)
move_to(vm, 640, 700)
entered_before_nav = count(vm, r"session entered")
vm.sendkey("tab"); settle(0.5)
img = shot(vm, "09_tab_net")
check(px(img, NET[0] + NET[2] // 2, NET[1]) == FOCUS_BORDER, "TAB moves the focus ring to the Network button", str(px(img, NET[0] + NET[2] // 2, NET[1])))
check(px(img, ENTER[0] + 110, ENTER[1]) == PRIMARY_BORDER, "...and removes it from the Enter button")
vm.sendkey("tab"); settle(0.4)
img = shot(vm, "10_tab_power")
check(px(img, POWER[0] + POWER[2] // 2, POWER[1]) == FOCUS_BORDER, "second TAB focuses Power")
vm.sendkey("shift-tab"); settle(0.4)
img = shot(vm, "11_shifttab")
check(px(img, NET[0] + NET[2] // 2, NET[1]) == FOCUS_BORDER, "Shift+TAB moves focus back to Network")
vm.sendkey("right"); settle(0.4)
check(px(shot(vm, "12_right"), POWER[0] + POWER[2] // 2, POWER[1]) == FOCUS_BORDER, "RIGHT arrow moves focus forward")
vm.sendkey("left"); settle(0.4)
check(px(shot(vm, "13_left"), NET[0] + NET[2] // 2, NET[1]) == FOCUS_BORDER, "LEFT arrow moves focus back")
check(count(vm, r"session entered") == entered_before_nav, "focus navigation (TAB/Shift+TAB/arrows) never changed screen", f"{entered_before_nav} -> {count(vm, 'session entered')}")

# ---- network panel ----
vm.sendkey("ret"); settle(0.6)
check("network panel opened" in vm.serial(), "ENTER on Network opens the status panel")
img = shot(vm, "14_netpanel")
vm.sendkey("esc"); settle(0.6)
check("network panel closed (ESC)" in vm.serial(), "ESC closes the network panel (keyboard works while a popup is open)")
move_to(vm, *centre(NET)); click(vm)
check(count(vm, r"network panel opened") == 2, "mouse click on Network opens the panel (exactly once)")
move_to(vm, 5, 5); click(vm)
check("network panel closed (click outside)" in vm.serial(), "click outside closes the panel")

# ---- power menu: open, ESC, Cancel, outside click ----
move_to(vm, *centre(POWER)); click(vm)
check(count(vm, r"power menu opened") == 1, "clicking Power opens the menu")
m = re.search(r"power menu opened panel=.*?shutdown=\((\d+),(\d+),(\d+),(\d+)\) reboot=\((\d+),(\d+),(\d+),(\d+)\) cancel=\((\d+),(\d+),(\d+),(\d+)\)", vm.serial())
SH = tuple(int(v) for v in m.groups()[0:4]); RB = tuple(int(v) for v in m.groups()[4:8]); CA = tuple(int(v) for v in m.groups()[8:12])
shot(vm, "15_powermenu")
vm.sendkey("esc"); settle(0.6)
check("power menu closed (ESC)" in vm.serial(), "ESC closes the power menu")
move_to(vm, *centre(POWER)); click(vm)
move_to(vm, *centre(CA)); click(vm)
check("power menu closed (mouse click)" in vm.serial() and count(vm, r"power: (shutdown|reboot) requested") == 0, "Cancel closes the menu and requests nothing")
move_to(vm, *centre(POWER)); click(vm)
entered_before_outside = count(vm, r"session entered"); outside_before = count(vm, r"click outside")
move_to(vm, ex, ey); click(vm)
check(count(vm, r"session entered") == entered_before_outside and count(vm, r"click outside") == outside_before + 1, "click outside the menu closes it and does NOT activate the Enter button beneath")
check(vm.alive() and "shutdown" not in vm.status().lower(), "machine still running after open/cancel/close cycles")
img = shot(vm, "16_after_menu")
check(find_cursor(img) is not None, "cursor still visible after popups open/close")

# ---- real shutdown ----
move_to(vm, *centre(POWER)); click(vm)
move_to(vm, *centre(SH)); click(vm)
settle(2.0)
log = vm.serial()
check(count(vm, r"power: shutdown requested") == 1, "Shut down requested exactly once")
check("executing ACPI S5 shutdown" in log, "kernel executed the ACPI S5 path")
check("SHUTDOWN FAILED" not in log, "kernel did not report failure")
st = vm.status()
check("shutdown" in st.lower(), "QEMU reports the guest has SHUT DOWN (real ACPI power-off, not an animation)", st.strip())
shot(vm, "17_shutdown")
vm.stop()

# ======================================================================
print("\n=== B. Reboot (QEMU WITHOUT -no-reboot, to observe the restart) ===")
vm, ok = boot("B", allow_reboot=True)
check(ok, "boots to lock screen")
POWER = rect(vm, "power")
move_to(vm, *centre(POWER)); click(vm)
m = re.search(r"power menu opened panel=.*?reboot=\((\d+),(\d+),(\d+),(\d+)\)", vm.serial())
RB = tuple(int(v) for v in m.groups())
move_to(vm, *centre(RB)); click(vm)
check(vm.wait_serial(r"power: reboot requested", 10), "Reboot requested")
check(vm.wait_serial(r"executing reboot", 10), "kernel executed the reboot path")
ok2 = False
t0 = time.time()
while time.time() - t0 < 120:
    if count(vm, r"VEX OS kernel_entry\(\) reached") >= 2 and count(vm, r"\[ui\] lock screen shown") >= 2: ok2 = True; break
    time.sleep(0.5)
check(ok2, "guest actually RESTARTED: kernel_entry reached a 2nd time and the lock screen came up again", f"{count(vm, r'kernel_entry')} entries")
check("REBOOT FAILED" not in vm.serial(), "no reboot failure reported")
vm.stop()

print("\n=== C. Reboot with the project's own flags (-no-reboot) ===")
vm, ok = boot("C")
POWER = rect(vm, "power")
move_to(vm, *centre(POWER)); click(vm)
m = re.search(r"power menu opened panel=.*?reboot=\((\d+),(\d+),(\d+),(\d+)\)", vm.serial())
move_to(vm, *centre(tuple(int(v) for v in m.groups()))); click(vm)
check(vm.wait_serial(r"executing reboot", 10), "kernel executed the reboot path")
settle(3.0)
st = vm.status().strip()
# The launcher passes -no-reboot AND -no-shutdown: QEMU converts the guest reset into a shutdown and
# -no-shutdown then PAUSES the VM instead of exiting. The guest is stopped and did not restart.
check("shutdown" in st.lower() and count(vm, r"kernel_entry\(\) reached") == 1,
      "with the launcher's -no-reboot/-no-shutdown flags the reset halts the VM (paused, no restart) - documented launcher behaviour", st)
vm.stop()

# ======================================================================
print("\n=== D. Stress: input flood must not deadlock, storm or corrupt state ===")
vm, ok = boot("D")
ENTER, POWER = rect(vm, "enter"), rect(vm, "power")
t0 = time.time()
for i in range(600):                                    # 600 mouse packets back-to-back, alternating direction
    vm.mouse_move(40 if i % 2 == 0 else -40, 25 if i % 3 == 0 else -25)
for i in range(60):                                     # interleaved key traffic: TAB storm
    vm.sendkey("tab")
settle(2.0)
check(vm.alive(), "guest alive after 600 mouse packets + 60 TABs injected back-to-back")
log = vm.serial()
check(count(vm, r"session entered") == 0 and count(vm, r"power: ") == 0, "flood caused no spurious activation")
check("VEX KERNEL PANIC" not in log and "UNHANDLED CPU EXCEPTION" not in log, "no kernel panic / unhandled CPU exception during flood")
img = shot(vm, "20_after_flood")
check(find_cursor(img) is not None, "cursor still rendered and tracked after the flood")
move_to(vm, *centre(ENTER)); click(vm)
check(count(vm, r"session entered as Vex \(via mouse click\)") == 1, "UI still responsive: click Enter works after the flood")
vm.sendkey("l"); settle(0.6)
vm.sendkey("spc"); settle(0.6)
check(count(vm, r"session entered as Vex \(via SPACE\)") == 1, "keyboard still responsive after the flood")
# idle for a while: the loop must stay alive (timer-driven hlt loop, no spin, no storm)
tk0 = vm.status()
time.sleep(5)
check(vm.alive() and "running" in vm.status().lower(), "guest still running after 5 s idle")
vm.stop()

# ======================================================================
print("\n=== Summary ===")
bad = [w for ok, w in results if not ok]
print(f"{len(results) - len(bad)}/{len(results)} end-to-end checks passed")
for w in bad: print("  FAILED:", w)
print("screenshots:", OUT)
sys.exit(1 if bad else 0)
