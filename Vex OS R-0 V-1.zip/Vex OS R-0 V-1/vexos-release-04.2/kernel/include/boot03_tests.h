/*
 * Vex OS - kernel/include/boot03_tests.h
 *
 * BOOT-03 subsystem self-tests.
 *
 * These run on the BSP, in the kernel, on real (virtual) hardware, after
 * every subsystem is up. They are not a substitute for the external
 * QEMU harness - the harness checks that the machine boots at all and
 * that the expected lines appear across many CPU counts and repeats.
 * These check the things only in-kernel code can check: that a freed
 * frame is really free, that an unmapped page really faults, that a
 * timer interrupt really recurs.
 *
 * DESIGN RULE: a check that cannot fail is not a check. Every predicate
 * here is one that a plausible implementation bug would break, and
 * kernel/include/boot03_inject.h exists to demonstrate that the
 * important ones do fail when the implementation is broken on purpose.
 */

#ifndef VEXOS_BOOT03_TESTS_H
#define VEXOS_BOOT03_TESTS_H

#include <stdint.h>
#include "bootinfo.h"
#include "smp.h"

typedef struct {
    int memory;
    int paging;
    int interrupts;
    int timer;
    int smp;
    int kernel_foundation;

    uint32_t checks_run;
    uint32_t checks_failed;
} Boot03Results;

/* Runs every subsystem test. `smp` may be NULL if SMP startup was never
 * attempted, in which case the SMP result is recorded as a failure
 * rather than skipped - a milestone that requires working SMP cannot
 * pass by not testing it. */
void boot03_run_tests(BootInfo *info, const SmpInfo *smp,
                      uint64_t lapic_base, Boot03Results *out);

/* Prints the BOOT-03 summary block. Prints BOOT SAGA COMPLETE only if
 * every subsystem passed and no individual check failed. */
void boot03_print_summary(const Boot03Results *r);

/* 1 if everything passed - including any condition folded in with
 * boot03_gate_and(). */
int boot03_all_passed(const Boot03Results *r);

/* AND-folds an external condition into the readiness gate. Once folded
 * false it stays false; there is no way to clear it, deliberately, so a
 * later caller cannot re-declare readiness after an earlier one denied it.
 *
 * WHY THE GATE IS SHARED RATHER THAN PER-MILESTONE. "SYSTEM READY" is a
 * single claim about the whole machine, and every external witness -
 * scripts/smp-test.sh, scripts/smp-matrix.sh, scripts/mttcg-matrix.sh,
 * scripts/fault-inject.sh - keys on that one line. If KERNEL-01 could
 * fail while SYSTEM READY still printed, then every one of those harnesses
 * would report a green run on a broken kernel, and the negative controls
 * for KERNEL-01 could not exist at all: an injection that breaks a
 * KERNEL-01 invariant has to be observable as a machine that refuses to
 * declare itself ready.
 *
 * BOOT-03's own behaviour is unchanged when nothing is folded in, and
 * unchanged when what is folded in passes - which is the normal case. */
void boot03_gate_and(int ok);

#endif /* VEXOS_BOOT03_TESTS_H */
