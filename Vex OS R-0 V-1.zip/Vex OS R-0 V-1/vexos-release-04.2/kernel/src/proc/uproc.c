/*
 * uproc.c - PROC-01 kernel side: map a validated VXE1 image into the process window, run it through the Ring 3
 * machinery, serve its syscalls, enforce the CPU budget, and tear everything down. See kernel/include/uproc.h
 * for the guarantees AND the stated limits (one process at a time, no per-process page tables, no SMEP/SMAP).
 */
#include "uproc.h"
#include "ring3.h"
#include "vmm.h"
#include "pmm.h"
#include "serial.h"
#include "timer.h"
#include "idt.h"
#include "crystal_kernel.h"

static uint64_t g_win;                  /* base of the 40-page window (kmap area) */
static int      g_ready;
static int      g_busy;
static uint64_t g_pid_next = 1;
static uint64_t g_runs;

/* Context of the run in flight. Only valid while A.running. */
static struct {
    volatile int running;
    uint64_t pid, start_tick, out_bytes, rejected;
    uint64_t text_lo, text_hi, data_lo, data_hi, stack_lo, stack_hi;   /* [lo, hi) of each MAPPED segment */
    char     last[UPROC_MAX_WRITE + 1];
    uint64_t last_len;
} A;

uint64_t uproc_runs_total(void) { return g_runs; }

/* ---- user pointer validation -------------------------------------------------------------------------------------
 * Containment in ONE mapped segment of this process (so a range can never span a guard page or two segments), then a
 * per-page walk confirming present + user (+ writable) + 4 KiB granularity. Overflow is rejected before any sum.      */
static int seg_contains(uint64_t lo, uint64_t hi, uint64_t ptr, uint64_t len)
{
    if (lo >= hi) return 0;                              /* segment not mapped in this run */
    if (ptr < lo || ptr >= hi) return 0;                 /* also covers len == 0: the pointer itself must be inside */
    return len <= hi - ptr;                              /* ptr + len <= hi without computing the sum */
}

static int user_ok(uint64_t ptr, uint64_t len, int need_write)
{
    if (ptr == 0) return 0;
    if (len > UINT64_MAX - ptr) return 0;
    int in = seg_contains(A.data_lo, A.data_hi, ptr, len) || seg_contains(A.stack_lo, A.stack_hi, ptr, len);
    if (!in && !need_write) in = seg_contains(A.text_lo, A.text_hi, ptr, len);     /* text is readable, never writable */
    if (!in) return 0;
    uint64_t span = len ? len : 1, first = ptr & ~(uint64_t)(UPROC_PAGE - 1), last = (ptr + span - 1) & ~(uint64_t)(UPROC_PAGE - 1);
    for (uint64_t pg = first; ; pg += UPROC_PAGE) {
        uint64_t e = 0, sz = 0;
        if (vmm_query(pg, &e, &sz) != VMM_OK || !(e & VMM_PRESENT) || !(e & VMM_USER) || sz != UPROC_PAGE) return 0;
        if (need_write && !(e & VMM_WRITE)) return 0;
        if (pg == last) break;
    }
    return 1;
}

static void from_user(void *dst, uint64_t src, uint64_t n) { volatile const uint8_t *s = (volatile const uint8_t *)(uintptr_t)src; uint8_t *d = dst; for (uint64_t i = 0; i < n; i++) d[i] = s[i]; }
static void to_user(uint64_t dst, const void *src, uint64_t n)   { volatile uint8_t *d = (volatile uint8_t *)(uintptr_t)dst; const uint8_t *s = src; for (uint64_t i = 0; i < n; i++) d[i] = s[i]; }

/* ---- watchdog -------------------------------------------------------------------------------------------------- */
static int over_budget(void) { return timer_ticks() - A.start_tick >= UPROC_MAX_TICKS; }

static void uproc_tick(void *frame)
{
    InterruptFrame *f = frame;
    if (!A.running || (f->cs & 3) != 3) return;          /* only ever abandon an interrupted USER frame */
    if (over_budget()) ring3_finish(RING3_OUT_TIMEOUT, 0);
}

/* ---- syscalls ----------------------------------------------------------------------------------------------------- */
static int64_t sys_write(uint64_t ptr, uint64_t len)
{
    if (len > UPROC_MAX_WRITE) return UPROC_E_INVAL;
    if (!user_ok(ptr, len, 0)) return UPROC_E_FAULT;
    if (A.out_bytes + len > UPROC_MAX_OUTPUT) return UPROC_E_QUOTA;
    char buf[UPROC_MAX_WRITE + 1]; from_user(buf, ptr, len);
    for (uint64_t i = 0; i < len; i++) A.last[i] = buf[i];
    A.last[len] = 0; A.last_len = len; A.out_bytes += len;
    serial_puts("[uproc pid="); serial_put_dec64(A.pid); serial_puts("] write: ");
    for (uint64_t i = 0; i < len; i++) { char c = buf[i]; serial_putc((c >= 0x20 && c < 0x7F) ? c : '.'); }
    serial_puts("\n");
    return (int64_t)len;
}

static int64_t sys_ai_ask(uint64_t in, uint64_t in_len, uint64_t out, uint64_t cap)
{
    if (in_len > 256 || cap == 0 || cap > 4096) return UPROC_E_INVAL;
    if (!user_ok(in, in_len, 0) || !user_ok(out, cap, 1)) return UPROC_E_FAULT;
    char text[257], reply[512];
    from_user(text, in, in_len); text[in_len] = 0;
    int r = crystal_kernel_ask(text, (size_t)in_len, reply, sizeof reply);
    if (r < 0) return (r == -100) ? UPROC_E_BUSY : (r == -101) ? UPROC_E_IO : UPROC_E_INVAL;
    uint64_t n = (uint64_t)r < cap - 1 ? (uint64_t)r : cap - 1;
    to_user(out, reply, n);
    uint8_t z = 0; to_user(out + n, &z, 1);
    return r;
}

static int64_t uproc_syscall(InterruptFrame *f)
{
    if (over_budget()) ring3_finish(RING3_OUT_TIMEOUT, 0);     /* syscall entry is a safe point: nothing is held */
    switch (f->rax) {                                          /* full 64-bit comparison: no number aliasing */
    case UPROC_SYS_EXIT:   ring3_finish(RING3_OUT_EXITED, f->rdi);
    case UPROC_SYS_WRITE:  { int64_t r = sys_write(f->rdi, f->rsi); if (r < 0) A.rejected++; return r; }
    case UPROC_SYS_GETPID: return (int64_t)A.pid;
    case UPROC_SYS_AI_ASK: { int64_t r = sys_ai_ask(f->rdi, f->rsi, f->rdx, f->r10); if (r < 0) A.rejected++; return r; }
    default:               A.rejected++; return UPROC_E_NOSYS;
    }
}

/* ---- init ------------------------------------------------------------------------------------------------------------ */
int uproc_init(void)
{
    if (g_ready) return 1;
    if (!ring3_initialised()) { serial_puts("[uproc] init: ring3 not initialised\n"); return 0; }
    g_win = vmm_kmap_reserve_virtual(UPROC_WINDOW_PAGES);
    if (!g_win) { serial_puts("[uproc] init: no virtual space for the process window\n"); return 0; }
    timer_set_tick_hook(uproc_tick);
    g_ready = 1;
    serial_puts("[uproc] process loader ready: window "); serial_put_hex64(g_win); serial_puts(" ("); serial_put_dec64(UPROC_WINDOW_PAGES); serial_puts(" pages)\n");
    return 1;
}

/* ---- run ------------------------------------------------------------------------------------------------------------- */
static void zero_frame(uint64_t phys) { volatile uint8_t *p = (volatile uint8_t *)(uintptr_t)(VEX_PHYS_MAP_BASE + phys); for (uint64_t i = 0; i < UPROC_PAGE; i++) p[i] = 0; }
static void copy_to_frame(uint64_t phys, uint64_t off, const uint8_t *src, uint64_t n)
{ volatile uint8_t *p = (volatile uint8_t *)(uintptr_t)(VEX_PHYS_MAP_BASE + phys); for (uint64_t i = 0; i < n; i++) p[off + i] = src[i]; }

#define TEXT_FLAGS  (VMM_USER)                               /* read-only, executable   */
#define DATA_FLAGS  (VMM_USER | VMM_WRITE | VMM_NX)          /* writable, never executable */

UprocStatus uproc_run(const uint8_t *img, size_t len, UprocResult *out)
{
    UprocResult R; uint8_t *rp = (uint8_t *)&R; for (size_t i = 0; i < sizeof R; i++) rp[i] = 0;
    UprocLayout L; UprocStatus st = uproc_image_validate(img, len, &L);
    if (st != UPROC_OK) { R.status = st; if (out) *out = R; return st; }
    if (!g_ready) { R.status = UPROC_E_NOT_INIT; if (out) *out = R; return R.status; }
    if (__atomic_exchange_n(&g_busy, 1, __ATOMIC_ACQUIRE)) { R.status = UPROC_E_BUSY_RUN; if (out) *out = R; return R.status; }

    uint64_t tf[UPROC_MAX_TEXT_PAGES], df[UPROC_MAX_DATA_PAGES], sf[UPROC_MAX_STACK_PAGES];
    uint64_t tva = g_win + (uint64_t)UPROC_PG_TEXT0 * UPROC_PAGE, dva = g_win + (uint64_t)UPROC_PG_DATA0 * UPROC_PAGE;
    uint64_t stop = g_win + (uint64_t)UPROC_PG_STACK_TOP * UPROC_PAGE, slo = stop - (uint64_t)L.stack_pages * UPROC_PAGE;
    uint32_t nt = 0, nd = 0, ns = 0, mt = 0, md = 0, ms = 0;     /* frames allocated / pages mapped */
    st = UPROC_OK;

    for (; nt < L.text_pages; nt++)  { tf[nt] = pmm_alloc_page(); if (!tf[nt]) { st = UPROC_E_NO_MEMORY; break; } zero_frame(tf[nt]); }
    if (st == UPROC_OK) for (; nd < L.data_pages; nd++)  { df[nd] = pmm_alloc_page(); if (!df[nd]) { st = UPROC_E_NO_MEMORY; break; } zero_frame(df[nd]); }
    if (st == UPROC_OK) for (; ns < L.stack_pages; ns++) { sf[ns] = pmm_alloc_page(); if (!sf[ns]) { st = UPROC_E_NO_MEMORY; break; } zero_frame(sf[ns]); }

    if (st == UPROC_OK) {                                        /* fill through the supervisor-only direct map, BEFORE mapping user-visible */
        for (uint64_t o = 0; o < L.text_size; o += UPROC_PAGE) { uint64_t n = L.text_size - o < UPROC_PAGE ? L.text_size - o : UPROC_PAGE; copy_to_frame(tf[o / UPROC_PAGE], 0, img + L.text_off + o, n); }
        for (uint64_t o = 0; o < L.data_size; o += UPROC_PAGE) { uint64_t n = L.data_size - o < UPROC_PAGE ? L.data_size - o : UPROC_PAGE; copy_to_frame(df[o / UPROC_PAGE], 0, img + L.data_off + o, n); }
        for (; mt < L.text_pages; mt++)  if (vmm_map_user_page(tva + (uint64_t)mt * UPROC_PAGE, tf[mt], TEXT_FLAGS) != VMM_OK) { st = UPROC_E_MAP; break; }
        if (st == UPROC_OK) for (; md < L.data_pages; md++)  if (vmm_map_user_page(dva + (uint64_t)md * UPROC_PAGE, df[md], DATA_FLAGS) != VMM_OK) { st = UPROC_E_MAP; break; }
        if (st == UPROC_OK) for (; ms < L.stack_pages; ms++) if (vmm_map_user_page(slo + (uint64_t)ms * UPROC_PAGE, sf[ms], DATA_FLAGS) != VMM_OK) { st = UPROC_E_MAP; break; }
    }

    Ring3Result rr; uint8_t *z = (uint8_t *)&rr; for (size_t i = 0; i < sizeof rr; i++) z[i] = 0;
    if (st == UPROC_OK) {
        A.pid = g_pid_next++; A.out_bytes = 0; A.rejected = 0; A.last[0] = 0; A.last_len = 0;
        A.text_lo = tva;  A.text_hi = tva + (uint64_t)L.text_pages * UPROC_PAGE;
        A.data_lo = dva;  A.data_hi = dva + (uint64_t)L.data_pages * UPROC_PAGE;
        A.stack_lo = slo; A.stack_hi = stop;
        A.start_tick = timer_ticks(); g_runs++;
        serial_puts("[uproc] run pid="); serial_put_dec64(A.pid); serial_puts(" text="); serial_put_dec64(L.text_size);
        serial_puts("B data="); serial_put_dec64(L.data_size); serial_puts("B bss="); serial_put_dec64(L.bss_size); serial_puts("B\n");
        ring3_set_ext_syscall(uproc_syscall);
        A.running = 1;
        ring3_run_ext(tva + L.entry, stop - 16, dva, tva, &rr);
        A.running = 0;
        ring3_set_ext_syscall(0);
        R.pid = A.pid; R.ticks = timer_ticks() - A.start_tick; R.syscalls_rejected = A.rejected; R.bytes_written = A.out_bytes;
        for (uint64_t i = 0; i <= A.last_len; i++) R.last_write[i] = A.last[i];
        R.last_write_len = A.last_len;
        R.outcome = rr.outcome; R.exit_code = rr.exit_code; R.fault_vector = rr.fault_vector; R.fault_error_code = rr.fault_error_code;
        R.fault_rip = rr.fault_rip; R.fault_cr2 = rr.fault_cr2; R.syscalls = rr.syscalls_seen;
        R.text_va = tva; R.data_va = dva; R.stack_lo_va = slo; R.stack_top_va = stop;
        serial_puts("[uproc] pid="); serial_put_dec64(A.pid); serial_puts(" ended: ");
        serial_puts(rr.outcome == RING3_OUT_EXITED ? "exited" : rr.outcome == RING3_OUT_FAULTED ? "FAULT isolated" : rr.outcome == RING3_OUT_TIMEOUT ? "TIMEOUT (cpu budget)" : "no-outcome");
        serial_puts("\n");
    }

    /* Teardown: runs on EVERY path (success, load failure, partial allocation). Unmap first, then free the frame. */
    for (uint32_t i = 0; i < mt; i++) vmm_unmap_page(tva + (uint64_t)i * UPROC_PAGE);
    for (uint32_t i = 0; i < md; i++) vmm_unmap_page(dva + (uint64_t)i * UPROC_PAGE);
    for (uint32_t i = 0; i < ms; i++) vmm_unmap_page(slo + (uint64_t)i * UPROC_PAGE);
    uint32_t leaked = 0;
    for (uint32_t i = 0; i < nt; i++) if (pmm_free_page(tf[i]) != PMM_OK) leaked++;
    for (uint32_t i = 0; i < nd; i++) if (pmm_free_page(df[i]) != PMM_OK) leaked++;
    for (uint32_t i = 0; i < ns; i++) if (pmm_free_page(sf[i]) != PMM_OK) leaked++;
    if (leaked) { serial_puts("[uproc] WARNING: frames not released: "); serial_put_dec64(leaked); serial_puts("\n"); }

    R.status = st; if (out) *out = R;
    __atomic_store_n(&g_busy, 0, __ATOMIC_RELEASE);
    return st;
}
