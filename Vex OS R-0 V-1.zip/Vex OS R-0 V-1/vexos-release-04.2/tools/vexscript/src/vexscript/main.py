"""VEX-Script 1.1 CLI"""

from __future__ import annotations
import argparse
import sys
from pathlib import Path
from .interpreter import Interpreter
from .errors import VexError


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="VEX-Script 1.1 reference interpreter")
    ap.add_argument("source", help=".vex source file")
    ap.add_argument("--version", action="version", version="VexScript 2.2.0 (2.0+++)")
    args = ap.parse_args(argv)

    path = Path(args.source)
    if not path.exists():
        print(f"error: file not found: {path}", file=sys.stderr)
        return 1

    try:
        interp = Interpreter()
        interp.load(path.read_text(), str(path))
        code = interp.run_main()
        return int(code) if code is not None else 0
    except VexError as e:
        print(e.format(), file=sys.stderr)
        return 1
    except Exception as e:
        print(f"internal error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
