/*
 * Vex OS - kernel/include/percpu.h
 *
 * BOOT-03 CPU-local storage foundation.
 *
 * Every CPU gets a PerCpu block and points its GS base at it, so
 * `%gs:0` reaches "this CPU's data" without a lookup keyed on APIC ID.
 * This is the mechanism a scheduler, per-CPU run queues and per-CPU
 * interrupt state will all be built on; BOOT-03 establishes it and
 * proves it works, and nothing more.
 *
 * WHY GS AND NOT AN APIC-ID LOOKUP
 *
 *   An APIC-ID-indexed array needs a LAPIC MMIO read plus a bounds
 *   check on every access, and the LAPIC ID space is not dense. GS base
 *   is a single MSR write per CPU at startup, after which CPU-local
 *   access is one instruction with no memory dependency on shared
 *   state. It is also what the eventual syscall path will need anyway.
 *
 * WHICH MSR
 *
 *   IA32_GS_BASE (0xC0000101) is written directly, NOT
 *   IA32_KERNEL_GS_BASE (0xC0000102). KERNEL_GS_BASE is the *shadow*
 *   that `swapgs` exchanges with the active GS base; it becomes
 *   relevant when there is a userspace to switch from. Vex OS has no
 *   ring 3 yet, so the active base is the one that matters. Writing the
 *   wrong one of these two is a classic silent bug: `%gs:0` would read
 *   from address 0 and the failure would look like a null dereference.
 *
 * SELF POINTER AT OFFSET 0
 *
 *   PerCpu.self must stay the first field. percpu_this() reads
 *   `%gs:0` to get the block's own linear address, which is what lets
 *   ordinary C code hold a normal pointer. A static assertion below
 *   enforces the offset so a future field reorder cannot break it
 *   silently.
 */

#ifndef VEXOS_PERCPU_H
#define VEXOS_PERCPU_H

#include <stdint.h>

/* Written into every PerCpu block so a CPU can verify it is reading its
 * own block and not uninitialised or someone else's memory. */
#define PERCPU_MAGIC 0x5645583350435055ULL   /* "VEX3PCPU" */

typedef struct PerCpu {
    struct PerCpu *self;        /* MUST be offset 0 - see above */
    uint64_t magic;             /* PERCPU_MAGIC once initialized */
    uint32_t cpu_index;         /* index into the MADT-derived CPU list */
    uint32_t apic_id;           /* this CPU's LAPIC ID, read from its own LAPIC */
    uint64_t kernel_stack_top;  /* stack this CPU is running on */
    uint64_t cr3;               /* page tables this CPU reported running on */
    volatile uint64_t ticks;    /* timer ticks counted BY THIS CPU */
    uint64_t is_bsp;
    void    *current_context;   /* KernelContext of whatever this CPU runs */
    uint64_t reserved[4];       /* extension space; keeps size stable-ish */
} PerCpu;

/* Fails the build if the self pointer ever stops being at offset 0. */
_Static_assert(__builtin_offsetof(PerCpu, self) == 0,
               "PerCpu.self must be at offset 0 - percpu_this() reads %gs:0");

/* Maximum CPUs the per-CPU array covers. Kept equal to ACPI_MAX_CPUS by
 * a static assertion in percpu.c rather than by hoping they match. */
#define PERCPU_MAX_CPUS 32

/* Initializes the PerCpu block for the CALLING CPU and points its GS
 * base at it. Called once by the BSP and once by each AP, on the CPU
 * being initialized - it cannot be done on another CPU's behalf,
 * because writing GS base affects only the CPU executing the wrmsr.
 *
 * Returns 0 if `index` is out of range. */
int percpu_init_for_this_cpu(uint32_t index, uint32_t apic_id,
                             uint64_t kernel_stack_top, int is_bsp);

/* This CPU's block, via %gs:0. Only valid once
 * percpu_init_for_this_cpu() has run ON THIS CPU - if GS base is still
 * zero this reads linear address 0 and returns whatever happens to be
 * there, which is not a defined value. Callers that cannot be certain
 * (interrupt handlers, in particular) must use percpu_this_or_null(). */
PerCpu *percpu_this(void);

/* Safe variant: checks IA32_GS_BASE directly and returns NULL if
 * CPU-local storage is not yet established on this CPU, then validates
 * the magic before handing the block back. Costs an rdmsr, which is
 * acceptable in BOOT-03's interrupt path and is the difference between
 * a skipped counter update and a fault inside an interrupt handler. */
PerCpu *percpu_this_or_null(void);

/* Verifies that %gs:0 on this CPU resolves to the block that was
 * initialized for `index`: correct magic, correct self pointer, correct
 * index. Returns 1 on success. This is the actual evidence that
 * CPU-local storage works, as opposed to the MSR write having been
 * issued. */
int percpu_verify_this_cpu(uint32_t index);

/* The block for an arbitrary index, for the BSP's diagnostics. Returns
 * NULL if out of range. */
PerCpu *percpu_get(uint32_t index);

/* How many blocks have been initialized, across all CPUs. */
uint32_t percpu_initialized_count(void);

#endif /* VEXOS_PERCPU_H */
