# VEX-Script Changelog — 1.4.0

## Added
- `::` qualified paths for module symbols (`math_mod::add`)
- Per-module function namespaces (no global merge of imports)
- Static rejection of field access/assign on non-struct types
- Expanded 1.4 test suite (`scripts/test_1_4.py`)

## Strengthened
- Nested struct field type checking
- Chained field mutation mutability (root binding)
- Function arity/type/return checking (from 1.3, retained)

## Breaking
- Imported module functions are no longer injected as bare global names.
  Use `module::function(...)`.

## Compatibility
- 1.0 / 1.1 / 1.2 local (non-import) programs unchanged
- Examples updated for qualified module access
