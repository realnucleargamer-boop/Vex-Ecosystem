# VexScript 2.0 Phase A

## Implemented
- `import` / selective `import mod::{ names }`
- `pub fn` and privacy-by-default for modules
- Deterministic resolution (file dir, module_paths, std/, vex/)
- Cycle and duplicate import detection
- Diagnostics `file:line:col: error[E####]: message`

## Error codes
| Code | Meaning |
|------|---------|
| E0001 | missing module |
| E0002 | import cycle |
| E0003 | missing symbol |
| E0004 | private symbol access |
| E0005 | duplicate import |
| E0006 | malformed import |
| E0007 | redefinition |
