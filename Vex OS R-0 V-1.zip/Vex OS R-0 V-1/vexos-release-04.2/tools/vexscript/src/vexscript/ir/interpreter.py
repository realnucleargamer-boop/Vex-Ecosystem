"""Reference interpreter for Vex IR (hosted testing). Supports i64, bool, string, structs."""
from __future__ import annotations
from typing import Any
from .nodes import ModuleIR, Value
from ..errors import VexError


class IRInterpreter:
    def __init__(self, mod: ModuleIR):
        self.mod = mod
        self.fns = {f.name: f for f in mod.functions}
        self.output: list[str] = []

    def run(self, entry: str = "main") -> int:
        from ..evolve_rt import reset_evolve_state
        reset_evolve_state()
        if entry not in self.fns:
            raise VexError(f"IR: no function @{entry}", error_code="E0310")
        result = self._call(entry, [])
        if result is None:
            return 0
        if isinstance(result, bool):
            return int(result)
        if isinstance(result, int):
            return result
        return 0

    def _call(self, name: str, args: list[Any]) -> Any:
        if name in ("println", "print", "print_i64"):
            for a in args:
                self.output.append(str(a))
            return 0
        if name in ("concat",):
            if len(args) >= 2:
                return str(args[0]) + str(args[1])
            return ""
        if name in ("len_string", "str_len", "str_length"):
            return len(str(args[0])) if args else 0
        if name in ("array_length",):
            a = args[0] if args else []
            return len(a) if isinstance(a, list) else 0
        if name in ("str_equals",):
            return 1 if len(args) >= 2 and str(args[0]) == str(args[1]) else 0
        if name == "str_char_at":
            _s = str(args[0]); _i = int(args[1])
            return ord(_s[_i]) if 0 <= _i < len(_s) else -1
        if name in ("str_starts_with",):
            return 1 if len(args) >= 2 and str(args[0]).startswith(str(args[1])) else 0
        if name in ("str_ends_with",):
            return 1 if len(args) >= 2 and str(args[0]).endswith(str(args[1])) else 0
        if name in ("str_contains",):
            return 1 if len(args) >= 2 and str(args[1]) in str(args[0]) else 0
        if name in ("str_contains",):
            return 1 if (len(args) >= 2 and str(args[1]) in str(args[0])) else 0
        if name == "rng_seed":
            self._rng_state = int(args[0]) & 0xFFFFFFFFFFFFFFFF
            if self._rng_state == 0:
                self._rng_state = 0x9E3779B97F4A7C15
            return 0
        if name == "rng_u64":
            if not hasattr(self, "_rng_state"):
                self._rng_state = 0x9E3779B97F4A7C15
            self._rng_state = (self._rng_state + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
            z = self._rng_state
            z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9 & 0xFFFFFFFFFFFFFFFF
            z = (z ^ (z >> 27)) * 0x94D049BB133111EB & 0xFFFFFFFFFFFFFFFF
            return z ^ (z >> 31)
        if name in ("abs",):
            return abs(int(args[0])) if args else 0
        if name in ("min", "max"):
            if len(args) >= 2:
                return min(int(args[0]), int(args[1])) if name == "min" else max(int(args[0]), int(args[1]))
            return 0

        if name.startswith("tensor_") or name.startswith("neural_") or name.startswith("evolve_") or name in (
            "tensor_create_1", "tensor_create_2", "tensor_fill",
            "tensor_add", "tensor_mul", "tensor_dot", "tensor_matmul",
            "tensor_get_1", "tensor_get_2", "tensor_set_1", "tensor_set_2",
            "tensor_length", "neural_relu", "neural_linear", "neural_linear_bias",
            "neural_forward_2",
            "evolve_create", "evolve_size", "evolve_get", "evolve_set",
            "evolve_randomize", "evolve_mutate", "evolve_crossover",
            "evolve_select_tournament",
            "evolve_checkpoint_save", "evolve_checkpoint_load", "evolve_checkpoint_exists",
            "evolve_best_index", "evolve_generation",
        ):
            from ..tensor_rt import (
                tensor_create, tensor_fill, tensor_add, tensor_mul,
                tensor_dot, tensor_matmul, tensor_get, tensor_set, tensor_length, Tensor,
            )
            if name == "tensor_create_1":
                return tensor_create("f32", int(args[0]))
            if name == "tensor_create_2":
                return tensor_create("f32", int(args[0]), int(args[1]))
            if name == "tensor_fill":
                return tensor_fill(args[0], float(args[1]))
            if name == "tensor_add":
                return tensor_add(args[0], args[1])
            if name == "tensor_mul":
                return tensor_mul(args[0], args[1])
            if name == "tensor_dot":
                return tensor_dot(args[0], args[1])
            if name == "tensor_matmul":
                return tensor_matmul(args[0], args[1])
            if name == "tensor_get_1":
                return tensor_get(args[0], int(args[1]))
            if name == "tensor_get_2":
                return tensor_get(args[0], int(args[1]), int(args[2]))
            if name == "tensor_set_1":
                return tensor_set(args[0], float(args[1]), int(args[2]))
            if name == "tensor_set_2":
                return tensor_set(args[0], float(args[1]), int(args[2]), int(args[3]))
            if name == "tensor_length":
                return tensor_length(args[0])
            if name == "neural_relu":
                from ..tensor_rt import neural_relu
                return neural_relu(args[0])
            if name == "neural_linear":
                from ..tensor_rt import neural_linear
                return neural_linear(args[0], args[1], None)
            if name == "neural_linear_bias":
                from ..tensor_rt import neural_linear
                return neural_linear(args[0], args[1], args[2])
            if name == "neural_forward_2":
                from ..tensor_rt import neural_forward_2layer
                return neural_forward_2layer(args[0], args[1], args[2], args[3], args[4])
            if name.startswith("evolve_"):
                from .. import evolve_rt as er
                rng = lambda: self._call("rng_u64", []) if False else None
                # use module-level rng via interpreter method pattern
                def _rng():
                    # splitmix on a side state stored on interpreter
                    if not hasattr(self, "_rng_state"):
                        self._rng_state = 0x9E3779B97F4A7C15
                    self._rng_state = (self._rng_state + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
                    z = self._rng_state
                    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9 & 0xFFFFFFFFFFFFFFFF
                    z = (z ^ (z >> 27)) * 0x94D049BB133111EB & 0xFFFFFFFFFFFFFFFF
                    return z ^ (z >> 31)
                if name == "evolve_create":
                    return er.evolve_create(int(args[0]), int(args[1]))
                if name == "evolve_size":
                    return er.evolve_size(int(args[0]))
                if name == "evolve_get":
                    return er.evolve_get(int(args[0]), int(args[1]))
                if name == "evolve_set":
                    return er.evolve_set(int(args[0]), int(args[1]), args[2])
                if name == "evolve_randomize":
                    return er.evolve_randomize(int(args[0]), _rng)
                if name == "evolve_mutate":
                    return er.evolve_mutate(args[0], _rng, int(args[1]))
                if name == "evolve_crossover":
                    return er.evolve_crossover(args[0], args[1], _rng)
                if name == "evolve_select_tournament":
                    scores = [float(args[0]), float(args[1]), float(args[2]), float(args[3])]
                    return er.evolve_select_tournament(scores, int(args[4]), _rng)
                if name == "evolve_checkpoint_save":
                    return er.evolve_checkpoint_save(int(args[0]), str(args[1]))
                if name == "evolve_checkpoint_load":
                    return er.evolve_checkpoint_load(str(args[0]))
                if name == "evolve_checkpoint_exists":
                    return er.evolve_checkpoint_exists(str(args[0]))
                if name == "evolve_best_index":
                    return er.evolve_best_index([float(args[0]), float(args[1]), float(args[2]), float(args[3])])
                if name == "evolve_generation":
                    return er.evolve_generation(int(args[0]), int(args[1]), _rng, int(args[2]))

        if name.startswith("genome_") or name.startswith("stream_") or name.startswith(
            "fitness_"
        ) or name.startswith("migrate_") or name.startswith("diversity_") or name.startswith("elite_"):
            # VEX AI 1.0 language wave (Bug 3 fix): route genome/stream/
            # fitness/migration/diversity/elite builtins through the IR
            # execution path via the same genome_rt/evolve_rt runtime the
            # hosted AST interpreter uses. Hosted-runtime, IR-interpreter
            # tier -- not x86-64 native. See docs "Native status".
            from .. import genome_rt as gr
            from .. import evolve_rt as er

            if name.startswith("genome_"):
                fn = getattr(gr, name, None)
                if fn is None:
                    raise VexError(f"IR: undefined function @{name}", error_code="E0310")
                return fn(*args)
            fn = getattr(er, name, None)
            if fn is None:
                raise VexError(f"IR: undefined function @{name}", error_code="E0310")
            if name == "stream_advance":
                def _rng2():
                    if not hasattr(self, "_rng_state"):
                        self._rng_state = 0x9E3779B97F4A7C15
                    self._rng_state = (self._rng_state + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
                    z = self._rng_state
                    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9 & 0xFFFFFFFFFFFFFFFF
                    z = (z ^ (z >> 27)) * 0x94D049BB133111EB & 0xFFFFFFFFFFFFFFFF
                    return z ^ (z >> 31)
                return fn(int(args[0]), int(args[1]), _rng2)
            return fn(*args)

        if name in ("gpu_available", "device_set", "device_get_code", "workers_set", "workers_get"):
            # VEX AI 1.1: acceleration/device abstraction reaches the IR path.
            from .. import accel_rt as ar
            if name == "gpu_available":
                return ar.gpu_available()
            if name == "device_set":
                return ar.device_set("cuda" if int(args[0]) == 1 else "cpu")
            if name == "device_get_code":
                return 1 if ar.device_get() == "cuda" else 0
            if name == "workers_set":
                return ar.workers_set(int(args[0]))
            if name == "workers_get":
                return ar.workers_get()

        if name in ("stream_advance_batch2", "stream_advance_batch4"):
            from .. import accel_rt as ar

            def _rng3():
                if not hasattr(self, "_rng_state"):
                    self._rng_state = 0x9E3779B97F4A7C15
                self._rng_state = (self._rng_state + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
                z = self._rng_state
                z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9 & 0xFFFFFFFFFFFFFFFF
                z = (z ^ (z >> 27)) * 0x94D049BB133111EB & 0xFFFFFFFFFFFFFFFF
                return z ^ (z >> 31)
            sids = [int(a) for a in (args[:2] if name.endswith("2") else args[:4])]
            rate = int(args[-1])
            gens = ar.stream_advance_batch(sids, rate, _rng3)
            return gens[0]

        if name.startswith("gpop_"):
            # VEX AI 1.2: GPU-friendly batched population runtime reaches
            # the IR execution path too (same runtime gpu_rt.py the hosted
            # interpreter's gpop_* builtins call).
            from .. import gpu_rt as gp
            if name == "gpop_create":
                return gp.pop_create(int(args[0]), int(args[1]), int(args[2]))
            if name == "gpop_size":
                return gp.pop_size_of(int(args[0]))
            if name == "gpop_gene_len":
                return gp.pop_gene_len(int(args[0]))
            if name == "gpop_generation":
                return gp.pop_generation(int(args[0]))
            if name == "gpop_fitness_target":
                return gp.pop_fitness_target_batch(int(args[0]), str(args[1]))
            if name == "gpop_fitness_structural":
                return gp.pop_fitness_structural_batch(int(args[0]))
            if name == "gpop_reasoning_bonus":
                return gp.pop_reasoning_bonus_batch(int(args[0]), int(args[1]))
            if name == "gpop_upper_count_at":
                return gp.pop_upper_count_at(int(args[0]), int(args[1]))
            if name == "gpop_advance":
                if not hasattr(self, "_gpop_seed_step"):
                    self._gpop_seed_step = 0
                self._gpop_seed_step += 1
                return gp.pop_advance_batch(int(args[0]), int(args[1]), int(args[2]), self._gpop_seed_step)
            if name == "gpop_best_index":
                return gp.pop_best_index(int(args[0]))
            if name == "gpop_best_fitness":
                return gp.pop_best_fitness(int(args[0]))
            if name == "gpop_avg_fitness_milli":
                return gp.pop_avg_fitness_milli(int(args[0]))
            if name == "gpop_best_string":
                return gp.pop_string_at(int(args[0]), gp.pop_best_index(int(args[0])))
            if name == "gpop_backend_code":
                return {"cuda": 2, "torch-cpu": 1, "numpy-cpu": 0}.get(gp.backend_name(), -1)
            raise VexError(f"IR: undefined function @{name}", error_code="E0310")

        from ..hosted import HOSTED_BUILTINS
        if name in HOSTED_BUILTINS:
            result = HOSTED_BUILTINS[name](*args)
            return result
        if name not in self.fns:
            raise VexError(f"IR: undefined function @{name}", error_code="E0310")
        fn = self.fns[name]
        if len(args) != len(fn.params):
            raise VexError(f"IR: arity mismatch @{name}", error_code="E0311")
        vals: dict[str, Any] = {}
        slots: dict[str, Any] = {}
        for (pname, _), a in zip(fn.params, args):
            vals[pname] = a
        blocks = {b.name: b for b in fn.blocks}
        cur = fn.blocks[0].name
        steps = 0
        while steps < 1_000_000:
            steps += 1
            b = blocks[cur]
            for inst in b.instructions:
                if inst.op == "store_local":
                    slots[str(inst.extra)] = self._read(inst.args[0], vals)
                    continue
                if inst.dest:
                    vals[inst.dest] = self._eval(inst, vals, slots)
                else:
                    self._eval_side(inst, vals, slots)
            term = b.terminator
            if term is None:
                raise VexError(f"IR: block {cur} has no terminator", error_code="E0312")
            if term.op == "ret":
                if not term.args:
                    return 0
                return self._read(term.args[0], vals)
            if term.op == "br":
                cur = term.extra
                continue
            if term.op == "br_cond":
                c = self._read(term.args[0], vals)
                t, f = term.extra
                cur = t if c else f
                continue
            raise VexError(f"IR: bad terminator {term.op}", error_code="E0312")
        raise VexError("IR: step limit exceeded", error_code="E0314")

    def _read(self, v: Value, vals: dict[str, Any]) -> Any:
        if v.kind == "lit":
            # typed literals in Value.ty when present
            if v.ty == "string":
                return str(v.text)
            if v.ty == "bool":
                return bool(int(v.text)) if str(v.text).isdigit() else (str(v.text).lower() == "true")
            try:
                return int(v.text)
            except ValueError:
                return str(v.text)
        if v.text not in vals:
            raise VexError(f"IR: undefined SSA {v.text}", error_code="E0315")
        return vals[v.text]

    def _eval(self, inst, vals: dict[str, Any], slots: dict[str, Any]) -> Any:
        if inst.op == "const":
            if inst.ty == "string" or isinstance(inst.extra, str):
                # Distinguish numeric strings carefully: only treat as string if ty says so
                if inst.ty == "string":
                    return str(inst.extra) if inst.extra is not None else ""
                # if extra is str but ty is i64, try int
            if inst.ty == "bool":
                return bool(inst.extra)
            if inst.ty and inst.ty.startswith("struct:"):
                return {"__struct__": inst.ty[7:], **(inst.extra if isinstance(inst.extra, dict) else {})}
            try:
                return int(inst.extra) if inst.extra is not None else 0
            except (TypeError, ValueError):
                return inst.extra
        if inst.op == "copy":
            return self._read(inst.args[0], vals)
        if inst.op == "load_local":
            return slots.get(str(inst.extra), 0)
        if inst.op in ("add", "sub", "mul", "div", "mod"):
            a = int(self._read(inst.args[0], vals))
            b = int(self._read(inst.args[1], vals))
            if inst.op == "add":
                return a + b
            if inst.op == "sub":
                return a - b
            if inst.op == "mul":
                return a * b
            if inst.op == "div":
                if b == 0:
                    raise VexError("IR: division by zero", error_code="E0313")
                return a // b
            if b == 0:
                raise VexError("IR: mod by zero", error_code="E0313")
            return a % b
        if inst.op in ("eq", "ne", "lt", "le", "gt", "ge"):
            a = self._read(inst.args[0], vals)
            b = self._read(inst.args[1], vals)
            # string-aware equality
            if isinstance(a, str) or isinstance(b, str):
                sa, sb = str(a), str(b)
                if inst.op == "eq":
                    return 1 if sa == sb else 0
                if inst.op == "ne":
                    return 1 if sa != sb else 0
                raise VexError(f"IR: ordered compare on strings not supported", error_code="E0316")
            ai, bi = int(a), int(b)
            ops = {
                "eq": ai == bi, "ne": ai != bi, "lt": ai < bi,
                "le": ai <= bi, "gt": ai > bi, "ge": ai >= bi,
            }
            return 1 if ops[inst.op] else 0
        if inst.op == "and":
            return 1 if self._read(inst.args[0], vals) and self._read(inst.args[1], vals) else 0
        if inst.op == "or":
            return 1 if self._read(inst.args[0], vals) or self._read(inst.args[1], vals) else 0
        if inst.op == "not":
            return 0 if self._read(inst.args[0], vals) else 1
        if inst.op == "call":
            args = [self._read(a, vals) for a in inst.args]
            return self._call(str(inst.extra), args)
        if inst.op == "make_array":
            return [self._read(a, vals) for a in inst.args]
        if inst.op == "index":
            arr = self._read(inst.args[0], vals)
            idx = int(self._read(inst.args[1], vals))
            if not isinstance(arr, list):
                raise VexError("IR: index on non-array", error_code="E0318")
            if idx < 0 or idx >= len(arr):
                raise VexError(f"IR: bounds {idx}", error_code="E0319")
            return arr[idx]
        if inst.op == "make_struct":
            fields = {}
            names = str(inst.extra).split(",") if inst.extra else []
            for i, a in enumerate(inst.args):
                key = names[i] if i < len(names) else f"f{i}"
                fields[key] = self._read(a, vals)
            st = inst.ty or "struct"
            return {"__struct__": st, **fields}
        if inst.op == "extract":
            obj = self._read(inst.args[0], vals)
            field = str(inst.extra) if inst.extra is not None else ""
            if isinstance(obj, dict):
                if field in obj:
                    return obj[field]
                raise VexError(f"IR: no field '{field}'", error_code="E0317")
            return obj
        if inst.op == "insert":
            obj = self._read(inst.args[0], vals)
            val = self._read(inst.args[1], vals)
            field = str(inst.extra)
            if isinstance(obj, dict):
                new = dict(obj)
                new[field] = val
                return new
            return obj
        return 0

    def _eval_side(self, inst, vals, slots):
        if inst.op == "call":
            args = [self._read(a, vals) for a in inst.args]
            self._call(str(inst.extra), args)
        if inst.op == "index_set":
            arr = self._read(inst.args[0], vals)
            idx = int(self._read(inst.args[1], vals))
            val = self._read(inst.args[2], vals)
            if not isinstance(arr, list):
                raise VexError("IR: index_set on non-array", error_code="E0318")
            if idx < 0 or idx >= len(arr):
                raise VexError(f"IR: bounds {idx}", error_code="E0319")
            arr[idx] = val


def run_module(mod: ModuleIR, entry: str = "main") -> tuple[int, str]:
    interp = IRInterpreter(mod)
    code = interp.run(entry)
    out = "\n".join(interp.output)
    if out:
        out += "\n"
    return int(code) if isinstance(code, int) else 0, out
