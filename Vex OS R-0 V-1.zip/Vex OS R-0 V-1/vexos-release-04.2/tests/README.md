# Build-environment tests

These test the logic in `scripts/VexToolchain.ps1` and `scripts/VexDisk.ps1`.
They are self-contained, need no elevation, and touch nothing outside a
temporary directory. They do **not** build the OS.

```powershell
pwsh -NoLogo -File tests\Test-VexBuildLogic.ps1
pwsh -NoLogo -File tests\Test-VexCandidateTables.ps1
```

(`powershell.exe` 5.1 also works; the scripts contain no 7.x-only syntax.)

## What they cover

`Test-VexBuildLogic.ps1` — 10 groups:

1. `Expand-VexDirCandidate` wildcard/absent-path expansion
2. `Resolve-VexTool` environment-override handling (file vs directory, quoting,
   surrounding whitespace, non-existent override)
3. `Resolve-VexTool` candidate-directory search
4. Toolchain cache: write, read back, and invalidation when the cached path no
   longer exists or no longer executes
5. `Resolve-VexToolchain` missing-tool error quality (does the message actually
   name the tool, the download URL, and the override variable?)
6. `Resolve-VexToolchain` end-to-end via overrides, plus `PATH` injection
   (process scope only, no duplicate entries across repeated calls,
   platform-correct path separator)
7. `Invoke-VexDiskpart` error detection — non-zero exit, error text on a
   zero exit, and the unlaunchable-`diskpart` case
8. `Get-VexFreeDriveLetter` override validation
9. `New-VexEfiVhd` host-safety and argument guards (path must be under
   `build\`, extension must be `.vhd`, ESP must fit, prefix-collision paths
   such as `build2\` are refused)
10. `Remove-VexFileWithRetry` / `Dismount-VexVhd` edge cases

`Test-VexCandidateTables.ps1` — asserts the contents of the discovery tables:
that each known install location (admin `Program Files`, per-user
`%LOCALAPPDATA%\bin\NASM`, winget `Links` and `Packages\<Id>_*`, Chocolatey,
Scoop, MSYS2, Visual Studio's bundled LLVM) is present and correctly spelled,
that there are no empty or duplicate entries, that the tool-spec table covers
every executable the build actually invokes, and that a stripped environment
does not produce malformed candidates. A typo in one of these literals is the
most likely way for discovery to silently fail on a real machine, and it is
invisible to a syntax check.

## What they cannot cover

These ran on **Linux PowerShell 7**. They cannot exercise, and therefore do
not verify:

- real `diskpart` invocation, VHD attach/detach, GPT/ESP creation, FAT32
  formatting, or drive-letter assignment
- the Windows registry `InstallLocation` probe
- whether the Windows candidate paths exist on any particular machine
- actual `clang` / `lld-link` / `ld.lld` / `llvm-objcopy` / `nasm` invocation
- booting the resulting image in QEMU

A green run here means the decision logic and error handling behave as
intended. It does **not** mean the build has been verified on Windows. That
requires running `.\build.ps1` from an elevated PowerShell session on a real
Windows host.

## LOCK-01 / INPUT-03 (Linux/WSL)

- `python3 tests/check_build_lists.py` - `kernel/Makefile` and `build.ps1` must list identical sources.
- `python3 scripts/verify_winpath_on_linux.py` - replays build.ps1's clang/lld pipeline on Linux and boots it.
- `python3 scripts/lockscreen_e2e.py` - boots the image in QEMU and injects real PS/2 key/mouse events. See `docs/LOCK-01.md`.

## DESKTOP-01
- `python3 tests/vexapp_host_test.py` - compiles the VexScript terminal with the real toolchain and runs it against a C mock of the OS services.
- `python3 scripts/build_vexapp.py --check` - generated assembly must match the VexScript sources.
- `python3 scripts/desktop_e2e.py build/vexos.img build/vexos-seed.img` - real PS/2 end-to-end run (supersedes `lockscreen_e2e.py`).

## RELEASE-02
- `python3 scripts/release_e2e.py build/vexos.img build/vexos-seed.img` - passwords, accounts, Explorer, Task Manager, size, volatility (supersedes `desktop_e2e.py`).
- `python3 scripts/refresh_regression.py ...` - incremental-vs-full redraw invariant (F12).
