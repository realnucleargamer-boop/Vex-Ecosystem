#!/usr/bin/env python3
"""Compiles the REAL wallpaper_core.c, wallpaper.c and generated wallpaper_data.c natively (AddressSanitizer + UBSan; the PMM and
serial are stubbed) and runs tests/host/wallpaper_harness.c: container validation + fuzzing, cover-fit geometry, scaler exactness,
cache lifecycle, allocation-failure and corrupt-asset behaviour, thumbnail clipping.  Also checks the committed wallpaper_data.c is
reproducible from assets/wallpapers/src when Pillow/OpenCV are installed, and cross-checks the scaler against Pillow.
Does NOT prove that the kernel draws the wallpaper (see scripts/wallpaper_e2e.py, real QEMU)."""
import os, subprocess, sys, tempfile
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
k = os.path.join(root, "kernel")
def build(extra, tag):
    d = tempfile.mkdtemp(); exe = os.path.join(d, "t")
    cc = ["gcc", "-std=gnu11", "-g", "-O1", "-fsanitize=address,undefined", "-fno-sanitize-recover=all", "-Wall", "-Wextra", "-I", os.path.join(k, "include"), "-I", os.path.join(root, "common/include"),
          *extra, os.path.join(root, "tests/host/wallpaper_harness.c"), os.path.join(k, "src/ui/wallpaper_core.c"), os.path.join(k, "src/ui/wallpaper.c"), os.path.join(k, "src/ui/wallpaper_data.c"), "-o", exe]
    c = subprocess.run(cc, capture_output=True, text=True)
    if c.returncode: print(c.stderr); sys.exit(1)
    return exe
rc = 0
print("== normal build =="); rc |= subprocess.run([build([], "n")]).returncode
print("\n== test build with forced corrupt #2 and missing #4 =="); rc |= subprocess.run([build(["-DVEX_WP_TEST_CORRUPT=2", "-DVEX_WP_TEST_MISSING=4"], "t")]).returncode
try:
    import PIL, cv2  # noqa
    print("\n== generated data reproducible from assets =="); rc |= subprocess.run([sys.executable, os.path.join(root, "tools/make_wallpapers.py"), "--check"]).returncode
except ImportError:
    print("\nSKIP  reproducibility check (needs Pillow + opencv-python)")
sys.exit(rc)
