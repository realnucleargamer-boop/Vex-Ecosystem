# Vex OS - scripts/VexDisk.ps1
#
# VHD / diskpart helpers for the Windows-native build. Dot-source from
# build.ps1:
#
#     . (Join-Path $RepoRoot "scripts\VexDisk.ps1")
#
# WHY THIS FILE EXISTS
# --------------------
# The original inline diskpart block in build.ps1 had four failure modes that
# all present to the user as the same unhelpful "diskpart did not mount the
# new image at V:":
#
#   1. Hardcoded drive letter V:. If anything else holds V: - another VHD, a
#      USB stick, a mapped drive - the build fails and the message blames
#      diskpart.
#   2. Stale attached VHD. If a previous run died between `attach vdisk` and
#      `detach vdisk` (Ctrl-C, compile error, crash), build\vexos.vhd is
#      still attached. The next run's `Remove-Item` then fails with a sharing
#      violation, or `create vdisk` fails because the file is in use.
#   3. No detach on failure. The copy step ran outside any try/finally, so a
#      failure there left the VHD attached, guaranteeing failure mode 2 on the
#      next run. One transient error poisoned every subsequent build.
#   4. Mount is not synchronous. diskpart's `assign letter=` returns before
#      the volume is necessarily reachable through the filesystem namespace,
#      so an immediate Test-Path can fail on a mount that would have been
#      ready a moment later.
#
# Everything here is scoped to VHD files by explicit path
# (`select vdisk file="..."`). No function in this file ever selects a disk by
# index, and no function operates on a path outside the caller-supplied build
# directory - that guard is enforced in New-VexEfiVhd, not left to convention,
# because the blast radius of getting this wrong is a formatted host disk.

#Requires -Version 5.1

Set-StrictMode -Off

# ------------------------------------------------------------------
# diskpart invocation with real error detection
#
# diskpart's exit code is not a reliable success signal: it can report 0
# while an individual command inside the script failed. So check the exit
# code AND scan the captured output for its error strings, and - most
# importantly - have callers verify the intended outcome independently.
# ------------------------------------------------------------------
function Invoke-VexDiskpart {
    param(
        [Parameter(Mandatory=$true)][string[]]$Lines,
        [Parameter(Mandatory=$true)][string]$WorkDir,
        [string]$Label = "diskpart",
        [switch]$Tolerant   # for cleanup, where "nothing to do" is a normal outcome
    )

    if (-not (Test-Path -LiteralPath $WorkDir)) {
        New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null
    }

    $scriptPath = Join-Path $WorkDir ("diskpart_" + [Guid]::NewGuid().ToString("N").Substring(0,8) + ".txt")
    # ASCII on purpose: diskpart /s does not reliably accept a UTF-8 BOM.
    Set-Content -LiteralPath $scriptPath -Value $Lines -Encoding ASCII

    $output    = ""
    $launchErr = $false
    try {
        $output = (& diskpart /s "$scriptPath" 2>&1 | Out-String)
    } catch {
        # diskpart missing or unlaunchable. Must be treated as failure
        # explicitly: $LASTEXITCODE is stale in this path and could be 0.
        $output    = "Could not launch diskpart: $($_.Exception.Message)"
        $launchErr = $true
    } finally {
        Remove-Item -LiteralPath $scriptPath -Force -ErrorAction SilentlyContinue
    }
    $code = if ($launchErr) { -1 } else { $LASTEXITCODE }

    $failed = $launchErr -or
              ($code -ne 0) -or
              ($output -match "DiskPart has encountered an error") -or
              ($output -match "The arguments specified for this command are not valid") -or
              ($output -match "There is no virtual disk selected")

    if ($failed -and -not $Tolerant) {
        throw ("$Label failed (exit code $code).`n--- diskpart script ---`n" +
               ($Lines -join "`n") + "`n--- diskpart output ---`n" + $output)
    }

    return [pscustomobject]@{
        ExitCode = $code
        Output   = $output
        Failed   = [bool]$failed
    }
}

# ------------------------------------------------------------------
# Drive-letter selection
#
# Letters are collected from four independent sources because no single one
# is complete:
#   - DriveInfo / Get-PSDrive: letters visible to this process now.
#   - Test-Path: catches anything the above miss.
#   - HKLM\SYSTEM\MountedDevices: machine-global letter reservations,
#     including volumes that are not currently mounted. Without this, a
#     letter can be "free" by enumeration and still collide on assign.
#
# Ordering note: search N..Z before D..M. Network mappings (per-logon, so
# invisible to an elevated session) conventionally sit at the end of the
# alphabet, and local volumes at the start. Neither end is safe, but volume
# letter assignment is machine-global while a network mapping is not, so
# preferring the middle-to-high range and cross-checking MountedDevices
# minimises the chance of shadowing something the user can see in their
# non-elevated session.
# ------------------------------------------------------------------
function Get-VexUsedDriveLetters {
    $used = New-Object 'System.Collections.Generic.HashSet[string]'

    try {
        foreach ($d in [System.IO.DriveInfo]::GetDrives()) {
            if ($d.Name -and $d.Name.Length -ge 1) { [void]$used.Add($d.Name.Substring(0,1).ToUpper()) }
        }
    } catch {
        # Best-effort source. Losing one source only makes the used-letter set
        # smaller, and a wrong "free" guess is caught later by the assign
        # retry loop - so degrade quietly rather than block the build.
        Write-Verbose "DriveInfo enumeration failed: $($_.Exception.Message)"
    }

    try {
        foreach ($d in (Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
            if ($d.Name -and $d.Name.Length -eq 1) { [void]$used.Add($d.Name.ToUpper()) }
        }
    } catch {
        Write-Verbose "Get-PSDrive enumeration failed: $($_.Exception.Message)"
    }

    foreach ($c in [char[]]([char]'A'..[char]'Z')) {
        $L = [string]$c
        if (Test-Path -LiteralPath ($L + ":\") -ErrorAction SilentlyContinue) { [void]$used.Add($L) }
    }

    # Machine-global reservations.
    try {
        $md = Get-ItemProperty -Path "HKLM:\SYSTEM\MountedDevices" -ErrorAction SilentlyContinue
        if ($md) {
            foreach ($p in $md.PSObject.Properties) {
                if ($p.Name -match '^\\DosDevices\\([A-Za-z]):$') {
                    [void]$used.Add($Matches[1].ToUpper())
                }
            }
        }
    } catch {
        Write-Verbose "MountedDevices probe failed: $($_.Exception.Message)"
    }

    return $used
}

function Get-VexFreeDriveLetter {
    param([int]$Count = 3)

    # Explicit override wins, and is returned without a free-check: if the
    # user names a letter, honour it and let the assign fail loudly rather
    # than silently substituting a different one.
    $override = [Environment]::GetEnvironmentVariable("VEXOS_VHD_LETTER", "Process")
    if (-not [string]::IsNullOrWhiteSpace($override)) {
        $L = $override.Trim().TrimEnd(':','\').ToUpper()
        if ($L -notmatch '^[D-Z]$') {
            throw "VEXOS_VHD_LETTER must be a single letter D-Z (got '$override')."
        }
        return @($L)
    }

    $used = Get-VexUsedDriveLetters
    $order = @()
    $order += [char[]]([char]'N'..[char]'Z') | ForEach-Object { [string]$_ }
    $order += [char[]]([char]'D'..[char]'M') | ForEach-Object { [string]$_ }

    $free = @()
    foreach ($L in $order) {
        if (-not $used.Contains($L)) {
            $free += $L
            if ($free.Count -ge $Count) { break }
        }
    }

    if ($free.Count -eq 0) {
        throw ("No free drive letter available for mounting the build VHD (A-Z all in use or reserved).`n" +
               "  Free one up, or set `$env:VEXOS_VHD_LETTER to a letter you know is safe to reuse.")
    }
    return $free
}

# ------------------------------------------------------------------
# Stale-mount cleanup
#
# Detach a VHD by exact file path. Tolerant by design: "not attached" and
# "file does not exist" are both normal, expected outcomes here.
# ------------------------------------------------------------------
function Dismount-VexVhd {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$WorkDir,
        [switch]$Quiet
    )

    if (-not (Test-Path -LiteralPath $Path)) { return $false }

    $full = (Resolve-Path -LiteralPath $Path).Path

    # Prefer the Storage module when present: Get-DiskImage tells us whether
    # the image is actually attached, so we can skip a pointless diskpart
    # round-trip and give an accurate message. Guarded because the module is
    # not guaranteed to be available in every Windows edition/PS host.
    $isAttached = $null
    if (Get-Command Get-DiskImage -ErrorAction SilentlyContinue) {
        try {
            $di = Get-DiskImage -ImagePath $full -ErrorAction Stop
            $isAttached = [bool]$di.Attached
        } catch { $isAttached = $null }   # unknown - fall through to diskpart
    }

    if ($isAttached -eq $false) { return $false }

    if (-not $Quiet) { Write-Host "  Detaching possibly-stale VHD: $full" -ForegroundColor DarkGray }

    $res = Invoke-VexDiskpart -WorkDir $WorkDir -Label "diskpart detach" -Tolerant -Lines @(
        "select vdisk file=`"$full`""
        "detach vdisk"
    )
    return (-not $res.Failed)
}

# ------------------------------------------------------------------
# Delete a file that a just-detached VHD driver may still hold briefly.
# ------------------------------------------------------------------
function Remove-VexFileWithRetry {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$Attempts = 5,
        [int]$DelayMs  = 400
    )
    for ($i = 1; $i -le $Attempts; $i++) {
        if (-not (Test-Path -LiteralPath $Path)) { return }
        try {
            Remove-Item -LiteralPath $Path -Force -ErrorAction Stop
            return
        } catch {
            if ($i -eq $Attempts) {
                throw ("Could not delete '$Path' after $Attempts attempts: $($_.Exception.Message)`n" +
                       "  Most likely it is still attached as a virtual disk. Check Disk Management,`n" +
                       "  or detach it manually:`n" +
                       "    diskpart`n    select vdisk file=`"$Path`"`n    detach vdisk`n    exit")
            }
            Start-Sleep -Milliseconds $DelayMs
        }
    }
}

# ------------------------------------------------------------------
# Wait for a mount to become usable.
#
# Test-Path on the drive root is necessary but not sufficient - the root can
# appear before the volume is writable. Confirm with an actual directory
# creation, which is what the caller is about to do anyway.
# ------------------------------------------------------------------
function Wait-VexVolumeReady {
    param(
        [Parameter(Mandatory=$true)][string]$Letter,
        [int]$TimeoutSeconds = 20
    )
    $root = "$Letter`:\"
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $deadline) {
        if (Test-Path -LiteralPath $root) {
            try {
                $probe = Join-Path $root ".vexos-write-probe"
                New-Item -ItemType Directory -Force -Path $probe -ErrorAction Stop | Out-Null
                Remove-Item -LiteralPath $probe -Force -Recurse -ErrorAction SilentlyContinue
                return $true
            } catch {
                # Root exists but the volume is not writable yet. This is the
                # expected transient state right after diskpart's assign, and
                # is precisely why this function polls instead of testing once.
                Write-Verbose "Volume ${Letter}: not writable yet: $($_.Exception.Message)"
            }
        }
        Start-Sleep -Milliseconds 400
    }
    return $false
}

# ------------------------------------------------------------------
# Create a fixed VHD with a GPT EFI System Partition, FAT32-formatted, and
# mount it at a free drive letter.
#
# Returns the assigned drive letter. The caller MUST call Dismount-VexVhd in
# a finally block.
#
# Retries across up to three candidate drive letters: the free-letter check
# and the assign are not atomic, and on a machine with removable media or
# other VHD activity a letter can be taken in between.
# ------------------------------------------------------------------
function New-VexEfiVhd {
    param(
        [Parameter(Mandatory=$true)][string]$VhdPath,
        [Parameter(Mandatory=$true)][string]$BuildDir,
        [Parameter(Mandatory=$true)][int]$SizeMB,
        [int]$EspSizeMB = 32,
        [string]$Label = "VEXOS"
    )

    # --- Host-safety guard, enforced structurally ---
    # Every path this function writes to must live under the build directory.
    # A bug elsewhere that produced an absolute path pointing at, say, the
    # host's EFI partition must stop here rather than reach diskpart.
    $buildFull = (Resolve-Path -LiteralPath $BuildDir).Path.TrimEnd('\')
    $vhdParent = (Resolve-Path -LiteralPath (Split-Path -Parent $VhdPath)).Path.TrimEnd('\')
    if ($vhdParent -ne $buildFull -and -not $vhdParent.StartsWith($buildFull + '\')) {
        throw "Refusing to create a VHD at '$VhdPath' - it is outside the build directory '$buildFull'."
    }
    if ([IO.Path]::GetExtension($VhdPath).ToLower() -ne ".vhd") {
        # diskpart decides VHD vs VHDX from the extension and rejects others.
        throw "VHD path must end in .vhd (diskpart requires it): '$VhdPath'."
    }

    if ($EspSizeMB -ge $SizeMB) {
        throw "EspSizeMB ($EspSizeMB) must be smaller than the total image size ($SizeMB MB)."
    }

    # Clear anything left over from a previous run before touching the file.
    Dismount-VexVhd -Path $VhdPath -WorkDir $BuildDir | Out-Null
    Remove-VexFileWithRetry -Path $VhdPath

    $letters = Get-VexFreeDriveLetter -Count 3
    $lastOutput = ""

    for ($i = 0; $i -lt $letters.Count; $i++) {
        $letter = $letters[$i]
        Write-Host "  Creating $VhdPath (${SizeMB}MB fixed VHD, GPT + ESP, FAT12/16), mounting at ${letter}:" -ForegroundColor DarkGray

        $res = Invoke-VexDiskpart -WorkDir $BuildDir -Label "diskpart VHD create" -Tolerant -Lines @(
            "create vdisk file=`"$VhdPath`" maximum=$SizeMB type=fixed"
            "attach vdisk"
            "convert gpt"
            "create partition efi size=$EspSizeMB"
            "format quick fs=fat label=`"$Label`""
            "assign letter=$letter"
        )
        $lastOutput = $res.Output

        if (-not $res.Failed) {
            if (Wait-VexVolumeReady -Letter $letter) {
                return $letter
            }
            Write-Host "  ${letter}: did not become ready; retrying with another letter." -ForegroundColor Yellow
        } else {
            Write-Host "  diskpart reported an error using ${letter}:; retrying with another letter." -ForegroundColor Yellow
        }

        # Full teardown before the next attempt. Re-creating a 64MB fixed VHD
        # is cheap, and starting from a known-clean state is far easier to
        # reason about than trying to re-drive a half-configured vdisk.
        Dismount-VexVhd -Path $VhdPath -WorkDir $BuildDir -Quiet | Out-Null
        try {
            Remove-VexFileWithRetry -Path $VhdPath
        } catch {
            # If the leftover file cannot be removed we still want to try the
            # next drive letter; `create vdisk` will surface the real problem
            # with better context than this cleanup step can.
            Write-Verbose "Could not remove '$VhdPath' between attempts: $($_.Exception.Message)"
        }
    }

    throw ("Could not create and mount the build VHD after $($letters.Count) attempts " +
           "(tried drive letters: $($letters -join ', ')).`n" +
           "  Last diskpart output:`n$lastOutput`n" +
           "  If a drive letter conflict is the cause, set `$env:VEXOS_VHD_LETTER to a letter you know is free.")
}
