/*
 * Vex OS - bootloader/src/main_win.c
 *
 * Windows-toolchain (clang/lld) build of the Vex bootloader.
 *
 * This performs EXACTLY the same 8 responsibilities, in the same
 * order, against the same frozen BootInfo/boot_layout contracts, as
 * bootloader/src/main.c (the Linux/gnu-efi build):
 *
 *   1. Start from UEFI
 *   2. Obtain the EFI memory map
 *   3. Locate/load the kernel
 *   4. Obtain framebuffer information
 *   5. Obtain the ACPI RSDP
 *   6. Collect kernel physical location/size
 *   7. Construct BootInfo
 *   8. Transfer control to the kernel entry point
 *
 * The only difference from main.c is the EFI runtime layer: this file
 * uses the vendored minimal header (bootloader/include/efi/efi.h) and
 * calls UEFI protocol functions directly - no `uefi_call_wrapper`
 * shim, because clang's native x86_64-windows calling convention
 * already matches what UEFI requires (see efi.h's header comment).
 *
 * main.c and main_win.c are intentionally two files rather than one
 * #ifdef'd file: the already boot-verified Linux/gnu-efi path stays
 * completely unmodified and unaffected by this port.
 */

#include "efi/efi.h"
#include "bootinfo.h"
#include "boot_layout.h"

/* clang can lower aggregate/array initializers (e.g. a local CHAR16
 * buffer initialized from a string literal) into calls to memcpy
 * even under -ffreestanding - freestanding only means the compiler
 * won't assume libc headers exist, not that it won't emit these
 * calls. No libc is linked here, so we supply it ourselves. */
void *memcpy(void *dst, const void *src, UINTN n)
{
    UINT8 *d = (UINT8 *)dst;
    const UINT8 *s = (const UINT8 *)src;
    for (UINTN i = 0; i < n; i++) d[i] = s[i];
    return dst;
}

#define KERNEL_PATH ((CHAR16 *)u"\\KERNEL.ELF")

/* CRITICAL ABI NOTE: this file is compiled for the x86_64-windows
 * target, so its native calling convention is Microsoft x64 (first
 * integer arg in RCX). The kernel (kernel_entry/start.asm) is a
 * freestanding ELF binary built with the System V AMD64 convention
 * (first integer arg in RDI) regardless of build host. Without
 * forcing the convention at this one call site, `info` would land in
 * RCX and the kernel would read garbage out of RDI - a silent wrong-
 * pointer crash. `sysv_abi` makes this call site emit a SysV-
 * convention call despite the surrounding code being MS-ABI-native. */
typedef void (__attribute__((sysv_abi)) *KernelEntry)(BootInfo *info);

/* ---------------------------------------------------------------- */
/* Minimal console output helpers (replace gnu-efi's Print())         */
/* ---------------------------------------------------------------- */

static void put_str(EFI_SYSTEM_TABLE *st, const CHAR16 *s)
{
    /* OutputString takes a non-const CHAR16*; UEFI does not modify
     * it in practice. Cast away const at the call site only. */
    st->ConOut->OutputString(st->ConOut, (CHAR16 *)s);
}

static void put_hex64(EFI_SYSTEM_TABLE *st, UINT64 v)
{
    CHAR16 buf[19];
    const CHAR16 digits[] = u"0123456789ABCDEF";
    buf[0] = u'0'; buf[1] = u'x';
    for (int i = 0; i < 16; i++) {
        buf[2 + i] = digits[(v >> ((15 - i) * 4)) & 0xF];
    }
    buf[18] = 0;
    put_str(st, buf);
}

static void put_dec64(EFI_SYSTEM_TABLE *st, UINT64 v)
{
    CHAR16 buf[21];
    int i = 20;
    buf[i--] = 0;
    if (v == 0) buf[i--] = u'0';
    while (v > 0 && i >= 0) {
        buf[i--] = (CHAR16)(u'0' + (v % 10));
        v /= 10;
    }
    put_str(st, &buf[i + 1]);
}

/* ---------------------------------------------------------------- */
/* Memory map                                                        */
/* ---------------------------------------------------------------- */

static EFI_STATUS get_memory_map(EFI_SYSTEM_TABLE *st,
                                  EFI_MEMORY_DESCRIPTOR **map_out,
                                  UINTN *map_size_out,
                                  UINTN *map_key_out,
                                  UINTN *desc_size_out,
                                  UINT32 *desc_version_out)
{
    EFI_BOOT_SERVICES *bs = st->BootServices;
    UINTN map_size = 0;
    EFI_MEMORY_DESCRIPTOR *map = NULL;
    EFI_STATUS status;

    status = bs->GetMemoryMap(&map_size, map, map_key_out, desc_size_out, desc_version_out);
    if (status != EFI_BUFFER_TOO_SMALL) {
        put_str(st, u"[boot] GetMemoryMap size probe failed\r\n");
        return status;
    }

    map_size += 2 * (*desc_size_out);

    status = bs->AllocatePool(EfiLoaderData, map_size, (VOID **)&map);
    if (EFI_ERROR(status)) {
        put_str(st, u"[boot] AllocatePool for memory map failed\r\n");
        return status;
    }

    status = bs->GetMemoryMap(&map_size, map, map_key_out, desc_size_out, desc_version_out);
    if (EFI_ERROR(status)) {
        put_str(st, u"[boot] GetMemoryMap failed\r\n");
        bs->FreePool(map);
        return status;
    }

    *map_out = map;
    *map_size_out = map_size;
    return EFI_SUCCESS;
}

/* ---------------------------------------------------------------- */
/* Graphics (UEFI GOP)                                                */
/* ---------------------------------------------------------------- */

/* BOOT-LOGO-01: a direct, allocation-free framebuffer mark before the
 * kernel takes control. Unknown formats deliberately retain text-only boot. */
static void draw_startup_logo(EFI_GRAPHICS_OUTPUT_PROTOCOL *gop,
                              EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *mi)
{
    if (mi->PixelFormat != PixelRedGreenBlueReserved8BitPerColor &&
        mi->PixelFormat != PixelBlueGreenRedReserved8BitPerColor) return;
    UINT32 w=mi->HorizontalResolution,h=mi->VerticalResolution;
    if(w<160||h<80) return;
    UINT32 ox=(w-144)/2,oy=(h-48)/2,pitch=mi->PixelsPerScanLine;
    UINT32 color=(mi->PixelFormat==PixelRedGreenBlueReserved8BitPerColor)?0x0000A8FF:0x00FFA800;
    volatile UINT32 *p=(volatile UINT32 *)(UINTN)gop->Mode->FrameBufferBase;
    for(UINT32 y=0;y<48;y++) for(UINT32 x=0;x<144;x++) {
        int on=((x<40)&&((x<6&&y<36)||(x>33&&y<36)||(y>=32&&y<40&&x>=6&&x<=33)))||
               ((x>=52&&x<92)&&(x<58||y<6||(y>=18&&y<24)||(y>=36&&y<42)))||
               ((x>=104&&x<144)&&((x-104<6+y/2)||(143-x<6+y/2)||(x-104<6+(47-y)/2)||(143-x<6+(47-y)/2)));
        if(on) p[(oy+y)*pitch+ox+x]=color;
    }
}

static EFI_STATUS init_graphics(EFI_SYSTEM_TABLE *st, BootInfo *info)
{
    EFI_GUID gop_guid = EFI_GRAPHICS_OUTPUT_PROTOCOL_GUID;
    EFI_GRAPHICS_OUTPUT_PROTOCOL *gop = NULL;
    EFI_STATUS status;

    status = st->BootServices->LocateProtocol(&gop_guid, NULL, (VOID **)&gop);
    if (EFI_ERROR(status)) {
        put_str(st, u"[boot] GOP not available (no framebuffer)\r\n");
        info->framebuffer_addr = 0;
        info->framebuffer_size = 0;
        info->framebuffer_pixel_format = VEX_PIXEL_FORMAT_UNKNOWN;
        return status;
    }

    EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *mi = gop->Mode->Info;

    info->framebuffer_addr = gop->Mode->FrameBufferBase;
    info->framebuffer_size = gop->Mode->FrameBufferSize;
    info->framebuffer_width = mi->HorizontalResolution;
    info->framebuffer_height = mi->VerticalResolution;
    info->framebuffer_pitch = mi->PixelsPerScanLine * 4;
    info->framebuffer_bpp = 32;

    switch (mi->PixelFormat) {
        case PixelRedGreenBlueReserved8BitPerColor:
            info->framebuffer_pixel_format = VEX_PIXEL_FORMAT_RGBX8; break;
        case PixelBlueGreenRedReserved8BitPerColor:
            info->framebuffer_pixel_format = VEX_PIXEL_FORMAT_BGRX8; break;
        case PixelBitMask:
            info->framebuffer_pixel_format = VEX_PIXEL_FORMAT_BITMASK; break;
        default:
            info->framebuffer_pixel_format = VEX_PIXEL_FORMAT_UNKNOWN; break;
    }
    draw_startup_logo(gop, mi);

    put_str(st, u"[boot] Framebuffer: ");
    put_dec64(st, info->framebuffer_width);
    put_str(st, u"x");
    put_dec64(st, info->framebuffer_height);
    put_str(st, u" @ ");
    put_hex64(st, info->framebuffer_addr);
    put_str(st, u"\r\n");

    return EFI_SUCCESS;
}

/* ---------------------------------------------------------------- */
/* ACPI RSDP                                                          */
/* ---------------------------------------------------------------- */

static UINT64 find_rsdp(EFI_SYSTEM_TABLE *st)
{
    EFI_GUID acpi20 = ACPI_20_TABLE_GUID;
    EFI_GUID acpi10 = ACPI_TABLE_GUID;

    for (UINTN i = 0; i < st->NumberOfTableEntries; i++) {
        if (efi_guid_eq(&st->ConfigurationTable[i].VendorGuid, &acpi20)) {
            return (UINT64)(UINTN)st->ConfigurationTable[i].VendorTable;
        }
    }
    for (UINTN i = 0; i < st->NumberOfTableEntries; i++) {
        if (efi_guid_eq(&st->ConfigurationTable[i].VendorGuid, &acpi10)) {
            return (UINT64)(UINTN)st->ConfigurationTable[i].VendorTable;
        }
    }
    put_str(st, u"[boot] WARNING: no ACPI RSDP found\r\n");
    return 0;
}

/* ---------------------------------------------------------------- */
/* Kernel loading (fixed BOOT-01 physical address, see boot_layout.h) */
/* ---------------------------------------------------------------- */

static EFI_STATUS load_kernel(EFI_SYSTEM_TABLE *st, EFI_HANDLE image_handle, BootInfo *info)
{
    EFI_BOOT_SERVICES *bs = st->BootServices;
    EFI_GUID loaded_image_guid = EFI_LOADED_IMAGE_PROTOCOL_GUID;
    EFI_GUID fs_guid = EFI_SIMPLE_FILE_SYSTEM_PROTOCOL_GUID;
    EFI_GUID file_info_guid = EFI_FILE_INFO_GUID;
    EFI_LOADED_IMAGE_PROTOCOL *loaded_image;
    EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *fs;
    EFI_FILE_PROTOCOL *root, *kernel_file;
    EFI_STATUS status;

    status = bs->HandleProtocol(image_handle, &loaded_image_guid, (VOID **)&loaded_image);
    if (EFI_ERROR(status)) { put_str(st, u"[boot] HandleProtocol(LoadedImage) failed\r\n"); return status; }

    status = bs->HandleProtocol(loaded_image->DeviceHandle, &fs_guid, (VOID **)&fs);
    if (EFI_ERROR(status)) { put_str(st, u"[boot] HandleProtocol(FileSystem) failed\r\n"); return status; }

    status = fs->OpenVolume(fs, &root);
    if (EFI_ERROR(status)) { put_str(st, u"[boot] OpenVolume failed\r\n"); return status; }

    status = root->Open(root, &kernel_file, KERNEL_PATH, EFI_FILE_MODE_READ, 0);
    if (EFI_ERROR(status)) { put_str(st, u"[boot] Failed to open \\KERNEL.ELF\r\n"); return status; }

    UINTN info_size = 0;
    EFI_FILE_INFO *file_info = NULL;
    status = kernel_file->GetInfo(kernel_file, &file_info_guid, &info_size, file_info);
    if (status != EFI_BUFFER_TOO_SMALL) { put_str(st, u"[boot] GetInfo size probe failed\r\n"); return status; }

    status = bs->AllocatePool(EfiLoaderData, info_size, (VOID **)&file_info);
    if (EFI_ERROR(status)) return status;

    status = kernel_file->GetInfo(kernel_file, &file_info_guid, &info_size, file_info);
    if (EFI_ERROR(status)) { put_str(st, u"[boot] GetInfo failed\r\n"); return status; }

    UINT64 kernel_size = file_info->FileSize;
    bs->FreePool(file_info);

    /* BOOT-01 contract: fixed physical load address, must match the
     * kernel's linker.ld exactly (see common/include/boot_layout.h). */
    /* Reserve the kernel's RUN-TIME footprint, not its file size - the
     * flat binary excludes .bss (see VEX_KERNEL_RESERVE_BYTES). Kept
     * identical to the gnu-efi path in main.c on purpose. */
    UINTN reserve = (UINTN)VEX_KERNEL_RESERVE_BYTES;
    if (kernel_size > reserve) reserve = kernel_size;
    UINTN pages = (reserve + 4095) / 4096;
    EFI_PHYSICAL_ADDRESS kernel_addr = VEX_KERNEL_LOAD_PHYS;
    status = bs->AllocatePages(AllocateAddress, EfiLoaderData, pages, &kernel_addr);
    if (EFI_ERROR(status)) {
        put_str(st, u"[boot] AllocatePages(fixed) for kernel failed\r\n");
        return status;
    }

    UINTN read_size = kernel_size;
    status = kernel_file->Read(kernel_file, &read_size, (VOID *)(UINTN)kernel_addr);
    if (EFI_ERROR(status) || read_size != kernel_size) {
        put_str(st, u"[boot] Kernel read failed\r\n");
        return EFI_ERROR(status) ? status : EFI_LOAD_ERROR;
    }

    kernel_file->Close(kernel_file);

    info->kernel_physical_base = kernel_addr;
    info->kernel_physical_size = kernel_size;
    info->kernel_virtual_base = 0xFFFFFFFF80000000ULL;

    put_str(st, u"[boot] Kernel loaded: ");
    put_dec64(st, kernel_size);
    put_str(st, u" bytes @ physical ");
    put_hex64(st, kernel_addr);
    put_str(st, u"\r\n");

    return EFI_SUCCESS;
}

/* ---------------------------------------------------------------- */
/* Entry point                                                       */
/*                                                                     */
/* UEFI applications' entry point signature is identical regardless   */
/* of build toolchain: EFI_STATUS EFIAPI efi_main(EFI_HANDLE,          */
/* EFI_SYSTEM_TABLE*). lld-link is told the entry symbol explicitly    */
/* via /entry:efi_main (see bootloader/build.ps1 invocation).         */
/* ---------------------------------------------------------------- */

EFI_STATUS efi_main(EFI_HANDLE image_handle, EFI_SYSTEM_TABLE *system_table)
{
    EFI_STATUS status;
    EFI_BOOT_SERVICES *bs = system_table->BootServices;

    put_str(system_table, u"Vex OS Bootloader (Windows/clang build) - BOOT-01\r\n");

    BootInfo *info = NULL;
    status = bs->AllocatePool(EfiLoaderData, sizeof(BootInfo), (VOID **)&info);
    if (EFI_ERROR(status)) {
        put_str(system_table, u"[boot] Failed to allocate BootInfo\r\n");
        goto halt;
    }
    efi_zero(info, sizeof(BootInfo));

    info->magic = VEXOS_BOOTINFO_MAGIC;
    info->version = VEXOS_BOOTINFO_VERSION;
    info->header_size = sizeof(BootInfo);
    info->bootloader_version = 1;
    info->boot_flags = 0;

    info->rsdp_address = find_rsdp(system_table);

    init_graphics(system_table, info);

    status = load_kernel(system_table, image_handle, info);
    if (EFI_ERROR(status)) {
        put_str(system_table, u"[boot] FATAL: kernel load failed, halting.\r\n");
        goto halt;
    }

    EFI_MEMORY_DESCRIPTOR *map = NULL;
    UINTN map_size = 0, map_key = 0, desc_size = 0;
    UINT32 desc_version = 0;

    status = get_memory_map(system_table, &map, &map_size, &map_key, &desc_size, &desc_version);
    if (EFI_ERROR(status)) {
        put_str(system_table, u"[boot] FATAL: could not obtain memory map, halting.\r\n");
        goto halt;
    }

    info->memory_map = (UINT64)(UINTN)map;
    info->memory_map_size = map_size;
    info->memory_map_desc_size = desc_size;
    info->memory_map_desc_version = desc_version;

    status = bs->ExitBootServices(image_handle, map_key);
    if (EFI_ERROR(status)) {
        status = get_memory_map(system_table, &map, &map_size, &map_key, &desc_size, &desc_version);
        if (EFI_ERROR(status)) goto halt;

        info->memory_map = (UINT64)(UINTN)map;
        info->memory_map_size = map_size;
        info->memory_map_desc_size = desc_size;
        info->memory_map_desc_version = desc_version;

        status = bs->ExitBootServices(image_handle, map_key);
        if (EFI_ERROR(status)) {
            put_str(system_table, u"[boot] FATAL: ExitBootServices failed twice\r\n");
            goto halt;
        }
    }

    /* No more UEFI boot services calls past this point. */
    {
        KernelEntry entry = (KernelEntry)(UINTN)info->kernel_physical_base;
        entry(info);
    }

    for (;;) {
        __asm__ volatile ("cli; hlt");
    }

halt:
    put_str(system_table, u"[boot] Halting.\r\n");
    for (;;) {
        bs->Stall(1000000);
    }

    return EFI_SUCCESS;
}
