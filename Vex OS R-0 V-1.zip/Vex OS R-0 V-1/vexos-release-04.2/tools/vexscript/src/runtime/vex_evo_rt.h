#ifndef VEX_EVO_RT_H
#define VEX_EVO_RT_H
#include <stdint.h>

#define VEX_MAX_GENOMES 512
#define VEX_MAX_GENOME_LEN 81920
#define VEX_MAX_POPS 64
#define VEX_MAX_POP_SIZE 512
#define VEX_MAX_DIM 256
#define VEX_MAX_STREAMS 64

void vex_rt_rng_seed(int64_t seed);
int64_t vex_rt_rng_u64(void);

int64_t vex_rt_genome_create(int64_t capacity);
int64_t vex_rt_genome_from_cstr(const char *s);
int64_t vex_rt_genome_length(int64_t gid);
int64_t vex_rt_genome_char_code_at(int64_t gid, int64_t index);
int64_t vex_rt_genome_set_char_code(int64_t gid, int64_t index, int64_t code);
int64_t vex_rt_genome_fill_code(int64_t gid, int64_t code, int64_t length);
int64_t vex_rt_genome_copy(int64_t gid);
int64_t vex_rt_genome_compare(int64_t a, int64_t b);
int64_t vex_rt_genome_slice(int64_t gid, int64_t start, int64_t end);
const char *vex_rt_genome_to_cstr(int64_t gid);
/* returns pointer to static 2-byte buffer with one char + NUL */
const char *vex_rt_genome_char_at(int64_t gid, int64_t index);
int64_t vex_rt_genome_set_char(int64_t gid, int64_t index, const char *ch);
int64_t vex_rt_genome_append_char(int64_t gid, const char *ch);
int64_t vex_rt_genome_fill(int64_t gid, const char *ch, int64_t length);

/* text fitness: count matching positions vs cstr target (min length) */
int64_t vex_rt_genome_match_cstr(int64_t gid, const char *target);

int64_t vex_rt_stream_create(int64_t n, int64_t dim, int64_t elite_count);
int64_t vex_rt_stream_size(int64_t sid);
int64_t vex_rt_stream_generation(int64_t sid);
int64_t vex_rt_stream_set_elite_count(int64_t sid, int64_t n);
int64_t vex_rt_stream_advance(int64_t sid, int64_t rate_milli);
int64_t vex_rt_stream_pop(int64_t sid);

int64_t vex_rt_fitness_set(int64_t sid, int64_t index, int64_t score);
int64_t vex_rt_fitness_get(int64_t sid, int64_t index);
int64_t vex_rt_fitness_best_index(int64_t sid);
int64_t vex_rt_fitness_worst_index(int64_t sid);
int64_t vex_rt_fitness_average(int64_t sid);
int64_t vex_rt_fitness_sum(int64_t sid);

int64_t vex_rt_diversity_hamming_avg(int64_t sid);
int64_t vex_rt_migrate_copy(int64_t src, int64_t si, int64_t dst, int64_t di);
int64_t vex_rt_migrate_best(int64_t src, int64_t dst, int64_t di);
int64_t vex_rt_elite_preserve_count(int64_t sid);

void vex_rt_evo_reset(void);

#endif
