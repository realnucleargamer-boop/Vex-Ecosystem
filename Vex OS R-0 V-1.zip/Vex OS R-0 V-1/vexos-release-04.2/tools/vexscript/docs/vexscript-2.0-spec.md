# VexScript 2.0 — Language Specification

**Status:** Design frozen for architecture; implementation phased  
**Baseline:** VexScript 1.5.0 (reference interpreter)  
**Philosophy:** Static, deterministic, bare-metal capable, no GC, no JS runtime

---

## 1. Core language

### 1.1 Goals
- Strict static typing with explicit annotations at API boundaries
- User-defined `struct` types (value types)
- `const` and immutable-by-default locals (`let` / `let mut`)
- Deterministic evaluation; no hidden allocations in the language core
- Suitable for eventual compilation to Vex IR → x86-64 (and temporary C)

### 1.2 Keywords (2.0)
```
fn let mut const return
if else while for loop break continue
struct type enum  // enum reserved; limited use in 2.0.0
import export use mod pub
unsafe true false as
match  // reserved for 2.1+
```

### 1.3 Types
**Primitives:** `bool`, `i8` `i16` `i32` `i64`, `u8` `u16` `u32` `u64`, `f32` `f64` (float optional backend), `string` (fat pointer / handle in OS builds)

**Composite:**
```vex
[T; N]           // fixed array (compile-time N)
struct Name { fields }
type Alias = T;
*T / *mut T      // pointers (unsafe to deref)
Handle           // opaque u64 (OS objects)
fn(T) -> R       // function type (2.0 foundation)
```

**Rules:**
- No implicit numeric conversions; use `as`
- Integer literals are untyped until constrained
- `string` is not a pointer users may arithmetic on

### 1.4 Functions
```vex
pub fn add(a: i64, b: i64) -> i64 {
    return a + b;
}
fn main() -> i32 { return 0; }
```
- All paths returning non-void must return
- Parameters immutable bindings unless `mut`
- `pub` = exported from module

### 1.5 Control flow
Unchanged from 1.5: `if`/`else`, `while`, `for`, `loop`, `break`, `continue`  
Conditions must be `bool`.

### 1.6 Structs
```vex
struct Point {
    x: i64,
    y: i64,
}
let mut p = Point { x: 10, y: 20 };
p.x = 50;
```
Value semantics; assignment copies (no hidden refcount).

### 1.7 Constants
```vex
const MAX: i64 = 1024;
```
Must be compile-time evaluable in 2.0.0 (literals and simple ops).

### 1.8 Explicit casts
```vex
let x: i32 = 10;
let y: i64 = x as i64;
```
Narrowing may trap or truncate per backend policy (document per backend).

### 1.9 Unsafe
```vex
unsafe { *ptr = 1; }
```
Means language-safety responsibility only — **not** kernel privilege.

---

## 2. Modules & project system

### 2.1 Syntax
```vex
// math.vex
pub fn add(a: i64, b: i64) -> i64 { return a + b; }

// main.vex
import math;
// or
import math::{ add };
// qualified
let z = math::add(1, 2);
```

**`export`:** items are private by default; `pub` exports them.  
**`use` (1.x):** deprecated alias for `import` (accepted in 2.0, warn).

### 2.2 Resolution
1. Relative to importing file directory  
2. Project `src/` and `vendor/` paths from `vex.toml`  
3. Standard library `std::`

### 2.3 Cycles
Import cycles are **hard errors**.

### 2.4 Project layout
```
app/
  vex.toml
  src/
    main.vex
    ui/window.vex
  tests/
```

### 2.5 vex.toml (minimal)
```toml
[package]
name = "hello"
version = "0.1.0"

[dependencies]
# none in 2.0.0 core

[build]
entry = "src/main.vex"
```

---

## 3. Vex OS system API boundary

**Principle:** VexScript never receives raw kernel pointers. Only `Handle` and value types.

### 3.1 Namespace `std::sys` / `vex::sys` (names TBD; prefer `vex::`)

| API | Purpose | Status |
|-----|---------|--------|
| `vex::fs::*` | open/read/write/close paths | **ABI stub** until FS exists |
| `vex::proc::*` | spawn/exit/wait | **ABI stub** |
| `vex::thread::*` | spawn/join | **ABI stub** |
| `vex::mem::*` | page hints / stats | **ABI stub** |
| `vex::time::*` | monotonic clock, sleep | **ABI stub** |
| `vex::input::*` | keyboard/mouse events | **ABI stub** |
| `vex::info::*` | CPU, memory info | **ABI stub** |

### 3.2 Handle model
```vex
type Handle = u64;
// Invalid handle = 0
```
Syscalls (future): System V AMD64 register convention + `syscall`; numbers **not frozen** until kernel freezes them.

### 3.3 Compiler representation
Until Ring 3 exists, compiler may:
- Emit calls to host stubs (interpreter / hosted runtime), or
- Emit unresolved extern symbols `vex_sys_*` for linking later

**Do not** simulate a fake kernel inside the language.

---

## 4. UI & graphics foundation

**Layering:** VexScript → UI API → IPC → compositor/service → kernel graphics.

### 4.1 Core types
```vex
struct Color { r: u8, g: u8, b: u8, a: u8 }
struct Rect { x: i32, y: i32, w: i32, h: i32 }
type Window = Handle;
type Widget = Handle;
```

### 4.2 Window API (sketch)
```vex
fn window_create(width: i32, height: i32, title: string) -> Window;
fn window_destroy(w: Window);
fn window_set_title(w: Window, title: string);
```

### 4.3 Drawing (immediate-mode foundation; retained-mode later)
```vex
fn draw_rect(w: Window, r: Rect, c: Color);
fn draw_text(w: Window, x: i32, y: i32, text: string, c: Color);
fn clear(w: Window, c: Color);
fn present(w: Window);  // frame boundary
```

### 4.4 Widgets (handles only)
```vex
fn button_create(parent: Window, label: string) -> Widget;
fn label_create(parent: Window, text: string) -> Widget;
```

### 4.5 Events
```vex
enum EventKind { Close, Key, Mouse, Resize }  // 2.1 if enum incomplete
struct Event { kind: i32, data0: i64, data1: i64 }

fn poll_event(w: Window) -> Event;  // non-blocking
fn wait_event(w: Window) -> Event;
```
Callbacks in 2.0.0: function values / explicit poll loop (no closures required).

### 4.6 Layout
Deferred complex constraints to 2.1; 2.0 provides manual coordinates + simple `layout_row` stub.

---

## 5. Compiler architecture

```
VexScript sources
    → Lexer (locations)
    → Parser (AST)
    → Module resolver
    → Semantic analysis + typecheck
    → Vex IR generator
    → IR validate
    → Optional opts (DCE, constfold)
    → Backend: x86-64 | C (temporary) | interpreter (dev)
```

### 5.1 Diagnostics
```
path/file.vex:12:8: error[E0308]: type mismatch
  expected `i64`, found `bool`
```
Categories: `parse`, `type`, `resolve`, `import`, `ir`, `backend`.

### 5.2 Vex IR (canonical)
- Typed SSA-like or simple three-address form
- Explicit sizes; no hidden boxing
- Ops: arith, cmp, branch, call, load/store, getelementptr-style for aggregates
- `handle` as distinct IR type alias of i64

### 5.3 CLI
```
vexc build          # reads vex.toml
vexc check          # typecheck only
vexc run            # build + run (hosted)
vexc emit-ir file.vex
vexc emit-c file.vex   # temporary
```

---

## 6. Compatibility with 1.5

| Area | 2.0 policy |
|------|------------|
| `let` / `fn` / control flow | Compatible |
| Structs / `as` / bool conditions | Compatible |
| `use mod` | Deprecated → prefer `import`; still accepted |
| Bare imported names | **Removed** (1.4+ already required `mod::fn`) |
| Integer `if (1)` | Still rejected (1.5) |
| Modules without `pub` | Private by default (stricter) |

**Breaking:** default privacy; `import` preferred; optional `vex.toml` for multi-file apps.

---

## 7. What depends on Vex OS

| Feature | Depends on |
|---------|------------|
| Real `vex::fs` | Storage + VFS |
| Processes/threads | Scheduler + Ring 3 |
| Windows/draw | Framebuffer/compositor IPC |
| Input events | Drivers + input service |
| True syscalls | Frozen syscall ABI |
| No-host executables | Bootloader + userspace loader |

**Implementable now (language/compiler):** type system, modules, IR skeleton, diagnostics, hosted interpreter stubs, example programs, `vex.toml` reader.

---

## 8. Non-goals for 2.0
- Generics / traits
- Async/await
- GC / refcount runtime
- Full borrow checker
- Package registry
- JIT
- Self-hosting compiler
