/* Host harness for wallpaper_core.c + wallpaper.c (PMM/serial stubbed) + the generated wallpaper_data.c. ASan+UBSan build. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "wallpaper.h"
#include "pmm.h"
/* ---- stubs for the kernel services wallpaper.c uses ---- */
static int pmm_fail; static int live_allocs; static uint64_t last_pages;
uint64_t pmm_try_alloc_pages(uint64_t n) { if (pmm_fail) return 0; void *p = calloc((size_t)n, PMM_PAGE_SIZE); if (p) live_allocs++; last_pages = n; return (uint64_t)(uintptr_t)p; }
PmmResult pmm_free_pages(uint64_t phys, uint64_t n) { (void)n; if (!phys) return PMM_ERR_BAD_REQUEST; free((void *)(uintptr_t)phys); live_allocs--; return PMM_OK; }
void serial_puts(const char *s) { (void)s; } void serial_put_dec64(uint64_t v) { (void)v; }

static int fails, total;
#define CHECK(c, m) do { total++; if (!(c)) { fails++; printf("FAIL  %s\n", m); } else printf("PASS  %s\n", m); } while (0)
static uint32_t rng = 12345; static uint32_t rnd(void) { rng = rng * 1664525u + 1013904223u; return rng >> 8; }
static uint8_t *dupblob(const WpAsset *a, uint32_t extra_len_delta) { (void)extra_len_delta; uint8_t *b = malloc(a->size); memcpy(b, a->data, a->size); return b; }   /* exact-size heap copy: ASan flags any over-read */
static GfxFb mkfb(uint32_t w, uint32_t h, uint32_t **mem) { GfxFb f; *mem = calloc((size_t)w * h, 4); f.pixels = (volatile uint32_t *)*mem; f.width = w; f.height = h; f.pitch_px = w; f.r_shift = 16; f.g_shift = 8; f.b_shift = 0; f.ok = 1; return f; }

int main(void)
{
    const WpAsset *A = wp_assets; int N = wp_asset_count;
    CHECK(N == 6, "six embedded wallpapers");
    for (int i = 0; i < N; i++) { WpImage im; char m[96]; snprintf(m, sizeof m, "asset %d (%s) passes full verification, 320x180", i + 1, A[i].id); CHECK(wp_verify(A[i].data, A[i].size, &im) == WP_OK && im.w == 320 && im.h == 180, m); }
    { uint8_t d[1000]; for (int i = 0; i < 1000; i++) d[i] = (uint8_t)rnd(); CHECK(wp_crc32((const uint8_t *)"123456789", 9) == 0xCBF43926u, "crc32 matches the standard check value"); (void)d; }

    /* ---- validator: every structural corruption is rejected with the right code ---- */
    WpImage im; uint8_t *b = dupblob(&A[0], 0); uint32_t L = A[0].size;
    CHECK(wp_parse(NULL, 100, &im) == WP_E_NULL && wp_parse(b, 0, &im) == WP_E_NULL && wp_parse(b, L, NULL) == WP_E_NULL, "null / zero-length inputs rejected");
    for (uint32_t n = 1; n < WP_HEADER_BYTES; n++) { uint8_t *t = malloc(n); memcpy(t, b, n); if (wp_parse(t, n, &im) != WP_E_TRUNCATED) { CHECK(0, "short header"); } free(t); }
    CHECK(1, "every header length 1..19 -> TRUNCATED (no over-read, ASan)");
    { uint8_t *t = malloc(L - 1); memcpy(t, b, L - 1); CHECK(wp_parse(t, L - 1, &im) == WP_E_TRUNCATED, "one byte short -> TRUNCATED"); free(t); }
    { uint8_t *t = malloc(L + 1); memcpy(t, b, L); t[L] = 0; CHECK(wp_parse(t, L + 1, &im) == WP_E_SIZE, "trailing byte -> SIZE"); free(t); }
    b[0] = 'X'; CHECK(wp_parse(b, L, &im) == WP_E_MAGIC, "bad magic"); b[0] = 'V';
    b[8] = 2; CHECK(wp_parse(b, L, &im) == WP_E_FORMAT, "unknown pixel format"); b[8] = 1;
    b[9] = 1; CHECK(wp_parse(b, L, &im) == WP_E_FORMAT, "reserved byte must be zero"); b[9] = 0;
    b[11] = 1; CHECK(wp_parse(b, L, &im) == WP_E_FORMAT, "reserved word must be zero"); b[11] = 0;
    { uint16_t bad[] = { 0, 1, 15, 513, 4096, 65535 }; int ok = 1; for (unsigned i = 0; i < 6; i++) { b[4] = bad[i] & 255; b[5] = bad[i] >> 8; if (wp_parse(b, L, &im) != WP_E_DIMS) ok = 0; b[4] = 64; b[5] = 1; /* 320 */
            b[6] = bad[i] & 255; b[7] = bad[i] >> 8; if (wp_parse(b, L, &im) != WP_E_DIMS) ok = 0; b[6] = 180; b[7] = 0; } CHECK(ok, "width/height outside 16..512 rejected (0, 1, 15, 513, 4096, 65535)"); }
    b[12] ^= 1; CHECK(wp_parse(b, L, &im) == WP_E_SIZE, "pixel_bytes disagreeing with w*h*2 -> SIZE"); b[12] ^= 1;
    { uint32_t save = *(uint32_t *)(b + 12); *(uint32_t *)(b + 12) = 0xFFFFFFFFu; CHECK(wp_parse(b, L, &im) == WP_E_SIZE, "pixel_bytes = 4 GiB-1 -> SIZE (no 32-bit overflow)"); *(uint32_t *)(b + 12) = save; }
    CHECK(wp_parse(b, L, &im) == WP_OK && wp_verify(b, L, &im) == WP_OK, "restored blob is valid again");
    b[WP_HEADER_BYTES + 1000] ^= 0x40; CHECK(wp_verify(b, L, &im) == WP_E_CRC && wp_parse(b, L, &im) == WP_OK, "single flipped pixel bit -> CRC mismatch (structure still parses)"); b[WP_HEADER_BYTES + 1000] ^= 0x40;
    { int bad = 0; for (int k = 0; k < 4000; k++) { uint32_t pos = rnd() % L; uint8_t bit = (uint8_t)(1u << (rnd() % 8)); b[pos] ^= bit; WpStatus s = wp_verify(b, L, &im); if (s == WP_OK) bad++; b[pos] ^= bit; } CHECK(bad == 0, "4000 random single-bit flips anywhere in a blob are ALL detected"); }
    { int crash = 0; for (int k = 0; k < 20000; k++) { uint32_t n = rnd() % (L + 40); uint8_t *t = malloc(n ? n : 1); for (uint32_t i = 0; i < n; i++) t[i] = (i < 20 && (rnd() & 3)) ? b[i] : (uint8_t)rnd(); (void)wp_verify(t, n, &im); (void)wp_parse(t, n, &im); free(t); } CHECK(!crash, "20000 random/garbage blobs parsed without a crash or over-read (ASan/UBSan)"); }
    free(b);

    /* ---- cover geometry ---- */
    { WpCover c; int ok = 1; uint32_t sizes[][2] = { {1280,800},{1920,1080},{1024,768},{800,600},{640,480},{3840,2160},{64,64},{4096,64},{64,4096},{1280,720},{1366,768},{2560,1440},{1,1} };
      for (unsigned i = 0; i < sizeof sizes / sizeof *sizes; i++) { uint32_t w = sizes[i][0], h = sizes[i][1]; if (wp_cover(320, 180, w, h, &c) != WP_OK) { ok = (w == 1 && h == 1) ? ok : 0; continue; }
          if (c.sw < w || c.sh < h || c.cx + w > c.sw || c.cy + h > c.sh || (c.sw != w && c.sh != h)) ok = 0; }
      CHECK(ok, "cover-fit: scaled >= surface, crop window inside the scaled image, one axis exact (13 screen sizes)");
      CHECK(wp_cover(0, 180, 100, 100, &c) == WP_E_RANGE && wp_cover(320, 180, 0, 100, &c) == WP_E_RANGE && wp_cover(320, 180, 9000, 100, &c) == WP_E_RANGE && wp_cover(320, 180, 100, 100, NULL) == WP_E_RANGE, "cover-fit: zero / oversize / null arguments rejected"); }

    /* ---- row renderer: bounds and exactness ---- */
    { WpImage im2; wp_verify(A[0].data, A[0].size, &im2); WpCover c; wp_cover(320, 180, 1280, 800, &c); uint32_t *row = malloc(1280 * 4);
      CHECK(wp_render_row(&im2, &c, 800, 0, 10, row, 16, 8, 0) == WP_E_RANGE, "render: row == height rejected");
      CHECK(wp_render_row(&im2, &c, 0, 1279, 2, row, 16, 8, 0) == WP_E_RANGE && wp_render_row(&im2, &c, 0, 1281, 0, row, 16, 8, 0) == WP_E_RANGE, "render: span past the right edge rejected");
      CHECK(wp_render_row(&im2, &c, 0, 0xFFFFFFF0u, 100, row, 16, 8, 0) == WP_E_RANGE, "render: x0+n overflow rejected");
      CHECK(wp_render_row(&im2, &c, 0, 0, 1280, NULL, 16, 8, 0) == WP_E_NULL, "render: null output rejected");
      free(row);
      /* synthetic solid-colour image renders as exactly that colour everywhere (incl. edges) */
      uint8_t *sb = malloc(WP_HEADER_BYTES + 64 * 32 * 2); memcpy(sb, "VWP1", 4); sb[4] = 64; sb[5] = 0; sb[6] = 32; sb[7] = 0; sb[8] = 1; sb[9] = 0; sb[10] = sb[11] = 0; uint32_t pb = 64 * 32 * 2; memcpy(sb + 12, &pb, 4);
      for (int i = 0; i < 64 * 32; i++) { sb[20 + 2 * i] = 0x1F; sb[21 + 2 * i] = 0xF8 /* 0xF81F magenta */; }
      uint32_t crc = wp_crc32(sb + 20, pb); memcpy(sb + 16, &crc, 4);
      WpImage si; CHECK(wp_verify(sb, WP_HEADER_BYTES + pb, &si) == WP_OK, "synthetic image verifies");
      int ok = 1; uint32_t vws[] = { 64, 100, 333, 1280 }, vhs[] = { 32, 90, 200, 800 };
      for (int k = 0; k < 4; k++) { WpCover sc; wp_cover(64, 32, vws[k], vhs[k], &sc); uint32_t *r = malloc(vws[k] * 4); for (uint32_t y = 0; y < vhs[k]; y++) { if (wp_render_row(&si, &sc, y, 0, vws[k], r, 16, 8, 0) != WP_OK) ok = 0; for (uint32_t x = 0; x < vws[k]; x++) if (r[x] != 0xFF00FFu) ok = 0; } free(r); }
      CHECK(ok, "solid colour renders as exactly that colour at 4 sizes (no edge bleed, no off-by-one)");
      /* channel order follows the framebuffer shifts (BGR vs RGB) */
      uint32_t o1, o2; WpCover sc; wp_cover(si.w, si.h, 64, 32, &sc); wp_render_row(&si, &sc, 5, 5, 1, &o1, 16, 8, 0); wp_render_row(&si, &sc, 5, 5, 1, &o2, 0, 8, 16); CHECK(o1 == 0xFF00FFu && o2 == 0xFF00FFu, "pixel packing honours the framebuffer channel shifts"); free(sb);
    }
    /* mean luma classifies the real wallpapers as intended */
    { int ok = 1; const int light[] = { 0, 0, 0, 1, 1, 1 };
      for (int i = 0; i < N; i++) { WpImage a; wp_verify(A[i].data, A[i].size, &a); WpCover c; wp_cover(a.w, a.h, 320, 180, &c); uint32_t *buf = malloc(320 * 180 * 4); for (uint32_t y = 0; y < 180; y++) wp_render_row(&a, &c, y, 0, 320, buf + y * 320, 16, 8, 0);
          uint32_t l = wp_mean_luma(buf, 320, 320, 180, 16, 8, 0); if ((l > 150) != light[i]) { ok = 0; printf("   luma[%d]=%u\n", i, l); } free(buf); }
      CHECK(ok, "mean luma: 3 dark wallpapers < 150, 3 light wallpapers > 150 (drives dark/light desktop text)"); }

#ifndef VEX_WP_TEST_CORRUPT      /* the functional run assumes every asset is healthy; the fault-injection build runs only the checks below */
    /* ---- wallpaper.c: apply / reset / failure semantics against a stub PMM ---- */
    uint32_t *mem; GfxFb fb = mkfb(1280, 800, &mem);
    CHECK(wp_count() == 7 && wp_applied() == 0 && !wp_active() && wp_status(0) == WP_OK && !strcmp(wp_name(0), "Default") && wp_name(7) == NULL && wp_name(-1) == NULL, "initial state: default, no cache, 7 entries, out-of-range names are NULL");
    CHECK(wp_apply(2, &fb) == WP_OK && wp_applied() == 2 && wp_active() && wp_cache_bytes() == 4096000u && live_allocs == 1, "apply #2: cache of exactly 1280*800*4 bytes held");
    { volatile uint32_t *dst = mem; int ok = wp_blit_span(dst, 0, 0, 1280) && wp_blit_span(dst, 1279, 799, 1) && !wp_blit_span(dst, 1279, 0, 2) && !wp_blit_span(dst, 0, 800, 1) && !wp_blit_span(NULL, 0, 0, 1) && !wp_blit_span(dst, 1281, 0, 0);
      CHECK(ok, "blit: in-range spans copy, out-of-range / null spans refused"); }
    CHECK(wp_apply(2, &fb) == WP_OK && live_allocs == 1, "re-applying at the same size reuses the cache (no second allocation)");
    CHECK(wp_apply(5, &fb) == WP_OK && wp_applied() == 5 && live_allocs == 1, "switching wallpapers keeps a single cache");
    pmm_fail = 1; { GfxFb fb2; uint32_t *m2; fb2 = mkfb(1024, 768, &m2); CHECK(wp_apply(3, &fb2) == WP_E_NOMEM && wp_applied() == 5 && wp_active() && live_allocs == 1, "allocation failure: reported as NOMEM and the PREVIOUS wallpaper stays applied"); free(m2); } pmm_fail = 0;
    { GfxFb fb2; uint32_t *m2; fb2 = mkfb(1024, 768, &m2); CHECK(wp_apply(3, &fb2) == WP_OK && live_allocs == 1 && wp_cache_bytes() == 1024u * 768 * 4, "screen size change: new cache taken, old one freed (no leak)"); free(m2); }
    { GfxFb big; uint32_t *m3; big = mkfb(8, 8, &m3); big.width = 3840; big.height = 2160; CHECK(wp_apply(1, &big) == WP_E_SCREEN && wp_applied() == 3, "4K screen (33 MB cache) refused with SCREEN, previous kept"); free(m3);
      GfxFb tiny = mkfb(32, 32, &m3); CHECK(wp_apply(1, &tiny) == WP_E_SCREEN, "32x32 screen refused"); free(m3);
      GfxFb nofb = fb; nofb.ok = 0; CHECK(wp_apply(1, &nofb) == WP_E_SCREEN && wp_apply(1, NULL) == WP_E_SCREEN, "no usable framebuffer refused"); }
    CHECK(wp_apply(0, &fb) == WP_OK && wp_applied() == 0 && !wp_active() && live_allocs == 0 && wp_cache_bytes() == 0, "reset to default frees the cache: zero live allocations");
    CHECK(wp_apply(0, &fb) == WP_OK && live_allocs == 0, "reset twice is harmless");
    CHECK(wp_apply(99, &fb) == WP_E_MISSING && wp_apply(-3, &fb) == WP_E_MISSING && wp_applied() == 0, "unknown wallpaper index -> MISSING, nothing changes");
    for (int i = 0; i < 60; i++) { if (wp_apply(1 + (int)(rnd() % 6), &fb) != WP_OK) { CHECK(0, "stress apply"); break; } if (rnd() % 5 == 0) wp_apply(0, &fb); }
    CHECK(live_allocs <= 1, "60 random apply/reset cycles: never more than one live cache");
    wp_apply(0, &fb); CHECK(live_allocs == 0, "after the stress run, reset leaves zero live allocations");
    /* thumbnails */
    { uint32_t *tm; GfxFb t = mkfb(400, 300, &tm); int ok = 1;
      for (int i = 1; i <= N; i++) if (wp_draw_scaled(&t, i, 10, 10, 156 - 8, 91) != WP_OK) ok = 0;
      CHECK(ok, "thumbnails draw for all six wallpapers");
      CHECK(wp_draw_scaled(&t, 0, 0, 0, 10, 10) == WP_E_MISSING && wp_draw_scaled(&t, 7, 0, 0, 10, 10) == WP_E_MISSING && wp_draw_scaled(&t, 1, 0, 0, 0, 10) == WP_E_RANGE && wp_draw_scaled(&t, 1, 0, 0, 513, 10) == WP_E_RANGE, "thumbnail: default index, bad index, zero and over-wide sizes refused");
      CHECK(wp_draw_scaled(&t, 1, -50, -50, 100, 100) == WP_OK && wp_draw_scaled(&t, 1, 350, 250, 200, 200) == WP_OK && wp_draw_scaled(&t, 1, 5000, 5000, 100, 100) == WP_OK, "thumbnail: partially / fully off-screen placement clips safely (ASan)");
      free(tm); }
    free(mem);
#endif
#ifdef VEX_WP_TEST_CORRUPT
    CHECK(wp_status(VEX_WP_TEST_CORRUPT) == WP_E_CRC, "TEST BUILD: forced-corrupt wallpaper reports CRC");
    { uint32_t *m4; GfxFb f4 = mkfb(640, 480, &m4); wp_apply(1 == VEX_WP_TEST_CORRUPT ? 2 : 1, &f4); int before = wp_applied(); CHECK(wp_apply(VEX_WP_TEST_CORRUPT, &f4) == WP_E_CRC && wp_applied() == before, "TEST BUILD: applying a corrupt wallpaper fails and keeps the previous one"); wp_apply(0, &f4); free(m4); }
#endif
#ifdef VEX_WP_TEST_MISSING
    CHECK(wp_status(VEX_WP_TEST_MISSING) == WP_E_MISSING, "TEST BUILD: forced-missing wallpaper reports MISSING");
#endif
    printf("\n%d/%d wallpaper host checks passed\n", total - fails, total); return fails ? 1 : 0;
}
