# VexScript 3.0 Roadmap

```text
2.2.1 (2.0+++) ──► 3.0-A (types + RNG + specs)
                 ──► 3.0-B (tensor numeric core)
                 ──► 3.0-C (layers / forward)
                 ──► 3.0-D (evolution)
                 ──► 3.0-E (checkpoint / scale)
```

**Current:** Design complete; Phase A foundation next/in progress.

**Rule:** IR 2.0 accompanies 3.0; do not overload IR 1.2.

## Status update
- **3.0-A** complete (tensor types, RNG)
- **3.0-B** complete (tensor numeric core, IR 1.3 emit)
- Next: **3.0-C** layers / forward


## 3.0-C status
- neural_relu, neural_linear, neural_linear_bias, neural_forward_2
- Hosted + IR interpreter paths
- layer Dense(...) syntax sugar still Phase D/E optional


## 3.0-D status
- evolve_create / size / get / set / randomize
- evolve_mutate / crossover / select_tournament
- Deterministic with rng_seed
- Hosted + IR paths

