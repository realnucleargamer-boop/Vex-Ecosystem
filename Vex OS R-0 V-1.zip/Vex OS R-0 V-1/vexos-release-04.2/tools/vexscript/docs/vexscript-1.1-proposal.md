# VEX-Script 1.1 — Design Analysis & Proposal

## 1. Strengths of VEX-Script 1.0

- Clean, familiar, JavaScript-like surface that is still static and explicit.
- Strong separation of safe vs `unsafe`.
- Opaque `Handle` model — excellent for OS boundaries.
- No hidden runtime / no GC — good for systems and eventual bare-metal targeting.
- Explicit types and no implicit conversions — compiler-friendly.
- Clear “what is frozen / what is not” list.

## 2. Weaknesses & Gaps of 1.0 (as a usable language)

- No modules / multiple files → unusable for any non-trivial program.
- No real standard library beyond conceptual `print`/`println`.
- No error-handling story (no Result, no Option, no exceptions).
- `for` and `loop` are declared but underspecified.
- Fixed arrays exist in the syntax freeze but have no practical operations.
- No way to express “maybe a value” or “success/failure” cleanly.
- No tooling story (formatter, basic checker, package layout).
- String is frozen as a type but has almost no defined operations.
- No interoperability surface for future Vex AI or other languages.

## 3. Bugs / Design Problems

- Because 1.0 never had an implementation, there are no runtime bugs, but the specification left several semantic holes (exact `for` semantics, string operations, what `break`/`continue` do inside nested constructs).
- Treating all integer literals as a single width without clear rules can surprise users once multiple widths are used.

## 4. Syntax that must remain unchanged (compatibility)

- All frozen keywords.
- `fn`, `let`, `const`, `mut`, function syntax, `struct`, `type`.
- Control-flow skeleton (`if`/`else`/`while`/`for`/`loop`).
- `unsafe` block.
- `Handle = u64` direction.
- Explicit types and `as` casts.

## 5. Features that belong in 1.1 (evolutionary, high value)

1. **Modules / multi-file programs** (minimal `mod` + `use`)
2. **Standard library foundations** (`std::io`, `std::mem` stubs, basic string ops)
3. **Option and Result types** (library types, not new language syntax)
4. **Improved string operations** (len, concat, indexing under clear rules)
5. **Proper `for` and `loop` semantics** + `break`/`continue`
6. **Basic error reporting improvements** (more precise diagnostics)
7. **Project layout convention** (`src/`, `mod.vex`, etc.)
8. **Regression suite** that locks the 1.0 surface

## 6. Features that deliberately wait for 2.0 / later

- Generics / traits
- Async / concurrency
- Full ownership/borrow checker
- Macros
- Package manager
- Self-hosting compiler
- Deep Vex AI integration
- Advanced FFI
- SIMD
- Exceptions as control-flow

## 7. Design principle for 1.1

Every addition must:

- preserve the 1.0 surface,
- have a clear usability or reliability reason,
- keep the door open for a future real compiler backend (Vex IR → machine code),
- avoid coupling to Vex AI or Vex OS internals.

## 8. Implementation strategy for 1.1

Because no 1.0 compiler exists, VEX-Script 1.1 will be the **first concrete implementation**.  
It will:

- Accept the full 1.0 surface (compatibility).
- Add the 1.1 features listed above.
- Be implemented as an interpreter first (fast to test, easy to evolve), with a clear path to a later compiler backend.
- Carry a comprehensive test suite (positive + negative).

This is the pragmatic evolutionary path.
