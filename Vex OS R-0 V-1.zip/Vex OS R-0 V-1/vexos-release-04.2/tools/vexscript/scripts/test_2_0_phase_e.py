#!/usr/bin/env python3
"""VexScript 2.0 Phase E — x86-64 native backend"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vexscript.native import emit_asm, run_native, compile_native
from vexscript.compile_ir import run_via_ir
from vexscript.errors import VexError

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

print("VexScript 2.0 Phase E — x86-64 Backend")

def differential(src, name):
    ir_code, ir_out = run_via_ir(src)
    try:
        nat_code, nat_out = run_native(src)
    except Exception as e:
        check(name, False, f"native fail: {e}")
        return
    check(
        name,
        ir_code == nat_code and ir_out == nat_out,
        f"ir=({ir_code},{ir_out!r}) nat=({nat_code},{nat_out!r})",
    )

print("\n=== Codegen structure ===")
asm = emit_asm("fn main() -> i32 { return 0; }\n")
check("has main", "main:" in asm)
check("has prologue", "pushq %rbp" in asm)
check("has ret", "ret" in asm)

print("\n=== Differential (IR vs native) ===")
differential("""
fn main() -> i32 {
    println(1 + 2);
    return 0;
}
""", "add")

differential("""
fn main() -> i32 {
    println(10 * 5);
    return 0;
}
""", "mul")

differential("""
fn main() -> i32 {
    println(10 / 3);
    println(10 % 3);
    return 0;
}
""", "divmod")

differential("""
fn add(a: i64, b: i64) -> i64 { return a + b; }
fn main() -> i32 {
    println(add(7, 8));
    return 0;
}
""", "call")

differential("""
fn main() -> i32 {
    let x: i64 = 1;
    if (x < 2) {
        println(42);
    } else {
        println(0);
    }
    return 0;
}
""", "if")

differential("""
fn main() -> i32 {
    let mut i: i64 = 0;
    while (i < 3) {
        i = i + 1;
    }
    println(i);
    return 0;
}
""", "while")

print("\n=== Unsupported ===")
try:
    emit_asm("""
import vex::info;
fn main() -> i32 {
    println(vex::info::os_name());
    return 0;
}
""")
    check("reject hosted in native", False)
except VexError as e:
    check("reject hosted in native", "E0502" in str(e) or "not supported" in str(e).lower(), str(e))
except Exception as e:
    # may fail earlier on string println in IR path
    check("reject hosted in native", True, str(e))

print("\n=== Determinism ===")
src = "fn main() -> i32 { println(3 + 4); return 0; }\n"
check("asm deterministic", emit_asm(src) == emit_asm(src))

print(f"\n=== Phase E Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
