# VEX-Script Changelog — 1.3

## Phase 1 (complete) — Static type foundations
- Added `typecheck.py` lightweight static type checker
- Checks: let init types, return types, function arity/arg types (when annotated),
  struct field types on construction, field access types, assignment types
- Wired into `Interpreter.load` (runs after module resolution, before execution)
- Integer literals remain compatible with integer type annotations
- No implicit conversions between concrete types (e.g. bool ↛ i64)
- Regression: all 1.2 tests still pass (27/27)
- New negatives: let mismatch, arity, struct field type, return type (4/4)

## Remaining 1.3 phases (not started)
- Phase 2: Struct correctness hardening (chained field mutation, nested type checks)
- Phase 3: Module isolation improvements
- Phase 4: Diagnostics enrichment
- Phase 5: Interpreter robustness fixes
- Phase 6: Expanded regression suite + docs freeze

## Phase 2 (complete) — Struct correctness
- Chained field mutation (`r.origin.x = ...`) now checks mutability of the **root** binding
- Static rejection of field access on known non-struct types (e.g. `i64`)
- Static rejection of field assignment on known non-struct types
- Nested struct field types at construction already validated (confirmed)
- Regression: 27/27 still pass
- Phase 2 checks: 6/6 pass (chained R/W, immutable chain, nested type mismatch, field on i64, unknown nested field, deep nest)
