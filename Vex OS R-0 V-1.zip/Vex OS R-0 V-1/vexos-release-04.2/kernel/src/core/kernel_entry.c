/*
 * Vex OS - kernel/src/core/kernel_entry.c
 *
 * BOOT-02A kernel entry point.
 *
 * Current implemented boot chain:
 *   kernel_entry() -> validate BootInfo -> serial output ->
 *   Graphics 2 framebuffer init + boot splash -> gdt_init() ->
 *   idt_init() + self-test -> pmm_init() -> AP stack allocation
 *   self-test -> ... -> boot_progress_set(..., 100, ...) -> the
 *   existing BOOT-03 diagnostics dashboard + runtime UI -> halt.
 *
 * Graphics 2 (kernel/include/boot_progress.h, kernel/include/gfx/
 * progress.h) replaces the old fb_fill()/fb_bar() raw-pointer proof-
 * of-life hack with a real graphical "VEX OS" splash screen and a
 * loading bar driven by boot_progress_set() calls at each real stage
 * below - see docs/GRAPHICS-2.md.
 *
 * GDT (kernel/src/arch/x86_64/gdt/), IDT + exception handlers
 * (kernel/src/arch/x86_64/idt/), and a minimal bump-allocator PMM
 * (kernel/src/memory/physical/) are now implemented, per BOOT-02A.
 * Paging beyond what UEFI left in place, the kernel heap, ACPI,
 * APIC, and SMP are NOT implemented here - those are BOOT-02B and
 * later, built on top of this foundation, not before it.
 *
 * Interrupts are never enabled (`sti` is not called anywhere in this
 * file or anything it calls) - BOOT-02A's IDT is proven to dispatch
 * correctly (see idt_self_test) but real interrupt-driven work
 * (APIC timer, IPI-based SMP startup) is explicitly BOOT-02B's job.
 *
 * Freestanding C. No libc. No #include of any standard library
 * header. Linked at kernel_virtual_base = 0xFFFFFFFF80000000, but
 * for BOOT-01/02A we run at whatever physical address the bootloader
 * loaded us at (paging/higher-half relocation is a later milestone),
 * so this file must not assume its own high virtual address yet -
 * see linker script notes.
 */

#include "bootinfo.h"
#include "serial.h"
#include "panic.h"
#include "gdt.h"
#include "idt.h"
#include "pmm.h"
#include "ap_stack.h"
#include "acpi.h"
#include "lapic.h"
#include "ipi.h"
#include "tlb.h"
#include "smp.h"
#include "vmm.h"
#include "percpu.h"
#include "kstack.h"
#include "timer.h"
#include "boot03_tests.h"
#include "kernel01_tests.h"
#include "security01_tests.h"
#include "gfx/fb.h"
#include "gfx/screen.h"
#include "gfx/progress.h"
#include "boot_progress.h"
#include "graphics2_tests.h"
#include "ring3.h"
#include "security02_tests.h"
#include "pit_delay.h"

/* VISUAL VERIFICATION BUILD ONLY - NOT part of the normal boot path.
 * Real boot on real/TCG-emulated hardware completes in well under a
 * second, which is correct and exactly what BOOT-03 has always
 * targeted - but it also means a screenshot sequence cannot otherwise
 * catch the Graphics 2 splash bar moving between its real stages. This
 * #define, when set to 1, inserts a short real (PIT-measured) pause
 * after each boot_progress_set() purely so a human/screenshot can
 * observe the already-correct stage sequence; it changes nothing about
 * WHAT triggers a progress update or WHAT percent is shown, only adds
 * a pause so each one is visible. Builds shipped as the deliverable
 * set this back to 0 - see docs/GRAPHICS-2.md "Visual verification". */
#ifndef GRAPHICS2_VISUAL_DEMO
#define GRAPHICS2_VISUAL_DEMO 1   /* default unchanged; override: make EXTRA_CFLAGS=-DGRAPHICS2_VISUAL_DEMO=0 */
#endif
static inline void g2_demo_pause(void)
{
#if GRAPHICS2_VISUAL_DEMO
    pit_delay_us(5000000);
#endif
}

/* Real, measured "memory after boot" report - see docs/GRAPHICS-2.md
 * section 6, which previously could only report a conservative sum
 * because nothing queried live PMM state at the point boot completes.
 * __kernel_start/__kernel_end come from kernel/link.ld (already
 * existing symbols, not new); pmm_allocated_frames() is the existing
 * PMM query API (kernel/include/pmm.h) - this function invents no new
 * measurement mechanism, it just calls the ones that already exist, at
 * the one point in boot where "steady state" actually means something
 * (everything self-tests allocated has already been freed again by
 * here; see BOOT-03/KERNEL-01's own "nothing leaked" checks). */
extern char __kernel_start[];
extern char __kernel_end[];

#define MEM_BUDGET_PREVIOUS 5242880ULL     /* LOCK-01 target, kept for comparison */
#define MEM_BUDGET_DESKTOP01 20971520ULL   /* DESKTOP-01 budget: 20 MiB */
static BootInfo *g_mem_info; static uint64_t g_mem_peak;
static uint64_t mem_total(uint64_t *img, uint64_t *fb, uint64_t *pmm)
{
    *img = (uint64_t)(__kernel_end - __kernel_start);
    *fb = (g_mem_info && g_mem_info->framebuffer_addr) ? g_mem_info->framebuffer_size : 0;
    *pmm = pmm_allocated_frames() * PMM_PAGE_SIZE;
    return *img + *fb + *pmm;
}
static void mem_print(const char *tag)
{
    uint64_t img, fb, pmm, tot = mem_total(&img, &fb, &pmm);
    if (tot > g_mem_peak) g_mem_peak = tot;
    serial_puts("[memory] ["); serial_puts(tag); serial_puts("] kernel image="); serial_put_dec64(img);
    serial_puts(" framebuffer="); serial_put_dec64(fb);
    serial_puts(" pmm_frames="); serial_put_dec64(pmm_allocated_frames()); serial_puts(" ("); serial_put_dec64(pmm); serial_puts(" B)");
    serial_puts(" TOTAL="); serial_put_dec64(tot); serial_puts(" B ("); serial_put_dec64(tot / 1024);
    serial_puts(" KiB) sampled-peak="); serial_put_dec64(g_mem_peak);
    serial_puts(tot < MEM_BUDGET_DESKTOP01 ? " budget(20MiB)=PASS\n" : " budget(20MiB)=EXCEEDED\n");
}
/* Called by the UI at sign-in / terminal launch / terminal close: same accounting as the boot report. */
void memreport_snapshot(const char *tag) { mem_print(tag); }
void memreport_get(uint64_t *img, uint64_t *fb) { uint64_t p; (void)mem_total(img, fb, &p); }

static void boot_memory_report(BootInfo *info)
{
    g_mem_info = info;
    uint64_t img, fb, pmm, total_bytes = mem_total(&img, &fb, &pmm);
    g_mem_peak = total_bytes;
    serial_puts("\n[memory] Boot-complete memory report (measured, not estimated):\n");
    serial_puts("[memory]   kernel image (__kernel_start..__kernel_end, incl. .bss and all static buffers): "); serial_put_dec64(img);
    serial_puts(" bytes\n[memory]   framebuffer (BootInfo.framebuffer_size): "); serial_put_dec64(fb);
    serial_puts(" bytes\n[memory]   PMM frames currently allocated: "); serial_put_dec64(pmm_allocated_frames());
    serial_puts(" ("); serial_put_dec64(pmm); serial_puts(" bytes)\n[memory]   TOTAL: "); serial_put_dec64(total_bytes);
    serial_puts(" bytes ("); serial_put_dec64(total_bytes / 1024); serial_puts(" KiB)\n");
    serial_puts("[memory]   previous <5 MiB (5242880 B) LOCK-01 target, comparison only: ");
    serial_puts(total_bytes < MEM_BUDGET_PREVIOUS ? "PASS\n" : "EXCEEDED\n");
    serial_puts("[memory]   DESKTOP-01 budget 20 MiB (20971520 B): ");
    serial_puts(total_bytes < MEM_BUDGET_DESKTOP01 ? "PASS\n" : "EXCEEDED\n");
    serial_puts("[memory]   scope: image+framebuffer+PMM frames only. NOT measured: firmware/UEFI memory, page-table frames\n");
    serial_puts("[memory]   outside the PMM count, AP stacks reserved elsewhere, total physical RAM. Peak is sampled, not tracked.\n");
}
#include "input.h"
#include "user.h"
#include "ps2_keyboard.h"
#include "runtime_ui.h"
#include "ps2_mouse.h"
#include "power.h"
#include "netstatus.h"
#include "storage.h"
#include "vexui.h"
#include "input03_tests.h"
#include "desktop01_tests.h"
#include "accounts.h"
#include "apps.h"
#include "cpuacct.h"
#include "vfs.h"

/* Minimal freestanding memset/memcpy - no libc available. */
static void *k_memset(void *dst, int val, uint64_t n)
{
    uint8_t *d = (uint8_t *)dst;
    for (uint64_t i = 0; i < n; i++) d[i] = (uint8_t)val;
    return dst;
}

void *memcpy(void *dst, const void *src, size_t n)
{
    volatile uint8_t *d = (volatile uint8_t *)dst;
    const volatile uint8_t *s = (const volatile uint8_t *)src;

    for (size_t i = 0; i < n; i++)
        d[i] = s[i];

    return dst;
}

static int validate_bootinfo(BootInfo *info)
{
    if (info == 0) {
        serial_puts("[kernel] FATAL: BootInfo pointer is NULL\n");
        return 0;
    }
    if (info->magic != VEXOS_BOOTINFO_MAGIC) {
        serial_puts("[kernel] FATAL: BootInfo magic mismatch\n");
        return 0;
    }
    if (info->version != VEXOS_BOOTINFO_VERSION) {
        serial_puts("[kernel] FATAL: BootInfo version mismatch\n");
        return 0;
    }
    if (info->header_size != sizeof(BootInfo)) {
        serial_puts("[kernel] FATAL: BootInfo header_size mismatch "
                    "(bootloader/kernel built against different struct layouts)\n");
        return 0;
    }
    return 1;
}

/*
 * kernel_entry - the only symbol the bootloader jumps to.
 * System V AMD64: `info` arrives in RDI.
 */
void kernel_entry(BootInfo *info)
{
    /* Static: shared between the early Graphics 2 splash and the later
     * BOOT-03 diagnostics dashboard (gfx_boot_screen_draw) - one
     * framebuffer binding for the whole boot, not two. */
    static GfxFb gfx_fb;

    serial_init();
    serial_puts("\n[kernel] VEX OS kernel_entry() reached.\n");

    if (!validate_bootinfo(info)) {
        panic("BootInfo validation failed", 0, 0);
        /* panic() does not return */
    }

    serial_puts("[kernel] BootInfo validated OK.\n");
    serial_puts("[kernel] Architecture: x86-64\n");
    serial_puts("[kernel] Firmware: UEFI\n");

    /* Graphics 2: real framebuffer init + graphical boot splash,
     * replacing the old fb_fill()/fb_bar() raw-pointer hack. gfx_fb_init()
     * only reads BootInfo and a cast pointer - it has no dependency on
     * paging being active (see kernel/include/gfx/fb.h), so it is safe
     * here, exactly as safe as the raw hack it replaces, but it also
     * rejects pixel formats the renderer cannot decode (BITMASK/UNKNOWN),
     * which the raw hack did not check at all. */
    boot_progress_init();
#if GRAPHICS2_VISUAL_DEMO
    pit_delay_probe();
#endif
    int gfx2_ok = (info->framebuffer_addr != 0) && gfx_fb_init(&gfx_fb, info);
    if (gfx2_ok) {
        serial_puts("[kernel] Framebuffer: OK\n");
        gfx_boot_splash_bind(&gfx_fb);
        gfx_boot_splash_init(&gfx_fb);
        boot_progress_attach_renderer(gfx_boot_splash_render);
    } else {
        serial_puts(info->framebuffer_addr != 0
            ? "[kernel] Framebuffer: FAILED (unsupported pixel format)\n"
            : "[kernel] Framebuffer: NOT PRESENT\n");
    }
    boot_progress_set(BOOT_STAGE_FRAMEBUFFER, 10, "Framebuffer initialized");
    g2_demo_pause();

    serial_puts("[kernel] Memory Map: OK (");
    /* Minimal numeric output without a full printf - freestanding. */
    {
        char buf[24];
        uint64_t n = info->memory_map_size / (info->memory_map_desc_size ? info->memory_map_desc_size : 1);
        int i = 23;
        buf[i--] = 0;
        if (n == 0) buf[i--] = '0';
        while (n > 0 && i >= 0) {
            buf[i--] = (char)('0' + (n % 10));
            n /= 10;
        }
        serial_puts(&buf[i + 1]);
    }
    serial_puts(" descriptors)\n");

    /* --- BOOT-02A: GDT, IDT, PMM, AP stack allocation ---
     * Still no `sti` anywhere in this file or anything it calls -
     * per the BOOT-02A brief, interrupts stay globally disabled
     * until BOOT-02B's ACPI/APIC/SMP work is reviewed and built on
     * top of this. */

    gdt_init();
    {
        uint16_t cs = gdt_read_cs();
        serial_puts("[kernel] GDT: OK (CS=");
        serial_put_hex64(cs);
        serial_puts(cs == GDT_SEL_KERNEL_CODE ? ", matches expected 0x08)\n"
                                               : ", UNEXPECTED - does not match 0x08)\n");
    }

    idt_init();
    serial_puts("[kernel] IDT: OK (256 gates installed, PIC masked)\n");

    if (idt_self_test()) {
        serial_puts("[kernel] IDT self-test: PASS (int3 dispatched and returned)\n");
    } else {
        /* idt_common_handler prints its own diagnostics; reaching
         * here without the flag set means something returned
         * without going through the expected path. Not fatal on its
         * own, but worth flagging loudly rather than silently. */
        serial_puts("[kernel] IDT self-test: FAIL (flag not set after int3)\n");
    }
    boot_progress_set(BOOT_STAGE_CPU_TABLES, 20, "GDT / IDT installed");
    g2_demo_pause();

    pmm_init(info); /* prints its own arena summary to serial */

    {
        serial_puts("[kernel] AP stack allocation self-test (4 stacks, ");
        serial_put_dec64(AP_STACK_SIZE_PAGES * 4);
        serial_puts(" KiB each):\n");
        for (int i = 0; i < 4; i++) {
            uint64_t top = ap_stack_alloc_top();
            serial_puts("  stack[");
            serial_put_dec64((uint64_t)i);
            serial_puts("] top = ");
            serial_put_hex64(top);
            serial_puts("\n");
        }
        serial_puts("[kernel] PMM used so far: ");
        serial_put_dec64(pmm_arena_used_pages());
        serial_puts(" / ");
        serial_put_dec64(pmm_arena_total_pages());
        serial_puts(" pages\n");
    }
    boot_progress_set(BOOT_STAGE_MEMORY, 30, "Memory initialized");
    g2_demo_pause();


    /* --- BOOT-02B: ACPI -> MADT -> LAPIC detection/enumeration ---
     * Scaled down from the original BOOT-02 brief: this DETECTS
     * CPUs via the MADT and initializes the BSP's own LAPIC. It does
     * NOT start any secondary CPU - that's BOOT-02C. Still no `sti`
     * anywhere. */
    serial_puts("\n[kernel] VEX OS BOOT-02B\n");

    AcpiInfo acpi;
    int acpi_ok = acpi_init(info->rsdp_address, &acpi);
    serial_puts(acpi_ok ? "[kernel] ACPI: OK\n" : "[kernel] ACPI: FAILED\n");

    /* LOCK-01: FADT/DSDT power capabilities. Must run now, while the firmware
     * tables are still mapped (same assumption acpi_init makes). */
    (void)power_init(info->rsdp_address);

    if (acpi_ok) {
        serial_puts("[kernel] MADT: OK (local APIC base=");
        serial_put_hex64(acpi.local_apic_address);
        serial_puts(", ");
        serial_put_dec64(acpi.cpu_count);
        serial_puts(" processor entries)\n");
    } else {
        serial_puts("[kernel] MADT: SKIPPED (ACPI discovery failed)\n");
    }

    LapicInfo lapic;
    int lapic_ok = lapic_init(&lapic);
    if (lapic_ok) {
        serial_puts("[kernel] LAPIC: OK (BSP APIC ID=");
        serial_put_dec64(lapic.id);
        serial_puts(", base=");
        serial_put_hex64(lapic.physical_base);
        serial_puts(")\n");
    } else {
        serial_puts("[kernel] LAPIC: FAILED\n");
    }
    boot_progress_set(BOOT_STAGE_ACPI, 40, "ACPI / LAPIC discovered");
    g2_demo_pause();

    /* ---------------------------------------------------------------- *
     * BOOT-03 stage 1: take ownership of the page tables.
     *
     * This is placed AFTER ACPI/MADT/LAPIC discovery and BEFORE AP
     * startup, and both halves of that are deliberate:
     *
     *  - After discovery, because vmm_verify_before_activation() needs to
     *    know the LAPIC MMIO base in order to check that it is mapped, and
     *    mapped uncacheable, before the kernel starts depending on it.
     *    Discovery itself runs unchanged on the firmware tables, exactly
     *    as it did in BOOT-02B/02C.
     *
     *  - Before AP startup, because the BSP's CR3 is what gets copied into
     *    the AP trampoline data block. Starting APs first and switching
     *    page tables afterwards would leave every AP parked on firmware
     *    tables that the kernel no longer maintains.
     * ---------------------------------------------------------------- */
    serial_puts("\n[kernel] VEX OS BOOT-03: kernel paging\n");

    int paging_ok = 0;
    {
        VmmInfo vmi;
        uint64_t lapic_base_for_check = lapic_ok ? lapic.physical_base : 0;

        if (!vmm_build_kernel_tables(info, &vmi)) {
            serial_puts("[kernel] PAGING: FAILED to build kernel page tables -"
                        " staying on firmware tables\n");
        } else if (!vmm_verify_before_activation(info, lapic_base_for_check)) {
            /* Refuse to switch. A missing mapping found here is a printed
             * error; the same missing mapping found by loading CR3 is a
             * triple fault with no output at all. */
            serial_puts("[kernel] PAGING: FAILED verification - refusing to"
                        " activate the new page tables\n");
        } else {
            uint64_t old_cr3 = vmm_read_cr3();

            vmm_activate();

            uint64_t new_cr3 = vmm_read_cr3();
            serial_puts("[kernel] PAGING: CR3 ");
            serial_put_hex64(old_cr3);
            serial_puts(" -> ");
            serial_put_hex64(new_cr3);
            serial_puts(new_cr3 == vmi.pml4_phys ? " (kernel tables active)\n"
                                                 : " (UNEXPECTED value)\n");

            paging_ok = (new_cr3 == vmi.pml4_phys);

            if (paging_ok) {
                /* Touch the framebuffer again through the new tables - a
                 * real pixel round-trip (gfx_fb_selftest), not just a
                 * raw write with no readback. If the framebuffer mapping
                 * were wrong, this is where it would show - and it shows
                 * visibly, on the display (the splash would stop
                 * updating), not only on serial. */
                int fb_still_ok = gfx2_ok && gfx_fb_selftest(&gfx_fb);
                serial_puts(fb_still_ok
                    ? "[kernel] PAGING: OK (framebuffer, serial and"
                      " kernel code all live under kernel tables)\n"
                    : "[kernel] PAGING: OK, but framebuffer selftest FAILED"
                      " under kernel tables\n");
                gfx2_ok = fb_still_ok;
            }
        }
    }
    boot_progress_set(BOOT_STAGE_PAGING, 55,
        paging_ok ? "Kernel paging active" : "Paging unavailable (firmware tables)");
    g2_demo_pause();

    /* ---------------------------------------------------------------- *
     * BOOT-03 stage 2: CPU-local storage for the BSP.
     *
     * Done before AP startup so that the BSP's block is index 0 and so
     * that anything running on the BSP from here on can rely on %gs:0.
     * ---------------------------------------------------------------- */
    {
        uint64_t bsp_rsp;
        __asm__ volatile ("mov %%rsp, %0" : "=r"(bsp_rsp));

        int pc_ok = percpu_init_for_this_cpu(0, lapic_ok ? lapic.id : 0,
                                             bsp_rsp, 1 /* BSP */);
        if (pc_ok) pc_ok = percpu_verify_this_cpu(0);

        serial_puts(pc_ok
            ? "[kernel] PERCPU: OK (BSP block reachable via %gs:0)\n"
            : "[kernel] PERCPU: FAILED for the BSP\n");
    }

    /* ---------------------------------------------------------------- *
     * BOOT-02C: actually start the secondary CPUs.
     *
     * Everything above this point is unchanged BOOT-01/02A/02B
     * behaviour. AP startup is attempted only when both ACPI/MADT and
     * the BSP LAPIC are known good - sending INIT/SIPI based on a CPU
     * list we could not parse would be reckless.
     * ---------------------------------------------------------------- */
    static SmpInfo smp;   /* static: APs read this after kernel_entry's
                           * frame would otherwise still be live, and a
                           * multi-KiB struct does not belong on the
                           * 16 KiB boot stack. */

    if (acpi_ok && lapic_ok) {
        serial_puts("\n[kernel] VEX OS BOOT-02C: starting secondary CPUs\n");

        int all_up = smp_start_aps(info, &acpi, lapic.id, &smp);

        for (uint32_t i = 0; i < smp.cpu_count && i < ACPI_MAX_CPUS; i++) {
            CpuInfo *c = &smp.cpus[i];

            serial_puts("CPU ");
            serial_put_dec64(c->expected_apic_id);
            serial_puts(": ");
            serial_puts(smp_state_name(c->state));

            /* For a CPU that came online, print the identity the CPU
             * itself reported and the stack it was given. This is the
             * evidence that the AP executed kernel C code - it is not
             * derived from the MADT. */
            if (c->state == CPU_STATE_ONLINE) {
                serial_puts(" - self-reported APIC ID ");
                serial_put_dec64(c->reported_apic_id);
                serial_puts(", stack top ");
                serial_put_hex64(c->stack_top);
            }
            serial_puts("\n");
        }

        serial_puts("[kernel] SMP: ");
        serial_put_dec64(smp.online_count);
        serial_puts("/");
        serial_put_dec64(smp.cpu_count);
        serial_puts(" CPUs online");
        if (smp.failed_count > 0) {
            serial_puts(" (");
            serial_put_dec64(smp.failed_count);
            serial_puts(" FAILED)");
        }
        serial_puts("\n");

        serial_puts(all_up
            ? "[kernel] SMP: PASS - every enabled CPU reached AP C code\n"
            : "[kernel] SMP: INCOMPLETE - see per-CPU status above\n");
    } else {
        /* Preserved BOOT-02B fallback wording for the case where CPU
         * discovery did not work: no CPU is claimed to be online that
         * has not been proven online. */
        serial_puts("CPU 0: ONLINE (BSP) - MADT/LAPIC unavailable,"
                    " CPU count unknown\n");
        serial_puts("[kernel] SMP: 1/1 CPUs online"
                    " (ACPI/MADT or LAPIC discovery failed)\n");
    }
    boot_progress_set(BOOT_STAGE_SMP, 70, "SMP CPUs online");
    g2_demo_pause();

    /* ---------------------------------------------------------------- *
     * BOOT-03 stage 3: the LAPIC timer, and the first `sti` in the
     * history of this project.
     *
     * Deliberately AFTER AP startup. The INIT-SIPI-SIPI sequence uses
     * polled PIT delays and bounded spin loops with precise timing
     * expectations; taking timer interrupts in the middle of it would
     * change the timing of the one part of the system that is known to be
     * timing-sensitive, for no benefit. Bring the CPUs up first, then
     * turn on interrupts.
     * ---------------------------------------------------------------- */
    int timer_ok = 0;
    if (lapic_ok) {
        timer_ok = timer_init(lapic.physical_base);
        if (timer_ok) {
            /* THE FIRST `sti` IN VEX OS.
             *
             * Safe on the BSP specifically because: the legacy PIC is
             * masked (idt_init), the IDT has real gates for all 256
             * vectors, the BSP has a TSS loaded with IST1 for #DF, the
             * LAPIC is software-enabled with a dedicated spurious vector,
             * and the only unmasked LAPIC interrupt source is the timer
             * on a vector with a handler.
             *
             * KERNEL-01 Phase 2: APs now do this too, in ap_entry(),
             * once each has its own TSS/IST, its own CPU-local storage,
             * and its own LAPIC software-enabled. */
            __asm__ volatile ("sti");
            serial_puts("[kernel] INTERRUPTS: enabled on the BSP (first `sti`"
                        " in Vex OS; APs enable their own in ap_entry)\n");
        } else {
            serial_puts("[kernel] TIMER: FAILED - interrupts left disabled\n");
        }
    } else {
        serial_puts("[kernel] TIMER: SKIPPED (no working LAPIC)\n");
    }
    boot_progress_set(BOOT_STAGE_TIMER, 80, "Timer / interrupts enabled");
    g2_demo_pause();

    /* ---------------------------------------------------------------- *
     * KERNEL-01 Phase 3: arm the IPI layer.
     *
     * Deliberately after smp_start_aps() has finished, because ipi_init()
     * captures the CPU inventory it uses to validate targets, and an
     * inventory read while CPUs were still coming up would let a send to
     * a not-yet-online CPU be accepted. Nothing sends an IPI before this
     * point.
     * ---------------------------------------------------------------- */
    int ipi_ok = 0;
    if (acpi_ok && lapic_ok) {
        ipi_ok = ipi_init(&smp, lapic.physical_base);
    }
    serial_puts(ipi_ok ? "[kernel] IPI: layer armed (fixed delivery,"
                         " physical destination)\n"
                       : "[kernel] IPI: SKIPPED (no LAPIC or no CPU"
                         " inventory)\n");

    /* ---------------------------------------------------------------- *
     * KERNEL-01 Phase 4: arm cross-CPU TLB shootdown.
     *
     * After the IPI layer, because tlb_init() registers a vector that it
     * will send through that layer, and the layer refuses to send vectors
     * with no registered handler.
     *
     * Every mapping change made BEFORE this point was made while exactly
     * one CPU was running, so a local invlpg was a complete shootdown and
     * no retroactive flush is needed. Shootdowns attempted before this
     * point degrade to local invalidation and report
     * TLB_OK_LOCAL_ONLY - see tlb.h.
     * ---------------------------------------------------------------- */
    int tlb_ok = 0;
    if (ipi_ok) {
        tlb_ok = (tlb_init(&smp) == TLB_OK);
    }
    serial_puts(tlb_ok ? "[kernel] TLB: cross-CPU shootdown armed on vector"
                         " 0x40\n"
                       : "[kernel] TLB: SKIPPED (no IPI layer; local"
                         " invalidation only)\n");

    /* ---------------------------------------------------------------- *
     * BOOT-03 stage 4: prove it. Every claim in the summary block below
     * comes from a check that ran on this machine, on this boot.
     * ---------------------------------------------------------------- */
    static Boot03Results results;
    boot03_run_tests(info, (acpi_ok && lapic_ok) ? &smp : 0,
                     lapic_ok ? lapic.physical_base : 0, &results);

    /* Subsystems whose failure the tests cannot observe from the inside
     * are folded in here rather than left implicit. */
    if (!paging_ok) results.paging = 0;
    if (!timer_ok) results.timer = 0;

    /* ---------------------------------------------------------------- *
     * KERNEL-01 self-tests.
     *
     * Runs BEFORE boot03_print_summary, and this ordering is load-
     * bearing rather than stylistic. scripts/smp-test.sh polls the
     * serial log for "SYSTEM READY" and terminates QEMU shortly after it
     * appears, so anything printed after that line can be truncated out
     * of the captured log. Evidence that can be cut off is not evidence.
     *
     * The two suites keep separate check counters, so BOOT-03 still
     * reports its own unchanged tally and every pre-existing assertion
     * in scripts/ - including the literal "105/105" that
     * scripts/mttcg-matrix.sh greps for - is untouched by this
     * milestone. See kernel/include/kernel01_tests.h.
     * ---------------------------------------------------------------- */
    static Kernel01Results k01;
    kernel01_run_tests((acpi_ok && lapic_ok) ? &smp : 0, &k01);
    kernel01_print_summary(&k01);

    /* Fold KERNEL-01 into the readiness gate. Without this, a KERNEL-01
     * failure would still print SYSTEM READY and every harness in
     * scripts/ would report the boot as green - which would also make the
     * KERNEL-01 negative controls impossible to write. See
     * boot03_gate_and() in boot03_tests.h. */
    boot03_gate_and(kernel01_all_passed(&k01));

    /* ----------------------------------------------------------------
     * SECURITY-01.
     *
     * Runs after KERNEL-01 because it uses the kmap allocator and the
     * page tables that milestone finished, and before the BOOT-03
     * summary for the same truncation reason: smp-test.sh terminates
     * QEMU shortly after SYSTEM READY, so evidence printed later can be
     * cut out of the log.
     *
     * Folded into the same readiness gate. A SECURITY-01 failure must
     * suppress SYSTEM READY, or the negative controls could not be
     * written - an injection that breaks a security invariant has to be
     * observable as a failed boot, not just as a line in a log nobody
     * greps.
     *
     * Note what is deliberately absent: no "SECURITY-01 COMPLETE" is
     * printed anywhere, by this call or by the suite. There is no Ring 3
     * in this build, so the milestone as specified is not complete and
     * the kernel must not say that it is.
     * ---------------------------------------------------------------- */
    static Security01Results s01;
    security01_run_tests(&s01);
    security01_print_summary(&s01);
    boot03_gate_and(security01_all_passed(&s01));

    /* Graphics 2 self-tests - see kernel/include/graphics2_tests.h.
     * Runs here (gated into readiness exactly like KERNEL-01/SECURITY-01)
     * rather than only at the very end, for the same truncation reason:
     * scripts/smp-test.sh stops reading serial shortly after SYSTEM
     * READY appears. */
    static Graphics2Results g2;
    graphics2_run_tests(gfx2_ok ? &gfx_fb : 0, &g2);
    graphics2_print_summary(&g2);
    boot03_gate_and(graphics2_all_passed(&g2));

    /* SECURITY-02: Ring 3 foundation + audit suite. Deliberately AFTER
     * security01_run_tests(): SECURITY-01 asserts that zero user-accessible
     * page-table entries exist and that TSS.rsp0 is still zero, both true
     * only until ring3_init() runs. Running SECURITY-01 first keeps those
     * checks asserting exactly what they always asserted, unweakened. */
    int ring3_ok = ring3_init();
    static Security02Results s02;
    security02_run_tests(&s02);
    security02_print_summary(&s02);
    boot03_gate_and(ring3_ok && security02_all_passed(&s02));

    boot_progress_set(BOOT_STAGE_SELFTEST, 90, "Self-tests complete");
    g2_demo_pause();

    /* INPUT-02 is intentionally hardware-neutral: PS/2/USB drivers may
     * publish here later without exposing their registers to consumers. */
    input_init();
    int input_ok = input_self_test() && ps2_keyboard_init();
    serial_puts(input_ok ? "[kernel] INPUT-02: queue + PS/2 polling ready\n"
                                  : "[kernel] INPUT-02: event queue self-test FAIL\n");
    /* INPUT-03: logic self-tests (no hardware), then bring up the PS/2 mouse. */
    static Input03Results i03;
    input03_run_tests(&i03);
    input03_print_summary(&i03);
    boot03_gate_and(input03_all_passed(&i03));
    static Desktop01Results d01;
    desktop01_run_tests(&d01);
    desktop01_print_summary(&d01);
    boot03_gate_and(desktop01_all_passed(&d01));
    input_init();                         /* tests leave the queues dirty */
    int mouse_ok = ps2_mouse_init();
    (void)netstatus_probe();
    storage_init();                       /* STORAGE-01: PCI scan -> AHCI -> Vex data disk (never writes a disk it did not format) */
    user_init();
    int user_ok = user_kernel_service_register(VEX_CAP_INPUT | VEX_CAP_IPC) != 0 && user_kernel_service_register(VEX_CAP_GRAPHICS | VEX_CAP_IPC) != 0;
    serial_puts("[kernel] USER-02: service/handle foundation initialized\n");
    boot_progress_set(BOOT_STAGE_SERVICES, 97, "Input / user services ready");
    g2_demo_pause();

    boot_memory_report(info);

    serial_puts("\n");
    boot03_print_summary(&results);
    boot_progress_set(BOOT_STAGE_DONE, 100, "Boot complete");
    g2_demo_pause();

    /* ---------------------------------------------------------------- *
     * Native graphics — written specifically for BOOT-03's architecture.
     * Called last: needs paging, real PMM stats, real SMP facts, real
     * KERNEL-01 and SECURITY-01 results — all of which are known here.
     * See kernel/include/gfx/ and kernel/src/graphics/.
     * ---------------------------------------------------------------- */
    static GfxConsole gfx_con;
    static GfxBootStatus gfx_st;

    gfx_st.acpi_ok   = acpi_ok;
    gfx_st.lapic_ok  = lapic_ok;
    gfx_st.paging_ok = paging_ok;
    gfx_st.timer_ok  = timer_ok;
    gfx_st.smp_ok    = (acpi_ok && lapic_ok) ? 1 : 0;
    gfx_st.cpu_count = (acpi_ok && lapic_ok) ? smp.online_count : 1;
    gfx_st.usable_mib = pmm_usable_frames() * VMM_PAGE_SIZE / (1024u * 1024u);
    gfx_st.free_mib   = pmm_free_frames()   * VMM_PAGE_SIZE / (1024u * 1024u);
    gfx_st.b03        = &results;
    gfx_st.k01        = &k01;
    gfx_st.s01        = &s01;

    /* gfx_fb was already initialised by Graphics 2 at the top of boot
     * (gfx2_ok); re-running gfx_fb_init() here would just re-read the
     * same BootInfo fields into the same struct, so we reuse gfx2_ok
     * directly instead of calling it twice. */
    if (paging_ok && gfx2_ok) {
        gfx_boot_screen_draw(&gfx_fb, &gfx_con, &gfx_st);
        gfx_boot_screen_write_status(&gfx_con, &gfx_st);
        serial_puts("[kernel] VEX GRAPHICS ONLINE\n");
        (void)runtime_ui_init;   /* legacy diagnostics page kept in the build, no longer shown */
    } else {
        serial_puts("[kernel] graphics: skipped (no framebuffer or paging"
                    " not active)\n");
    }

    (void)k_memset; /* silence unused-static warning until heap milestone uses it */

    cpuacct_init(); vfs_init(); acct_init(); apps_tracker_reset();       /* tests used the store: start the real session empty */
#ifdef VEX_DEV_SEED_ACCOUNTS
    /* DEV/TEST BUILD ONLY (make EXTRA_CFLAGS=-DVEX_DEV_SEED_ACCOUNTS=1): pre-populates accounts so the
     * multi-account UI can be exercised end-to-end. Never enabled in the shipped configuration. */
    (void)acct_dev_create_pw("Vex", "vexpass1", ACCT_ROLE_ADMIN); (void)acct_dev_create_pw("Nexus", "nexuspw1", ACCT_ROLE_STANDARD); (void)acct_dev_create_pw("Bob", "bobpass1", ACCT_ROLE_STANDARD); (void)acct_select(0);
    serial_puts("[dev] VEX_DEV_SEED_ACCOUNTS: seeded 3 test accounts (NOT a product default)\n");
#endif
    /* LOCK-01: lock screen + session UI. Works headless (no framebuffer) too. */
    {
        VexUiFacts uf;
        uf.graphics_ok = gfx2_ok; uf.input_ok = input_ok; uf.user_ok = user_ok;
        uf.mouse_present = mouse_ok;
        uf.cpu_count = (acpi_ok && lapic_ok) ? smp.online_count : 1;
        uf.sec02_run = s02.checks_run; uf.sec02_failed = s02.checks_failed;
        vexui_init((paging_ok && gfx2_ok) ? &gfx_fb : 0, &uf);
    }

    /* Park the BSP with interrupts ENABLED, so the timer keeps ticking
     * and the machine is demonstrably alive rather than merely stopped.
     * `sti; hlt` in that order matters: `sti` unblocks interrupts after
     * the following instruction boundary, so an interrupt cannot slip in
     * between and leave the CPU halted with interrupts disabled.
     * Input is polled once per timer tick (100 Hz): no busy-wait. */
    for (;;) {
        ps2_keyboard_poll();
        vexui_poll();
        if (timer_ok) {
            cpuacct_idle_begin();
            __asm__ volatile ("sti; hlt");
            cpuacct_idle_end();
        } else {
            __asm__ volatile ("cli; hlt");
        }
    }
}


