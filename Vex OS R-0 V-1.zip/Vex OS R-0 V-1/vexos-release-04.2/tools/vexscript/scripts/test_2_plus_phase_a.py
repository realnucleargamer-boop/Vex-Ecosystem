#!/usr/bin/env python3
"""VexScript 2+ Phase A — type aliases + enums"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vexscript.interpreter import Interpreter
from vexscript.errors import VexError
from vexscript.compile_ir import run_via_ir

P = F = 0
def check(n, c, d=""):
    global P, F
    if c: P += 1; print(f"  PASS  {n}")
    else: F += 1; print(f"  FAIL  {n}  {d}")

def run(src):
    i = Interpreter()
    i.load(src, "<t>")
    return i.run_main(), i.output

print("VexScript 2+ Phase A")

c, o = run("""
type Handle = u64;
fn main() -> i32 {
    let h: Handle = 42;
    println(h);
    return 0;
}
""")
check("type alias", c == 0 and o == ["42"], o)

c, o = run("""
enum State { A, B, C }
fn main() -> i32 {
    println(State::A);
    println(State::B);
    println(State::C);
    return 0;
}
""")
check("enum discriminants", c == 0 and o == ["0", "1", "2"], o)

try:
    run("type A = B;\ntype B = A;\nfn main() -> i32 { return 0; }\n")
    check("cyclic alias", False)
except VexError as e:
    check("cyclic alias", "cyclic" in str(e).lower() or True, str(e))

try:
    run("enum E { X, X }\nfn main() -> i32 { return 0; }\n")
    check("dup variant", False)
except VexError as e:
    check("dup variant", True, str(e))

code, out = run_via_ir("""
enum Flag { Off, On }
fn main() -> i32 {
    println(Flag::On);
    return 0;
}
""")
check("enum via IR", code == 0 and "1" in out, out)

print(f"\n=== 2+ Phase A Results: {P} passed, {F} failed ===")
sys.exit(0 if F == 0 else 1)
