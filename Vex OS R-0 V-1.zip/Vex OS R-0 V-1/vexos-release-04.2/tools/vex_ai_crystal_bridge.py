#!/usr/bin/env python3
"""Safe host-side bridge to a separately installed VEX AI 1.5-Crystal engine."""
import argparse, json, os, subprocess, sys

def run(engine, args):
    result = subprocess.run([sys.executable, engine, *args], text=True, capture_output=True, timeout=60)
    if result.returncode: raise RuntimeError(result.stderr.strip() or "Crystal engine failed")
    try: payload = json.loads(result.stdout.strip().splitlines()[-1])
    except (IndexError, json.JSONDecodeError) as exc: raise RuntimeError("Crystal engine did not return one JSON object") from exc
    if not isinstance(payload, dict) or not payload.get("ok"): raise RuntimeError(str(payload.get("error", "Crystal engine rejected the request")))
    return payload

def main():
    p = argparse.ArgumentParser(description="VEX OS Release 04 Crystal host bridge")
    p.add_argument("--engine", default=os.environ.get("VEX_CRYSTAL_ENGINE"), help="path to Crystal scripts/engine.py")
    g = p.add_mutually_exclusive_group(required=True); g.add_argument("--status", action="store_true"); g.add_argument("--ask", metavar="TEXT")
    p.add_argument("--profile", default="normal"); ns = p.parse_args()
    if not ns.engine or not os.path.isfile(ns.engine): p.error("provide an existing Crystal engine.py with --engine or VEX_CRYSTAL_ENGINE")
    args = ["--status"] if ns.status else ["--infer", ns.ask, ns.profile]
    try: print(json.dumps(run(ns.engine, args), separators=(",", ":")))
    except (RuntimeError, subprocess.TimeoutExpired) as exc: print(json.dumps({"ok":False,"error":str(exc)})); return 1
    return 0
if __name__ == "__main__": raise SystemExit(main())
